No info.json is present.
