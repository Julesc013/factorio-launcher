using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Automation;
using FacMan.WinForms;
internal static class StartupProbe {
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool QueryFullProcessImageName(IntPtr p,uint flags,StringBuilder name,ref int size);
 [DllImport("user32.dll")] static extern bool EnumChildWindows(IntPtr parent,EnumProc callback,IntPtr data);
 delegate bool EnumProc(IntPtr handle,IntPtr data);
 [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern IntPtr SendMessageTimeout(IntPtr h,uint message,IntPtr count,StringBuilder text,uint flags,uint timeout,out IntPtr result);
 [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h,out Rect r);
 [DllImport("user32.dll")] static extern bool PrintWindow(IntPtr h,IntPtr dc,uint flags);
 [DllImport("user32.dll")] static extern bool PostMessage(IntPtr h,uint message,IntPtr w,IntPtr l);
 [StructLayout(LayoutKind.Sequential)] struct Rect { public int left,top,right,bottom; }
 static string Hash(string p) { using(var s=File.OpenRead(p)) using(var h=SHA256.Create())return String.Concat(h.ComputeHash(s).Select(b=>b.ToString("x2"))); }
 static void Need(bool ok,string why){if(!ok)throw new InvalidOperationException(why);}
 static List<string> Texts(IntPtr h) {
  var rows=new List<string>();int seen=0;
  EnumChildWindows(h,delegate(IntPtr c,IntPtr unused) {
   if(++seen>512)throw new InvalidOperationException("Control budget exceeded");
   if(IsWindowVisible(c)){var b=new StringBuilder(4096);IntPtr result;
    Need(SendMessageTimeout(c,0x000d,(IntPtr)b.Capacity,b,2,500,out result)!=IntPtr.Zero,"Control text query timed out");
    if(b.Length>0)rows.Add(b.ToString());}
   return true;},IntPtr.Zero);return rows;
 }
 static Task<byte[]> Drain(Stream stream,WindowsContainedProcess p) { return Task.Run(delegate {
  using(var saved=new MemoryStream()){byte[] b=new byte[4096];int n;
   while((n=stream.Read(b,0,b.Length))!=0){if(saved.Length+n>65536){p.TerminateTree();throw new InvalidOperationException("Stream limit exceeded");}saved.Write(b,0,n);}
   return saved.ToArray();}
 });}
 static void Save(string path,object value) {File.WriteAllText(path,new JavaScriptSerializer {MaxJsonLength=1048576}.Serialize(value));}
 [STAThread] static int Main(string[] a) {
  var watch=Stopwatch.StartNew();var texts=new List<string>();int pid=0;
  try {
   Need(a.Length==4,"Expected GUI, digest, workspace, evidence");
   string gui=Path.GetFullPath(a[0]),expected=a[1],workspace=Path.GetFullPath(a[2]),evidence=Path.GetFullPath(a[3]);
   Environment.SetEnvironmentVariable("FACMAN_PRESENTATION_MODE","live");
   Environment.SetEnvironmentVariable("FACMAN_WORKSPACE",workspace);
   Need(!Directory.Exists(workspace)&&!File.Exists(workspace),"Workspace must start absent");
   using(var owned=WindowsContainedProcess.StartSuspended(gui,"",
    delegate{Need(Hash(gui)==expected,"GUI hash changed before dispatch");},
    delegate(IntPtr handle){var b=new StringBuilder(32768);int count=b.Capacity;Need(QueryFullProcessImageName(handle,0,b,ref count),"Cannot observe suspended image");Need(String.Equals(Path.GetFullPath(b.ToString()),gui,StringComparison.OrdinalIgnoreCase),"Suspended image path differs");})) {
    pid=owned.ProcessId;owned.CloseInput();var stdout=Drain(owned.StandardOutput,owned);var stderr=Drain(owned.StandardError,owned);
    owned.Resume();using(var proc=Process.GetProcessById(pid)) {
     IntPtr window=IntPtr.Zero;
     while(watch.Elapsed.TotalSeconds<40){Need(!proc.HasExited,"GUI exited before window");proc.Refresh();window=proc.MainWindowHandle;if(window!=IntPtr.Zero)break;Thread.Sleep(100);}
     Need(window!=IntPtr.Zero,"GUI window deadline");var root=AutomationElement.FromHandle(window);
     Need(root.Current.ProcessId==pid&&root.Current.ControlType==ControlType.Window,"Wrong UIA process/window");
     Need(root.Current.Name=="FacMan C1 product window","Wrong product window identity");
     var tabs=root.FindFirst(TreeScope.Descendants,new PropertyCondition(AutomationElement.NameProperty,"FacMan product pages"));Need(tabs!=null,"Product pages missing");
     var settings=tabs.FindFirst(TreeScope.Descendants,new AndCondition(new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.TabItem),new PropertyCondition(AutomationElement.NameProperty,"Settings / About")));
     Need(settings!=null,"Settings tab missing");((SelectionItemPattern)settings.GetCurrentPattern(SelectionItemPattern.Pattern)).Select();
     bool ready=false;
     while(watch.Elapsed.TotalSeconds<40){Need(!proc.HasExited,"GUI exited during refresh");texts=Texts(window);string all=String.Join("\n",texts);
      if(all.Contains("Workspace: "+workspace)&&all.Contains("Status: uninitialized")&&!all.Contains("frontend_backend_projection_failed")){ready=true;break;}Thread.Sleep(150);}
     Save(Path.Combine(evidence,"visible-text.json"),texts);
     Rect bounds;Need(GetWindowRect(window,out bounds),"Missing window bounds");
     using(var bmp=new Bitmap(bounds.right-bounds.left,bounds.bottom-bounds.top))
      using(var graphics=Graphics.FromImage(bmp)){IntPtr dc=graphics.GetHdc();bool printed;try{printed=PrintWindow(window,dc,2);}finally{graphics.ReleaseHdc(dc);}Need(printed,"Target PrintWindow failed");bmp.Save(Path.Combine(evidence,"startup-settings.png"),ImageFormat.Png);}
     Need(ready,"Backend-derived workspace did not become available");
     Need(!Directory.Exists(workspace)&&!File.Exists(workspace),"Read-only startup changed absent workspace");
     Need(PostMessage(window,0x0010,IntPtr.Zero,IntPtr.Zero),"Cannot request normal close");
     Need(owned.ExitTask.Wait(5000),"Normal close deadline");Need(owned.ExitTask.Result==0,"GUI close exit failure");
     Need(owned.WaitForTreeEmptyAsync(DateTime.UtcNow.AddSeconds(5)).GetAwaiter().GetResult(),"Child tree still active");
     Need(Task.WaitAll(new Task[]{stdout,stderr},5000),"Stream drain deadline");
     File.WriteAllBytes(Path.Combine(evidence,"product.stdout"),stdout.Result);File.WriteAllBytes(Path.Combine(evidence,"product.stderr"),stderr.Result);
     Save(Path.Combine(evidence,"startup-result.json"),new {result="PASS",process_id=pid,gui=gui,sha256=Hash(gui),window_name="FacMan C1 product window",workspace=workspace,workspace_remained_absent=true,live_backend_workspace_rendered=true,normal_exit=owned.ExitTask.Result,tree_empty=true,seconds=watch.Elapsed.TotalSeconds});
    }
   }return 0;
  }catch(Exception error){if(a.Length==4)Save(Path.Combine(a[3],"startup-failure.json"),new {result="FAIL",error=error.ToString(),process_id=pid,texts=texts,seconds=watch.Elapsed.TotalSeconds});Console.Error.WriteLine(error);return 1;}
 }
}