import hashlib,json,os,subprocess,sys,time
from pathlib import Path
from xml.sax.saxutils import escape
E=Path(__file__).resolve().parent
R=Path(r"C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\worktrees\task-facman-resource-identity-01")
sys.path.insert(0,str(R))
from tools.winforms_build import msbuild_executable
plan=json.loads((E/"plan.json").read_bytes());P=Path(plan["package_root"]);run=E.parent.parent.parent/"ps8dc"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(["git",*a],cwd=R,timeout=30).decode().strip()
def snapshot():
 assert git("rev-parse","HEAD")==plan["source_head"] and git("rev-parse","HEAD^{tree}")==plan["source_tree"]
 assert not git("status","--porcelain=v1","--untracked-files=all")
 return [{"path":p.relative_to(P).as_posix(),"sha256":sha(p),"bytes":p.stat().st_size} for p in sorted(P.rglob("*")) if p.is_file()]
before=snapshot();assert sha(P/"FacMan.exe")==plan["executable_sha256"]
assert sha(Path(plan["containment_source"]["path"]))==plan["containment_source"]["sha256"]
assert run.resolve().parent==E.parents[2].resolve() and run.name=="ps8dc"
run.mkdir(exist_ok=False);(run/"bin").mkdir();(run/"t").mkdir()
refs=["System","System.Core","System.Drawing","System.Web.Extensions","System.Windows.Forms","UIAutomationClient","UIAutomationTypes","WindowsBase"]
project=run/"StartupProbe.csproj"
project.write_text('<Project ToolsVersion="15.0" xmlns="http://schemas.microsoft.com/developer/msbuild/2003"><PropertyGroup><OutputType>Exe</OutputType><TargetFrameworkVersion>v4.8</TargetFrameworkVersion><AssemblyName>StartupProbe</AssemblyName><PlatformTarget>x64</PlatformTarget></PropertyGroup><ItemGroup>'+''.join('<Reference Include="'+x+'" />' for x in refs)+'<Compile Include="'+escape(str(E/"StartupProbe.cs"))+'" /><Compile Include="'+escape(plan["containment_source"]["path"])+'" /></ItemGroup><Import Project="$(MSBuildToolsPath)\\Microsoft.CSharp.targets" /></Project>')
records=[]
def command(label,args,budget):
 t=time.monotonic()
 try:
  p=subprocess.run(args,cwd=run,capture_output=True,timeout=budget,env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1",TEMP=str(run/"t"),TMP=str(run/"t")))
  code=p.returncode;out=p.stdout;err=p.stderr;timeout=False
 except subprocess.TimeoutExpired as e:code=None;out=e.stdout or b"";err=e.stderr or b"";timeout=True
 row={"label":label,"argv":args,"budget_seconds":budget,"exit_code":code,"timed_out":timeout,"seconds":time.monotonic()-t}
 for name,data in [("stdout",out),("stderr",err)]:
  path=E/(label+"."+name);path.write_bytes(data);row[name]={"path":path.name,"bytes":len(data),"sha256":sha(path)}
 records.append(row);(E/"commands.json").write_text(json.dumps(records,indent=2)+"\n")
 print(json.dumps({"label":label,"exit_code":code,"seconds":row["seconds"]}),flush=True)
 assert code==0 and not timeout,label
try:
 command("build",[msbuild_executable(),str(project),"/p:Configuration=Release","/p:Platform=x64","/m:1",f"/p:OutputPath={run/'bin'}{os.sep}",f"/p:IntermediateOutputPath={run/'obj'}{os.sep}"],120)
 command("startup",[str(run/"bin/StartupProbe.exe"),str(P/"FacMan.exe"),plan["executable_sha256"],str(run/"fresh-workspace"),str(E)],75)
 assert before==snapshot()
 result={"schema":"facman.packaged-gui-startup-proof.v1","result":"PASS","plan_sha256":sha(E/"plan.json"),"source_head":plan["source_head"],"package_files_unchanged":before,"commands":records,"runtime_result":json.loads((E/"startup-result.json").read_bytes()),"limits":plan["limits"]}
 (E/"result.json").write_text(json.dumps(result,indent=2)+"\n")
 print(json.dumps({"result":"PASS","receipt":str(E/"result.json"),"sha256":sha(E/"result.json")}),flush=True)
except BaseException as error:
 (E/"failure.json").write_text(json.dumps({"result":"FAIL","error":repr(error),"source_and_package_unchanged":before==snapshot(),"commands":records,"retained_root":str(run)},indent=2)+"\n")
 raise
