import hashlib,json,subprocess,sys,zipfile
from pathlib import Path
E,O,R=map(Path,sys.argv[1:])
def sha(b):return hashlib.sha256(b).hexdigest()
def meta(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def git(*args):
 p=subprocess.run(['git','-C',str(R),*args],capture_output=True,timeout=30,check=True);return p.stdout
old=json.loads((O/'source-manifest.json').read_bytes()); new=json.loads((E/'source-manifest.json').read_bytes())
assert sha((E/'source-manifest.json').read_bytes())=='af3557b9cf65d58a848725832867c52cd6021ab25e995e2a4924b4ea83111aba'
assert sha((O/'source-manifest.json').read_bytes())=='d8788d5313fc49e6674790b9d2f4017aa0554e5ba11521a9a25a1ca4258ef5a8'
assert sha((O/'independent-original-review.json').read_bytes())=='e5a0b557eb19ac1cf40f93e098cd215e7a3749a54376a75d026f9af63dc8c1e5'
assert old['head']==new['head']==git('rev-parse','HEAD').decode().strip()
assert not git('diff','--cached','--name-only')
before=git('ls-files','--stage','-z')
oldrows={v['path']:v for v in old['source_files']}; newrows={v['path']:v for v in new['source_files']}
assert set(oldrows)==set(newrows) and len(newrows)==27
changed=[p for p in oldrows if oldrows[p]!=newrows[p]]
assert changed==['tools/package_runtime_smoke.py'],changed
with zipfile.ZipFile(O/'source.zip') as oz, zipfile.ZipFile(E/'source.zip') as nz:
 assert len(nz.namelist())==len(set(nz.namelist()))==27
 assert set(nz.namelist())==set(newrows)
 for path,v in newrows.items():
  b=(R/path).read_bytes(); n=b.replace(b'\r\n',b'\n')
  assert len(b)==v['bytes'] and sha(b)==v['raw_sha256']
  assert hashlib.sha1(b'blob '+str(len(n)).encode()+b'\0'+n).hexdigest()==v['git_blob']
  assert nz.read(path)==b
  if path in changed:
   ob=oz.read(path); bad='\u00ce\u00a9'.encode(); good='\u03a9'.encode()
   assert ob.count(bad)==1 and ob.replace(bad,good)==b
  else:assert oz.read(path)==b
aggregate=sha(''.join(v['path']+'\0'+v['raw_sha256']+'\n' for v in sorted(new['source_files'],key=lambda x:x['path'])).encode())
assert aggregate==new['source_aggregate']
assert sha(json.dumps(old['source_files'],sort_keys=True,separators=(',',':')).encode())==old['source_aggregate']
assert sha((E/'source.zip').read_bytes())==new['source_zip_sha256']
assert git('diff','--binary','--no-ext-diff')==(E/'tracked.patch').read_bytes()
assert sha((E/'tracked.patch').read_bytes())==new['tracked_patch_sha256']
v=new['successor_validation'];assert v['exit_code']==0 and '--workspace' not in v['command']
assert sha(Path(v['log']).read_bytes())==v['sha256']
for v in new['evidence']:
 b=Path(v['path']).read_bytes();assert len(b)==v['bytes'] and sha(b)==v['sha256']
assert git('ls-files','--stage','-z')==before
result={
 'schema':'facman.packaged-startup-independent-final-source-review.v1',
 'verdict':'PASS: all source findings resolved for the bounded source checkpoint.',
 'head':new['head'],'head_tree':new['head_tree'],'source_count':27,
 'source_manifest':meta(E/'source-manifest.json'),
 'source_aggregate':aggregate,
 'source_aggregate_algorithm':'SHA256 of sorted path + NUL + raw_sha256 + LF concatenated as UTF-8',
 'predecessor_aggregate':old['source_aggregate'],
 'predecessor_aggregate_algorithm':'SHA256 of JSON source_files rows with sort_keys=True and compact comma/colon separators',
 'aggregate_algorithm_note':'The two aggregate formats differ; assurance is based on every exact raw source row, normalized Git blob and exact ZIP/patch bytes, not direct comparison of unlike aggregate representations.',
 'original_independent_assurance':meta(O/'independent-original-review.json'),
 'original_validation_closure':meta(O/'independent-reference-closure.json'),
 'original_validation_archive':meta(O/'independent-reference-closure.zip'),
 'only_change':{'path':changed[0],'before':oldrows[changed[0]],'after':newrows[changed[0]],'oracle':'Old raw bytes contain exactly one UTF-8 U+00CE/U+00A9 pair; replacing only that pair with U+03A9 equals the entire successor file byte-for-byte.'},
 'all_other_source_bytes_unchanged':True,'index_unchanged':True,
 'tracked_patch':meta(E/'tracked.patch'),'source_zip':meta(E/'source.zip'),
 'successor_smoke':new['successor_validation'],
 'smoke_classification':'Audited ROOT recorded actual p5d runtime smoke PASS 2.90399 seconds with default workspace selector and exact restored source; no independent rerun or native rebuild claimed for this literal-only correction.',
 'independent_test_assurance_carried_forward':'Original 28 Python tests, 397 native resource assertions, native package identity executable, real product and legacy identity harnesses, six build-command policy cases and source/package/index immutability remain applicable; all runtime implementation bytes are unchanged.',
 'findings':[],
 'qualification':'Source checkpoint approval only. Dirty local prototype. Require fresh build from the actual reviewed clean commit, executed source/contract/provider identity, packaged and installed proofs and hosted/human/release gates. Earlier failures remain retained.',
 'review_script':meta(Path(__file__))
}
b=(json.dumps(result,indent=2)+'\n').encode()
(E/'independent-final-review.json').open('xb').write(b)
print(json.dumps({'review':meta(E/'independent-final-review.json'),'aggregate':aggregate,'patch':new['tracked_patch_sha256']}))

