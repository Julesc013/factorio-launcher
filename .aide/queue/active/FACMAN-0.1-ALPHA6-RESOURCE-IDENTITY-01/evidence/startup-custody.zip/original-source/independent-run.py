import hashlib,json,os,subprocess,sys,time,zipfile
from pathlib import Path
E=Path(sys.argv[1]); R=Path(sys.argv[2]); T=Path(sys.argv[3])
def digest(b): return hashlib.sha256(b).hexdigest()
def meta(p):
 b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':digest(b)}
def save(name,obj):
 with (E/name).open('x',encoding='utf-8',newline='\n') as f: json.dump(obj,f,indent=2); f.write('\n')
def git(*args):
 p=subprocess.run(['git','-C',str(R),*args],capture_output=True,timeout=30)
 if p.returncode: raise RuntimeError(p.stderr.decode(errors='replace'))
 return p.stdout
M=json.loads((E/'source-manifest.json').read_bytes())
assert digest((E/'source-manifest.json').read_bytes())=='d8788d5313fc49e6674790b9d2f4017aa0554e5ba11521a9a25a1ca4258ef5a8'
assert git('rev-parse','HEAD').decode().strip()==M['head']
assert not git('diff','--cached','--name-only')
before=git('ls-files','--stage','-z')
rows=[]
for v in M['source_files']:
 b=(R/v['path']).read_bytes()
 assert len(b)==v['bytes'] and digest(b)==v['raw_sha256'],v['path']
 n=b.replace(b'\r\n',b'\n'); blob=hashlib.sha1(b'blob '+str(len(n)).encode()+b'\0'+n).hexdigest()
 assert blob==v['git_blob'],(v['path'],blob)
 rows.append(v)
with zipfile.ZipFile(E/'source.zip') as z:
 names=z.namelist(); assert len(names)==len(set(names))==27
 assert set(names)=={v['path'] for v in rows}
 for v in rows: assert digest(z.read(v['path']))==v['raw_sha256']
assert digest((E/'source.zip').read_bytes())==M['source_zip_sha256']
assert digest((E/'tracked.patch').read_bytes())==M['tracked_patch_sha256']
patch=git('diff','--binary','--no-ext-diff')
assert patch==(E/'tracked.patch').read_bytes(),('patch mismatch',digest(patch))
for v in M['evidence']:
 b=Path(v['path']).read_bytes()
 assert len(b)==v['bytes'] and digest(b)==v['sha256'],v['path']
save('independent-before.json',{'source_manifest':meta(E/'source-manifest.json'),'head':M['head'],'index_sha256':digest(before),'raw_source_files':rows,'source_zip':meta(E/'source.zip'),'tracked_patch':meta(E/'tracked.patch'),'root_evidence_verified':M['evidence']})
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(R/'tests')+os.pathsep+str(R),TEMP=str(T/'t'),TMP=str(T/'t'))
PY=sys.executable
commands=[
 ('python',[PY,'-B','-m','unittest','tests.test_package_runtime_identity','tests.test_package_external_component_staging','tests.test_backend_identity_contract','-v'],60),
 ('paths',[PY,'-B','tools/workspace_hygiene.py','paths'],60),
 ('doctor',[PY,'-B','tools/workspace_hygiene.py','doctor','--measure','--max-task-roots','10'],60),
 ('native-resource',[str(T/'native-p5/Release/facman_resource_identity_smoke.exe')],60),
 ('native-package',[str(T/'native-p5/Release/facman_runtime_package_identity_smoke.exe')],60),
 ('identity-product',[PY,'-B','tools/winforms_backend_identity_check.py','--package',str(T/'packages-p5d/windows_product_x64'),'--work-dir',str(T/'identity-ir-p5d')],200),
 ('identity-legacy',[PY,'-B','tools/winforms_backend_identity_check.py','--package',str(T/'packages-p5l/windows_legacy_winforms_x64'),'--work-dir',str(T/'identity-ir-p5l')],200)]
# Bind all supplied package files and relevant already-built native inputs before replay.
inputs=[]
for folder in ('packages-p5d/windows_product_x64','packages-p5l/windows_legacy_winforms_x64'):
 for p in sorted((T/folder).rglob('*')):
  if p.is_file(): inputs.append(meta(p))
for p in (T/'native-p5/Release').iterdir():
 if p.name in ('facman_resource_identity_smoke.exe','facman_runtime_package_identity_smoke.exe','ulk.dll','usk.dll'): inputs.append(meta(p))
save('independent-runtime-inputs.json',inputs)
run=[]
try:
 for name,argv,timeout in commands:
  start=time.monotonic()
  with (E/('independent-'+name+'.stdout')).open('xb') as out,(E/('independent-'+name+'.stderr')).open('xb') as err:
   p=subprocess.run(argv,cwd=R,env=env,stdout=out,stderr=err,timeout=timeout)
  row={'name':name,'argv':argv,'exit_code':p.returncode,'seconds':time.monotonic()-start,'stdout':meta(E/('independent-'+name+'.stdout')),'stderr':meta(E/('independent-'+name+'.stderr'))}
  run.append(row)
  print(name,p.returncode,round(row['seconds'],3),flush=True)
  if p.returncode: raise RuntimeError(name+' failed; original retained')
finally:
 unchanged=[]
 for v in rows: unchanged.append(digest((R/v['path']).read_bytes())==v['raw_sha256'])
 input_unchanged=all(meta(Path(v['path']))==v for v in inputs)
 index_unchanged=git('ls-files','--stage','-z')==before
 save('independent-execution.json',{'commands':run,'source_unchanged':all(unchanged),'index_unchanged':index_unchanged,'runtime_inputs_unchanged':input_unchanged,'inputs':meta(E/'independent-runtime-inputs.json'),'scope':'Dirty-source source review and ordinary synthetic/native identity harnesses only; no committed candidate/installed/hosted/human qualification.'})
 assert all(unchanged) and index_unchanged and input_unchanged

