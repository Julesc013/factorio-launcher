import hashlib,json,os,sys,zipfile
from pathlib import Path
from unittest.mock import patch
E,R,T,G=map(Path,sys.argv[1:]); sys.path.insert(0,str(R))
from tools import native_build
def sha(b):return hashlib.sha256(b).hexdigest()
def meta(p):
 b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def save(name,obj):
 with (E/name).open('x',encoding='utf-8',newline='\n') as f: json.dump(obj,f,indent=2); f.write('\n')
M=json.loads((E/'source-manifest.json').read_bytes())
assert sha(json.dumps(M['source_files'],sort_keys=True,separators=(',',':')).encode())==M['source_aggregate']
base=E.parent
selected={}
def add(p,expected=None,size=None):
 b=p.read_bytes()
 if expected: assert sha(b)==expected,p
 if size is not None:assert len(b)==size,p
 selected[str(p)]=b
 return meta(p)
# Independent selection cases exercise generator policy without any build.
cases=[]
fixture=E/'independent-build-command-fixtures'; fixture.mkdir()
for name,platform,generator,targets in [
 ('vs-windows','nt','Visual Studio 18 2026',['alias','same','alias']),
 ('ninja-windows','nt','Ninja',['*']),
 ('make-posix','posix','Unix Makefiles',[]),
 ('vs-posix','posix','Visual Studio 18 2026',[]),
 ('missing-windows','nt',None,[]),
 ('vs-all','nt','Visual Studio 17 2022',['*'])]:
 root=fixture/name;root.mkdir()
 if generator is not None:(root/'CMakeCache.txt').write_text('CMAKE_GENERATOR:INTERNAL='+generator+'\n',encoding='utf-8')
 with patch.object(native_build.os,'name',platform):
  argv=native_build.command(root,'Release',targets,{'alias':'same'})
 expected=platform=='nt' and generator is not None and generator.startswith('Visual Studio')
 assert ('--clean-first' in argv)==expected
 assert ('/p:TrackFileAccess=false' in argv)==expected
 assert ('--' in argv)==expected
 assert ('--target' in argv)==bool(targets and '*' not in targets)
 if name=='vs-windows':assert argv[argv.index('--target')+1:argv.index('--clean-first')]==['same']
 cases.append({'name':name,'command':argv,'clean_rebuild_required':expected})
save('independent-command-policy.json',{'result':'PASS','cases':cases,'source':meta(R/'tools/native_build.py'),'effects':'Only six explicit synthetic cache files in this evidence directory; no CMake/build command executed.'})
# Close parent validation references including actual retained failures.
for name in ('validation-v1.json','prototype-validation-v5.json','final-source-validation-v6.json'):
 p=base/name;d=json.loads(p.read_bytes());add(p)
 for row in d:add(base/row['log'],row['sha256'])
p=base/'freshness-result.json';d=json.loads(p.read_bytes());add(p)
for row in d['commands']:
 for key in ('stdout','stderr'):
  v=row[key];add(base/v['path'],v['sha256'],v['bytes'])
assert d['initial']==d['unsafe_incremental']=='1' and d['corrected_clean_rebuild']=='2'
assert d['original_stale_package_refusal']=='compiled backend identity mismatch: build.source_revision'
for v in M['evidence']:add(Path(v['path']),v['sha256'],v['bytes'])
# Actual startup evidence: exact original files, no new GUI run here.
s=G/'evidence/package-97e/startup-p5d'
p=s/'result.json';d=json.loads(p.read_bytes())
add(s/'plan.json',d['plan_sha256'])
plan=json.loads((s/'plan.json').read_bytes())
assert plan['source_dirty'] is True
package=Path(plan['package_root'])
for v in d['package_files_unchanged']:
 p=package/v['path']; b=p.read_bytes()
 assert len(b)==v['bytes'] and sha(b)==v['sha256']
assert sha(Path(d['runtime_result']['gui']).read_bytes())==d['runtime_result']['sha256']==plan['executable_sha256']
for row in d['commands']:
 for key in ('stdout','stderr'):
  v=row[key];add(s/v['path'],v['sha256'],v['bytes'])
for name in ('result.json','run.py','commands.json','StartupProbe.cs','startup-result.json','startup-settings.png','visible-text.json','product.stdout','product.stderr'):add(s/name)
assert d['runtime_result']==json.loads((s/'startup-result.json').read_bytes())
runtime=d['runtime_result']
assert all(runtime[k] is True for k in ('workspace_remained_absent','live_backend_workspace_rendered','tree_empty'))
assert runtime['normal_exit']==0 and not Path(runtime['workspace']).exists()
# Bind runtime production inputs which are unchanged since the startup observation.
plan_differences=[]
for row in plan['source_files']:
 now=sha((R/row['path']).read_bytes())
 if now!=row['sha256']:plan_differences.append({'path':row['path'],'startup_sha256':row['sha256'],'current_sha256':now})
assert all(not v['path'].startswith(('apps/','runtime/')) for v in plan_differences),plan_differences
add(Path(plan['containment_source']['path']),plan['containment_source']['sha256'])
# Fresh independent harness commands and logs and exactly executed harness output.
for folder in ('identity-ir-p5d','identity-ir-p5l'):
 p=T/folder;rows=json.loads((p/'commands.json').read_bytes());add(p/'commands.json')
 for row in rows:
  assert row['exit_code']==0 and not row['timed_out']
  for v in row['logs']:add(p/v['path'],v['sha256'],v['bytes'])
 add(p/'bin/FacMan.BackendIdentity.Harness.exe')
 add(p/'bin/FacMan.BackendIdentity.Harness.exe.config')
for name in ('source-manifest.json','source.zip','tracked.patch','independent-run.py','independent-before.json','independent-execution.json','independent-runtime-inputs.json','independent-command-policy.json'):
 add(E/name)
execution=json.loads((E/'independent-execution.json').read_bytes())
for row in execution['commands']:
 for key in ('stdout','stderr'):
  v=row[key];add(Path(v['path']),v['sha256'],v['bytes'])
add(Path(__file__))
archive=E/'independent-reference-closure.zip'
roster=[]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for index,(origin,b) in enumerate(sorted(selected.items())):
  name=f'{index:03d}-'+Path(origin).name
  z.writestr(name,b)
  roster.append({'member':name,'origin':origin,'bytes':len(b),'sha256':sha(b)})
 z.writestr('manifest.json',json.dumps(roster,sort_keys=True,indent=2).encode()+b'\n')
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(roster)+1==len(set(z.namelist()))
 for row in roster:
  b=z.read(row['member'])
  assert sha(b)==row['sha256'] and b==Path(row['origin']).read_bytes()
save('independent-reference-closure.json',{'result':'PASS','source_aggregate_recomputed':M['source_aggregate'],'archive':meta(archive),'members':roster,'startup_plan_nonproduction_changes':plan_differences,'startup_qualification':'Audited recorded actual GUI execution, not independently rerun; own identity harnesses were rerun against these exact package binaries. Dirty prototype only.','inventory_custody':'Package files independently hash-verified before/after replay and against startup original. Entire product package payload is retained externally by ROOT, not duplicated into this compact evidence archive.'})
print(json.dumps({'archive':meta(archive),'members':len(roster),'receipt':meta(E/'independent-reference-closure.json'),'startup_plan_nonproduction_changes':plan_differences}))

