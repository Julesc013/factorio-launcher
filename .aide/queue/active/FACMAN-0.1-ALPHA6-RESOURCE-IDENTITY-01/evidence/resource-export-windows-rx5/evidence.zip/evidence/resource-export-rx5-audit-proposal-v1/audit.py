"""File-only audit of one closed rx5 outcome; never dispatches Git/native commands."""
import argparse,hashlib,json,os,stat,time,zipfile
from pathlib import Path
T=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-d9fce3b03d')
E=T/'evidence';RUN=T/'rx5';INV=T/'rx5-invocation';OUT=E/'resource-export-rx5-actual-seal'
READY=E/'resource-export-windows-ready-v5'
HEAD='c2ce811312aec8229c19f50fbbb07cac0b88a407';TREE='288eb824f0e0ded9cf1061252cd495fdb6fba161'
TESTS=['facman_resource_identity_smoke','facman_resource_product_cli','fl_archive_core_smoke']
LABELS=['base-head','base-status','provider0-head','provider0-status','provider1-head','provider1-status','clone','clone-head','checkout','candidate-status','configure','build','test-inventory']+['test-'+n for n in TESTS]
STREAMS={'receipt.json','stdin.raw','stdout.raw','stderr.raw'}
TOP={'owner.json','result.json','source-before.json','source-status.json','compiled-inputs.json','test-inventory.json','source-before-tests.json','source-after.json'}
COMPILER={'n/CMakeCache.txt','n/CMakeFiles/CMakeConfigureLog.yaml','n/CMakeFiles/4.2.3/CMakeCCompiler.cmake','n/CMakeFiles/4.2.3/CMakeCXXCompiler.cmake','n/CMakeFiles/4.2.3/CMakeSystem.cmake'}
BINARIES={'n/Release/'+n for n in ['facman.exe','facman_resource_identity_smoke.exe','fl_archive_core_smoke.exe','ulk.dll','usk.dll']}
class Refused(ValueError):pass
def require(condition,message):
 if not condition:raise Refused(message)
def plain(path):
 for part in [*reversed(path.parents),path]:
  value=part.lstat();require(not stat.S_ISLNK(value.st_mode) and not getattr(value,'st_file_attributes',0)&0x400,'reparse input')
 return value
def read(path,limit=16*1024**2):
 value=plain(path);require(stat.S_ISREG(value.st_mode) and value.st_size<=limit,'input type/size')
 with path.open('rb') as f:b=f.read(limit+1)
 after=path.lstat();require((value.st_dev,value.st_ino,value.st_size,value.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns),'input replaced')
 require(len(b)==value.st_size and len(b)<=limit,'input changed/limit');return b
def ref(path):
 b=read(path);return {'path':str(path),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def verify(row):require(type(row) is dict and ref(Path(row['path']))==row,'pinned input drift')
def document(path):
 v=json.loads(read(path));require(type(v) is dict,'JSON object');return v
def write(path,value):
 b=(json.dumps(value,indent=2,allow_nan=False)+'\n').encode();require(len(b)<=32*1024**2,'receipt bound')
 with path.open('xb') as f:f.write(b)
def closed(receipt):
 require(receipt.get('primary_stopped') is True and receipt.get('job_empty_observed') is True,'closure unavailable')
def outcome(inner,outer):
 closed(outer['receipt']);require(outer.get('stable_export_permitted') is True,'stable export not permitted')
 require(inner.get('quiescence')=='observed','inner closure unknown')
 require(inner.get('source_head')==HEAD and inner.get('candidate_tree')==TREE,'source identity')
 commands=inner.get('commands');require(type(commands) is list and len(commands)<=len(LABELS),'command count')
 labels=[row.get('label') for row in commands];require(labels==LABELS[:len(labels)],'command order or duplicate')
 for row in commands:closed(row)
 passed=inner.get('result')=='PASS_SCOPED_THREE_FIXTURES_ONLY'
 if passed:
  require(labels==LABELS and inner.get('native_qualification') is True and inner.get('selected_tests')==TESTS,'incomplete pass')
  require(all(row.get('exit_code')==0 and row.get('termination')=='completed' for row in commands),'failed command under pass')
  require(outer['receipt'].get('exit_code')==0,'outer failure under pass')
 else:require(inner.get('result')=='FAIL_OR_UNKNOWN' and inner.get('native_qualification') is False,'unexpected outcome')
 return 'PASS_RECORDED_THREE_FIXTURES_ONLY' if passed else 'CLOSED_FAILURE_PRESERVED'
def archive_class(relative):
 parts=Path(relative).parts;name=Path(relative).as_posix()
 if Path(relative).is_absolute() or any(x in ('.','..') or ':' in x for x in parts):return None
 if len(parts)==1 and name in TOP:return 'control'
 if len(parts)==3 and parts[0]=='e' and parts[1] in LABELS and parts[2] in STREAMS:return 'control'
 if name in COMPILER:return 'control'
 if name.startswith('n/CMakeFiles/4.2.3/CompilerIdC/') or name.startswith('n/CMakeFiles/4.2.3/CompilerIdCXX/'):return 'control'
 if name in BINARIES or name.startswith('n/tests/') or name.startswith('t/'):return 'artifacts'
 return None
def digest_stream(path,guard,git_blob=False):
 before=plain(path);require(stat.S_ISREG(before.st_mode) and before.st_size<=512*1024**2,'stream input bound')
 h=hashlib.sha256();count=0;git=hashlib.sha1(b'blob '+str(before.st_size).encode()+b'\0')
 with path.open('rb') as f:
  while b:=f.read(1024**2):guard();count+=len(b);require(count<=512*1024**2,'stream growth');h.update(b);git.update(b)
 after=path.lstat();require((before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns) and count==before.st_size,'stream changed')
 return dict(bytes=count,sha256=h.hexdigest(),**({'git_blob':git.hexdigest()} if git_blob else {}))
def inventory(root,guard):
 rows=[];total=0;before=plain(root);require(stat.S_ISDIR(before.st_mode),'inventory root type')
 def walk_error(error):raise error
 for directory,dirs,files in os.walk(root,followlinks=False,onerror=walk_error):
  for name in dirs+files:
   guard();p=Path(directory)/name;s=p.lstat();relative=p.relative_to(root).as_posix();link=stat.S_ISLNK(s.st_mode) or bool(getattr(s,'st_file_attributes',0)&0x400)
   row={'path':relative,'mode':stat.S_IMODE(s.st_mode),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns}
   if link:
    if name in dirs:dirs.remove(name)
    try:row.update(kind='symlink_or_reparse',target=os.readlink(p),followed=False)
    except OSError:row.update(kind='reparse',target=None,followed=False)
   elif stat.S_ISDIR(s.st_mode):row['kind']='directory'
   else:
    row.update(kind='file',**digest_stream(p,guard,git_blob=relative.startswith('s/') and not relative.startswith('s/.git/')));total+=row['bytes'];require(total<=2*1024**3,'retained root bytes')
   rows.append(row);require(len(rows)<=50000,'retained root entries')
 after=root.lstat();require((before.st_dev,before.st_ino,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_mtime_ns),'inventory root changed')
 return sorted(rows,key=lambda x:x['path'])
def copy_member(z,path,member,expected,guard):
 # The destination ZIP is newly created; original evidence is never edited.
 before=plain(path);h=hashlib.sha256();count=0
 with path.open('rb') as source,z.open(member,'w') as target:
  while b:=source.read(1024**2):guard();target.write(b);h.update(b);count+=len(b);require(count<=512*1024**2,'archive member bound')
 after=path.lstat();require((before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns),'archive source changed')
 require({'bytes':count,'sha256':h.hexdigest()}==expected,'archive member differs')
def check_source_rows(base,candidate,observed):
 expected={row['path']:row for row in base}
 expected.update({row['path']:row for row in candidate})
 source={row['path'][2:]:row for row in observed if row['path'].startswith('s/') and
         not row['path'].startswith('s/.git/') and row['kind']!='directory' and row['path']!='s/.git'}
 require(set(source)==set(expected),'source set differs')
 for name,row in expected.items():
  actual=source[name];require(actual['kind']=='file' and actual['bytes']==row['bytes'] and actual.get('git_blob')==row['git_blob'],'canonical source differs')
 return source

def expected_commands(ready,obs):
 git=[obs['tools']['git']['path'],'-c','core.longpaths=true','-c','core.hooksPath=NUL']
 expected={name:git+['rev-parse','HEAD'] for name in ['base-head','provider0-head','provider1-head','clone-head']}
 expected.update({name:git+['status','--porcelain=v1'] for name in ['base-status','provider0-status','provider1-status']})
 expected['checkout']=git+['-c','core.autocrlf=false','-c','core.eol=lf','-c','core.attributesFile=NUL','checkout','--detach',HEAD]
 expected['candidate-status']=git+['status','--porcelain=v1','--untracked-files=all']
 expected.update({name:ready['planned_commands'][name] for name in ['clone','configure','build']})
 build=ready['planned_commands']['build'][2]
 expected['test-inventory']=[obs['tools']['ctest']['path'],'--test-dir',build,'-C','Release','--show-only=json-v1','-R','^('+ '|'.join(TESTS) +')$']
 expected.update({'test-'+name:argv for name,argv in zip(TESTS,ready['planned_commands']['tests'],strict=True)})
 return expected

def check_test_argv(view,recorded,python,source,build):
 expected={TESTS[0]:[str(build/'Release/facman_resource_identity_smoke.exe')],TESTS[2]:[str(build/'Release/fl_archive_core_smoke.exe')],
 TESTS[1]:[python,str(source/'tests/integration/resource_identity_runtime.py'),'--cli',str(build/'Release/facman.exe'),'--fixture',str(build/'Release/facman_resource_identity_smoke.exe'),'--runtime-file',str(build/'Release/ulk.dll'),'--runtime-file',str(build/'Release/usk.dll'),'--work-root',str(build/'tests/native/resource-cli-runs')]}
 tests=view['tests'];require(len(tests)==3 and {row['name'] for row in tests}==set(TESTS) and set(recorded)==set(TESTS),'test membership')
 def normal(argv):return [arg.replace('\\','/') for arg in argv]
 for row in tests:
  name=row['name'];require(normal(row['command'])==normal(expected[name]) and normal(recorded[name])==normal(expected[name]),'test argv differs')

def audit(plan_path):
 start=time.monotonic()
 def guard():require(0<=time.monotonic()-start<=300,'audit deadline')
 plan=document(plan_path);require(plan.get('schema')=='facman.rx5-custody-audit-plan.v1' and plan.get('audit_enabled') is True,'audit disabled')
 for key,path in [('ready_plan',READY/'plan.json'),('effect_review',READY/'root-effect-review.json'),('root_wrapper',READY/'root-invocation-once/result.json')]:
  require(type(plan.get(key)) is dict and plan[key].get('path')==str(path),'fixed authority path');verify(plan[key]);guard()
 require(plan.get('max_seconds')==300 and plan.get('output')==str(OUT),'fixed audit bounds/root')
 ready=document(Path(plan['ready_plan']['path']));effect=document(Path(plan['effect_review']['path']))
 require(ready.get('source_head')==HEAD and ready.get('candidate_tree')==TREE and ready.get('root')==str(RUN) and ready.get('invocation_root')==str(INV),'ready identity')
 require(effect.get('plan_sha256')==plan['ready_plan']['sha256'] and effect.get('authorized_once') is True,'effect binding')
 require(ready.get('effect_review_path')==plan['effect_review']['path'],'review path')
 intent=document(INV/'intent.json');require(intent.get('plan_sha256')==plan['ready_plan']['sha256'] and intent.get('review_sha256')==plan['effect_review']['sha256'],'invocation correlation')
 require(intent.get('identity')==r'BLACKGLASS-WIN1\Jules' and intent.get('retry') is False,'invocation identity/retry')
 require(type(intent.get('started_at')) in (int,float) and intent['started_at']<ready['expires_at'],'recorded admission time')
 wrapper=document(Path(plan['root_wrapper']['path']));require(wrapper.get('identity')==intent['identity'] and wrapper.get('plan')==plan['ready_plan'] and wrapper.get('review')==plan['effect_review'],'wrapper binding')
 require(wrapper.get('result')=='CLOSED_HOST_INVOCATION' and wrapper.get('automatic_retries')==0,'root wrapper not closed')
 outer=document(INV/'result.json');inner=document(RUN/'result.json');verdict=outcome(inner,outer)
 if verdict=='PASS_RECORDED_THREE_FIXTURES_ONLY':require(wrapper.get('exit_code')==0,'failed root wrapper under pass')
 obs=document(Path(ready['observation']['path']));require(ready['source_review']==inner['read_only_source_review'],'source review')
 for row in ready['pins']:verify(row);guard()
 require(not OUT.exists(),'consumed audit output');OUT.mkdir()
 write(OUT/'intent.json',{'audit_plan':ref(plan_path),'ready_plan':plan['ready_plan'],'verdict_under_audit':verdict,'start_monotonic':start,'replay':False})
 control=[];artifacts=[];invrows=[];command_argv=expected_commands(ready,obs)
 for row in inner['commands']:
  label=row['label'];directory=RUN/'e'/label;receipt=document(directory/'receipt.json')
  require({k:v for k,v in row.items() if k not in ('label','receipt')}==receipt,'embedded receipt differs')
  require(os.path.samefile(Path(row['receipt']),directory/'receipt.json'),'receipt source path')
  for key in ('stdout','stderr'):
   b=read(directory/(key+'.raw'),8*1024**2);record=receipt[key]
   require(len(b)==record['captured_bytes'] and hashlib.sha256(b).hexdigest()==record['sha256'],'raw command stream differs')
  require(receipt['command']==command_argv[label],'planned command differs')
 for name in ['intent.json','result.json','outer/receipt.json','outer/stdin.raw','outer/stdout.raw','outer/stderr.raw']:
  p=INV/name;pin=ref(p);invrows.append(pin);control.append((p,'rx5-invocation/'+name,{'bytes':pin['bytes'],'sha256':pin['sha256']}))
 require(document(INV/'outer/receipt.json')==outer['receipt'],'outer receipt differs')
 for name in ['stdout','stderr']:
  b=read(INV/'outer'/(name+'.raw'),8*1024**2);row=outer['receipt'][name];require(len(b)==row['captured_bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],'outer raw differs')
 for key in ['ready_plan','effect_review','root_wrapper']:
  p=Path(plan[key]['path']);control.append((p,'authority/'+key+'.json',{'bytes':plan[key]['bytes'],'sha256':plan[key]['sha256']}))
 wrapper_root=Path(plan['root_wrapper']['path']).parent
 for name in ['stdout.raw','stderr.raw']:
  p=wrapper_root/name;pin=ref(p);require({k:pin[k] for k in ['bytes','sha256']}==wrapper[name],'wrapper raw differs');control.append((p,'root-wrapper/'+name,{k:pin[k] for k in ['bytes','sha256']}))
 observed=inventory(RUN,guard);write(OUT/'root-inventory.json',{'rows':observed,'symlinks_followed':False})
 if (RUN/'source-before.json').exists():
  base=json.loads(read(Path(ready['base_roster']['path'])));candidate=document(Path(ready['candidate_manifest']['path']))['source']
  actual=check_source_rows(base,candidate,observed)
  require(read(RUN/'s/.git/HEAD').decode().strip()==HEAD,'clone HEAD differs')
  for name in ['source-before.json','source-before-tests.json','source-after.json']:
   if not (RUN/name).exists():continue
   rows=json.loads(read(RUN/name));require(type(rows) is list and len(rows)==len(actual),'source map size')
   mapped={row['path']:row for row in rows};require(len(mapped)==len(rows) and set(mapped)==set(actual),'source map names')
   for path,row in mapped.items():require(row['bytes']==actual[path]['bytes'] and row['sha256']==actual[path]['sha256'],'source map bytes differ')
 if verdict=='PASS_RECORDED_THREE_FIXTURES_ONLY':
  require(all((RUN/n).is_file() for n in ['source-before.json','source-before-tests.json','source-after.json','compiled-inputs.json','test-inventory.json']),'missing pass evidence')
  compiler=read(RUN/'n/CMakeFiles/4.2.3/CMakeCXXCompiler.cmake').decode()
  require(obs['tools']['cl']['path'].replace('\\','/') in compiler,'actual compiler path differs')
  cache=read(RUN/'n/CMakeCache.txt').decode();require('CMAKE_GENERATOR:INTERNAL=Visual Studio 18 2026' in cache,'generator differs')
  compiled=document(RUN/'compiled-inputs.json');require(compiled['source_head']==HEAD and compiled['candidate_tree']==TREE and len(compiled['files'])==5,'compiled identity')
  seen=set()
  for row in compiled['files']:
   choices=[name for name in BINARIES if os.path.samefile(Path(row['path']),RUN/name)];require(len(choices)==1 and choices[0] not in seen,'compiled input membership');seen.add(choices[0])
   require(digest_stream(RUN/choices[0],guard)=={k:row[k] for k in ['bytes','sha256']},'compiled bytes differ')
  source=Path(ready['planned_commands']['clone'][-1]);build=Path(ready['planned_commands']['build'][2])
  check_test_argv(document(RUN/'test-inventory.json'),inner['expected_test_argv'],obs['tools']['python']['path'],source,build)
 for row in observed:
  if row['kind']!='file':continue
  kind=archive_class(row['path'])
  if kind:(control if kind=='control' else artifacts).append((RUN/row['path'],'rx5/'+row['path'],{k:row[k] for k in ['bytes','sha256']}))
 for name,selected in [('control-originals.zip',control),('selected-artifacts.zip',artifacts)]:
  require(len({member for _,member,_ in selected})==len(selected),'duplicate archive member')
  with zipfile.ZipFile(OUT/name,'x',compression=zipfile.ZIP_DEFLATED) as z:
   for path,member,expected in selected:copy_member(z,path,member,expected,guard)
  # Reread every compressed member independently before calling the packet sealed.
  with zipfile.ZipFile(OUT/name) as z:
   for _,member,expected in selected:
    h=hashlib.sha256();n=0
    with z.open(member) as f:
     while b:=f.read(1024**2):guard();h.update(b);n+=len(b)
    require({'bytes':n,'sha256':h.hexdigest()}==expected,'archive readback differs')
  write(OUT/(name+'.members.json'),{'members':[{'path':str(p),'member':m,**expected} for p,m,expected in selected]})
 require(observed==inventory(RUN,guard),'root changed across seal')
 for row in invrows:verify(row)
 for key in ['ready_plan','effect_review','root_wrapper']:verify(plan[key])
 guard();write(OUT/'result.json',{'schema':'facman.rx5-actual-custody-audit.v1','result':verdict,'original_outcome':inner['result'],'phase':inner['phase'],'inner_command_count':len(inner['commands']),'all_recorded_jobs_closed':True,'source_head':HEAD,'candidate_tree':TREE,'audit_plan':ref(plan_path),'root_map':ref(OUT/'root-inventory.json'),'control_archive':digest_stream(OUT/'control-originals.zip',guard),'artifact_archive':digest_stream(OUT/'selected-artifacts.zip',guard),'map_only_build_intermediates_and_clone_remain_at_original_paths':True,'old_failures_not_modified_by_audit':True,'native_reruns':0,'expired_historical_plan_not_reexecuted':True,'elapsed_seconds':time.monotonic()-start})
 return 0
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--plan',type=Path,required=True);args=parser.parse_args();raise SystemExit(audit(args.plan))
