"""Once-only ordinary Windows build/three-fixture controller; no live service."""
from __future__ import annotations
import argparse
import ctypes
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys
import time
import types

T = Path(r"C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-d9fce3b03d")
P = T / "evidence/resource-export-windows-plan-v5"
W = T.parents[1] / "worktrees/task-facman-resource-identity-01"
BASE = "c2ce811312aec8229c19f50fbbb07cac0b88a407"
BASE_TREE = "f5049798a04959c00be80791a48097dc8907313d"
TREE = "288eb824f0e0ded9cf1061252cd495fdb6fba161"
NAMES = ["facman_resource_identity_smoke", "facman_resource_product_cli", "fl_archive_core_smoke"]
REPARSE = 0x400


def require(value, label):
    if not value:
        raise ValueError(label)


def plain(path, directory=False):
    for item in [*reversed(path.parents), path]:
        s = item.lstat()
        require(not stat.S_ISLNK(s.st_mode) and not getattr(s, "st_file_attributes", 0) & REPARSE,
                "reparse input: " + str(item))
    require(stat.S_ISDIR(s.st_mode) if directory else stat.S_ISREG(s.st_mode), "unexpected input type")
    return s


def raw(path, maximum=8 * 1024**2):
    s = plain(path)
    require(0 <= s.st_size <= maximum, "input byte limit")
    with path.open("rb") as stream:
        b = stream.read(maximum + 1)
    require(len(b) == s.st_size and len(b) <= maximum, "input changed or exceeded bound")
    return b


def digest(path, maximum=256 * 1024**2):
    s = plain(path)
    require(s.st_size <= maximum, "file byte bound")
    h, n = hashlib.sha256(), 0
    with path.open("rb") as stream:
        while b := stream.read(1024**2):
            n += len(b)
            require(n <= maximum, "file grew beyond bound")
            h.update(b)
    require(n == s.st_size, "file changed while reading")
    return {"path": str(path), "bytes": n, "sha256": h.hexdigest()}


def verify(row):
    require(digest(Path(row["path"])) == row, "pinned file changed: " + row["path"])


def document(path):
    v = json.loads(raw(path))
    require(isinstance(v, dict), "expected JSON object")
    return v


def write(path, value):
    b = (json.dumps(value, indent=2, allow_nan=False) + "\n").encode()
    require(len(b) <= 16 * 1024**2, "result byte bound")
    with path.open("xb") as stream:
        stream.write(b)
        stream.flush()
        os.fsync(stream.fileno())


def expired(plan, wall=time.time):
    v = plan.get("expires_at")
    require(type(v) in (int, float) and 1 <= v <= 4102444800 and 0 < v - wall() <= 7200, "missing/expired finite effect plan")


def validate_plan(plan):
    require(plan.get("schema") == "facman.resource-export-windows-plan.v1", "plan schema")
    require(plan.get("source_head") == BASE and plan.get("source_tree") == BASE_TREE and
            plan.get("candidate_tree") == TREE, "source identity")
    require(plan.get("selected_tests") == NAMES, "only three selected fixtures are admitted")
    require(plan.get("root") == str(T / "rx5") and plan.get("invocation_root") == str(T / "rx5-invocation"),
            "fixed fresh children")
    require(plan.get("overall_seconds") == 1800 and plan.get("new_child_bytes") == 2 * 1024**3,
            "fixed effect bounds")
    require(plan.get("source_review", {}).get("sha256") ==
            "1b1d311297e70e0954ef44790333b03d4707dd26169d436d76099e080a7c5406", "source review")
    require(plan.get("dispatch_enabled") is True, "draft plan cannot dispatch")
    expired(plan)


def load_process(observation):
    package = types.ModuleType("tools")
    package.__path__ = []
    sys.modules["tools"] = package
    for name in ("provider_canary_process_windows", "provider_canary_process"):
        row = observation["tools"][name + ".py"]
        verify(row)
        spec = importlib.util.spec_from_file_location("tools." + name, row["path"])
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        setattr(package, name, module)
    return package.provider_canary_process


def environment(observation, temporary):
    tools = observation["tools"]
    windows = Path(r"C:\Windows")
    env = {"SystemRoot": str(windows), "WINDIR": str(windows),
           "ComSpec": str(windows / "System32/cmd.exe"),
           "USERPROFILE": str(Path(r"C:\Users\Jules")),
           "ProgramFiles": r"C:\Program Files", "ProgramFiles(x86)": r"C:\Program Files (x86)",
           "ProgramData": r"C:\ProgramData",
           "SystemDrive": "C:", "PROCESSOR_ARCHITECTURE": "AMD64",
           "LOCALAPPDATA": r"C:\Users\Jules\AppData\Local", "APPDATA": r"C:\Users\Jules\AppData\Roaming",
           "TEMP": str(temporary), "TMP": str(temporary), "TMPDIR": str(temporary),
           "PYTHONDONTWRITEBYTECODE": "1", "PYTHONNOUSERSITE": "1",
           "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": "NUL", "GIT_TERMINAL_PROMPT": "0",
           "GIT_OPTIONAL_LOCKS": "0", "GIT_LFS_SKIP_SMUDGE": "1", "GIT_ALLOW_PROTOCOL": "file",
           "GIT_CONFIG_COUNT": "1", "GIT_CONFIG_KEY_0": "core.longpaths", "GIT_CONFIG_VALUE_0": "true",
           "FACMAN_TASK_ROOT": str(T), "FACMAN_TASK_ID": "FACMAN-0.1-ALPHA6-RESOURCE-IDENTITY-01"}
    env["PATH"] = os.pathsep.join(dict.fromkeys([str(Path(tools[k]["path"]).parent)
                            for k in ("cmake", "git", "python", "cl", "msbuild", "rc")] +
                            [str(windows / "System32"), str(windows)]))
    return env


def clone_command(git, source):
    return [git, "-c", "core.longpaths=true", "-c", "core.hooksPath=NUL", "-c", "core.autocrlf=false", "-c", "core.attributesFile=NUL",
            "clone", "--no-checkout", "--no-local", "--depth=1", "--single-branch", "--no-tags", "--template=",
            "--branch", "task/facman-resource-identity-01", W.as_uri(), str(source)]


def configure_command(obs, source, build, providers):
    return [obs["tools"]["cmake"]["path"], "-S", str(source), "-B", str(build), "-G", "Visual Studio 18 2026",
            "-A", "x64", "-T", "version=14.51.36231", "-DCMAKE_SYSTEM_VERSION=10.0.26100.0",
            "-DCMAKE_GENERATOR_INSTANCE=C:/Program Files/Microsoft Visual Studio/18/Enterprise",
            "-DFACMAN_BUILD_CLI=ON", "-DFACMAN_BUILD_TUI=ON", "-DFACMAN_BUILD_TESTS=ON", "-DFACMAN_BUILD_GUI=OFF",
            "-DFACMAN_BUILD_SELF_SETUP=OFF", "-DFACMAN_WITH_SETUP=ON", "-DFACMAN_WARNINGS_AS_ERRORS=ON",
            "-DFACMAN_PROVIDER_MODE=source", "-DFACMAN_PROVIDER_SOURCE_LINKAGE=shared",
            "-DFLAUNCH_UNIVERSAL_LAUNCHER_ROOT=" + providers[0]["path"],
            "-DFLAUNCH_UNIVERSAL_SETUP_ROOT=" + providers[1]["path"],
            "-DFACMAN_PROVIDER_LOCK_FILE=" + str(source / "release/index/workspace_lock.v1.toml"),
            "-DPython3_EXECUTABLE=" + obs["tools"]["python"]["path"]]


def build_command(cmake, build):
    return [cmake, "--build", str(build), "--config", "Release", "--parallel", "4", "--target",
            "facman_cli", "facman_resource_identity_smoke", "fl_archive_core_smoke", "--clean-first", "--",
            "/p:TrackFileAccess=false"]


def inspect_ctest(value, python, source, build):
    tests = value.get("tests", [])
    require({t["name"] for t in tests} == set(NAMES) and len(tests) == 3, "selected CTest inventory")
    expected = {NAMES[0]: [str(build / "Release/facman_resource_identity_smoke.exe")],
                NAMES[2]: [str(build / "Release/fl_archive_core_smoke.exe")],
                NAMES[1]: [python, str(source / "tests/integration/resource_identity_runtime.py"),
                           "--cli", str(build / "Release/facman.exe"), "--fixture",
                           str(build / "Release/facman_resource_identity_smoke.exe"),
                           "--runtime-file", str(build / "Release/ulk.dll"), "--runtime-file",
                           str(build / "Release/usk.dll"), "--work-root",
                           str(build / "tests/native/resource-cli-runs")]}
    for t in tests:
        got = [x.replace("\\", "/") for x in t["command"]]
        require(got == [x.replace("\\", "/") for x in expected[t["name"]]], "CTest argv drift: " + t["name"])
    return expected


def inventory(root, maximum_bytes=2 * 1024**3, maximum_entries=50000):
    total, count, links = 0, 0, []
    for directory, dirs, files in os.walk(root, followlinks=False):
        for name in dirs + files:
            p = Path(directory) / name
            s = p.lstat()
            is_link = stat.S_ISLNK(s.st_mode) or bool(getattr(s, "st_file_attributes", 0) & REPARSE)
            if is_link:
                if name in dirs: dirs.remove(name)
                try: target = os.readlink(p)
                except OSError: target = None
                links.append({"path": str(p.relative_to(root)), "target": target, "followed": False})
            count += 1
            total += s.st_size if stat.S_ISREG(s.st_mode) and not is_link else 0
            require(count <= maximum_entries and total <= maximum_bytes, "owned child resource threshold")
    return {"entries": count, "bytes": total, "reparse_metadata_only": links, "threshold_not_filesystem_quota": True}


def snapshot(source, rows, guard, canonical=True):
    expected = {r["path"]: r for r in rows}
    seen, answer = set(), []
    for directory, dirs, files in os.walk(source, followlinks=False):
        if Path(directory) == source:
            dirs[:] = [d for d in dirs if d != ".git"]
        for name in dirs:
            plain(Path(directory) / name, directory=True)
        for name in files:
            path = Path(directory) / name
            relative = path.relative_to(source).as_posix()
            require(relative in expected, "extra source entry: " + relative)
            row = expected[relative]
            guard()
            b = raw(path, 64 * 1024**2)
            if canonical:
                oid = hashlib.sha1(b"blob " + str(len(b)).encode() + b"\0" + b).hexdigest()
                require(len(b) == row["bytes"] and oid == row["git_blob"], "canonical source bytes: " + relative)
            else:
                require(len(b) == row["physical_bytes"] and hashlib.sha256(b).hexdigest() == row["sha256"],
                        "provider physical bytes: " + relative)
            seen.add(relative)
            answer.append({"path": relative, "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()})
    require(seen == set(expected), "missing source entries")
    return answer


def child(plan, obs, process):
    root = Path(plan["root"])
    short = Path(obs["task_short_path"]) / "rx5"
    require(not root.exists(), "consumed build child must not be adopted")
    root.mkdir()
    require(os.path.samefile(root, short), "short child binding")
    source, build, tmp, logs = (short / x for x in ("s", "n", "t", "e"))
    tmp.mkdir(); logs.mkdir()
    env = environment(obs, tmp)
    budget = process.Budget(1750, 900)
    result = {"schema": "facman.resource-export-windows-result.v1", "result": "FAIL_OR_UNKNOWN",
              "source_head": BASE, "candidate_tree": TREE, "source_dirty": True, "commands": [],
              "native_qualification": False, "quiescence": "unknown", "phase": "created",
              "read_only_source_review": plan["source_review"]}
    write(root / "owner.json", {"schema": "facman.owned-test-child.v1", "plan": digest(Path(plan["self_path"])),
                               "parent_marker": obs["task_marker"], "retention": "retain_only"})
    def guard():
        expired(plan)
        require(budget.remaining() > 0, "controller elapsed deadline")
    def command(label, argv, timeout=60, cwd=None):
        guard(); verify(obs["task_marker"])
        result["phase"] = label
        result["quiescence"] = "unknown"
        for row in obs["tools"].values():
            if row["path"] == argv[0]: verify(row)
        timeout = min(timeout, plan["expires_at"] - time.time())
        require(timeout > 0, "effect deadline before command")
        r = process.command(argv, cwd=cwd or short, environment=env, timeout=timeout, budget=budget,
                            directory=logs / label, output_limit=8 * 1024**2)
        result["commands"].append({"label": label, "receipt": str(r.directory / "receipt.json"), **r.receipt})
        result["quiescence"] = "observed" if r.receipt.get("primary_stopped") and r.receipt.get("job_empty_observed") else "unknown"
        require(result["quiescence"] == "observed", "owned job quiescence unavailable")
        inventory(root)
        process.require(r)
        return r.stdout
    def git(label, args, cwd=W):
        return command(label, [obs["tools"]["git"]["path"], "-c", "core.longpaths=true", "-c", "core.hooksPath=NUL", *args], cwd=cwd)
    try:
        require(git("base-head", ["rev-parse", "HEAD"]).strip().decode() == BASE, "moved source base")
        require(git("base-status", ["status", "--porcelain=v1"]) == b"", "source worktree changed")
        providers = json.loads(raw(Path(plan["provider_roster"]["path"])))
        require([p["id"] for p in providers] == ["universal_launcher", "universal_setup"], "provider order")
        for index, provider in enumerate(providers):
            p = Path(provider["path"])
            require(git(f"provider{index}-head", ["rev-parse", "HEAD"], p).strip().decode() == provider["head"], "provider head")
            require(git(f"provider{index}-status", ["status", "--porcelain=v1"], p) == b"", "provider dirty")
            snapshot(p, provider["files"], guard, canonical=False)
        command("clone", clone_command(obs["tools"]["git"]["path"], source), 180)
        require(git("clone-head", ["rev-parse", "HEAD"], source).strip().decode() == BASE, "clone did not retain exact base")
        require(not (source / ".git/objects/info/alternates").exists(), "no object alternates")
        git("checkout", ["-c", "core.autocrlf=false", "-c", "core.eol=lf", "-c", "core.attributesFile=NUL",
                         "checkout", "--detach", BASE], source)
        rows = json.loads(raw(Path(plan["base_roster"]["path"])))
        snapshot(source, rows, guard)
        manifest = document(Path(plan["candidate_manifest"]["path"]))
        bypath = {r["path"]: r for r in rows}
        for row in manifest["source"]:
            b = raw(Path(plan["candidate_payload"]) / row["path"])
            require(hashlib.sha256(b).hexdigest() == row["sha256"], "overlay drift")
            out = source / row["path"]
            out.parent.mkdir(parents=True, exist_ok=True)
            plain(out.parent, directory=True)
            if out.exists(): plain(out)
            out.write_bytes(b)
            bypath[row["path"]] = {k: row[k] for k in ("path", "bytes", "git_blob", "mode")}
        final_rows = list(bypath.values())
        write(root / "source-before.json", snapshot(source, final_rows, guard))
        status = git("candidate-status", ["status", "--porcelain=v1", "--untracked-files=all"], source)
        write(root / "source-status.json", {"head": BASE, "tree": TREE, "dirty": True,
                                             "porcelain_utf8": status.decode()})
        command("configure", configure_command(obs, source, build, providers), 180)
        cache = raw(build / "CMakeCache.txt").decode()
        require("CMAKE_GENERATOR:INTERNAL=Visual Studio 18 2026" in cache, "generator changed")
        compiler = raw(build / "CMakeFiles/4.2.3/CMakeCXXCompiler.cmake").decode()
        require(obs["tools"]["cl"]["path"].replace("\\", "/") in compiler, "compiler changed")
        for row in obs["tools"].values(): verify(row)
        command("build", build_command(obs["tools"]["cmake"]["path"], build), 900)
        compiled = [digest(build / "Release" / name) for name in
                    ("facman.exe", "facman_resource_identity_smoke.exe", "fl_archive_core_smoke.exe", "ulk.dll", "usk.dll")]
        write(root / "compiled-inputs.json", {"files": compiled, "source_head": BASE, "candidate_tree": TREE})
        selection = "^(facman_resource_identity_smoke|facman_resource_product_cli|fl_archive_core_smoke)$"
        view = json.loads(command("test-inventory", [obs["tools"]["ctest"]["path"], "--test-dir", str(build),
                    "-C", "Release", "--show-only=json-v1", "-R", selection]))
        expected = inspect_ctest(view, obs["tools"]["python"]["path"], source, build)
        write(root / "test-inventory.json", view)
        write(root / "source-before-tests.json", snapshot(source, final_rows, guard))
        for index, name in enumerate(NAMES):
            for item in compiled: verify(item)
            command("test-" + name, [obs["tools"]["ctest"]["path"], "--test-dir", str(build), "-C", "Release",
                    "--output-on-failure", "--timeout", "180", "-R", "^" + name + "$"], 240)
        write(root / "source-after.json", snapshot(source, final_rows, guard))
        for index, provider in enumerate(providers):
            snapshot(Path(provider["path"]), provider["files"], guard, canonical=False)
        for item in compiled: verify(item)
        for row in plan["pins"]: verify(row)
        for row in obs["tools"].values(): verify(row)
        guard()
        result.update(result="PASS_SCOPED_THREE_FIXTURES_ONLY", native_qualification=True,
                      selected_tests=NAMES, inventory=inventory(root), expected_test_argv=expected)
    except BaseException as error:
        result["error"] = type(error).__name__ + ": " + str(error)[:2048]
    finally:
        if result["quiescence"] == "observed":
            try: result["retained_usage"] = inventory(root)
            except Exception as error: result["inventory_error"] = str(error)[:2048]
        write(root / "result.json", result)
    return 0 if result["result"] == "PASS_SCOPED_THREE_FIXTURES_ONLY" else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--effect-review-sha256", required=True)
    parser.add_argument("--child", action="store_true")
    args = parser.parse_args()
    plan = document(args.plan)
    validate_plan(plan)
    require(str(args.plan) == plan["self_path"], "exact plan path")
    review = document(Path(plan["effect_review_path"]))
    require(digest(Path(plan["effect_review_path"]))["sha256"] == args.effect_review_sha256 and
            review.get("plan_sha256") == digest(args.plan)["sha256"] and
            review.get("authorized_once") is True, "exact effect review is absent")
    obs = document(Path(plan["observation"]["path"]))
    for row in plan["pins"]: verify(row)
    for row in obs["tools"].values(): verify(row)
    verify(obs["task_marker"])
    require(os.name == "nt", "Windows only")
    name = ctypes.create_unicode_buffer(256); size = ctypes.c_ulong(len(name))
    require(ctypes.windll.secur32.GetUserNameExW(2, name, ctypes.byref(size)) and
            name.value.casefold() == r"BLACKGLASS-WIN1\Jules".casefold(), "real interactive identity required")
    s = T.stat()
    require((s.st_dev, s.st_ino) == (obs["task_stat"]["device"], obs["task_stat"]["inode"]), "task identity drift")
    process = load_process(obs)
    if args.child:
        intent = document(Path(plan["invocation_root"]) / "intent.json")
        require(intent["plan_sha256"] == digest(args.plan)["sha256"] and intent["review_sha256"] == args.effect_review_sha256,
                "parent invocation binding")
        return child(plan, obs, process)
    out = Path(plan["invocation_root"])
    require(not Path(plan["root"]).exists(), "retained source child exists")
    out.mkdir()
    write(out / "intent.json", {"schema": "facman.once-only-build-intent.v1", "plan_sha256": digest(args.plan)["sha256"],
                               "review_sha256": args.effect_review_sha256, "identity": name.value,
                               "started_at": time.time(), "retry": False})
    env = environment(obs, out)
    expired(plan)
    r = process.command([obs["tools"]["python"]["path"], "-I", "-B", str(Path(__file__).resolve()),
            "--plan", str(args.plan), "--effect-review-sha256", args.effect_review_sha256, "--child"],
            cwd=out, environment=env, timeout=min(1800, plan["expires_at"] - time.time()), directory=out / "outer", output_limit=8 * 1024**2)
    write(out / "result.json", {"schema": "facman.once-only-build-invocation.v1", "receipt": r.receipt,
            "inner_result": str(Path(plan["root"]) / "result.json"), "never_retry": True,
            "stable_export_permitted": bool(r.receipt.get("job_empty_observed") and r.receipt.get("primary_stopped"))})
    return 0 if r.ok and r.receipt.get("job_empty_observed") and r.receipt.get("primary_stopped") else 1


if __name__ == "__main__":
    raise SystemExit(main())
