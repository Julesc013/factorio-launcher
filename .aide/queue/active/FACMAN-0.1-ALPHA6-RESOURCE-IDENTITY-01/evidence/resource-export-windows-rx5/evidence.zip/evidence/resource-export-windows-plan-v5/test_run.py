"""Pure, temporary-byte and injected controller tests; no Git/native dispatch."""
import hashlib
import importlib.util
from pathlib import Path
import tempfile
import time
import types
import unittest
from unittest import mock

spec = importlib.util.spec_from_file_location("candidate_windows_run", Path(__file__).with_name("run.py"))
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)


def plan():
    return {"schema": "facman.resource-export-windows-plan.v1", "source_head": r.BASE,
            "source_tree": r.BASE_TREE, "candidate_tree": r.TREE,
            "selected_tests": r.NAMES[:], "root": str(r.T / "rx5"),
            "invocation_root": str(r.T / "rx5-invocation"), "overall_seconds": 1800,
            "new_child_bytes": 2 * 1024**3, "expires_at": time.time() + 1000,
            "dispatch_enabled": True, "source_review": {"sha256":
            "1b1d311297e70e0954ef44790333b03d4707dd26169d436d76099e080a7c5406"}, "self_path": "unused"}


def receipt(output=b"", *, closed=True, exit_code=0):
    return types.SimpleNamespace(stdout=output, directory=Path("mock-command"),
        returncode=exit_code, receipt={"primary_stopped": closed, "job_empty_observed": closed,
        "exit_code": exit_code, "termination": "completed" if closed else "cleanup_incomplete"})


class Admission(unittest.TestCase):
    def test_ready_positive_and_draft_refusal(self):
        p = plan(); r.validate_plan(p)
        p["dispatch_enabled"] = False
        with self.assertRaisesRegex(ValueError, "draft"): r.validate_plan(p)

    def test_no_unbounded_nonfinite_or_expired_plan(self):
        for value in (None, True, 0, 10**1000, float("nan"), float("inf"), time.time() - 1, time.time() + 8000):
            with self.subTest(value=str(value)[:30]):
                p = plan(); p["expires_at"] = value
                with self.assertRaises(ValueError): r.validate_plan(p)

    def test_source_scope_root_and_budget_drift_refuse(self):
        for key, value in (("source_head", "0" * 40), ("candidate_tree", "f" * 40),
                           ("selected_tests", r.NAMES + ["facman_process_supervisor_smoke"]),
                           ("root", str(r.T / "native-p6")), ("overall_seconds", 7200),
                           ("new_child_bytes", 20 * 1024**3)):
            with self.subTest(key=key):
                p = plan(); p[key] = value
                with self.assertRaises(ValueError): r.validate_plan(p)

    def test_clone_is_shallow_file_only_without_checkout_or_local_linking(self):
        args = r.clone_command("pinned-git.exe", Path("owned-source"))
        self.assertIn("--no-local", args); self.assertIn("--depth=1", args)
        self.assertIn("--no-checkout", args); self.assertIn("--template=", args)
        self.assertEqual(args[-2], r.W.as_uri()); self.assertNotIn("--shared", args)
        self.assertNotIn("--reference", args)

    def test_longpaths_is_explicit_on_git_argv_and_nested_process_environment(self):
        args = r.clone_command("pinned-git.exe", Path("owned-source"))
        self.assertEqual(args[1:3], ["-c", "core.longpaths=true"])
        observation = {"tools": {key: {"path": "C:/fixed/" + key + ".exe"}
                       for key in ("cmake", "git", "python", "cl", "msbuild", "rc")}}
        env = r.environment(observation, Path("owned-temp"))
        self.assertEqual(env["GIT_CONFIG_COUNT"], "1")
        self.assertEqual(env["GIT_CONFIG_KEY_0"], "core.longpaths")
        self.assertEqual(env["GIT_CONFIG_VALUE_0"], "true")
        self.assertNotIn("--global", args)
        self.assertNotIn("config", args)

    def test_installer_programdata_is_fixed_without_other_environment_expansion(self):
        observation = {"tools": {key: {"path": "C:/fixed/" + key + ".exe"}
                       for key in ("cmake", "git", "python", "cl", "msbuild", "rc")}}
        with mock.patch.dict("os.environ", {"ProgramData": "untrusted-parent-value",
                                           "SystemDrive": "Z:", "UNREVIEWED_INPUT": "ignored"}):
            env = r.environment(observation, Path("owned-temp"))
        self.assertEqual(env.get("ProgramData"), r"C:\ProgramData")
        self.assertEqual(env["SystemDrive"], "C:")
        self.assertNotIn("UNREVIEWED_INPUT", env)

    def test_common_data_and_native_host_use_only_fixed_observed_environment(self):
        observation = {"tools": {key: {"path": "C:/fixed/" + key + ".exe"}
                       for key in ("cmake", "git", "python", "cl", "msbuild", "rc")}}
        with mock.patch.dict("os.environ", {"SystemDrive": "Z:",
                    "PROCESSOR_ARCHITECTURE": "x86", "ALLUSERSPROFILE": "not-admitted"}):
            env = r.environment(observation, Path("owned-temp"))
        self.assertEqual(env.get("SystemDrive"), "C:")
        self.assertEqual(env.get("PROCESSOR_ARCHITECTURE"), "AMD64")
        self.assertNotIn("ALLUSERSPROFILE", env)
        self.assertNotIn("PROCESSOR_ARCHITEW6432", env)

    def test_build_keeps_clean_tracking_and_only_three_targets(self):
        args = r.build_command("cmake.exe", Path("owned-build"))
        start = args.index("--target")
        self.assertEqual(args[start + 1:start + 4], ["facman_cli", "facman_resource_identity_smoke", "fl_archive_core_smoke"])
        self.assertIn("--clean-first", args); self.assertEqual(args[-1], "/p:TrackFileAccess=false")
        self.assertEqual(args[args.index("--parallel") + 1], "4")

    def test_environment_does_not_forward_arbitrary_values(self):
        observation = {"tools": {key: {"path": "C:/fixed/" + key + ".exe"}
                       for key in ("cmake", "git", "python", "cl", "msbuild", "rc")}}
        with mock.patch.dict("os.environ", {"GH_TOKEN": "synthetic-never-forward", "HTTP_PROXY": "synthetic"}):
            env = r.environment(observation, Path("owned-temp"))
        self.assertNotIn("GH_TOKEN", env); self.assertNotIn("HTTP_PROXY", env)
        self.assertEqual(env["GIT_ALLOW_PROTOCOL"], "file")
        self.assertEqual(env["GIT_CONFIG_NOSYSTEM"], "1")

    def test_exact_ctest_inventory_and_argument_drift(self):
        s, b, py = Path("source"), Path("build"), "python.exe"
        commands = [[str(b / "Release/facman_resource_identity_smoke.exe")],
             [py, str(s / "tests/integration/resource_identity_runtime.py"), "--cli", str(b / "Release/facman.exe"),
              "--fixture", str(b / "Release/facman_resource_identity_smoke.exe"), "--runtime-file", str(b / "Release/ulk.dll"),
              "--runtime-file", str(b / "Release/usk.dll"), "--work-root", str(b / "tests/native/resource-cli-runs")],
             [str(b / "Release/fl_archive_core_smoke.exe")]]
        view = {"tests": [{"name": n, "command": c} for n, c in zip(r.NAMES, commands)]}
        r.inspect_ctest(view, py, s, b)
        commands[1][-1] = "historical-fixtures"
        with self.assertRaisesRegex(ValueError, "argv drift"): r.inspect_ctest(view, py, s, b)

    def test_duplicate_ctest_name_refuses(self):
        with self.assertRaisesRegex(ValueError, "inventory"):
            r.inspect_ctest({"tests": [{"name": r.NAMES[0]}] * 3}, "p", Path("s"), Path("b"))


class Bytes(unittest.TestCase):
    def test_canonical_bytes_and_crlf_refusal(self):
        with tempfile.TemporaryDirectory(prefix="facman-rx5-source-test-") as temporary:
            root = Path(temporary); b = b"known\n"; (root / "x.c").write_bytes(b)
            row = {"path": "x.c", "bytes": len(b), "git_blob": hashlib.sha1(b"blob 6\0" + b).hexdigest()}
            self.assertEqual(len(r.snapshot(root, [row], lambda: None)), 1)
            (root / "x.c").write_bytes(b"known\r\n")
            with self.assertRaisesRegex(ValueError, "canonical"): r.snapshot(root, [row], lambda: None)

    def test_provider_physical_bytes_are_separate_from_git_normalization(self):
        with tempfile.TemporaryDirectory(prefix="facman-rx5-provider-test-") as temporary:
            root = Path(temporary); b = b"known\r\n"; (root / "x.c").write_bytes(b)
            row = {"path": "x.c", "physical_bytes": len(b), "sha256": hashlib.sha256(b).hexdigest(), "git_blob": "not-used"}
            r.snapshot(root, [row], lambda: None, canonical=False)
            (root / "extra").write_bytes(b"")
            with self.assertRaisesRegex(ValueError, "extra"): r.snapshot(root, [row], lambda: None, canonical=False)

    def test_missing_source_and_expired_guard_refuse(self):
        with tempfile.TemporaryDirectory(prefix="facman-rx5-missing-test-") as temporary:
            root = Path(temporary)
            with self.assertRaisesRegex(ValueError, "missing"):
                r.snapshot(root, [{"path": "absent.c"}], lambda: None)
            (root / "x").write_bytes(b"")
            with self.assertRaisesRegex(RuntimeError, "expired"):
                r.snapshot(root, [{"path": "x"}], mock.Mock(side_effect=RuntimeError("expired")))

    def test_retained_fixture_link_is_metadata_only_and_pruned(self):
        dirs = ["kept-link"]
        facts = types.SimpleNamespace(st_mode=r.stat.S_IFLNK, st_file_attributes=r.REPARSE, st_size=987654)
        with mock.patch.object(r.os, "walk", return_value=iter([("owned", dirs, [])])), \
             mock.patch.object(Path, "lstat", return_value=facts), \
             mock.patch.object(r.os, "readlink", return_value="original-fixture"):
            value = r.inventory(Path("owned"))
        self.assertEqual(dirs, [])
        self.assertEqual(value["entries"], 1)
        self.assertEqual(value["bytes"], 0)
        self.assertEqual(value["reparse_metadata_only"], [{"path": "kept-link", "target": "original-fixture", "followed": False}])

    def test_resource_threshold_and_no_output_deletion(self):
        with tempfile.TemporaryDirectory(prefix="facman-rx5-limit-test-") as temporary:
            root = Path(temporary); (root / "keep").write_bytes(b"12345")
            with self.assertRaisesRegex(ValueError, "threshold"): r.inventory(root, maximum_bytes=4)
            self.assertEqual((root / "keep").read_bytes(), b"12345")


class DispatchFailures(unittest.TestCase):
    def exercise(self, outputs):
        process = types.SimpleNamespace(Budget=mock.Mock(return_value=types.SimpleNamespace(remaining=lambda: 1000)),
                                        command=mock.Mock(side_effect=outputs), require=mock.Mock())
        process.require.side_effect = lambda row: None if row.returncode == 0 else (_ for _ in ()).throw(ValueError("failed"))
        observation = {"task_short_path": str(r.T), "task_marker": {}, "tools": {"git": {"path": "git.exe"}}}
        with mock.patch.object(Path, "exists", return_value=False), mock.patch.object(Path, "mkdir"), \
             mock.patch.object(r.os.path, "samefile", return_value=True), mock.patch.object(r, "environment", return_value={}), \
             mock.patch.object(r, "write") as write, mock.patch.object(r, "digest", return_value={}), \
             mock.patch.object(r, "verify"), mock.patch.object(r, "inventory", return_value={}) as inv:
            code = r.child(plan(), observation, process)
            result = write.call_args_list[-1].args[1]
        return code, result, process.command, inv

    def test_moved_base_refuses_before_clone_and_preserves_closed_read(self):
        code, value, calls, _ = self.exercise([receipt(b"moved\n")])
        self.assertEqual(code, 1); self.assertEqual(calls.call_count, 1)
        self.assertEqual(value["quiescence"], "observed")
        self.assertIn("moved source base", value["error"])
        self.assertEqual(calls.call_args.args[0][1:3], ["-c", "core.longpaths=true"])

    def test_start_exception_clears_previous_quiescence_and_stops(self):
        code, value, calls, inv = self.exercise([receipt((r.BASE + "\n").encode()), RuntimeError("injected before usable helper result")])
        self.assertEqual(code, 1); self.assertEqual(calls.call_count, 2)
        self.assertEqual(value["quiescence"], "unknown")
        self.assertEqual(inv.call_count, 1)
        self.assertNotIn("retained_usage", value)

    def test_unclosed_group_prevents_stable_inventory(self):
        code, value, calls, inv = self.exercise([receipt(closed=False)])
        self.assertEqual(code, 1); self.assertEqual(calls.call_count, 1)
        self.assertEqual(value["quiescence"], "unknown"); inv.assert_not_called()

    def test_nonzero_closed_child_is_failure_without_retry(self):
        code, value, calls, _ = self.exercise([receipt(exit_code=7)])
        self.assertEqual(code, 1); self.assertEqual(calls.call_count, 1)
        self.assertEqual(value["quiescence"], "observed")
        self.assertFalse(value["native_qualification"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
