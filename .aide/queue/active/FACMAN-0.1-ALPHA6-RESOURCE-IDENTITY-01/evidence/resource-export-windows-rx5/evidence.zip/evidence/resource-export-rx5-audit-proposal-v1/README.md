# RX5 recorded-outcome custody auditor

This is source preparation only. The ten pure and mocked tests passed. No rx5 output
was read, and no build, fixture, Git or native command was dispatched by this packet.
The draft is disabled until ROOT reports closure and supplies the exact final wrapper
receipt in a separately bound ready plan. The historical effect expiry is checked
against the recorded invocation start; the audit never reexecutes that effect.

The auditor preserves a closed failure as a failure. A recorded pass requires all
sixteen commands, all three selected fixtures, both levels of owned-job closure,
exact command arguments, source maps/canonical blob identities, compiler metadata,
and unchanged five compiled inputs. CTest child arguments are derived independently
and slash spelling is normalized without treating a different executable as equal.
This is only the scoped three-fixture evidence, not complete product qualification.

Two exclusive-create ZIPs retain original control/compiler-identification bytes and
selected binaries/fixture artifacts. Exact member maps identify every source file.
The complete retained root is hashed before/after; remaining clone and intermediate
files stay map-only. Links remain metadata-only. Old failed roots are never touched.
The exact prefix allowlist and bounds are in plan.draft.json and audit.py.

The 300-second guard is cooperative around ordinary reads/compression, not a hard
filesystem-syscall deadline. The source assumes the protected controller namespace.
Unknown closure refuses before stable hashing/export. Later refusal retains the
new audit intent and partial archive; there is no replay, adoption or cleanup path.

The final ten-test run supersedes the initial seven-test source preparation, whose
original source and raw logs remain in pre-final-7-test-source.zip. The wrapper
closed-state check is a final metadata-only assertion added after that run and is
covered by the next source review; no actual build outcome has been inferred.
