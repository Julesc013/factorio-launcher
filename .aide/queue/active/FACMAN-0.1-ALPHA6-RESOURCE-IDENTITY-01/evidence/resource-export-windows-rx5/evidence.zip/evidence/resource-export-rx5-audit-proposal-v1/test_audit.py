"""Pure audit closure/allowlist regression; no actual rx5 access."""
import copy,importlib.util,unittest,hashlib,io
from types import SimpleNamespace
from unittest.mock import patch
from pathlib import Path
s=importlib.util.spec_from_file_location('audit',Path(__file__).with_name('audit.py'));a=importlib.util.module_from_spec(s);s.loader.exec_module(a)
def values():
 commands=[{'label':n,'primary_stopped':True,'job_empty_observed':True,'exit_code':0,'termination':'completed'} for n in a.LABELS]
 return {'quiescence':'observed','source_head':a.HEAD,'candidate_tree':a.TREE,'commands':commands,'result':'PASS_SCOPED_THREE_FIXTURES_ONLY','native_qualification':True,'selected_tests':a.TESTS},{'receipt':{'primary_stopped':True,'job_empty_observed':True,'exit_code':0},'stable_export_permitted':True}
class Tests(unittest.TestCase):
 def test_exact_pass(self):self.assertEqual(a.outcome(*values()),'PASS_RECORDED_THREE_FIXTURES_ONLY')
 def test_closed_configure_failure(self):
  i,o=values();i.update(result='FAIL_OR_UNKNOWN',native_qualification=False);i['commands']=i['commands'][:11];i['commands'][-1]['exit_code']=1;o['receipt']['exit_code']=1
  self.assertEqual(a.outcome(i,o),'CLOSED_FAILURE_PRESERVED')
 def test_unknown_outer_or_inner_refuses(self):
  for scope,key in [('outer','job_empty_observed'),('outer','primary_stopped'),('inner','job_empty_observed'),('inner','primary_stopped')]:
   with self.subTest(scope=scope,key=key):
    i,o=values();(o['receipt'] if scope=='outer' else i['commands'][-1])[key]=False
    with self.assertRaises(a.Refused):a.outcome(i,o)
 def test_short_failed_or_fabricated_pass_refuses(self):
  for delta in ['short','failed','duplicate','wrongsource']:
   i,o=values()
   if delta=='short':i['commands'].pop()
   elif delta=='failed':i['commands'][3]['exit_code']=1
   elif delta=='duplicate':i['commands'][3]['label']=i['commands'][2]['label']
   else:i['source_head']='0'*40
   with self.assertRaises(a.Refused):a.outcome(i,o)
 def test_only_explicit_archive_prefixes(self):
  for path in ['s/.git/config','n/Other/executable.exe','n/CMakeFiles/unrelated.txt','e/unknown/stdout.raw','elsewhere/secret','n/Release/other.dll']:
   with self.subTest(path=path):self.assertIsNone(a.archive_class(path))
 def test_required_control_and_owned_artifact_prefixes(self):
  for path in ['result.json','e/configure/stderr.raw','n/CMakeFiles/4.2.3/CompilerIdC/Debug/CMakeCCompilerId.obj']:
   self.assertEqual(a.archive_class(path),'control')
  for path in ['n/Release/facman.exe','n/tests/native/resource-cli-runs/result.json','t/retained-fixture/file']:
   self.assertEqual(a.archive_class(path),'artifacts')
 def test_canonical_source_set_and_blob_identity(self):
  base=[{'path':'a','bytes':1,'git_blob':'one'}];candidate=[{'path':'b','bytes':2,'git_blob':'two'}]
  rows=[{'path':'s/a','kind':'file','bytes':1,'git_blob':'one'},{'path':'s/b','kind':'file','bytes':2,'git_blob':'two'}]
  self.assertEqual(set(a.check_source_rows(base,candidate,rows)),{'a','b'})
  for mutation in ['extra','missing','blob','link']:
   bad=copy.deepcopy(rows)
   if mutation=='extra':bad.append({'path':'s/c','kind':'file','bytes':1,'git_blob':'one'})
   elif mutation=='missing':bad.pop()
   elif mutation=='blob':bad[0]['git_blob']='changed'
   else:bad[0]['kind']='symlink_or_reparse'
   with self.subTest(mutation=mutation),self.assertRaises(a.Refused):a.check_source_rows(base,candidate,bad)
 def test_stream_literal_git_hash(self):
  data=b'binary\x00\xff\r\n';facts=SimpleNamespace(st_mode=0o100600,st_size=len(data),st_dev=1,st_ino=2,st_mtime_ns=3)
  with patch.object(a,'plain',return_value=facts),patch.object(Path,'open',return_value=io.BytesIO(data)),patch.object(Path,'lstat',return_value=facts):
   result=a.digest_stream(Path('synthetic'),lambda:None,git_blob=True)
  self.assertEqual(result,dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),git_blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()))
 def test_ctest_argv_is_independently_derived(self):
  source=Path('C:/fixed/source');build=Path('C:/fixed/build');python='C:/fixed/python.exe'
  recorded={a.TESTS[0]:[str(build/'Release/facman_resource_identity_smoke.exe')],a.TESTS[2]:[str(build/'Release/fl_archive_core_smoke.exe')],a.TESTS[1]:[python,str(source/'tests/integration/resource_identity_runtime.py'),'--cli',str(build/'Release/facman.exe'),'--fixture',str(build/'Release/facman_resource_identity_smoke.exe'),'--runtime-file',str(build/'Release/ulk.dll'),'--runtime-file',str(build/'Release/usk.dll'),'--work-root',str(build/'tests/native/resource-cli-runs')]}
  view={'tests':[{'name':n,'command':[x.replace('\\','/') for x in args]} for n,args in recorded.items()]}
  a.check_test_argv(view,recorded,python,source,build)
  recorded[a.TESTS[0]]=['unexpected.exe'];view['tests'][0]['command']=['unexpected.exe']
  with self.assertRaises(a.Refused):a.check_test_argv(view,recorded,python,source,build)
 def test_traversal_cannot_extend_archive_prefix(self):
  for name in ['n/tests/../../foreign','t/../foreign','n/tests/file:stream','C:/n/tests/file']:
   with self.subTest(name=name):self.assertIsNone(a.archive_class(name))
if __name__=='__main__':unittest.main(verbosity=2)
