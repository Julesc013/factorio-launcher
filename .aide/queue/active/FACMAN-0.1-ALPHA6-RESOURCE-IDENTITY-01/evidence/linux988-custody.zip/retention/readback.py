import hashlib,json,os,stat,time,subprocess
from pathlib import Path
E=Path("/mnt/c/Users/Jules/AppData/Local/FacMan/Development/repositories/factorio-launcher-5db2844e2f29/tasks/facman-0.1-al-d9fce3b03d/evidence/linux-lp9-durable-run");A=json.loads((E/"linux-artifacts.json").read_bytes());root=Path(A["root"])
M=json.loads((E/"linux-root-marker.json").read_bytes());marker=M["marker"]
namespace=json.loads((E/"linux-namespace-marker.json").read_bytes());base=root.parent
deadline=time.monotonic()+80
boot=Path("/proc/sys/kernel/random/boot_id").read_text().strip()
mount=subprocess.run(["/usr/bin/findmnt","--json","--output","TARGET,SOURCE,FSTYPE,UUID","--target","/var/lib"],capture_output=True,check=True,timeout=10)
filesystem=json.loads(mount.stdout)["filesystems"];assert len(filesystem)==1
assert filesystem[0]["fstype"]=="ext4" and filesystem[0]["uuid"]==marker["filesystem_uuid"]==namespace["marker"]["filesystem_uuid"]
observations=[]
for p,m,filename,digest in [(root,marker,".facman-linux-execution-root.v2.json",M["marker_sha256"]),(base,namespace["marker"],".facman-development-namespace.v1.json",namespace["marker_sha256"])]:
 s=p.lstat();assert stat.S_ISDIR(s.st_mode) and not p.is_symlink()
 assert (s.st_ino,s.st_uid,s.st_gid,stat.S_IMODE(s.st_mode))==(m["inode"],0,0,0o711)
 raw=(p/filename).read_bytes();assert hashlib.sha256(raw).hexdigest()==digest and json.loads(raw)==m
 observations.append({"path":str(p),"inode":s.st_ino,"creation_device":m["device"],"current_device":s.st_dev,"mode":"0711","marker_sha256":digest})
assert not (root/"fixtures").exists() and not (root/"sdk-parent").exists() and not (root/"tmp/identity-workspace").exists()
actual=set()
for parent,dirs,files in os.walk(root,followlinks=False):
 for name in files+[name for name in dirs if (Path(parent)/name).is_symlink()]:
  actual.add((Path(parent)/name).relative_to(root).as_posix())
assert actual=={r["relative_path"] for r in A["entries"]}
for r in A["entries"]:
 assert time.monotonic()<deadline
 p=root/r["relative_path"];s=p.lstat()
 assert s.st_size==r["bytes"] and s.st_uid==r["uid"] and s.st_gid==r["gid"] and oct(stat.S_IMODE(s.st_mode))==r["mode"]
 if r["kind"]=="symlink":assert p.is_symlink() and os.readlink(p)==r["target"] and p.resolve().is_relative_to(root)
 else:
  assert stat.S_ISREG(s.st_mode)
  h=hashlib.sha256()
  with p.open("rb") as f:
   for chunk in iter(lambda:f.read(1048576),b""):
    assert time.monotonic()<deadline;h.update(chunk)
  assert h.hexdigest()==r["sha256"],r["relative_path"]
assert Path("/proc/sys/kernel/random/boot_id").read_text().strip()==boot
print(json.dumps({"result":"PASS_CURRENT_DURABLE_BUILD_ORIGINALS","entries":len(A["entries"]),"filesystem":filesystem[0],"creation_boot_id":marker["creation_boot_id"],"current_boot_id":boot,"observed_in_different_boot":boot!=marker["creation_boot_id"],"root_observations":observations,"fixtures_and_sdk_absent":True,"device_numbers_observed_not_treated_as_cross_boot_identity":True}))
