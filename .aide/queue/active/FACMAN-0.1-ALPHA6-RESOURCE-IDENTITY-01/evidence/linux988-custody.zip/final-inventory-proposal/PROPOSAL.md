# Complete post-continuation inventory proposal

The frozen continuation exporter records only descendants of its fixtures root. It omits exactly the continuation child directory, `.continuation-owner.json`, and the fixtures directory itself. Their final Linux mode/uid/gid cannot be reconstructed from creation intent or Windows-side copies. The full root map remains unavailable until a separate observation closes.

Use one separately reviewed finite read-only collector after the continuation closes and its actual receipt is independently audited. Reuse the frozen preimage observer and current-epoch/root checks; compare all 2,753 preserved SDK rows and the observed exported descendants, then directly observe the three missing rows. Emit a complete sorted SDK-shaped map and current object/epoch metadata. No frozen runtime changes, extra selected test, or Linux effect is included in this proposal.

The exact source/effect plan, interpreter/controller pins, actual continuation/export/review hashes, output reservation and expiry remain unresolved. This proposal is not dispatch authority. The factual SDK and three-check documentation checkpoint can proceed independently of this later map.
