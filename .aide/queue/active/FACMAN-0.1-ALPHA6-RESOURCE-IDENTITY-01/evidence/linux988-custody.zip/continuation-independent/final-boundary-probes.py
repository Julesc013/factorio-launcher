"""Independent final-boundary probes; invoke only the already mocked source harness."""
import json,sys
from pathlib import Path
from unittest import mock
P=Path(__file__).parent.parent/'linux-fixture-continuation-v1';sys.path.insert(0,str(P))
import continuation_runtime_tests as t
original=mock.patch.object
results=[]
for mode in ('preserved_after','final_input','outer_after'):
    def intercept(target,name,*args,**kw):
        if mode=='preserved_after' and target is t.r.pre and name=='verify':
            kw={'side_effect':[dict(status='PASS'),ValueError('independent preserved-root drift')]}
        if mode=='final_input' and target is t.r.v6 and name=='verify_inputs':
            kw={'side_effect':[None,ValueError('independent final-input drift')]}
        if mode=='outer_after' and target is t.c and name=='verify_sources':
            kw={'side_effect':[None,None,ValueError('independent final-controller drift')]}
        return original(target,name,*args,**kw)
    with original(mock.patch,'object',side_effect=intercept):
        if mode=='outer_after':
            record,calls,receipts,creates=t.OuterTests().harness()
            assert record['result']=='FAIL_RETAINED' and len(calls)==1
            assert 'independent final-controller drift' in record['error']
        else:
            record,closes,reads,exports,receipts=t.RuntimeTests().harness()
            assert record['result']=='FAIL_RETAINED' and exports==0
            assert any('independent' in x for x in record['final_observation_errors'])
        assert receipts[-1][1]==record
        results.append(dict(mode=mode,result=record['result'],durable_final_receipt=True,errors=record.get('final_observation_errors',record.get('error'))))
print(json.dumps(dict(result='PASS_INJECTED_REFUSALS',cases=results,linux_native_sdk_effects=False),indent=2))
