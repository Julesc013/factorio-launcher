"""Seal closed once-only SDK execution; Windows evidence reads/writes only."""
from pathlib import Path, PurePosixPath
import hashlib, json, zipfile, io, collections
T=Path(r"C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-d9fce3b03d")
E=T/"evidence"; R=E/"linux-installed-sdk-lp9-run-01"; P=E/"linux-installed-sdk-ready-v1"
D=E/"linux-installed-sdk-actual-seal"
def sha(raw): return hashlib.sha256(raw).hexdigest()
def read(path):
    path=Path(path)
    assert not path.is_symlink() and path.is_file(),str(path)
    raw=path.read_bytes()
    assert len(raw)<=64*1024**2,str(path)
    return raw
def decode(raw): return json.loads(raw)
def ref(path):
    raw=read(path);return dict(path=str(path),bytes=len(raw),sha256=sha(raw))
def write(name,value):
    raw=(json.dumps(value,indent=2,sort_keys=True)+"\n").encode()
    with (D/name).open("xb") as f:f.write(raw)
    return ref(D/name)
plan_raw=read(P/"ready-plan.json"); plan=decode(plan_raw)
assert sha(plan_raw)=="c3692f663dec183c7c0b8effe517468d83ee48f72adba165aee1ba2d52a69f29"
b_raw=read(P/"bindings.json");b=decode(b_raw)
assert sha(b_raw)==plan["bindings_sha256"]=="57ce4e7f324206803b058e14dc70a189087036ee77a09e1e265819049f7da512"
review=read(P/"root-effect-review.json")
assert sha(review)=="cbd51eafa9e0fffded19bd2d469087496994e65116f0b60328db52a7bccc1199"
for name,digest in plan["script_hashes"].items():assert sha(read(P/name))==digest
inv=decode(read(P/"invocation/result.json"))
assert inv["exit_code"]==0 and inv["error"] is None and inv["source_unchanged"] and inv["automatic_retries"]==0
assert inv["identity"].casefold()=="blackglass-win1\\jules"
win=decode(read(R/"windows-result.json"));linux=decode(read(R/"linux-result.json"))
assert win["result"]==linux["result"]=="PASS_INSTALLED_SHARED_SDK_CONSUMPTION_ONLY"
assert linux["source_commit"]==b["source_commit"]==plan["source_commit"]
assert linux["source_tree"]==b["source_tree"]==plan["source_tree"]
assert linux["quiescent"] is True and linux["effects_reset"] is False
assert linux["final_source_observation"]["status"]=="PASS"
assert linux["initial_source_observation"]==linux["final_source_observation"]["rows"]
assert linux["epoch_before"]==linux["epoch_after"]
assert linux["export"]["status"]=="PASS" and linux["export"]["stable_export_attempted"]
assert not any(k in linux for k in ("error","post_error","close_error"))
assert win["final_control_observation"]["status"]=="PASS"
job=decode(read(R/"wsl-sdk/receipt.json"))
assert job["exit_code"]==0 and job["job_empty_observed"] and job["primary_stopped"] and job["error"] is None
for stream in ("stdout","stderr"):
    row=job[stream];raw=read(R/"wsl-sdk"/row["file"])
    assert len(raw)==row["captured_bytes"] and sha(raw)==row["sha256"]
assert len(linux["commands"])==12
for c in linux["commands"]:
    assert c["exit_code"]==0 and c["quiescence"]["quiescent"] and not c["cleanup_errors"] and c["refusal"] is None
    assert decode(read(R/(c["name"]+".json")))==c
    for stream in ("stdout","stderr"):assert len(read(R/(c["name"]+"."+stream+".raw")))==c["stream_bytes"][stream]
assert decode(read(R/"worker-identity.stdout.raw"))==dict(uid=65534,gid=65534,groups=[])
old={row["path"]:row for row in b["original_root_inventory"]}
after_raw=read(R/"root-after.json");after=decode(after_raw);new={row["path"]:row for row in after}
assert len(old)==1467 and len(new)==len(after)
assert all(new.get(name)==row for name,row in old.items())
added=sorted(set(new)-set(old))
assert all(x in (".sdk-run-owner.v1.json","native/install_manifest.txt","sdk-parent") or x.startswith("sdk-parent/") for x in added)
assert "native/install_manifest.txt" not in old
manifest=new["native/install_manifest.txt"]
assert (manifest["mode"],manifest["uid"],manifest["gid"])==(0o600,65534,65534)
assert manifest==linux["original_mutations"]["install_manifest_after"]
assert not linux["original_mutations"]["allowed_build_change"]
assert linux["install_manifest_before"] is None
assert new[".sdk-run-owner.v1.json"]["mode"]==0o400
assert new["sdk-parent"]["mode"]==0o700
expected={row["path"]:row for row in linux["export"]["members"]}
assert set(expected)=={x for x in added if new[x]["kind"]=="file"}
assert len(expected)<=4096 and sum(x["bytes"] for x in expected.values())<=512*1024**2
z_raw=read(R/"sdk-custody.zip");nested={}
with zipfile.ZipFile(io.BytesIO(z_raw)) as z:
    names=z.namelist()
    assert len(names)==len(set(names))==len(expected)
    for name in names:
        assert not PurePosixPath(name).is_absolute() and ".." not in PurePosixPath(name).parts
        raw=z.read(name);row=expected[name]
        assert len(raw)==row["bytes"] and sha(raw)==row["sha256"] and row==new[name]
        nested[name]=raw
assert len(z_raw)==linux["export"]["archive_bytes"]
work="sdk-parent/retained-sdk/";stage=work+"relocated-sdk/"
md=decode(nested["sdk-parent/sdk-metadata-oracle.json"])
rt=decode(nested["sdk-parent/sdk-runtime-oracle.json"])
assert md["result"]=="PASS" and md["initial_prefix_absent"] is True
assert rt["result"]=="PASS_RELOCATED_CURRENT_LEGACY_CONSUMERS" and rt["loader_ownership_claim"] is False
command_names=["01-install","02-configure","03-build","04-facman_sdk_consumer","05-facman_sdk_legacy_consumer"]
assert md["commands"]==command_names
helper=[]
for name in command_names:
    c=decode(nested[work+"commands/"+name+".json"]);assert c["exit_code"]==0 and "error" not in c
    row=dict(name=name,receipt=c)
    for stream in ("stdout","stderr"):
        raw=nested[work+"commands/"+name+"."+stream+".raw"]
        row[stream]=dict(bytes=len(raw),sha256=sha(raw))
    helper.append(row)
assert set(md["install_manifest_members"])=={x[len(stage):] for x,row in new.items() if x.startswith(stage) and row["kind"] in ("file","symlink")}
assert not any(x.startswith(work+"initial-sdk") for x in new)
assert len(md["install_manifest_members"])==len(set(md["install_manifest_members"]))
assert len(rt["elf"])==3 and len(rt["consumers"])==2
for item in rt["elf"]:
    assert item["original_sha256"]==old[item["source"]]["sha256"]
    assert item["installed_sha256"]==sha(nested[stage+item["installed"]])
    assert item["raw_byte_equivalence_claim"] is False
for item in rt["consumers"]:
    assert item["sha256"]==sha(nested[work+"consumer-build/"+item["name"]])
# Independently inspect exported ABI metadata and generated relocatable metadata.
abi=decode(nested[stage+"share/facman/abi/compatibility.v1.json"])
assert abi["flb_abi"]["encoded"]==65539 and abi["required_ulk_abi"]==dict(major=1,minor=9,encoded=65545)
config=nested[stage+"lib/cmake/FacMan/FacManConfig.cmake"].decode()
assert 'set(FacMan_FLB_ABI_VERSION "1.3")' in config and 'set(FacMan_REQUIRED_ULK_ABI_VERSION "1.9")' in config
for name,raw in nested.items():
    if name.startswith(stage+"lib/cmake/FacMan/") or name==stage+"lib/pkgconfig/facman-flb.pc":
        text=raw.decode("utf-8")
        assert all(x not in text and x.replace("/","\\") not in text for x in md["forbidden_prefixes"])
# Read and bind the exact closed output roster only. No Linux traversal or effects.
selected={}
def select(path):
    path=Path(path);assert path.is_relative_to(T)
    name=path.relative_to(T).as_posix()
    assert name not in selected
    selected[name]=(path,read(path))
for path in sorted(R.rglob("*")):
    assert not path.is_symlink(),str(path)
    if path.is_file():select(path)
for path in sorted((P/"invocation").iterdir()):
    assert path.is_file() and not path.is_symlink();select(path)
for name in ("ready-plan.json","bindings.json","proposal.json","root-effect-review.json","invoke-once.py",*plan["script_hashes"]):
    select(P/name)
for row in b["preserved_receipts"]:
    path=Path(row["path"]);raw=read(path)
    assert len(raw)==row["bytes"] and sha(raw)==row["sha256"],str(path)
    if path.relative_to(T).as_posix() not in selected:select(path)
assert len(selected)<=200 and sum(len(x[1]) for x in selected.values())<=96*1024**2
archive=D/"closed-sdk-evidence.zip"
with zipfile.ZipFile(archive,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=6) as out:
    for name,(path,raw) in sorted(selected.items()):out.writestr(name,raw)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(selected) and len(z.namelist())==len(selected)
    for name,(path,raw) in selected.items():
        assert z.read(name)==raw and read(path)==raw
roster=[dict(member=name,path=str(path),bytes=len(raw),sha256=sha(raw)) for name,(path,raw) in sorted(selected.items())]
mapref=write("closed-originals.json",roster)
sdkmap=write("sdk-export-members.json",list(expected.values()))
oracles=write("recorded-oracles.json",dict(metadata=md,runtime=rt,helper_commands=helper))
summary=dict(schema="facman.installed_sdk_actual_handoff.v1",
    status="PASS_RECORDED_INSTALLED_SHARED_SDK_RUN_SEALED_PENDING_ROOT_AUDIT",
    actual_result=linux["result"],source_commit=linux["source_commit"],source_tree=linux["source_tree"],
    windows_identity=inv["identity"],invocation=ref(P/"invocation/result.json"),windows_result=ref(R/"windows-result.json"),
    linux_result=ref(R/"linux-result.json"),outer_seconds=inv["elapsed_seconds"],linux_seconds=linux["elapsed_seconds"],
    linux_commands=12,all_groups_observed_quiescent=True,windows_job_empty_observed=True,automatic_retries=0,
    source_custody=dict(regular_input_files=sum(sum(x["kind"]=="file" for x in root["files"]) for root in b["source_roots"]),
        initial_final_inventory_rows=linux["initial_source_observation"],semantics="sequential exact source rows and Git controls; no OS source lease"),
    actual_epoch=linux["epoch_before"],persistent_root=dict(filesystem_uuid=b["filesystem_uuid"],
        root_inode=b["root_inode"],namespace_inode=b["namespace_inode"],root_marker=b["root_marker"],namespace_marker=b["namespace_marker"]),
    original_root_entries=len(old),final_root_entries=len(new),final_root_kind_counts=dict(collections.Counter(x["kind"] for x in after)),
    root_after=ref(R/"root-after.json"),root_after_schema="JSON array: relative path/kind/mode/uid/gid; file bytes/sha256 or symlink target",
    original_rows_unchanged=True,added_entries=len(added),allowed_added_prefix="sdk-parent/",
    allowed_added_exact=[".sdk-run-owner.v1.json","native/install_manifest.txt","sdk-parent"],
    install_manifest_after=manifest,sdk_export=ref(R/"sdk-custody.zip"),sdk_export_regular_members=len(expected),
    sdk_export_uncompressed_bytes=sum(x["bytes"] for x in expected.values()),sdk_symlinks="metadata mapped only; no target dereference",
    metadata_oracle=dict(result=md["result"],install_manifest_members=len(md["install_manifest_members"]),initial_prefix_absent=True,
        flb_abi="1.3",required_ulk_abi="1.9",generated_exports_no_tested_source_build_initial_prefix=True),
    runtime_oracle=dict(result=rt["result"],elf=rt["elf"],consumers=rt["consumers"],ordinary_host_dependencies_only=True),
    qualification=linux["qualification"],limits=[
        "Installed/shared relocated current and legacy SDK consumption only.",
        "No static SDK, provider adoption, hosted, game, human, package or release eligibility transfer.",
        "Prior native fixture run remains failed: 13 passed, resource CLI failed, ABI symbol unrun.",
        "Ordinary-group supervision only; no session-escape or hardened/private-loader authority.",
        "Original native/GTK build is preserved separately; only SDK outputs plus reviewed manifest/intent exported.",
        "Archive verification is a recorded byte audit, not an independent SDK rerun or fresh Linux root readback."],
    archive=ref(archive),archive_original_files=len(roster),originals_map=mapref,sdk_member_map=sdkmap,
    recorded_oracles=oracles,plan=ref(P/"ready-plan.json"),root_effect_review=ref(P/"root-effect-review.json"),
    collector_actual_audit=b["collector_actual_audit"],fixture_actual_audit=b["fixture_audit"],
    install_script_review=b["install_script_review"])
handoff=write("handoff.json",summary)
print(json.dumps(dict(handoff=handoff,archive=summary["archive"],root_after=summary["root_after"],
    original_files=len(roster),root_entries=len(new),sdk_files=len(expected),installed_members=len(md["install_manifest_members"]),
    elf=rt["elf"],consumer_names=[x["name"] for x in rt["consumers"]])))
