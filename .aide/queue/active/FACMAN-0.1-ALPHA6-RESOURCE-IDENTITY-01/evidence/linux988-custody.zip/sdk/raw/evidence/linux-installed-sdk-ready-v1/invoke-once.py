from pathlib import Path
import subprocess,json,hashlib,sys,os,time
D=Path(__file__).parent;Q=D/"invocation"
assert not Q.exists();Q.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
identity=subprocess.run(["whoami"],capture_output=True,check=True,timeout=5).stdout.decode().strip()
assert identity.casefold()==r"BLACKGLASS-WIN1\Jules".casefold()
plan=(D/"ready-plan.json").read_bytes();review=(D/"root-effect-review.json").read_bytes()
assert sha(plan)=="c3692f663dec183c7c0b8effe517468d83ee48f72adba165aee1ba2d52a69f29"
assert sha(review)=="cbd51eafa9e0fffded19bd2d469087496994e65116f0b60328db52a7bccc1199"
p=json.loads(plan)
assert sha((D/"bindings.json").read_bytes())=="57ce4e7f324206803b058e14dc70a189087036ee77a09e1e265819049f7da512"
for name,digest in p["script_hashes"].items():assert sha((D/name).read_bytes())==digest
argv=[sys.executable,"-B",str(D/"windows_controller.py"),"--plan",str(D/"ready-plan.json"),
      "--review",str(D/"root-effect-review.json"),"--review-sha256",sha(review)]
intent={"identity":identity,"argv":argv,"plan_sha256":sha(plan),"review_sha256":sha(review),
 "source_hashes":p["script_hashes"],"once_only":True,"automatic_retries":0,"sdk_effects":True}
with (Q/"intent.json").open("x") as f:json.dump(intent,f,indent=2)
start=time.monotonic();error=None;code=None
try:
 with (Q/"stdout.raw").open("xb") as out,(Q/"stderr.raw").open("xb") as err:
  result=subprocess.run(argv,cwd=D,env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1"),stdout=out,stderr=err,timeout=930)
 code=result.returncode
except BaseException as e:error=repr(e)
sources_same=all(sha((D/n).read_bytes())==s for n,s in p["script_hashes"].items())
value={"identity":identity,"argv":argv,"exit_code":code,"error":error,"elapsed_seconds":time.monotonic()-start,
 "source_unchanged":sources_same,"plan_sha256":sha(plan),"review_sha256":sha(review),"automatic_retries":0,
 "sdk_effects":True,"stdout_sha256":sha((Q/"stdout.raw").read_bytes()),"stderr_sha256":sha((Q/"stderr.raw").read_bytes())}
with (Q/"result.json").open("x") as f:json.dump(value,f,indent=2)
print(json.dumps(value))
raise SystemExit(0 if code==0 and error is None and sources_same else 1)
