"""Proposed lp9 SDK lane. Import and --check perform no native effects."""
from __future__ import annotations
import argparse, hashlib, json, os, re, stat, sys, time, traceback
from pathlib import Path, PurePosixPath
import sdk_records as r
import sdk_process as proc
import sdk_metadata as metadata

def verify_source(bindings, deadline):
    summaries=[]
    for item in bindings["source_roots"]:
        root=r.native_path(item["root"])
        r.require(time.monotonic()<deadline,"source observation deadline")
        expected=r.validate_rows(item["files"])
        # Files and tracked directories are an exact physical snapshot, excluding .git.
        actual=r.inventory(root,deadline,exclude_git=True)
        r.require(r.validate_rows(actual)==expected,"physical source input changed")
        for row in item["git_control"]: r.reference(row)
        summaries.append(dict(root=str(root),files=len(expected),commit=item["commit"],tree=item["tree"]))
    r.require(summaries[0]["commit"]==r.SOURCE_HEAD and summaries[0]["tree"]==r.SOURCE_TREE,"tested clone source")
    return summaries

def check_binding_files(plan, directory):
    raw=r.read(directory/"bindings.json")
    r.require(r.sha(raw)==plan["bindings_sha256"],"binding digest")
    b=r.decode(raw)
    r.require(b["root_marker"]["path"]==str(r.ROOT/".facman-linux-execution-root.v2.json") and
              b["namespace_marker"]["path"]==str(r.ROOT.parent/".facman-development-namespace.v1.json"),
              "marker references must name the actual original Linux markers")
    r.require(b["schema"]=="facman.linux_installed_sdk_bindings.v1" and b["complete"] is True,"complete bindings")
    for key in ("build_handoff","retention_audit","fixture_audit","install_script_review"):
        value=r.decode(r.reference(b[key]))
        r.require(value["result"].startswith("PASS"),"required independent input "+key)
    # The final reviewed binding explicitly attributes these receipts. Status alone is never custody.
    for key in ("source_commit","source_tree"):
        r.require(b[key]==plan[key],"binding/source mismatch")
    r.require(b["build_provider_mode"]=="source" and b["build_provider_linkage"]=="shared","producer linkage")
    r.require(b["source_roots"][0]["root"]==plan["source_root"],"same-checkpoint helper clone")
    for item in b["source_roots"]:
        r.require(len(item["files"])<=10000,"source file count")
    r.require(1<=len(b["system_library_dirs"])<=8 and all(
        isinstance(x,str) and x.startswith("/usr/lib/") and ":" not in x and ".." not in Path(x).parts
        for x in b["system_library_dirs"]),"explicit nonempty canonical system library search")
    for ref in b["tool_inputs"]+b["install_scripts"]+b["preserved_receipts"]: r.reference(ref)
    tools={x["path"] for x in b["tool_inputs"]}
    r.require({"/usr/bin/python3.12","/usr/bin/cmake","/usr/bin/findmnt",b["readelf"],b["loader"]}<=tools,"tool byte custody")
    r.require(b["readelf"].startswith("/usr/bin/") and b["loader"].startswith("/usr/lib/"),"read-only tool scope")
    r.require(1<=len(b["elf_objects"])<=16,"bounded SDK ELF map")
    for item in b["elf_objects"]:
        r.safe_relative(item["build_relative"]);r.safe_relative(item["installed_relative"])
        r.require(item["build_relative"].startswith("native/") and item["installed_relative"].startswith("lib/"),
                  "build/installed ELF paths")
        r.require(item["install_transform"] in ("copy","generated_cmake_rpath"),"explicit install transform")
    r.fixture_link_reference(b["fixture_inventory"])
    r.validate_rows(b["original_root_inventory"])
    original={x["path"]:x for x in b["original_root_inventory"]}
    r.require(not any(n=="sdk-parent" or n.startswith("sdk-parent/") or n==".sdk-run-owner.v1.json"
                      for n in original),"original SDK effects absent")
    b["original_root_inventory"]=list(original.values())
    return b

def marker_guard(plan,b,handles):
    root=Path(plan["root"]); base=root.parent
    for path,key,mode in ((base,"base",0o711),(root,"root",0o711)):
        current=r.plain(path).stat(); held=os.fstat(handles[key])
        r.require(stat.S_ISDIR(current.st_mode) and current.st_uid==current.st_gid==0 and
                  stat.S_IMODE(current.st_mode)==mode and
                  (current.st_dev,current.st_ino)==(held.st_dev,held.st_ino),"held original root changed")
    for key in ("root_marker","namespace_marker"):
        r.reference(b[key]); info=Path(b[key]["path"]).lstat()
        r.require(info.st_uid==info.st_gid==0 and stat.S_IMODE(info.st_mode)==0o400,"root-owned immutable marker mode")
    if "sdk" in handles:
        current=r.plain(root/"sdk-parent").stat();held=os.fstat(handles["sdk"])
        r.require((current.st_dev,current.st_ino)==(held.st_dev,held.st_ino) and
                  current.st_uid==current.st_gid==65534 and stat.S_IMODE(current.st_mode)==0o700,
                  "owned SDK child changed")

def admit_original(plan,b,deadline):
    root=r.plain(plan["root"]);base=r.plain(root.parent)
    handles={}
    try:
        for name,path in (("base",base),("root",root)):
            handles[name]=os.open(path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
        marker_guard(plan,b,handles)
        m=r.decode(r.reference(b["root_marker"]))
        n=r.decode(r.reference(b["namespace_marker"]))
        r.require(m["schema"]=="facman.local-wsl-execution-root.v2" and
                  n["schema"]=="facman.local-wsl-development-namespace.v1","durable marker versions")
        r.require(m["source_commit"]==r.SOURCE_HEAD and m["source_tree"]==r.SOURCE_TREE and
                  m["filesystem_uuid"]==b["filesystem_uuid"]==n["filesystem_uuid"] and
                  b["filesystem_uuid"]=="70d21306-6314-4edd-8ba5-4e3d67d8d625","durable source/filesystem binding")
        info=os.fstat(handles["root"])
        r.require(info.st_ino==m["inode"]==b["root_inode"] and
                  os.fstat(handles["base"]).st_ino==n["inode"]==b["namespace_inode"],"original root/namespace inode")
        # ROOT supplies an independent historical retention audit; each run establishes its own epoch.
        current=r.inventory(root,deadline,preserve_fixture_links=True)
        r.require(current==sorted(b["original_root_inventory"],key=lambda x:x["path"]),"original build/fixture bytes")
        r.require(not os.path.lexists(root/"sdk-parent") and
                  not os.path.lexists(root/".sdk-run-owner.v1.json"),"SDK intent is single-use")
        r.require(os.statvfs(root).f_bavail*os.statvfs(root).f_frsize>=2*r.TREE_CAP,"disk headroom")
        return handles,current
    except BaseException:
        for fd in handles.values():os.close(fd)
        raise

def create_child(root,handles,intent):
    fd=os.open(".sdk-run-owner.v1.json",os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,
               0o400,dir_fd=handles["root"])
    with os.fdopen(fd,"wb") as stream:
        stream.write((json.dumps(intent,sort_keys=True)+"\n").encode());stream.flush();os.fsync(stream.fileno())
    os.fsync(handles["root"])
    os.mkdir("sdk-parent",0o700,dir_fd=handles["root"])
    sdk=os.open("sdk-parent",os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=handles["root"])
    handles["sdk"]=sdk
    os.fchown(sdk,65534,65534);os.fchmod(sdk,0o700)
    for name in ("tmp","home","data","config","cache","state","run"):
        os.mkdir(name,0o700,dir_fd=sdk)
        child=os.open(name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=sdk)
        try:os.fchown(child,65534,65534);os.fchmod(child,0o700)
        finally:os.close(child)
    os.fsync(sdk);os.fsync(handles["root"])

def environment(root,b):
    case=root/"sdk-parent"
    env=dict(PATH="/usr/bin:/bin",LANG="C.UTF-8",LC_ALL="C.UTF-8",HOME=str(case/"home"),
        TMPDIR=str(case/"tmp"),TMP=str(case/"tmp"),TEMP=str(case/"tmp"),
        XDG_DATA_HOME=str(case/"data"),XDG_CONFIG_HOME=str(case/"config"),XDG_CACHE_HOME=str(case/"cache"),
        XDG_STATE_HOME=str(case/"state"),XDG_RUNTIME_DIR=str(case/"run"),
        PYTHONDONTWRITEBYTECODE="1",PYTHONNOUSERSITE="1",CMAKE_BUILD_PARALLEL_LEVEL="4",
        LD_LIBRARY_PATH=":".join(b["system_library_dirs"]),
        DYLD_LIBRARY_PATH=":".join(b["system_library_dirs"]),LD_DEBUG="libs,files")
    r.require(all(x for x in env["LD_LIBRARY_PATH"].split(":")),"no empty loader path element")
    return env

def helper_argv(plan):
    source=PurePosixPath(plan["source_root"])
    return ["/usr/bin/python3.12","-I","-B",str(source/"tools/installed_sdk_smoke.py"),
        "--cmake","/usr/bin/cmake","--build-dir",str(r.ROOT/"native"),
        "--source-dir",str(source/"tests/installed_consumer"),"--config","Release",
        "--work-root",plan["work_root"]]

def metadata_oracle(plan,work):
    commands=work/"commands"
    names=["01-install","02-configure","03-build","04-facman_sdk_consumer","05-facman_sdk_legacy_consumer"]
    for name in names:
        value=r.decode(r.read(commands/(name+".json")))
        r.require(value["exit_code"]==0 and "error" not in value,"all actual helper commands passed")
        r.read(commands/(name+".stdout.raw"));r.read(commands/(name+".stderr.raw"))
    stage=work/"relocated-sdk"
    r.require(not os.path.lexists(work/"initial-sdk"),"initial prefix still present after relocation")
    abi=r.decode(r.read(stage/"share/facman/abi/compatibility.v1.json"))
    r.require(abi["flb_abi"]==dict(major=1,minor=3,encoded=65539,oldest_tested_client=65537,
        rule="requested major must match and requested minor must not exceed the runtime minor"),"FLB contract")
    r.require(abi["required_ulk_abi"]==dict(major=1,minor=9,encoded=65545),"ULK ABI contract")
    artifact=r.decode(r.read(stage/"share/facman/manifest/facman-install-artifact-manifest.v1.json"))
    r.require(artifact["sdk"]["flb_abi"]=="1.3" and artifact["sdk"]["required_ulk_abi"]=="1.9","artifact ABI metadata")
    config=r.read(stage/"lib/cmake/FacMan/FacManConfig.cmake").decode()
    for variable,version in (("FacMan_FLB_ABI_VERSION","1.3"),("FacMan_REQUIRED_ULK_ABI_VERSION","1.9")):
        r.require(re.findall(r'(?m)^set\('+variable+r' "([0-9.]+)"\)$',config)==[version],"exported ABI metadata")
    forbidden=[plan["source_root"],str(r.ROOT/"native"),str(work/"initial-sdk")]
    selected=list((stage/"lib/cmake/FacMan").glob("*.cmake"))+[stage/"lib/pkgconfig/facman-flb.pc"]
    r.require(4<=len(selected)<=16,"closed generated export metadata count")
    for file in selected:
        text=r.read(file).decode("utf-8")
        r.require(not any(path in text or path.replace("/","\\") in text for path in forbidden),
                  "actual tested source/build/old-prefix leak")
    stage_rows=r.inventory(stage,time.monotonic()+30)
    manifest=r.read(r.ROOT/"native/install_manifest.txt").decode().splitlines()
    r.require(manifest and len(manifest)<=r.COUNT_CAP and len(manifest)==len(set(manifest)),"install manifest membership")
    observed=[]
    for line in manifest:
        initial=Path(line);r.require(initial.is_absolute() and ".." not in initial.parts and
            initial.is_relative_to(work/"initial-sdk"),"install escaped intended initial prefix")
        destination=stage/initial.relative_to(work/"initial-sdk")
        r.require(os.path.lexists(destination),"manifest output absent after relocation")
        observed.append(destination.relative_to(stage).as_posix())
    actual_members={x["path"] for x in stage_rows if x["kind"] in ("file","symlink")}
    r.require(actual_members==set(observed),"installed members disagree with CMake manifest")
    r.json_new(work.parent/"sdk-metadata-oracle.json",dict(result="PASS",commands=names,
        initial_prefix_absent=True,install_manifest_members=observed,forbidden_prefixes=forbidden))
    return names

def elf_metadata(text):
    needed=re.findall(r"\(NEEDED\).*?\[([^\]]+)\]",text)
    soname=re.findall(r"\(SONAME\).*?\[([^\]]+)\]",text)
    build_id=re.findall(r"Build ID: ([0-9a-f]+)",text)
    r.require(needed and len(soname)<=1 and len(build_id)==1,"ELF metadata incomplete")
    return dict(needed=needed,soname=soname,build_id=build_id)

def loader_rows(text):
    result=[]
    for line in text.splitlines():
        line=line.strip()
        if not line:continue
        if re.fullmatch(r"linux-vdso\.so\.1 \(0x[0-9a-f]+\)",line):continue
        match=re.fullmatch(r"(?:\S+ => )?(/[^\s]+) \(0x[0-9a-f]+\)",line)
        r.require(match is not None,"unsupported/unresolved loader output")
        result.append(match.group(1))
    r.require(result and len(result)<=32,"loader closure count")
    return result

def runtime_oracles(plan,b,work,run):
    stage=work/"relocated-sdk";forbidden=[plan["source_root"],str(r.ROOT/"native"),str(work/"initial-sdk")]
    elf_proofs=[]
    for i,item in enumerate(b["elf_objects"]):
        old=r.ROOT/item["build_relative"];new=stage/item["installed_relative"]
        before=run("elf-build-%02d"%i,[b["readelf"],"-W","-d","-n",str(old)],30)
        after=run("elf-installed-%02d"%i,[b["readelf"],"-W","-d","-n",str(new)],30)
        r.require(elf_metadata(before)==elf_metadata(after),"installed ELF identity metadata mismatch")
        r.require(not any(x in after for x in forbidden),"installed ELF retained forbidden runtime path")
        elf_proofs.append(dict(source=item["build_relative"],installed=item["installed_relative"],
            original_sha256=r.sha(r.read(old)),installed_sha256=r.sha(r.read(new)),
            transform=item["install_transform"],metadata=elf_metadata(after),
            raw_byte_equivalence_claim=False))
    expected={str((stage/x["installed_relative"]).resolve()) for x in b["elf_objects"]}
    consumers=[]
    for index,name in enumerate(("facman_sdk_consumer","facman_sdk_legacy_consumer")):
        binary=work/"consumer-build"/name;r.plain(binary)
        text=run("consumer-loader-%d"%index,[b["loader"],"--list",str(binary)],30,consumer=True)
        loaded={str(r.plain(Path(x).resolve())) for x in loader_rows(text)}
        system_paths=loaded-expected
        r.require(expected<=loaded and all(any(Path(p).is_relative_to(Path(d))
                  for d in b["system_library_dirs"]) for p in system_paths),
                  "SDK dependencies must come from relocated SDK; ordinary host dependencies from system dirs")
        systems=[]
        for path in sorted(system_paths):
            raw=r.read(path);systems.append(dict(path=path,bytes=len(raw),sha256=r.sha(raw),
                status="ordinary host byte observation; no system ownership or hardened loader claim"))
        trace=r.read(work/"commands"/("%02d-"%(index+4)+name+".stderr.raw")).decode()
        actual={str(Path(x.strip()).resolve()) for x in re.findall(r"calling init:\s*([^\r\n]+)",trace)}
        r.require(expected<=actual and actual<=loaded,"actual consumer loader trace incomplete/foreign")
        r.require(not any(x in trace for x in forbidden),"actual consumer searched original source/build/prefix")
        consumers.append(dict(name=name,sha256=r.sha(r.read(binary)),loaded=sorted(loaded),
                              actual_init_paths=sorted(actual),ordinary_system_dependencies=systems))
    r.json_new(work.parent/"sdk-runtime-oracle.json",dict(result="PASS_RELOCATED_CURRENT_LEGACY_CONSUMERS",
        elf=elf_proofs,consumers=consumers,loader_ownership_claim=False,
        installation_attribution="recorded reviewed CMake install transform; raw binary byte equality is not asserted"))

def execute(plan,raw_plan,directory):
    r.require(sys.platform=="linux" and os.getuid()==os.geteuid()==0,"Linux root controller required")
    r.validate_plan(plan);b=check_binding_files(plan,directory)
    start=time.monotonic();deadline=start+plan["bounds"]["command_lane_seconds"]
    output=r.native_path(plan["windows_evidence"]);r.plain(output)
    result=dict(schema="facman.linux_installed_sdk_result.v1",result="FAIL_RETAINED",
        plan_sha256=r.sha(raw_plan),source_commit=r.SOURCE_HEAD,source_tree=r.SOURCE_TREE,
        commands=[],qualification=plan["qualification"],effects_reset=False)
    handles={};quiescent=True;before=None
    try:
        env=environment(r.ROOT,b)
        def monitor():
            if handles: marker_guard(plan,b,handles)
            r.inventory(r.ROOT,deadline,hashes=False,stable=False,preserve_fixture_links=True)
        def run(name,argv,seconds,consumer=False,metadata_only=False):
            nonlocal quiescent
            current_env=dict(metadata.ENVIRONMENT if metadata_only else env)
            if consumer:current_env["LD_LIBRARY_PATH"]=str(Path(plan["work_root"])/"relocated-sdk/lib")+":"+env["LD_LIBRARY_PATH"]
            try:
                value=(metadata.command if metadata_only else proc.command)({},r.ROOT,name,argv,output,deadline,r.ROOT/("sdk-parent" if "sdk" in handles else "native"),
                    environment=current_env,command_seconds=seconds,monitor=monitor)
                result["commands"].append(value)
            except proc.CommandRefusal as error:
                result["commands"].append(error.record)
                quiescent=error.record["quiescence"]["quiescent"]
                raise
            except BaseException:
                quiescent=False
                raise
            return r.read(output/(name+".stdout.raw"),4*1024**2).decode("utf-8")
        def epoch(name):
            boot=Path("/proc/sys/kernel/random/boot_id").read_text().strip()
            value=r.decode(run(name,list(metadata.ARGV),10,metadata_only=True))
            rows=value["filesystems"]
            r.require(len(rows)==1 and rows[0]["fstype"]=="ext4" and
                      rows[0]["uuid"]==b["filesystem_uuid"],"actual durable filesystem UUID")
            r.require(Path("/proc/sys/kernel/random/boot_id").read_text().strip()==boot,"epoch changed")
            return dict(boot_id=boot,filesystem=rows[0],device=Path(plan["root"]).stat().st_dev)
        result["initial_source_observation"]=verify_source(b,deadline)
        result["epoch_before"]=epoch("epoch-before")
        handles,before=admit_original(plan,b,deadline)
        old=next((x for x in before if x["path"]=="native/install_manifest.txt"),None)
        if old:
            raw=r.read(r.ROOT/"native/install_manifest.txt")
            with (output/"install-manifest-before.raw").open("xb") as stream:stream.write(raw)
        result["install_manifest_before"]=old
        intent=dict(schema="facman.local-sdk-run-owner.v1",plan_sha256=r.sha(raw_plan),
            source_commit=r.SOURCE_HEAD,source_tree=r.SOURCE_TREE,root_marker_sha256=b["root_marker"]["sha256"],
            retention="retained on success/failure; no reset authority")
        create_child(r.ROOT,handles,intent);r.json_new(output/"intent.json",intent)
        identity=run("worker-identity",["/usr/bin/python3.12","-I","-B","-c",
            "import os,json;print(json.dumps(dict(uid=os.getuid(),gid=os.getgid(),groups=os.getgroups())))"],30)
        r.require(r.decode(identity)==plan["identity"],"actual worker identity")
        run("installed-sdk",helper_argv(plan),480)
        work=Path(plan["work_root"]);metadata_oracle(plan,work);runtime_oracles(plan,b,work,run)
        result["epoch_after"]=epoch("epoch-after")
        r.require(result["epoch_after"]==result["epoch_before"],"SDK execution epoch changed")
        result["result"]="PASS_INSTALLED_SHARED_SDK_CONSUMPTION_ONLY"
        result["qualification"]=dict(plan["qualification"],installed_shared_sdk_consumption=True)
    except BaseException as error:
        result.update(error=repr(error),traceback=traceback.format_exc())
    finally:
        post=time.monotonic()+plan["bounds"]["post_seconds"]
        try:
            result["final_source_observation"]=dict(status="PASS",rows=verify_source(b,post),
                semantics="sequential observation on success or failure; no source lease")
        except BaseException as error:
            result["final_source_observation"]=dict(status="FAIL",error=repr(error));result["result"]="FAIL_RETAINED"
        result["quiescent"]=quiescent
        if quiescent and before is not None:
            try:
                marker_guard(plan,b,handles)
                after=r.inventory(r.ROOT,post,preserve_fixture_links=True)
                result["original_mutations"]=r.compare_original(before,after)
                r.json_new(output/"root-after.json",after)
                result["export"]=r.export_selected(r.ROOT,output,after,post,quiescent=True)
            except BaseException as error:
                result["post_error"]=repr(error);result["result"]="FAIL_RETAINED"
        else:result["export"]=dict(status="SKIPPED_NOT_QUIESCENT_OR_NOT_ADMITTED",stable_export_attempted=False)
        for fd in reversed(list(handles.values())):
            try:os.close(fd)
            except BaseException as error:result["close_error"]=repr(error);result["result"]="FAIL_RETAINED"
        if not result["result"].startswith("PASS_"):
            result["qualification"]=dict(plan["qualification"])
        result["elapsed_seconds"]=time.monotonic()-start
        r.json_new(output/"linux-result.json",result)
    return result

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan",type=Path,required=True)
    parser.add_argument("--execute",action="store_true")
    parser.add_argument("--approved-plan-sha256")
    args=parser.parse_args();raw=r.read(args.plan);plan=r.decode(raw)
    r.validate_plan(plan,ready=args.execute)
    if not args.execute:
        print(json.dumps(dict(result="PROPOSAL_ONLY",plan_sha256=r.sha(raw),effects=[])));return
    r.require(args.approved_plan_sha256==r.sha(raw),"exact approved plan")
    for name,digest in plan["script_hashes"].items():
        r.require(r.sha(r.read(args.plan.parent/name))==digest,"runner source changed")
    result=execute(plan,raw,args.plan.parent)
    print(json.dumps(dict(result=result["result"])))
    raise SystemExit(0 if result["result"].startswith("PASS_") else 1)

if __name__=="__main__":main()
