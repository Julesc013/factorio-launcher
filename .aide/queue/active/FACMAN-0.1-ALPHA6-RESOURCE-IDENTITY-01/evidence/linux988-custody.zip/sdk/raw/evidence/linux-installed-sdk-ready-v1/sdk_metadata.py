"""Fixed uid0 read-only query; every SDK command remains in sdk_process as uid65534."""
import os
from pathlib import Path
from sdk_records import ROOT
from sdk_process import require,json_new,OUTPUT_CAP,worker_limits,live_group_members,cleanup_command,CommandRefusal
ARGV=["/usr/bin/findmnt","--json","--output","TARGET,SOURCE,FSTYPE,UUID","--target","/var/lib"]
ENVIRONMENT={"PATH":"/usr/bin:/bin","LANG":"C.UTF-8","LC_ALL":"C.UTF-8"}
def command(plan, root, name, argv, logs, overall_deadline, case, *, environment, command_seconds, monitor):
    require(name in ("epoch-before","epoch-after") and root==ROOT and argv==ARGV and environment==ENVIRONMENT and command_seconds==10, "literal metadata-only controller query")
    import selectors, signal, subprocess, time
    require(time.monotonic() < overall_deadline, "overall budget before spawn")
    env = dict(environment)
    require(0 < command_seconds <= 480, "finite SDK command bound")
    streams = {}
    started, reason, counts, process = time.monotonic(), None, {"stdout": 0, "stderr": 0}, None
    selector = None
    cleanup_deadline = None
    spawn_attempted = False
    reaping_started = False
    record = {"name": name, "argv": argv, "cwd": str(case), "environment": env,
              "exit_code": None, "refusal": "spawn not completed"}
    try:
        for key in ("stdout", "stderr"):
            streams[key] = (logs / (name + "." + key + ".raw")).open("xb")
        selector = selectors.DefaultSelector()
        require(time.monotonic() < overall_deadline, "overall budget immediately before spawn")
        spawn_attempted = True
        process = subprocess.Popen(argv, cwd=case, env=env, stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True,
            user=0, group=0, extra_groups=[], preexec_fn=worker_limits)
        leader = process.pid
        # Do not reap leader until all group signaling is complete. Its held zombie
        # prevents PID/group-number reuse during this ordinary cleanup protocol.
        for key in streams:
            pipe = getattr(process, key); os.set_blocking(pipe.fileno(), False)
            selector.register(pipe, selectors.EVENT_READ, key)
        deadline = min(overall_deadline, started + command_seconds)
        exited = False
        while not exited or selector.get_map():
            if time.monotonic() >= deadline:
                reason = "deadline"; break
            try:
                monitor()
            except (OSError, ValueError) as error:
                reason = "fixture bound/observation: " + str(error); break
            for event, _ in selector.select(0.1):
                block = os.read(event.fileobj.fileno(), 65536)
                if not block:
                    selector.unregister(event.fileobj); continue
                key = event.data; room = OUTPUT_CAP - counts[key]
                streams[key].write(block[:room]); counts[key] += min(room, len(block))
                if len(block) > room: reason = "output limit"
            if reason: break
            exited = os.waitid(os.P_PID, leader, os.WEXITED | os.WNOHANG | os.WNOWAIT) is not None
            if exited and selector.get_map():
                # Pipes held by descendants get a finite drain window.
                deadline = min(deadline, time.monotonic() + 1)
        # Kill only this still-owned session/process-group. This cannot account for
        # a deliberately escaped session; such suites are excluded from this lane.
        cleanup_deadline = time.monotonic() + 5
        try: os.killpg(leader, signal.SIGTERM)
        except ProcessLookupError: pass
        finish = min(cleanup_deadline, time.monotonic() + 1)
        while time.monotonic() < finish and selector.get_map():
            for event, _ in selector.select(0.05):
                block = os.read(event.fileobj.fileno(), 65536)
                if not block: selector.unregister(event.fileobj); continue
                key = event.data; room = OUTPUT_CAP - counts[key]
                streams[key].write(block[:room]); counts[key] += min(room, len(block))
                if len(block) > room and reason is None: reason = "output limit"
        try: os.killpg(leader, signal.SIGKILL)
        except ProcessLookupError: pass
        group_deadline = min(cleanup_deadline, time.monotonic() + 3)
        remaining = live_group_members(leader)
        while remaining and time.monotonic() < group_deadline:
            time.sleep(0.05)
            remaining = live_group_members(leader)
        if remaining: reason = reason or "owned group did not stop within cleanup budget"
        # Once waiting can reap the leader, its numeric group is no longer safe
        # to signal if returncode publication is interrupted. Retain uncertainty.
        reaping_started = True
        exit_code = process.wait(timeout=max(0, min(1, cleanup_deadline - time.monotonic())))
        record = {"name": name, "argv": argv, "cwd": str(case), "environment": env,
                  "pid": leader, "pgid": leader, "exit_code": exit_code, "refusal": reason,
                  "group_empty_observed": not remaining,
                  "seconds": time.monotonic()-started, "stream_bytes": counts,
                  "session_escape_containment_qualified": False}
    except BaseException as caught:
        record.update(refusal=reason or repr(caught), command_error=repr(caught),
                      seconds=time.monotonic()-started, stream_bytes=counts,
                      spawn_pid=None if process is None else process.pid)
    finally:
        cleanup = cleanup_command(process, selector, streams, cleanup_deadline,
                                  record.get("group_empty_observed"), spawn_attempted, reaping_started)
        record["cleanup_errors"] = cleanup["errors"]
        record["quiescence"] = {key: value for key, value in cleanup.items() if key != "errors"}
        record["stream_bytes"] = counts
        # Even a failed cleanup leaves the original error and a command receipt.
        json_new(logs / (name + ".json"), record)
    if not (record["exit_code"] == 0 and record["refusal"] is None
            and not cleanup["errors"] and cleanup["quiescent"]):
        raise CommandRefusal(record)
    return record

