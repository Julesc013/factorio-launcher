"""Proposed Windows entry point. Refuses all unresolved plans before effects."""
from __future__ import annotations
import argparse, os, sys, time, traceback
from pathlib import Path
import sdk_records as r

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan",type=Path,required=True)
    parser.add_argument("--review",type=Path,required=True)
    parser.add_argument("--review-sha256",required=True)
    args=parser.parse_args()
    raw=r.read(args.plan);plan=r.decode(raw);r.validate_plan(plan)
    review_raw=r.read(args.review)
    r.require(r.sha(review_raw)==args.review_sha256,"review receipt custody")
    review=r.decode(review_raw)
    r.require(review["result"].startswith("PASS") and review["plan_sha256"]==r.sha(raw) and
              review["effect_execution_approved"] is True,"ROOT exact effect review required")
    for name,digest in plan["script_hashes"].items():
        r.require(r.sha(r.read(args.plan.parent/name))==digest,"frozen runner source")
    bound_raw=r.read(args.plan.parent/"bindings.json")
    r.require(r.sha(bound_raw)==plan["bindings_sha256"],"final binding custody")
    bindings=r.decode(bound_raw)
    r.require(bindings["complete"] is True,"unresolved build/retention bindings")
    for name in ("build_handoff","retention_audit","fixture_audit","install_script_review"):
        r.reference(bindings[name])
    r.reference(bindings["windows_owner_marker"])
    for ref in bindings["windows_supervisor_inputs"]:r.reference(ref)
    supervisor=Path(bindings["windows_supervisor_root"])
    expected={str(supervisor/"tools/provider_canary_process.py"),
              str(supervisor/"tools/provider_canary_process_windows.py")}
    r.require({x["path"] for x in bindings["windows_supervisor_inputs"]}==expected,
              "exact existing supervisor files")
    output=Path(plan["windows_evidence"])
    task=Path(plan["windows_task"])
    r.plain(task);r.plain(output.parent)
    r.require(output.parent==task/"evidence" and not os.path.lexists(output),"fresh owned evidence")
    r.require(os.name=="nt","interactive Windows controller only")
    sys.path.insert(0,str(supervisor))
    from tools import provider_canary_process as bounded
    output.mkdir()
    start=time.monotonic();result=dict(result="FAIL_RETAINED",plan_sha256=r.sha(raw),
        review_sha256=args.review_sha256,source_commit=r.SOURCE_HEAD,source_tree=r.SOURCE_TREE)
    try:
        linux_plan="/mnt/"+args.plan.drive[0].lower()+"/"+"/".join(args.plan.parts[1:])
        linux_runner=str(Path(linux_plan).parent/"linux_sdk.py").replace("\\","/")
        cmd=["wsl.exe","-d","Ubuntu-24.04","--exec","/usr/bin/timeout",
            "--signal=TERM","--kill-after=10","810","/usr/bin/python3.12","-B",
            linux_runner,"--plan",linux_plan,"--execute","--approved-plan-sha256",r.sha(raw)]
        value=bounded.command(cmd,cwd=supervisor,environment=dict(os.environ,PYTHONDONTWRITEBYTECODE="1"),
            timeout=plan["bounds"]["outer_seconds"],directory=output/"wsl-sdk",
            output_limit=plan["bounds"]["stream_bytes"])
        result["command_receipt"]=dict(path=str(value.directory/"receipt.json"),
            sha256=r.sha(r.read(value.directory/"receipt.json")))
        bounded.require(value)
        closed=r.decode(r.read(output/"linux-result.json"))
        r.require(closed["result"]=="PASS_INSTALLED_SHARED_SDK_CONSUMPTION_ONLY" and
                  closed["quiescent"] is True and closed["plan_sha256"]==r.sha(raw),
                  "SDK run lacks closed proof")
        result["result"]=closed["result"]
    except BaseException as error:
        result.update(error=repr(error),traceback=traceback.format_exc(),
                      stable_output_claim=False,reset_performed=False)
    finally:
        # This receipt reports supervisor outcome. It does not bless growing Linux artifacts.
        try:
            for ref in bindings["windows_supervisor_inputs"]:r.reference(ref)
            result["final_control_observation"]={"status":"PASS"}
        except BaseException as error:
            result.update(result="FAIL_RETAINED",stable_output_claim=False,
                final_control_observation={"status":"FAIL","error":repr(error)})
        finally:
            result["elapsed_seconds"]=time.monotonic()-start
            r.json_new(output/"windows-result.json",result)
            print(__import__("json").dumps(result))
    raise SystemExit(0 if result["result"].startswith("PASS_") else 1)

if __name__=="__main__":main()
