
import hashlib,json,os,re,stat,sys,zipfile
from datetime import datetime,timezone
from pathlib import Path
E=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-d9fce3b03d\evidence')
S=E/'linux-namespace-v2-actual-seal'
R=E/'linux-namespace-ready-v2/ready-9aa5e27d1b024191ac09fdabc5f13003'
P=E/'linux-namespace-successor-export-ready-v1'
A=E/'linux-namespace-host-9aa5e27d1b024191ac09fdabc5f13003'
B=E/'linux-namespace-export-90b5719cb1d545e382ef8185272257a4'
C=E/'linux-namespace-export-controller-90b5719cb1d545e382ef8185272257a4'
N=E/'linux-pid-namespace-controls-source-v2';H=E/'linux-pid-namespace-controls-controller-v3';X=E/'linux-namespace-closed-export-source-v2'
old=E/'linux-namespace-failed-actual-seal'
S.mkdir()
observed={}
def read(p):
    p=Path(p);before=p.lstat()
    assert stat.S_ISREG(before.st_mode) and not getattr(before,'st_file_attributes',0)&0x400,('plain file',p)
    raw=p.read_bytes();after=p.lstat()
    assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
    observed[str(p)]=raw;return raw
def j(p):return json.loads(read(p))
def desc(p):
    raw=read(p);return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def bound(row):
    p=Path(row['path']);raw=read(p)
    assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'],('reference',p)
    return raw
def put(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
try:
    ns=j(R/'namespace-plan.json');host=j(R/'host-plan.json');ep=j(P/'plan.json')
    assert desc(R/'namespace-plan.json')['sha256']=='4907053de3002ed1a038c2303cddc4f1a03f4ccd9e2d9877d99ca455629c394e'
    assert desc(R/'host-plan.json')['sha256']=='3408d325953722f32ac3c1162f9f65952544c0e65030c483cdc3438ca392d71e'
    assert desc(P/'plan.json')['sha256']=='b89ccc83f1fa772ac2535d3b1cef1211f2ff987828c005ad71418502850c5b4a'
    source_files=[]
    for directory,digest in [(N,'f22db3e255b2a5c31cf0ed872e70bdd1362051d54b042f79d028d2a930426dc5'),(H,'505837600e2ceb7d2b757d1fdc690f782ba42dac510985e6d168d04ba14b9ea0'),(X,'dc7e3123fcf6b9743b85032ab1c33f9531fce6917a6699bb9165ae961e15d9f8')]:
        review=j(directory/'root-source-review.json');assert desc(directory/'root-source-review.json')['sha256']==digest
        packet=j(directory/'source-packet.json')
        for row in packet['source_files']:bound(row);source_files.append(row)
        assert review['result'].startswith('PASS') and not review['effect_execution_approved']
    for name,digest in ns['script_hashes'].items():assert desc(N/name)['sha256']==digest
    for name,digest in host['script_hashes'].items():assert desc(H/name)['sha256']==digest
    for name,digest in ep['source_hashes'].items():assert desc(X/name)['sha256']==digest
    b=j(R/'bindings.json');assert desc(R/'bindings.json')['sha256']==ns['bindings_sha256']
    for row in b['source_inputs']+b['preserved_inputs']:bound(row)
    before=j(old/'complete-root-after.json');assert len(before)==2905
    assert desc(old/'complete-root-after.json')['sha256']=='ae923ec7ea46d005fac87f60fa3af4d5ff47ef92730f4dae9b05dd81885f7dce'
    assert before==b['original_root_inventory']
    prior_review=j(old/'root-actual-review.json');assert prior_review['namespace_result']=='FAIL_RETAINED'
    bound(prior_review['originals']);bound(prior_review['custody'])
    nreview=j(R/'root-namespace-effect-review.json');hreview=j(R/'root-host-effect-review.json');ereview=j(P/'root-effect-review.json')
    assert nreview['plan_sha256']==desc(R/'namespace-plan.json')['sha256'] and nreview['effect_execution_approved']
    assert hreview['plan_sha256']==desc(R/'host-plan.json')['sha256'] and hreview['execution_authorized'] and hreview['result']=='PASS_EXACT_EFFECT'
    assert ereview['plan_sha256']==desc(P/'plan.json')['sha256'] and ereview['execution_authorized'] and ereview['result']=='PASS_EXACT_EXPORT'
    assert desc(R/'root-namespace-effect-review.json')['sha256']==host['namespace_effect_review']['sha256']
    ar=j(A/'result.json');er=j(B/'result.json');cr=j(C/'result.json')
    assert desc(A/'result.json')['sha256']=='0d3d28d1c24ee94ecf2b360b0c68812c15c365dca0408a39eb144b790a376a50'
    assert ar['result']=='GUARDIAN_REPORTED_PASS_AUDIT_PENDING' and not ar['qualification']
    assert cr['result']=='EXPORTED_ORIGINALS_AUDIT_PENDING' and cr['archive_complete'] and not cr['qualification']
    assert er['result']=='PASS_CLOSED_CONTROL_EVIDENCE_EXPORT' and er['archive_complete'] and not er['close_errors'] and not er['qualification']
    assert er['namespace_plan_sha256']==desc(R/'namespace-plan.json')['sha256'] and er['export_plan_sha256']==desc(P/'plan.json')['sha256']
    for row in [ep[k] for k in ['before_root_map','bindings','host_plan','host_result','namespace_plan']]:bound(row)
    for output,result,wanted in [(A,ar,265),(C,cr,120)]:
        command=j(output/'command/receipt.json');assert command==result['host_receipt']
        assert command['exit_code']==0 and command['termination']=='completed' and command['primary_stopped'] and command['job_empty_observed'] and command['job_terminated']
        assert command['error'] is None and command['elapsed_seconds']<=wanted+5
        for key in ['stdout','stderr']:
            raw=read(output/'command'/command[key]['file'])
            assert len(raw)==command[key]['captured_bytes'] and hashlib.sha256(raw).hexdigest()==command[key]['sha256']
        assert json.loads(read(output/'command/stdout.raw'))==j(output/'response.json')
    assert j(A/'response.json')==dict(result='PASS_SYNTHETIC_NAMESPACE_CONTROLS_ONLY')
    assert j(C/'response.json')==er
    for folder,plan,review,result in [(R,host,hreview,ar),(P,ep,ereview,cr)]:
        invocation=j(folder/'invocation-once/result.json')
        assert invocation['identity']=='BLACKGLASS-WIN1\\Jules' and invocation['exit_code']==0 and invocation['automatic_retries']==0
        assert datetime.fromisoformat(invocation['ended_at']).timestamp()<plan['expires_at']
        assert invocation['plan_sha256']==result['plan_sha256']
        for key in ['stdout.raw','stderr.raw']:
            raw=read(folder/'invocation-once'/key);record=invocation[key]
            assert len(raw)==record['bytes'] and hashlib.sha256(raw).hexdigest()==record['sha256']
        assert json.loads(read(folder/'invocation-once/stdout.raw'))==result
    archive=B/'control-evidence.zip';raw=read(archive)
    assert len(raw)==er['archive']['bytes']==781818 and hashlib.sha256(raw).hexdigest()==er['archive']['sha256']=='4022b69a8591445b7ae876acc5a15eede05da11bbe2d25d5a3fe8f9c34d85a9d'
    CASES=['normal','setsid_orphan','held_stdout_ignore_term','worker_timeout','init_sigkill','unshare_sigkill','case_controller_sigkill','proc_mount_refusal']
    allowed={'.process-controls-intent.v2.json','process-controls-v2/result.json','process-controls-v2/root-after.json','process-controls-v2/proc_mount_refusal/not-a-directory'}|{'process-controls-v2/'+case+'/'+name for case in CASES for name in ['stdout.raw','stderr.raw','result.json']}
    files={row['path']:row for row in er['files']};roster={row['path']:row for row in er['roster']}
    assert len(files)==28 and len(roster)==78 and len(files)==len(er['files']) and len(roster)==len(er['roster'])
    assert set(files)==allowed
    extracted=[]
    with zipfile.ZipFile(archive) as z:
        assert len(z.infolist())==28 and set(z.namelist())==allowed
        data={}
        for name in sorted(allowed):
            raw=z.read(name);row=files[name];assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
            assert {k:v for k,v in row.items() if k!='sha256'}==roster[name]
            path=S/'exported-originals'/name;path.parent.mkdir(parents=True,exist_ok=True)
            with path.open('xb') as f:f.write(raw)
            extracted.append(dict(archive_member=name,export_metadata=row,local_file=dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())))
            data[name]=raw
    full=json.loads(data['process-controls-v2/result.json']);snapshot=json.loads(data['process-controls-v2/root-after.json']);intent=json.loads(data['.process-controls-intent.v2.json'])
    assert full['plan_sha256']==er['namespace_plan_sha256']==intent['plan_sha256']
    assert intent==dict(schema='facman.process_controls_intent.v1',plan_sha256=full['plan_sha256'],retained=True,automatic_cleanup=False)
    assert full['result']=='PASS_SYNTHETIC_NAMESPACE_CONTROLS_ONLY' and full['qualification'] and full['quiescent'] and not full['native_fixtures_executed']
    assert full['elapsed_seconds']<240 and [r['case'] for r in full['cases']]==CASES
    outcomes={'normal':(0,'normal'),'setsid_orphan':(0,'orphan_retained_until_init_exit'),'held_stdout_ignore_term':(42,'deadline'),'worker_timeout':(42,'deadline'),'init_sigkill':(70,None),'unshare_sigkill':(247,None),'case_controller_sigkill':(-9,None),'proc_mount_refusal':(1,None)}
    nonces=set()
    for record in full['cases']:
        case=record['case'];assert record==json.loads(data['process-controls-v2/'+case+'/result.json'])
        assert record['result']=='PASS_SYNTHETIC_CONTROL_ONLY' and not record.get('error') and not record.get('close_errors')
        assert record['cleanup']==dict(all_registered_handles_exited=True,errors=[],quiescent=True,scope_accounted=True)
        assert record['sentinel_alive'] and record['mountinfo_unchanged'] and record['elapsed_seconds']<30
        assert (record['controller_exit'],record['init_outcome'])==outcomes[case]
        assert re.fullmatch('[0-9a-f]{32}',record['nonce']) and record['nonce'] not in nonces;nonces.add(record['nonce'])
        expected={'unshare'} if case=='proc_mount_refusal' else {'init','unshare','worker'}|({'orphan','session'} if case=='setsid_orphan' else {'orphan'} if case=='held_stdout_ignore_term' else set())
        assert set(record['roles'])==expected
        assert record['armed']==record['trigger_sent']==record['terminated_before_cleanup']==(case!='proc_mount_refusal')
        for key in ['stdout','stderr']:assert len(data['process-controls-v2/'+case+'/'+key+'.raw'])==record['streams'][key]['captured_bytes']
    assert full['cases'][6]['expected_controller_peer_reset']=="ConnectionResetError(104, 'Connection reset by peer')"
    assert b'ConnectionResetError' in data['process-controls-v2/init_sigkill/stderr.raw']
    assert data['process-controls-v2/proc_mount_refusal/stderr.raw']==b'unshare: mount /var/lib/facman-development/lp9-20260907-01/process-controls-v2/proc_mount_refusal/not-a-directory failed: Not a directory\n'
    sentinel=full['sentinel_identity'];assert sentinel['uid']==sentinel['gid']==[65534]*4 and sentinel['groups']==[] and sentinel['no_new_privs']==1 and all(int(v,16)==0 for v in sentinel['caps'].values())
    assert full['sentinel_cleanup']==dict(all_registered_handles_exited=True,errors=[],quiescent=True)
    epochs=[]
    for folder,name,wanted in [(A/'metadata','epoch-before',full['current_epoch']),(A/'metadata','epoch-after',full['final_epoch']),(B,'epoch-before',None)]:
        value=j(folder/(name+'.json'));assert wanted is None or value==wanted
        assert value['result']=='PASS_CURRENT_EPOCH_OBSERVATION' and value['qualification'] and value['terminated_before_cleanup']
        assert value['uid']==value['gid']==0 and value['groups']==[] and value['exit_code']==0 and not value['close_errors']
        assert value['cleanup']==dict(all_registered_handles_exited=True,errors=[],quiescent=True)
        assert value['argv']==['/usr/bin/findmnt','--json','--output','TARGET,SOURCE,FSTYPE,UUID','--target','/var/lib']
        stdout=read(folder/(name+'.stdout.raw'));stderr=read(folder/(name+'.stderr.raw'))
        assert len(stdout)==value['streams']['stdout']['captured_bytes'] and len(stderr)==value['streams']['stderr']['captured_bytes']==0
        filesystem=json.loads(stdout)['filesystems'];assert filesystem==[value['filesystem']]
        assert value['filesystem_uuid']=='70d21306-6314-4edd-8ba5-4e3d67d8d625' and value['elapsed_seconds']<15
        epochs.append(value)
    assert (epochs[0]['boot_id'],epochs[0]['device'],epochs[0]['filesystem_uuid'])==(epochs[1]['boot_id'],epochs[1]['device'],epochs[1]['filesystem_uuid'])
    prior={r['path']:r for r in before};snap={r['path']:r for r in snapshot};assert len(snap)==len(snapshot)==2981
    assert all(snap.get(name)==row for name,row in prior.items())
    finals={'process-controls-v2/result.json','process-controls-v2/root-after.json'}
    assert not finals&snap.keys()
    additions={}
    for name,row in roster.items():
        assert name not in prior
        projected={k:row[k] for k in ['path','kind','mode','uid','gid']}
        if row['kind']=='file':projected.update(bytes=row['bytes'],sha256=files[name]['sha256'])
        else:assert row['kind']=='directory'
        additions[name]=projected
        if name not in finals:assert snap[name]==projected
    assert set(snap)-set(prior)==set(additions)-finals
    complete=sorted([*prior.values(),*additions.values()],key=lambda r:r['path']);assert len(complete)==2983
    put(S/'complete-root-after.json',complete)
    put(S/'exported-members.json',extracted)
    put(S/'case-facts.json',dict(result='PASS_RECORDED_EIGHT_SYNTHETIC_CONTROLS',cases=full['cases'],sentinel_identity=sentinel,epochs=epochs,namespace_elapsed_seconds=full['elapsed_seconds'],raw_pidfd_event_stream_available=False,raw_namespace_census_listing_available=False,proof_basis='Frozen source enforces pidfd exits and namespace empty census before setting terminated_before_cleanup; original per-case records retain the resulting assertions. No independent live replay or invented event trace.'))
    for folder in [A,B,C,R,P]:
        for path in sorted(folder.rglob('*')):
            if path.is_file():read(path)
    for p in [old/'root-actual-review.json',old/'complete-root-after.json']:read(p)
    # Exact present bytes must still agree before sealing closed original streams.
    for name,raw in observed.items():assert Path(name).read_bytes()==raw,('changed after audit',name)
    originals=sorted(observed)
    members=[]
    with zipfile.ZipFile(S/'originals.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
        for index,name in enumerate(originals):
            p=Path(name);member='originals/'+str(index).zfill(3)+'-'+p.name;raw=observed[name];z.writestr(member,raw)
            members.append(dict(path=name,archive_member=member,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
    with zipfile.ZipFile(S/'originals.zip') as z:
        assert len(z.infolist())==len(members)
        for row in members:
            raw=z.read(row['archive_member']);assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
    put(S/'custody.json',dict(originals=members,archive=desc(S/'originals.zip'),exported_members=desc(S/'exported-members.json'),raw_bytes_preserved=True,source_files=source_files))
    facts=dict(result='PASS_RECORDED_EIGHT_SYNTHETIC_NAMESPACE_CONTROLS',namespace_request_id=host['request_id'],export_request_id=ep['request_id'],case_count=8,passing_cases=CASES,
        namespace_result=full['result'],namespace_quiescent=True,source_files_verified=len(source_files),
        export=desc(archive),exported_regular_members=28,actual_export_roster_rows=78,prior_rows_preserved=2905,guardian_prefinal_rows=2981,
        complete_root_after=desc(S/'complete-root-after.json'),complete_observed_union_rows=2983,
        complete_map_canonical_sha256=hashlib.sha256(json.dumps(complete,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
        canonical_definition='UTF8 compact sorted-key JSON, ensure_ascii=True, no trailing newline',
        map_basis='Actual source-bound whole-root snapshot preserves all 2905 original rows; actual export roster matches 76 overlapping additions and supplies the two final result/map files. No new Linux sweep or inferred metadata.',
        original_failed_v1_preserved=True,previous_failure_review=desc(old/'root-actual-review.json'),original_host_results_unmodified=True,
        original_archive=desc(S/'originals.zip'),original_member_count=len(members),custody=desc(S/'custody.json'),case_facts=desc(S/'case-facts.json'),
        actual_audit_linux_reads=0,actual_audit_replays=0,
        proof_ceiling='Source-bound recorded eight synthetic assertions and exact exported custody. No per-pidfd event stream/raw census snapshot was serialized; no product/native/SDK/hostile isolation/pre-arm/guardian-loss/release qualification.',
        repeated_export_observation_basis='Audited frozen exporter repeats roster and hashes before completing; this audit independently verifies its closed outputs and every archive member, without another live Linux read.',
        recorded_at=datetime.now(timezone.utc).isoformat())
    put(S/'independent-actual-review.json',facts)
    print(json.dumps(dict(review=desc(S/'independent-actual-review.json'),map=desc(S/'complete-root-after.json'),canonical=facts['complete_map_canonical_sha256'],originals=facts['original_archive'],original_count=len(members),case_count=8,roster_rows=78)))
except BaseException as error:
    import traceback
    put(S/'audit-failure.json',dict(result='AUDIT_REFUSED',error=repr(error),traceback=traceback.format_exc(),linux_effects=False))
    raise
