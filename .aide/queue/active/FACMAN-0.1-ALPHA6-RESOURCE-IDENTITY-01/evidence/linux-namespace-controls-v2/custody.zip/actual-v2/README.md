# Independent audit of namespace controls v2

All eight recorded synthetic controls passed. The independently checked archive contains 28 byte-exact regular originals and a 78-row actual export roster. The complete observed union has 2,983 rows: every prior 2,905 row is unchanged, the guardian pre-final snapshot contributes 76 matching new rows, and the export supplies the actual final result and root-after files. Their Linux metadata is preserved separately; the canonical whole-root map uses the established path/kind/mode/owner/size/hash projection.

The controller-kill case retains ConnectionResetError 104 as an expected EOF, controller exit -9, armed/triggered state and terminated_before_cleanup=true. The first seven cases require registered pidfd exits and an empty namespace census before that flag can be set in the frozen reviewed source. The mount-refusal case instead records only unshare, exit1, no armed worker and the exact expected stderr. All cases preserve sentinel-alive and unchanged-mount assertions and accounted quiescent cleanup. Three original metadata receipts and their raw stdout/stderr are bound; the namespace run's before/after boot, device and UUID agree.

These are source-bound original result assertions. No separate per-pidfd event stream, raw census listing or raw mountinfo snapshot was serialized, so none is invented. The exporter is source-bound to repeated roster/hash observations before completing. This Windows-only audit independently checks its closed archive and all members; it does not claim a third live Linux observation.

The first namespace run remains failed and its complete original custody/archive/map are preserved in the new seal. Its six passing assertions, failed seventh and unattempted eighth are not rewritten by v2. The existing Windows host reports remain audit-pending originals.

The main audit sealed 18 namespace/host/exporter runtime-and-test source files. The separate supplement additionally binds both unchanged Windows supervisor source files. audit-tool-payload.py preserves the Python source of the actual review tool payload; the shell's stdin transport bytes were not separately captured and no claim of exact stdin transport is made.

This result qualifies only the eight fixed synthetic controls and their retained custody. It grants no native product-test delegation, SDK/product/hostile-isolation/pre-arm/guardian-loss/hosted/release qualification. No Linux read, test replay, repository, queue, Git or public mutation occurred in this audit.
