from pathlib import Path
import ctypes,datetime,hashlib,json,os,subprocess,sys,time
D=Path(r"C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-d9fce3b03d\evidence\linux-continuation-final-inventory-candidate-v1")
P=D/'effect-proposal-f689d8579b144642ac10118a293fddb2'
SHA='64bd253ac9c49720b6ddf41de0b8feaee3865cb31cc5ab09dadef236dcfcfb20'
def digest(raw):return hashlib.sha256(raw).hexdigest()
def ref(p):
 raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=digest(raw))
def new(path,value):
 with path.open('xb') as f:f.write((json.dumps(value,indent=2,sort_keys=True)+'\n').encode());f.flush();os.fsync(f.fileno())
source=P/'invocation.json';raw=source.read_bytes();assert digest(raw)=='ac5f8736da3680d3934808a4870cdb41c43c888dc02f314852852aace0684c11'
proposal=json.loads(raw);review=Path(proposal['expected_review_path']);assert digest(review.read_bytes())==SHA
assert ref(Path(proposal['plan']['path']))==proposal['plan'];assert ref(Path(proposal['interpreter']['path']))==proposal['interpreter']
argv=list(proposal['argv']);assert argv[-1]=='ROOT_REVIEW_SHA256_TO_BE_BOUND_AFTER_REVIEW';argv[-1]=SHA
assert Path(sys.executable)==Path(argv[0]);plan=json.loads(Path(proposal['plan']['path']).read_bytes());assert time.time()+30<plan['expires_at']
lib=ctypes.WinDLL('secur32',use_last_error=True);fn=lib.GetUserNameExW;fn.argtypes=[ctypes.c_int,ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_ulong)];fn.restype=ctypes.c_bool
buf=ctypes.create_unicode_buffer(512);size=ctypes.c_ulong(512);assert fn(2,buf,ctypes.byref(size));assert buf.value.casefold()==r'BLACKGLASS-WIN1\Jules'.casefold()
out=P/'invocation-once';out.mkdir()
started=time.time();mono=time.monotonic();record=dict(schema='facman.final_inventory_once_invocation.v1',result='DISPATCH_OUTCOME_UNKNOWN',proposal=ref(source),review=ref(review),plan=proposal['plan'],argv=argv,identity=buf.value,environment_overrides=proposal['environment'],cwd=proposal['cwd'],started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),started_unix=started,exit_code=None,retries=0)
new(out/'intent.json',record)
env=dict(os.environ,**proposal['environment'])
with (out/'stdout.raw').open('xb') as stdout,(out/'stderr.raw').open('xb') as stderr:
 try:
  proc=subprocess.Popen(argv,cwd=proposal['cwd'],env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
  record['pid']=proc.pid;print(json.dumps(dict(state='DISPATCHED_ONCE',pid=proc.pid,request_id=plan['request_id'],invocation=str(out))),flush=True)
  record['exit_code']=proc.wait(timeout=270);record['result']='PROCESS_CLOSED'
 except subprocess.TimeoutExpired:
  record['result']='OUTER_DEADLINE_UNKNOWN';proc.kill()
  try:record['exit_code']=proc.wait(timeout=5)
  except BaseException as error:record['close_error']=repr(error)
 except BaseException as error:record.update(result='INVOCATION_ERROR_UNKNOWN',error=repr(error))
 finally:
  stdout.flush();stderr.flush();os.fsync(stdout.fileno());os.fsync(stderr.fileno())
record.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-mono,stdout=ref(out/'stdout.raw'),stderr=ref(out/'stderr.raw'))
new(out/'result.json',record);print(json.dumps(dict(result=record['result'],exit_code=record['exit_code'],elapsed_seconds=record['elapsed_seconds'],receipt=ref(out/'result.json'))),flush=True)
