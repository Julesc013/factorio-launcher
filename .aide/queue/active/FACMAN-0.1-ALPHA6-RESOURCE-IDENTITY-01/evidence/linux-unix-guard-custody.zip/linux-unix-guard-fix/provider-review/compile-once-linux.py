import hashlib,json,os,signal,subprocess,time,traceback,shlex
from pathlib import Path
D=Path(__file__).resolve().parent;P=D/'compile-plan.json';plan=json.loads(P.read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(D/'fixed.cpp')==plan['source_raw_sha256']
S=Path('/mnt/c/'+plan['old_source']['root'][3:].replace(chr(92),'/'));inputs={x['path']:x for x in plan['old_source']['files']}
def controls():
 return {n:sha(S/n) for n in plan['old_source']['control']}
before=controls();assert before==plan['old_source']['control']
for name,row in inputs.items():
 if name.endswith(('.h','.hpp','.inc')):assert sha(S/name)==row['raw_sha256']
env=dict(os.environ,TMPDIR=str(D/'tmp'),PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0');(D/'tmp').mkdir()
result={'schema':'facman.independent-linux-tu-result.v1','result':'FAIL_RETAINED','plan_sha256':sha(P),'source_sha256':sha(D/'fixed.cpp'),'automatic_retries':0};current=None;started=time.monotonic()
try:
 with (D/'gcc.stdout').open('xb') as out,(D/'gcc.stderr').open('xb') as err:
  current=subprocess.Popen(plan['command'],cwd=D,env=env,stdout=out,stderr=err,start_new_session=True)
  try:code=current.wait(timeout=plan['timeout_seconds'])
  finally:
   try:os.killpg(current.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   current.wait(timeout=5)
 assert code==0,('compiler_exit',code)
 deptext=(D/'fixed.d').read_text().replace(chr(92)+chr(10),' ');deps=shlex.split(deptext.split(':',1)[1]);observed=[]
 for name in deps:
  path=Path(name);digest=sha(path)
  if path.is_relative_to(S):assert digest==inputs[path.relative_to(S).as_posix()]['raw_sha256']
  observed.append({'path':name,'bytes':path.stat().st_size,'sha256':digest})
 assert sha(D/'fixed.cpp')==plan['source_raw_sha256'] and controls()==before
 result.update(result='PASS_EXACT_GCC_TU_ONLY',exit_code=code,object_sha256=sha(D/'fixed.o'),object_bytes=(D/'fixed.o').stat().st_size,dependencies=observed,source_controls_unchanged=True)
except BaseException as error:
 result.update(error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
finally:
 result.update(elapsed_seconds=round(time.monotonic()-started,6),stdout_sha256=sha(D/'gcc.stdout'),stderr_sha256=sha(D/'gcc.stderr'))
 with (D/'gcc-result.json').open('x',encoding='utf-8',newline=chr(10)) as f:json.dump(result,f,indent=2);f.write(chr(10))
 print(json.dumps({k:v for k,v in result.items() if k!='dependencies'}),flush=True)
raise SystemExit(0 if result['result'].startswith('PASS_') else 1)
