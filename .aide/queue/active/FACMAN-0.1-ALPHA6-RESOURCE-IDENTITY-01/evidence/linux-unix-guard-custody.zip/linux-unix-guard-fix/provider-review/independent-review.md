Independent review: PASS for the one-file Unix guard correction and actual GCC translation-unit compile.

The missing-entrypoints guard still refuses before dereference. `fields()` remains unconditional afterward; the only source change is braces and statement layout. GCC's original Release optimization and warnings-as-errors flags pass with empty stdout/stderr in 2.471689 seconds. The resulting 51,240-byte object is retained externally with SHA256 4018dfdf279bf959fc408ab67f5fe3e56cf8a76b68090caf87c2b252a217a540. The original failing build and its partial outputs remain intact.

No full native/GTK, native fixture, CLI runtime identity, package, host or release qualification is granted by this review.
