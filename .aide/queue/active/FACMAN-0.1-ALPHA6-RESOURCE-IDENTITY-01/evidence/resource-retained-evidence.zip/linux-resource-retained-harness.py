from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,tarfile,tempfile,time,uuid
source=Path(sys.argv[1]); evidence=Path(sys.argv[2])
runid=uuid.uuid4().hex; output=evidence/('linux-harness-'+runid);output.mkdir()
work=Path(tempfile.mkdtemp(prefix='facman-resource-')); snapshot=work/'source';snapshot.mkdir()
sources=[
'runtime/base/fl_path_safety.cpp','runtime/base/fl_sha256.cpp','runtime/platform/fl_file_io.cpp',
'runtime/core/json/fl_json.cpp','runtime/core/json/fl_json_ascii.cpp',
'runtime/archive/fl_archive_platform.cpp','runtime/archive/fl_archive_policy.cpp','runtime/archive/fl_archive_reader.cpp',
'runtime/archive/fl_archive_retained_extraction.cpp',
'runtime/package/fl_runtime_component.cpp','runtime/package/fl_process_image.cpp',
'runtime/package/fl_product_resource_identity.cpp','runtime/package/fl_product_resource_windows.cpp','runtime/package/fl_product_resource_unix.cpp',
'runtime/resources/fl_resource_pack.cpp','runtime/resources/fl_product_resources.cpp','runtime/resources/fl_resource_selection.cpp','runtime/resources/fl_resource_inventory.cpp',
'tests/native/facman_resource_identity_smoke.cpp','external/miniz/miniz.c']
directories=['runtime/base','runtime/platform','runtime/core','runtime/archive','runtime/package','runtime/resources','external/picojson','external/miniz']
paths=set(sources)
for directory in directories:
    paths.update(p.relative_to(source).as_posix() for p in (source/directory).rglob('*.h'))
def sha(data):return hashlib.sha256(data).hexdigest()
before={p:sha((source/p).read_bytes()) for p in sorted(paths)}
for p in paths:
    target=snapshot/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source/p,target)
commands=[];start=time.monotonic();status='FAIL'
def run(name,args,**kwargs):
    completed=subprocess.run(args,capture_output=True,timeout=240,**kwargs)
    (output/(name+'.stdout')).write_bytes(completed.stdout);(output/(name+'.stderr')).write_bytes(completed.stderr)
    commands.append(dict(name=name,args=args,exit=completed.returncode,stdout_sha256=sha(completed.stdout),stderr_sha256=sha(completed.stderr)))
    if completed.returncode:raise RuntimeError(name+' failed: '+str(completed.returncode))
    return completed.stdout.decode('utf-8','replace')
try:
    run('compiler',['g++','--version']);run('cmake',['cmake','--version']);run('identity',['id']);run('filesystem',['stat','-f','-c','%T',str(work)])
    (snapshot/'CMakeLists.txt').write_text('cmake_minimum_required(VERSION 3.20)\nproject(ResourceIdentityProof LANGUAGES C CXX)\nset(CMAKE_CXX_STANDARD 17)\nadd_executable(resource_identity\n'+'\n'.join(sources)+')\ntarget_include_directories(resource_identity PRIVATE '+' '.join(directories+['runtime/core/json'])+')\ntarget_link_libraries(resource_identity PRIVATE pthread)\n')
    shutil.copyfile(snapshot/'CMakeLists.txt',output/'CMakeLists.txt')
    run('configure',['cmake','-S',str(snapshot),'-B',str(work/'build'),'-G','Ninja','-DCMAKE_BUILD_TYPE=Debug'])
    run('build',['cmake','--build',str(work/'build'),'--parallel','4'])
    temp=work/'fixtures';temp.mkdir()
    executable=work/'build/resource_identity'
    run('native',[str(executable)],cwd=work,env=dict(os.environ,TMPDIR=str(temp)))
    shutil.copyfile(executable,output/'resource_identity')
    status='PASS'
except Exception as error:
    (output/'exception.txt').write_text(str(error)+'\n')
finally:
    after={p:sha((source/p).read_bytes()) for p in sorted(paths)}
    if before!=after: status='FAIL'
    with tarfile.open(output/'raw-linux-work.tar.gz','w:gz') as archive:
        for name in ['source','fixtures']:
            if (work/name).exists():archive.add(work/name,arcname=name)
        for name in ['CMakeCache.txt','build.ninja','.ninja_log']:
            if (work/'build'/name).exists():archive.add(work/'build'/name,arcname='build/'+name)
    receipt=dict(schema='facman.resource_identity_linux_harness.v1',result=status,uid=os.getuid(),work=str(work),source=str(source),seconds=time.monotonic()-start,source_before=before,source_after=after,source_unchanged=before==after,commands=commands,scope='minimal native resource harness; not full CLI or packaged candidate qualification',artifacts={p.name:sha(p.read_bytes()) for p in output.iterdir() if p.is_file()})
    (output/'validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(dict(result=status,receipt=str(output/'validation.json'),sha256=sha((output/'validation.json').read_bytes()))))
sys.exit(0 if status=='PASS' else 1)
