
from pathlib import Path
import datetime,hashlib,json,os,subprocess,time,zipfile,tarfile,binascii
wt=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\worktrees\task-facman-resource-identity-01')
tr=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-d9fce3b03d')
ev=tr/'evidence'; build=tr/'native-developer'
os.environ.update(GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',FACMAN_TASK_ID='FACMAN-0.1-ALPHA6-RESOURCE-IDENTITY-01',TEMP=str(tr/'t'),TMP=str(tr/'t'),PYTHONPATH=str(wt/'tests'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def readjson(path):return json.loads(path.read_bytes())
def git(*args):
 p=subprocess.run(['git',*args],cwd=wt,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if p.returncode:raise RuntimeError(f'git {args}: {p.stderr.decode(errors="replace")}')
 return p.stdout
def sources(paths):
 return {n:None if x is None and not (wt/n).exists() else {'bytes':(wt/n).stat().st_size,'sha256':sha((wt/n).read_bytes())} for n,x in paths.items()}
mraw=(ev/'resource-retained-source-manifest.json').read_bytes(); manifest=json.loads(mraw)
assert sha(mraw)=='0c43c3ca0d4072de6a0f990838d5f1ecaa6172948bd9ae5ae75a63c2210ebdbe'
head=git('rev-parse','HEAD').decode().strip();assert head==manifest['head']=='6f8ece1d343400f314e054183beee106bac46358'
index_before=sha(git('ls-files','--stage','-z'))
assert git('diff','--cached','--name-only')==b''
before=sources(manifest['paths']);assert before==manifest['paths']
aggregate=sha(json.dumps(before,sort_keys=True,separators=(',',':')).encode())
assert aggregate==manifest['aggregate_sha256']=='d01b39d8739a420120810079a0e861ead80a34539ff1a0434eadcc650f232d83'
patch=git('diff','--binary','--no-ext-diff','HEAD')
untracked=sorted(x.decode('utf-8') for x in git('ls-files','--others','--exclude-standard','-z').split(b'\0') if x)
for name in untracked:
 p=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',name],cwd=wt,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 assert p.returncode==1,(name,p.returncode,p.stderr)
 patch+=p.stdout
assert patch==(ev/'resource-retained-candidate.patch').read_bytes()
assert sha(patch)=='96aa68f6433780f74129a27b8c5e3bcd05363e38f9afd4bcecc66d1b053ed9b8'
archive=ev/'resource-retained-source.zip'
assert sha(archive.read_bytes())=='b5a2fe4313fdd5de59e368edb0647c8566f9a8ed462809814b8f2571a4be9a66'
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))==47
 assert set(z.namelist())=={n for n,v in before.items() if v is not None}|{'source-manifest.json'}
 assert z.read('source-manifest.json')==mraw
 for n,v in before.items():
  if v is not None:assert z.read(n)==(wt/n).read_bytes()
with zipfile.ZipFile(ev/'resource-identity-source.zip') as z:
 prior_delta=[n for n,v in before.items() if v is not None and (n not in z.namelist() or z.read(n)!=(wt/n).read_bytes())]
linux=ev/'linux-harness-3738fc0c6bf94e36a02f652c63f57ed6'
lraw=(linux/'validation.json').read_bytes();lr=json.loads(lraw)
assert sha(lraw)=='3b458a9f92ec464d43c2d57cae4957a5e6a578d90a071eae56bdba30231a0c11'
assert lr['source_before']==lr['source_after'] and lr['result']=='PASS'
for n,digest in lr['source_before'].items():assert sha((wt/n).read_bytes())==digest,n
for n,digest in lr['artifacts'].items():assert sha((linux/n).read_bytes())==digest,n
with tarfile.open(linux/'raw-linux-work.tar.gz') as t:
 names=[x.name for x in t.getmembers()]
 assert len(names)==len(set(names))
 for n,digest in lr['source_before'].items():
  assert sha(t.extractfile('source/'+n).read())==digest,n
fixture_oracles={}
with tarfile.open(linux/'raw-linux-work.tar.gz') as t:
 members={x.name:x for x in t.getmembers()}
 roots=[n for n in members if n.startswith('fixtures/facman-resources-') and n.count('/')==1]
 assert len(roots)==1
 fr=roots[0]
 original_payload=b'A'*70000+b'abcd';foreign_payload=b'B'*70000+bytes.fromhex('c7e75c51')
 assert len(original_payload)==len(foreign_payload)==70004
 assert binascii.crc32(original_payload)==binascii.crc32(foreign_payload)==662017341
 for platform in ['windows','linux','macos']:
  out=fr+'/'+platform+'-consumed-export/content/factorio/test.txt'
  assert t.extractfile(out).read()==foreign_payload
  packrel='facman.resources' if platform=='windows' else 'share/facman/facman.resources' if platform=='linux' else 'Contents/Resources/facman.resources'
  import io
  with zipfile.ZipFile(io.BytesIO(t.extractfile(fr+'/'+platform+'-consumed-digest/'+packrel).read())) as z:
   assert z.read('content/factorio/test.txt')==original_payload
  for mode in ['root_substitution','marker_collision']:
   prefix=fr+'/'+platform+'-'+mode
   actual={n[len(prefix)+1:] for n in members if n.startswith(prefix+'/')}
   assert actual=={'.facman-archive-staging.v1','foreign.txt'},(platform,mode,actual)
   assert t.extractfile(prefix+'/.facman-archive-staging.v1').read()==b'foreign marker'
   assert t.extractfile(prefix+'/foreign.txt').read()==b'foreign sentinel'
  for mode in ['root_substitution']:
   orig=fr+'/'+platform+'-'+mode+'-original'
   assert orig in members and not any(n.startswith(orig+'/') for n in members)
  prefix=fr+'/'+platform+'-failed-export'
  actual={n[len(prefix)+1:] for n in members if n.startswith(prefix+'/')}
  assert actual=={'.facman-archive-staging.v1','foreign.txt'},(platform,actual)
  assert t.extractfile(prefix+'/.facman-archive-staging.v1').read()==b'foreign marker'
  assert t.extractfile(prefix+'/foreign.txt').read()==b'foreign sentinel'
  orig=fr+'/'+platform+'-failed-export-original'
  assert t.extractfile(orig+'/.facman-archive-staging.v1').read()==b'schema=facman.archive_staging.v1\n'
  assert orig+'/manifest/resource-pack.v1.json' in members
  fixture_oracles[platform]='Raw archived source restored; CRC-colliding foreign consumed output retained; substituted root inventories exactly two unchanged foreign files; original roots retained.'
windows_raw=(ev/'windows-retained-qualified-validation.json').read_bytes();wr=json.loads(windows_raw)
assert sha(windows_raw)=='acb861832577389e7beace624e56d38920de61be4f220deab774063d723d4ca3'
assert wr['result']=='PASS' and wr['source_before']==wr['source_after']
for n,digest in wr['source_before'].items():assert sha((wt/n).read_bytes())==digest,n
for command in wr['commands']:
 assert command['exit']==0
 assert sha((ev/(command['name']+'.txt')).read_bytes())==command['log_sha256']
binaries_before={n:sha((build/'Debug'/n).read_bytes()) for n in wr['executables']}
assert binaries_before==wr['executables']
last=build/'Testing/Temporary/LastTest.log'
prior_last=last.read_bytes() if last.exists() else b''
prior=ev/'native-review-retained-prior-LastTest.log'
assert not prior.exists();prior.write_bytes(prior_last)
command=['ctest','--test-dir',str(build),'-C','Debug','-R','^(facman_resource_identity_smoke|facman_resource_product_cli|facman_runtime_package_identity_smoke|fl_json_core_smoke|fl_archive_core_smoke)$','--output-on-failure']
log=ev/'native-review-retained-ctest.txt'
assert not log.exists()
start=time.monotonic()
with log.open('wb') as f:p=subprocess.run(command,cwd=wt,stdout=f,stderr=subprocess.STDOUT,timeout=240)
elapsed=time.monotonic()-start
post_last=last.read_bytes()
(ev/'native-review-retained-LastTest.log').write_bytes(post_last)
after=sources(manifest['paths'])
index_after=sha(git('ls-files','--stage','-z'))
binaries_after={n:sha((build/'Debug'/n).read_bytes()) for n in wr['executables']}
validation_inputs_after={n:sha((wt/n).read_bytes()) for n in wr['source_before']}
result='PASS' if p.returncode==0 and before==after and index_before==index_after and binaries_before==binaries_after and validation_inputs_after==wr['source_before'] else 'FAIL'
receipt={'schema':'facman.resource_retained_extraction_independent_review.v1','reviewer':'/root/native_ownership','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':result,'head':head,'scope':'Independent review of ROOT-authored retained-extraction remediation, full candidate custody verification; baseline implementation was authored by this reviewer and independently reviewed by ROOT.','source_manifest_sha256':sha(mraw),'source_aggregate_sha256':aggregate,'source_paths':len(before),'present':sum(v is not None for v in before.values()),'deleted':sum(v is None for v in before.values()),'source_before':before,'source_after':after,'source_unchanged':before==after,'index_before_sha256':index_before,'index_after_sha256':index_after,'patch_sha256':sha(patch),'source_zip_sha256':sha(archive.read_bytes()),'delta_from_superseded_source':prior_delta,'native_inputs':len(wr['source_before']),'native_inputs_unchanged':validation_inputs_after==wr['source_before'],'windows_author_validation_sha256':sha(windows_raw),'windows_binaries_before':binaries_before,'windows_binaries_after':binaries_after,'independent_windows_ctest':{'command':command,'exit':p.returncode,'seconds':elapsed,'log':log.name,'sha256':sha(log.read_bytes()),'last_test_sha256':sha(post_last),'prior_last_test_sha256':sha(prior_last)},'linux_audited_receipt_sha256':sha(lraw),'linux_source_inputs':len(lr['source_before']),'linux_artifacts':len(lr['artifacts']),'linux_fixture_oracles':fixture_oracles,'linux_rerun_by_reviewer':False,'findings':[],'closed_initial_findings':['Literal newline build errors fixed.','Native root-substitution expectation distinguishes performed POSIX mutation and observed Windows deny-delete behavior; marker replacement still executes.','Standard and nonstandard callback exceptions are caught inside the sink and adapter without unwinding through miniz cleanup.','Preparation rename assertions run outside callback; actual POSIX rename and CRC mutation are mandatory.'],'review_conclusions':['Opt-in retained extractor calls no removal or legacy cleanup path, including marker creation and exception failures.','Complete unique per-member SHA/size closure includes captured internal manifest and is admitted before destination creation.','Hashes are updated only for successful complete sink writes using the same opened reader; CRC collision restored before final observation remains a SHA refusal.','Root/parent revalidations are observations; docs explicitly describe remaining namespace races and sequential ordinary inventory file closure.','Existing standalone selectors and legacy extractor cleanup are unchanged by this remediation.','Canonical authority update grants conditional publication authorization only; resource leaf remains active and unrelated qualification gates remain unchanged.'],'limitations':['Windows actual native test rerun is independent; Linux 454 assertions are source-bound audited execution by ROOT, with raw fixture contents independently verified.','Fresh hosted/full packaged candidate and macOS native qualification remain pending.','No atomic package snapshot, protected export namespace, cleanup authority, game/host/human/signing or Beta1 qualification is supplied by this review.'],'prior_evidence_sha256':{n:sha((ev/n).read_bytes()) for n in ['resource-identity-source.zip','resource-identity-validation.zip','root-resource-red-evidence.zip','root-resource-independent-tests.json','native-review-retained-extraction-initial.json']}}
out=ev/'native-review-retained-final.json'
assert not out.exists();out.write_bytes((json.dumps(receipt,indent=2,sort_keys=True)+'\n').encode())
print(json.dumps({'result':result,'receipt':str(out),'sha256':sha(out.read_bytes()),'ctest_seconds':elapsed,'source_unchanged':before==after},indent=2))
raise SystemExit(0 if result=='PASS' else 1)

