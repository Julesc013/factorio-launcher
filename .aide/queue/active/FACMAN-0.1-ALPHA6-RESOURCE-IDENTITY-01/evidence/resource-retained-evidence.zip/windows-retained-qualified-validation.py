from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path.cwd();task=Path(__file__).resolve().parent.parent;ev=task/'evidence';build=task/'native-developer'
def sha(b):return hashlib.sha256(b).hexdigest()
def inputs():
    files=set()
    for folder in ['runtime','apps','external','tests/native','cmake','bindings']:
        if (root/folder).exists():
            files.update(p for p in (root/folder).rglob('*') if p.is_file() and (p.suffix in {'.c','.cpp','.cc','.h','.hpp','.cmake','.toml','.json'} or p.name=='CMakeLists.txt'))
    files.add(root/'CMakeLists.txt')
    files.add(root/'tests/integration/resource_identity_runtime.py')
    return {p.relative_to(root).as_posix():sha(p.read_bytes()) for p in sorted(files)}
before=inputs();start=time.monotonic();records=[];status='FAIL'
def run(name,args):
    log=ev/(name+'.txt')
    with log.open('wb') as output:
        completed=subprocess.run(args,stdout=output,stderr=subprocess.STDOUT,timeout=900)
    records.append(dict(name=name,args=args,exit=completed.returncode,log_sha256=sha(log.read_bytes())))
    if completed.returncode:raise RuntimeError(name+' failed: '+str(completed.returncode))
try:
    run('windows-retained-qualified-build',['cmake','--build',str(build),'--config','Debug','--target','facman_resource_identity_smoke','facman_cli','facman_runtime_package_identity_smoke','fl_json_core_smoke','fl_archive_core_smoke','--parallel','--','/p:TrackFileAccess=false'])
    run('windows-retained-qualified-ctest',['ctest','--test-dir',str(build),'-C','Debug','-R','^(facman_resource_identity_smoke|facman_resource_product_cli|facman_runtime_package_identity_smoke|fl_json_core_smoke|fl_archive_core_smoke)$','--output-on-failure'])
    status='PASS'
except Exception as error:records.append(dict(exception=str(error)))
after=inputs()
if before!=after:status='FAIL'
receipt=dict(schema='facman.resource_identity_windows_validation.v1',result=status,source_before=before,source_after=after,source_unchanged=before==after,seconds=time.monotonic()-start,commands=records,executables={name:sha((build/'Debug'/name).read_bytes()) for name in ['facman.exe','facman_resource_identity_smoke.exe','facman_runtime_package_identity_smoke.exe','fl_json_core_smoke.exe','fl_archive_core_smoke.exe']},fixture_only=True,authority=dict(game=False,live_native_install=False,human=False,publication=False,beta1=False))
receipt_path=ev/'windows-retained-qualified-validation.json';receipt_path.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(result=status,receipt=str(receipt_path),sha256=sha(receipt_path.read_bytes()))))
raise SystemExit(0 if status=='PASS' else 1)
