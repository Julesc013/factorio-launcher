README="# POSIX supervisor V3 proof custody\n\nThis supplement preserves the exact reviewed source and recorded Linux proof\nfor the [POSIX ownership and I/O contract](../../../../../../docs/architecture/posix-process-supervision.v1.md)\nunder the existing [resource WorkUnit](../../ExecPlan.md). The implementation\nbookkeeping remains a separate, unapplied proposal against 5f3ad450.\n\n[Custody records](custody.json) map original paths and raw SHA-256 values to\n[custody.zip](custody.zip). Files were captured once, each nested source/actual\narchive was checked against its original roster, and every selected original\nand outer archive member was rechecked afterward. Original bytes are preserved;\nthe existing source manifests' compiled=false fields describe their earlier\nsource freeze and are not rewritten after the later native run.\n\nThe selected evidence includes the original I/O V1 bytes, V2 source custody,\nthe five-file V3 source and reviews, reviewed driver custody, actual three-query\ndependency preflight, ten-command actual evidence and ROOT independent review,\nand the earlier focused seven-command lifecycle proof. The ten-command proof's\n91-original ZIP and the predecessor's 40-original ZIP remain intact.\nNested archives contain repeated source/evidence bytes. Their member counts\nare not added together or presented as a unique-artifact total. The outer\ncustody map names any selected originals sharing one identical stored member.\n\n## What changed and what ran\n\nThe POSIX correction retains child ownership through the single consuming wait,\nbounds EINTR retries, and checks termination-clock arithmetic at the actual\naddition. Its nonblocking pump handles exec status, stdin and both output streams.\nAnonymous socket stdin suppresses SIGPIPE locally without changing caller\nsignals. Post-fork uncertainty remains pending; only the exact positive exec\nfailure handshake plus expected reaped status narrows start failure. Ambiguous\ninherited-descriptor close failures refuse before exec.\n\nThe recorded V3 validation ran ten exact commands: five warning-as-error compile\ncommands, default pump and unchanged lifecycle oracles, anonymous AF_UNIX socket\ncontrols, and two deliberately broken lifecycle variants with their required\nexact exit1 diagnostics. Four x86_64 PIE test binaries were executed. The actual\nsupervisor adapter was compiled to an ET_REL object and was never executed.\nAll 21 source copies and both mutations were checked. Five actual dependency\nlists close against the 368-input preflight. The native archive contains all\n33 recorded regular files from the 52-row child inventory.\n\nROOT's independent actual review is\n6761a5d3540391fa68e62b19698b8de19dbe7f662903daa5e547f4a6fd44bb2a.\nThe predecessor focused lifecycle proof remains separately bound to d90a6a4f\nand does not qualify the later I/O source by inheritance.\n\n## Remaining boundaries\n\nThis is bounded ordinary native evidence. No product supervised child, session\nescape, PID-reuse race, Apple compilation/socket behavior, full integrated\nprocess suite, hosted build or release was qualified by this lane. A successful\ngroup termination request is not proof that every descendant stopped. The\nembedding process must preserve exclusive wait/SIGCHLD ownership; synchronous\ncallbacks must return for the in-process deadline to advance.\n\nThe ZIP makes selected source, logs, receipts and the exported small native\nartifacts portable. Original Linux directories and the host's 368 compiler/header\ninputs are not installed or reconstructed by this supplement. Their observations\nremain exact recorded-run evidence, with no fresh Linux readback or ongoing\navailability claim. Absolute original paths in the custody map are provenance,\nnot instructions to access or recreate those paths.\n\nNo repository patch is applied, no WorkUnit is closed, and no current package,\nGUI, provider adoption, human/game, signing or publication gate is discharged.\nThe resource-export correction and its Windows evidence remain independent.\n"
import hashlib,json,os,subprocess,sys,zipfile
from io import BytesIO
from pathlib import Path,PurePosixPath
E=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-d9fce3b03d\evidence')
WT=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\worktrees\task-facman-resource-identity-01')
CANARY=WT.parent/'task-facman-provider-canary-01'
OUT=E/'posix-io-custody-supplement-v1'
REL='.aide/queue/active/FACMAN-0.1-ALPHA6-RESOURCE-IDENTITY-01/evidence/posix-supervisor-io-v3'
PAY=OUT/'payload'/REL
captured={};selected=[];nested=[]
def sha(raw):return hashlib.sha256(raw).hexdigest()
def blob(raw):return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def read(path):
 path=Path(path);key=str(path.resolve())
 if key not in captured:
  info=path.lstat();assert path.is_file() and not getattr(info,'st_file_attributes',0)&0x400
  raw=path.read_bytes();assert len(raw)<=4*1024**2;captured[key]=raw
 return captured[key]
def ref(path,wanted=None):
 raw=read(path);digest=sha(raw)
 if wanted:assert digest==wanted,(path,digest)
 return dict(path=str(path),bytes=len(raw),sha256=digest)
def add(label,path,wanted=None):
 row=ref(path,wanted);assert label not in {r['requested_member'] for r in selected}
 selected.append(dict(**row,requested_member=label));return row
def js(path):return json.loads(read(path))
def write(path,raw):
 path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('xb') as f:f.write(raw)
def new(path,value):write(path,(json.dumps(value,indent=2,sort_keys=True)+'\n').encode())
if OUT.exists():raise ValueError('supplement exists')
book=E/'posix-io-bookkeeping-v1'
bookref=ref(book/'source-manifest.json','9e7563d5cbcd07647b9829a09883f0ed14a9650bf685837ba2d11b0f535c6bee')
bookzipref=ref(book/'proposal.zip','6bf8eaca498f2128a2d12790002eae412f4475af5938b54226eb5ce41ffee2d9')
bookmanifest=js(book/'source-manifest.json')
for row in bookmanifest['standalone']['files']:
 raw=read(book/'payload'/row['path']);assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
groups={
 'candidate-v3':('posix-supervisor-io-candidate-v3',['source-manifest.json','root-source-review.json','scope.json','source.zip','complete.patch','v2-to-v3.diff','source-checks.json','source-checks.log','predecessor-v2.json','original-v1.zip']),
 'candidate-v2':('posix-supervisor-io-candidate-v2',['source-manifest.json','handoff.json','custody-roster.json','review-custody.zip','REVIEW.md']),
 'driver':('posix-io-native-driver-v1',['core-plan.json','source-manifest.json','source-custody.zip','custody.json','review-handoff.json','root-source-review.json','README.md']),
 'preflight':('posix-io-preflight-actual-seal',['root-actual-review.json','custody.json','originals.zip']),
 'actual-io':('posix-io-validation-actual-seal',['root-actual-review.json','review.json','custody.json','originals.zip','dependencies.json','native-files.json','source-copies-review.json']),
 'focused-lifecycle':('posix-lifecycle-native-actual-seal',['root-actual-review.json','custody.json','originals.zip']),
}
for label,(directory,names) in groups.items():
 for name in names:add(label+'/'+name,E/directory/name)
pins={
 E/'posix-supervisor-io-candidate-v3/source-manifest.json':'7f31a5eb3a93619c9f41e89b2b5e094bde03d1cd3f2903aff2f8d343417b2ab4',
 E/'posix-io-native-driver-v1/source-custody.zip':'b408722465b15de91adde12a974160007a64551027896250435ba7c7f3109752',
 E/'posix-io-preflight-actual-seal/root-actual-review.json':'c24059cccccf4457f53929996223f4d20fdfe61f6187a7e0c0ecb66122c2cba2',
 E/'posix-io-validation-actual-seal/root-actual-review.json':'6761a5d3540391fa68e62b19698b8de19dbe7f662903daa5e547f4a6fd44bb2a',
 E/'posix-io-validation-actual-seal/originals.zip':'084342d7f758c4ecd50dcc451ca71946b336ca73cb961530038264da4eaee353',
 E/'posix-lifecycle-native-actual-seal/root-actual-review.json':'d90a6a4fc8fb02f3176970b02e5eeaf214d1f00fd4e717429e97496bc5674a72',
}
for path,digest in pins.items():ref(path,digest)
v3=js(E/'posix-supervisor-io-candidate-v3/source-manifest.json')
for row in v3['files']:
 p=E/'posix-supervisor-io-candidate-v3/payload'/row['path'];add('candidate-v3/payload/'+row['path'],p,row['sha256'])
old=E/'posix-supervisor-candidate-v1'
for name in ['source-manifest.json','root-source-review.json']:
 add('focused-candidate/'+name,old/name)
add('focused-candidate/facman_posix_child_lifecycle_smoke.cpp',old/'payload/tests/native/facman_posix_child_lifecycle_smoke.cpp','1eefdb9fd43f0e59fe62c8fd56512e0828c0b842a49b54c183643cd395f791d4')
helpers=[
 ('sdk_process.py',E/'linux-installed-sdk-effect-proposal-v3/sdk_process.py','392ff8aa80e57718df4d276d99effc85fec8ba46b0321598df3461392030cfe5'),
 ('sdk_records.py',E/'linux-installed-sdk-effect-proposal-v3/sdk_records.py','ef4f2e0303545d696e2403d9e52ea441e6aa4ea4f350678e8ebf9b9b1e82d133'),
 ('ns_control_host.py',E/'linux-pid-namespace-controls-controller-v2/ns_control_host.py','361a0ded6902838e8d21e80e287356dc1a8890db40e887f0459f88f4d9bc2152'),
 ('provider_canary_process.py',CANARY/'tools/provider_canary_process.py','5f7b834f3a26a84ffc40e7a164a615d4855cf01b4fbc50fb909e83cc53c9c1fe'),
 ('provider_canary_process_windows.py',CANARY/'tools/provider_canary_process_windows.py','47233123222a02befb87edaa302ad0232b06ae4f266ba97b0d1e4308b55b236c'),
]
for name,path,digest in helpers:add('driver-helpers/'+name,path,digest)
def verify_zip(zip_path,rows,base=None,member_key='member'):
 with zipfile.ZipFile(BytesIO(read(zip_path))) as z:
  names=z.namelist();assert len(names)==len(set(names))==len(rows)
  for row in rows:
   name=row.get(member_key,row['path']);assert name in names
   raw=z.read(name);assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
   original=base/row['path'] if base else Path(row['path'])
   assert raw==read(original)
 nested.append(dict(archive=ref(zip_path),member_count=len(rows),original_bytes_reverified=True))
verify_zip(E/'posix-io-native-driver-v1/source-custody.zip',js(E/'posix-io-native-driver-v1/custody.json')['members'],E/'posix-io-native-driver-v1',member_key='path')
verify_zip(E/'posix-supervisor-io-candidate-v2/review-custody.zip',js(E/'posix-supervisor-io-candidate-v2/custody-roster.json')['members'],E/'posix-supervisor-io-candidate-v2',member_key='path')
verify_zip(E/'posix-supervisor-io-candidate-v3/source.zip',v3['files'],E/'posix-supervisor-io-candidate-v3/payload',member_key='path')
for directory in ['posix-io-preflight-actual-seal','posix-io-validation-actual-seal','posix-lifecycle-native-actual-seal']:
 ledger=js(E/directory/'custody.json');rows=ledger['files'] if isinstance(ledger,dict) else ledger
 verify_zip(E/directory/'originals.zip',rows)
# The original uncorrected I/O candidate is preserved with its original manifest.
v1=E/'posix-supervisor-io-candidate-v1'
with zipfile.ZipFile(BytesIO(read(E/'posix-supervisor-io-candidate-v3/original-v1.zip'))) as z:
 assert len(z.namelist())==7
 for name in z.namelist():assert z.read(name)==read(v1/name)
nested.append(dict(archive=ref(E/'posix-supervisor-io-candidate-v3/original-v1.zip'),member_count=7,original_bytes_reverified=True))
rootreview=js(E/'posix-io-validation-actual-seal/root-actual-review.json')
assert rootreview.get('result','').startswith('PASS')
# Select bookkeeping references without copying its unapplied payload into the three-file source scope.
for name in ['source-manifest.json','handoff.json','PROPOSAL.md']:
 add('bookkeeping-reference/'+name,book/name)
unique={};rows=[]
for row in selected:
 raw=read(row['path']);digest=row['sha256']
 if digest in unique:assert unique[digest][1]==raw
 else:unique[digest]=(row['requested_member'],raw)
 rows.append({**row,'member':unique[digest][0]})
assert len(rows)==len({r['path'] for r in rows})
for path,raw in captured.items():assert Path(path).read_bytes()==raw,('changed original',path)
PAY.mkdir(parents=True)
with zipfile.ZipFile(PAY/'custody.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 for name,raw in unique.values():z.writestr(name,raw)
with zipfile.ZipFile(PAY/'custody.zip') as z:
 assert set(z.namelist())=={v[0] for v in unique.values()}
 for row in rows:assert z.read(row['member'])==read(row['path'])
for path,raw in captured.items():assert Path(path).read_bytes()==raw,('changed after seal',path)
zipraw=(PAY/'custody.zip').read_bytes()
custody=dict(schema='facman.posix_supervisor_io_portable_custody.v1',result='PRESERVED_REVIEWED_SOURCE_AND_RECORDED_NATIVE_PROOF',
 archive=dict(path='custody.zip',bytes=len(zipraw),sha256=sha(zipraw)),selected_original_count=len(rows),outer_unique_member_count=len(unique),
 selected_originals=rows,nested_archives=nested,
 byte_accounting='Outer identical raw payloads share one stored member. Nested archive member counts overlap and must not be summed as globally unique bytes or independent executions.',
 source_state={'candidate_base':'98858a7f4317d4f234ade9bb6a03ced70804abfd','candidate_v3_manifest_sha256':pins[E/'posix-supervisor-io-candidate-v3/source-manifest.json'],
 'bookkeeping_base':'5f3ad4500e01a0b15c15c522e37ad62f753099eb','bookkeeping_manifest':bookref,'existing_10_36_proposal_unchanged':True,'applied':False},
 qualification={'recorded_ten_command_outcomes':True,'five_compiles':True,'anonymous_socket_controls':True,'actual_adapter_executed':False,
 'real_product_child_or_pid_reuse':False,'apple':False,'full_process_suite':False,'hosted':False,'package_or_release':False,'human_or_game':False},
 original_availability='Selected bytes are portable here. Original Linux roots and host compiler/header inputs are observations, not recreated files or an ongoing availability claim.',
 source_freeze_fields='Earlier compiled=false/source-only metadata remains unchanged; later actual receipts independently bind the tested source.',
 root_actual_review_sha256=pins[E/'posix-io-validation-actual-seal/root-actual-review.json'],
 focused_predecessor_review_sha256=pins[E/'posix-lifecycle-native-actual-seal/root-actual-review.json'])
new(PAY/'custody.json',custody);write(PAY/'README.md',README.encode())
files=[]
for name in ['README.md','custody.json','custody.zip']:
 raw=(PAY/name).read_bytes();files.append(dict(path=REL+'/'+name,bytes=len(raw),sha256=sha(raw),git_blob=blob(raw),mode='100644',preimage=None))
# Pure tree projections, read-only git. Existing source proposal is untouched.
def git(*args):return subprocess.run(['git','--no-optional-locks','-c','diff.autoRefreshIndex=false',*args],cwd=WT,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30).stdout
assert git('rev-parse','HEAD').decode().strip()==bookmanifest['base_commit'] and git('status','--porcelain=v1')==b''
flat={}
for record in git('ls-tree','-r','-z',bookmanifest['base_commit']).split(b'\0'):
 if record:
  info,path=record.split(b'\t',1);mode,kind,oid=info.decode().split();flat[path.decode()]=(mode,oid)
def tree(extra):
 entries={**flat,**{r['path']:(r['mode'],r['git_blob']) for r in extra}};node={}
 for path,value in entries.items():
  cur=node;parts=path.split('/')
  for p in parts[:-1]:cur=cur.setdefault(p,{})
  cur[parts[-1]]=value
 def rec(n):
  raw=b''
  for name,value in sorted(n.items(),key=lambda kv:(kv[0]+'/' if isinstance(kv[1],dict) else kv[0]).encode()):
   mode,oid=('40000',rec(value)) if isinstance(value,dict) else value
   raw+=mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(oid)
  return hashlib.sha1(b'tree '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
 return rec(node)
assert tree([])==bookmanifest['base_tree']
assert tree(bookmanifest['standalone']['files'])==bookmanifest['standalone']['projected_tree']
assert tree(bookmanifest['resource_union']['files'])==bookmanifest['resource_union']['projected_tree']
sys.path.insert(0,str(WT));from tools import source_format_check
for row in files:
 p=OUT/'payload'/row['path']
 if p.suffix!='.zip':assert source_format_check.validate_file(p,row['path'])==[]
for name in ['custody.json','README.md']:
 text=(PAY/name).read_text(encoding='utf-8');assert '\r' not in text and text.endswith('\n')
for path,raw in captured.items():assert Path(path).read_bytes()==raw
manifest=dict(schema='facman.posix_io_portable_supplement_proposal.v1',result='FROZEN_THREE_FILE_SUPPLEMENT_NOT_APPLIED',
 files=files,base_commit=bookmanifest['base_commit'],base_tree=bookmanifest['base_tree'],preserved_bookkeeping=bookref,
 preserved_bookkeeping_archive=bookzipref,standalone_13_tree=tree(bookmanifest['standalone']['files']+files),
 resource_union_39_tree=tree(bookmanifest['resource_union']['files']+files),
 selected_originals=len(rows),outer_unique_members=len(unique),nested_member_occurrences_reverified=sum(r['member_count'] for r in nested),
 readback_original_paths=len(captured),no_native_effects=True,no_repository_mutations=True,
 aggregate=sha(''.join(r['path']+'\0'+r['sha256']+'\n' for r in files).encode()),
 aggregate_algorithm='SHA256 ordered listed path+NUL+rawSHA256+LF',
 generator=ref(Path(__file__)))
new(OUT/'source-manifest.json',manifest)
new(OUT/'handoff.json',dict(manifest=ref(OUT/'source-manifest.json'),files=files,standalone_13_tree=manifest['standalone_13_tree'],resource_union_39_tree=manifest['resource_union_39_tree'],
 archive_member_counts_overlap=True,existing_proposals_unchanged=True))
print(json.dumps(dict(handoff=ref(OUT/'handoff.json'),manifest=ref(OUT/'source-manifest.json'),archive=dict(bytes=len(zipraw),sha256=sha(zipraw)),selected_originals=len(rows),unique_members=len(unique),nested_checks=nested,standalone_13_tree=manifest['standalone_13_tree'],resource_union_39_tree=manifest['resource_union_39_tree']),indent=2))
