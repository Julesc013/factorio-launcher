"""Finite external host adapter. Incomplete plans refuse before loading the job helper."""
import argparse,hashlib,importlib.util,json,os,re,stat,sys,time,types
from pathlib import Path,PureWindowsPath
D=Path(__file__).resolve().parent
TASK=D.parent.parent
N=D.parent/'linux-pid-namespace-controls-source-v1'
WT=TASK.parent.parent/'worktrees/task-facman-provider-canary-01'
HELPERS={'provider_canary_process.py':'5f7b834f3a26a84ffc40e7a164a615d4855cf01b4fbc50fb909e83cc53c9c1fe','provider_canary_process_windows.py':'47233123222a02befb87edaa302ad0232b06ae4f266ba97b0d1e4308b55b236c'}
SCRIPTS=('collect_missing.py','ns_control_host.py')
NAMESPACE_PINS={'ns_common.py': '53f9a2961f5002476379f7c3196e28ce04407b94284544143985e89ad05a3305', 'ns_actors.py': '33512c3fe73e0872f12884544c62b9536c7c618cf380d69bf8b2f2ed806993df', 'ns_guardian.py': '9565ce7320753da00bf01a5336601574fc618cba4f4ef05ea8baa218ce4a33fe', 'ns_epoch.py': '1eca00791bd933f34eedd3b76050a222d692f5923d2e361710bc7d16d422ba44', 'sdk_records.py': 'ef4f2e0303545d696e2403d9e52ea441e6aa4ea4f350678e8ebf9b9b1e82d133'}
def require(ok,message):
    if not ok:raise ValueError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(path,cap=16*1024**2):
    p=Path(path);require(p.is_absolute(),'absolute reference')
    for q in [*reversed(p.parents),p]:
        info=q.lstat();require(not stat.S_ISLNK(info.st_mode) and not getattr(info,'st_file_attributes',0)&0x400,'plain reference')
    with p.open('rb') as f:
        a=os.fstat(f.fileno());require(stat.S_ISREG(a.st_mode) and a.st_size<=cap,'bounded reference');raw=f.read(cap+1);b=os.fstat(f.fileno())
    require(len(raw)<=cap and (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns)==(b.st_dev,b.st_ino,b.st_size,b.st_mtime_ns),'changed reference');return raw
def reference(row):
    raw=read(row['path']);require(len(raw)==row['bytes'] and sha(raw)==row['sha256'],'reference mismatch');return raw
def json_new(path,value):
    raw=(json.dumps(value,indent=2,allow_nan=False)+'\n').encode();require(len(raw)<=16*1024**2,'receipt cap')
    with path.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
def linux(path):
    p=PureWindowsPath(path);require(p.is_absolute() and p.drive.lower()=='c:' and '..' not in p.parts,'fixed C drive path');return '/mnt/c/'+'/'.join(p.parts[1:])
def validate(plan,now):
    require(plan.get('schema')=='facman.namespace_host_plan.v1' and plan.get('execution_authorized') is True,'unresolved host proposal')
    require(plan.get('mode') in ('collect_missing','controls'),'fixed host mode')
    require(type(plan.get('expires_at')) in (int,float) and 0<plan['expires_at']-now<=3600,'finite new expiry')
    require(isinstance(plan.get('request_id'),str) and re.fullmatch('[0-9a-f]{32}',plan['request_id']) and int(plan['request_id'],16)>0,'new request')
    require(set(plan['script_hashes'])==set(SCRIPTS),'exact host source set')
    require(plan['automatic_retries']==0,'no retries')
    require(plan['namespace_source_review']['sha256']=='8b0a3332a58b23c2d38c7a1e56d998b32ef984747dfc8f0aecde4f20971a7c79','approved namespace source review')
    if plan['mode']=='controls':
        require(plan.get('closed_state_bound') is True,'SDK/continuation state not closed')
        for k in ('closed_state_review','closed_state_map','source_controls','missing_inputs','namespace_plan','namespace_effect_review'):
            require(isinstance(plan.get(k),dict),'unresolved '+k)
    return plan
def verify(plan):
    for name,digest in plan['script_hashes'].items():require(sha(read(D/name))==digest,'host source drift')
    for name,digest in HELPERS.items():require(sha(read(WT/'tools'/name))==digest,'supervisor drift')
    review=json.loads(reference(plan['namespace_source_review']));require(review['result'].startswith('PASS'),'namespace source review')
    for row in plan['namespace_runtime_sources']:
        require(Path(row['path']).parent==N and NAMESPACE_PINS.get(Path(row['path']).name)==row['sha256'],'fixed approved namespace runtime source');reference(row)
    require({Path(r['path']).name for r in plan['namespace_runtime_sources']}=={'ns_common.py','ns_actors.py','ns_guardian.py','ns_epoch.py','sdk_records.py'},'exact namespace runtime closure')
    if plan['mode']=='controls':
        for k in ('closed_state_review','closed_state_map','source_controls','missing_inputs'):reference(plan[k])
        np=json.loads(reference(plan['namespace_plan']));nr=json.loads(reference(plan['namespace_effect_review']))
        require(np['execution_authorized'] is True and np['bindings_complete'] is True,'namespace plan unresolved')
        require(nr['effect_execution_approved'] is True and nr['result'].startswith('PASS') and nr['plan_sha256']==plan['namespace_plan']['sha256'],'exact namespace effect approval')
        binding=read(Path(plan['namespace_plan']['path']).parent/'bindings.json');require(sha(binding)==np['bindings_sha256'],'namespace bindings changed');b=json.loads(binding)
        root_rows=json.loads(reference(plan['closed_state_map']));require(b['original_root_inventory']==root_rows,'actual final root map differs')
        controls=json.loads(reference(plan['source_controls']));require(set(controls)=={'runtime_inputs','preserved_inputs'} and len(controls['runtime_inputs'])<=16 and len(controls['preserved_inputs'])<=32,'small synthetic control input view')
        require(b['source_inputs']==controls['runtime_inputs'] and b['preserved_inputs']==controls['preserved_inputs'],'synthetic inputs differ')
        collected=json.loads(reference(plan['missing_inputs']));require(collected['schema']=='facman.namespace_missing_inputs.v1' and collected['result']=='READ_ONLY_OBSERVATION','read-only missing input receipt')
        require(b['guardian_capabilities']==collected['guardian_capabilities'],'guardian capabilities differ')
        for row in collected['tools']:
            require(next(x for x in b['tools'] if x['path']==row['path'])=={k:row[k] for k in ('path','bytes','sha256')},'collected tool binding differs')
        require(np['execution_evidence_root']==linux(TASK/'evidence'/('linux-namespace-host-'+plan['request_id'])/'metadata'),'exact metadata output')
        require(np['script_hashes']=={Path(r['path']).name:r['sha256'] for r in plan['namespace_runtime_sources']},'namespace plan source mismatch')
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def engine():
    require('tools' not in sys.modules,'unexpected tools module');pkg=types.ModuleType('tools');pkg.__path__=[];sys.modules['tools']=pkg
    pkg.provider_canary_process_windows=load('tools.provider_canary_process_windows',WT/'tools/provider_canary_process_windows.py')
    return load('tools.provider_canary_process',WT/'tools/provider_canary_process.py')
def command_argv(plan):
    prefix=[r'C:\Windows\System32\wsl.exe','-d','Ubuntu-24.04','--exec','/usr/bin/timeout','--signal=TERM']
    if plan['mode']=='collect_missing':return prefix+['--kill-after=5','15','/usr/bin/python3.12','-I','-B',linux(D/'collect_missing.py'),'--collect-read-only'],25
    return prefix+['--kill-after=10','250','/usr/bin/python3.12','-I','-B',linux(N/'ns_guardian.py'),'--plan',linux(plan['namespace_plan']['path']),'--execute','--review',linux(plan['namespace_effect_review']['path']),'--review-sha256',plan['namespace_effect_review']['sha256']],265
def run(plan_path,review_path,expected_plan,expected_review,*,injected_engine=None):
    raw=read(plan_path);require(sha(raw)==expected_plan,'exact host plan');plan=validate(json.loads(raw),time.time())
    rr=read(review_path,65536);require(sha(rr)==expected_review,'exact host review');review=json.loads(rr)
    require(review.get('schema')=='facman.namespace_host_effect_review.v1' and review.get('result')=='PASS_EXACT_EFFECT' and review.get('execution_authorized') is True and review.get('plan_sha256')==expected_plan and review.get('mode')==plan['mode'] and review.get('expires_at')==plan['expires_at'],'host effect not approved')
    require(os.name=='nt','Windows host');verify(plan)
    dest=TASK/'evidence'/('linux-namespace-host-'+plan['request_id']);require(not os.path.lexists(dest),'consumed request; no retry')
    runner=engine() if injected_engine is None else injected_engine
    started=time.monotonic();deadline=started+min(270,plan['expires_at']-time.time());dest.mkdir()
    result=dict(result='FAIL_RETAINED',plan_sha256=expected_plan,mode=plan['mode'],command_state='NOT_DISPATCHED',linux_outcome='UNKNOWN',automatic_retries=0,windows_job_is_not_linux_containment=True)
    try:
        json_new(dest/'intent.json',dict(plan_sha256=expected_plan,review_sha256=expected_review,mode=plan['mode'],state='CONSUMED_BEFORE_DISPATCH'))
        (dest/'metadata').mkdir();verify(plan);argv,seconds=command_argv(plan);remaining=min(seconds,deadline-time.monotonic(),plan['expires_at']-time.time());require(remaining>0,'expiry before dispatch')
        result['command_state']='DISPATCH_OUTCOME_UNKNOWN'
        answer=runner.command(argv,cwd=TASK,environment=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1'),timeout=remaining,directory=dest/'command',output_limit=4*1024**2)
        result.update(command_state='HOST_RESULT_RETURNED',host_receipt=answer.receipt);runner.require(answer)
        value=json.loads(answer.stdout)
        if plan['mode']=='collect_missing':require(value['schema']=='facman.namespace_missing_inputs.v1' and value['result']=='READ_ONLY_OBSERVATION' and value['namespace_effects'] is False,'missing-input response')
        else:require(value['result']=='PASS_SYNTHETIC_NAMESPACE_CONTROLS_ONLY','guardian success absent')
        json_new(dest/'response.json',value)
        result.update(result='PASS_READ_ONLY_COLLECTION' if plan['mode']=='collect_missing' else 'GUARDIAN_REPORTED_PASS_AUDIT_PENDING',linux_outcome='READ_ONLY' if plan['mode']=='collect_missing' else 'GUARDIAN_REPORTED_SUCCESS',qualification=False)
    except BaseException as error:result.update(result='FAIL_RETAINED',error=repr(error))
    finally:
        try:verify(plan)
        except BaseException as error:result.update(result='FAIL_RETAINED',final_source_error=repr(error))
        if time.monotonic()>=deadline or time.time()>=plan['expires_at']:result.update(result='FAIL_RETAINED',final_deadline_error='expired')
        result['elapsed_seconds']=time.monotonic()-started;result['qualification']=False
        json_new(dest/'result.json',result)
    return result
def main():
    p=argparse.ArgumentParser();p.add_argument('--plan',required=True,type=Path);p.add_argument('--review',required=True,type=Path);p.add_argument('--plan-sha256',required=True);p.add_argument('--review-sha256',required=True);a=p.parse_args()
    value=run(a.plan,a.review,a.plan_sha256,a.review_sha256);print(json.dumps(value));return 1 if value['result']=='FAIL_RETAINED' else 0
if __name__=='__main__':raise SystemExit(main())
