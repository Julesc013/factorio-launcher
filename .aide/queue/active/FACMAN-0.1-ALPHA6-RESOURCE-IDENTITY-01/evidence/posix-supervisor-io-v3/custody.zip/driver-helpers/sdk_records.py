"""Bounded, sequential SDK planning/receipt primitives. No effects on import."""
from __future__ import annotations
import hashlib, json, os, re, stat, time, zipfile
from pathlib import Path, PurePosixPath, PureWindowsPath

ROOT = PurePosixPath("/var/lib/facman-development/lp9-20260907-01")
SOURCE_HEAD = "98858a7f4317d4f234ade9bb6a03ced70804abfd"
SOURCE_TREE = "b6d16889a0f444202ebef1747dbdf801f21022d1"
TASK = "/mnt/c/Users/Jules/AppData/Local/FacMan/Development/repositories/factorio-launcher-5db2844e2f29/tasks/facman-0.1-al-d9fce3b03d"
FILE_CAP, TREE_CAP, COUNT_CAP = 64*1024**2, 2*1024**3, 20000
HEX = re.compile("[0-9a-f]{64}")
BOUNDS = dict(command_seconds=480, command_lane_seconds=600, post_seconds=180,
              outer_seconds=900, metadata_seconds=10, cleanup_seconds=5, parallelism=4,
              stream_bytes=4*1024**2, file_bytes=FILE_CAP,
              root_bytes=TREE_CAP, root_entries=COUNT_CAP,
              export_bytes=512*1024**2, export_members=4096)

def require(value, message):
    if not value: raise ValueError(message)

def sha(raw): return hashlib.sha256(raw).hexdigest()

def decode(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate JSON key")
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))

def plain(path):
    path = Path(path)
    require(path.is_absolute() and ".." not in path.parts, "absolute plain path required")
    for item in [*reversed(path.parents), path]:
        info = item.lstat()
        require(not stat.S_ISLNK(info.st_mode) and not getattr(info, "st_file_attributes", 0)&1024,
                "link/reparse input refused")
    return path

def read(path, cap=FILE_CAP):
    path = plain(path)
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    try:
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and before.st_size <= cap, "input type/size")
        with os.fdopen(fd, "rb", closefd=False) as stream: raw = stream.read(cap+1)
        after = os.fstat(fd)
        keys = ("st_dev", "st_ino", "st_size", "st_mtime_ns")
        require(len(raw)<=cap and all(getattr(before,k)==getattr(after,k) for k in keys),
                "input changed during bounded read")
        return raw
    finally: os.close(fd)

def json_new(path, value):
    raw = (json.dumps(value, indent=2, sort_keys=True, allow_nan=False)+"\n").encode()
    require(len(raw)<=32*1024**2, "receipt size")
    with Path(path).open("xb") as output:
        output.write(raw); output.flush(); os.fsync(output.fileno())

def native_path(text):
    if os.name=="nt": return Path(text)
    p=PureWindowsPath(text)
    return Path("/mnt")/p.drive[0].lower()/Path(*p.parts[1:]) if p.drive else Path(text)

def reference(row):
    require(isinstance(row,dict) and set(row)=={"path","bytes","sha256"}, "exact reference shape")
    require(type(row["bytes"]) is int and 0<=row["bytes"]<=FILE_CAP and HEX.fullmatch(row["sha256"]),
            "reference bounds")
    raw=read(native_path(row["path"]))
    require(len(raw)==row["bytes"] and sha(raw)==row["sha256"], "reference mismatch: "+row["path"])
    return raw

def safe_relative(text):
    p=PurePosixPath(text)
    require(isinstance(text,str) and text and not p.is_absolute() and
            "\\" not in text and ".." not in p.parts and p.as_posix()==text and
            all(x not in ("",".") for x in p.parts), "relative member refused")
    return p

FIXTURE_INVENTORY_SHA256 = '4b00f088d8267d0263a8391cf9206d00cc76e67e50b22dadea4eedd0cf9e96a1'
FIXTURE_LINKS = {'fixtures/11-facman_resource_identity_smoke/tmp/facman-resources-5288963200/linux-linked/share/facman/facman.resources': '/var/lib/facman-development/lp9-20260907-01/fixtures/11-facman_resource_identity_smoke/tmp/facman-resources-5288963200/linux-symlink-target', 'fixtures/11-facman_resource_identity_smoke/tmp/facman-resources-5288963200/linux-root-alias': '/var/lib/facman-development/lp9-20260907-01/fixtures/11-facman_resource_identity_smoke/tmp/facman-resources-5288963200/linux-linked', 'fixtures/11-facman_resource_identity_smoke/tmp/facman-resources-5288963200/macos-linked/Contents/Resources/facman.resources': '/var/lib/facman-development/lp9-20260907-01/fixtures/11-facman_resource_identity_smoke/tmp/facman-resources-5288963200/macos-symlink-target', 'fixtures/11-facman_resource_identity_smoke/tmp/facman-resources-5288963200/macos-root-alias': '/var/lib/facman-development/lp9-20260907-01/fixtures/11-facman_resource_identity_smoke/tmp/facman-resources-5288963200/macos-linked', 'fixtures/11-facman_resource_identity_smoke/tmp/facman-resources-5288963200/windows-linked/facman.resources': '/var/lib/facman-development/lp9-20260907-01/fixtures/11-facman_resource_identity_smoke/tmp/facman-resources-5288963200/windows-symlink-target', 'fixtures/11-facman_resource_identity_smoke/tmp/facman-resources-5288963200/windows-root-alias': '/var/lib/facman-development/lp9-20260907-01/fixtures/11-facman_resource_identity_smoke/tmp/facman-resources-5288963200/windows-linked'}

def fixture_link_reference(ref):
    require(ref["sha256"]==FIXTURE_INVENTORY_SHA256,"exact audited fixture inventory")
    value=decode(reference(ref))
    actual={"fixtures/"+x["path"]:x["target"] for x in value["files"]
            if x["kind"]=="symlink" and PurePosixPath(x["target"]).is_absolute()}
    require(actual==FIXTURE_LINKS,"exact six preserved original fixture links")
    return actual

def admit_link(root,path,relative,target_text,preserve_fixture_links):
    target=PurePosixPath(target_text)
    if target.is_absolute():
        require(preserve_fixture_links and root==Path(ROOT) and
                FIXTURE_LINKS.get(relative)==target_text,
                "unapproved absolute symlink")
        # Exact old negative-fixture metadata only: no resolve/read of the target.
        return
    require(path.resolve().is_relative_to(root),"symlink target outside retained root")

def inventory(root, deadline, *, hashes=True, stable=True, exclude_git=False, preserve_fixture_links=False):
    root=plain(root); pending=[root]; rows=[]; total=0
    while pending:
        require(time.monotonic()<deadline, "inventory deadline")
        current=pending.pop()
        try:
            entries=os.scandir(current)
        except FileNotFoundError:
            if stable or current==root: raise
            continue
        with entries as iterator:
            for item in iterator:
                if exclude_git and current==root and item.name==".git": continue
                require(time.monotonic()<deadline, "inventory deadline")
                try: info=item.stat(follow_symlinks=False)
                except FileNotFoundError:
                    if stable: raise
                    continue
                path=Path(item.path); relative=path.relative_to(root).as_posix()
                row=dict(path=relative,mode=stat.S_IMODE(info.st_mode),uid=info.st_uid,gid=info.st_gid)
                if stat.S_ISDIR(info.st_mode):
                    row["kind"]="directory"; pending.append(path)
                elif stat.S_ISLNK(info.st_mode):
                    try:
                        target_text=os.readlink(path)
                    except FileNotFoundError:
                        if stable: raise
                        continue
                    row.update(kind="symlink",target=target_text)
                    # Ordinary installed SONAME links are metadata; never followed by export.
                    admit_link(root,path,relative,row["target"],preserve_fixture_links)
                else:
                    require(stat.S_ISREG(info.st_mode), "special output refused")
                    total+=info.st_size
                    require(info.st_size<=FILE_CAP, "single-file limit")
                    row.update(kind="file",bytes=info.st_size)
                    if hashes:
                        raw=read(path)
                        require(len(raw)==info.st_size, "inventory size changed")
                        row["sha256"]=sha(raw)
                rows.append(row)
                require(len(rows)<=COUNT_CAP and total<=TREE_CAP, "sampled whole-root bound")
    return sorted(rows,key=lambda x:x["path"])

def validate_rows(rows):
    require(isinstance(rows,list) and len(rows)<=COUNT_CAP,"row count")
    seen=set()
    for row in rows:
        safe_relative(row["path"]); require(row["path"] not in seen,"duplicate row"); seen.add(row["path"])
        require(row["kind"] in ("directory","file","symlink"),"row type")
        for key in ("mode","uid","gid"): require(type(row[key]) is int,"integer metadata")
        if row["kind"]=="file":
            require(type(row["bytes"]) is int and 0<=row["bytes"]<=FILE_CAP and
                    HEX.fullmatch(row["sha256"]),"file row identity")
    require(sum(r.get("bytes",0) for r in rows)<=TREE_CAP,"row total")
    return {r["path"]:r for r in rows}

def compare_original(before, after):
    old,new=validate_rows(before),validate_rows(after)
    changes=[]
    for name,row in old.items():
        if new.get(name)!=row:
            require(name=="native/install_manifest.txt" and new.get(name,{}).get("kind")=="file",
                    "unapproved original mutation: "+name)
            require(row["kind"]=="file" and all(new[name][k]==row[k] for k in ("mode","uid","gid")),"manifest metadata change")
            changes.append(name)
    for name,row in new.items():
        if name not in old:
            require(name in ("native/install_manifest.txt",".sdk-run-owner.v1.json","sdk-parent") or
                    name.startswith("sdk-parent/"),"unapproved added path: "+name)
            if name=="native/install_manifest.txt": require(row["kind"]=="file" and row["uid"]==row["gid"]==65534 and row["mode"]==0o600,"manifest type/owner/mode")
            if name==".sdk-run-owner.v1.json": require(row["kind"]=="file" and row["uid"]==row["gid"]==0 and row["mode"]==0o400,"SDK intent metadata")
            if name=="sdk-parent": require(row["kind"]=="directory" and row["uid"]==row["gid"]==65534 and row["mode"]==0o700,"SDK parent metadata")
    return dict(allowed_build_change=changes, install_manifest_before=old.get("native/install_manifest.txt"),
                install_manifest_after=new.get("native/install_manifest.txt"))

def validate_plan(plan, *, ready=True):
    require(plan["schema"]=="facman.linux_installed_sdk_effect_plan.v1","plan schema")
    require(plan["source_commit"]==SOURCE_HEAD and plan["source_tree"]==SOURCE_TREE,"source checkpoint")
    require(plan["root"]==str(ROOT) and plan["source_root"]==TASK+"/lp9/source","fixed owned roots")
    require(plan["work_root"]==str(ROOT/"sdk-parent/retained-sdk"),"fresh SDK work path")
    require(plan["bounds"]==BOUNDS,"reviewed finite bounds")
    require(plan["identity"]==dict(uid=65534,gid=65534,groups=[]),"worker identity")
    require(plan["provider_mode"]=="source" and plan["provider_linkage"]=="shared","bounded SDK lane")
    require(plan["qualification"]==dict(installed_shared_sdk_consumption=False,
            provider_adoption=False,hosted=False,release=False,game=False,human=False),"proposal scope")
    require(plan["bindings_file"]=="bindings.json","fixed local bindings")
    require(plan["windows_evidence"].endswith("\\evidence\\linux-installed-sdk-lp9-run-01"),
            "fixed evidence child")
    if ready:
        require(plan["execution_authorized"] is True and plan["binding_complete"] is True,
                "unresolved proposal is not executable")
        require(HEX.fullmatch(plan["bindings_sha256"] or ""),"final binding digest absent")
        require(len(plan["script_hashes"])==5,"exact five runner inputs")
    return plan

def export_selected(root, destination, rows, deadline, *, quiescent):
    if not quiescent:
        return dict(status="SKIPPED_NOT_QUIESCENT",stable_export_attempted=False)
    selected=[]
    for row in rows:
        name=row["path"]
        if row["kind"]!="file": continue
        if name.startswith("sdk-parent/") or name in (".sdk-run-owner.v1.json","native/install_manifest.txt"):
            selected.append(row)
    require(len(selected)<=4096 and sum(r["bytes"] for r in selected)<=512*1024**2,"export bounds")
    archive=Path(destination)/"sdk-custody.zip"; members=[]
    with zipfile.ZipFile(archive,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=6) as output:
        for row in selected:
            require(time.monotonic()<deadline,"export deadline")
            raw=read(root/row["path"])
            require(len(raw)==row["bytes"] and sha(raw)==row["sha256"],"snapshot changed before export")
            output.writestr(row["path"],raw); members.append(row)
    # Each member originated from the same captured bytes used for this map.
    return dict(status="PASS",stable_export_attempted=True,archive=str(archive),
                archive_bytes=archive.stat().st_size,
                members=members,symlinks="mapped only; not dereferenced",
                original_build="separate immutable build archive/reference retained; not repacked")
