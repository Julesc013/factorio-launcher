# POSIX V3 integration bookkeeping proposal

This external proposal applies no repository changes. Its base is exactly
5f3ad4500e01a0b15c15c522e37ad62f753099eb / tree
0d71e56e859447dea121f6a85299ec63c4652cfc. The worktree/index remain clean and
unchanged. The five reviewed V3 source files and unchanged earlier lifecycle
oracle are copied byte-for-byte, with no new production implementation.

The ten-path standalone view adds four bookkeeping files: native CMake,
test-impact policy, the existing resource WorkUnit ExecPlan and a focused
architecture note. No task status, queue, canonical plan, generated TODO,
provider pin, ABI or publication gate changes are proposed.

The separate 36-path union is a computed tree and three readable shared-file
views. It preserves the resource V3 27-path candidate and its two admission
files, including the exact additional resource-inspection schema permission.
Only native CMake, test-impact and ExecPlan need explicit additive union.
The resource's other 25 payload files remain byte-identical. Its app/resource
CMake changes are not touched. The union does not transfer either lane's
qualification to the other or authorize the union's application/build.

## Registration and selector choice

UNIX CMake adds two deterministic default tests and one explicit anonymous
socket test using the pump binary. The socket command passes --native-sockets
and has its own integration/platform labels. All three have a ten-second CTest
timeout. Default tests share actual production templates; the adapter is already
compiled through the existing platform target after source application.

The two default targets are added to the existing configuration-optional fast
list. The fast graph accepts their absence on Windows and includes them on UNIX.
The affected runner currently builds literal module targets before executing
their exact-name CTest regex; it does not use configuration-optional filtering.
The socket registration also has no separate executable target. A narrow
process-source module therefore uses the existing '*' vocabulary, preserving
all other modules and fast required/optional rules. ROOT accepted this bounded
choice instead of expanding the repair into a runner refactor.

That all-native selection is a future validation obligation. It does not grant
permission for new process/session fixtures and does not claim that the full
suite was executed. Existing tests/native/CMake changes already select all
native tests under current policy. A future independently scoped runner change
could narrow conditional affected selection.

## Actual evidence and next integration

ROOT's independent actual review
6761a5d3540391fa68e62b19698b8de19dbe7f662903daa5e547f4a6fd44bb2a
verified all ten exact outcomes, 21 source copies, both causal mutants,
33 native archive files / 52 inventory rows, five dependency lists against
368 inputs and 91 original evidence streams. The two exit1 results were the
required mutant failures. The adapter ET_REL object was never executed.
Anonymous AF_UNIX controls did not fork a child or bind/connect/listen.

The current source/selector/format checks are source-only. No CMake configure,
compiler or native command ran for this bookkeeping. Fresh integrated-tree
validation, process/session behavior, Apple, full current platform/package,
hosted, human/game and release gates remain open. Caller callback-return and
exclusive wait/SIGCHLD premises remain explicit.

Review the exact standalone and union manifests/diffs before applying either.
Preserve source payload hashes, use normal task/Git admission, and bind the final
staged/committed tree before new effects. The earlier frozen source/driver,
initial reviewer roster mistake, original audits and native proof archives are
unchanged. No automatic cleanup or ref mutation is included.
