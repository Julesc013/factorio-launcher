
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time,tomllib,zipfile
sys.dont_write_bytecode=True
wt=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\worktrees\task-facman-resource-identity-01')
ev=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-d9fce3b03d\evidence')
os.environ.update(GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8')
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):
 p=subprocess.run(['git',*args],cwd=wt,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if p.returncode:raise RuntimeError((args,p.stderr.decode(errors='replace')))
 return p.stdout
def tree(ref):
 result={}
 for entry in git('ls-tree','-r','-z',ref).split(b'\0'):
  if entry:
   meta,name=entry.split(b'\t');mode,typ,oid=meta.split()
   result[name.decode('utf-8')]=(mode.decode(),oid.decode())
 return result
def index():
 result={}
 for entry in git('ls-files','--stage','-z').split(b'\0'):
  if entry:
   meta,name=entry.split(b'\t');mode,oid,stage=meta.split()
   assert stage==b'0'
   result[name.decode('utf-8')]=(mode.decode(),oid.decode())
 return result
def tree_digest(entries):
 root={}
 for path,value in entries.items():
  cursor=root;parts=path.split('/')
  for part in parts[:-1]:cursor=cursor.setdefault(part,{})
  cursor[parts[-1]]=value
 def digest(node):
  data=b''
  for name,value in sorted(node.items(),key=lambda item:(item[0]+('/' if isinstance(item[1],dict) else '')).encode('utf-8')):
   mode,oid=('40000',digest(value)) if isinstance(value,dict) else value
   data+=mode.encode()+b' '+name.encode('utf-8')+b'\0'+bytes.fromhex(oid)
  return hashlib.sha1(b'tree '+str(len(data)).encode()+b'\0'+data).hexdigest()
 return digest(root)
def document(ref,path,parser):return parser(git('show',ref+':'+path).decode('utf-8'))
head=git('rev-parse','HEAD').decode().strip();incoming=git('rev-parse','MERGE_HEAD').decode().strip()
assert head=='1e450ad2ea449b3363799bdbe107e898f4663e58'
assert incoming=='cbdb6581ede9a7b2b80a79a0e77b67b988cea617'
base=git('merge-base',head,incoming).decode().strip();assert base=='6f8ece1d343400f314e054183beee106bac46358'
a,b,c=tree(base),tree(head),tree(incoming);staged=index();index_before=sha(git('ls-files','--stage','-z'))
assert tree_digest(staged)=='f86cc4a249684a94f754994908ccf467c9db6c33'
simple=[];both=[];errors=[]
for n in sorted(set(a)|set(b)|set(c)|set(staged)):
 av,bv,cv,iv=(x.get(n) for x in [a,b,c,staged])
 if bv==cv:expected=bv
 elif av==bv:expected=cv
 elif av==cv:expected=bv
 else:both.append(n);continue
 simple.append(n)
 if iv!=expected:errors.append(n)
assert not errors,errors
candidate_raw=(ev/'resource-dev-sync-candidate.json').read_bytes()
assert sha(candidate_raw)=='2ec9042e5b31da6c9030bb548330847e55a161cafd175227c4a9a59aa380ca9f'
candidate=json.loads(candidate_raw)
preserved=candidate['preserved_resource_paths']
assert len(preserved)==32
for n,oid in preserved.items():assert staged[n]==b[n] and staged[n][1]==oid,n
impact='contracts/policy/test_impact.v1.json'
oi,ti,ii=[document(ref,impact,json.loads) for ref in ['HEAD','MERGE_HEAD','']]
assert ii['modules']==[oi['modules'][0]]+ti['modules']
assert {k:v for k,v in ii.items() if k!='modules'}=={k:v for k,v in ti.items() if k!='modules'}
absent=object()
def merge(a,b,c):
 if b==c:return b
 if a==b:return c
 if a==c:return b
 if all(isinstance(x,dict) for x in (a,b,c)):
  return {k:merge(a.get(k,absent),b.get(k,absent),c.get(k,absent)) for k in a.keys()|b.keys()|c.keys()}
 if all(isinstance(x,list) for x in (a,b,c)) and len(a)==len(b)==len(c):return [merge(*v) for v in zip(a,b,c)]
 raise AssertionError('Non-trivial semantic conflict')
plan_path='release/index/plan.v1.toml'
pa,pb,pc,pi=[document(ref,plan_path,tomllib.loads) for ref in [base,'HEAD','MERGE_HEAD','']]
expected_plan=merge(pa,pb,pc)
summary=next(x for x in expected_plan['later'] if x['id']=='FACMAN-ALPHA-FACTORY-01')
bad='\u00e2\u20ac\u201d';assert summary['summary'].count(bad)==2
summary['summary']=summary['summary'].replace(bad,'\u2014')
assert expected_plan==pi
active=sorted(x['id'] for x in pi['workunit'] if x.get('status')=='active')
expected_active=sorted(['FACMAN-0.1-ALPHA6-LAB-INPUT-REGISTRY-01','FACMAN-0.1-ALPHA6-RESOURCE-IDENTITY-01','FACMAN-0.1-ALPHA6-NATIVE-CONTROL-GALLERY-01'])
assert active==expected_active,active
completed=['FACMAN-0.1-ALPHA6-NATIVE-INTEGRATION-OWNERSHIP-01','FACMAN-0.1-ALPHA6-WORKSPACE-MIGRATION-RECOVERY-01']
for name in completed:assert next(x for x in pi['workunit'] if x['id']==name)['status']=='complete'
assert pi['execution_programme']['public_publication_authorized'] is True
assert pi['execution_programme']['human_acceptance_may_be_synthesized'] is False
assert pi['execution_programme']['publication_scope']==pb['execution_programme']['publication_scope']
sys.path.insert(0,str(wt))
from tools.aide_queue_records import read_queue_records,render_queue_index,validate_queue_index
records=read_queue_records(wt/'.aide/queue')
assert not validate_queue_index(wt/'.aide/queue',records)
assert sorted(x.id for x in records if x.lifecycle_state=='active_automated')==expected_active
for name in completed:assert next(x for x in records if x.id==name).lifecycle_state=='closed'
assert git('show',':.aide/queue/index.yaml').decode()==render_queue_index(wt/'.aide/queue',records)
conflicts=ev/'resource-dev-sync-conflict-inputs.zip'
with zipfile.ZipFile(conflicts) as z:
 names=z.namelist();assert len(names)==len(set(names))==28
 paths=[n.removeprefix('conflicted/') for n in names if n.startswith('conflicted/')]
 assert len(paths)==7
 for n in paths:
  for stage,ref in [('stage1',base),('stage2',head),('stage3',incoming)]:
   assert z.read(stage+'/'+n)==git('show',ref+':'+n),(stage,n)
def working_snapshot():
 values={}
 for n in sorted(set(staged)|set(a)|set(b)|set(c)):
  if staged.get(n)!=a.get(n) or n in preserved or n in both:
   p=wt/n
   if p.is_file():values[n]=sha(p.read_bytes())
   elif not p.exists():values[n]=None
 return values
raw_before=working_snapshot()
line_custody=[]
for n,digest in raw_before.items():
 if digest is None:assert n not in staged;continue
 data=(wt/n).read_bytes()
 expected=git('cat-file','blob',staged[n][1])
 if data!=expected:
  assert data.replace(b'\r\n',b'\n')==expected,(n,'non-line-ending working/index drift')
  line_custody.append({'path':n,'raw_sha256':sha(data),'index_sha256':sha(expected)})
validation_raw=(ev/'resource-dev-sync-validation.json').read_bytes();vr=json.loads(validation_raw)
assert vr['result']=='PASS'
for record in vr['commands']:
 assert record['exit_code']==0
 assert sha((ev/('resource-dev-sync-'+record['name']+'.txt')).read_bytes())==record['sha256']
commands=[]
for name,args in [('plan',[sys.executable,'tools/generate_plan_views.py','--check']),('state',[sys.executable,'tools/project_state.py','--validate']),('diff',['git','diff','--cached','--check'])]:
 log=ev/('native-review-resource-sync-'+name+'.txt');assert not log.exists()
 start=time.monotonic()
 with log.open('wb') as f:run=subprocess.run(args,cwd=wt,stdout=f,stderr=subprocess.STDOUT,timeout=120)
 commands.append({'name':name,'command':args,'exit':run.returncode,'seconds':time.monotonic()-start,'log':log.name,'sha256':sha(log.read_bytes())})
 assert run.returncode==0
raw_after=working_snapshot();index_after=sha(git('ls-files','--stage','-z'))
assert index_before==index_after and raw_before==raw_after and staged==index()
receipt={'schema':'facman.resource_dev_sync_independent_review.v1','reviewer':'/root/native_ownership','result':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'incoming':incoming,'merge_base':base,'index_tree':tree_digest(staged),'index_before_sha256':index_before,'index_after_sha256':index_after,'source_before':raw_before,'source_after':raw_after,'source_index_unchanged':raw_before==raw_after and index_before==index_after,'mechanical_three_way_paths':len(simple),'unexpected_mechanical_results':errors,'both_changed_metadata_paths':both,'preserved_resource_paths':preserved,'complete_conflict_archive_sha256':sha(conflicts.read_bytes()),'conflict_stages_verified':21,'impact_union':'exact checkpoint resource module prepended to unchanged incoming modules; every other incoming impact field unchanged','canonical_plan':'exact independent recursive three-way semantic union plus the disclosed two-em-dash encoding correction','active_workunits':active,'canonical_complete_queue_closed':completed,'publication_authority':'conditional qualified alpha/Beta1 authorization preserved; human synthesis false and other qualification gates unchanged','line_ending_working_index_custody':line_custody,'author_validation_receipt_sha256':sha(validation_raw),'author_validation':'211 tests across 13 Python modules and strict/plan/state/diff passed before encoding-only correction; logs independently hashed','independent_commands':commands,'native_rerun':False,'native_rerun_reason':'All 32 resource source/tool/test/architecture paths remain exact reviewed checkpoint; incoming gallery/runtime-independent source is retained exactly from its qualified dev commit.','findings':[],'closed_low_severity_finding':'Pre-existing alpha-factory mojibake corrected only at its canonical summary and generated projection.','scope_limits':['This review authorizes the resolved integration candidate, not packaged resource qualification.','Incoming lab and native/workspace closeouts remain their existing bounded source/evidence authority.']}
p=ev/'native-review-resource-sync-final.json';assert not p.exists();p.write_bytes((json.dumps(receipt,indent=2,sort_keys=True)+'\n').encode())
print(json.dumps({'result':'PASS','receipt':str(p),'sha256':sha(p.read_bytes()),'index_tree':tree_digest(staged),'verified_paths':len(simple),'preserved_resource_paths':len(preserved),'line_custody_paths':len(line_custody)},indent=2))

