from pathlib import Path
import hashlib,json,subprocess,zipfile,datetime
wt=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\worktrees\task-facman-resource-identity-01')
ev=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-d9fce3b03d\evidence')
paths=['tools/resource_package_proof.py','tools/resource_package_cases.py','tests/test_resource_package_proof.py','contracts/schema/release/facman_resource_package_proof.v1.schema.json']
sha=lambda b:hashlib.sha256(b).hexdigest()
source={p:{'bytes':(wt/p).stat().st_size,'sha256':sha((wt/p).read_bytes())} for p in paths}
validation=json.loads((ev/'resource-package-frozen-validation.json').read_bytes())
assert validation['result']=='PASS'
assert validation['source_before']==validation['source_after']=={p:v['sha256'] for p,v in source.items()}
for record in validation['commands']:assert sha((ev/record['log']).read_bytes())==record['sha256']
native_log=(ev/'resource-package-frozen-tests.txt').read_text()
native_root=Path(native_log.split('native_fixture_root=')[-1].strip())
assert native_root.is_relative_to(ev.parent/'t')
receipts=[native_root/'windows-portable-resource-package.v1.json',native_root/'windows-installed-stage-resource-package.v1.json',native_root/'failed.json']
artifacts={}
native=[]
for path in receipts:
 raw=path.read_bytes();value=json.loads(raw)
 artifacts['native/'+path.name]=raw
 native.append({'path':str(path),'sha256':sha(raw),'status':value['status'],'package_mode':value['package_mode'],'cases':len(value['cases']),'commands':len(value['commands']),'fixture_only':True})
 for row in value['artifacts']:
  source_path=native_root/row['path']
  assert source_path.is_relative_to(native_root) and '..' not in Path(row['path']).parts
  data=source_path.read_bytes()
  assert len(data)==row['bytes'] and sha(data)==row['sha256']
  artifacts['native/'+row['path']]=data
for name in ['resource-package-helper-initial-tests.txt','resource-package-helper-native-tests.txt','resource-package-final-native-tests.txt','resource-package-final-source-quality.txt','resource-package-final-local-validation.json','resource-package-frozen-tests.txt','resource-package-frozen-quality.txt','resource-package-frozen-validation.json','resource-package-frozen-validation.py']:
 p=ev/name
 if p.exists():artifacts['validation/'+name]=p.read_bytes()
for kind,data in [('source',source),('evidence',{k:{'bytes':len(v),'sha256':sha(v)} for k,v in artifacts.items()})]:
 p=ev/('resource-package-helper-'+kind+'-manifest.json')
 assert not p.exists();p.write_bytes((json.dumps(data,indent=2,sort_keys=True)+'\n').encode())
 z=ev/('resource-package-helper-'+kind+'.zip')
 assert not z.exists()
 with zipfile.ZipFile(z,'x',compression=zipfile.ZIP_DEFLATED) as out:
  if kind=='source':
   for n in sorted(source):out.writestr(n,(wt/n).read_bytes())
  else:
   for n,raw in sorted(artifacts.items()):out.writestr(n,raw)
  out.writestr('manifest.json',p.read_bytes())
 with zipfile.ZipFile(z) as check:
  assert check.testzip() is None
patch=b''
for name in sorted(paths):
 p=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',name],cwd=wt,capture_output=True)
 assert p.returncode==1
 patch+=p.stdout
p=ev/'resource-package-helper.patch';assert not p.exists();p.write_bytes(patch)
packet={'schema':'facman.resource_package_helper_review.v1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt,text=True).strip(),'source':source,'source_aggregate_sha256':sha(json.dumps(source,sort_keys=True,separators=(',',':')).encode()),'patch_sha256':sha(patch),'source_zip_sha256':sha((ev/'resource-package-helper-source.zip').read_bytes()),'evidence_zip_sha256':sha((ev/'resource-package-helper-evidence.zip').read_bytes()),'evidence_payload_records':len(artifacts),'validation_sha256':sha((ev/'resource-package-frozen-validation.json').read_bytes()),'native_receipts':native,'native_input_sha256':{'cli':validation['native_cli_sha256'],'fixture':validation['native_fixture_sha256']},'result':'PASS','tests':'14 tests, zero skips, actual Windows native fixture portable and installed_stage plus damaged-manifest fail receipt; source/schema quality checks pass','scope':'Only four assigned helper/cases/test/schema files. No index/branch/commit/remote/workflow or other source edits by this worker.','limitations':['Input provenance stays supplied_path_not_producer_attested; fixture records are not produced-asset qualification.','Fresh Windows/Linux/macOS produced portable/installed_stage execution is still required through ROOT-owned workflow/companion assembly.','Bounded path/file observations and exclusive file creation do not confer atomic namespace/cleanup authority.','No recursive cleanup; all private native fixture copies, exports and failed outputs remain in marker-owned task storage.']}
out=ev/'resource-package-helper-review.json';assert not out.exists();out.write_bytes((json.dumps(packet,indent=2,sort_keys=True)+'\n').encode())
print(json.dumps({'packet':str(out),'sha256':sha(out.read_bytes()),'source_aggregate':packet['source_aggregate_sha256'],'patch':packet['patch_sha256'],'native':native,'artifacts':len(artifacts)},indent=2))

