from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path.cwd()
ev=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-d9fce3b03d\evidence')
paths=['tools/resource_package_proof.py','tools/resource_package_cases.py','tests/test_resource_package_proof.py','contracts/schema/release/facman_resource_package_proof.v1.schema.json']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={name:sha(root/name) for name in paths}
checks=[('tests',[sys.executable,'-m','unittest','-v','test_resource_package_proof']),
 ('quality',[sys.executable,'-c',"from tools import source_format_check as f,json_contract as j;from pathlib import Path;import json;paths="+repr(paths)+";problems=sum((f.validate_file(Path(p),p) for p in paths),[])+j.supported_schema_problems(j.load_schema(Path(paths[-1])));print(json.dumps(problems));raise SystemExit(bool(problems))"])]
commands=[]
for name,args in checks:
 log=ev/('resource-package-frozen-'+name+'.txt')
 assert not log.exists()
 started=time.monotonic()
 with log.open('wb') as out:run=subprocess.run(args,stdout=out,stderr=subprocess.STDOUT,timeout=240)
 commands.append({'name':name,'args':args,'exit':run.returncode,'seconds':time.monotonic()-started,'log':log.name,'sha256':sha(log)})
 print(name,run.returncode,flush=True)
after={name:sha(root/name) for name in paths}
receipt={'result':'PASS' if before==after and all(x['exit']==0 for x in commands) else 'FAIL','head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_before':before,'source_after':after,'source_unchanged':before==after,'commands':commands,'fixture_only':True,'native_cli_sha256':sha(Path(os.environ['FACMAN_RESOURCE_PROOF_CLI'])),'native_fixture_sha256':sha(Path(os.environ['FACMAN_RESOURCE_PROOF_FIXTURE']))}
p=ev/'resource-package-frozen-validation.json'
assert not p.exists();p.write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print(p,sha(p),flush=True)
raise SystemExit(0 if receipt['result']=='PASS' else 1)

