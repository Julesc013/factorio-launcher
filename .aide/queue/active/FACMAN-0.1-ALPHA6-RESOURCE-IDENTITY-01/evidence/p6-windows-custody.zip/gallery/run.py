import hashlib,json,os,subprocess,sys,time,zipfile
from pathlib import Path
from xml.sax.saxutils import escape
REPO=Path(r"C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\worktrees\task-facman-resource-identity-01")
TASK=Path(r"C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-0-36077e5ebb")
EV=TASK/"evidence/package-97e/gallery-p6"
ASSET=Path('C:\\Users\\Jules\\AppData\\Local\\FacMan\\Development\\repositories\\factorio-launcher-5db2844e2f29\\tasks\\facman-0.1-al-d9fce3b03d\\dist-p6\\FacMan-0.1.0-alpha.5-windows-x64-portable.zip')
sys.path.insert(0,str(REPO))
from tools import control_gallery_fixtures,winforms_build
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*a): return subprocess.check_output(["git",*a],cwd=REPO,timeout=30).decode().strip()
plan=json.loads((EV/"plan.json").read_bytes())
def source_check():
 assert git("rev-parse","HEAD")==plan["source_head"]
 assert git("rev-parse","HEAD^{tree}")==plan["source_tree"]
 assert not git("status","--porcelain=v1","--untracked-files=all")
 for r in plan["source_files"]: assert sha(REPO/r["path"])==r["sha256"]
 assert sha(ASSET)==plan["asset_sha256"]
source_check()
RUN=TASK/"pgp6";RUN.mkdir(exist_ok=False)
records=[]
def command(label,args,timeout=120):
 start=time.monotonic()
 row={"label":label,"args":args,"budget_seconds":timeout,"dispatched":True}
 try:
  p=subprocess.run(args,cwd=RUN,capture_output=True,timeout=timeout,env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1",TEMP=str(RUN/"t"),TMP=str(RUN/"t")))
  out,err=p.stdout,p.stderr;row.update(exit_code=p.returncode,timed_out=False)
 except subprocess.TimeoutExpired as e:
  out,err=e.stdout or b"",e.stderr or b"";row.update(exit_code=None,timed_out=True)
 finally:
  row["seconds"]=round(time.monotonic()-start,6)
 for channel,data in (("stdout",out),("stderr",err)):
  f=EV/(label+"."+channel);f.write_bytes(data)
  row[channel]={"path":f.name,"bytes":len(data),"sha256":sha(f)}
 records.append(row)
 (EV/"commands.json").write_text(json.dumps(records,indent=2)+"\n",encoding="utf-8")
 print(label,row.get("exit_code"),row["seconds"],flush=True)
 assert row.get("exit_code")==0 and not row["timed_out"],label
try:
 (RUN/"t").mkdir();(RUN/"input").mkdir();(RUN/"bin").mkdir()
 with zipfile.ZipFile(ASSET) as z:
  assert z.namelist().count("FacMan.exe")==1
  blob=z.read("FacMan.exe")
 product=RUN/"input/FacMan.exe";product.write_bytes(blob);digest=sha(product)
 wrapper=RUN/"PackagedGalleryProbe.cs"
 wrapper.write_text("""using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Web.Script.Serialization;
using FacMan.WinForms;
internal static class PackagedGalleryProbe {
 [STAThread] private static int Main(string[] args) {
  if(args.Length != 4) return 2;
  Assembly assembly=typeof(C1ShellForm).Assembly;
  string location=Path.GetFullPath(assembly.Location);
  string expected=Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"FacMan.exe"));
  string digest;
  using(var stream=File.OpenRead(location))
  using(var hash=SHA256.Create()) digest=String.Concat(hash.ComputeHash(stream).Select(b=>b.ToString("x2")));
  if(!String.Equals(location,expected,StringComparison.OrdinalIgnoreCase) || digest!=args[0]) throw new InvalidOperationException("Packaged assembly binding mismatch");
  File.WriteAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"assembly-binding.json"),
   new JavaScriptSerializer().Serialize(new { location=location, sha256=digest, assembly=assembly.FullName }));
  return (int)typeof(GalleryHarness).GetMethod("Main",BindingFlags.NonPublic|BindingFlags.Static).Invoke(null,new object[]{args.Skip(1).ToArray()});
 }
}
""",encoding="utf-8")
 refs=["System","System.Core","System.Drawing","System.Web.Extensions","System.Windows.Forms","UIAutomationClient","UIAutomationTypes"]
 project=RUN/"PackagedGallery.csproj"
 project.write_text('<Project ToolsVersion="15.0" xmlns="http://schemas.microsoft.com/developer/msbuild/2003"><PropertyGroup><OutputType>Exe</OutputType><TargetFrameworkVersion>v4.8</TargetFrameworkVersion><AssemblyName>FacMan.PackagedGallery</AssemblyName><StartupObject>PackagedGalleryProbe</StartupObject><PlatformTarget>x64</PlatformTarget></PropertyGroup><ItemGroup>'+''.join('<Reference Include="'+n+'" />' for n in refs)+'<Reference Include="FacMan"><HintPath>'+escape(str(product))+'</HintPath><Private>True</Private></Reference><Compile Include="'+escape(str(REPO/"tests/winforms_control_gallery/GalleryHarness.cs"))+'" /><Compile Include="PackagedGalleryProbe.cs" /></ItemGroup><Import Project="$(MSBuildToolsPath)\\Microsoft.CSharp.targets" /></Project>',encoding="utf-8")
 command("build",[winforms_build.msbuild_executable(),str(project),"/p:Configuration=Release","/p:Platform=x64","/m:1",f"/p:OutputPath={RUN/'bin'}{os.sep}",f"/p:IntermediateOutputPath={RUN/'obj'}{os.sep}"])
 assert sha(RUN/"bin/FacMan.exe")==digest
 fixtures=RUN/"fixtures";fixtures.mkdir();fixture_rows=[]
 for name,case in control_gallery_fixtures.cases().items():
  p=fixtures/(name+".json");p.write_bytes((json.dumps(case,sort_keys=True,indent=2,ensure_ascii=False)+"\n").encode())
  fixture_rows.append({"path":p.relative_to(RUN).as_posix(),"sha256":sha(p)})
 command("gallery",[str(RUN/"bin/FacMan.PackagedGallery.exe"),digest,"--check",str(fixtures),str(RUN/"evidence")])
 binding=json.loads((RUN/"bin/assembly-binding.json").read_bytes())
 assert binding["sha256"]==digest
 assert Path(binding["location"]).samefile(RUN/"bin/FacMan.exe")
 receipt=json.loads((RUN/"evidence/control-gallery.v1.json").read_bytes())
 assert receipt["result"]=="PASS" and receipt["live_transport_constructed"] is False
 assert receipt["human_experience"]=="pending"
 assert len(receipt["rows"])==len(fixture_rows)*4
 assert sha(product)==sha(RUN/"bin/FacMan.exe")==digest
 source_check()
 result={"schema":"facman.packaged-winforms-gallery-local-result.v1","result":"PASS","source_head":plan["source_head"],"source_tree":plan["source_tree"],"asset":{"path":str(ASSET),"sha256":sha(ASSET)},"package_member":{"path":"FacMan.exe","bytes":len(blob),"sha256":digest},"runtime_assembly":binding,"commands":records,"fixtures":fixture_rows,"assertions":receipt["assertions"],"render_cells":len(receipt["rows"]),"constrained_cells":len(receipt["constrained_rows"]),"actual_high_contrast":receipt["actual_high_contrast"],"raw_receipt":{"path":str(RUN/"evidence/control-gallery.v1.json"),"sha256":sha(RUN/"evidence/control-gallery.v1.json")},"source_unchanged":True,"limits":[plan["qualification_ceiling"],"Product assembly bytes come directly from package; gallery host and wrapper are separate test executables.","Scale simulation and actual host palette only; no host setting changes."]}
 (EV/"result.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
 print(json.dumps({"result":"PASS","assertions":result["assertions"],"render_cells":result["render_cells"],"receipt":str(EV/"result.json"),"sha256":sha(EV/"result.json")}),flush=True)
except BaseException as e:
 p=EV/"failure.json"
 p.write_text(json.dumps({"result":"FAIL","error":repr(e),"commands":records,"effects_retained":str(RUN)},indent=2)+"\n",encoding="utf-8")
 raise
