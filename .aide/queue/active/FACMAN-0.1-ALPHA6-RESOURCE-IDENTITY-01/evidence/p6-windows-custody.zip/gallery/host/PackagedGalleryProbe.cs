using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Web.Script.Serialization;
using FacMan.WinForms;
internal static class PackagedGalleryProbe {
 [STAThread] private static int Main(string[] args) {
  if(args.Length != 4) return 2;
  Assembly assembly=typeof(C1ShellForm).Assembly;
  string location=Path.GetFullPath(assembly.Location);
  string expected=Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"FacMan.exe"));
  string digest;
  using(var stream=File.OpenRead(location))
  using(var hash=SHA256.Create()) digest=String.Concat(hash.ComputeHash(stream).Select(b=>b.ToString("x2")));
  if(!String.Equals(location,expected,StringComparison.OrdinalIgnoreCase) || digest!=args[0]) throw new InvalidOperationException("Packaged assembly binding mismatch");
  File.WriteAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"assembly-binding.json"),
   new JavaScriptSerializer().Serialize(new { location=location, sha256=digest, assembly=assembly.FullName }));
  return (int)typeof(GalleryHarness).GetMethod("Main",BindingFlags.NonPublic|BindingFlags.Static).Invoke(null,new object[]{args.Skip(1).ToArray()});
 }
}
