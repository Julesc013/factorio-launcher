import ctypes,hashlib,json,os,subprocess,sys,time
from pathlib import Path
R=Path("C:\\Users\\Jules\\AppData\\Local\\FacMan\\Development\\repositories\\factorio-launcher-5db2844e2f29\\worktrees\\task-facman-resource-identity-01");T=Path("C:\\Users\\Jules\\AppData\\Local\\FacMan\\Development\\repositories\\factorio-launcher-5db2844e2f29\\tasks\\facman-0.1-al-d9fce3b03d");Base=Path("C:\\Users\\Jules\\AppData\\Local\\FacMan\\Development\\repositories\\factorio-launcher-5db2844e2f29\\tasks\\task-facman-0-36077e5ebb")/"evidence/package-97e/startup-remediation/clean-p6";E=Base/"proof-replay";E.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(["git","-c","safe.directory="+str(R),*a],cwd=R,timeout=30).decode().strip()
def source():return {"commit":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),"clean":not bool(git("status","--porcelain=v1","--untracked-files=all"))}
original=json.loads((Base/"result.json").read_bytes());expected=original["source"];assert source()==expected
assert sha(Base/"result.json")=="e3b9b7a830ddffbe8bba4c32e433b4b0c2bac5d1beb8ac037a7abcb0cf7a5f02"
assert sha(Base/"cwd-diagnosis/result.json")=="2b6292757b32bb659795ff968d3127c7b7b0e7ccb8d5a947d90bca2b93956e4c"
assert all(r["exit_code"]==0 for r in original["commands"][:-1]) and original["commands"][-1]["name"]=="portable-proofs"
stage=T/"packages-p6/windows_product_x64";N=T/"native-p6";D=T/"dist-p6";Setup=T/"setup-p6";Proof=T/"evidence/rp6"
assert not Setup.exists() and not Proof.exists();assert Setup.resolve().parent==T.resolve() and Proof.resolve().parent==(T/"evidence").resolve()
def inventory():return [{"path":p.relative_to(stage).as_posix(),"bytes":p.stat().st_size,"sha256":sha(p)} for p in sorted(stage.rglob("*")) if p.is_file()]
before=inventory();portable,=D.glob("FacMan-*-windows-x64-portable.zip");portable_sha=sha(portable)
version=portable.name[len("FacMan-"):-len("-windows-x64-portable.zip")];setup=Setup/("FacMan-"+version+"-windows-x64-setup.exe")
env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1",PYTHONPATH=str(R),FACMAN_TASK_ROOT=str(T),FACMAN_TASK_ID="FACMAN-0.1-ALPHA6-RESOURCE-IDENTITY-01")
buf=ctypes.create_unicode_buffer(32768);assert ctypes.windll.kernel32.GetShortPathNameW(str(T/"t"),buf,len(buf));assert Path(buf.value).samefile(T/"t");env.update(TEMP=buf.value,TMP=buf.value)
record={"schema":"facman.p6-unfinished-package-proof-continuation.v1","status":"running","source":expected,"original_failed_receipt_sha256":sha(Base/"result.json"),"cwd_diagnosis_sha256":sha(Base/"cwd-diagnosis/result.json"),"scope":"Continue only package proof stages using unchanged freshly compiled p6 artifacts and absent compact owned proof directories; no rebuild or source change.","package_before":before,"commands":[]}
(E/"plan.json").write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8",newline="\n")
started=time.monotonic()
def save():(E/"result.json").write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8",newline="\n")
def run(name,args,budget):
 assert source()==expected and inventory()==before and sha(portable)==portable_sha
 log=E/(name+".log");start=time.monotonic()
 with log.open("xb") as out:r=subprocess.run([str(a) for a in args],cwd=R,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=min(budget,900-(start-started)))
 row={"name":name,"argv":[str(a) for a in args],"exit_code":r.returncode,"seconds":time.monotonic()-start,"log":str(log),"sha256":sha(log)};record["commands"].append(row);save();print(json.dumps({"name":name,"exit_code":r.returncode,"seconds":row["seconds"],"sha256":row["sha256"]}),flush=True);assert r.returncode==0,name
try:
 run("portable-proofs",[sys.executable,"tools/product_package_proofs.py","--executable",stage/"bin/facman.exe","--profile","windows_product_x64","--package-mode","portable","--evidence-root",Proof],180)
 run("setup-build",[sys.executable,"tools/self_contained_setup.py","--portable",portable,"--bootstrap",N/"Release/FacManSetup.exe","--out",Setup],120)
 run("installed-proofs",[sys.executable,"tests/integration/facman_self_setup_lifecycle.py","--setup-exe",N/"Release/FacManSetup.exe","--payload",setup,"--workspace-lifecycle-evidence",Proof/"windows-installed-workspace-lifecycle.v1.json","--resource-package-evidence",Proof/"windows-installed-resource-package.v1.json"],240)
 run("payload-equivalence",[sys.executable,"tools/package_contract_tck.py","--profile","windows_product_x64","--canonical-stage",stage,"--payload-zip",setup,"--canonical-artifact",portable,"--payload-artifact",setup,"--adapter","windows_setup_overlay_v1","--version",version,"--receipt",Proof/"windows-payload-equivalence.v1.json"],120)
 record["assets"]=[{"path":str(p),"bytes":p.stat().st_size,"sha256":sha(p)} for p in [portable,setup,stage/"FacMan.exe",stage/"bin/facman.exe"]]
 record["proofs"]=[{"path":str(p),"bytes":p.stat().st_size,"sha256":sha(p)} for p in sorted(Proof.glob("*.v1.json"))]
 record["status"]="PASS_LOCAL_COMMITTED_BUILD_AND_FIXTURES";record["ordinary_gui_startup"]="pending separate exact packaged-GUI probe"
except BaseException as error:record["status"]="FAIL";record["failure"]=repr(error);raise
finally:
 record["source_after"]=source();record["package_unchanged"]=inventory()==before and sha(portable)==portable_sha;record["elapsed_seconds"]=time.monotonic()-started;save();print(json.dumps({"status":record["status"],"sha256":sha(E/"result.json")}),flush=True)
