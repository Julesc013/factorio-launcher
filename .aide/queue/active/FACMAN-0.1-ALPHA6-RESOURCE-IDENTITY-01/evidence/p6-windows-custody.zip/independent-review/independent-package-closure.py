from pathlib import Path,PurePosixPath
import hashlib,json,stat,struct,subprocess,tomllib,zipfile
E=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-0-36077e5ebb\evidence\package-97e\startup-remediation\p6-review');R=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\worktrees\task-facman-resource-identity-01');T=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-d9fce3b03d');G=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-0-36077e5ebb')
HEAD='f9d27901ede83d1ac21176dd36e35ceadc633881';TREE='a6b314e2724fba62fc17705d0a81a8006dbd8d93'
ST=T/'packages-p6/windows_product_x64'; RP=T/'evidence/rp6';BASE=G/'evidence/package-97e'
def sha(b):return hashlib.sha256(b).hexdigest()
def fh(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def j(p):return json.loads(Path(p).read_bytes())
def inv(root):
 return {p.relative_to(root).as_posix():{'size':p.stat().st_size,'sha256':fh(p)} for p in root.rglob('*') if p.is_file()}
def checkref(row,base=E):
 p=Path(row['path']);p=p if p.is_absolute() else base/p
 assert fh(p)==row['sha256'],p
 if 'bytes' in row:assert p.stat().st_size==row['bytes'],p
 return p
def git(*args,root=R):return subprocess.check_output(['git','-C',str(root),*args],timeout=30).decode().strip()
def clean():assert git('rev-parse','HEAD')==HEAD and git('rev-parse','HEAD^{tree}')==TREE and git('status','--porcelain=v1')=='' and git('diff','--cached','--name-only')==''
def rawzip(path):
 with zipfile.ZipFile(path) as z:
  names=z.namelist();assert len(names)==len(set(names))==len({x.casefold() for x in names})
  out={}
  for zi in z.infolist():
   n=zi.filename;assert not zi.is_dir() and not n.startswith('/') and all(x not in ('','..','.') for x in n.split('/')) and ':' not in n and '\\' not in n
   assert zi.file_size<32*1024*1024
   b=z.read(zi);assert len(b)==zi.file_size
   out[n]=b
  return out
def identities(data):return {p:{'size':len(b),'sha256':sha(b)} for p,b in data.items()}
clean(); observed=inv(ST);assert len(observed)==113
portable=T/'dist-p6/FacMan-0.1.0-alpha.5-windows-x64-portable.zip'
setup=T/'setup-p6/FacMan-0.1.0-alpha.5-windows-x64-setup.exe'
pzip=rawzip(portable);assert identities(pzip)==observed
szip=rawzip(setup);prefix='facman/generations/0.1.0-alpha.5/'
runtime={n[len(prefix):]:b for n,b in szip.items() if n.startswith(prefix)}
assert identities(runtime)==observed
assert set(szip)-{prefix+n for n in runtime}=={'facman/maintenance/FacManSetup.exe','facman/state/current-generation.v1.json'}
assert szip['facman/maintenance/FacManSetup.exe']==(T/'native-p6/Release/FacManSetup.exe').read_bytes()
state=json.loads(szip['facman/state/current-generation.v1.json']);assert state['generation']=='0.1.0-alpha.5',state
def managed(b):
 assert b[:2]==b'MZ';pe=struct.unpack_from('<I',b,60)[0];assert b[pe:pe+4]==b'PE\0\0'
 optional=pe+24;magic=struct.unpack_from('<H',b,optional)[0];dd=optional+({0x10b:96,0x20b:112}[magic])
 rva,size=struct.unpack_from('<II',b,dd+14*8)
 return rva!=0 and size!=0
assert managed(pzip['FacMan.exe']) and not managed(pzip['bin/facman.exe']) and pzip['FacMan.exe']!=pzip['bin/facman.exe']
manifest=tomllib.loads(pzip['manifest/package.v1.toml'].decode())
build=json.loads(pzip['manifest/build_info.v1.json'])
backend=j(E/'independent-product-inspect.stdout')['payload']['backend_identity']
for label,expected in [('source_revision',HEAD),('source_dirty',False),('universal_launcher_revision','5479939ca5cbc9ee0f901608a92012778b4752ae'),('universal_setup_revision','d2a2aae7e61c47035c92334b0522143b4fea3880')]:
 assert manifest[label]==backend['build'][label]==backend['package'][label]==expected
assert backend['build']['build_identity']==build['build_identity']
pk=backend['package']
for k in ('verified','build_matches_package','contract_set_matches_build'):assert pk[k] is True
assert pk['mode']=='packaged' and pk['integrity']=='sha256_consistent' and pk['authenticity']=='not_proven_unsigned'
for k,p in [('backend_sha256','bin/facman.exe'),('manifest_sha256','manifest/package.v1.toml'),('closure_sha256','manifest/hashes.sha256')]:assert pk[k]==sha(pzip[p])
hashrows=pzip['manifest/hashes.sha256'].decode().splitlines();hashed={}
for line in hashrows:
 digest,n=line.split('  ',1);assert n not in hashed and sha(pzip[n])==digest;hashed[n]=digest
assert len(hashed)==pk['files_verified']==112 and set(hashed)==set(pzip)-{'manifest/hashes.sha256'}
pack=rawzip(ST/'facman.resources');members=identities(pack);pm=json.loads(pack['manifest/resource-pack.v1.json'])
assert len(pm['entries'])==len(pack)-1
agg=hashlib.sha256()
for row in pm['entries']:
 assert members[row['path']]=={'size':row['bytes'],'sha256':row['sha256']}
 agg.update(row['path'].encode()+b'\0'+str(row['bytes']).encode()+b'\0'+row['sha256'].encode()+b'\n')
assert agg.hexdigest()==pm['content_sha256']
contracts=hashlib.sha256();schema_names=sorted(n for n in pack if n.startswith('contracts/schema/'))
for n in schema_names:
 raw=pack[n];normalized=raw.replace(b'\r\n',b'\n').replace(b'\r',b'\n')
 contracts.update(n.encode()+b'\0'+normalized+b'\0')
 assert normalized==(R/n).read_bytes().replace(b'\r\n',b'\n').replace(b'\r',b'\n'),n
assert contracts.hexdigest()==backend['contract_set_sha256']==pk['contract_set_sha256']
portable_inv=None;resource_results=[]
case_ids=['original_identity','relocated_identity','export_members','existing_output_refusal','missing_resource_refusal','truncated_resource_refusal','foreign_resource_refusal','no_display_terminal','original_unchanged']
for mode in ('portable','installed'):
 receipt_path=RP/f'windows-{mode}-resource-package.v1.json';receipt=j(receipt_path)
 assert receipt['status']=='pass' and receipt['failure'] is None and receipt['original_unchanged'] is True
 assert receipt['source_revision']==HEAD and receipt['source_tree']==TREE and receipt['source_dirty'] is False
 assert all(v is False for v in receipt['authority'].values()) and receipt['input_provenance']=='supplied_path_not_producer_attested'
 assert receipt['package_mode']==('portable' if mode=='portable' else 'installed_stage')
 assert receipt['cases']==[{'id':x,'status':'pass'} for x in case_ids]
 assert len(receipt['artifacts'])==46 and len(receipt['commands'])==20
 amap={}
 for row in receipt['artifacts']:
  assert row['path'] not in amap;assert not Path(row['path']).is_absolute() and '..' not in Path(row['path']).parts
  checkref(row,RP);amap[row['path']]=row
 input_=receipt['input'];invp=RP/input_['inventory_artifact'];assert fh(invp)==input_['inventory_sha256']
 iv=j(invp);ivmap={x['path']:{'size':x['size'],'sha256':x['sha256']} for x in iv}
 assert len(iv)==len(ivmap) and ivmap==observed
 if portable_inv is None:portable_inv=iv
 else:assert iv==portable_inv
 for key in ('executable','resource','manifest'):
  row=input_[key];assert observed[row['path']]=={'size':row['bytes'],'sha256':row['sha256']}
 source=j(RP/receipt['proof_source_artifact'])
 for n,row in source.items():assert fh(R/n)==row['sha256'] and (R/n).stat().st_size==row['size'],n
 work=invp.parent;oracle=j(work/'resource-oracle.json');assert oracle['members']==members and oracle['entries']==[x['path'] for x in pm['entries']]
 assert oracle['content_sha256']==agg.hexdigest()
 relocation=work/'Relocated package \u00e9 \u03b2';assert inv(relocation)==observed
 exported=j(work/'export-inventory.json');exmap={x['path']:{'size':x['size'],'sha256':x['sha256']} for x in exported['files']}
 expected=dict(members);marker=b'schema=facman.archive_staging.v1\n';expected['.facman-archive-staging.v1']={'size':len(marker),'sha256':sha(marker)}
 assert exmap==expected==inv(work/'Exported resources')
 commands={x['id']:x for x in receipt['commands']};assert len(commands)==20
 for cid,row in commands.items():
  assert not row['timed_out'] and not row['output_limit_exceeded'] and row['error'] is None
  assert row['stdout'] in amap and row['stderr'] in amap and (RP/row['stderr']).read_bytes()==b''
  expected_exit=1 if cid in ('existing_output','missing','truncated','foreign') else 0
  assert row['exit_code']==expected_exit
  if cid.endswith('_help') or cid.endswith('_version'):continue
  response=j(RP/row['stdout'])
  assert response['outcome']==('refused' if expected_exit else 'ok')
  if expected_exit:
   assert response['payload'] is None and response['effects']==[] and response['operation']['effects_may_have_occurred'] is False
   assert response['error']['code']==('archive_staging_root_exists' if cid=='existing_output' else 'resource_package_invalid')
  if cid in ('original_list','original_verify','relocated_list','relocated_verify'):
   payload=response['payload'];assert payload['entries']==oracle['entries'] and payload['content_sha256']==oracle['content_sha256'] and payload['pack_sha256']==observed['facman.resources']['sha256'] and payload['package_manifest_sha256']==observed['manifest/package.v1.toml']['sha256']
   expected_path=Path(input_['root'])/'facman.resources' if cid.startswith('original') else relocation/'facman.resources'
   if expected_path.exists():assert Path(payload['path']).samefile(expected_path)
  if cid=='export':
   payload=response['payload'];assert payload['entry_count']==len(pm['entries']) and Path(payload['destination']).samefile(work/'Exported resources')
 assert (work/'truncated.resources').read_bytes()==b'PK\x03\x04'
 assert rawzip(work/'foreign.resources')['content/proof-foreign.txt']==b'Foreign resource qualification fixture\n'
 resource_results.append({'mode':mode,'receipt_sha256':fh(receipt_path),'cases':9,'commands':20,'artifacts':46,'input_members':len(iv),'exported_members_plus_marker':len(expected),'retained_original_installed_root_exists':Path(input_['root']).exists()})
equiv=j(RP/'windows-payload-equivalence.v1.json')
digest=sha(json.dumps([{'path':n,**observed[n]} for n in sorted(observed,key=lambda x:x.encode())],sort_keys=True,separators=(',',':')).encode())
assert equiv['status']=='pass' and equiv['problems']==[] and equiv['canonical_stage_digest']==equiv['payload_runtime_digest']==digest
assert equiv['canonical_file_count']==equiv['payload_runtime_file_count']==113
assert equiv['canonical_artifact']['sha256']==fh(portable) and equiv['payload_artifact']['sha256']==fh(setup)
workspace=[]
for mode in ('portable','installed'):
 path=RP/f'windows-{mode}-workspace-lifecycle.v1.json';w=j(path)
 assert w['status']=='pass' and w['source_revision']==HEAD and w['source_tree']==TREE and w['source_dirty'] is False
 assert w['executable_sha256']==sha(pzip['bin/facman.exe']) and len(w['cases'])==11 and len({x['case_id'] for x in w['cases']})==11
 assert all(x['status']=='pass' for x in w['cases']) and all(x is False for x in w['authority'].values())
 workspace.append({'mode':mode,'cases':11,'receipt_sha256':fh(path)})
clean()
result={'schema':'facman.p6-independent-package-closure.v1','status':'PASS','source_revision':HEAD,'source_tree':TREE,'stage_inventory_count':113,'portable':{'sha256':fh(portable),'bytes':portable.stat().st_size},'setup':{'sha256':fh(setup),'bytes':setup.stat().st_size,'members':len(szip),'adapter_owned_members':2},'gui_sha256':sha(pzip['FacMan.exe']),'cli_sha256':sha(pzip['bin/facman.exe']),'pe_identity':'Distinct managed GUI and native CLI, each identical to corresponding portable/installed payload member.','contract_schema_count':len(schema_names),'contract_digest':contracts.hexdigest(),'pack_member_count':len(pack),'resource_proofs':resource_results,'workspace_proofs':workspace,'stage_digest':digest,'compiled_identity':backend,'limits':['Recorded native/resource/lifecycle executions audited; only product inspect rerun independently.','Unsigned local Windows portable and disposable installed payloads; no provider remote closure, hosted, human, real DPI, Factorio or release eligibility.']}
with (E/'independent-package-closure.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'path':str(E/'independent-package-closure.json'),'sha256':fh(E/'independent-package-closure.json'),'schema_count':len(schema_names),'pack_members':len(pack),'status':'PASS'}))
