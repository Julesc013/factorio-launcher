from pathlib import Path
import hashlib,json,os,stat,subprocess,time,zipfile
E=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-0-36077e5ebb\evidence\package-97e\startup-remediation\p6-review');R=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\worktrees\task-facman-resource-identity-01');T=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-d9fce3b03d');G=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-0-36077e5ebb')
HEAD='f9d27901ede83d1ac21176dd36e35ceadc633881';TREE='a6b314e2724fba62fc17705d0a81a8006dbd8d93'
def sha(b):return hashlib.sha256(b).hexdigest()
def readj(p):return json.loads(p.read_bytes())
def fhash(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(n,d):
 b=(json.dumps(d,indent=2,ensure_ascii=False)+'\n').encode()
 with (E/n).open('xb') as f:f.write(b)
 return {'path':str(E/n),'bytes':len(b),'sha256':sha(b)}
def git(*a,root=R):
 return subprocess.check_output(['git','-C',str(root),*a],timeout=30).decode().strip()
def source():
 d={'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--porcelain=v1'),'index':git('diff','--cached','--name-only')}
 assert d=={'head':HEAD,'tree':TREE,'status':'','index':''},d
 return d
plan={'scope':'Independent original-file/source/package/recorded-execution audit. One read-only product inspect command. No rebuild/gallery/setup/source/index/ref mutations.','source':HEAD,'custody_expected':'57924e217640584f67335db616532f67019c4b0788b746a0cd281e175f08111d','write_scope':str(E),'command':[str(T/'packages-p6/windows_product_x64/bin/facman.exe'),'product','inspect','--json'],'cwd':str(T/'t'),'timeout_seconds':30}
save('independent-audit-plan.json',plan)
before=source(); h=readj(E/'handoff.json');c=readj(E/'artifact-custody.json')
assert fhash(E/'handoff.json')=='b0db7b08f7d7ef01ee2700c55c39faa5cdc7fdcac50fca6e28dbe7300c07f784'
assert fhash(E/'artifact-custody.json')==plan['custody_expected']
assert h['source']['commit']==HEAD and h['source']['tree']==TREE and h['source']['clean'] is True
roots=[Path(p) for p in c['roots']];seen=set();total=0
for row in c['files']:
 p=Path(row['path']);key=str(p).casefold()
 assert key not in seen,('duplicate',p);seen.add(key)
 assert any(p.is_relative_to(r) for r in roots),('outside roots',p)
 st=p.lstat();assert stat.S_ISREG(st.st_mode) and not st.st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT,('indirection',p)
 assert st.st_size==row['bytes'] and fhash(p)==row['sha256'],('changed',p)
 total+=st.st_size
assert len(seen)==c['count']==2567 and total==c['bytes']==286299793
for row in h['top_receipts']+[h['providers_manifest']]:
 p=Path(row['path']);assert fhash(p)==row['sha256'],p
 if 'bytes' in row:assert p.stat().st_size==row['bytes']
provider=readj(Path(h['providers_manifest']['path']))
cmd=plan['command'];started=time.monotonic()
cp=subprocess.run(cmd,cwd=plan['cwd'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30,check=False)
logs={}
for name,b in [('independent-product-inspect.stdout',cp.stdout),('independent-product-inspect.stderr',cp.stderr)]:
 assert len(b)<=4*1024*1024
 with (E/name).open('xb') as f:f.write(b)
 logs[name]={'bytes':len(b),'sha256':sha(b)}
product=json.loads(cp.stdout);assert cp.returncode==0,(cp.returncode,cp.stderr)
result={'schema':'facman.p6-independent-initial-custody.v1','status':'PASS','source_before':before,'source_after':source(),'custody_files':len(seen),'custody_bytes':total,'top_receipts_verified':len(h['top_receipts']),'providers_manifest_sha256':fhash(Path(h['providers_manifest']['path'])),'actual_command':{'argv':cmd,'cwd':plan['cwd'],'exit_code':cp.returncode,'seconds':time.monotonic()-started,'logs':logs},'product_keys':list(product),'limitations':['No rebuild or native/gallery replay.','Original clean-p6 FAIL retained; no relabeling.','Local unsigned Windows two-asset scope only.']}
ref=save('independent-initial-custody.json',result);print(json.dumps(ref));print('product keys',list(product))
