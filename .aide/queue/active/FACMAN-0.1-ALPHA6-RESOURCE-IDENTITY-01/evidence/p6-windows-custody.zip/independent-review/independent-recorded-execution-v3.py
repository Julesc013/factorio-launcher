from pathlib import Path
import hashlib,json,re,struct,subprocess
E=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-0-36077e5ebb\evidence\package-97e\startup-remediation\p6-review');R=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\worktrees\task-facman-resource-identity-01');T=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-d9fce3b03d');G=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-0-36077e5ebb');B=G/'evidence/package-97e'
H='f9d27901ede83d1ac21176dd36e35ceadc633881';TR='a6b314e2724fba62fc17705d0a81a8006dbd8d93'
def j(p):return json.loads(Path(p).read_bytes())
def sh(b):return hashlib.sha256(b).hexdigest()
def fh(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
refs={}
def pin(p,want=None):
 p=Path(p);v={'path':str(p),'bytes':p.stat().st_size,'sha256':fh(p)}
 if want is not None:assert v['sha256']==want,p
 refs[str(p)]=v;return v
def git(*a,root=R):return subprocess.check_output(['git','-C',str(root),*a],timeout=30).decode().strip()
def clean():
 assert git('rev-parse','HEAD')==H and git('rev-parse','HEAD^{tree}')==TR and git('status','--porcelain=v1')=='' and git('diff','--cached','--name-only')==''
def commands(rows,parent):
 for row in rows:
  if 'log' in row:pin(row['log'],row['sha256'])
  for name in ('stdout','stderr'):
   if isinstance(row.get(name),dict):
    r=row[name];p=Path(r['path']);pin(p if p.is_absolute() else parent/p,r['sha256'])
clean()
buildp=B/'startup-remediation/clean-p6/result.json';build=j(buildp);pin(buildp)
commands(build['commands'],buildp.parent)
assert build['status']=='FAIL' and len(build['commands'])==13
assert all(r['exit_code']==0 for r in build['commands'][:12]) and build['commands'][-1]['name']=='portable-proofs' and build['commands'][-1]['exit_code']==1
for row in build['commands']:assert row['source_after']['commit']==H and row['source_after']['tree']==TR and row['source_after']['clean'] is True,row
cmd=next(r for r in build['commands'] if r['name']=='build')
assert '--clean-first' in cmd['argv'] and '/p:TrackFileAccess=false' in cmd['argv'] and cmd['argv'][cmd['argv'].index('--parallel')+1]=='4'
assert 'product.cpp' in Path(cmd['log']).read_text()
ctest=next(r for r in build['commands'] if r['name']=='ctest')
ctext=Path(ctest['log']).read_text()
assert '100% tests passed, 0 tests failed out of 44' in ctext
assert len(re.findall(r'\d+/44 Test +#\d+:.*Passed',ctext))==44
last=T/'native-p6/Testing/Temporary/LastTest.log';pin(last)
assert last.read_text().count('Test Passed.')==44
runtime=next(r for r in build['commands'] if r['name']=='runtime-smoke')
rt=j(runtime['log']);assert rt['backend_identity']['compiled_source_revision']==H and rt['backend_identity']['compiled_source_dirty'] is False
assert rt['doctor_workspace_write'] is False and rt['tui']['execution_authority']=='blocked_pending_real_play_gate'
identity=T/'identity-cli-p6/commands.json';idc=j(identity);pin(identity);assert len(idc)==2 and all(x['exit_code']==0 and x['timed_out'] is False for x in idc)
assert (T/'identity-cli-p6/identity.stderr').read_bytes()==b''
co=B/'startup-remediation/clean-p6/checkout/current-checkout-observation.v2.json';checkout=j(co);pin(co)
assert checkout['source']['head']==H and checkout['source']['tree']==TR and checkout['source']['dirty'] is False and checkout['source']['index_flags_clean'] is True
assert checkout['result']['status']=='pass' and checkout['remote_evidence']['source_closure_proven'] is False
providers=[]
for p in build['providers']:
 root=Path(p['path']);actual={'root':str(root),'head':git('rev-parse','HEAD',root=root),'tree':git('rev-parse','HEAD^{tree}',root=root),'status':git('status','--porcelain=v1',root=root)}
 assert actual['head']==p['revision'] and actual['tree']==p['tree'] and actual['status']==''
 providers.append(actual)
diagp=B/'startup-remediation/clean-p6/cwd-diagnosis/result.json';diag=j(diagp);pin(diagp)
assert diag['result']=='LONG_CWD_REFUSAL_SAME_OBJECT_SHORT_PASS' and diag['same_directory_object'] is True
long,short=diag['commands'];assert long['cwd_characters']==263 and long['error']['winerror']==267 and long['exit_code'] is None
assert short['cwd_characters']==144 and short['exit_code']==0 and short['error'] is None
assert Path(long['cwd']).samefile(Path(short['cwd']))
replayp=B/'startup-remediation/clean-p6/proof-replay/result.json';replay=j(replayp);pin(replayp);commands(replay['commands'],replayp.parent)
assert replay['status']=='PASS' and replay['original_failed_receipt_sha256']==fh(buildp) and replay['cwd_diagnosis_sha256']==fh(diagp) and replay['package_unchanged'] is True
assert all(x['exit_code']==0 for x in replay['commands'])
for row in replay['assets']+replay['proofs']:pin(row['path'],row['sha256'])
startup=B/'startup-p6';sr=j(startup/'result.json');pin(startup/'result.json');commands(sr['commands'],startup)
sp=j(startup/'plan.json');pin(startup/'plan.json',sr['plan_sha256'])
assert sr['source_head']==H and sp['source_tree']==TR and sp['source_dirty'] is False
for row in sp['source_files']:pin(R/row['path'],row['sha256'])
pin(sp['containment_source']['path'],sp['containment_source']['sha256'])
runtime=sr['runtime_result'];assert runtime==j(startup/'startup-result.json');pin(startup/'startup-result.json')
assert runtime['result']=='PASS' and runtime['live_backend_workspace_rendered'] is True and runtime['workspace_remained_absent'] is True and runtime['normal_exit']==0 and runtime['tree_empty'] is True
assert not Path(runtime['workspace']).exists()
pin(runtime['gui'],runtime['sha256'])
visible=j(startup/'visible-text.json');pin(startup/'visible-text.json')
text='\n'.join(visible);assert 'Workspace: '+runtime['workspace'] in text and 'Status: uninitialized' in text and 'Source mode: live_backend' in text and 'frontend_backend_' not in text
for n in ('StartupProbe.cs','run.py','startup-settings.png'):pin(startup/n)
assert (startup/'product.stdout').read_bytes()==(startup/'product.stderr').read_bytes()==b''
assert all(x['exit_code']==0 and x['timed_out'] is False for x in sr['commands'])
gp=B/'gallery-p6';gr=j(gp/'result.json');pin(gp/'result.json');commands(gr['commands'],gp)
plan=j(gp/'plan.json');pin(gp/'plan.json')
assert gr['source_head']==H and gr['source_tree']==TR and gr['result']=='PASS' and gr['source_unchanged'] is True
for row in plan['source_files']:pin(R/row['path'],row['sha256'])
commands(plan['prerequisites'],gp);assert all(row['exit_code']==0 for row in plan['prerequisites'])
assembly=gr['runtime_assembly'];pin(assembly['location'],assembly['sha256'])
assert assembly==j(G/'pgp6/bin/assembly-binding.json');pin(G/'pgp6/bin/assembly-binding.json')
assert assembly['sha256']==gr['package_member']['sha256']==runtime['sha256']
for row in gr['fixtures']:pin(G/'pgp6'/row['path'],row['sha256'])
raw=G/'pgp6/evidence/control-gallery.v1.json';rr=j(raw);pin(raw,gr['raw_receipt']['sha256'])
assert rr['assertions']==gr['assertions']==6729 and len(rr['rows'])==gr['render_cells']==28 and len(rr['constrained_rows'])==gr['constrained_cells']==1
assert rr['live_transport_constructed'] is False and rr['actual_high_contrast'] is False
assert {(row['scenario'],row['scale']) for row in rr['rows']}=={(sc,scale) for sc in ('ready/baseline','blocked/baseline','busy/baseline','recovery/baseline','empty/baseline','error/baseline','ready/overflow') for scale in (1,1.25,1.5,2)}
imagepins=[]
for row in rr['rows']+rr['constrained_rows']:
 p=raw.parent/row['image'];imagepins.append(pin(p))
 b=p.read_bytes();assert b[:8]==b'\x89PNG\r\n\x1a\n';width,height=struct.unpack_from('>II',b,16);assert width>0 and height>0
assert len({r['path'] for r in imagepins})==29
for n in ('PackagedGalleryProbe.cs','PackagedGallery.csproj'):pin(G/'pgp6'/n)
old=B/'startup8dc/stale-build-finding.json';o=j(old);pin(old,'2cbf05aee6d8b51d4002eddbdc809d8028d9dc5f0a78f4e82c078cae87ae4cfc')
for row in o['files']:pin(row['path'],row['sha256'])
pin(E/'handoff-correction.json','1c9a3b452dc6732a15435dbf8614b7ebadc00904b3d8d59527f4bfe6bd110a86')
clean()
out={'schema':'facman.p6-independent-recorded-execution.v1','status':'PASS','source_revision':H,'source_tree':TR,'recorded_native_tests':44,'recorded_successful_commands_before_original_failure':12,'original_build_receipt_status':'FAIL preserved','cwd_diagnosis':{'long':263,'error':267,'same_object_short':144,'short_exit':0},'provider_checkouts':providers,'remote_source_closure_proven':False,'startup':runtime,'gallery':{'assertions':6729,'render_cells':28,'constrained_cells':1,'pngs':29,'fixture_count':7,'live_transport_constructed':False,'actual_high_contrast':False},'old_stale_build_files_unchanged':6,'references':list(refs.values()),'visual_review':['startup-settings.png: own product window displays live backend absent workspace state; no schema/identity error visible.','ready-overflow-200.png: actual production controls, scroll regions and long-label wrap; recording-only actions.'],'limits':['Build/CTest/startup/gallery are audited recorded executions, not independent reruns.','Actual product inspect separately independently executed and captured.','No remote source closure, arbitrary long-path support, human/monitor DPI/screen-reader/Factorio/hosted/release qualification.']}
p=E/'independent-recorded-execution.json'
with p.open('x',encoding='utf-8') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps({'path':str(p),'sha256':fh(p),'references':len(refs),'status':'PASS'}))
