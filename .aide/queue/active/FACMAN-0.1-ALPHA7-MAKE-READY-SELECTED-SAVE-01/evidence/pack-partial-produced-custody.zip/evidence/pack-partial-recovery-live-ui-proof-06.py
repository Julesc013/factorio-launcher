"""Admitted actual GUI -> owned Content import -> existing reconstruction oracle.

Requires completed checked integration, accepted delivered CLI proof, and an
independent exact parent/helper/artifact decision. Never builds a product or
changes a delivered byte. Every command owns a finite Windows Job Object.
"""
import ctypes,datetime,hashlib,json,os,shutil,stat,subprocess,sys,traceback,zipfile
from ctypes import wintypes
sys.dont_write_bytecode=True
from pathlib import Path
from types import SimpleNamespace
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
SOURCE='5cb795a12521e926d9335da9cc66b6868a2319c8'
SCENARIO=W/'pack-partial-recovery-live-ui-proof-06'
OUTPUT=E/'pack-partial-recovery-live-ui-result-06.json'
HELPER=E/'pack-partial-recovery-live-ui-driver-05.ps1'
HELPER_SHA='3aa3f4d5a873378c1e42a10d8c08f77d323f11a6cc732a43e4d8a254ec1b0ca5'
REVIEW=E/'pack-partial-recovery-live-ui-execution-review-06.json'
ADMISSION=E/'pack-partial-recovery-original-portable-admission-06.json'
CORE=E/'pack-partial-recovery-produced-result.json'
CORE_REVIEW=E/'pack-partial-recovery-produced-final-review.json'
COMPLETION=E/'pack-partial-recovery-postintegration-completion-04.json'
assert __debug__ and os.name=='nt'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
def tree(p):
 result={}
 for f in sorted(Path(p).rglob('*')):
  assert not getattr(f.stat(follow_symlinks=False),'st_file_attributes',0)&stat.FILE_ATTRIBUTE_REPARSE_POINT
  if f.is_file():result[f.relative_to(p).as_posix()]=sha(f)
 return result
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True,timeout=30).strip()
def exclusive(p,v):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
# All evidence decisions precede every directory/effect creation.
a=load(ADMISSION);core=load(CORE);cr=load(CORE_REVIEW);c=load(COMPLETION);review=load(REVIEW)
assert a['status']=='ADMITTED_EXISTING_WINDOWS_PRODUCED_PACKAGE' and a['source_commit']==SOURCE
assert core['status']=='PASS_SCOPED_WINDOWS_PRODUCED_PARTIAL_PACK_RECOVERY' and core['producer_source']==SOURCE
assert core['product_did_not_change_producers_or_delivery'] and core['clean_consumer_workspaces']==13
assert {cell['kind'] for cell in core['negative_preservation_cells']}=={'changed_source','conflicting_raw_entry','torn_generated_entry'}
assert cr['verdict']=='PASS' and cr['independent'] and cr['non_authoring']
assert cr['approve_scoped_produced_partial_pack_recovery'] and cr['result_sha256']==sha(CORE)
assert c['status']=='reviewed_pack_partial_recovery_integrated_and_clean_primaries_synchronized' and c['source']==SOURCE
assert review['verdict']=='PASS' and review['independent'] and review['non_authoring'] and review['approve_exact_live_ui_proof']
assert review['script_sha256']==sha(__file__) and review['helper_sha256']==sha(HELPER)==HELPER_SHA
for key,p in [('admission_sha256',ADMISSION),('core_result_sha256',CORE),('core_review_sha256',CORE_REVIEW),('completion_sha256',COMPLETION)]:
 assert review[key]==sha(p)
assert review['source']==SOURCE and review['delivery_files']==a['delivery_files']
assert not OUTPUT.exists() and not SCENARIO.exists() and not SCENARIO.is_symlink()
assert not git('status','--porcelain')
head=git('rev-parse','HEAD');assert head==c['facman_dev']
assert git('rev-parse','HEAD^{tree}')==a['producer_tree']==a['consumer_tree']
subprocess.run(['git','merge-base','--is-ancestor',SOURCE,head],cwd=R,check=True,timeout=30)
marker=load(W/'.facman-development-root.v1.json')
assert Path(marker['source_root']).resolve()==R and Path(marker['canonical_path']).resolve()==W
assert marker['task_id']=='task/facman-world-restore-retention-01'
for parent in [W,*W.parents]:assert not getattr(parent.stat(follow_symlinks=False),'st_file_attributes',0)&stat.FILE_ATTRIBUTE_REPARSE_POINT
cli=Path(a['executable']).resolve(strict=True);delivery=Path(a['delivery_root']).resolve(strict=True)
assert delivery.is_relative_to(W) and cli.is_relative_to(delivery) and sha(cli)==a['executable_sha256']
assert tree(delivery)==a['delivery_files']
guis=[delivery/leaf for leaf in a['delivery_files'] if Path(leaf).name.lower()=='facman.winforms.exe']
assert len(guis)==1;gui=guis[0];assert sha(gui)==review['gui_sha256']
os.environ['FACMAN_DEV_ROOT']=r'D:\Projects\Factorio\.task-builds'
os.environ['TEMP']=os.environ['TMP']=str(W/'t');os.environ['PYTHONDONTWRITEBYTECODE']='1'
for key in list(os.environ):
 if key.startswith('FACMAN_TEST_') or key.endswith('_FAULT') or key in ('FACMAN_PRESENTATION_MODE','FACMAN_CLI_PATH'):
  os.environ.pop(key)
os.environ['FACMAN_CLI_EXE']=str(cli)
os.environ['PYTHONPATH']=os.pathsep.join([str(R),str(R/'tests')])
sys.path[:0]=[str(R),str(R/'tests')]
from tools import provider_canary_process as owned
budget=owned.Budget(600,180);records=[]
record=dict(status='ADMITTING_EXACT_LIVE_UI_PROOF',source=SOURCE,head=head,commands=records,
 new_task_roots=0,new_clones=0,new_worktrees=0,product_builds=0,optional_candidates=0,
 helper_utility_compilations=1,setup_executed=False,factorio_executed=False,human_qualified=False,
 legacy_portable_profile=True,canonical_installed_setup_qualified=False,
 whole_workunit_closed=False,beta_qualified=False,review_sha256=sha(REVIEW))
# Retain each ancestor without delete sharing before any effect; reparse
# directories are rejected by the handle, not solely by path inspection.
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.CreateFileW.argtypes=[wintypes.LPCWSTR,wintypes.DWORD,wintypes.DWORD,ctypes.c_void_p,wintypes.DWORD,wintypes.DWORD,ctypes.c_void_p]
kernel.CreateFileW.restype=wintypes.HANDLE
kernel.GetFileInformationByHandleEx.argtypes=[wintypes.HANDLE,ctypes.c_int,ctypes.c_void_p,wintypes.DWORD]
kernel.GetFileInformationByHandleEx.restype=wintypes.BOOL
kernel.CloseHandle.argtypes=[wintypes.HANDLE];kernel.CloseHandle.restype=wintypes.BOOL
class AttributeTag(ctypes.Structure):
 _fields_=[('attributes',wintypes.DWORD),('tag',wintypes.DWORD)]
leases=[]
def retain_ancestry(path):
 for directory in [path,*path.parents]:
  handle=kernel.CreateFileW(str(directory),0x80,3,None,3,0x02200000,None)
  assert handle not in (None,ctypes.c_void_p(-1).value),ctypes.WinError(ctypes.get_last_error())
  info=AttributeTag()
  if not kernel.GetFileInformationByHandleEx(handle,9,ctypes.byref(info),ctypes.sizeof(info)) or not info.attributes&0x10 or info.attributes&0x400:
   kernel.CloseHandle(handle);raise AssertionError('Unsafe output ancestor')
  leases.append(handle)
retain_ancestry(E)
# A unique external attempt claim prevents silent replay; all outputs remain.
exclusive(E/'pack-partial-recovery-live-ui-proof-06.claim.json',dict(pid=os.getpid(),review_sha256=sha(REVIEW),source=SOURCE,no_replay=True))
SCENARIO.mkdir();retain_ancestry(SCENARIO);(SCENARIO/'commands').mkdir()
output_stream=OUTPUT.open('x+',encoding='utf-8',newline='\n')
def save():
 output_stream.seek(0);json.dump(record,output_stream,indent=2);output_stream.write('\n');output_stream.truncate();output_stream.flush();os.fsync(output_stream.fileno())
def command(label,argv,timeout=60,environment=None,allowed=(0,)):
 result=owned.command([str(x) for x in argv],cwd=R,environment=dict(os.environ) if environment is None else environment,
  timeout=timeout,budget=budget,output_limit=256*1024,directory=SCENARIO/'commands'/f'{len(records)+1:03d}-{label}',wait_for_job_empty_after_primary=True)
 p=result.directory/'receipt.json';records.append(dict(name=label,path=str(p),sha256=sha(p),exit=result.returncode));save()
 assert result.receipt['primary_stopped'] and result.receipt['job_empty_observed']
 assert result.receipt['termination']=='completed' and result.returncode in allowed
 return result
try:
 identity=command('identity',['powershell','-NoProfile','-Command','[Security.Principal.WindowsIdentity]::GetCurrent().Name']).stdout.decode().strip()
 assert identity.casefold()==r'BLACKGLASS-WIN1\Jules'.casefold()
 d=command('hygiene',['py','-3','-B','tools/workspace_hygiene.py','doctor','--measure'],allowed=(0,1))
 h=json.loads(d.stdout);assert set(h['violations']).issubset({'unmanaged_secondary_worktrees_present'})
 assert h['task_root_bytes']+64*1024**2<=20*1024**3 and shutil.disk_usage(W).free>=12*1024**3+64*1024**2
 # Small CLI fixtures are IO jobs; no native compiler or build is admitted.
 import native_cli
 def logged_run(argv,**kw):
  assert Path(argv[0]).samefile(cli) and '--workspace' in argv
  assert Path(argv[argv.index('--workspace')+1]).resolve().is_relative_to(SCENARIO)
  assert kw.get('stdout')==subprocess.PIPE and kw.get('stderr')==subprocess.PIPE and not kw.get('check',False)
  result=command('cli',argv,environment=kw.get('env'))
  encoding=kw.get('encoding') or ('utf-8' if kw.get('text') else None)
  return subprocess.CompletedProcess(argv,result.returncode,result.stdout.decode(encoding) if encoding else result.stdout,
   result.stderr.decode(encoding) if encoding else result.stderr)
 native_cli.subprocess=SimpleNamespace(run=logged_run,PIPE=subprocess.PIPE)
 import test_portable_modpack_import as imports
 import test_local_modset_solver as solver
 fixture_before=tree(solver.FIXTURE_INSTALL)
 producer=SCENARIO/'producer';consumer=SCENARIO/'consumer'
 oracle=imports.PortableModpackImportTests()
 _,pack=oracle.make_pack(producer,b'live UI exact settings\0\xff')
 producer_before=tree(producer)
 assert not consumer.exists()
 solver.call(consumer,'installs','import',str(solver.FIXTURE_INSTALL),'--id','fixture')
 assert solver.call(consumer,'instances','list')['instances']==[]
 snapshot=solver.call(consumer,'presentation','query','content')
 descriptors=[v for v in snapshot['available_semantic_actions'] if v['action_id']=='modsets.import']
 assert len(descriptors)==1 and descriptors[0]['availability']=='available'
 descriptor=descriptors[0];ui_output=SCENARIO/'ui-result-01.json'
 installation_fields=[v for v in descriptor['input_fields'] if v['field_id']=='installation_id']
 assert len(installation_fields)==1 and installation_fields[0]['choices']==['fixture'] and installation_fields[0]['default']=='fixture'
 binding=dict(schema='facman.produced_live_ui_ownership.v1',source=SOURCE,scenario=str(SCENARIO),
  gui=str(gui),gui_sha256=sha(gui),workspace=str(consumer),pack=str(pack),pack_sha256=sha(pack),
  output=str(ui_output),action_label=descriptor['label'],admission_sha256=sha(ADMISSION),execution_review_sha256=sha(REVIEW))
 owner=SCENARIO/'.facman-live-ui-owner.v1.json';exclusive(owner,binding)
 command('actual-gui-ui-automation',['powershell','-NoProfile','-ExecutionPolicy','RemoteSigned','-MTA','-File',str(HELPER),
  '-Gui',str(gui),'-GuiSha256',sha(gui),'-Workspace',str(consumer),'-Pack',str(pack),
  '-ActionLabel',descriptor['label'],'-Output',str(ui_output),'-Scenario',str(SCENARIO),'-OwnershipSha256',sha(owner)],180)
 ui=load(ui_output)
 assert ui['status']=='PASS_ACTUAL_PRODUCT_UI_IMPORT_TRANSPORT_REQUIRES_DOMAIN_ORACLE_REVIEW' and ui['gui_terminal'] is True
 oracle.assert_reconstruction(consumer,pack)
 assert tree(producer)==producer_before and tree(solver.FIXTURE_INSTALL)==fixture_before
 assert tree(delivery)==a['delivery_files']
 receipts=list((consumer/'.facman/action-receipts-v2').glob('*.v2.json'))
 receipts=[(path,load(path)) for path in receipts if load(path)['action_id']=='modsets.import']
 assert len(receipts)==1
 path,semantic=receipts[0]
 assert semantic['state']=='terminal' and semantic['scope']=='content'
 result_raw=semantic['result_json'].encode()
 assert semantic['result_length']==len(result_raw) and semantic['result_digest']==hashlib.sha256(result_raw).hexdigest()
 result=json.loads(result_raw);request=json.loads(semantic['request_json'])
 assert result['outcome']=='completed' and result['action_payload']['instance_id']=='reconstructed'
 assert request['source_path']==str(pack) and request['new_instance_id']=='reconstructed' and request['installation_id']=='fixture'
 assert request['confirmation']=='explicit' and request['display_name']=='Restored pack'
 assert semantic['schema']=='facman.presentation_action_receipt.v2' and semantic['contract_version']==2
 request_raw=semantic['request_json'].encode('utf-8')
 assert semantic['request_fingerprint']==hashlib.sha256(request_raw).hexdigest()
 key=semantic['idempotency_key'];assert key=='winforms-'+request['request_id']
 assert semantic['key_digest']==hashlib.sha256(key.encode('utf-8')).hexdigest()
 assert path.name==semantic['key_digest']+'.v2.json'
 assert result['schema']=='facman.semantic_action_result.v1' and result['command']=='presentation.action'
 assert result['action_id']==request['action_id']==semantic['action_id']=='modsets.import'
 assert request['scope']==semantic['scope']=='content'
 assert result['request_id']==request['request_id']==semantic['request_id']
 op=result['operation'];assert op['outcome']==result['outcome']=='completed'
 for receipt_key,request_key in [('request_id','request_id'),('operation_id','durable_operation_id'),('attempt_id','attempt_id')]:
  assert op[receipt_key]==semantic[receipt_key]==request[request_key] and request[request_key]
 assert op['durable_operation_id']==semantic['operation_id']
 assert op['target_instance_id']==semantic['target_instance_id']==request['new_instance_id']=='reconstructed'
 assert op['target_installation_id']==semantic['target_installation_id']==request['installation_id']=='fixture'
 assert semantic['effect_set']==result['effects']==['workspace_write'] and not result['problems']
 replacement=result['replacement_snapshot'];assert replacement['schema']=='facman.presentation_snapshot.v1' and replacement['page']['scope']=='content'
 selection=replacement['selected_context']
 assert selection['instance_id']=='reconstructed' and selection['installation_id']=='fixture' and selection['display_name']=='Restored pack'
 assert Path(replacement['workspace_health']['workspace']).samefile(consumer)
 target=consumer/'instances/reconstructed';payload=load(target/'modpack-import.v1.json')
 assert result['action_payload']==payload and payload['command']=='modsets.import' and payload['instance_id']=='reconstructed'
 assert Path(payload['path']).samefile(target) and payload['install_ref']=='fixture' and payload['offline'] is True
 assert payload['archive_sha256']==sha(pack) and payload['archive_size']==pack.stat().st_size
 journals=[(f,load(f)) for f in (consumer/'transactions').glob('*.transaction.v1.json')]
 journals=[(f,j) for f,j in journals if j['command_id']=='modsets.import']
 assert len(journals)==1;journal_path,journal=journals[0]
 assert journal['schema']=='facman.transaction.v2' and journal['state']=='complete'
 assert journal_path.name==journal['transaction_id']+'.transaction.v1.json' and journal['transaction_id']
 assert Path(journal['target']).samefile(target) and journal['commit_strategy']=='modpack_instance_no_replace_v1'
 assert [Path(v).resolve() for v in journal['source_identities']]==[pack.resolve(),solver.FIXTURE_INSTALL.resolve()]
 assert journal['completed_steps']==['pack_source_inventory_bound','request_validated','target_and_sources_validated',
  'pack_extraction_started','pack_generated_inventory_bound','pack_inventory_bound','pack_instance_verified',
  'commit_started','pack_instance_committed','audit_recorded','journal_closed']
 assert journal['effect_parent_identity'] and journal['effect_file_identity'] and not journal['error']
 context=json.loads(journal['operation_context']);binding=context['source_binding']
 assert context['schema']=='facman.modpack_import_install.v1' and context['install_id']=='fixture' and context['root_identity']
 for item in context['files']:
  bound_file=Path(item['path']);assert sha(bound_file)==item['sha256'] and bound_file.stat().st_size==item['size']
 assert binding==dict(schema='facman.modpack_import_source.v1',archive_sha256=sha(pack),archive_size=pack.stat().st_size,
  manifest_sha256=payload['source_manifest_sha256'],lock_sha256=payload['source_lock_sha256'],
  instance_id='reconstructed',install_id='fixture',display_name='Restored pack')
 with zipfile.ZipFile(pack) as archive:
  raw={info.filename:archive.read(info) for info in archive.infolist() if not info.is_dir()}
 generated=['mods/modset-lock.v1.json','instance.v1.json','config/config.ini','modpack-import.v1.json']
 expected={name:dict(path=name,sha256=hashlib.sha256(data).hexdigest(),size=len(data)) for name,data in raw.items()}
 for name in generated:
  assert name not in expected;data=(target/name).read_bytes()
  expected[name]=dict(path=name,sha256=hashlib.sha256(data).hexdigest(),size=len(data))
 assert len(journal['expected_files'])==len(expected)
 assert {item['path']:item for item in journal['expected_files']}==expected
 actual=tree(target);assert actual=={name:item['sha256'] for name,item in expected.items()}
 for name,data in raw.items():assert (target/name).read_bytes()==data
 final=solver.call(consumer,'presentation','query','content','--instance','reconstructed')
 assert final['selected_context']==selection and final['workspace_health']['incomplete_transactions']==0
 record['journal']=dict(path=str(journal_path),sha256=sha(journal_path),transaction_id=journal['transaction_id'],inventory_files=len(expected))
 record['request_and_result_bound']=True
 record['selected_context']=selection
 assert git('rev-parse','HEAD')==head and not git('status','--porcelain') and budget.remaining()>0
 assert sum(f.stat().st_size for f in SCENARIO.rglob('*') if f.is_file())<64*1024**2
 record.update(status='PASS_ACTUAL_DELIVERED_GUI_CONTENT_IMPORT_REQUIRES_INDEPENDENT_RESULT_REVIEW',
  ui_sha256=sha(ui_output),semantic_receipt=dict(path=str(path),sha256=sha(path),operation_id=semantic['operation_id']),
  delivery_and_producer_unchanged=True,clean_consumers=1,source_gameplay_claim='unclaimed')
except BaseException as error:
 record.update(status='ACTIONABLE_FAILURE_RETAIN_ALL_OWNED_EVIDENCE',error=repr(error),traceback=traceback.format_exc())
finally:
 record['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 try:save()
 finally:
  output_stream.close()
  for handle in reversed(leases):kernel.CloseHandle(handle)
print(json.dumps(dict(status=record['status'],receipt_sha256=sha(OUTPUT),commands=len(records))),flush=True)
if not record['status'].startswith('PASS_'):raise SystemExit(1)
