"""Recover the exact already-produced portable ZIP; preserve failed Setup payload."""
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import hashlib,io,json,os,shutil,stat,subprocess,sys,time,tomllib,zipfile
sys.dont_write_bytecode=True
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
SOURCE='5cb795a12521e926d9335da9cc66b6868a2319c8'
MERGE='dce1ed5cabfd8af848c122dc063c1196b3c95772'
INPUT=E/'pack-partial-recovery-produced-admission.json'
INSPECTION=E/'pack-partial-recovery-original-portable-reconstruction-inspection-02.json'
COMPLETION=E/'pack-partial-recovery-postintegration-completion-04.json'
REVIEW=E/'pack-partial-recovery-original-portable-admission-review-06.json'
OUTPUT=E/'pack-partial-recovery-original-portable-admission-06.json'
DELIVERY=W/'pack-partial-recovery-original-portable-01'
ARCHIVE=E/'pack-partial-recovery-exact-original-portable-01.zip'
assert os.name=='nt' and __debug__ and sys.version_info[:2]==(3,11)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True,timeout=30).strip()
def tree(root):
 files={}
 for p in sorted(root.rglob('*')):
  assert not getattr(p.stat(follow_symlinks=False),'st_file_attributes',0)&stat.FILE_ATTRIBUTE_REPARSE_POINT
  if p.is_file():files[p.relative_to(root).as_posix()]=sha(p)
 return files
def exclusive(path,data):
 with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(data,f,indent=2);f.write('\n')
a=load(INPUT);i=load(INSPECTION);c=load(COMPLETION);review=load(REVIEW)
assert a['status']=='ADMITTED_EXISTING_WINDOWS_PRODUCED_PACKAGE' and a['source_commit']==SOURCE
assert i['status']=='EXACT_ORIGINAL_PRODUCER_PORTABLE_BYTES_RECOVERABLE' and i['admission_sha256']==sha(INPUT)
assert c['status']=='reviewed_pack_partial_recovery_integrated_and_clean_primaries_synchronized' and c['facman_dev']==MERGE and c['task_refs_retired']
assert review['verdict']=='PASS' and review['independent'] and review['non_authoring'] and review['approve_exact_original_portable_admission']
assert review['script_sha256']==sha(__file__) and review['source']==SOURCE
for key,path in [('original_admission_sha256',INPUT),('inspection_sha256',INSPECTION),('completion_sha256',COMPLETION)]:assert review[key]==sha(path)
assert git('rev-parse','HEAD')==MERGE and not git('status','--porcelain')
assert git('rev-parse','HEAD^{tree}')==a['producer_tree']==a['consumer_tree']
marker=load(W/'.facman-development-root.v1.json')
assert Path(marker['source_root']).resolve()==R and Path(marker['canonical_path']).resolve()==W
assert marker['task_id']=='task/facman-world-restore-retention-01'
for p in [W,*W.parents]:assert not getattr(p.stat(follow_symlinks=False),'st_file_attributes',0)&stat.FILE_ATTRIBUTE_REPARSE_POINT
assert not OUTPUT.exists() and not DELIVERY.exists() and not ARCHIVE.exists()
os.environ['FACMAN_DEV_ROOT']=r'D:\Projects\Factorio\.task-builds'
os.environ['TEMP']=os.environ['TMP']=str(W/'t');os.environ['PYTHONDONTWRITEBYTECODE']='1'
d=subprocess.run([sys.executable,'-B','tools/workspace_hygiene.py','doctor','--measure'],cwd=R,capture_output=True,timeout=180)
assert d.returncode in (0,1);h=json.loads(d.stdout)
assert set(h['violations']).issubset({'unmanaged_secondary_worktrees_present'})
assert h['task_root_bytes']+256*1024**2<=20*1024**3 and shutil.disk_usage(W).free>=12*1024**3+256*1024**2
original=Path(a['delivery_root']).resolve(strict=True);assert original.is_relative_to(W)
assert tree(original)==a['delivery_files']
provenance=load(a['provenance']);assert sha(a['provenance'])==a['provenance_sha256']
pkg=provenance['package_record'];generation=Path(a['executable']).parent.parent
build=load(generation/'manifest/build_info.v1.json')
manifest=tomllib.loads((generation/'manifest/package.v1.toml').read_text())
assert manifest['source_revision']==SOURCE and manifest['source_dirty'] is False
assert manifest['profile_id']=='windows_legacy_winforms_x64' and manifest['entrypoint']=='bin/FacMan.WinForms.exe'
assert manifest['universal_launcher_revision']=='5479939ca5cbc9ee0f901608a92012778b4752ae'
assert manifest['universal_setup_revision']=='2749a15b835a6c1c9968598a2b434d85809691ad'
assert build['source_commit']==SOURCE and build['source_dirty'] is False
stamp=datetime.fromisoformat(build['source_timestamp_utc'].replace('Z','+00:00'))
dt=(stamp.year,stamp.month,stamp.day,stamp.hour,stamp.minute,stamp.second)
entries={}
for f in generation.rglob('*'):
 if not f.is_file():continue
 name=f.relative_to(generation).as_posix()
 name='bin/FacMan.WinForms.exe' if name=='FacMan.exe' else name
 assert name not in entries;entries[name]=(f.read_bytes(),os.access(f,os.X_OK))
assert len(entries)==pkg['portable_input']['generation_file_count']==595
assert sum(len(v[0]) for v in entries.values())<=128*1024**2
memory=io.BytesIO()
with zipfile.ZipFile(memory,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,(data,x) in sorted(entries.items()):
  info=zipfile.ZipInfo(name,dt);info.create_system=3;info.external_attr=(0o755 if x else 0o644)<<16;info.compress_type=zipfile.ZIP_DEFLATED
  z.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
archive_bytes=memory.getvalue();expected=pkg['portable_input']['sha256']
assert hashlib.sha256(archive_bytes).hexdigest()==expected==i['expected_original_portable_sha256']==review['original_portable_sha256']
assert len(archive_bytes)==8090602 and len(archive_bytes)<=64*1024**2
# The complete original archive identity is proven before any package effect.
exclusive(E/'pack-partial-recovery-original-portable-admission-06.claim.json',dict(pid=os.getpid(),source=SOURCE,review_sha256=sha(REVIEW),no_replay=True))
with ARCHIVE.open('xb') as f:f.write(archive_bytes)
DELIVERY.mkdir();files={}
for name,(data,_) in sorted(entries.items()):
 path=PurePosixPath(name)
 assert not path.is_absolute() and '\\' not in name and all(v not in ('','.','..') and ':' not in v for v in name.split('/'))
 target=DELIVERY.joinpath(*path.parts);assert target.resolve().is_relative_to(DELIVERY.resolve())
 target.parent.mkdir(parents=True,exist_ok=True)
 for parent in [target.parent,*target.parent.parents]:
  assert not getattr(parent.stat(follow_symlinks=False),'st_file_attributes',0)&stat.FILE_ATTRIBUTE_REPARSE_POINT
  if parent==W:break
 with target.open('xb') as f:f.write(data)
 files[name]=hashlib.sha256(data).hexdigest()
sys.path.insert(0,str(R));from tools.package_hash_manifest import verify_manifest
assert verify_manifest(DELIVERY)==[]
assert sha(ARCHIVE)==expected and ARCHIVE.stat().st_size==len(archive_bytes)
assert tree(original)==a['delivery_files'] and tree(DELIVERY)==files
assert git('rev-parse','HEAD')==MERGE and not git('status','--porcelain')
result=dict(a)
result.update(delivery_root=str(DELIVERY),delivery_files=files,executable=str(DELIVERY/'bin/facman.exe'),executable_sha256=sha(DELIVERY/'bin/facman.exe'),
 recovery_form='byte_identical_original_producer_portable_zip',original_portable_archive=str(ARCHIVE),original_portable_sha256=sha(ARCHIVE),
 original_self_setup_admission_sha256=sha(INPUT),original_self_setup_delivery_root=str(original),original_self_setup_delivery_files=a['delivery_files'],
 original_self_setup_unchanged=True,legacy_portable_profile=True,canonical_installed_setup_qualified=False,
 original_portable_admission_review_sha256=sha(REVIEW),completion_sha256=sha(COMPLETION),source_dirty=False,native_builds=0,candidate_dispatches=0,
 proof_execution_approved=False,recorded_at=datetime.now(timezone.utc).isoformat())
exclusive(OUTPUT,result)
print(json.dumps(dict(status=result['status'],recovery_form=result['recovery_form'],original_portable_sha256=sha(ARCHIVE),files=len(files),admission_sha256=sha(OUTPUT))),flush=True)
