"""Use delivered bytes for existing import oracles in separate owned workspaces.

Execution requires a hash-bound independent controller review and an admitted
existing producer artifact. This script never builds, dispatches CI, installs
FacMan or launches Factorio. Failed fixtures and process streams are retained.
"""
from datetime import datetime, timezone
import hashlib
import inspect
import textwrap
import math
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import traceback
import time
from types import SimpleNamespace
import unittest

ROOT = Path(r"D:\Projects\Factorio\factorio-launcher")
EVIDENCE = Path(__file__).resolve().parent
TASK = EVIDENCE.parent
ADMISSION = EVIDENCE / "pack-partial-recovery-original-portable-admission-06.json"
REVIEW = EVIDENCE / "pack-partial-recovery-original-portable-controller-review-08.json"
OUTPUT = EVIDENCE / "pack-partial-recovery-produced-result.json"
SCENARIO = TASK / "pack-partial-recovery-produced-proof"
METHODS = [
    "test_process_loss_before_staging_reconstructs_from_the_original_durable_source_binding",
    "test_process_loss_adopts_original_lock_and_recovers_partial_raw_and_generated_states",
    "test_missing_entry_recovery_survives_a_second_interruption_and_preserves_existing_objects",
    "test_generated_intent_precedes_writes_and_resumes_missing_generated_files",
    "test_recovery_before_staging_can_itself_be_interrupted_after_a_complete_entry",
    "test_late_foreign_staging_before_recovery_exclusive_creation_is_preserved",
    "test_process_loss_recovers_through_ordinary_recovery_action"
]

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def tree(root):
    result = {}
    for path in sorted(Path(root).rglob("*")):
        if path.is_symlink():
            raise AssertionError("Controller excludes redirected fixture paths")
        if path.is_file():
            result[path.relative_to(root).as_posix()] = sha(path)
    return result

def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()

def save():
    temporary = OUTPUT.with_suffix(".writing")
    temporary.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(OUTPUT)

def now():
    return datetime.now(timezone.utc).isoformat()

record = {"status": "NOT_EXECUTED", "commands": [], "workspaces": [], "producer_snapshots": [],
          "new_task_roots": 0, "new_worktrees": 0, "builds": 0, "candidate_dispatches": 0,
          "actual_factorio_execution": False, "whole_workunit_closed": False,
          "beta_qualified": False, "methods": METHODS}
live = set()
run_owns_scenario = False
original_popen = subprocess.Popen
CLI = None
proof_deadline = None

class LoggedProcess(original_popen):
    def __init__(self, argv, **kwargs):
        assert proof_deadline is not None and time.monotonic() < proof_deadline, "Produced recovery proof time budget exhausted"
        assert Path(argv[0]).samefile(CLI)
        assert "--workspace" in argv
        workspace = Path(argv[argv.index("--workspace") + 1]).resolve()
        assert workspace.is_relative_to(SCENARIO.resolve())
        self.return_text = bool(kwargs.pop("text", False) or kwargs.pop("universal_newlines", False) or kwargs.get("encoding"))
        self.decode_encoding = kwargs.pop("encoding", None) or "utf-8"
        kwargs.pop("errors", None)
        assert kwargs.get("stdout") == subprocess.PIPE and kwargs.get("stderr") == subprocess.PIPE
        ordinal = len(record["commands"]) + 1
        self.cleanup_deadline = None
        self.entry = {"ordinal": ordinal, "argv": [str(x) for x in argv], "workspace": str(workspace),
                      "stdout": str(SCENARIO / "streams" / f"{ordinal:03d}.stdout"),
                      "stderr": str(SCENARIO / "streams" / f"{ordinal:03d}.stderr"),
                      "fault_point": (kwargs.get("env") or {}).get("FACMAN_TEST_MODPACK_IMPORT_PAUSE"),
                      "status": "starting"}
        record["commands"].append(self.entry)
        save()
        super().__init__(argv, **kwargs)
        live.add(self)
        self.entry.update(pid=self.pid, status="running")
        save()

    def begin_cleanup(self):
        if self.cleanup_deadline is None:
            self.cleanup_deadline = time.monotonic() + 10

    def kill(self):
        self.begin_cleanup()
        return super().kill()

    def communicate(self, *args, **kwargs):
        assert len(args) <= 1, "Pass a wait timeout by keyword"
        deadline = self.cleanup_deadline if self.cleanup_deadline is not None else proof_deadline
        remaining = max(0.0, deadline - time.monotonic())
        requested = kwargs.pop("timeout", None)
        if requested is not None:
            assert isinstance(requested, (int, float)) and math.isfinite(requested) and requested >= 0
            remaining = min(remaining, requested)
        kwargs["timeout"] = remaining
        stdout, stderr = super().communicate(*args, **kwargs)
        for field, data in (("stdout", stdout), ("stderr", stderr)):
            assert isinstance(data, bytes)
            Path(self.entry[field]).write_bytes(data)
            self.entry[field + "_sha256"] = hashlib.sha256(data).hexdigest()
        self.entry.update(exit_code=self.returncode, status="completed")
        live.discard(self)
        save()
        if self.return_text:
            return stdout.decode(self.decode_encoding), stderr.decode(self.decode_encoding)
        return stdout, stderr

def logged_run(argv, **kwargs):
    assert not kwargs.pop("check", False)
    process = LoggedProcess(argv, **kwargs)
    try:
        stdout, stderr = process.communicate(timeout=min(60, max(0, proof_deadline - time.monotonic())))
    except BaseException:
        process.begin_cleanup()
        if process.poll() is None:
            process.kill()
        try:
            process.communicate(timeout=10)
        except BaseException as cleanup_error:
            record.setdefault("cleanup_errors", []).append(repr(cleanup_error))
            save()
        raise
    return subprocess.CompletedProcess(argv, process.returncode, stdout, stderr)

class OwnedDirectory:
    def __init__(self, prefix="", **kwargs):
        assert not kwargs
        self.path = SCENARIO / "consumers" / f"{len(record['workspaces']) + 1:02d}"
        self.path.mkdir(parents=True)
        self.entry = {"path": str(self.path), "initial_files": tree(self.path)}
        assert not self.entry["initial_files"]
        record["workspaces"].append(self.entry)
        save()

    def __enter__(self):
        return str(self.path)

    def __exit__(self, *args):
        assert not live, "Do not hash fixtures while an owned process holds their files"
        self.entry["retained_files"] = tree(self.path)
        save()

try:
    assert not OUTPUT.exists() and not SCENARIO.exists(), "Attach to retained proof; never replay implicitly"
    assert ADMISSION.is_file() and REVIEW.is_file()
    admission = json.loads(ADMISSION.read_text(encoding="utf-8-sig"))
    review = json.loads(REVIEW.read_text(encoding="utf-8-sig"))
    assert review["verdict"] == "PASS" and review["controller_sha256"] == sha(__file__)
    assert review["admission_sha256"] == sha(ADMISSION)
    assert admission["status"] == "ADMITTED_EXISTING_WINDOWS_PRODUCED_PACKAGE"
    assert admission["windows_producer_job_pass"] is True
    source = admission["source_commit"]
    publication = json.loads((EVIDENCE / "pack-partial-recovery-published-05.json").read_bytes())
    assert publication["source"] == source and sha(EVIDENCE / "pack-partial-recovery-published-05.json") == admission["publication_sha256"]
    assert review["independent"] and review["non_authoring"] and review["approve_exact_produced_recovery_proof"] is True
    assert review["publication_sha256"] == admission["publication_sha256"]

    assert re.fullmatch(r"[0-9a-f]{40}", source)
    subprocess.check_call(["git", "merge-base", "--is-ancestor", source, "HEAD"], cwd=ROOT)
    assert not git("status", "--porcelain")
    assert git("rev-parse", "HEAD^{tree}") == admission["producer_tree"], "Changed proof oracle closure"
    assert admission["consumer_tree"] == admission["producer_tree"]
    CLI = Path(admission["executable"]).resolve(strict=True)
    delivery_root = Path(admission["delivery_root"]).resolve(strict=True)
    assert delivery_root.is_relative_to(TASK.resolve()) and CLI.is_relative_to(delivery_root)
    assert sha(CLI) == admission["executable_sha256"]
    assert tree(delivery_root) == admission["delivery_files"]
    assert admission["test_source_sha256"] == sha(ROOT / "tests/test_portable_modpack_import.py")
    assert admission["solver_helper_sha256"] == sha(ROOT / "tests/test_local_modset_solver.py")
    assert shutil.disk_usage(TASK).free > 8 * 1024**3 + 256 * 1024**2
    marker = json.loads((TASK / ".facman-development-root.v1.json").read_text(encoding="utf-8-sig"))
    assert Path(marker["source_root"]).resolve() == ROOT and Path(marker["canonical_path"]).resolve() == TASK.resolve()
    assert marker["task_id"] == "task/facman-world-restore-retention-01"
    assert shutil.disk_usage(TASK).free >= 12 * 1024**3 + 256 * 1024**2
    proof_deadline = time.monotonic() + 1200
    source_head = git("rev-parse", "HEAD")
    source_tree = git("rev-parse", "HEAD^{tree}")
    fixture = ROOT / "tests/fixtures/fake_factorio_install"
    fixture_before = tree(fixture)
    record.update(status="RUNNING", started_at=now(), producer_source=source,
                  consumer_source=source_head, consumer_tree=source_tree,
                  admission_sha256=sha(ADMISSION), controller_review_sha256=sha(REVIEW))
    SCENARIO.mkdir()
    run_owns_scenario = True
    (SCENARIO / "streams").mkdir()
    save()
    for name in list(os.environ):
        if name.startswith("FACMAN_TEST_") or name.endswith("_FAULT"):
            os.environ.pop(name)
    os.environ["FACMAN_DEV_ROOT"] = r"D:\Projects\Factorio\.task-builds"
    os.environ["TEMP"] = os.environ["TMP"] = str(TASK / "t")
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    os.environ["FACMAN_CLI_EXE"] = str(CLI)
    sys.path.insert(0, str(ROOT))
    sys.path.insert(0, str(ROOT / "tests"))
    import native_cli
    import test_local_modset_solver as solver
    import test_portable_modpack_import as imports
    native_cli.subprocess = SimpleNamespace(run=logged_run, PIPE=subprocess.PIPE)
    imports.subprocess = SimpleNamespace(run=logged_run, Popen=LoggedProcess, PIPE=subprocess.PIPE)
    imports.tempfile = SimpleNamespace(TemporaryDirectory=OwnedDirectory)

    class SeparateWorkspaceImport(imports.PortableModpackImportTests):
        def make_pack(self, workspace, settings=None):
            producer = SCENARIO / "producers" / f"{len(record['producer_snapshots']) + 1:02d}"
            producer.mkdir(parents=True)
            source_instance, pack = super().make_pack(producer, settings)
            before = tree(producer)
            record["producer_snapshots"].append({"path": str(producer), "before": before})
            solver.call(workspace, "installs", "import", str(solver.FIXTURE_INSTALL), "--id", "fixture")
            listed = solver.call(workspace, "instances", "list")
            self.assertEqual([], listed["instances"])
            self.assertNotEqual(producer.resolve(), workspace.resolve())
            self.assertEqual(before, tree(producer))
            save()
            return source_instance, pack

    import test_presentation_pack_import as presentation
    presentation.subprocess = SimpleNamespace(Popen=LoggedProcess, PIPE=subprocess.PIPE)
    presentation.tempfile = SimpleNamespace(TemporaryDirectory=OwnedDirectory)

    class SeparateWorkspacePresentation(presentation.PresentationPackImportTests):
        def prepare(self, root, settings=None):
            producer, consumer = root / "producer", root / "consumer"
            _, pack = imports.PortableModpackImportTests().make_pack(producer, settings)
            before = tree(producer)
            assert not consumer.exists()
            record["producer_snapshots"].append({"path": str(producer), "before": before})
            record["workspaces"][-1].update(clean_consumer=str(consumer), initial_consumer_absent=True)
            solver.call(consumer, "installs", "import", str(solver.FIXTURE_INSTALL), "--id", "fixture")
            save()
            return producer, consumer, pack

    # Reuse the maintained ordinary action oracle, varying only its interruption
    # boundary. Add replay/preservation checks after genuine domain recovery.
    original_method = inspect.getsource(presentation.PresentationPackImportTests.test_process_loss_recovers_through_ordinary_recovery_action)
    original_points = 'for point in ("verified", "published", "committed"):'
    assert original_method.count(original_points) == 1
    method_source = original_method.replace(original_points, 'for point in ("precreate", "extracted-entry", "generated-entry"):')
    end_assertion = '                self.assertEqual(before, snapshot(producer))'
    assert method_source.count(end_assertion) == 1
    method_source = method_source.replace(end_assertion, end_assertion + "\n" +
        '                after = snapshot(consumer)\n'
        '                self.assertEqual((0, out, ""), invoke_machine(recovery))\n'
        '                self.assertEqual(after, snapshot(consumer))\n'
        '                replay_code, replay_out, replay_err = invoke_machine(args)\n'
        '                self.assertEqual((4, ""), (replay_code, replay_err), replay_out)\n'
        '                self.assertEqual("outcome_unknown", json.loads(replay_out)["payload"]["outcome"])\n'
        '                self.assertEqual(after, snapshot(consumer))\n'
        '                self.assertEqual(before, snapshot(producer))')
    namespace = dict(vars(presentation))
    exec(compile(textwrap.dedent(method_source), "<reviewed-ordinary-partial-import-oracle>", "exec"), namespace)
    setattr(SeparateWorkspacePresentation, METHODS[-1], namespace[METHODS[-1]])
    record["maintained_oracle_sha256"] = hashlib.sha256(original_method.encode()).hexdigest()
    record["scoped_oracle_sha256"] = hashlib.sha256(method_source.encode()).hexdigest()
    save()
    # Bind actual executed package/provider bytes before consumer effects.
    from tools.package.runtime_identity import require_backend_identity
    preflight_workspace = SCENARIO / "read-only-identity-workspace"
    probe = logged_run([str(CLI), "--workspace", str(preflight_workspace), "product", "inspect", "--json"],
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8")
    assert probe.returncode == 0 and not probe.stderr and not preflight_workspace.exists()
    envelope = json.loads(probe.stdout)
    assert envelope["schema"] == "facman.transport_response.v2"
    identity = require_backend_identity(CLI.parent.parent, CLI, envelope["payload"])
    assert identity["compiled_source_revision"] == source and identity["compiled_source_dirty"] is False
    # Existing same-binary terminal smoke, using an absent owned workspace.
    terminal = {}
    for label, args in (("catalog", ["--list", "--json"]),
                        ("workspace_status", ["--command", "workspace.status", "--json"])):
        response = logged_run([str(CLI), "tui", "--workspace", str(preflight_workspace), *args],
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8")
        assert response.returncode == 0 and not response.stderr and not preflight_workspace.exists()
        terminal[label] = json.loads(response.stdout)
    assert terminal["catalog"]["schema"] == "facman.tui_catalog.v1" and terminal["catalog"]["commands"]
    assert terminal["workspace_status"]["command"] == "workspace.status"
    record["same_binary_tui_readonly"] = {"catalog_present": True, "command_count": len(terminal["catalog"]["commands"]),
                                         "workspace_status": True, "workspace_initialized": False,
                                         "human_fullscreen_tui_accepted": False}
    record["executed_backend_identity"] = identity
    record["portable_delivery_form"] = admission["recovery_form"]
    record["canonical_installed_setup_qualified"] = False
    save()
    suite = unittest.TestSuite([*(SeparateWorkspaceImport(method) for method in METHODS[:-1]), SeparateWorkspacePresentation(METHODS[-1])])
    log_path = EVIDENCE / "pack-partial-recovery-produced-unittest.log"
    with log_path.open("x", encoding="utf-8") as stream:
        result = unittest.TextTestRunner(stream=stream, verbosity=2, failfast=True).run(suite)
    record["test_result"] = {"methods": result.testsRun, "failures": len(result.failures),
                             "errors": len(result.errors), "skips": len(result.skipped),
                             "log_sha256": sha(log_path)}
    save()
    assert result.wasSuccessful() and result.testsRun == len(METHODS) and not result.skipped
    assert len(record["workspaces"]) == 10 and len(record["producer_snapshots"]) == 10
    # Deliberate input damage belongs to each fresh negative fixture. Compare
    # against its injected preimage; never restore it to manufacture immutability.
    negative_cells = []
    oracle = SeparateWorkspaceImport()
    for kind in ("changed_source", "conflicting_raw_entry", "torn_generated_entry"):
        with OwnedDirectory() as value:
            consumer = Path(value)
            _, pack = oracle.make_pack(consumer, b"negative settings\0\xff")
            tx, stage, journal = oracle.partial_import(consumer, pack, generated=kind=="torn_generated_entry")
            injected = None
            if kind == "changed_source":
                pack.write_bytes(pack.read_bytes() + b"owned changed source fixture")
                source_record = record["producer_snapshots"][-1]
                source_record["expected_final_after_fixture_injection"] = tree(pack.parent)
                source_record["fixture_injection"] = {"kind": kind, "path": str(pack), "sha256": sha(pack)}
                injected = pack
            elif kind == "conflicting_raw_entry":
                intended = json.loads(journal.read_bytes())["expected_files"]
                relative = next(item["path"] for item in intended if not (stage / item["path"]).exists())
                injected = stage / relative
                injected.parent.mkdir(parents=True, exist_ok=True)
                with injected.open("xb") as handle:
                    handle.write(b"foreign existing entry fixture")
            else:
                candidates = [stage / leaf for leaf in ("mods/modset-lock.v1.json", "instance.v1.json",
                                                       "config/config.ini", "modpack-import.v1.json")]
                injected = next(path for path in candidates if path.is_file())
                data = injected.read_bytes(); assert len(data)>1
                injected.write_bytes(data[:len(data)//2])
            consumer_before = tree(consumer)
            source_before = tree(pack.parent)
            retained_before = oracle.retained_files(stage)
            journal_before = journal.read_bytes()
            refused = solver.call(consumer, "workspace", "recovery", "apply", tx, success=False)
            assert refused["refusal"]["code"] == "recovery_modpack_import_unsafe"
            assert tree(consumer) == consumer_before and tree(pack.parent) == source_before
            assert journal.read_bytes() == journal_before
            oracle.assert_retained_files(stage, retained_before)
            assert not (consumer / "instances/reconstructed").exists()
            negative_cells.append({"kind": kind, "workspace": str(consumer), "transaction_id": tx,
                "injected_path": str(injected), "injected_sha256": sha(injected),
                "refusal_code": refused["refusal"]["code"], "consumer_preimage": consumer_before,
                "source_preimage": source_before, "journal_sha256": sha(journal),
                "staging_objects_and_bytes_preserved": True, "source_preserved": True,
                "consumer_and_journal_preserved": True, "torn_repair_claimed": False})
            record["negative_preservation_cells"] = negative_cells
            save()
    assert len(record["workspaces"]) == 13 and len(record["producer_snapshots"]) == 13
    assert not live
    for item in record["producer_snapshots"]:
        assert tree(Path(item["path"])) == item.get("expected_final_after_fixture_injection", item["before"]), "Product changed producer data"
    assert tree(fixture) == fixture_before
    assert tree(delivery_root) == admission["delivery_files"]
    assert tree(Path(admission["original_self_setup_delivery_root"])) == admission["original_self_setup_delivery_files"]
    assert git("rev-parse", "HEAD") == source_head and not git("status", "--porcelain")
    assert sum(path.stat().st_size for path in SCENARIO.rglob("*") if path.is_file()) < 256 * 1024**2
    assert time.monotonic() < proof_deadline, "Produced recovery proof exceeded its deadline"
    record.update(status="PASS_SCOPED_WINDOWS_PRODUCED_PARTIAL_PACK_RECOVERY",
                  finished_at=now(), positive_producer_and_delivery_bytes_unchanged=True, product_did_not_change_producers_or_delivery=True,
                  clean_consumer_workspaces=13, presentation_loss_boundaries=["precreate", "extracted-entry", "generated-entry"],
                  full_programme_complete=False)
    save()
    print(json.dumps({"status": record["status"], "commands": len(record["commands"]),
                      "clean_consumers": 13, "receipt_sha256": sha(OUTPUT)}))
except BaseException as exc:
    for process in tuple(live):
        process.begin_cleanup()
        if process.poll() is None:
            process.kill()
        try:
            process.communicate(timeout=10)
        except BaseException as cleanup_error:
            record.setdefault("cleanup_errors", []).append(repr(cleanup_error))
    record.update(status="ACTIONABLE_FAILURE", error=repr(exc), traceback=traceback.format_exc(), finished_at=now())
    if run_owns_scenario:
        save()
    print(json.dumps({"status": record["status"], "error": repr(exc), "commands": len(record["commands"])}))
    sys.exit(1)
