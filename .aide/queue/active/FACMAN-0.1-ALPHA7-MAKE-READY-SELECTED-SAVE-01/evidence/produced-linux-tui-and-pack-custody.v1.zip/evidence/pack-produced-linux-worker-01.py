import hashlib,importlib.abc,importlib.util,json,os,sys,unittest
from pathlib import Path,PureWindowsPath
R=Path('/mnt/d/Projects/Factorio/factorio-launcher');E=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
unix=lambda p:Path('/mnt/d').joinpath(*PureWindowsPath(p).parts[1:])
admission=E/'tui-produced-linux-admission-02.json';a=json.loads(admission.read_bytes())
source_path=E/'pack-produced-linux-source-admission-01.json';s=json.loads(source_path.read_bytes())
assert sha(admission)==s['package_admission_sha256'] and a['source_commit']==s['source_commit']
root=unix(a['delivery_root']);exe=unix(a['executable'])
def inventory():return {p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file()}
before=inventory();assert before==a['delivery_files']
assert os.geteuid()==65534 and os.getgroups()==[] and not os.access(root,os.W_OK) and not os.access(R,os.W_OK)
fixture=R/'tests/fixtures/fake_factorio_install'
def fixture_inventory():return {p.relative_to(fixture).as_posix():sha(p) for p in fixture.rglob('*') if p.is_file()}
assert fixture_inventory()==s['fixture_inventory']
home=Path(os.environ['TMPDIR'])/'home';home.mkdir()
os.environ.update(HOME=str(home),XDG_CONFIG_HOME=str(home/'config'),XDG_CACHE_HOME=str(home/'cache'),XDG_DATA_HOME=str(home/'data'),FACMAN_CLI_EXE=str(exe),PYTHONDONTWRITEBYTECODE='1')
sys.path.insert(0,str(R));sys.path.insert(0,str(R/'tests'));loaded={}
class ExactSource(importlib.abc.MetaPathFinder,importlib.abc.Loader):
 def find_spec(self,fullname,path=None,target=None):
  if fullname in s['exact_sources']:return importlib.util.spec_from_loader(fullname,self)
 def create_module(self,spec):return None
 def exec_module(self,module):
  entry=s['exact_sources'][module.__name__];data=(E/'pack-produced-linux-exact-sources-01'/(module.__name__+'.py')).read_bytes()
  assert hashlib.sha256(data).hexdigest()==entry['sha256'];loaded[module.__name__]=entry['sha256']
  module.__file__=str(R/entry['path']);exec(compile(data,module.__file__,'exec'),module.__dict__)
sys.meta_path.insert(0,ExactSource())
import native_cli
original=native_cli.invoke;commands=[]
log=(E/'pack-produced-linux-commands-01.ndjson').open('x',encoding='utf-8')
def invoke(*args,**kwargs):
 result=original(*args,**kwargs)
 env=kwargs.get('env') or {};row=dict(argv=[str(x) for x in args[0]],exit=result[0],stdout=result[1],stderr=result[2],faults={k:v for k,v in env.items() if k.startswith('FACMAN_TEST_')})
 commands.append(row);log.write(json.dumps(row)+'\n');log.flush();return result
native_cli.invoke=invoke
methods=['test_exported_pack_reconstructs_offline_exact_bytes_and_rebound_local_lock',
 'test_existing_target_and_foreign_staging_are_preserved',
 'test_process_loss_before_staging_reconstructs_from_the_original_durable_source_binding',
 'test_missing_entry_recovery_survives_a_second_interruption_and_preserves_existing_objects',
 'test_generated_intent_precedes_writes_and_resumes_missing_generated_files',
 'test_partial_recovery_refuses_changed_source_context_inventory_and_markers_without_effects',
 'test_generated_recovery_refuses_drift_without_new_file_or_journal_effects']
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(['test_portable_modpack_import.PortableModpackImportTests.'+m for m in methods]))
log.close();after=inventory()
v=dict(schema='facman.produced_linux_offline_pack_acceptance.v1',source_commit=s['source_commit'],source_tree=s['source_tree'],producer_commit=a['producer_commit'],package_admission_sha256=sha(admission),source_admission_sha256=sha(source_path),executable_sha256=sha(exe),methods=methods,tests=result.testsRun,skips=result.skipped,failures=len(result.failures),errors=len(result.errors),command_count=len(commands),commands_sha256=sha(E/'pack-produced-linux-commands-01.ndjson'),exact_modules=loaded,delivery_unchanged=before==after,fixture_unchanged=fixture_inventory()==s['fixture_inventory'],uid=os.geteuid(),groups=os.getgroups(),package_read_only=True,source_read_only=True,subcases_filtered=False,scope='FacMan offline pack reconstruction, supported interruption recovery and preservation/refusal; synthetic installation inputs',usk_extraction_qualified=False,posix_uncooperative_namespace_qualified=False,physical_ext4_host=False,human=False,game=False,beta=False)
v['status']='PASS_PRODUCED_LINUX_OFFLINE_PACK_SCOPE' if result.wasSuccessful() and result.testsRun==7 and not result.skipped and v['delivery_unchanged'] and v['fixture_unchanged'] else 'ACTIONABLE_PRODUCED_LINUX_PACK_FAILURE'
(E/'pack-produced-linux-result-01.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v))
raise SystemExit(0 if v['status']=='PASS_PRODUCED_LINUX_OFFLINE_PACK_SCOPE' else 1)
