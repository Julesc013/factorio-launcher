import hashlib,json,os,subprocess,traceback
from pathlib import Path
R=Path('/mnt/d/Projects/Factorio/factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
root=W/'tui-produced-linux-delivery-01';fixture=E/'posix-publication-private-fixtures-01'
out=E/'tui-produced-linux-private-result-01.json';assert not out.exists()
assert fixture.is_dir() and not list(fixture.iterdir()) and not os.path.ismount(fixture)
mounted=[];v=dict(status='STARTING_SCOPED_PRIVATE_PRODUCED_TUI_PROOF',new_roots=0,new_candidates=0,new_clones=0,goal_status_mutated=False)
try:
 for path in (root,R):
  subprocess.run(['mount','--bind',str(path),str(path)],check=True,timeout=30)
  mounted.append(path)
  subprocess.run(['mount','-o','remount,bind,ro',str(path)],check=True,timeout=30)
 subprocess.run(['mount','-t','tmpfs','-o','size=128m,nosuid,nodev,mode=1777','facman-tui-package-proof',str(fixture)],check=True,timeout=30);mounted.append(fixture)
 env=dict(os.environ,TMPDIR=str(fixture),TMP=str(fixture),TEMP=str(fixture),PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='0',FACMAN_DEV_ROOT='/mnt/d/Projects/Factorio/.task-builds')
 with (E/'tui-produced-linux-tests-01.stdout').open('xb') as stdout,(E/'tui-produced-linux-tests-01.stderr').open('xb') as stderr:
  p=subprocess.run(['setpriv','--reuid=65534','--regid=65534','--clear-groups','python3','-B',str(E/'tui-produced-linux-worker-01.py')],cwd=R,env=env,stdout=stdout,stderr=stderr,timeout=480)
 v['worker_exit']=p.returncode
 result=json.loads((E/'tui-produced-linux-result-01.json').read_bytes());v['worker_result_sha256']=sha(E/'tui-produced-linux-result-01.json')
 assert p.returncode==0 and result['status']=='PASS_PRODUCED_LINUX_ORDINARY_AND_PTY'
 v['status']='PASS_SCOPED_PRODUCED_LINUX_TUI_PRIVATE_EXECUTION'
except BaseException as ex:v.update(status='ACTIONABLE_PRODUCED_TUI_EXECUTION_FAILURE',error=str(ex),traceback=traceback.format_exc())
finally:
 if fixture in mounted and list(fixture.iterdir()):
  archive=E/'tui-produced-linux-synthetic-fixture-state-01.tar';assert not archive.exists()
  subprocess.run(['tar','-cf',str(archive),'-C',str(fixture),'.'],check=True,timeout=60);v['synthetic_fixture_archive_sha256']=sha(archive)
 for path in reversed(mounted):subprocess.run(['umount',str(path)],check=True,timeout=30)
 v.update(private_mount_absent=not os.path.ismount(fixture),package_bind_absent=not os.path.ismount(root),source_bind_absent=not os.path.ismount(R))
 out.write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v))
raise SystemExit(0 if v['status']=='PASS_SCOPED_PRODUCED_LINUX_TUI_PRIVATE_EXECUTION' else 1)
