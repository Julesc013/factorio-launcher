import hashlib,json,os,subprocess,sys,traceback,zipfile
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1')
sys.path.insert(0,str(R));from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
P='tui-produced-linux';a=json.loads((E/'tui-selected-save-source-assurance-04.json').read_bytes())
Q='.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
paths=[Q+'/ExecPlan.md',Q+'/evidence/produced-linux-tui-and-pack-custody.v1.zip',Q+'/evidence/produced-linux-tui-and-pack.v1.json']
out=E/(P+'-commit-result-01.json');assert not out.exists()
v=dict(status='REVIEWING_SCOPED_QUALIFICATION_CHECKPOINT',base=a['base'],commands=[],goal_status_mutated=False)
def save():out.write_text(json.dumps(v,indent=2)+'\n')
def run(label,args,timeout=180):
 r=owned.command(args,cwd=R,environment=dict(os.environ),timeout=timeout,directory=E/(P+'-commit01-'+label),output_limit=1024*1024)
 v['commands'].append(dict(label=label,exit=r.returncode,receipt_sha256=sha(r.directory/'receipt.json')));save()
 assert r.ok and r.receipt['primary_stopped'] and r.receipt['job_empty_observed'],(label,r.stderr[-1500:].decode('utf-8','replace'))
 return r
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
try:
 assert git('rev-parse','HEAD')==a['base'] and git('branch','--show-current')==a['branch']
 assert git('rev-parse','origin/dev')==a['upstream_integration']
 for n,h in a['source_files_sha256'].items():assert sha(R/n)==h,n
 actual=set(subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines())
 actual.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R,text=True).splitlines())
 assert actual==set(paths) and not git('diff','--cached','--name-only')
 receipt=json.loads((R/paths[2]).read_bytes());archive=R/paths[1]
 assert receipt['qualified_source']==a['base'] and receipt['custody_sha256']==sha(archive)
 with zipfile.ZipFile(archive) as z:
  m=json.loads(z.read('custody-manifest.json'));assert len(z.infolist())==receipt['custody_members']==len(m)+1
  for n,h in m.items():assert hashlib.sha256(z.read('evidence/'+n)).hexdigest()==h,n
 assert receipt['tui_tests']==5 and receipt['pack_tests']==7 and receipt['skips']==0
 native=json.loads((E/'tui-selected-save-native-result-07.json').read_bytes())
 assert native['status']=='PASS_SCOPED_NATIVE_ORDINARY_TUI_SELECTED_SAVE'
 assert receipt['combined_windows_native_result_sha256']==sha(E/'tui-selected-save-native-result-07.json')
 for label in ('policy','detect','plan'):run(label,['py','-3','-B','.aide/scripts/aide_lite.py','git',label])
 run('strict',['py','-3','-B','tools/strict_check.py'],1800)
 message='test(tui): qualify delivered Linux terminal workflows\n\nWork-Item: FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01\nEvidence-Ref: '+paths[2]+'\n'
 message_file=E/(P+'-commit-message-01.txt');message_file.write_text(message,encoding='utf-8',newline='\n')
 run('message',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--message',message])
 changes=[dict(path=n,state='content',sha256=sha(R/n),git_blob_oid=git('hash-object','--path',n,str(R/n)),ownership='task_owned') for n in sorted(paths)]
 snapshot=hashlib.sha256((json.dumps(changes,indent=2,sort_keys=True,separators=(',',': '))+'\n').encode()).hexdigest()
 msg_sha=sha(message_file)
 review=E/(P+'-commit-review-01.json')
 review.write_text(json.dumps(dict(schema_version='aide.git-commit-review.v1',verdict='PASS',reviewer='/root',runtime_author='/root/tui_selected_save_impl',non_authoring_runtime=True,branch=a['branch'],base_commit=a['base'],snapshot_sha256=snapshot,message_sha256=msg_sha,source_assurance_sha256=sha(E/'tui-selected-save-source-assurance-04.json'),scope='three evidence/checkpoint paths; fourteen TUI source hashes unchanged',linux_produced_qualification_sha256=receipt['pack_result_sha256'],windows_qualification_sha256=receipt['combined_windows_native_result_sha256'],custody_verified=True),indent=2)+'\n')
 classification=E/(P+'-classification-01.json')
 classification.write_text(json.dumps(dict(schema_version='aide.git-commit-classification.v1',branch=a['branch'],base_commit=a['base'],work_item='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01',snapshot_sha256=snapshot,message_sha256=msg_sha,changed_paths=changes,reviews=[dict(path=str(review),sha256=sha(review),verdict='PASS')]),indent=2)+'\n')
 helper=['py','-3','-B','.aide/scripts/aide_lite.py','git','commit-plan','--classification',str(classification),'--message-file',str(message_file)]
 run('plan-stage',helper);run('stage',['git','add','--',*paths]);run('staged-diff',['git','diff','--cached','--check']);run('plan-commit',helper)
 assert git('rev-parse','HEAD')==a['base']
 run('commit',['git','commit','-F',str(message_file)])
 v.update(status='COMMITTED_COMBINED_QUALIFICATION',source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'));save()
 run('range',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--range',a['upstream_integration']+'..HEAD'])
 assert not git('status','--porcelain')
 v.update(status='COMMITTED_QUALIFIED_TUI_CHECKPOINT_AWAITING_EXISTING_RETRY',pr=409,changed_paths=paths,published_history_preserved=True,remote_not_pushed=True)
except BaseException as ex:v.update(error=str(ex),traceback=traceback.format_exc())
finally:save();print(json.dumps({k:x for k,x in v.items() if k!='commands'},indent=2))
