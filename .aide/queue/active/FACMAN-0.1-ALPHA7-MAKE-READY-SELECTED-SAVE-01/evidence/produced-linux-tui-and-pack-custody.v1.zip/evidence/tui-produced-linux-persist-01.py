import hashlib,json,subprocess,zipfile
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert subprocess.check_output(['git','branch','--show-current'],cwd=R,text=True).strip()=='task/facman-tui-selected-save-01'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R)
n=json.loads((E/'tui-selected-save-native-result-07.json').read_bytes())
assert n['status']=='PASS_SCOPED_NATIVE_ORDINARY_TUI_SELECTED_SAVE'
t=json.loads((E/'tui-produced-linux-result-02.json').read_bytes());p=json.loads((E/'pack-produced-linux-result-01.json').read_bytes())
assert t['tests']==5 and p['tests']==7 and not t['skips'] and not p['skips']
assert t['status']=='PASS_PRODUCED_LINUX_ORDINARY_AND_PTY' and p['status']=='PASS_PRODUCED_LINUX_OFFLINE_PACK_SCOPE'
assert t['delivery_unchanged'] and p['delivery_unchanged'] and p['fixture_unchanged'] and not p['subcases_filtered']
assert json.loads((E/'tui-produced-linux-acceptance-review-02.json').read_bytes())['verdict']=='PASS_SCOPED_PRODUCED_LINUX_TUI_ACCEPTANCE'
assert json.loads((E/'pack-produced-linux-acceptance-review-01.json').read_bytes())['verdict']=='PASS_SCOPED_PRODUCED_LINUX_OFFLINE_PACK_ACCEPTANCE'
files=set()
for pattern in ('tui-produced-linux-*.json','tui-produced-linux-*.py','tui-produced-linux-*.stdout','tui-produced-linux-*.stderr',
                'pack-produced-linux-*.json','pack-produced-linux-*.py','pack-produced-linux-*.ndjson','pack-produced-linux-*.stdout','pack-produced-linux-*.stderr',
                'tui-selected-save-dev-sync-result-01.json','tui-selected-save-source-assurance-04.json','tui-selected-save-native-result-07.json'):
 files.update(E.glob(pattern))
for name in ('tui-produced-linux-exact-tests-01','tui-produced-linux-source-truth-01','pack-produced-linux-exact-sources-01'):
 files.update(p for p in (E/name).iterdir() if p.is_file())
for pattern in ('tui-produced-linux-owned-execution-*','pack-produced-linux-owned-execution-*','tui-selected-save-*-execution-07'):
 for directory in E.glob(pattern):
  if directory.is_dir():files.update(p for p in directory.iterdir() if p.name in ('receipt.json','stdout.raw','stderr.raw'))
assert all(p.is_file() and p.resolve().is_relative_to(E.resolve()) and p.suffix not in ('.exe','.dll','.bin','.zip') for p in files)
Q=R/'.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01';archive=Q/'evidence/produced-linux-tui-and-pack-custody.v1.zip';out=Q/'evidence/produced-linux-tui-and-pack.v1.json'
assert not archive.exists() and not out.exists()
manifest={p.relative_to(E).as_posix():sha(p) for p in sorted(files)}
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files):
  i=zipfile.ZipInfo('evidence/'+p.relative_to(E).as_posix(),(1980,1,1,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,p.read_bytes())
 i=zipfile.ZipInfo('custody-manifest.json',(1980,1,1,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,json.dumps(manifest,indent=2)+'\n')
v=dict(schema='facman.produced_linux_tui_and_pack_acceptance.v1',work_item=Q.name,
 qualified_source='ceae116a08894dbc43c1d87c54c3ed4f3d06858c',source_commit=t['source_commit'],source_tree=t['source_tree'],producer_commit=t['producer_commit'],
 workflow_run=38272752230,artifact_id=11759083596,artifact_sha256='9a4d8249bac1165ef51c6bf667886581e1c2c56696c15f6570a9feca13742d14',
 executable_sha256=t['executable_sha256'],tui_tests=5,pack_tests=7,skips=0,pack_command_count=p['command_count'],
 tui_result_sha256=sha(E/'tui-produced-linux-result-02.json'),pack_result_sha256=sha(E/'pack-produced-linux-result-01.json'),
 tui_review_sha256=sha(E/'tui-produced-linux-acceptance-review-02.json'),pack_review_sha256=sha(E/'pack-produced-linux-acceptance-review-01.json'),
 package_and_checkout_read_only=True,uid=65534,groups=[],workspace_filesystem='private bounded128MiB tmpfs in WSL Ubuntu24.04',
 package_fixture_unchanged=True,all_selected_test_subcases_run=True,initial_transport_probe_failure_preserved=True,
 combined_dev_source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
 combined_windows_native_result_sha256=sha(E/'tui-selected-save-native-result-07.json'),
 custody_archive=archive.name,custody_sha256=sha(archive),custody_members=len(files)+1,
 new_candidates=0,new_clones=0,new_worktrees=0,new_task_roots=0,
 usk_extraction_qualified=False,posix_uncooperative_namespace_qualified=False,physical_ext4_host=False,
 macos=False,selected_save_posix_owner=False,human=False,game=False,beta=False,workunit_closed=False)
out.write_text(json.dumps(v,indent=2)+'\n')
with (Q/'ExecPlan.md').open('a',encoding='utf-8') as f:
 f.write('\n### Produced Linux terminal and offline reconstruction\n\n'
 'The existing c95809b6 producer artifact has an identical reviewed source\n'
 'tree and verified provider/package inventory. Its actual TUI passes five\n'
 'ordinary/PTY methods, including resize, no-color and terminal restoration.\n'
 'The same image passes all seven selected offline import methods and244\n'
 'native calls, preserving selected content, settings, provenance and known\n'
 'objects through supported losses and replay. Changed, foreign and torn\n'
 'entries are preserved/refused. Every selected subcase ran unfiltered.\n'
 'Package and checkout were read-only; workspaces used owned unprivileged\n'
 'bounded private tmpfs. The initial v2 probe-oracle failure is retained.\n'
 'The TUI branch also normally merges checked dev0b8e8b6 and requalifies\n'
 'Windows native, ordinary and ConPTY behavior. See the produced Linux\n'
 'receipt and custody in evidence/produced-linux-tui-and-pack.v1.json.\n'
 'USK extraction, uncooperative POSIX namespaces, physical ext4/APFS,\n'
 'genuine game/human, canonical installed Desktop and Beta remain open.\n')
print(json.dumps(dict(status='PERSISTED_COMBINED_TUI_AND_DELIVERED_LINUX_ACCEPTANCE',receipt_sha256=sha(out),archive_sha256=sha(archive),members=len(files)+1,bytes=archive.stat().st_size)))
