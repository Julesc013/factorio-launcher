import hashlib,importlib.abc,importlib.util,json,os,subprocess,sys,unittest
from pathlib import Path,PureWindowsPath
R=Path('/mnt/d/Projects/Factorio/factorio-launcher');E=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
unix=lambda p:Path('/mnt/d').joinpath(*PureWindowsPath(p).parts[1:])
a_path=E/'tui-produced-linux-admission-02.json';a=json.loads(a_path.read_bytes())
assert a['status']=='ADMITTED_EXISTING_LINUX_PRODUCED_TUI_PACKAGE'
root=unix(a['delivery_root']);exe=unix(a['executable']);sources=unix(a['exact_test_root'])
def inventory():return {p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file()}
before=inventory();assert before==a['delivery_files'] and sha(exe)==a['executable_sha256']
assert os.geteuid()==65534 and os.getgroups()==[]
assert not os.access(root,os.W_OK) and not os.access(R,os.W_OK)
os.environ.update(FACMAN_CLI_EXE=str(exe),FACMAN_TUI_EXE=str(exe),PYTHONDONTWRITEBYTECODE='1')
fixture=Path(os.environ['TMPDIR']);home=fixture/'home';home.mkdir()
os.environ.update(HOME=str(home),XDG_CONFIG_HOME=str(home/'config'),XDG_CACHE_HOME=str(home/'cache'),XDG_DATA_HOME=str(home/'data'))
loaded={}
class ExactSource(importlib.abc.MetaPathFinder,importlib.abc.Loader):
 def find_spec(self,fullname,path=None,target=None):
  if fullname in a['exact_test_sources']:return importlib.util.spec_from_loader(fullname,self)
 def create_module(self,spec):return None
 def exec_module(self,module):
  data=(sources/(module.__name__+'.py')).read_bytes();h=hashlib.sha256(data).hexdigest()
  assert h==a['exact_test_sources'][module.__name__];loaded[module.__name__]=h
  module.__file__=str(R/'tests'/(module.__name__+'.py'))
  exec(compile(data,module.__file__,'exec'),module.__dict__)
sys.meta_path.insert(0,ExactSource())
names=['test_tui_product.TuiProductTests.test_ordinary_observation_choice_preserves_empty_workspace',
       'test_tui_product.TuiProductTests.test_ordinary_shell_pages_launch_deck_and_advanced_handoff','test_tui_pty']
v=dict(schema='facman.tui_selected_save_produced_linux_scope.v1',source_commit=a['source_commit'],
 producer_commit=a['producer_commit'],source_tree=a['source_tree'],admission_sha256=sha(a_path),
 executable_sha256=sha(exe),uid=os.geteuid(),groups=os.getgroups(),package_read_only=True,source_read_only=True,
 selected_save_owner_qualified=False,physical_ext4_host=False,human=False,game=False,beta=False)
try:
 inspect=subprocess.run([str(exe),'--workspace',str(fixture/'identity-consumer'),'product','inspect','--json'],capture_output=True,timeout=60)
 (E/'tui-produced-linux-product-inspect-02.stdout').write_bytes(inspect.stdout)
 (E/'tui-produced-linux-product-inspect-02.stderr').write_bytes(inspect.stderr)
 assert inspect.returncode==0 and not inspect.stderr
 product=json.loads(inspect.stdout);assert product['schema']=='facman.transport_response.v2' and product['protocol_version']==2 and product['command']=='product.inspect' and product['outcome']=='ok' and product['error'] is None
 spec=importlib.util.spec_from_file_location('_exact_runtime_identity',sources/'runtime_identity.py')
 helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
 assert sha(sources/'runtime_identity.py')==a['runtime_identity_helper_sha256']
 identity=helper.require_backend_identity(root,exe,product['payload']);assert identity['compiled_source_revision']==a['producer_commit']
 v['backend_identity']=identity
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(names))
 after=inventory();v.update(tests=result.testsRun,skips=result.skipped,failures=len(result.failures),errors=len(result.errors),exact_test_modules=loaded,delivery_unchanged=before==after)
 assert result.wasSuccessful() and result.testsRun==5 and not result.skipped and before==after
 v['status']='PASS_PRODUCED_LINUX_ORDINARY_AND_PTY'
except BaseException as ex:
 import traceback
 v.update(status='ACTIONABLE_PRODUCED_LINUX_TUI_FAILURE',error=str(ex),traceback=traceback.format_exc())
finally:
 (E/'tui-produced-linux-result-02.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v))
raise SystemExit(0 if v['status']=='PASS_PRODUCED_LINUX_ORDINARY_AND_PTY' else 1)
