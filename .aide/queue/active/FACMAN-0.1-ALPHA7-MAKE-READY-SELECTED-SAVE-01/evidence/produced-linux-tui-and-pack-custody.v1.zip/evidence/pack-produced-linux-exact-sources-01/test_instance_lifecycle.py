# SPDX-FileCopyrightText: 2026 Jules C
# SPDX-License-Identifier: MIT

from __future__ import annotations

import hashlib
import json
import os
import tempfile
import unittest
from contextlib import contextmanager
from pathlib import Path

from native_cli import invoke
from tools import json_contract


ROOT = Path(__file__).resolve().parents[1]
FIXTURE_INSTALL = ROOT / "tests" / "fixtures" / "fake_factorio_install"
SCHEMA_ROOT = ROOT / "contracts" / "schema" / "factorio"


def assert_schema(test: unittest.TestCase, document: dict, name: str) -> None:
    schema = json_contract.load_schema(SCHEMA_ROOT / name)
    test.assertEqual([], json_contract.validate(document, schema), name)


def snapshot(root: Path) -> dict[str, str]:
    return {
        path.relative_to(root).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(item for item in root.rglob("*") if item.is_file())
    }


def snapshot_without_configuration_lock(root: Path) -> dict[str, str]:
    return {path: digest for path, digest in snapshot(root).items()
            if path != "locks/configuration.write.lock"}


def create_fixture(workspace: Path, instance_id: str = "main") -> Path:
    code, stdout, stderr = invoke([
        "--workspace", str(workspace), "installs", "import", str(FIXTURE_INSTALL), "--id", "fixture", "--json",
    ])
    if code != 0:
        raise AssertionError(stderr or stdout)
    code, stdout, stderr = invoke([
        "--workspace", str(workspace), "instances", "create", instance_id,
        "--id", instance_id, "--install", "fixture", "--json",
    ])
    if code != 0:
        raise AssertionError(stderr or stdout)
    root = workspace / "instances" / instance_id
    (root / "script-output" / "preserved.txt").write_text("preserved\n", encoding="utf-8")
    (root / "logs" / "volatile.log").write_text("volatile\n", encoding="utf-8")
    return root


@contextmanager
def hold_configuration_lock(path: Path):
    if os.name == "nt":
        import ctypes

        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.CreateFileW.argtypes = [ctypes.c_wchar_p, ctypes.c_uint32, ctypes.c_uint32,
                                       ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32,
                                       ctypes.c_void_p]
        kernel.CreateFileW.restype = ctypes.c_void_p
        kernel.CloseHandle.argtypes = [ctypes.c_void_p]
        handle = kernel.CreateFileW(str(path), 0xC0010000, 1, None, 3, 0x00200000, None)
        if handle in (None, ctypes.c_void_p(-1).value):
            raise OSError(ctypes.get_last_error(), "Cannot hold instance configuration lock")
        try:
            yield
        finally:
            kernel.CloseHandle(handle)
    else:
        import fcntl

        descriptor = os.open(path, os.O_RDWR | os.O_NOFOLLOW)
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
            yield
        finally:
            fcntl.flock(descriptor, fcntl.LOCK_UN)
            os.close(descriptor)


class InstanceLifecycleTests(unittest.TestCase):
    def test_clone_refuses_an_active_or_changed_source_configuration_lock(self) -> None:
        with tempfile.TemporaryDirectory(prefix="facman clone source lock ") as temporary:
            workspace = Path(temporary)
            source = create_fixture(workspace)
            marker = source / "locks" / "configuration.write.lock"
            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "instances", "clone", "main", "main", "--json",
            ])
            self.assertNotEqual(0, code, stderr or stdout)
            self.assertEqual("instance_clone_target_exists", json.loads(stdout)["refusal"]["code"])
            self.assertFalse(marker.exists())

            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "profiles", "apply", "main", "gui", "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)
            original_marker = marker.read_bytes()
            source_manifest = (source / "instance.v1.json").read_bytes()
            with hold_configuration_lock(marker):
                code, stdout, stderr = invoke([
                    "--workspace", str(workspace), "instances", "clone", "main", "copy", "--json",
                ])
                self.assertNotEqual(0, code, stderr or stdout)
                self.assertEqual("instance_configuration_lock_contended", json.loads(stdout)["refusal"]["code"])
                self.assertFalse((workspace / "instances" / "copy").exists())
                self.assertEqual(source_manifest, (source / "instance.v1.json").read_bytes())

            marker.write_text("unrecognized lock\n", encoding="utf-8")
            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "instances", "clone", "main", "copy", "--json",
            ])
            self.assertNotEqual(0, code, stderr or stdout)
            self.assertEqual("instance_configuration_lock_unsafe", json.loads(stdout)["refusal"]["code"])
            self.assertFalse((workspace / "instances" / "copy").exists())
            marker.write_bytes(original_marker)
            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "instances", "clone", "main", "copy", "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)
            self.assertEqual("preserved\n", (workspace / "instances" / "copy" / "script-output" / "preserved.txt").read_text())
            self.assertFalse((workspace / "instances" / "copy" / "locks" / "configuration.write.lock").exists())

    def test_profile_recovery_waits_for_active_instance_configuration_owner(self) -> None:
        with tempfile.TemporaryDirectory(prefix="facman profile recovery lock ") as temporary:
            workspace = Path(temporary)
            instance = create_fixture(workspace)
            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "profiles", "create", "quiet",
                "--audio", "disabled", "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)
            env = os.environ.copy()
            env["FACMAN_TEST_PROFILE_APPLY_EXIT_AFTER_MANIFEST"] = "1"
            code, _, _ = invoke([
                "--workspace", str(workspace), "profiles", "apply", "main", "quiet", "--json",
            ], env=env)
            self.assertEqual(86, code)
            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "workspace", "recovery", "inspect", "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)
            transaction = next(item for item in json.loads(stdout)["transactions"]
                               if item["command_id"] == "profiles.apply")
            marker = instance / "locks" / "configuration.write.lock"
            with hold_configuration_lock(marker):
                code, stdout, stderr = invoke([
                    "--workspace", str(workspace), "workspace", "recovery", "apply",
                    transaction["transaction_id"], "--json",
                ])
                self.assertNotEqual(0, code, stderr or stdout)
                self.assertEqual("instance_configuration_lock_contended",
                                 json.loads(stdout)["refusal"]["code"])
                self.assertFalse((instance / "instance-overrides.v1.json").exists())
            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "workspace", "recovery", "apply",
                transaction["transaction_id"], "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)
            self.assertEqual("complete", json.loads(stdout)["transactions"][0]["state"])
            self.assertEqual("quiet", json.loads((instance / "instance-overrides.v1.json").read_text())["profile_id"])

    def test_profile_and_rename_refuse_the_same_active_configuration_lock(self) -> None:
        with tempfile.TemporaryDirectory(prefix="facman instance config lock ") as temporary:
            workspace = Path(temporary)
            instance = create_fixture(workspace)
            marker = instance / "locks" / "configuration.write.lock"
            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "profiles", "apply", "main", "missing", "--json",
            ])
            self.assertNotEqual(0, code, stderr or stdout)
            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "instances", "rename", "main",
                "--name", "Stale", "--expected-revision", "0" * 64, "--json",
            ])
            self.assertNotEqual(0, code, stderr or stdout)
            self.assertFalse(marker.exists())
            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "profiles", "apply", "main", "gui", "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)
            manifest = (instance / "instance.v1.json").read_bytes()
            overrides = (instance / "instance-overrides.v1.json").read_bytes()
            original_marker = marker.read_bytes()
            self.assertIn(b"facman.instance_configuration_lock.v1", original_marker)
            with hold_configuration_lock(marker):
                for command in (("instances", "rename", "main", "--name", "Blocked"),
                                ("profiles", "apply", "main", "gui")):
                    code, stdout, stderr = invoke([
                        "--workspace", str(workspace), *command, "--json",
                    ])
                    self.assertNotEqual(0, code, stderr or stdout)
                    self.assertEqual("instance_configuration_lock_contended",
                                     json.loads(stdout)["refusal"]["code"])
                self.assertEqual(manifest, (instance / "instance.v1.json").read_bytes())
                self.assertEqual(overrides, (instance / "instance-overrides.v1.json").read_bytes())
            marker.write_text("unrecognized lock\n", encoding="utf-8")
            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "instances", "rename", "main",
                "--name", "Blocked", "--json",
            ])
            self.assertNotEqual(0, code, stderr or stdout)
            self.assertEqual("instance_configuration_lock_unsafe", json.loads(stdout)["refusal"]["code"])
            self.assertEqual(manifest, (instance / "instance.v1.json").read_bytes())
            marker.write_bytes(original_marker)
            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "instances", "rename", "main",
                "--name", "Allowed", "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)

    def test_rename_staged_interruption_rolls_back_verified_file(self) -> None:
        with tempfile.TemporaryDirectory(prefix="facman rename staged recovery ") as temporary:
            workspace = Path(temporary)
            instance = create_fixture(workspace)
            original = (instance / "instance.v1.json").read_bytes()
            env = os.environ.copy()
            env["FACMAN_TEST_TRANSACTION_FAIL_STATE"] = "committing"
            code, _, _ = invoke([
                "--workspace", str(workspace), "instances", "rename", "main",
                "--name", "Renamed", "--json",
            ], env=env)
            self.assertNotEqual(0, code)
            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "workspace", "recovery", "inspect", "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)
            transaction = next(item for item in json.loads(stdout)["transactions"]
                               if item["command_id"] == "instances.rename")
            stage = instance / (".instance.rename." + transaction["transaction_id"] + ".staging")
            self.assertTrue(stage.is_file())
            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "workspace", "recovery", "apply",
                transaction["transaction_id"], "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)
            self.assertEqual("rolled_back", json.loads(stdout)["transactions"][0]["state"])
            self.assertEqual(original, (instance / "instance.v1.json").read_bytes())
            self.assertFalse(stage.exists())

    def test_rename_recovery_refuses_changed_stage(self) -> None:
        with tempfile.TemporaryDirectory(prefix="facman rename changed stage ") as temporary:
            workspace = Path(temporary)
            instance = create_fixture(workspace)
            original = (instance / "instance.v1.json").read_bytes()
            env = os.environ.copy()
            env["FACMAN_TEST_TRANSACTION_FAIL_STATE"] = "committing"
            code, _, _ = invoke([
                "--workspace", str(workspace), "instances", "rename", "main",
                "--name", "Renamed", "--json",
            ], env=env)
            self.assertNotEqual(0, code)
            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "workspace", "recovery", "inspect", "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)
            transaction = next(item for item in json.loads(stdout)["transactions"]
                               if item["command_id"] == "instances.rename")
            stage = instance / (".instance.rename." + transaction["transaction_id"] + ".staging")
            stage.write_text('{"unowned":true}\n', encoding="utf-8")
            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "workspace", "recovery", "apply",
                transaction["transaction_id"], "--json",
            ])
            self.assertNotEqual(0, code, stderr or stdout)
            self.assertEqual("recovery_instance_rename_unsafe", json.loads(stdout)["refusal"]["code"])
            self.assertEqual(original, (instance / "instance.v1.json").read_bytes())
            self.assertTrue(stage.exists())

    def test_rename_crash_after_journal_rolls_back_without_effect(self) -> None:
        with tempfile.TemporaryDirectory(prefix="facman rename journal recovery ") as temporary:
            workspace = Path(temporary)
            instance = create_fixture(workspace)
            original = (instance / "instance.v1.json").read_bytes()
            env = os.environ.copy()
            env["FACMAN_TEST_INSTANCE_RENAME_EXIT_AFTER_JOURNAL"] = "1"
            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "instances", "rename", "main",
                "--name", "Renamed", "--json",
            ], env=env)
            self.assertEqual(84, code, stderr or stdout)
            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "workspace", "recovery", "inspect", "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)
            transaction = next(item for item in json.loads(stdout)["transactions"]
                               if item["command_id"] == "instances.rename")
            self.assertEqual("requested", transaction["state"])
            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "workspace", "recovery", "apply",
                transaction["transaction_id"], "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)
            self.assertEqual("rolled_back", json.loads(stdout)["transactions"][0]["state"])
            self.assertEqual(original, (instance / "instance.v1.json").read_bytes())
            self.assertEqual("preserved\n", (instance / "script-output" / "preserved.txt").read_text())

    def test_rename_crash_after_replace_closes_verified_journal(self) -> None:
        with tempfile.TemporaryDirectory(prefix="facman rename published recovery ") as temporary:
            workspace = Path(temporary)
            instance = create_fixture(workspace)
            original = (instance / "instance.v1.json").read_bytes()
            env = os.environ.copy()
            env["FACMAN_TEST_INSTANCE_RENAME_EXIT_AFTER_REPLACE"] = "1"
            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "instances", "rename", "main",
                "--name", "Renamed", "--json",
            ], env=env)
            self.assertEqual(88, code, stderr or stdout)
            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "workspace", "recovery", "inspect", "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)
            transaction = next(item for item in json.loads(stdout)["transactions"]
                               if item["command_id"] == "instances.rename")
            self.assertEqual("committing", transaction["state"])
            self.assertEqual("Renamed", json.loads((instance / "instance.v1.json").read_text())["display_name"])
            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "workspace", "recovery", "apply",
                transaction["transaction_id"], "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)
            self.assertEqual("complete", json.loads(stdout)["transactions"][0]["state"])
            backup = workspace / "backups" / "instances" / (transaction["transaction_id"] + "-main")
            self.assertEqual(original, (backup / "instance.v1.json").read_bytes())
            self.assertEqual("preserved\n", (instance / "script-output" / "preserved.txt").read_text())

    def test_clone_rename_archive_restore_is_reversible_and_id_immutable(self) -> None:
        with tempfile.TemporaryDirectory(prefix="facman lifecycle ") as temporary:
            workspace = Path(temporary)
            source = create_fixture(workspace)
            source_before = snapshot(source)

            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "instances", "inspect", "main", "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)
            inspected = json.loads(stdout)
            assert_schema(self, inspected, "factorio_instance_inspection.v1.schema.json")
            self.assertEqual("main", inspected["instance_id"])
            self.assertEqual("not_granted", inspected["run_authority_state"])
            self.assertFalse(inspected["mutation_executed"])

            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "instances", "clone", "main", "copy",
                "--name", "Copy Display", "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)
            cloned = json.loads(stdout)
            assert_schema(self, cloned, "factorio_instance_lifecycle.v1.schema.json")
            self.assertFalse(cloned["hard_delete_available"])
            copy = workspace / "instances" / "copy"
            self.assertTrue((copy / "script-output" / "preserved.txt").is_file())
            self.assertFalse((copy / "logs" / "volatile.log").exists())
            self.assertEqual(source_before, snapshot_without_configuration_lock(source))

            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "instances", "verify", "copy", "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)
            verified = json.loads(stdout)
            assert_schema(self, verified, "factorio_instance_verification.v1.schema.json")
            self.assertIn(verified["status"], {"pass", "warning"})

            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "instances", "inspect", "copy", "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)
            revision = json.loads(stdout)["manifest_sha256"]
            before_rename = json.loads((copy / "instance.v1.json").read_text(encoding="utf-8"))
            self.assertEqual(
                hashlib.sha256((copy / "instance.v1.json").read_bytes()).hexdigest(), revision,
            )

            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "instances", "rename", "copy",
                "--name", "Renamed Display", "--expected-revision", revision, "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)
            manifest = json.loads((copy / "instance.v1.json").read_text(encoding="utf-8"))
            self.assertEqual("copy", manifest["instance_id"])
            self.assertEqual("Renamed Display", manifest["display_name"])
            before_rename["display_name"] = "Renamed Display"
            self.assertEqual(before_rename, manifest)
            self.assertTrue(any((workspace / "backups" / "instances").rglob("instance.v1.json")))

            renamed_bytes = (copy / "instance.v1.json").read_bytes()
            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "instances", "rename", "copy",
                "--name", "Stale Display", "--expected-revision", revision, "--json",
            ])
            self.assertNotEqual(0, code)
            self.assertIn("instance_manifest_revision_changed", stdout + stderr)
            self.assertEqual(renamed_bytes, (copy / "instance.v1.json").read_bytes())

            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "instances", "diff", "main", "copy", "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)
            compared = json.loads(stdout)
            assert_schema(self, compared, "factorio_instance_diff.v1.schema.json")
            self.assertTrue(compared["volatile_content_ignored"])

            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "instances", "archive", "copy", "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)
            archived = json.loads(stdout)
            assert_schema(self, archived, "factorio_instance_lifecycle.v1.schema.json")
            archive_id = archived["archive_id"]
            archive_root = workspace / "trash" / "instances" / archive_id
            self.assertFalse(copy.exists())
            self.assertTrue((archive_root / "archive.v1.json").is_file())
            self.assertTrue((archive_root / "script-output" / "preserved.txt").is_file())

            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "instances", "restore", archive_id, "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)
            restored = json.loads(stdout)
            assert_schema(self, restored, "factorio_instance_lifecycle.v1.schema.json")
            self.assertEqual("copy", restored["instance_id"])
            self.assertTrue(copy.is_dir())
            self.assertTrue(archive_root.is_dir(), "restore preserves the owned trash record")
            restored_manifest = json.loads((copy / "instance.v1.json").read_text(encoding="utf-8"))
            self.assertEqual("copy", restored_manifest["instance_id"])
            self.assertEqual("Renamed Display", restored_manifest["display_name"])

            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "instances", "restore", archive_id,
                "--new-id", "restored-alt", "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)
            alternate = json.loads(stdout)
            assert_schema(self, alternate, "factorio_instance_lifecycle.v1.schema.json")
            self.assertEqual("restored-alt", alternate["instance_id"])
            alternate_manifest = json.loads(
                (workspace / "instances" / "restored-alt" / "instance.v1.json").read_text(encoding="utf-8")
            )
            self.assertEqual("restored-alt", alternate_manifest["instance_id"])

    def test_faults_never_clobber_destination_or_hard_delete_source(self) -> None:
        cases = [
            ("clone", "after_validated"),
            ("clone", "during_copy"),
            ("clone", "after_verified"),
            ("archive", "before_commit"),
        ]
        for operation, stage in cases:
            with self.subTest(operation=operation, stage=stage), tempfile.TemporaryDirectory(
                prefix="facman lifecycle fault "
            ) as temporary:
                workspace = Path(temporary)
                source = create_fixture(workspace)
                before = snapshot(source)
                env = os.environ.copy()
                env["FACMAN_INSTANCE_LIFECYCLE_FAULT"] = stage
                args = ["--workspace", str(workspace), "instances", operation, "main"]
                if operation == "clone":
                    args.append("fault-copy")
                args.append("--json")
                code, _, _ = invoke(args, env=env)
                self.assertNotEqual(0, code)
                self.assertTrue(source.is_dir())
                self.assertEqual(before, snapshot_without_configuration_lock(source) if operation == "clone" else snapshot(source))
                self.assertFalse((workspace / "instances" / "fault-copy").exists())
                self.assertFalse(any((workspace / "instances").glob("*.staging")))

    def test_archive_refuses_run_lock_without_moving_content(self) -> None:
        with tempfile.TemporaryDirectory(prefix="facman lifecycle lock ") as temporary:
            workspace = Path(temporary)
            source = create_fixture(workspace)
            (source / "locks" / "run.lock").write_text("active\n", encoding="utf-8")
            before = snapshot(source)
            code, stdout, _ = invoke([
                "--workspace", str(workspace), "instances", "archive", "main", "--json",
            ])
            self.assertNotEqual(0, code)
            self.assertEqual("run_lock_contended", json.loads(stdout)["refusal"]["code"])
            self.assertEqual(before, snapshot(source))

    def test_restore_refuses_when_registered_install_version_drifted(self) -> None:
        with tempfile.TemporaryDirectory(prefix="facman restore incompatible ") as temporary:
            workspace = Path(temporary)
            create_fixture(workspace)
            code, stdout, stderr = invoke([
                "--workspace", str(workspace), "instances", "archive", "main", "--json",
            ])
            self.assertEqual(0, code, stderr or stdout)
            archive_id = json.loads(stdout)["archive_id"]
            install_ref = workspace / "installs" / "refs" / "fixture.json"
            document = json.loads(install_ref.read_text(encoding="utf-8"))
            document["version"] = "9.9.9"
            install_ref.write_text(json.dumps(document, separators=(",", ":")) + "\n", encoding="utf-8")
            code, stdout, _ = invoke([
                "--workspace", str(workspace), "instances", "restore", archive_id, "--json",
            ])
            self.assertNotEqual(0, code)
            self.assertEqual("instance_restore_install_incompatible", json.loads(stdout)["refusal"]["code"])
            self.assertFalse((workspace / "instances" / "main").exists())
            self.assertTrue((workspace / "trash" / "instances" / archive_id).is_dir())

    def test_archive_fault_matrix_preserves_live_or_owned_trash_content(self) -> None:
        for stage in ("after_validated", "before_commit", "after_commit", "after_metadata"):
            with self.subTest(stage=stage), tempfile.TemporaryDirectory(
                prefix="facman archive fault "
            ) as temporary:
                workspace = Path(temporary)
                source = create_fixture(workspace)
                before = snapshot(source)
                env = os.environ.copy()
                env["FACMAN_INSTANCE_LIFECYCLE_FAULT"] = stage
                code, _, _ = invoke([
                    "--workspace", str(workspace), "instances", "archive", "main", "--json",
                ], env=env)
                self.assertNotEqual(0, code)
                archives = list((workspace / "trash" / "instances").glob("*-main"))
                if stage in {"after_validated", "before_commit"}:
                    self.assertTrue(source.is_dir())
                    self.assertEqual(before, snapshot(source))
                    self.assertEqual([], archives)
                else:
                    self.assertFalse(source.exists())
                    self.assertEqual(1, len(archives))
                    moved = snapshot(archives[0])
                    moved.pop("archive.v1.json", None)
                    self.assertEqual(before, moved)

    def test_restore_fault_matrix_preserves_archive_and_bounded_destination_state(self) -> None:
        for stage in ("after_validated", "during_copy", "after_verified", "after_commit"):
            with self.subTest(stage=stage), tempfile.TemporaryDirectory(
                prefix="facman restore fault "
            ) as temporary:
                workspace = Path(temporary)
                create_fixture(workspace)
                code, stdout, stderr = invoke([
                    "--workspace", str(workspace), "instances", "archive", "main", "--json",
                ])
                self.assertEqual(0, code, stderr or stdout)
                archive_id = json.loads(stdout)["archive_id"]
                archive_root = workspace / "trash" / "instances" / archive_id
                archive_before = snapshot(archive_root)
                env = os.environ.copy()
                env["FACMAN_INSTANCE_LIFECYCLE_FAULT"] = stage
                code, _, _ = invoke([
                    "--workspace", str(workspace), "instances", "restore", archive_id, "--json",
                ], env=env)
                self.assertNotEqual(0, code)
                self.assertEqual(archive_before, snapshot(archive_root))
                destination = workspace / "instances" / "main"
                if stage == "after_commit":
                    self.assertTrue((destination / "instance.v1.json").is_file())
                    self.assertTrue((destination / ".facman-staging.v1").is_file())
                else:
                    self.assertFalse(destination.exists())

    def test_clone_post_commit_fault_leaves_recognizable_committed_target(self) -> None:
        with tempfile.TemporaryDirectory(prefix="facman clone commit fault ") as temporary:
            workspace = Path(temporary)
            source = create_fixture(workspace)
            source_before = snapshot(source)
            env = os.environ.copy()
            env["FACMAN_INSTANCE_LIFECYCLE_FAULT"] = "after_commit"
            code, _, _ = invoke([
                "--workspace", str(workspace), "instances", "clone", "main", "copy", "--json",
            ], env=env)
            self.assertNotEqual(0, code)
            self.assertEqual(source_before, snapshot_without_configuration_lock(source))
            destination = workspace / "instances" / "copy"
            self.assertTrue((destination / "instance.v1.json").is_file())
            self.assertTrue((destination / ".facman-staging.v1").is_file())
            code, stdout, _ = invoke([
                "--workspace", str(workspace), "instances", "verify", "copy", "--json",
            ])
            self.assertNotEqual(0, code)
            self.assertEqual(
                "instance_transaction_recovery_required", json.loads(stdout)["refusal"]["code"]
            )


if __name__ == "__main__":
    unittest.main()
