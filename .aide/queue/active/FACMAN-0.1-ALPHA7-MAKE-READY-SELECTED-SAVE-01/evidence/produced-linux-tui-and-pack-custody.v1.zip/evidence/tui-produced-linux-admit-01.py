import hashlib,io,json,re,shutil,subprocess,tarfile,tomllib,zipfile
from pathlib import Path,PurePosixPath
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
S='c95809b693e8795cb405b0494e3855ce7fef75ab';M='5dd9f7187c425e31b9c90f48add8b1f12f2c14a5';T='f04a3c412b3c1b40ef2416879d5fa0d4a2626ef0'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
d=json.loads((E/'tui-produced-linux-download-01.json').read_bytes());z_path=E/'tui-produced-linux-artifact-01.zip'
assert d['status']=='DOWNLOADED_EXISTING_EXACT_SOURCE_ARTIFACT' and sha(z_path)==d['artifact_sha256']
assert d['artifact']['id']==11759083596 and d['artifact']['workflow_run']['head_sha']==S
assert subprocess.check_output(['git','rev-parse',S+'^{tree}'],cwd=R,text=True).strip()==T
truth_path=E/'tui-produced-linux-source-truth-01/checkout-source-observation.v1.json'
truth=json.loads(truth_path.read_bytes());assert truth['source']['commit']==M and truth['source']['tree']==T and not truth['source']['dirty']
pins={'universal_launcher':'5479939ca5cbc9ee0f901608a92012778b4752ae','universal_setup':'2749a15b835a6c1c9968598a2b434d85809691ad'}
assert {p['id']:p['commit'] for p in truth['providers']}==pins and all(not p['dirty'] for p in truth['providers'])
root=W/'tui-produced-linux-delivery-01';out=E/'tui-produced-linux-admission-01.json';tests=E/'tui-produced-linux-exact-tests-01'
assert not root.exists() and not out.exists() and not tests.exists()
assert shutil.disk_usage(W).free>=13*1024**3
with zipfile.ZipFile(z_path) as z:
 raw=z.read('tui-dist/facman-0.1.0-alpha.6-linux-tui-x64-portable.tar.gz')
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as t:
  members=t.getmembers();assert len(members)<1000 and sum(m.size for m in members)<=128*1024**2
  names=set();casefold=set()
  for m in members:
   n=m.name;p=PurePosixPath(n)
   assert n and not p.is_absolute() and '\\' not in n and ':' not in n and all(c not in ('','.','..') for c in n.split('/'))
   assert m.isfile() or m.isdir();assert n not in names and n.casefold() not in casefold
   names.add(n);casefold.add(n.casefold())
  build=json.loads(t.extractfile('manifest/build_info.v1.json').read())
  manifest=tomllib.loads(t.extractfile('manifest/package.v1.toml').read().decode())
  assert build['profile_id']==manifest['profile_id']=='linux_portable_tui_x64'
  assert build['source_commit']==manifest['source_revision']==M and not build['source_dirty'] and not manifest['source_dirty']
  assert build['source_revisions']==dict(factorio_launcher=M,**pins)
  assert not build['published'] and not build['signed'] and not build['release_eligible']
  root.mkdir()
  for m in members:
   target=root/PurePosixPath(m.name)
   assert target.resolve().is_relative_to(root.resolve())
   if m.isdir():target.mkdir(parents=True,exist_ok=True)
   else:
    target.parent.mkdir(parents=True,exist_ok=True)
    with t.extractfile(m) as src,target.open('xb') as dst:shutil.copyfileobj(src,dst,1024*1024)
 files={p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file()}
 rows={}
 for line in (root/'manifest/hashes.sha256').read_text().splitlines():
  match=re.fullmatch(r'([0-9a-f]{64})  (.+)',line);assert match,line
  h,n=match.groups();assert n not in rows and files[n]==h,n;rows[n]=h
 assert set(rows)==set(files)-{'manifest/hashes.sha256'},'closure inventory differs'
 tests.mkdir();sources={}
 for module in ('test_tui_product','test_tui_pty'):
  data=subprocess.check_output(['git','show',S+':tests/'+module+'.py'],cwd=R)
  (tests/(module+'.py')).write_bytes(data);sources[module]=hashlib.sha256(data).hexdigest()
 v=dict(status='ADMITTED_EXISTING_LINUX_PRODUCED_TUI_PACKAGE',source_commit=S,producer_commit=M,source_tree=T,
        run_id=38272752230,artifact_id=11759083596,artifact_sha256=sha(z_path),tui_archive_sha256=hashlib.sha256(raw).hexdigest(),
        source_truth_sha256=sha(truth_path),provider_pins=pins,profile_id=manifest['profile_id'],delivery_root=str(root),
        delivery_files=files,executable=str(root/'bin/facman'),executable_sha256=files['bin/facman'],
        exact_test_sources=sources,exact_test_root=str(tests),new_task_roots=0,new_clones=0,new_candidates=0,
        selected_save_owner_qualified=False,human=False,game=False,beta=False)
 out.write_text(json.dumps(v,indent=2)+'\n');print(json.dumps({k:x for k,x in v.items() if k not in ('delivery_files','exact_test_sources')}))
