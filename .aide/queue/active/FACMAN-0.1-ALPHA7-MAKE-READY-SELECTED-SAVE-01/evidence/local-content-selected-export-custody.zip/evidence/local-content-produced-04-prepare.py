"""Preserve failed campaign; repair only held-lock capture and fail-fast behavior."""
import ast
import hashlib
import json
import os
from pathlib import Path
E = Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
source = E/'local-content-produced-03.py'
assert sha(source)=='d6e8bfaec28f4e00447318214904d2516dfed153531a0dcbc197e67aba82dea3'
failure_path = E/'local-content-produced-03.json'
failure = json.loads(failure_path.read_text(encoding='utf-8'))
assert failure['status']=='ACTIONABLE_FAILURE' and len(failure['commands'])==3 and failure['live_owned_children']==0
text = source.read_text(encoding='utf-8')
for before, after in {
    "S = W/'local-content-produced-03/scenario'": "S = W/'local-content-produced-03/scenario-04'",
    "OUT = E/'local-content-produced-03.json'": "OUT = E/'local-content-produced-04.json'",
    "REVIEW = E/'local-content-produced-03-controller.review.json'": "REVIEW = E/'local-content-produced-04-controller.review.json'",
    "write(E/'local-content-produced-03.claim.json'": "write(E/'local-content-produced-04.claim.json'",
    "test_log = E/'local-content-produced-03-unittest.log'": "test_log = E/'local-content-produced-04-unittest.log'",
    'verbosity=2, resultclass=RecordedResult': 'verbosity=2, resultclass=RecordedResult, failfast=True',
}.items():
    assert text.count(before)==1, before
    text = text.replace(before, after)
start, end = text.index('def capture(root, label):'), text.index('class OwnedDirectory:')
text = text[:start]+'''def capture(root, label):
    root = Path(root).resolve()
    assert root.is_relative_to(S.resolve()) and root.exists()
    number = len(record['state_captures'])+1
    destination = S/'states'/f'{number:03d}'
    assert not destination.exists()
    entry = dict(number=number, label=label, test=current_test, root=str(root),
                 destination=str(destination), status='capturing', exclusively_held_configuration_locks=[])
    # Reserve and persist the ordinal before I/O; retain partial captures on failure.
    record['state_captures'].append(entry); save()
    destination.mkdir(parents=True)
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink(), 'This packet intentionally excludes redirected-path host cases'
        if path.is_file():
            holders = [process for process in live if process.poll() is None and
                       path.resolve()==process.workspace/'instances/solver/locks/configuration.write.lock']
            if holders:
                entry['exclusively_held_configuration_locks'].append(dict(path=str(path),
                    owned_live_PIDs=[process.pid for process in holders], size=path.stat().st_size,
                    reason='Native command owns the exclusive configuration lock; preserve and do not read or unlock.'))
                continue
            target = destination/path.relative_to(root)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)
    entry.update(status='captured', files=tree(destination)); save()

'''+text[end:]
before = "    record['previous_configuration_before'] = tree(configuration)"
assert text.count(before)==1
text = text.replace(before, before+"\n    record['failed_campaign_before'] = tree(W/'local-content-produced-03/scenario')\n    record['failed_campaign_receipt_sha256'] = '"+sha(failure_path)+"'")
before = "    assert record['previous_configuration_before']==tree(configuration)"
assert text.count(before)==1
text = text.replace(before, before+"\n    assert record['failed_campaign_before']==tree(W/'local-content-produced-03/scenario')\n    assert sha(E/'local-content-produced-03.json')==record['failed_campaign_receipt_sha256']")
ast.parse(text)
destination = E/'local-content-produced-04.py'
with destination.open('x', encoding='utf-8', newline='\n') as f:
    f.write(text); f.flush(); os.fsync(f.fileno())
receipt = dict(status='pre_execution_capture_adapter_repair_no_campaign_issued', script_sha256=sha(destination),
    failed_script_sha256=sha(source), failed_receipt_sha256=sha(failure_path),
    failed_log_sha256=sha(E/'local-content-produced-03-unittest.log'),
    category='driver_capture_read_of_exclusively_held_native_configuration_lock_then_ordinal_collision',
    failed_actual_commands=3, no_accepted_cells=True, live_owned_children=0,
    failed_apply_interrupted_by_owned_supervisor=True, product_defect_demonstrated=False,
    same_admitted_package=True, additional_downloads=0, additional_extractions=0,
    builds=0, new_roots=0, no_failed_evidence_modified=True)
with (E/'local-content-produced-04-prepare.json').open('x', encoding='utf-8', newline='\n') as f:
    f.write(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt))
