"""Consume scoped independent produced acceptance and retain demonstrated export gap."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
E = Path(__file__).resolve().parent
R = Path(r'D:\Projects\Factorio\factorio-launcher')
O = Path(r'D:\Development\FacMan\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-o-38884d9b48\evidence')
CHECKPOINT = O/'world-backup-resumption.json'
EXPECTED = '791c8c4ae23c1464f8fdbcb64cc854087e68ef232b066933870ee1a1b5dfd2e6'
HEAD = '0911e4da96a332f10a5965872357e1ee30398d08'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(name, expected):
    path=E/name; assert sha(path)==expected
    return dict(path=str(path),sha256=expected)
def write(p, value):
    with p.open('x',encoding='utf-8',newline='\n') as f:
        f.write(json.dumps(value,indent=2)+'\n');f.flush();os.fsync(f.fileno())
assert sha(CHECKPOINT)==EXPECTED
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==HEAD
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()
receipt=pin('local-content-produced-04.json','b78038a94b75ac81543159e50f5948bf8687fe6be0f70d9e69acddff7f18d64b')
review=pin('local-content-produced-review-04.json','1e569684fbbf6385eb817adde31b06972fc78ba639149151782704c0a43048c8')
assert json.loads(Path(review['path']).read_text(encoding='utf-8'))['verdict']=='PASS'
actual=json.loads(Path(receipt['path']).read_text(encoding='utf-8'))
assert actual['commands_executed']==55 and actual['passing_cells']==11 and actual['verified_delivery_files_unchanged']==587
admission=pin('local-content-produced-admission-03.json','106fcc42adeb46b70ee936293bf2f8557f9edad148b5173614a3bfb4198e790b')
baseline=pin('local-content-export-baseline-01.json','65ffe266ed9fe2d6bc82a6ca79617e225a9ea9f021e5497cac2902c4756a6774')
assert json.loads(Path(baseline['path']).read_text(encoding='utf-8'))['status']=='DEMONSTRATED_VERIFIED_SELECTION_EXPORT_DEFECT'
data=json.loads(CHECKPOINT.read_text(encoding='utf-8'))
family=data['local_content_publication_boundary']
assert family['integrated_dev']==HEAD and family['observer_terminal_consumed']
family.update(status='qualified_source_and_current_produced_publication_boundary_pass',
    current_produced_runtime_qualified=True,produced_qualification_scope='Publication-boundary refusal and retained fault diagnostics only; earlier source7671 core41-command proof remains separate.',
    produced_receipt=receipt,produced_review=review,produced_admission=admission,
    produced_source=HEAD,produced_commands=55,produced_cells=11,produced_methods=4,state_captures=225,
    delivery_files_unchanged=587,whole_workunit_closed=False,full_programme_complete=False,
    retained_driver_failure=pin('local-content-produced-03.json','534266547e1925bde273f9d5be9ab7ce8101a0d85bfcf57ff8ab2429d44efa0f'),
    driver_failure_category='Exclusive configuration-lock capture error;3actualcalls,zeroacceptedcells;ownedpausedapplyinterruptedbeforepublication;oldscenariointact.')
data['local_content_export_followup']=dict(status='demonstrated_verified_selection_export_defect',source=HEAD,baseline=baseline,commands=5,
    accepted_export=False,refusal_code='modset_verification_failed',refusal_reason='Modset lock changed before export',
    managed_state_and_sources_unchanged=True,work_item='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01',
    planned_modpack_unit_activated=False,planned_local_content_unit_closed=False,whole_workunit_closed=False)
data['next_action']='Continue active MakeReady portable prepared-content slice from qualified dev0911: repair modset export to consume its already verified selected physical archives and exact lock, retaining trusted virtual metadata and all export publication/recovery guards. Baseline5deliveredcalls demonstrates current refusal after successful apply/verify. No new WorkUnit/root/WIP admission or prerequisite closure. Then source regression/review/normalintegration, followed by genuine delivered export/offline reconstruction proof; retain original clauses, three unfinished prerequisites and external gates.'
data['updated_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
temporary=CHECKPOINT.with_suffix('.json.writing')
assert not temporary.exists();write(temporary,data);assert sha(CHECKPOINT)==EXPECTED;temporary.replace(CHECKPOINT)
print(json.dumps(dict(status=family['status'],next_gap='verified_solver_selection_export',checkpoint_sha256=sha(CHECKPOINT),whole_workunit_closed=False)))
