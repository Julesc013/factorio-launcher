"""Wait for reviewed lock-capture repair, then execute one exact follow-up."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
E = Path(__file__).resolve().parent
SCRIPT = E/'local-content-produced-04.py'
REVIEW = E/'local-content-produced-04-controller.review.json'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert __debug__ and os.environ.get('PYTHONOPTIMIZE')=='0' and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1'
deadline = time.monotonic()+600
while not REVIEW.exists() and time.monotonic()<deadline: time.sleep(1)
assert REVIEW.exists(), 'Controller review deadline; follow-up not launched'
review = json.loads(REVIEW.read_text(encoding='utf-8'))
assert review['verdict']=='PASS' and review['independent'] and review['non_authoring'], review
assert review['script_sha256']==sha(SCRIPT)=='20ce8d7afef4bff7a0c7a253e62689dde8a9cb332c9244dc406d27237b2ac9ed'
assert review['admission_sha256']==sha(E/'local-content-produced-admission-03.json')=='106fcc42adeb46b70ee936293bf2f8557f9edad148b5173614a3bfb4198e790b'
assert not (E/'local-content-produced-04.json').exists() and not (E/'local-content-produced-04.claim.json').exists()
print(json.dumps(dict(status='independent_capture_repair_review_pass_launch_once', review_sha256=sha(REVIEW))), flush=True)
result = subprocess.run([sys.executable, '-B', str(SCRIPT)], env=os.environ.copy(), timeout=900)
sys.exit(result.returncode)
