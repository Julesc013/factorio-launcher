import hashlib
import json
from pathlib import Path
import subprocess

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
HEAD = '0911e4da96a332f10a5965872357e1ee30398d08'
def out(*argv):
    c = subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=60)
    assert c.returncode == 0,(argv[:3],c.stderr[:500]); return c.stdout.strip()
def gh(path): return json.loads(out('gh','api',path))
assert out('powershell','-NoProfile','-Command','[System.Security.Principal.WindowsIdentity]::GetCurrent().Name') == r'BLACKGLASS-WIN1\Jules'
assert subprocess.run(['gh','auth','status'],cwd=R,capture_output=True,timeout=60).returncode == 0
assert out('gh','api','user','--jq','.login') == 'Julesc013'
assert out('git','branch','--show-current') == 'dev' and not out('git','status','--porcelain')
assert out('git','rev-parse','HEAD') == out('git','rev-parse','origin/dev') == HEAD
runs = gh('repos/Julesc013/factorio-launcher/actions/runs?head_sha='+HEAD+'&per_page=100')
selected = [r for r in runs['workflow_runs'] if r['path'] == '.github/workflows/ci.yml' and r['event'] == 'push' and r['head_branch'] == 'dev' and r['head_sha'] == HEAD]
assert len(selected) == 1
run = selected[0]; assert run['status'] == 'completed' and run['conclusion'] == 'success'
artifacts = gh(f"repos/Julesc013/factorio-launcher/actions/runs/{run['id']}/artifacts?per_page=100")
assert artifacts['total_count'] == len(artifacts['artifacts'])
names = ['windows-self-setup-'+HEAD, 'windows-package-composition-'+HEAD]
chosen = {name:[a for a in artifacts['artifacts'] if a['name']==name] for name in names}
assert all(len(v)==1 and not v[0]['expired'] and v[0]['workflow_run']['id']==run['id'] and v[0]['workflow_run']['head_sha']==HEAD for v in chosen.values())
record = dict(status='EXACT_INTEGRATED_SOURCE_EXISTING_ARTIFACTS_FOUND',source=HEAD,run=run,artifacts={name:v[0] for name,v in chosen.items()},all_artifact_inventory=artifacts,new_roots=0,builds=0,candidate_dispatches=0,CI_reruns=0,model_wait_calls=0)
path = E/'local-content-current-artifacts-03.json'
with path.open('x',encoding='utf-8',newline='\n') as f: f.write(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(status=record['status'],source=HEAD,run=run['id'],artifacts={k:dict(id=v['id'],digest=v['digest'],size=v['size_in_bytes']) for k,v in record['artifacts'].items()},receipt_sha256=hashlib.sha256(path.read_bytes()).hexdigest())))
