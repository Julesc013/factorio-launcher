"""Bind existing automatic CI artifacts and the documented setup path projection."""
import ast
import hashlib
import json
from pathlib import Path
E = Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
metadata = E/'local-content-current-artifacts-03.json'
assert sha(metadata) == 'a3fc7ce450cd475177ebc683eb8e029687cdf39a9a08da6c55c9fb06c03c823d'
m = json.loads(metadata.read_text(encoding='utf-8'))
assert m['source'] == '0911e4da96a332f10a5965872357e1ee30398d08' and m['run']['id'] == 37349632111
source = E/'local-content-produced-admission-02.py'
text = source.read_text(encoding='utf-8')
for before, after in {
    'local-content-produced-admission-02': 'local-content-produced-admission-03',
    'local-content-current-Windows-self-setup-02': 'local-content-current-Windows-self-setup-03',
    'local-content-current-Windows-composition-02': 'local-content-current-Windows-composition-03',
    'local-content-current-artifacts-02': 'local-content-current-artifacts-03',
    'local-content-produced-02': 'local-content-produced-03',
    '7671fe3f63c269fde9956356a9d174cc143421a9': m['source'],
    '37328110880': '37349632111',
    '11355477681': '11364164714',
    '11355916649': '11364384128',
    '8ddec3deea42e9b99b23c4407073ea88dca30226f44891d6e842f4135bf7169d': '006c4afd479642bf03265e2d5921d6220ed8256f46b6d6b417ce05ceb65a426a',
    '332fc8fccbd4591dfb16bfd30356bf0d2882456a9c9013eaa6d097c9c957e317': '88fc552d1b648fb0f750c1ff4be9c79100cbcaada20002a1445374370379279b',
}.items():
    assert before in text, before
    text = text.replace(before, after)
before = "    assert set(closure['inventory']) == set(actual)\n    assert closure['tree_sha256'] == hashlib.sha256(json.dumps(actual,separators=(',',':'),sort_keys=True).encode('utf-8')).hexdigest()"
after = """    # tools/self_setup_package.py moves the WinForms entry to the generation root.
    assert set(actual)-set(closure['inventory']) == {'FacMan.exe'}
    assert set(closure['inventory'])-set(actual) == {'bin/FacMan.WinForms.exe'}
    projected = dict(actual)
    projected['bin/FacMan.WinForms.exe'] = projected.pop('FacMan.exe')
    assert closure['tree_sha256'] == hashlib.sha256(json.dumps(projected,separators=(',',':'),sort_keys=True).encode('utf-8')).hexdigest()
    record['composition_path_projection'] = 'Exact inverse of documented bin/FacMan.WinForms.exe to FacMan.exe relocation; bytes unchanged.'"""
assert text.count(before) == 1
text = text.replace(before, after)
before = "    assert build_info['profile_id'] == 'windows_legacy_winforms_x64'"
assert text.count(before) == 1
text = text.replace(before, before+"\n    assert build_info['source_commit'] == BASE and not build_info['source_dirty']")
before = "    run, log = check('resource', [sys.executable, '-B', 'tools/workspace_hygiene.py',"
assert text.count(before) == 1
text = text.replace(before, "    run, _ = check('paths', [sys.executable, '-B', 'tools/workspace_hygiene.py', 'paths'])\n    assert run.returncode == 0\n"+before)
ast.parse(text)
destination = E/'local-content-produced-admission-03.py'
with destination.open('x', encoding='utf-8', newline='\n') as f: f.write(text)
print(json.dumps(dict(status='current_source_admission_prepared_no_download', source=m['source'], script_sha256=sha(destination), metadata_sha256=sha(metadata), previous_admission_script_sha256=sha(source), documented_projection=True)))
