"""Reuse the retired owned branch at qualified dev; no WorkUnit/root admission."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tomllib

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
H = '0911e4da96a332f10a5965872357e1ee30398d08'
B = 'task/facman-world-restore-retention-01'
U = 'FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
sys.path.insert(0, str(R/'.aide/scripts'))
import aide_lite

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def run(*args):
    p = subprocess.run(args, cwd=R, capture_output=True, text=True, encoding='utf-8', timeout=120)
    assert p.returncode == 0, (args, p.returncode, p.stderr[:500])
    return p.stdout.strip()

def write(p, v):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        f.write(json.dumps(v, indent=2)+'\n')

assert __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0'
assert run('git', 'branch', '--show-current') == 'dev'
assert run('git', 'rev-parse', 'HEAD') == run('git', 'rev-parse', 'origin/dev') == H
assert not run('git', 'status', '--porcelain')
terminal = E/'local-content-concurrency-integration-01.json'
assert sha(terminal) == 'eeb43c6fbbfe0998ea9d125984dbbea499e9872856bf82018d3113c43551237a'
t = json.loads(terminal.read_text(encoding='utf-8'))
assert t['status'] == 'integration_and_automatic_merge_CI_pass' and t['merge'] == H and t['branch_retired']
marker = E.parent/'.facman-development-root.v1.json'
m = json.loads(marker.read_text(encoding='utf-8'))
assert m['task_id'] == B and Path(m['canonical_path']).samefile(E.parent) and Path(m['source_root']).samefile(R)
plan = tomllib.loads((R/'release/index/plan.v1.toml').read_text(encoding='utf-8'))
unit = next(x for x in plan['workunit'] if x['id'] == U)
assert unit['status'] == 'active' and len(unit['close_after']) == 5
assert run('powershell', '-NoProfile', '-Command', '[System.Security.Principal.WindowsIdentity]::GetCurrent().Name') == 'BLACKGLASS-WIN1\\Jules'
assert subprocess.run(['gh','auth','status'],cwd=R,capture_output=True,timeout=60).returncode == 0, 'Real-user authentication check failed; no credential output retained'
assert run('gh', 'api', 'user', '--jq', '.login') == 'Julesc013'
assert run('gh', 'api', 'repos/Julesc013/factorio-launcher/git/ref/heads/dev', '--jq', '.object.sha') == H
assert not run('git', 'ls-remote', '--heads', 'origin', 'refs/heads/'+B)
assert subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/'+B],cwd=R).returncode == 1
assert json.loads(run('gh', 'pr', 'list', '--head', B, '--state', 'open', '--json', 'number')) == []
for name, extra in [('paths', []), ('doctor', ['--measure'])]:
    p = subprocess.run([sys.executable,'-B','tools/workspace_hygiene.py',name,*extra],cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
    hygiene = json.loads(p.stdout)
    write(E/('local-content-export-01-prebranch-'+name+'.json'),hygiene)
    if name == 'doctor':
        assert p.returncode in {0,1} and set(hygiene['violations']) <= {'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
        assert len(hygiene['task_roots']) <= 8 and hygiene['task_root_bytes'] <= 20*1024**3
    else:
        assert p.returncode == 0
for category, operations in [('task',['inspect','noop-check','recover']),('git',['policy','detect','plan'])]:
    for operation in operations:
        argv = [sys.executable,'-B','.aide/scripts/aide_lite.py',category,operation]
        if category == 'task':
            argv += ['--task-id',U]
        with (E/('local-content-export-01-prebranch-'+category+'-'+operation+'.log')).open('x',encoding='utf-8') as f:
            p = subprocess.run(argv,cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=120)
        assert p.returncode == 0
helper = aide_lite.make_git_helper_plan(R, 'plan')
assert helper['status'] == 'ready_dry_run' and not helper['blockers']
review = E/'local-content-concurrency-integration-01.review.json'
assert sha(review) == '14ddec497aac4f8448d32ddae85d3f6cc5ec866388f0642ed695be1e399d3a2b'
produced_receipt=E/'local-content-produced-04.json'
produced_review=E/'local-content-produced-review-04.json'
baseline=E/'local-content-export-baseline-01.json'
assert sha(produced_receipt)=='b78038a94b75ac81543159e50f5948bf8687fe6be0f70d9e69acddff7f18d64b'
assert sha(produced_review)=='1e569684fbbf6385eb817adde31b06972fc78ba639149151782704c0a43048c8'
assert json.loads(produced_review.read_text(encoding='utf-8'))['verdict']=='PASS'
assert sha(baseline)=='65ffe266ed9fe2d6bc82a6ca79617e225a9ea9f021e5497cac2902c4756a6774'
assert json.loads(baseline.read_text(encoding='utf-8'))['status']=='DEMONSTRATED_VERIFIED_SELECTION_EXPORT_DEFECT'
argv = ['git','switch','--no-track','-c',B,H]
write(E/'local-content-export-01-branch-01-plan.json', dict(
    schema='facman.exact-base-task-branch-plan.v1', work_item=U, branch=B, start_commit=H,
    helper_plan=helper, planned_command=argv,
    operator_authority='Standing compact-restart authorization: new sequential task from latest qualified dev, same active MakeReady content preparation outcome and retired immutable owned-root branch identifier; bounded already-prepared selected-content export repair from actual delivered5-call defect; selected physical archives plus exact verified lock, trusted virtual metadata retained and all existing publication/recovery guards preserved, without activating or closing planned units.',
    prior_integration_sha256=sha(terminal), qualified_owner_contract_review_sha256=sha(review),
    produced_receipt_sha256=sha(produced_receipt), produced_review_sha256=sha(produced_review), export_baseline_sha256=sha(baseline),
    root=str(E.parent), marker_sha256=sha(marker), original_acceptance=unit['acceptance'],
    close_after=unit['close_after'], new_roots=0, new_worktrees=0, task_start_repeated=False,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
write(E/'local-content-export-01-branch-01.claim.json', dict(pid=os.getpid(), no_automatic_replay=True))
run(*argv)
assert sha(marker) == json.loads((E/'local-content-export-01-branch-01-plan.json').read_text(encoding='utf-8'))['marker_sha256']
write(E/'local-content-export-01-branch-01.json', dict(status='branch_created_from_qualified_dev',branch=B,base=H,work_item=U,new_roots=0,new_worktrees=0,acceptance_complete=False))
print(json.dumps(dict(status='branch_created_from_qualified_dev', branch=B, base=H)))
