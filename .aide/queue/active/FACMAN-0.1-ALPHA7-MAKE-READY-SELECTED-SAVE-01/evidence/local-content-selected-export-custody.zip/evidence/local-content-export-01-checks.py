import hashlib, json, os, subprocess, sys, time, zipfile
from pathlib import Path
R=Path('D:/Projects/Factorio/factorio-launcher')
W=Path('D:/Development/FacMan/repositories/factorio-launcher-5db2844e2f29/tasks/task-facman-w-bc5cd0812e')
E=W/'evidence'
P=sys.argv[2] if len(sys.argv)>2 else 'local-content-export-01'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONOPTIMIZE='0',
         PYTHONPATH=str(R/'tests')+os.pathsep+str(R), TEMP=str(W/'test-temp'), TMP=str(W/'test-temp'))
commands={
 'preflight': [
  ['py','-3','tools/codegen/generate_contracts.py','--check'],
  ['py','-3','tools/codegen/generate_metadata.py','--check'],
  ['py','-3','tools/modset_solver_check.py'],
  ['py','-3','tools/modset_route_check.py'],
  ['py','-3','tools/transaction_recovery_check.py'],
  ['py','-3','tools/source_format_check.py'],
  ['py','-3','tools/strict_check.py'],
 ],
 'build': [['py','-3','tools/dev.py','build','developer','--task-root',str(W),'--build-root',str(W/'native-developer'),
            '--configuration','Debug','--target','facman_cli']],
 'focused': [['py','-3','-m','unittest','-v','test_local_modset_solver','test_modzip_depth','test_recovery',
              'test_instance_lifecycle','test_cli_machine_result']],
 'concurrency': [['py','-3','-m','unittest','-v','test_local_modset_solver.LocalModsetSolverTests.test_apply_refuses_selected_archive_change_at_publication_boundary','test_local_modset_solver.LocalModsetSolverTests.test_apply_preserves_external_managed_state_change_at_publication_boundary']],
 'solver': [['py','-3','-m','unittest','-v','test_local_modset_solver']],
 'QA': [
  ['py','-3','tools/codegen/generate_contracts.py','--check'],
  ['py','-3','tools/codegen/generate_metadata.py','--check'],
  ['py','-3','tools/generate_plan_views.py','--check'],
  ['py','-3','tools/project_state.py','--validate'],
  ['py','-3','-m','unittest','tests.test_plan_views','tests.test_current_truth_roles','tests.test_aide_target_truth','tests.test_aide_compaction'],
  ['py','-3','.aide/scripts/aide_lite.py','test'],
  ['py','-3','tools/strict_check.py'],
  ['py','-3','tools/source_format_check.py'],
  ['git','diff','--check'],
  ['py','-3','.aide/scripts/aide_lite.py','commit','template'],
  ['py','-3','.aide/scripts/aide_lite.py','commit','check','--message',(E/'local-content-repair-01-commit.txt').read_text(encoding='utf-8')],
 ],
}
commands['export_regression'] = [['py','-3','-m','unittest','-v',
    'test_local_modset_solver.LocalModsetSolverTests.test_applied_selection_exports_exact_lock_and_only_selected_archives',
    'test_local_modset_solver.LocalModsetSolverTests.test_virtual_only_selection_exports_lock_without_inventing_archive',
    'test_local_modset_solver.LocalModsetSolverTests.test_export_refuses_valid_changed_selection_after_staging']]
commands['baseline'] = commands['export_regression']
commands['focused'] = [['py','-3','-m','unittest','-v','test_local_modset_solver','test_modzip_depth']]
mode=sys.argv[1]
result_path=E/f'{P}-{mode}.json'
assert not result_path.exists()
assert json.loads((W/'.facman-development-root.v1.json').read_text(encoding='utf-8'))['task_id']=='task/facman-world-restore-retention-01'
if mode=='build':
    import shutil
    classify = """
$facmanHeavy=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('MSBuild.exe','cl.exe','cmake.exe','ninja.exe') })
$facmanResult=@(foreach ($facmanProcess in $facmanHeavy) {
    $facmanParent=@(Get-CimInstance Win32_Process -Filter "ProcessId=$($facmanProcess.ParentProcessId)")
    $facmanOrphan=($facmanProcess.Name -eq 'MSBuild.exe' -and $facmanParent.Count -eq 0 -and $facmanProcess.CommandLine -match '/nodemode:[1-9]' -and $facmanProcess.CommandLine -match '/nodeReuse:true')
    $facmanIdle=$false
    $facmanDelta=$null
    if ($facmanOrphan) {
        $facmanCpu=(Get-Process -Id $facmanProcess.ProcessId -ErrorAction SilentlyContinue).CPU
        Start-Sleep -Seconds 2
        $facmanNow=Get-Process -Id $facmanProcess.ProcessId -ErrorAction SilentlyContinue
        $facmanDelta=if ($null -eq $facmanNow) {0} else {$facmanNow.CPU-$facmanCpu}
        $facmanIdle=($facmanDelta -eq 0)
    }
    [pscustomobject]@{name=$facmanProcess.Name;pid=$facmanProcess.ProcessId;created=$facmanProcess.CreationDate;parent_alive=($facmanParent.Count -gt 0);orphan_reusable_node=$facmanOrphan;cpu_delta_seconds=$facmanDelta;idle_preexisting_node=$facmanIdle;active_job=(-not $facmanIdle)}
})
ConvertTo-Json -InputObject $facmanResult -Compress
"""
    active=subprocess.run(['powershell','-NoProfile','-Command',classify],capture_output=True,text=True,encoding='utf-8',timeout=60)
    assert active.returncode==0
    classified=json.loads(active.stdout)
    with (E/f'{P}-build-process-admission.json').open('x',encoding='utf-8') as f:json.dump(classified,f,indent=2)
    assert not any(p['active_job'] for p in classified),'Preserve active heavy job; never duplicate it'
    measured=subprocess.run([sys.executable,'-B','tools/workspace_hygiene.py','doctor','--measure'],cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=180)
    doctor=json.loads(measured.stdout)
    with (E/f'{P}-build-resource.json').open('x',encoding='utf-8') as f:json.dump(doctor,f,indent=2)
    assert measured.returncode in {0,1} and set(doctor['violations']) <= {'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
    assert len(doctor['task_roots'])<=8 and doctor['task_root_bytes']+1024**3<=20*1024**3
    assert shutil.disk_usage(W).free>=9*1024**3
    capsule=E/'local-content-export-01-before-build-images.zip'
    metadata=E/'local-content-export-01-before-build-images.json'
    if capsule.exists():
        receipt=json.loads(metadata.read_text(encoding='utf-8'))
        assert sha(capsule)==receipt['sha256']
        with zipfile.ZipFile(capsule) as z:
            for item in receipt['files']:
                member=Path(item['path']).relative_to(W/'native-developer').as_posix()
                assert hashlib.sha256(z.read(member)).hexdigest()==item['sha256']
    else:
        paths=sorted(p for p in (W/'native-developer').rglob('*') if p.suffix.lower() in ('.exe','.dll'))
        with zipfile.ZipFile(capsule,'x',compression=zipfile.ZIP_DEFLATED) as z:
            for p in paths: z.write(p,p.relative_to(W/'native-developer').as_posix())
        with metadata.open('x',encoding='utf-8') as f:
            json.dump(dict(capsule=str(capsule),sha256=sha(capsule),files=[dict(path=str(p),sha256=sha(p),size=p.stat().st_size) for p in paths]),f,indent=2);f.write('\n')
if mode in ('focused','solver','concurrency','export_regression'): env['FACMAN_CLI_EXE']=str(W/'native-developer/Debug/facman.exe')
if mode=='baseline': env['FACMAN_CLI_EXE']=str(W/'local-content-produced-03/facman/generations/0.1.0-alpha.6/bin/facman.exe')
records=[]
for index,argv in enumerate(commands[mode]):
    log=E/f'{P}-{mode}-{index+1:02}.log'
    assert not log.exists()
    started=time.time()
    with log.open('xb') as f:
        process=subprocess.Popen(argv,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
        try: code=process.wait(timeout=1800 if mode=='build' else 900)
        except subprocess.TimeoutExpired:
            process.terminate(); process.wait(timeout=30); code=124
    record=dict(argv=argv,pid=process.pid,exit_code=code,duration_seconds=round(time.time()-started,3),
                log=str(log),sha256=sha(log))
    records.append(record)
    if code:
        with result_path.open('x',encoding='utf-8') as f: json.dump(dict(status='ACTIONABLE_FAILURE',commands=records),f,indent=2);f.write('\n')
        print(json.dumps(record))
        print(log.read_text(encoding='utf-8',errors='replace')[-4500:])
        raise SystemExit(code)
with result_path.open('x',encoding='utf-8') as f: json.dump(dict(status='PASS',commands=records),f,indent=2);f.write('\n')
print(json.dumps(dict(mode=mode,status='PASS',commands=len(records),receipt=str(result_path),sha256=sha(result_path))))
