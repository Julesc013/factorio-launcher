"""Prepare one bounded delivered-CLI export defect reproduction in owned W."""
import ast
from pathlib import Path
E = Path(__file__).resolve().parent
old = (E/'local-content-produced-02.py').read_text(encoding='utf-8')
text = old.split('try:\n    assert __debug__', 1)[0]
text = text.replace("S=W/'local-content-produced-02/scenario'", "S=W/'local-content-produced-03/export-baseline-01'")
text = text.replace("CLI=W/'local-content-produced-02/facman", "CLI=W/'local-content-produced-03/facman")
text = text.replace("OUT=E/'local-content-produced-02.json'", "OUT=E/'local-content-export-baseline-01.json'")
text = text.replace('7671fe3f63c269fde9956356a9d174cc143421a9', '0911e4da96a332f10a5965872357e1ee30398d08')
text = text.replace("'concurrency':'PENDING_NO_BARRIER'", "'scope':'demonstrate_verified_solver_selection_export_gap'")
text += '''try:
    assert __debug__ and os.environ.get('PYTHONOPTIMIZE')=='0' and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1'
    assert not OUT.exists() and not S.exists()
    marker=json.loads((W/'.facman-development-root.v1.json').read_text(encoding='utf-8'))
    assert marker['task_id']=='task/facman-world-restore-retention-01' and Path(marker['canonical_path']).samefile(W)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==rec['producer_source']
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()
    admission_path=E/'local-content-produced-admission-03.json'
    assert sha(admission_path)=='106fcc42adeb46b70ee936293bf2f8557f9edad148b5173614a3bfb4198e790b'
    admission=json.loads(admission_path.read_text(encoding='utf-8'))
    assert sha(CLI)==admission['executable_sha256']=='95685278d76794eef8170e6e38ac86b4c0af98dd53511eeb7c36e2d8ea1ae172'
    assert sha(CLI.parent/'flb_factorio.dll')==admission['binding_DLL_sha256']=='6f44231dec45836148fcb4f9b25386f3c360217464aff5be8bd40605a1ed062c'
    assert tree(CLI.parent.parent)==admission['delivery_files_before']
    assert admission['resource_admission']['roots']==8 and shutil.disk_usage(W).free>=8*1024**3+64*1024**2
    prior=W/'local-content-produced-03/scenario-04'
    rec['qualified_publication_boundary_before']=tree(prior)
    rec['admission_sha256']=sha(admission_path)
    rec['CLI_sha256']=sha(CLI);rec['DLL_sha256']=sha(CLI.parent/'flb_factorio.dll')
    with (E/'local-content-export-baseline-01.claim.json').open('x',encoding='utf-8') as f:
        json.dump({'PID':os.getpid(),'source':rec['producer_source'],'no_automatic_replay':True},f)
    S.mkdir();save()
    workspace=setup('selection');mods=workspace/'instances/solver/mods'
    mod(workspace,'library','1.0.0',['base >= 2.0'])
    mod(workspace,'library','2.0.0',['base >= 2.0'])
    mod(workspace,'application','1.0.0',['base >= 2.0','library >= 1.0'])
    shutil.copyfile(R/'tests/fixtures/factorio_mods/malformed_info_json/malformed_info_1.0.0.zip',mods/'malformed_info_1.0.0.zip')
    applied=run('apply-selected',workspace,['modsets','apply','solver','--enable','application'])
    verified=run('verify-selected',workspace,['modsets','verify','solver'])
    assert not verified['problems']
    expected=state(workspace);capture('verified-before-export',workspace)
    archives={p.name:sha(p) for p in mods.glob('*.zip')}
    output=workspace/'selected-modset.zip'
    refused=run('export-refusal',workspace,['modsets','export','solver',str(output)],ok=False)
    assert refused['refusal']['code']=='modset_verification_failed'
    assert refused['refusal']['reason']=='Modset lock changed before export'
    assert not output.exists() and state(workspace)==expected
    assert archives=={p.name:sha(p) for p in mods.glob('*.zip')}
    capture('after-refused-export',workspace)
    assert tree(CLI.parent.parent)==admission['delivery_files_before'] and tree(prior)==rec['qualified_publication_boundary_before']
    rec.update(status='DEMONSTRATED_VERIFIED_SELECTION_EXPORT_DEFECT',export_refusal=refused,
               desired_packages=applied['desired_mods'],verified_delivery_files_unchanged=587,
               managed_state_and_sources_unchanged=True,new_roots=0,builds=0,candidate_dispatches=0,CI_reruns=0,
               model_wait_calls=0,whole_workunit_closed=False,full_programme_complete=False)
    save();print(json.dumps({'status':rec['status'],'commands':len(rec['commands']),'refusal':refused['refusal'],'receipt_sha256':sha(OUT)}))
except BaseException as error:
    rec.update(status='ACTIONABLE_FAILURE',error=repr(error),traceback=traceback.format_exc());save()
    print(json.dumps({'status':rec['status'],'error':repr(error),'commands':len(rec['commands'])}));sys.exit(1)
'''
ast.parse(text)
with (E/'local-content-export-baseline-01.py').open('x', encoding='utf-8', newline='\n') as f: f.write(text)
