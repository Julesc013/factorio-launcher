import ast
import hashlib
from pathlib import Path
E = Path(__file__).resolve().parent
source = E/'local-content-current-artifacts-02.py'
text = source.read_text(encoding='utf-8')
text = text.replace('7671fe3f63c269fde9956356a9d174cc143421a9', '0911e4da96a332f10a5965872357e1ee30398d08').replace('local-content-current-artifacts-02', 'local-content-current-artifacts-03')
ast.parse(text)
destination = E/'local-content-current-artifacts-03.py'
with destination.open('x', encoding='utf-8', newline='\n') as f: f.write(text)
print(hashlib.sha256(destination.read_bytes()).hexdigest())
