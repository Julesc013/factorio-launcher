"""Run integrated publication-boundary assertions against the admitted delivery.

Keep fixture workspaces, byte-exact process streams and assertion state snapshots.
No product, source, branch, package or prior-evidence mutation is permitted.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback
from types import SimpleNamespace
import unittest

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
W = E.parent
S = W/'local-content-produced-03/scenario-04'
OUT = E/'local-content-produced-04.json'
ADMISSION = E/'local-content-produced-admission-03.json'
REVIEW = E/'local-content-produced-04-controller.review.json'
HEAD = '0911e4da96a332f10a5965872357e1ee30398d08'
ADMISSION_SHA = '106fcc42adeb46b70ee936293bf2f8557f9edad148b5173614a3bfb4198e790b'
TEST_SHA = '8b0cfa8340dd75097ab61893addcb0d028816e0f5dd9e3a22d87f9dfec172fba'
CLI_SHA = '95685278d76794eef8170e6e38ac86b4c0af98dd53511eeb7c36e2d8ea1ae172'
DLL_SHA = '6f44231dec45836148fcb4f9b25386f3c360217464aff5be8bd40605a1ed062c'
METHODS = [
    'test_apply_refuses_selected_archive_change_at_publication_boundary',
    'test_apply_preserves_external_managed_state_change_at_publication_boundary',
    'test_apply_preserves_unverified_publication_staging_and_history',
    'test_failed_apply_retry_preserves_attempts_and_has_its_own_rollback_id',
]
record = dict(status='PENDING', producer_source=HEAD, consumer_source=HEAD,
              commands=[], cells=[], state_captures=[], workspaces=[], methods=METHODS,
              new_roots=0, new_worktrees=0, builds=0, candidate_dispatches=0,
              CI_reruns=0, model_wait_calls=0, actual_Factorio_execution=False,
              human_experience=False, whole_workunit_closed=False,
              full_programme_complete=False, redirect_symlinks_exercised=False,
              total_unmanaged_writer_serialization=False, export_offline_proof=False)
live = set()
CLI = None
current_test = None

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def tree(p): return {q.relative_to(p).as_posix(): sha(q) for q in sorted(p.rglob('*')) if q.is_file()}
def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        f.write(json.dumps(value, indent=2)+'\n'); f.flush(); os.fsync(f.fileno())
def save():
    temporary = OUT.with_suffix('.writing')
    assert not temporary.exists()
    write(temporary, record); temporary.replace(OUT)
def git(*args): return subprocess.check_output(['git', *args], cwd=R, text=True).strip()

def capture(root, label):
    root = Path(root).resolve()
    assert root.is_relative_to(S.resolve()) and root.exists()
    number = len(record['state_captures'])+1
    destination = S/'states'/f'{number:03d}'
    assert not destination.exists()
    entry = dict(number=number, label=label, test=current_test, root=str(root),
                 destination=str(destination), status='capturing', exclusively_held_configuration_locks=[])
    # Reserve and persist the ordinal before I/O; retain partial captures on failure.
    record['state_captures'].append(entry); save()
    destination.mkdir(parents=True)
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink(), 'This packet intentionally excludes redirected-path host cases'
        if path.is_file():
            holders = [process for process in live if process.poll() is None and
                       path.resolve()==process.workspace/'instances/solver/locks/configuration.write.lock']
            if holders:
                entry['exclusively_held_configuration_locks'].append(dict(path=str(path),
                    owned_live_PIDs=[process.pid for process in holders], size=path.stat().st_size,
                    reason='Native command owns the exclusive configuration lock; preserve and do not read or unlock.'))
                continue
            target = destination/path.relative_to(root)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)
    entry.update(status='captured', files=tree(destination)); save()

class OwnedDirectory:
    def __init__(self, prefix='', **kwargs):
        assert not kwargs, kwargs
        self.path = S/'workspaces'/f'{len(record["workspaces"])+1:02d}'
        self.path.mkdir(parents=True)
        record['workspaces'].append(dict(path=str(self.path), prefix=prefix, test=current_test))
        save()
    def __enter__(self): return str(self.path)
    def __exit__(self, *args): capture(self.path, 'workspace-context-exit-retained')

class RecordedProcess(subprocess.Popen):
    def __init__(self, argv, **kwargs):
        assert Path(argv[0]).samefile(CLI), argv
        assert '--workspace' in argv
        self.workspace = Path(argv[argv.index('--workspace')+1]).resolve()
        assert self.workspace.is_relative_to((S/'workspaces').resolve())
        if self.workspace.exists(): capture(self.workspace, 'before-command')
        number = len(record['commands'])+1
        self.stdout_path = S/'streams'/f'{number:02d}.stdout'
        self.stderr_path = S/'streams'/f'{number:02d}.stderr'
        self.stdout_stream = self.stdout_path.open('xb')
        self.stderr_stream = self.stderr_path.open('xb')
        self.entry = dict(number=number, argv=argv, requested_cwd=str(kwargs.get('cwd')),
                          cwd=str(CLI.parent), supervisor_PID=os.getpid(), test=current_test,
                          started_at_utc=now(), explicit_test_environment={k:v for k,v in kwargs.get('env', os.environ).items()
                          if k.startswith('FACMAN_TEST_') or k.endswith('_FAULT')})
        kwargs.update(cwd=CLI.parent, stdout=self.stdout_stream, stderr=self.stderr_stream,
                      encoding='utf-8', text=True)
        try: super().__init__(argv, **kwargs)
        except BaseException:
            self.stdout_stream.close(); self.stderr_stream.close(); raise
        live.add(self)
        self.entry['PID'] = self.pid
        record['commands'].append(self.entry); save()
        self.recorded = False
    def communicate(self, *args, **kwargs):
        super().communicate(*args, **kwargs)
        if not self.recorded:
            self.stdout_stream.close(); self.stderr_stream.close()
            self.entry.update(exit_code=self.returncode, stdout=str(self.stdout_path), stderr=str(self.stderr_path),
                              stdout_sha256=sha(self.stdout_path), stderr_sha256=sha(self.stderr_path), finished_at_utc=now())
            self.recorded = True; live.discard(self); save()
            if self.workspace.exists(): capture(self.workspace, 'after-command')
        return self.stdout_path.read_text(encoding='utf-8'), self.stderr_path.read_text(encoding='utf-8')

def invoke(args, env=None):
    process = RecordedProcess([str(CLI), *args], env=env or os.environ.copy(), cwd=R)
    try: stdout, stderr = process.communicate(timeout=30)
    except BaseException:
        if process.poll() is None: process.kill()
        process.communicate(timeout=10); raise
    assert not stderr, stderr
    envelope = json.loads(stdout)
    assert envelope['schema'] == 'facman.transport_response.v2'
    payload = envelope.get('payload')
    if payload is None and envelope.get('error') is not None:
        error = envelope['error']
        payload = dict(schema='facman.client_refusal.v1', status='refused',
                       refusal=dict(code=error.get('code', 'client_failure'), reason=error.get('message', 'Command failed')))
    return process.returncode, json.dumps(payload, ensure_ascii=False, separators=(',', ':'))+'\n', stderr

class RecordedResult(unittest.TextTestResult):
    def startTest(self, test):
        global current_test
        current_test = test.id(); super().startTest(test)
    def addSubTest(self, test, subtest, error):
        record['cells'].append(dict(test=test.id(), subtest=str(subtest), result='PASS' if error is None else 'FAIL'))
        save(); super().addSubTest(test, subtest, error)
    def addSuccess(self, test):
        if not any(cell['test']==test.id() for cell in record['cells']):
            record['cells'].append(dict(test=test.id(), result='PASS')); save()
        super().addSuccess(test)

try:
    assert __debug__ and os.environ.get('PYTHONOPTIMIZE')=='0' and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1'
    assert not OUT.exists() and not S.exists()
    assert git('branch', '--show-current')=='dev' and not git('status', '--porcelain')
    assert git('rev-parse', 'HEAD')==git('rev-parse', 'origin/dev')==HEAD
    marker = json.loads((W/'.facman-development-root.v1.json').read_text(encoding='utf-8'))
    assert marker['task_id']=='task/facman-world-restore-retention-01'
    assert Path(marker['canonical_path']).samefile(W) and Path(marker['source_root']).samefile(R)
    assert sha(ADMISSION)==ADMISSION_SHA
    admission = json.loads(ADMISSION.read_text(encoding='utf-8'))
    assert admission['status']=='ADMITTED_EXISTING_PRODUCED_WINDOWS_DELIVERY' and admission['source']==HEAD
    CLI = Path(admission['executable'])
    assert sha(CLI)==CLI_SHA and sha(CLI.parent/'flb_factorio.dll')==DLL_SHA
    assert tree(CLI.parent.parent)==admission['delivery_files_before']
    assert sha(R/'tests/test_local_modset_solver.py')==TEST_SHA
    review = json.loads(REVIEW.read_text(encoding='utf-8'))
    assert review['verdict']=='PASS' and review['independent'] and review['non_authoring']
    assert review['script_sha256']==sha(Path(__file__)) and review['admission_sha256']==ADMISSION_SHA
    resource = admission['resource_admission']
    peak = 128*1024**2
    assert resource['roots']==8 and resource['retained_bytes']+resource['peak_extra_bytes']<20*1024**3
    assert shutil.disk_usage(W).free>=8*1024**3+peak
    record.update(admission_sha256=ADMISSION_SHA, controller_review_sha256=sha(REVIEW),
                  controller_sha256=sha(Path(__file__)), CLI_sha256=CLI_SHA, DLL_sha256=DLL_SHA,
                  assertion_source_sha256=TEST_SHA, resource=dict(roots=8, peak_extra_bytes=peak,
                  admission_measured_bytes=resource['retained_bytes'], free_bytes=shutil.disk_usage(W).free))
    previous = W/'local-content-produced-02/scenario'
    configuration = W/'instance-configuration-produced-01/scenario'
    record['previous_produced_scenario_before'] = tree(previous)
    record['previous_configuration_before'] = tree(configuration)
    record['failed_campaign_before'] = tree(W/'local-content-produced-03/scenario')
    record['failed_campaign_receipt_sha256'] = '534266547e1925bde273f9d5be9ab7ce8101a0d85bfcf57ff8ab2429d44efa0f'
    record['fixture_install_before'] = tree(R/'tests/fixtures/fake_factorio_install')
    write(E/'local-content-produced-04.claim.json', dict(PID=os.getpid(), source=HEAD, scenario=str(S), no_automatic_replay=True))
    S.mkdir(); (S/'streams').mkdir(); save()
    for key in list(os.environ):
        if key.startswith('FACMAN_TEST_') or key.endswith('_FAULT'): os.environ.pop(key)
    os.environ['FACMAN_CLI_EXE'] = str(CLI)
    sys.path.insert(0, str(R)); sys.path.insert(0, str(R/'tests'))
    import test_local_modset_solver as product_tests
    original_snapshot, original_managed_state = product_tests.snapshot, product_tests.managed_state
    def observed_snapshot(root, excluded=None):
        result = original_snapshot(root, excluded)
        capture(root, 'assertion-snapshot'); return result
    def observed_managed_state(workspace):
        result = original_managed_state(workspace)
        capture(workspace, 'assertion-managed-state'); return result
    product_tests.tempfile = SimpleNamespace(TemporaryDirectory=OwnedDirectory)
    product_tests.subprocess = SimpleNamespace(Popen=RecordedProcess, PIPE=subprocess.PIPE)
    product_tests.invoke = invoke
    product_tests.snapshot, product_tests.managed_state = observed_snapshot, observed_managed_state
    suite = unittest.TestSuite(product_tests.LocalModsetSolverTests(method) for method in METHODS)
    test_log = E/'local-content-produced-04-unittest.log'
    with test_log.open('x', encoding='utf-8', newline='\n') as stream:
        result = unittest.TextTestRunner(stream=stream, verbosity=2, resultclass=RecordedResult, failfast=True).run(suite)
    record['test_result'] = dict(methods_run=result.testsRun, failures=len(result.failures), errors=len(result.errors),
                               skips=len(result.skipped), log=str(test_log), log_sha256=sha(test_log))
    save()
    assert result.wasSuccessful() and result.testsRun==4 and not result.skipped
    assert len(record['cells'])==11 and all(cell['result']=='PASS' for cell in record['cells'])
    assert len(record['commands'])==55 and not live
    assert all(not Path(command['stderr']).read_bytes() for command in record['commands'])
    assert record['previous_produced_scenario_before']==tree(previous)
    assert record['previous_configuration_before']==tree(configuration)
    assert record['failed_campaign_before']==tree(W/'local-content-produced-03/scenario')
    assert sha(E/'local-content-produced-03.json')==record['failed_campaign_receipt_sha256']
    assert record['fixture_install_before']==tree(R/'tests/fixtures/fake_factorio_install')
    assert tree(CLI.parent.parent)==admission['delivery_files_before']
    assert git('rev-parse', 'HEAD')==HEAD and git('branch', '--show-current')=='dev' and not git('status', '--porcelain')
    scenario_bytes = sum(path.stat().st_size for path in S.rglob('*') if path.is_file())
    assert scenario_bytes<peak
    record.update(status='PASS_SCOPED_CURRENT_PRODUCED_WINDOWS_PUBLICATION_BOUNDARY',
                  current_produced_publication_boundary_qualified=True, verified_delivery_files_unchanged=587,
                  source_inputs_and_prior_scenarios_unchanged=True, scenario_bytes=scenario_bytes,
                  commands_executed=55, passing_methods=4, passing_cells=11, finished_at_utc=now())
    save()
    print(json.dumps(dict(status=record['status'], source=HEAD, commands=55, passing_cells=11,
                         passing_methods=4, delivery_files_unchanged=587, state_captures=len(record['state_captures']),
                         scenario_bytes=scenario_bytes, receipt_sha256=sha(OUT), whole_workunit_closed=False)))
except BaseException as error:
    for process in tuple(live):
        if process.poll() is None: process.kill()
        try: process.communicate(timeout=10)
        except BaseException: pass
    record.update(status='ACTIONABLE_FAILURE', error=repr(error), traceback=traceback.format_exc(),
                  live_owned_children=len(live), finished_at_utc=now())
    if not OUT.exists() or record.get('commands'): save()
    print(json.dumps(dict(status=record['status'], error=repr(error), executed_commands=len(record['commands']), live_owned_children=len(live))))
    sys.exit(1)
