"""Publish scoped durable evidence; append one reference without changing gates."""
import copy
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tomllib
import zipfile

R=Path(r'D:\Projects\Factorio\factorio-launcher')
E=Path(__file__).resolve().parent
W=E.parent
UNIT='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
BASE='0911e4da96a332f10a5965872357e1ee30398d08'
D=R/'.aide/queue/active'/UNIT/'evidence'
SOURCES={
    'runtime/factorio/modsets/flb_factorio_modset_operations.cpp':'a231755bdb2b4785d1288605f4b687c0420fdf078770aef3e57f5f3641c57c8f',
    'tests/test_local_modset_solver.py':'c59d62aeb0f44f3c3ac3121e917e54106b43232639023d5e8acc07341a912ba5',
    'docs/product/local_modset_solver.md':'bd201312bf3be8da4cd935a2dcc279b29ebb4a8e5f558452fed04dd2dbe17fd9',
}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(v,indent=2)+'\n')
def pin(name,expected):
    p=E/name;assert sha(p)==expected;return dict(path='evidence/'+name,sha256=expected)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==BASE
for p,expected in SOURCES.items():assert sha(R/p)==expected
source_review=pin('local-content-export-review-01.json','6064d6988a764af34fb9020107178aabf96098c68910bb656406b33a9d0cdb59')
assert read(E/'local-content-export-review-01.json')['verdict']=='PASS'
preflight=pin('local-content-export-01-preflight.json','c560d8e29c6e3ec60bb0d7c4f6764db2473c6c57ee45c8c07cb39000fb804a79')
build=pin('local-content-export-01-build.json','2cf27d61619ef8ac0e91860e248368cb224a76542ac51dcd031898ea62fc2100')
focused=pin('local-content-export-01-focused.json','fae408df51513be1b7f19083b9c02c7fafaa2314e2a456184e78690340d17917')
for descriptor in (preflight,build,focused):
    value=read(E/Path(descriptor['path']).name);assert value['status']=='PASS'
    for command in value['commands']:assert command['exit_code']==0 and sha(Path(command['log']))==command['sha256']
log_path=Path(read(E/'local-content-export-01-focused.json')['commands'][0]['log'])
log=log_path.read_text(encoding='utf-8')
passed=re.findall(r'^test_\S+ \(([^)]+)\) \.\.\. ok$',log,re.M)
skipped=[line for line in log.splitlines() if '... skipped ' in line]
assert len(passed)==32 and len(skipped)==3 and 'Ran 34 tests' in log and 'OK (skipped=3)' in log
assert sum('publication symlink' in line for line in skipped)==2 and sum('private POSIX' in line for line in skipped)==1
assert sha(W/'native-developer/Debug/facman.exe')=='f8b0f48d3484fd026ae1cb79d0000787f578033cd25fefc6d8da22fe94e28a64'
produced_pin=pin('local-content-produced-04.json','b78038a94b75ac81543159e50f5948bf8687fe6be0f70d9e69acddff7f18d64b')
produced_review=pin('local-content-produced-review-04.json','1e569684fbbf6385eb817adde31b06972fc78ba639149151782704c0a43048c8')
produced=read(E/'local-content-produced-04.json')
assert produced['producer_source']==BASE and produced['commands_executed']==55 and produced['passing_cells']==11
assert read(E/'local-content-produced-review-04.json')['verdict']=='PASS'
for command in produced['commands']:
    assert sha(Path(command['stdout']))==command['stdout_sha256'] and sha(Path(command['stderr']))==command['stderr_sha256']
baseline=pin('local-content-export-baseline-01.json','65ffe266ed9fe2d6bc82a6ca79617e225a9ea9f021e5497cac2902c4756a6774')
assert read(E/'local-content-export-baseline-01.json')['status']=='DEMONSTRATED_VERIFIED_SELECTION_EXPORT_DEFECT'
baseline_tests=read(E/'local-content-export-01-baseline.json')
assert baseline_tests['status']=='ACTIONABLE_FAILURE' and baseline_tests['commands'][0]['exit_code']==1
assert sha(Path(baseline_tests['commands'][0]['log']))=='a870a8a559c73c6c013411da8a01e67c6d524cefab9360277b27f77bce8b43cf'
mode_failure=E/'local-content-export-01-mode-selection-failure.json'
write(mode_failure,dict(category='driver_mode_name_mismatch',requested_mode='static',correct_mode='preflight',
    outcome="KeyError: 'static' before command dispatch",checks_issued=0,product_failure=False,
    retained_in='Codex tool transcript; no standalone raw log was collected',corrected_preflight_receipt=preflight))
members={}
def admit(p,member):
    assert p.is_file() and not p.is_symlink() and not(getattr(p.stat(),'st_file_attributes',0)&0x400)
    assert p.suffix.lower() not in {'.exe','.dll','.pdb'} and member not in members
    members[member]=p
for pattern in ['local-content-export-01*','local-content-export-baseline-01*','local-content-export-review-01.json',
                'local-content-produced-03*','local-content-produced-04*','local-content-produced-review-04.json',
                'local-content-produced-admission-03*','local-content-current-artifacts-03*']:
    for p in sorted(E.glob(pattern)):
        if p.is_file() and p.suffix.lower() in {'.json','.log','.py'} and p not in members.values():admit(p,'evidence/'+p.name)
for label,scenario in [('produced-publication-boundary',W/'local-content-produced-03/scenario-04'),
                       ('retained-driver-failure',W/'local-content-produced-03/scenario'),
                       ('produced-export-baseline',W/'local-content-produced-03/export-baseline-01')]:
    for p in sorted(scenario.rglob('*')):
        if p.is_file():admit(p,label+'/'+p.relative_to(scenario).as_posix())
archive=D/'local-content-selected-export-custody.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for member,p in sorted(members.items()):z.write(p,member)
plan_path=R/'release/index/plan.v1.toml'
text=plan_path.read_text(encoding='utf-8');before=tomllib.loads(text)
unit=next(x for x in before['workunit'] if x['id']==UNIT)
assert unit['status']=='active' and len(unit['acceptance'])==2 and len(unit['close_after'])==5
public=D/'local-content-selected-export.v1.json';ref=public.relative_to(R).as_posix()
assert ref not in unit['evidence']
receipt=dict(status='PASS_SCOPED_WINDOWS_SELECTED_EXPORT_NATIVE_FIXTURE',work_item=UNIT,base=BASE,
    behavior=['Export the exact successfully verified lock and only its selected physical archives',
              'Retain trusted built-in provenance as virtual lock metadata without inventing archives',
              'Require the same selected lock at staged and private-copy source checks; preserve external edits',
              'Retain digest/entry/identity/private-publication/no-clobber/recovery safeguards'],
    source_hashes=SOURCES,native_CLI_sha256=sha(W/'native-developer/Debug/facman.exe'),source_review=source_review,
    verification=dict(preflight=preflight,native_build=build,affected_modules=dict(receipt=focused,reported_methods=34,
        completed_passing_methods=32,passed_ids=passed,not_applicable=skipped,symlink_subcases=2,POSIX_method=1,log_sha256=sha(log_path)),
        baseline=dict(produced=baseline,commands=5,new_regression_methods=3,old_package_failures=3,
                      baseline_log_sha256='a870a8a559c73c6c013411da8a01e67c6d524cefab9360277b27f77bce8b43cf',
                      note='Third baseline fails upstream before its stage barrier; closed-process stream cleanup corrected after retained ResourceWarning.')),
    qualified_produced_publication_boundary=dict(source=BASE,receipt=produced_pin,review=produced_review,
        commands=55,cells=11,methods=4,state_captures=225,CLI_sha256=produced['CLI_sha256'],DLL_sha256=produced['DLL_sha256'],
        delivery_files_unchanged=587,scope='Already integrated publication guard and fault diagnostics; this delivered package predates the new selected-export change'),
    custody=dict(path=archive.relative_to(R).as_posix(),sha256=sha(archive),members=len(members),files={n:sha(p) for n,p in sorted(members.items())},
        executables_included=False,licensed_game_inputs_included=False),original_acceptance=unit['acceptance'],close_after=unit['close_after'],
    whole_workunit_closed=False,qualification=dict(current_produced_selected_export=False,import_offline_reconstruction=False,
        virtual_metadata_drift=False,total_unmanaged_writer_serialization=False,symlink_host=False,genuine_game=False,human_experience=False,Beta=False),
    retained_failures=['Produced03 capture read an exclusively held configuration lock, then ordinal collisions;3actualcommands/zeroacceptedcells/ownedpausedapplyinterruptedbeforepublication',
        'Current delivered5command campaign demonstrates verified selection export refusal','All3new export regressions fail old package; corrected test child-stream cleanup',
        'Driver mode label static refused before checks; corrected mode preflight passes'],
    remaining=['Required current-source and automatic merge CI','Genuine delivered selected-export acceptance','Offline import/reconstruction and content frontend acceptance',
               'Original federated MakeReady clauses and three unfinished close-after prerequisites'],
    external_gates_preserved=['PR343 owner-only protected-control gate','Source-distinct A5-to-A6 produced update/rollback','Applicable host/game/human gates'],
    resource_use=dict(new_roots=0,new_worktrees=0,workers=2,heavy_local_jobs=1,build_peak_bytes=1024**3,reserve_bytes=8*1024**3),
    finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
write(public,receipt)
start=text.index('id = "'+UNIT+'"');end=text.find('\n[[workunit]]',start)
if end<0:end=len(text)
section=text[start:end];last='  "'+unit['evidence'][-1]+'",';assert section.count(last)==1
updated=text[:start]+section.replace(last,last+'\n  "'+ref+'",',1)+text[end:]
expected=copy.deepcopy(before);next(x for x in expected['workunit'] if x['id']==UNIT)['evidence'].append(ref)
assert tomllib.loads(updated)==expected;plan_path.write_text(updated,encoding='utf-8',newline='\n')
write(E/'local-content-export-01-packet.json',dict(status=receipt['status'],public_receipt=ref,public_receipt_sha256=sha(public),custody_sha256=sha(archive),
    custody_members=len(members),canonical_change='Exactly one evidence append; status/original clauses/all gates preserved',whole_workunit_closed=False))
print(json.dumps(dict(status=receipt['status'],reported_methods=34,completed_passing_methods=32,NA_symlink_subcases=2,NA_POSIX_method=1,
    qualified_base_produced_commands=55,custody_members=len(members),public_receipt_sha256=sha(public),custody_sha256=sha(archive))))
