"""Single claimed produced-package local-content scenario; no source mutation."""
import hashlib, json, os, shutil, subprocess, sys, traceback, zipfile
from pathlib import Path
R=Path('D:/Projects/Factorio/factorio-launcher')
E=Path(__file__).resolve().parent
W=E.parent
S=W/'local-content-produced-03/export-baseline-01'
CLI=W/'local-content-produced-03/facman/generations/0.1.0-alpha.6/bin/facman.exe'
OUT=E/'local-content-export-baseline-01.json'
rec={'status':'PENDING','producer_source':'0911e4da96a332f10a5965872357e1ee30398d08','consumer_source':'0911e4da96a332f10a5965872357e1ee30398d08','commands':[],'cells':[],'scope':'demonstrate_verified_solver_selection_export_gap','game_execution':False,'human_experience':False}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save():
    t=OUT.with_suffix('.writing'); t.write_text(json.dumps(rec,indent=2)+'\n',encoding='utf-8'); t.replace(OUT)
def tree(p): return {x.relative_to(p).as_posix():sha(x) for x in sorted(p.rglob('*')) if x.is_file()}
def capture(label, ws):
    d=S/'states'/label; assert not d.exists()
    for p in ws.rglob('*'):
        if p.is_file():
            q=d/p.relative_to(ws); q.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(p,q)
    rec.setdefault('states',{})[label]=tree(d);save()
def state(ws,id='solver'):
    paths=[ws/'instances'/id/'mods/mod-list.json',ws/'instances'/id/'mods/modset-lock.v1.json',ws/'modsets'/f'{id}.modset-lock.v1.json']
    return [p.read_bytes() if p.exists() else None for p in paths]
def run(label,ws,args,ok=True,human=False,fault=None):
    n=len(rec['commands'])+1; stem=S/f'{n:02d}-{label}'
    argv=[str(CLI),'--workspace',str(ws),*args]+([] if human else ['--json'])
    env=os.environ.copy()
    for k in list(env):
        if k.startswith('FACMAN_TEST_') or k.endswith('_FAULT'): env.pop(k)
    if fault:env['FACMAN_MODSET_FAULT']=fault
    entry={'label':label,'argv':argv,'cwd':str(CLI.parent),'supervisor_PID':os.getpid(),'fault':fault}
    with stem.with_suffix('.stdout').open('xb') as out,stem.with_suffix('.stderr').open('xb') as err:
        p=subprocess.Popen(argv,cwd=CLI.parent,env=env,stdout=out,stderr=err)
        entry['PID']=p.pid; rec['commands'].append(entry);save()
        try:p.wait(timeout=30)
        except BaseException:p.kill();p.wait(timeout=10);entry['timeout']=True;save();raise
    entry.update(exit_code=p.returncode,stdout=str(stem.with_suffix('.stdout')),stderr=str(stem.with_suffix('.stderr')),
                 stdout_sha256=sha(stem.with_suffix('.stdout')),stderr_sha256=sha(stem.with_suffix('.stderr')));save()
    assert (p.returncode==0)==ok,(label,p.returncode)
    assert not stem.with_suffix('.stderr').read_bytes(),label
    text=stem.with_suffix('.stdout').read_text(encoding='utf-8')
    if human:return text
    v=json.loads(text);assert v['schema']=='facman.transport_response.v2'
    if ok:assert v['error'] is None;return v['payload']
    return v['payload'] or {'refusal':{'code':v['error']['code']}}
def mod(ws,name,ver,deps):
    p=ws/'instances/solver/mods'/f'{name}_{ver}.zip'
    info={'name':name,'title':name,'version':ver,'factorio_version':'2.0','dependencies':deps}
    z=zipfile.ZipInfo(f'{name}_{ver}/info.json',(2026,7,12,0,0,0));z.external_attr=0o644<<16
    with zipfile.ZipFile(p,'x',compression=zipfile.ZIP_STORED) as f:f.writestr(z,json.dumps(info,sort_keys=True)+'\n')
def setup(label):
    ws=S/label
    run(label+'-import',ws,['installs','import',str(R/'tests/fixtures/fake_factorio_install'),'--id','fixture'])
    run(label+'-create',ws,['instances','create','Solver','--id','solver','--install','fixture'])
    return ws
def passed(name):rec['cells'].append({'name':name,'result':'PASS'});save()
try:
    assert __debug__ and os.environ.get('PYTHONOPTIMIZE')=='0' and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1'
    assert not OUT.exists() and not S.exists()
    marker=json.loads((W/'.facman-development-root.v1.json').read_text(encoding='utf-8'))
    assert marker['task_id']=='task/facman-world-restore-retention-01' and Path(marker['canonical_path']).samefile(W)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==rec['producer_source']
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()
    admission_path=E/'local-content-produced-admission-03.json'
    assert sha(admission_path)=='106fcc42adeb46b70ee936293bf2f8557f9edad148b5173614a3bfb4198e790b'
    admission=json.loads(admission_path.read_text(encoding='utf-8'))
    assert sha(CLI)==admission['executable_sha256']=='95685278d76794eef8170e6e38ac86b4c0af98dd53511eeb7c36e2d8ea1ae172'
    assert sha(CLI.parent/'flb_factorio.dll')==admission['binding_DLL_sha256']=='6f44231dec45836148fcb4f9b25386f3c360217464aff5be8bd40605a1ed062c'
    assert tree(CLI.parent.parent)==admission['delivery_files_before']
    assert admission['resource_admission']['roots']==8 and shutil.disk_usage(W).free>=8*1024**3+64*1024**2
    prior=W/'local-content-produced-03/scenario-04'
    rec['qualified_publication_boundary_before']=tree(prior)
    rec['admission_sha256']=sha(admission_path)
    rec['CLI_sha256']=sha(CLI);rec['DLL_sha256']=sha(CLI.parent/'flb_factorio.dll')
    with (E/'local-content-export-baseline-01.claim.json').open('x',encoding='utf-8') as f:
        json.dump({'PID':os.getpid(),'source':rec['producer_source'],'no_automatic_replay':True},f)
    S.mkdir();save()
    workspace=setup('selection');mods=workspace/'instances/solver/mods'
    mod(workspace,'library','1.0.0',['base >= 2.0'])
    mod(workspace,'library','2.0.0',['base >= 2.0'])
    mod(workspace,'application','1.0.0',['base >= 2.0','library >= 1.0'])
    shutil.copyfile(R/'tests/fixtures/factorio_mods/malformed_info_json/malformed_info_1.0.0.zip',mods/'malformed_info_1.0.0.zip')
    applied=run('apply-selected',workspace,['modsets','apply','solver','--enable','application'])
    verified=run('verify-selected',workspace,['modsets','verify','solver'])
    assert not verified['problems']
    expected=state(workspace);capture('verified-before-export',workspace)
    archives={p.name:sha(p) for p in mods.glob('*.zip')}
    output=workspace/'selected-modset.zip'
    refused=run('export-refusal',workspace,['modsets','export','solver',str(output)],ok=False)
    assert refused['refusal']['code']=='modset_verification_failed'
    assert refused['refusal']['reason']=='Modset lock changed before export'
    assert not output.exists() and state(workspace)==expected
    assert archives=={p.name:sha(p) for p in mods.glob('*.zip')}
    capture('after-refused-export',workspace)
    assert tree(CLI.parent.parent)==admission['delivery_files_before'] and tree(prior)==rec['qualified_publication_boundary_before']
    rec.update(status='DEMONSTRATED_VERIFIED_SELECTION_EXPORT_DEFECT',export_refusal=refused,
               desired_packages=applied['desired_mods'],verified_delivery_files_unchanged=587,
               managed_state_and_sources_unchanged=True,new_roots=0,builds=0,candidate_dispatches=0,CI_reruns=0,
               model_wait_calls=0,whole_workunit_closed=False,full_programme_complete=False)
    save();print(json.dumps({'status':rec['status'],'commands':len(rec['commands']),'refusal':refused['refusal'],'receipt_sha256':sha(OUT)}))
except BaseException as error:
    rec.update(status='ACTIONABLE_FAILURE',error=repr(error),traceback=traceback.format_exc());save()
    print(json.dumps({'status':rec['status'],'error':repr(error),'commands':len(rec['commands'])}));sys.exit(1)
