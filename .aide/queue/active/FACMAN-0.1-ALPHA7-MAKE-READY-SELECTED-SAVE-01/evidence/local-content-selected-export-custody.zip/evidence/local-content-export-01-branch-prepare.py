"""Bind the normal owned-branch continuation to qualified dev and produced proof."""
import ast
import hashlib
import json
from pathlib import Path
E = Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
source = E/'local-content-concurrency-01-branch.py'
text = source.read_text(encoding='utf-8')
for before, after in {
    'local-content-concurrency-01': 'local-content-export-01',
    '7671fe3f63c269fde9956356a9d174cc143421a9': '0911e4da96a332f10a5965872357e1ee30398d08',
    'local-content-repair-integration-01.json': 'local-content-concurrency-integration-01.json',
    '5d71793648c95a99c12059b85bf6d0588e8a02e86f38c2a7827d630f4af54be0': 'eeb43c6fbbfe0998ea9d125984dbbea499e9872856bf82018d3113c43551237a',
    'local-content-repair-integration-01.review.json': 'local-content-concurrency-integration-01.review.json',
    'deff1c328cd4191a286ceb027ca9b5f4cb4c41ecb9aa0cbb0fef6410e3c452eb': '14ddec497aac4f8448d32ddae85d3f6cc5ec866388f0642ed695be1e399d3a2b',
    'bounded publication-boundary external source/state drift acceptance': 'bounded already-prepared selected-content export repair from actual delivered5-call defect; selected physical archives plus exact verified lock, trusted virtual metadata retained and all existing publication/recovery guards preserved',
}.items():
    assert before in text, before
    text=text.replace(before, after)
before = "argv = ['git','switch','--no-track','-c',B,H]"
extra = """produced_receipt=E/'local-content-produced-04.json'
produced_review=E/'local-content-produced-review-04.json'
baseline=E/'local-content-export-baseline-01.json'
assert sha(produced_receipt)=='b78038a94b75ac81543159e50f5948bf8687fe6be0f70d9e69acddff7f18d64b'
assert sha(produced_review)=='1e569684fbbf6385eb817adde31b06972fc78ba639149151782704c0a43048c8'
assert json.loads(produced_review.read_text(encoding='utf-8'))['verdict']=='PASS'
assert sha(baseline)=='65ffe266ed9fe2d6bc82a6ca79617e225a9ea9f021e5497cac2902c4756a6774'
assert json.loads(baseline.read_text(encoding='utf-8'))['status']=='DEMONSTRATED_VERIFIED_SELECTION_EXPORT_DEFECT'
"""
assert text.count(before)==1;text=text.replace(before,extra+before)
before = 'prior_integration_sha256=sha(terminal), qualified_owner_contract_review_sha256=sha(review),'
assert text.count(before)==1
text=text.replace(before,before+'\n    produced_receipt_sha256=sha(produced_receipt), produced_review_sha256=sha(produced_review), export_baseline_sha256=sha(baseline),')
ast.parse(text)
destination=E/'local-content-export-01-branch.py'
with destination.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
print(json.dumps(dict(status='exact_qualified_dev_branch_continuation_prepared',script_sha256=sha(destination),base='0911e4da96a332f10a5965872357e1ee30398d08',new_workunit_admission=False,new_roots=0,new_worktrees=0)))
