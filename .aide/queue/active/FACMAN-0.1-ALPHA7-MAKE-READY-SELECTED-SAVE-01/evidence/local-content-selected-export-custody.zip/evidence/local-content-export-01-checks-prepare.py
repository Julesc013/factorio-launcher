import ast
import hashlib
from pathlib import Path
E=Path(__file__).resolve().parent
text=(E/'local-content-concurrency-02-checks.py').read_text(encoding='utf-8')
text=text.replace('local-content-concurrency-01','local-content-export-01')
before='mode=sys.argv[1]'
assert text.count(before)==1
extra="""commands['export_regression'] = [['py','-3','-m','unittest','-v',
    'test_local_modset_solver.LocalModsetSolverTests.test_applied_selection_exports_exact_lock_and_only_selected_archives',
    'test_local_modset_solver.LocalModsetSolverTests.test_virtual_only_selection_exports_lock_without_inventing_archive',
    'test_local_modset_solver.LocalModsetSolverTests.test_export_refuses_valid_changed_selection_after_staging']]
commands['baseline'] = commands['export_regression']
commands['focused'] = [['py','-3','-m','unittest','-v','test_local_modset_solver','test_modzip_depth']]
"""
text=text.replace(before,extra+before)
text=text.replace("if mode in ('focused','solver','concurrency'):","if mode in ('focused','solver','concurrency','export_regression'):")
before='records=[]'
assert text.count(before)==1
text=text.replace(before,"if mode=='baseline': env['FACMAN_CLI_EXE']=str(W/'local-content-produced-03/facman/generations/0.1.0-alpha.6/bin/facman.exe')\n"+before)
ast.parse(text)
destination=E/'local-content-export-01-checks.py'
with destination.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
print(hashlib.sha256(destination.read_bytes()).hexdigest())
