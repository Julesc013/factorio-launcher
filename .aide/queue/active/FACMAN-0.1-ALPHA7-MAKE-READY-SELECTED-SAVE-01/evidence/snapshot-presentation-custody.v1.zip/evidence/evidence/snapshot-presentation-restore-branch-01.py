import hashlib,json,os,subprocess,sys
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
BASE='6c6efc8a679404147a56a24803bd8c4618bafefa';BRANCH='task/facman-snapshot-presentation-restore-01'
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1')
sys.dont_write_bytecode=True;sys.path.insert(0,str(R));from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True,encoding='utf-8').strip()
assert git('rev-parse','HEAD')==BASE and git('branch','--show-current')=='dev' and not git('status','--porcelain')
commands=[]
def run(label,args):
 r=owned.command(args,cwd=R,environment=dict(os.environ),timeout=180,directory=E/('snapshot-presentation-restore-branch01-'+label),output_limit=4*1024*1024,wait_for_job_empty_after_primary=True)
 commands.append(dict(label=label,receipt=str(r.directory/'receipt.json'),sha256=sha(r.directory/'receipt.json')))
 assert r.ok and r.receipt['primary_stopped'] and r.receipt['job_empty_observed'],label
 return r
for action in ('policy','detect','plan'):run(action,['py','-3','-B','.aide/scripts/aide_lite.py','git',action])
run('paths',['py','-3','-B','tools/workspace_hygiene.py','paths'])
run('fetch',['git','fetch','origin','dev']);assert git('rev-parse','origin/dev')==BASE
prior=json.loads((E/'snapshot-local-install-merge-and-dev-sync-result-01.json').read_bytes())
assert prior['status']=='SYNCHRONIZED_EXACT_CHECKED_DEV_READY_FOR_NEXT_OUTCOME' and prior['dev']==BASE
assert prior['resource_use']['task_root_bytes']<20*1024**3 and prior['resource_use']['task_roots']==8
run('create',['git','switch','-c',BRANCH,BASE]);assert git('branch','--show-current')==BRANCH and git('rev-parse','HEAD')==BASE
out=E/'snapshot-presentation-restore-branch-result-01.json';assert not out.exists()
result=dict(status='READY_ON_NEW_TASK_BRANCH_FROM_LATEST_INTEGRATED_DEV',branch=BRANCH,base=BASE,commands=commands,new_roots=0,new_worktrees=0,
            hygiene_receipt=str(E/'snapshot-local-install-merge-sync01-doctor/receipt.json'),operator_approval='standing user instruction for implementation and normal checked branch flow')
out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in result.items() if k!='commands'},indent=2))
