import hashlib,json,subprocess
from pathlib import Path
E=Path(__file__).resolve().parent;W=E.parent;R=Path(r'D:\Projects\Factorio\factorio-launcher')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_bytes())
packet=E/'snapshot-presentation-author-packet-01.json'
assert sha(packet)=='d77d4caf1d18f540f48535716da814bf12ab73cb2b8a636f6dbbcc9bdcc76929'
p=load(packet);assert p['base']=='6c6efc8a679404147a56a24803bd8c4618bafefa'
assert p['status']=='PASS_BOUNDED_WINDOWS_SOURCE_QUALIFICATION_PRIOR_FAILURES_RETAINED'
git=lambda *a:subprocess.check_output(['git','-c','core.safecrlf=false',*a],cwd=R,text=True).strip()
assert git('rev-parse','HEAD')==p['base'] and git('branch','--show-current')==p['branch']
dirty=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
assert dirty<=set(p['source_files']) and len(p['source_files'])==19
stat_only=set(p['source_files'])-dirty
assert stat_only<={'.aide/memory/project-state.md','.aide/memory/project-state.v2.json','README.md'}
for name in stat_only:assert git('hash-object','--path',name,str(R/name))==git('rev-parse','HEAD:'+name)
for name,digest in p['source_files'].items():assert sha(R/name)==digest
for name,digest in p['protected_unchanged_files'].items():assert sha(R/name)==digest
for name,digest in p['compiled_inputs_unchanged_from_passed_build'].items():assert sha(R/name)==digest
assert sha(p['patch']['path'])==p['patch']['sha256']
custody=Path(p['raw_hash_custody']['path']);assert sha(custody)==p['raw_hash_custody']['sha256']
artifacts=[]
for line in custody.read_text(encoding='utf-8').splitlines():
 digest,name=line.split('  ',1);path=(E/name).resolve(strict=True)
 assert path.is_relative_to(W.resolve()) and sha(path)==digest
 artifacts.append(dict(path=str(path),sha256=digest))
assert len(artifacts)==p['raw_artifact_count']==184
def check_receipt(path,digest=None):
 path=Path(path)
 if digest:assert sha(path)==digest
 r=load(path);assert r['termination']=='completed' and r['primary_stopped'] and r['job_empty_observed']
 for stream in ('stdout','stderr'):assert sha(path.parent/r[stream]['file'])==r[stream]['sha256']
 return r
for row in p['process_receipts']:check_receipt(E/row['path'],row['sha256'])
assert len(p['process_receipts'])==37
for c in p['qualification']['commands']:
 r=check_receipt(c['receipt'],c['receipt_sha256']);assert r['exit_code']==c['exit_code']==0
 if c['name'] in p['focused_method_counts']:
  raw=(Path(c['receipt']).parent/'stderr.raw').read_text(encoding='utf-8')
  assert f"Ran {p['focused_method_counts'][c['name']]} test" in raw and '\nOK' in raw and 'FAILED' not in raw and 'skipped' not in raw
native=E/'snapshot-presentation-windows-native-05/stdout.raw'
assert '100% tests passed, 0 tests failed out of 3' in native.read_text(encoding='utf-8')
assert p['focused_methods_total']==sum(p['focused_method_counts'].values())==24
end=p['endurance'];assert end['status']=='pass' and end['durable_operations']==end['receipt_files']==64
assert end['idempotent_replays']==end['conflict_controls']==end['restart_cycles']==4 and end['failures']==0
assert end['elapsed_seconds']==4.295 and end['receipt_bytes']==129024
env=check_receipt(p['retained_environment']['receipt']);assert env['exit_code']==0
raw=(Path(p['retained_environment']['receipt']).parent/'stderr.raw').read_text(encoding='utf-8')
assert 'Ran 3 tests' in raw and '\nOK' in raw
for c in p['final_checks']['commands']:
 r=check_receipt(c['receipt'])  # exact receipt hash is in the verified raw custody
 assert c['exit_code']==r['exit_code']==(1 if c['name']=='doctor' else 0)
assert p['resource_after']['violations']==['unmanaged_secondary_worktrees_present']
assert p['resource_after']['task_roots']==8 and p['resource_after']['measured_bytes']<20*1024**3
assert p['resource']['measured_bytes']+p['resource']['conservative_additional_peak_bytes']<20*1024**3
assert p['resource_after']['free_bytes']>=12*1024**3
assert p['cache_bytes_unchanged'] and sha(Path(p['resource']['build_root'])/'CMakeCache.txt')==p['cache_sha256_after']
assert sha(p['qualification']['cli'])==p['qualification']['cli_sha256']
service=(R/'runtime/factorio/application/presentation_service.cpp').read_text(encoding='utf-8')
support=(R/'runtime/factorio/application/presentation_action_support.cpp').read_text(encoding='utf-8')
store=(R/'apps/gui/windows/winforms/C1LivePresentationStore.cs').read_text(encoding='utf-8')
assert 'if (!instances_result && request.scope == "activity_recovery")' in service
assert 'error.code, error.message, error.path + " " + error.detail' in service
assert 'if (!installs_result || !instances_result)' in service
assert 'RestoreSnapshotRequest{request.source_path, request.new_instance_id, request.installation_id}' in service
assert 'std::get<transactions::RecoveryResult>(result.output).json' in support
assert 'transactions::to_json(std::get<transactions::Refusal>(result.output), "workspace.recovery.apply")' in support
assert '(receipt.ActionId == "modsets.import" || receipt.ActionId == "snapshots.restore") && receipt.Outcome == "completed"' in store
for key in ('commits','pushes','ci_runs','real_game'):assert not p[key]
out=E/'snapshot-presentation-independent-review-01.json';assert not out.exists()
v=dict(schema='facman.independent_snapshot_presentation_source_review.v1',verdict='PASS_SCOPED_SOURCE_FOR_REQUIRED_CURRENT_CI',
 base=p['base'],branch=p['branch'],packet_sha256=sha(packet),reviewer_script_sha256=sha(__file__),non_authoring=True,
 source_files_sha256=p['source_files'],preserved_artifacts=artifacts,artifacts_verified=184,
 product_files=4,focused_methods_passed=24,native_tests_passed=3,retained_unchanged_owner_environment_methods=3,
 bounded_endurance_operations=64,bounded_endurance_replays=4,bounded_endurance_conflicts=4,bounded_endurance_restarts=4,
 endurance_seconds=4.295,closed_recorded_jobs=37,
 raw_owner_report_and_typed_recovery_payload_preserved=True,activity_only_inventory_fallback=True,
 ordinary_scopes_retain_repository_refusal=True,unknown_receipt_not_rewritten_after_recovery=True,
 explicit_no_selection_entry_and_returned_selection=True,source_installation_world_and_foreign_bytes_preserved=True,
 immutable_codec_schema_golden_owner_and_historical_receipts_preserved=True,
 postqualification_test_formatting_reviewed=True,configured_workers=2,observed_two_compiler_process_maximum=False,
 windows_UI='compiled structural control/form/store only; no backend-through-UI or physical-input qualification',
 retained_failure_campaigns_not_relabelled=True,required_current_CI_pending=True,produced_current_package_pending=True,
 workunit_closed=False,real_game=False,beta=False,rc=False,new_roots=0,new_caches=0,new_worktrees=0)
out.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:value for k,value in v.items() if k not in ('source_files_sha256','preserved_artifacts')},indent=2))
