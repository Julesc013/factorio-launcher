import datetime,difflib,hashlib,json,os,re,shutil,subprocess,sys
from pathlib import Path
R=Path(r"D:\Projects\Factorio\factorio-launcher");W=Path(r"D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e");E=W/"evidence";B=W/"native-developer"
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
qualification=json.loads((E/"snapshot-presentation-windows-result-05.json").read_text());assert qualification["status"]=="PASS_FOCUSED_WINDOWS_QUALIFICATION"
checks=json.loads((E/"snapshot-presentation-final-checks-result-02.json").read_text());assert checks["status"]=="PASS_FINAL_CHECKS"
resource=json.loads((E/"snapshot-presentation-resource-01.json").read_text());assert resource["fixture_before"]=={p.relative_to(R).as_posix():sha(p) for p in (R/"tests/fixtures").rglob("*") if p.is_file()}
corrective=json.loads((E/"snapshot-presentation-corrective-source-01.json").read_text());protected=corrective["protected_unchanged_files"];assert protected=={n:sha(R/n) for n in protected}
compiled_inputs={n:h for n,h in corrective["source_files"].items() if n.startswith(("runtime/","apps/","tests/"))}
formatting=json.loads((E/"snapshot-presentation-test-format-correction-01.json").read_text());assert formatting["ast_equivalent"];assert compiled_inputs.pop(Path(formatting["path"]).as_posix())==formatting["before_sha256"];assert sha(R/formatting["path"])==formatting["after_sha256"]
assert compiled_inputs=={n:sha(R/n) for n in compiled_inputs}
doctor=json.loads((E/"snapshot-presentation-final-doctor-02/stdout.raw").read_text());assert set(doctor["violations"])<={"unmanaged_secondary_worktrees_present"};assert doctor["task_root_bytes"]<20*1024**3;assert shutil.disk_usage(W).free>12*1024**3
raw=subprocess.check_output(["git","-c","core.safecrlf=false","status","--porcelain","-z"],cwd=R).decode();entries=[n for n in raw.split("\0") if n];names=sorted(n[3:] for n in entries);assert len(names)==19
patch=subprocess.check_output(["git","-c","core.safecrlf=false","diff","--",*names],cwd=R)
for item in entries:
 if item.startswith("?? "):
  n=item[3:];patch+="".join(difflib.unified_diff([], (R/n).read_text().splitlines(keepends=True),fromfile="/dev/null",tofile="b/"+n)).encode()
patch_path=E/"snapshot-presentation-final-source-01.patch";patch_path.write_bytes(patch)
receipts=[];artifacts={}
for p in sorted(E.glob("snapshot-presentation-*")):
 paths=list(p.rglob("*")) if p.is_dir() else [p]
 for child in paths:
  if not child.is_file() or child.name.startswith("snapshot-presentation-author-packet"):continue
  relative=child.relative_to(E).as_posix();artifacts[relative]=sha(child)
  if child.name=="receipt.json":
   receipt=json.loads(child.read_text());assert receipt["job_empty_observed"] and receipt["primary_stopped"],relative
   receipts.append(dict(path=relative,sha256=sha(child),termination=receipt["termination"],job_empty=True,primary_stopped=True))
manifest=E/"snapshot-presentation-author-packet-01.sha256";manifest.write_text("".join(h+"  "+n+"\n" for n,h in sorted(artifacts.items())))
counts={}
for command in qualification["commands"]:
 if command["name"].startswith("windows-") and command["name"] not in ("windows-build","windows-native","windows-receipt-endurance"):
  stderr=Path(command["receipt"]).with_name("stderr.raw").read_text(errors="replace");match=re.search(r"Ran (\d+) tests? in",stderr);assert match and "\nOK\n" in stderr,command["name"];counts[command["name"]]=int(match.group(1))
endurance=json.loads((E/"snapshot-presentation-endurance-result-05.json").read_text());assert endurance["status"]=="pass",endurance
record=dict(schema="facman.snapshot_presentation_author_packet.v1",status="PASS_BOUNDED_WINDOWS_SOURCE_QUALIFICATION_PRIOR_FAILURES_RETAINED",created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),base="6c6efc8a679404147a56a24803bd8c4618bafefa",branch=subprocess.check_output(["git","branch","--show-current"],cwd=R).decode().strip(),source_files={n:sha(R/n) for n in names},patch=dict(path=str(patch_path),sha256=sha(patch_path)),protected_unchanged_files=protected,qualification=qualification,focused_method_counts=counts,focused_methods_total=sum(counts.values()),native_ctest_count=3,endurance=endurance,retained_environment=dict(methods=3,result="PASS unchanged-owner/shared-dispatch baseline before presentation correction",receipt=str(E/"snapshot-presentation-windows-environment-03/receipt.json")),final_checks=checks,resource=resource,cache_sha256_after=sha(B/"CMakeCache.txt"),cache_bytes_unchanged=resource["cache_sha256"]==sha(B/"CMakeCache.txt"),source_fixture_inputs_unchanged=True,compiled_inputs_unchanged_from_passed_build=compiled_inputs,postqualification_test_formatting= formatting,resource_after=dict(task_roots=len(doctor["task_roots"]),measured_bytes=doctor["task_root_bytes"],violations=doctor["violations"],free_bytes=shutil.disk_usage(W).free),admission_census_limit="Inherited raw-string regex was overescaped; separate correct live census proves observed build processes descend from the single owned build. Original admission observation is retained without a false process-maximum claim.",process_receipts=receipts,all_recorded_jobs_empty=True,raw_artifact_count=len(artifacts),raw_hash_custody=dict(path=str(manifest),sha256=sha(manifest)),retained_failures=["original68endurance failures from incomplete independent fixture", "initial8method snapshot suite:4failures1error; three presentation gaps and one stale-test assumption", "runner03 terminalsource assertion from authorizedmidrun edits; all19 command methods separatelypassed", "runner04 guard assertion from evidence-suffix substitution; zero commands/builds", "strict01 test-only overlong line; AST-equivalent formatting correction and strict02pass"],limits=["Windows source qualification only; no new hosted CI or deliveredpackage qualification", "Modal harness structural controls only; no physicalUI/backendthroughUI claim", "Configured CMake/MSBuild parallel2; actualcensus has3cl driverprocesses, no observed2compilerprocessmaximum claim", "No new provider/game authority; unchanged schemas/fingerprint/receiptcodec/owner/recovery", "No new roots/caches/worktrees; no commit/push/CI/Gitbranch changes"],commits=0,pushes=0,ci_runs=0,real_game=False)
out=E/"snapshot-presentation-author-packet-01.json";assert not out.exists();out.write_text(json.dumps(record,indent=2)+"\n");print(json.dumps(dict(packet=str(out),sha256=sha(out),focused_methods=sum(counts.values()),receipts=len(receipts),raw_artifacts=len(artifacts),manifest_sha256=sha(manifest),patch_sha256=sha(patch_path))))
