import hashlib,json,os,subprocess,sys
from pathlib import Path
R=Path(r"D:\Projects\Factorio\factorio-launcher");W=Path(r"D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e");E=W/"evidence";sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();env=dict(os.environ,FACMAN_DEV_ROOT=r"D:\Projects\Factorio\.task-builds",TEMP=str(W/"t"),TMP=str(W/"t"),PYTHONDONTWRITEBYTECODE="1",PYTHONUTF8="1",FACMAN_MIN_FREE_GIB="12")
assert json.loads((E/"snapshot-presentation-windows-result-05.json").read_text())["status"]=="PASS_FOCUSED_WINDOWS_QUALIFICATION"
names=json.loads((E/"snapshot-presentation-corrective-source-01.json").read_text())["source_files"]
before={n:sha(R/n) for n in names};record=dict(schema="facman.snapshot_presentation_final_checks.v1",status="started",commands=[],source_before=before);out=E/"snapshot-presentation-final-checks-result-01.json";assert not out.exists()
for name,args in [("strict",["py","-3","-B","tools/strict_check.py"]),("portable-aide",["py","-3","-B",".aide/scripts/aide_lite.py","test"]),("diff",["git","-c","core.safecrlf=false","diff","--check"]),("doctor",["py","-3","-B","tools/workspace_hygiene.py","doctor","--measure"])]:
 cap=owned.command(args,cwd=R,environment=env,timeout=900,directory=E/("snapshot-presentation-final-"+name+"-01"),output_limit=32*1024*1024,wait_for_job_empty_after_primary=True)
 item=dict(name=name,argv=args,exit_code=cap.returncode,termination=cap.receipt["termination"],job_empty=cap.receipt["job_empty_observed"],primary_stopped=cap.receipt["primary_stopped"],receipt=str(cap.directory/"receipt.json"));record["commands"].append(item);owned.write_json(out,record);print(name,cap.returncode,flush=True)
 if name!="doctor" and not cap.ok:
  record["status"]="FAIL_RETAINED";owned.write_json(out,record);print((cap.stdout+cap.stderr).decode(errors="replace")[-10000:]);raise SystemExit(cap.returncode or 1)
 assert item["job_empty"] and item["primary_stopped"]
assert before=={n:sha(R/n) for n in names},"Source changed during final static checks"
record.update(status="PASS_FINAL_CHECKS",source_unchanged=True);owned.write_json(out,record)
