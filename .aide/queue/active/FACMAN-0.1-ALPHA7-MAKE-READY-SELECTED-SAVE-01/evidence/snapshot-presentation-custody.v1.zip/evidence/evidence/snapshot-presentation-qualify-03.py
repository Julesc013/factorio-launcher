import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e');E=W/'evidence';B=W/'native-developer';sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();env=dict(os.environ,FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',FACMAN_MIN_FREE_GIB='12',CMAKE_BUILD_PARALLEL_LEVEL='2',MSBUILDDISABLENODEREUSE='1',PYTHONPATH=str(R/'tests')+os.pathsep+str(R))
resource=json.loads((E/'snapshot-presentation-resource-01.json').read_text());assert resource['peak_within_20GiB'];assert json.loads((W/'.facman-development-root.v1.json').read_text())['task_id']=='task/facman-world-restore-retention-01';assert subprocess.check_output(['git','branch','--show-current'],cwd=R).decode().strip()=='task/facman-snapshot-presentation-restore-01'
record=dict(schema='facman.snapshot_presentation_qualification.v1',status='started',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),commands=[],real_game=False,provider_edits=False,linux_builds=0)
out=E/'snapshot-presentation-windows-result-03.json';assert not out.exists()
def save():owned.write_json(out,record)
save()
# Preserve idle and active foreign processes. Wait here, never terminate them.
ps=r"Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(cl|c1xx|link|clang|clang\+\+|ninja|cmake|MSBuild)(\.exe)?$' } | Select-Object ProcessId,ParentProcessId,Name,CommandLine | ConvertTo-Json -Depth 4"
started=time.monotonic();observations=[]
while True:
 raw=subprocess.check_output(['powershell','-NoProfile','-Command',ps],timeout=30);rows=json.loads(raw) if raw.strip() else [];rows=rows if isinstance(rows,list) else [rows]
 active=[p for p in rows if p['Name'].lower() not in ['cmake.exe','msbuild.exe'] or (p['Name'].lower()=='cmake.exe' and '--build' in (p['CommandLine'] or '')) or (p['Name'].lower()=='msbuild.exe' and '/nodemode:' not in (p['CommandLine'] or '').lower())]
 observations.append(dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),active=active,all_build_processes=rows));(E/'snapshot-presentation-heavy-admission-03.json').write_text(json.dumps(observations,indent=2)+'\n')
 if not active:break
 if time.monotonic()-started>1200:raise AssertionError('Foreign active build admission did not become idle; preserved all processes')
 time.sleep(5)
def run(name,args,timeout=600):
 cap=owned.command(args,cwd=R,environment=env,timeout=timeout,directory=E/f'snapshot-presentation-{name}-03',output_limit=32*1024*1024,wait_for_job_empty_after_primary=True)
 item=dict(name=name,argv=args,exit_code=cap.returncode,termination=cap.receipt['termination'],job_empty=cap.receipt['job_empty_observed'],primary_stopped=cap.receipt['primary_stopped'],receipt=str(cap.directory/'receipt.json'),receipt_sha256=sha(cap.directory/'receipt.json'),stdout_sha256=sha(cap.directory/'stdout.raw'),stderr_sha256=sha(cap.directory/'stderr.raw'));record['commands'].append(item);save();print(name,cap.returncode,cap.receipt['termination'],flush=True)
 if not cap.ok or not item['job_empty'] or not item['primary_stopped']:
  record.update(status='FAIL_RETAINED',failed_command=name);save();print(cap.stdout.decode(errors='replace')[-7000:]+cap.stderr.decode(errors='replace')[-7000:],flush=True);raise SystemExit(cap.returncode or 1)
exe=B/'Release/facman.exe';assert exe.is_file();env.update(FACMAN_CLI_EXE=str(exe),FACMAN_TUI_EXE=str(exe))
for name,tests in [('ordinary-tui',['test_tui_product.TuiProductTests.test_ordinary_saves_snapshot_form_navigation_cancel_and_confirm_without_selected_instance']),('existing-pack-import',['test_presentation_pack_import']),('existing-presentation',['test_presentation_service']),('immutable-legacy-receipt',['test_presentation_intent']),('environment',['test_environment_reconstruction']),('winforms-scoped-guard',['test_facman_winforms_c1_shell.FacManWinFormsC1ShellTests.test_content_and_saves_are_ordinary_descriptor_driven_pages'])]:
 run('windows-'+name,['py','-3','-B','-m','unittest',*tests,'-v'],900)
assert resource['source_before']=={n:sha(R/n) for n in resource['source_before']},'Source changed during tests';assert resource['fixture_before']=={p.relative_to(R).as_posix():sha(p) for p in (R/'tests/fixtures').rglob('*') if p.is_file()},'Fixture inputs changed'
record.update(status='PASS_FOCUSED_WINDOWS_QUALIFICATION',source_unchanged=True,source_fixture_inputs_unchanged=True,cli=str(exe),cli_sha256=sha(exe),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save();print(json.dumps(dict(status=record['status'],commands=len(record['commands']),result=str(out))),flush=True)
