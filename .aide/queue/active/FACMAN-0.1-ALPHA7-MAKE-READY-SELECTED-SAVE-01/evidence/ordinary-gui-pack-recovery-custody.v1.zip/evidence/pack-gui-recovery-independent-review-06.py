"""Read-only evidence assurance: exact named inputs; never execute products."""
import ast,ctypes,hashlib,io,json,subprocess,sys,zipfile
from ctypes import wintypes as wt
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).parent;W=E.parent;RAW=E/'pack-gui-recovery-raw-06'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
digest=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_bytes())
expected={'pack-gui-recovery-raw-06/result.json':'b061ed624dbcbf850716642ea8571a500e085b8f112f5368a27a74092bd0e863','pack-gui-recovery-preparation-06.json':'0f2acfaa3d05d245a87b75093ea506894de398a9efc31e26243242dc0206e0cb','pack-gui-recovery-plan-06.json':'709e7a2f62c0d478fd3d976cee91b951dcdf7b60e46be4bd6e3737ba04c291b7','pack-gui-recovery-preimage-06.json':'f4f3d12d5ec7264b61a12b2648df57d66c17d3dcd4e5cb94c34ed02a39b952be'}
for n,h in expected.items():assert sha(E/n)==h,n
plan=load(E/'pack-gui-recovery-plan-06.json');pre=load(E/'pack-gui-recovery-preimage-06.json');result=load(RAW/'result.json');launch=load(E/'pack-gui-recovery-launch-result-06.json')
assert result['status']==launch['status']=='PASS_ORDINARY_GUI_RECOVERY_OF_RETAINED_FAILED05'
assert plan['execution_tree']==plan['artifact_tree']=='f8d2f65989eccc0c710355af79f8a8f16f74e9d6'
assert plan['artifact']==12027606187 and plan['artifact_source']=='3ba5e00f9c1b95f9431bf1d4acf009e3ab174aad'
for n,v in plan['prepared_scripts'].items():assert sha(E/n)==v['sha256'];ast.parse((E/n).read_bytes())
for n,h in plan['evidence_inputs'].items():assert sha(E/n)==h,n
for n,h in pre['raw05_evidence'].items():assert sha(E/n)==h,n
for n,h in plan['source_inputs'].items():assert sha(R/n)==h,n
assert sha(W/'.facman-development-root.v1.json')==plan['task_marker_sha256']
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
assert git('rev-parse','HEAD')==plan['execution_head'] and git('rev-parse','HEAD^{tree}')==plan['execution_tree'] and not git('status','--porcelain')
for key in ('identity','paths','doctor','worker'):
 row=launch[key];p=Path(row['receipt']);assert sha(p)==row['receipt_sha256'];receipt=load(p)
 assert receipt['termination']=='completed' and receipt['primary_stopped'] and receipt['job_empty_observed'] and not receipt['job_terminated']
 for stream in ('stdout','stderr'):
  raw=(p.parent/receipt[stream]['file']).read_bytes();assert len(raw)==receipt[stream]['captured_bytes'] and digest(raw)==receipt[stream]['sha256']
assert launch['worker']['exit_code']==0 and launch['worker_dispatch_count']==1
assert len(result['calls'])==5
for i,row in enumerate(result['calls']):
 directory=RAW/f'command-{i:03}';p=directory/'receipt.json';receipt=load(p);assert sha(p)==row['receipt_sha256']
 assert row['exit_code']==receipt['exit_code']==0 and receipt['termination']=='completed' and receipt['primary_stopped'] and receipt['job_empty_observed'] and not receipt['job_terminated']
 for stream in ('stdout','stderr'):
  data=(directory/receipt[stream]['file']).read_bytes();assert len(data)==receipt[stream]['captured_bytes'] and digest(data)==receipt[stream]['sha256']
 assert not (directory/'stderr.raw').read_bytes()
 assert row['argv'][2:4] in (['modsets','verify'],['instances','verify'],['instances','list']) or row['argv'][2:5] in (['workspace','recovery','inspect'],['workspace','recovery','plan'])
session=result['sessions'];assert len(session)==1
terminal=session[0]['terminal'];assert terminal['pid']==52832 and terminal['exit_code']==0 and terminal['stdout']==terminal['stderr']=='' and not terminal['safety_termination'] and terminal['owned_job_active_processes']==0
assert terminal['launch']['created_suspended'] and terminal['launch']['exact_job_membership_before_resume'] and terminal['launch']['resume_previous_suspend_count']==1
children=terminal['backend_processes'];assert len(children)==66 and len({c['process_identity'] for c in children})==66
roles={role:[c for c in children if c['role']==role] for role in ('packaged_backend','windows_console_host')};assert all(len(v)==33 for v in roles.values())
for c in children:assert c['exact_job_membership'] and c['exit_code']==0 and c['gui_pid']==52832 and sha(c['image'])==c['image_sha256']
events=session[0]['events'];clicks=[e for e in events if e['stage']=='WM_COMMAND/BN_CLICKED'];assert [e['text'] for e in clicks]==['&Apply supported recovery','OK']
for e in clicks:assert e['pid']==52832 and e['post_succeeded'] and all(a['visible'] and a['enabled'] for a in e['ancestors']) and e['notification_parent']==e['parent_hwnd']
dialog=next(e for e in events if e['stage']=='exact retained transaction explicit confirmation');tx=result['transaction_id'];assert dialog['title']=='Recover operation' and any(tx in c.get('text','') for c in dialog['controls'])
assert any(e['stage']=='ordinary recovery completed; original uncertainty retained' and any(c.get('text','').replace('\r\n','\n')=='Instance\nRestored pack' for c in e['controls']) for e in events)
before=result['snapshots'][0]['inventory'];after=result['snapshots'][1]['inventory'];assert before==pre['fixture_inventory'] and after==result['final_fixture_inventory']
cas={}
for inv in (before,after):
 for n,row in inv.items():
  if not row['directory']:
   data=(RAW/'cas'/row['sha256']).read_bytes();assert digest(data)==row['sha256'] and len(data)==row['size'];cas[row['sha256']]=data
stage=pre['stage_relative'];target=pre['target_relative'];journal=pre['journal_relative'];original=pre['semantic_receipt_relative']
for n,row in before.items():
 if n in (stage,journal,journal+'.recovery.lock') or n.startswith(stage+'/'):continue
 assert after[n]==row,n
assert after[target]['identity']==pre['stage_identity']==before[stage]['identity']
for n,row in before.items():
 if n.startswith(stage+'/') and n.split('/')[-1] not in ('.facman-archive-staging.v1','.facman-transaction-staging.v2.json'):
  assert after[target+'/'+n[len(stage)+1:]]==row,n
for row in pre['journal']['expected_files']:
 assert before[stage+'/'+row['path']]['sha256']==after[target+'/'+row['path']]['sha256']==row['sha256']
 assert len(cas[row['sha256']])==row['size']
assert cas[after[original]['sha256']].decode()==pre['original_semantic_receipt_text'] and after[original]==before[original]
old=load(W/'t/j3/pg1'/original);assert old['state']=='accepted_outcome_unknown' and json.loads(old['result_json'])['outcome']=='outcome_unknown'
rr=result['recovery_receipt'];rq=json.loads(rr['request_json']);rs=json.loads(rr['result_json'])
assert digest(rr['request_json'].encode())==rr['request_fingerprint'] and digest(rr['result_json'].encode())==rr['result_digest'] and len(rr['result_json'].encode())==rr['result_length']
assert rr['state']=='terminal' and rq['action_id']==rr['action_id']==rs['action_id']=='recovery.apply_supported' and rq['confirmation']=='explicit' and rq['transaction_id']==tx and rq['scope']=='activity_recovery' and rs['outcome']=='completed'
assert json.loads(cas[after[journal]['sha256']])['state']=='complete'
newfiles={n for n,row in after.items() if not row['directory'] and n not in before};recoveryfiles=[n for n in newfiles if '/action-receipts-v2/' in n];assert len(recoveryfiles)==1 and json.loads(cas[after[recoveryfiles[0]]['sha256']])==rr
assert newfiles=={target+'/'+v['path'] for v in pre['journal']['expected_files']}|set(recoveryfiles)
pack=cas[pre['source_pack_sha256']];provenance=json.loads(cas[after[target+'/modpack-import.v1.json']['sha256']])
with zipfile.ZipFile(io.BytesIO(pack)) as z:
 for n in ('modset-lock.v1.json','modpack-manifest.v1.json','mods/simple_1.0.0.zip','mods/mod-list.json','mods/mod-settings.dat'):assert z.read(n)==cas[after[target+'/'+n]['sha256']]
 assert digest(z.read('modset-lock.v1.json'))==provenance['source_lock_sha256'] and digest(z.read('modpack-manifest.v1.json'))==provenance['source_manifest_sha256']
assert provenance['archive_sha256']==digest(pack) and provenance['archive_size']==len(pack) and provenance['install_ref']=='fixture' and provenance['source_instance_id']=='solver'
lockbytes=cas[after[target+'/mods/modset-lock.v1.json']['sha256']];lock=json.loads(lockbytes);assert digest(lockbytes)==provenance['target_lock_sha256'] and lock['instance_id']=='reconstructed' and next(m['source'] for m in lock['mods'] if m['name']=='base')=='install-data:fixture'
# Reobserve only explicit final paths and their native identities; no evidence-root scan.
api=ctypes.WinDLL('kernel32',use_last_error=True)
class Info(ctypes.Structure):_fields_=[('attributes',wt.DWORD),('creation',wt.FILETIME),('access',wt.FILETIME),('write',wt.FILETIME),('volume',wt.DWORD),('size_high',wt.DWORD),('size_low',wt.DWORD),('links',wt.DWORD),('index_high',wt.DWORD),('index_low',wt.DWORD)]
api.CreateFileW.argtypes=[wt.LPCWSTR,wt.DWORD,wt.DWORD,ctypes.c_void_p,wt.DWORD,wt.DWORD,wt.HANDLE];api.CreateFileW.restype=wt.HANDLE
api.GetFileInformationByHandle.argtypes=[wt.HANDLE,ctypes.POINTER(Info)];api.GetFileInformationByHandle.restype=wt.BOOL
api.CloseHandle.argtypes=[wt.HANDLE];api.CloseHandle.restype=wt.BOOL
for n,row in after.items():
 p=W/'t/j3/pg1'/n;handle=api.CreateFileW(str(p),128,7,None,3,35651584,None);assert handle!=ctypes.c_void_p(-1).value
 try:
  info=Info();assert api.GetFileInformationByHandle(handle,ctypes.byref(info)) and not info.attributes&1024
  assert f'{info.volume}:{info.index_high<<32|info.index_low}'==row['identity'] and bool(info.attributes&16)==row['directory']
  if not row['directory']:assert info.links==1 and sha(p)==row['sha256'] and p.stat().st_size==row['size']
 finally:assert api.CloseHandle(handle)
admission=load(E/'tui-feedback-delivered-extract-02.json');G=Path(plan['package']);assert len(admission['file_inventory'])==599
for n,h in admission['file_inventory'].items():assert sha(G/n)==h,n
sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools.package.runtime_identity import require_backend_identity
identity=require_backend_identity(G,G/'bin/facman.exe',load(E/'pack-gui-interrupted-raw-04/command-005/stdout.raw')['payload'])
classification=load(E/plan['root_classification_file']);assert classification['actual_template']=='vanilla' and not classification['intentional_fault_applied'] and not classification['gui_child_drain_qualified'] and classification['gui_primary_exit']==0
assert not result['prior05_child_drain_qualified'] and not result['planned_intentional_fault_journey_qualified'] and result['intentional_fault_count']==result['import_dispatches']==result['setup_replays']==0
review=dict(schema='facman.ordinary_gui_recovery.independent_review.v1',verdict='PASS_SCOPED_ORDINARY_GUI_RECOVERY_ONLY',reviewer='/root/tui_feedback_review; non-author of recovery06 controllers',bindings=expected,execution_head=plan['execution_head'],execution_tree=plan['execution_tree'],artifact_source=plan['artifact_source'],artifact=plan['artifact'],scripts=plan['prepared_scripts'],launch_result_sha256=sha(E/'pack-gui-recovery-launch-result-06.json'),review_script_sha256=sha(__file__),actual_gui=dict(pid=52832,ordinary_activity_controls=True,exact_transaction=tx,explicit_confirmation=True,natural_exit_zero=True,strict_original_helper=True,backend_zero_exits=33,conhost_zero_exits=33,exact_job_membership=True,safety_termination=False,job_empty=True),readonly_cli_jobs=5,verified=dict(source_inputs=len(plan['source_inputs']),retained_evidence_inputs=len(plan['evidence_inputs']),retained_failed05_files=len(pre['raw05_evidence']),package_files=599,preimage_entries=len(before),final_entries=len(after),cas_unique_referenced=len(cas),expected_staged_files=9,current_native_identities_reobserved=len(after),archive_and_settings_bytes=True,provenance_and_rebound_lock=True,unrelated_bytes_and_identities_preserved=True,original_accepted_outcome_unknown_preserved=True,recovery_semantic_completed=True,terminal_inspection_read_only=True),actionable_findings=[],limitations=['Accepts only new ordinary GUI recovery from retained failed05, not the planned intentional-fault/lifetime journey.','Failed05 callback rejected legitimate template_id vanilla after verified staging; no deliberate fault occurred. GUI primary exited0 but child-drain qualification failed. Those original outcomes remain failed and retained.','Earlier03 directory-helper and04 selector failures remain historical; no relabel or replay.','No product rerun, GUI interaction, download, build, repository edit, or Git mutation performed for this review.','No full F11, real game, human, host, Beta/RC, or release qualification.'])
out=E/'pack-gui-recovery-independent-review-06.json';assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(verdict=review['verdict'],path=str(out),sha256=sha(out),verified=review['verified']),indent=2))
