"""Exact-hash execution entry point; resource waiting belongs to this script."""
import hashlib
import importlib
import json
import os
from pathlib import Path
import shutil
import sys
import traceback

sys.dont_write_bytecode = True
E = Path(__file__).resolve().parent
sys.path[:0] = [str(E), r'D:\Projects\Factorio\factorio-launcher']
R = Path(r'D:\Projects\Factorio\factorio-launcher')
W = E.parent
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main(reviewed_hash):
    plan_path = E / 'pack-gui-interrupted-plan-04.json'
    assert sha(plan_path) == reviewed_hash
    plan = json.loads(plan_path.read_bytes())
    probe = importlib.import_module('pack-gui-interrupted-probe-04')
    probe.PLAN = plan_path
    probe.guard(plan)
    assert not Path(plan['fixture_root']).exists()
    assert not Path(plan['new_raw_prefix']).exists()
    output = E / 'pack-gui-interrupted-launch-result-04.json'
    assert not output.exists()
    from tools import provider_canary_process as owned
    result = dict(status='RESOURCE_WAIT', plan_sha256=reviewed_hash,
        execution_head=plan['execution_head'], artifact_source=plan['artifact_source'],
        worker_dispatch_count=0, product_builds=0, downloads=0, new_task_roots=0,
        new_worktrees=0, new_clones=0)
    def save():
        total = 0
        for item in E.glob('pack-gui-interrupted-*'):
            total += item.stat().st_size if item.is_file() else sum(p.stat().st_size for p in item.rglob('*') if p.is_file())
        assert total <= 128*1024**2
        owned.write_json(output, result)
    def command(argv, name, timeout):
        directory = E / ('pack-gui-interrupted-' + name + '-04')
        cap = owned.command(argv, cwd=R, environment=dict(os.environ), directory=directory,
            timeout=timeout, output_limit=2 * 1024**2, wait_for_job_empty_after_primary=True)
        result[name] = dict(receipt=str(directory/'receipt.json'), receipt_sha256=sha(directory/'receipt.json'),
            exit_code=cap.returncode, termination=cap.receipt['termination'])
        save()
        assert cap.receipt['termination'] == 'completed' and cap.receipt['primary_stopped']
        assert cap.receipt['job_empty_observed'] and not cap.receipt['job_terminated']
        return cap
    try:
        os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',
            TEMP=str(W/'t'), TMP=str(W/'t'), PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1', FACMAN_MIN_FREE_GIB='12')
        save()
        sample = probe.wait_for_resources(dict(
            verdict='ADMIT_EXACT_GUI_INTERRUPTED_IMPORT_RESOURCE_PROBE',
            plan_sha256=reviewed_hash, prepared_scripts=plan['prepared_scripts']), 'before-doctor')
        result['resource_sample'] = sample
        identity = command(['powershell', '-NoProfile', '-NonInteractive', '-Command',
            '[Security.Principal.WindowsIdentity]::GetCurrent().Name'], 'identity', 30)
        assert identity.ok and identity.stdout.decode().strip().casefold() == r'BLACKGLASS-WIN1\Jules'.casefold()
        paths = command([sys.executable, '-B', 'tools/workspace_hygiene.py', 'paths'], 'paths', 60)
        assert paths.ok
        doctor = command([sys.executable, '-B', 'tools/workspace_hygiene.py', 'doctor', '--measure',
            '--max-task-roots', '8', '--max-bytes', str(20*1024**3)], 'doctor', 600)
        measured = json.loads(doctor.stdout)
        assert (doctor.returncode, measured['result'], measured['violations']) in (
            (0, 'pass', []), (1, 'fail', ['unmanaged_secondary_worktrees_present']))
        assert len(measured['task_roots']) <= 8 and all(r['owned'] for r in measured['task_roots'])
        assert measured['task_root_bytes'] + plan['limits']['new_total_bytes'] < 20*1024**3
        assert shutil.disk_usage(W).free - plan['limits']['new_total_bytes'] > 12*1024**3
        result['doctor_admission'] = dict(task_roots=len(measured['task_roots']), bytes=measured['task_root_bytes'],
            known_unchanged_advisory=measured['violations'], foreign_worktrees_touched=False)
        # The second finite census phase has separate live first/latest state;
        # waiting remains indefinite and creates no product/helper retries.
        result['pre_worker_resource_sample'] = probe.wait_for_resources(dict(
            verdict='ADMIT_EXACT_GUI_INTERRUPTED_IMPORT_RESOURCE_PROBE',
            plan_sha256=reviewed_hash, prepared_scripts=plan['prepared_scripts']), 'before-worker')
        probe.guard(plan)
        assert not Path(plan['fixture_root']).exists() and not Path(plan['new_raw_prefix']).exists()
        result.update(status='RUNNING_SINGLE_FINITE_GUI_SCENARIO', worker_dispatch_count=1); save()
        worker = command([sys.executable, '-B', str(E/'pack-gui-interrupted-worker-04.py'),
            '--reviewed-plan-sha256', reviewed_hash], 'worker', 360)
        status_path = E/'pack-gui-interrupted-worker-status-04.json'
        if status_path.exists():
            result['worker_status'] = json.loads(status_path.read_bytes())
            result['worker_status_sha256'] = sha(status_path)
            save()
        if not worker.ok:
            state = result.get('worker_status', {})
            raise AssertionError('Worker exited ' + str(worker.returncode) + ' during ' +
                str(state.get('phase', 'startup')) + ': ' + str(state.get('error') or
                state.get('wrapper_error') or 'See exact worker command stdout/stderr and receipt'))
        proof = json.loads((Path(plan['new_raw_prefix'])/'result.json').read_bytes())
        assert worker.ok and proof['status'] == 'PASS_EXACT_PACKAGED_GUI_INTERRUPTED_IMPORT_ORDINARY_RECOVERY'
        assert proof['intentional_fault_count'] == 1 and proof['naturally_drained_gui_jobs'] == 2
        assert proof['final_guards'] == dict(package_599_unchanged=True, source_clean_and_frozen=True,
            source_fixture_unchanged=True, no_cleanup_deletion=True)
        probe.guard(plan)
        result.update(status='PASS_EXACT_PACKAGED_GUI_INTERRUPTED_IMPORT_ORDINARY_RECOVERY',
            proof_sha256=sha(Path(plan['new_raw_prefix'])/'result.json'))
    except BaseException as error:
        result.update(status='FAIL_RETAINED', error=str(error), traceback=traceback.format_exc())
    finally:
        save()
        print(json.dumps({k:result.get(k) for k in ('status','worker_dispatch_count','error')}), flush=True)
    return 0 if result['status'].startswith('PASS_') else 1


if __name__ == '__main__':
    assert len(sys.argv) == 3 and sys.argv[1] == '--reviewed-plan-sha256'
    raise SystemExit(main(sys.argv[2]))
