"""Recover retained failed05 through one strict ordinary GUI session only."""
import contextlib, ctypes, hashlib, importlib, json, os, sys, time, traceback
from ctypes import wintypes as wt
from pathlib import Path
from unittest.mock import patch
R=Path(r'D:\Projects\Factorio\factorio-launcher'); E=Path(__file__).resolve().parent; W=E.parent
G=W/'t/j3/g3b'; F=W/'t/j3/pg1'; C=F/'c'; WS=F/'consumer'; RAW=E/'pack-gui-recovery-raw-06'
sys.dont_write_bytecode=True; sys.path[:0]=[str(E),str(R/'tests'),str(R)]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
STATUS_STREAM=None; STATUS=dict(status='STARTED',phase='entry')
def status_update(**values):
    STATUS.update(values); raw=(json.dumps(STATUS,indent=2)+'\n').encode(); assert len(raw)<=1024**2
    STATUS_STREAM.seek(0); STATUS_STREAM.write(raw); STATUS_STREAM.truncate(); STATUS_STREAM.flush(); os.fsync(STATUS_STREAM.fileno())

def execute(plan_hash):
    probe=importlib.import_module('pack-gui-recovery-probe-06'); assert sha(probe.PLAN)==plan_hash
    plan=json.loads(probe.PLAN.read_bytes()); probe.guard(plan)
    launch_path=E/'pack-gui-recovery-launch-result-06.json'; launch_raw=launch_path.read_bytes(); launch=json.loads(launch_raw)
    assert launch['plan_sha256']==plan_hash and launch['worker_dispatch_count']==1
    assert launch['execution_head']==plan['execution_head'] and launch['artifact_source']==plan['artifact_source']
    assert launch['status']=='RUNNING_SINGLE_FINITE_GUI_SCENARIO' and launch['pre_worker_resource_sample']['quiet'] and launch['resource_sample']['quiet']
    assert launch['doctor_admission']['task_roots']<=8 and launch['doctor_admission']['bytes']+plan['limits']['new_total_bytes']<20*1024**3
    assert launch['doctor_admission']['foreign_worktrees_touched'] is False
    assert not RAW.exists() and F.is_dir()
    pre=json.loads((E/'pack-gui-recovery-preimage-06.json').read_bytes())
    assert pre['prior05_child_drain_qualified'] is False and pre['intentional_fault_applied'] is False
    import native_cli, test_windows_delivered_joined_gui as gui, test_portable_modpack_import as portable
    from tools import provider_canary_process as owned
    from tools.package.runtime_identity import require_backend_identity
    started=time.monotonic(); deadline=started+300; active=None; fixed=[]; transient=[]
    result=dict(status='STARTED',plan_sha256=plan_hash,calls=[],sessions=[],snapshots=[],
        prior05_child_drain_qualified=False,planned_intentional_fault_journey_qualified=False,
        intentional_fault_count=0,import_dispatches=0,setup_replays=0,fixture_created=False,
        real_game=False,human=False,full_F11=False,beta=False)
    api = ctypes.WinDLL('kernel32', use_last_error=True)
    api.CreateFileW.argtypes = [wt.LPCWSTR, wt.DWORD, wt.DWORD, ctypes.c_void_p, wt.DWORD, wt.DWORD, wt.HANDLE]
    api.CreateFileW.restype = wt.HANDLE
    api.CloseHandle.argtypes, api.CloseHandle.restype = ([wt.HANDLE], wt.BOOL)
    class Info(ctypes.Structure):
        _fields_ = [('attributes', wt.DWORD), ('creation', wt.FILETIME), ('access', wt.FILETIME), ('write', wt.FILETIME), ('volume', wt.DWORD), ('size_high', wt.DWORD), ('size_low', wt.DWORD), ('links', wt.DWORD), ('index_high', wt.DWORD), ('index_low', wt.DWORD)]
    api.GetFileInformationByHandle.argtypes = [wt.HANDLE, ctypes.POINTER(Info)]
    api.GetFileInformationByHandle.restype = wt.BOOL
    def object_identity(path):
        handle = api.CreateFileW(str(path), 128, 7, None, 3, 35651584, None)
        if handle == ctypes.c_void_p(-1).value:
            raise ctypes.WinError(ctypes.get_last_error())
        try:
            info = Info()
            if not api.GetFileInformationByHandle(handle, ctypes.byref(info)):
                raise ctypes.WinError(ctypes.get_last_error())
            assert not info.attributes & 1024, 'Identity observation refuses reparse point: ' + str(path)
            assert info.attributes & 16 or info.links == 1
            return f'{info.volume}:{info.index_high << 32 | info.index_low}'
        finally:
            assert api.CloseHandle(handle)
    def pin(path, directory, group):
        path = Path(path)
        status_update(phase='no_follow_pin', path=str(path), directory=directory)
        assert path.is_absolute()
        handle = api.CreateFileW(str(path), 128, 3 if directory else 1, None, 3, 35651584, None)
        assert handle != ctypes.c_void_p(-1).value, str(path)
        try:
            info = Info()
            assert api.GetFileInformationByHandle(handle, ctypes.byref(info))
            assert not info.attributes & 1024 and bool(info.attributes & 16) == directory
            assert directory or info.links == 1
            identity = f'{info.volume}:{info.index_high << 32 | info.index_low}'
            assert object_identity(path) == identity
            group.append(handle)
            return identity
        except BaseException:
            api.CloseHandle(handle)
            raise
    def unpin(group):
        while group:
            assert api.CloseHandle(group.pop())
    def bounded():
        assert time.monotonic()<deadline, 'Finite recovery scenario deadline reached'
        assert sum(p.stat().st_size for p in RAW.rglob('*') if p.is_file())<=80*1024**2
        assert sum(p.stat().st_size for p in F.rglob('*') if p.is_file())<=16*1024**2
    def save():
        owned.write_json(RAW/'result.json',result)
        status_update(status=result['status'],error=result.get('error'),traceback=result.get('traceback'),cleanup=result.get('cleanup_errors'))
    def inventory(root,capture=False):
        rows={}
        for p in sorted(root.rglob('*')):
            assert time.monotonic()<deadline
            st=p.lstat(); assert not p.is_symlink() and not getattr(st,'st_file_attributes',0)&0x400
            row=dict(identity=object_identity(p),directory=p.is_dir())
            if p.is_file():
                raw=p.read_bytes(); row.update(size=len(raw),sha256=hashlib.sha256(raw).hexdigest())
                if capture:
                    blob=RAW/'cas'/row['sha256']
                    if not blob.exists():
                        with blob.open('xb') as stream: stream.write(raw)
            rows[p.relative_to(root).as_posix()]=row
        return rows
    def package_inventory():
        rows={}
        for p in sorted(G.rglob('*')):
            st=p.lstat(); assert not p.is_symlink() and not getattr(st,'st_file_attributes',0)&0x400
            if p.is_file(): rows[p.relative_to(G).as_posix()]=sha(p)
        return rows
    def machine(args,env=None):
        bounded(); assert len(result['calls'])<16 and args[:2]==['--workspace',str(WS)]
        assert args[2:4] in (['modsets','verify'],['instances','verify'],['instances','list']) or args[2:5] in (
            ['workspace','recovery','inspect'],['workspace','recovery','plan'])
        directory=RAW/f'command-{len(result["calls"]):03}'
        cap=owned.command([str(G/'bin/facman.exe'),*args],cwd=C,environment=environment,directory=directory,
            timeout=min(30,deadline-time.monotonic()),output_limit=1024**2,wait_for_job_empty_after_primary=True)
        result['calls'].append(dict(argv=args,receipt_sha256=sha(directory/'receipt.json'),exit_code=cap.returncode)); save()
        assert cap.receipt['termination']=='completed' and cap.receipt['primary_stopped'] and cap.receipt['job_empty_observed'] and not cap.receipt['job_terminated']
        bounded(); return cap.returncode,cap.stdout.decode().replace('\r\n','\n'),cap.stderr.decode().replace('\r\n','\n')
    original_receipt=F/pre['semantic_receipt_relative']; journal=F/pre['journal_relative']
    stage=F/pre['stage_relative']; target=F/pre['target_relative']; tx=pre['journal']['transaction_id']
    environment={k:v for k,v in os.environ.items() if not k.startswith('FACMAN_')}
    environment.update(PATH='',PYTHONDONTWRITEBYTECODE='1',TEMP=str(F),TMP=str(F))
    try:
        for directory in reversed([F.parent,*F.parent.parents]): pin(directory,True,fixed)
        for directory in [F,E,G,R]: pin(directory,True,fixed)
        assert inventory(F)==pre['fixture_inventory'], 'Frozen failed05 fixture changed'
        assert sha(original_receipt)==pre['semantic_receipt_sha256'] and sha(journal)==pre['journal_sha256']
        assert not target.exists() and not (WS/'.facman-modpack-import-verified-release').exists()
        admission=json.loads((E/'tui-feedback-delivered-extract-02.json').read_bytes())
        actual=package_inventory()
        assert actual==admission['file_inventory'] and len(actual)==599
        # The original compiled identity response is retained in04 and bound to
        # these identical package bytes. No initial product/setup command repeats.
        product=json.loads((E/'pack-gui-interrupted-raw-04/command-005/stdout.raw').read_bytes())['payload']
        result['backend_identity']=require_backend_identity(G,G/'bin/facman.exe',product)
        assert product['backend_identity']['build']['source_revision']==plan['artifact_source']
        RAW.mkdir(); (RAW/'cas').mkdir(); (RAW/'launcher-admission.raw.json').write_bytes(launch_raw)
        before=inventory(F,True); result['snapshots'].append(dict(stage='frozen failed05 preimage',inventory=before))
        original_bytes=original_receipt.read_bytes(); assert original_bytes.decode()==pre['original_semantic_receipt_text']
        # Keep immutable original authority/source inputs pinned. Stage and
        # journal pins are temporary and released before native recovery writes.
        for p in [F/'.facman-diagnostic-fixture.v1.json',original_receipt,WS/'workspace.v1.json',F/'producer/pack.zip']:
            pin(p,False,fixed)
        for row in pre['operation_context']['files']: pin(Path(row['path']),False,fixed)
        pin(stage,True,transient); pin(journal,False,transient)
        for p in stage.rglob('*'): pin(p,p.is_dir(),transient)
        save()
        active=gui.OwnedControls(G/'bin/FacMan.WinForms.exe',C,WS,environment,deadline)
        result['sessions'].append(dict(events=active.events)); main=active.window('FacMan'); active.show_main_offscreen(main)
        active.wait(lambda: bool(active.revision(main)) and 'revision 0' not in active.revision(main),'fresh retained recovery observation')
        active.frame(main,'before ordinary Activity navigation')
        tabs=[h for h in active.enumerate(main) if active.text(h,True).upper()=='SYSTABCONTROL32' or active.text(h,True).upper().startswith('WINDOWSFORMS10.SYSTABCONTROL32.')]
        assert len(tabs)==1 and active.send(tabs[0],0x1304)==7
        active.send(tabs[0],0x1330,4); assert active.send(tabs[0],0x130B)==4
        active.wait(lambda:any(active.text(h)=='Activity' and active.api.IsWindowVisible(h) for h in active.enumerate(main)),'visible ordinary Activity page')
        active.frame(main,'ordinary retained transaction recovery')
        active.click(active.control(main,'Apply supported recovery'))
        dialog=active.window('Recover operation',tx); active.frame(dialog,'exact retained transaction explicit confirmation')
        assert sha(original_receipt)==pre['semantic_receipt_sha256'] and sha(journal)==pre['journal_sha256']
        assert inventory(F)==before, 'Observation or confirmation changed retained inputs'
        unpin(transient)  # Original native owner must acquire publication capability itself.
        active.click(active.control(dialog,'OK'))
        active.wait(lambda:json.loads(journal.read_bytes())['state']=='complete','ordinary GUI recovery completion')
        active.wait(lambda:any(active.text(h).replace('\r\n','\n')=='Instance\nRestored pack' for h in active.enumerate(main)),'refreshed reconstructed instance selection')
        active.frame(main,'ordinary recovery completed; original uncertainty retained')
        active.finish(); result['sessions'][-1]['terminal']=active.terminal; active=None
        with patch.object(native_cli,'invoke_machine',machine),patch.object(native_cli,'ROOT',C):
            portable.PortableModpackImportTests().assert_reconstruction(WS,F/'producer/pack.zip')
        assert original_receipt.read_bytes()==original_bytes and object_identity(target)==pre['stage_identity']
        after=inventory(F,True); result['snapshots'].append(dict(stage='completed ordinary recovery',inventory=after))
        staging_prefix=pre['stage_relative']+'/'
        journal_key=pre['journal_relative']; lock_key=journal_key+'.recovery.lock'
        for name,row in before.items():
            if name in (pre['stage_relative'],journal_key,lock_key) or name.startswith(staging_prefix): continue
            assert after[name]==row, 'Existing unrelated input changed: '+name
        for name,row in before.items():
            if name.startswith(staging_prefix) and name.split('/')[-1] not in ('.facman-archive-staging.v1','.facman-transaction-staging.v2.json'):
                new=pre['target_relative']+'/'+name[len(staging_prefix):]; assert after[new]==row
        receipts=[(p,json.loads(p.read_bytes())) for p in (WS/'.facman/action-receipts-v2').glob('*.v2.json')]
        recovered=[(p,r) for p,r in receipts if r['action_id']=='recovery.apply_supported']; assert len(recovered)==1
        rp,rr=recovered[0]; rq=json.loads(rr['request_json']); assert rq['transaction_id']==tx and rq['confirmation']=='explicit'
        assert json.loads(rr['result_json'])['outcome']=='completed'
        newfiles={n for n,v in after.items() if not v['directory'] and n not in before}
        allowed={pre['target_relative']+'/'+v['path'] for v in pre['journal']['expected_files']}|{rp.relative_to(F).as_posix()}
        assert newfiles==allowed, 'Unexpected new persistent file effects'
        # Terminal recovery inspection only; neither the original request nor
        # terminal apply is replayed after the completed ordinary GUI effect.
        terminal_before=inventory(WS)
        for args in (['--workspace',str(WS),'workspace','recovery','inspect','--json'],
                     ['--workspace',str(WS),'workspace','recovery','plan',tx,'--json']):
            code,out,err=machine(args); assert code==0 and not err, out+err
        assert inventory(WS)==terminal_before and original_receipt.read_bytes()==original_bytes
        assert package_inventory()==actual
        probe.guard(plan); bounded()
        result.update(status='PASS_ORDINARY_GUI_RECOVERY_OF_RETAINED_FAILED05',naturally_drained_gui_jobs=1,
            original_uncertainty_sha256=sha(original_receipt),transaction_id=tx,recovery_receipt=rr,
            final_guards=dict(package_599_unchanged=True,source_clean_and_frozen=True,original_uncertainty_unchanged=True,
                unrelated_inputs_preserved=True,terminal_inspection_read_only=True))
    except BaseException as error:
        result.update(status='FAIL_RETAINED',error=repr(error),traceback=traceback.format_exc())
        if active:
            try:
                for h in active.enumerate(observe=False):
                    try: active.frame(h,'failure; original exception retained')
                    except BaseException as ex: active.events.append(dict(stage='failure frame error',error=repr(ex)))
            except BaseException as ex: result['frame_error']=repr(ex)
    finally:
        unpin(transient)
        if active:
            try: active.finish()
            except BaseException as ex:
                result.setdefault('cleanup_errors',[]).append(repr(ex)); result['status']='FAIL_RETAINED_CLEANUP'
            result['sessions'][-1]['terminal']=active.terminal
        if RAW.exists():
            try: result['final_fixture_inventory']=inventory(F,True); bounded()
            except BaseException as ex:
                result['final_guard_error']=repr(ex); result['status']='FAIL_RETAINED_FINAL_GUARD'
            result['elapsed_seconds']=time.monotonic()-started; save()
        else: status_update(status=result['status'],error=result.get('error'),traceback=result.get('traceback'))
        unpin(fixed)
    return 0 if result['status']=='PASS_ORDINARY_GUI_RECOVERY_OF_RETAINED_FAILED05' else 1

if __name__=='__main__':
    with (E/'pack-gui-recovery-worker-status-06.json').open('x+b') as STATUS_STREAM:
        status_update()
        try:
            assert len(sys.argv)==3 and sys.argv[1]=='--reviewed-plan-sha256'; code=execute(sys.argv[2]); status_update(exit_code=code)
        except BaseException as ex: status_update(status='FAIL_RETAINED',wrapper_error=repr(ex),wrapper_traceback=traceback.format_exc(),exit_code=1); code=1
        print(json.dumps(STATUS),flush=True)
    raise SystemExit(code)
