"""Prepared resource gate; no product execution or fixture creation.

Nothing runs on import. Root must separately approve exact plan/script hashes.
The eventual controller calls wait_for_resources before its finite GUI phase.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
W = E.parent
PLAN = E / 'pack-gui-interrupted-plan-04.json'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def guard(plan):
    def git(*args):
        return subprocess.check_output(['git', *args], cwd=R, text=True, timeout=30).strip()
    assert git('rev-parse', 'HEAD') == plan['execution_head']
    assert git('rev-parse', 'HEAD^{tree}') == plan['execution_tree']
    assert git('branch', '--show-current') == 'dev' and not git('status', '--porcelain')
    assert sha(W / '.facman-development-root.v1.json') == plan['task_marker_sha256']
    assert all(sha(R / name) == digest for name, digest in plan['source_inputs'].items())
    assert all(sha(E / name) == item['sha256'] for name, item in plan['prepared_scripts'].items())
    assert all(sha(E / name) == digest for name, digest in plan['evidence_inputs'].items())


def wait_for_resources(root_review, phase):
    plan = json.loads(PLAN.read_bytes())
    assert root_review['verdict'] == 'ADMIT_EXACT_GUI_INTERRUPTED_IMPORT_RESOURCE_PROBE'
    assert root_review['plan_sha256'] == sha(PLAN)
    assert root_review['prepared_scripts'] == plan['prepared_scripts']
    guard(plan)
    assert phase in ('before-doctor', 'before-worker')
    output = E / ('pack-gui-interrupted-resources-' + phase + '-04.json')
    assert not output.exists()
    probe = (E / 'joined-final-input-resource-probe-02.ps1').read_text().replace(
        'Identity=[System.Security.Principal.WindowsIdentity]::GetCurrent().Name;',
        'Identity=[System.Security.Principal.WindowsIdentity]::GetCurrent().Name;ProbePID=$PID;'
        'ProbeCreationUtc=([Diagnostics.Process]::GetCurrentProcess().StartTime.ToUniversalTime().ToString("o"));')
    linux = """import json,os
active=[]
for n in os.listdir('/proc'):
 if n.isdigit():
  try:
   comm=open('/proc/'+n+'/comm').read().strip()
   if comm in {'facman','factorio','cmake','ninja','cc1plus','ctest','g++','c++','clang','clang++','gcc','cc','ld','as'}:
    active.append(dict(pid=int(n),command=open('/proc/'+n+'/cmdline','rb').read().decode(errors='replace').replace(chr(0),' ')))
  except FileNotFoundError:pass
print(json.dumps(dict(mount_namespace=os.readlink('/proc/self/ns/mnt'),active=active)))"""
    with output.open('x+b') as raw:
        attempt = 0
        first = None
        while True:
            sample = json.loads(subprocess.check_output(['powershell', '-NoProfile', '-NonInteractive',
                '-Command', probe], text=True, timeout=45))
            assert sample['Identity'].casefold() == r'BLACKGLASS-WIN1\Jules'.casefold()
            assert type(sample['ProbePID']) is int and sample['ProbePID'] > 0 and sample['ProbeCreationUtc']
            own_cpu = [r for r in sample['HeavyCPU'] if r['PID'] == sample['ProbePID']]
            own_io = [r for r in sample['HeavyIO'] if r['IDProcess'] == sample['ProbePID']]
            assert all(r['Name'].casefold() in ('powershell', 'pwsh') for r in own_cpu)
            assert all(r['Name'].casefold().startswith(('powershell', 'pwsh')) for r in own_io)
            sample.update(OwnExactProbeCPU=own_cpu, OwnExactProbeIO=own_io)
            sample['HeavyCPU'] = [r for r in sample['HeavyCPU'] if r['PID'] != sample['ProbePID']]
            sample['HeavyIO'] = [r for r in sample['HeavyIO'] if r['IDProcess'] != sample['ProbePID']]
            sample['Linux'] = json.loads(subprocess.check_output(['wsl.exe', '-d', 'Ubuntu-24.04',
                '-u', 'root', '--exec', '/usr/bin/python3', '-B', '-c', linux], text=True, timeout=45))
            sample['quiet'] = (not sample['HeavyCPU'] and not sample['HeavyIO'] and
                not sample['Toolchains'] and not sample['Linux']['active'] and
                sample['AvailablePhysicalBytes'] >= 3 * 1024**3 and
                shutil.disk_usage(W).free - plan['limits']['new_total_bytes'] > 12 * 1024**3)
            if first is None:
                first = sample
            # Live resource state is first/latest samples plus an exact count,
            # not a claimed archive of every waiting census. The same owned
            # handle permits indefinite healthy waiting with bounded storage.
            state = dict(schema='facman.live_resource_wait.v1', phase=phase,
                sample_count=attempt+1, first_sample=first, latest_sample=sample,
                intermediate_censuses_retained=False, product_dispatched=False)
            encoded = (json.dumps(state, sort_keys=True) + '\n').encode()
            assert len(encoded) <= 16 * 1024**2
            raw.seek(0); raw.write(encoded); raw.truncate(); raw.flush(); os.fsync(raw.fileno())
            if sample['quiet']:
                guard(plan)
                return sample
            # Indefinite script-owned backoff, bounded individual waits. No
            # foreign process is stopped, signalled, reprioritized or resumed.
            delay = (60, 120, 300, 600)[min(attempt, 3)]
            attempt += 1
            for _ in range(delay // 60):
                time.sleep(60)


if __name__ == '__main__':
    raise SystemExit('PREPARED_ONLY: no resource/product dispatch; exact root review required')
