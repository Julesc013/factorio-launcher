"""Package exact accepted recovery evidence; no product/repository/Git mutation."""
import hashlib, json, zipfile
from pathlib import Path
E=Path(__file__).resolve().parent; R=Path(r'D:\Projects\Factorio\factorio-launcher')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
dig=lambda raw:hashlib.sha256(raw).hexdigest()
result_path=E/'pack-gui-recovery-raw-06/result.json'; result=json.loads(result_path.read_bytes())
plan=json.loads((E/'pack-gui-recovery-plan-06.json').read_bytes())
pre=json.loads((E/'pack-gui-recovery-preimage-06.json').read_bytes())
review_path=E/'pack-gui-recovery-independent-review-06.json'; review=json.loads(review_path.read_bytes())
assert sha(result_path)=='b061ed624dbcbf850716642ea8571a500e085b8f112f5368a27a74092bd0e863'
assert sha(review_path)=='03de91b50e379160a27d59420c8e83827bed16292a05bd66c454be0b84850168'
assert review['verdict']=='PASS_SCOPED_ORDINARY_GUI_RECOVERY_ONLY' and not review['actionable_findings']
assert result['status']=='PASS_ORDINARY_GUI_RECOVERY_OF_RETAINED_FAILED05'
files={}; source_map={}
def add(path, archive=None):
    path=Path(path); archive=archive or ('evidence/'+path.relative_to(E).as_posix())
    assert not path.is_symlink() and '..' not in Path(archive).parts and not Path(archive).is_absolute()
    raw=path.read_bytes()
    # Exclude delivered executables/libraries and actual native image payloads.
    assert path.suffix.lower() not in ('.exe','.dll','.pdb','.lib','.a','.so','.dylib')
    assert not raw.startswith((b'MZ',b'\x7fELF',b'\xcf\xfa\xed\xfe',b'\xfe\xed\xfa\xcf'))
    if archive in files: assert files[archive]==raw; return
    files[archive]=raw; source_map[archive]=str(path)

# Actual executed03/04/05 controllers, admission reviews and observed failures.
for version in ('03','04','05'):
    for stem in ('plan','preparation','probe','worker','launch','root-execution-review','launch-result'):
        suffix='.py' if stem in ('probe','worker','launch') else '.json'
        add(E/f'pack-gui-interrupted-{stem}-{version}{suffix}')
    if version!='03': add(E/f'pack-gui-interrupted-worker-status-{version}.json')
    for name in ('receipt.json','stdout.raw','stderr.raw'):
        add(E/f'pack-gui-interrupted-worker-{version}/{name}')
for name in ('pack-gui-interrupted-fault-01.py','pack-gui-interrupted-directory-diagnosis-04.json',
    'pack-gui-interrupted-directory-observations-04.json','pack-gui-interrupted-helper-selftest-04.json',
    'pack-gui-interrupted-root-failure-classification-05.json','pack-gui-interrupted-retained-fixture-admission-05.json',
    'pack-gui-interrupted-raw-04/result.json'):
    add(E/name)
# Exact retained05 raw/CAS preimage is already enumerated, bounded and hash-closed.
for name, expected in pre['raw05_evidence'].items(): assert sha(E/name)==expected; add(E/name)
# The compiled package identity response reused by06; no package image bytes.
for number in ('005','006'):
    for name in ('receipt.json','stdout.raw','stderr.raw'): add(E/f'pack-gui-interrupted-raw-04/command-{number}/{name}')
for stem in ('plan','preparation','probe','worker','launch','root-execution-review','launch-result','worker-status','independent-review'):
    suffix='.py' if stem in ('probe','worker','launch') else '.json'
    add(E/f'pack-gui-recovery-{stem}-06{suffix}')
for name in ('pack-gui-recovery-independent-review-06.py','pack-gui-recovery-preimage-06.json',
    'pack-gui-recovery-native-block-06.txt','pack-gui-recovery-resources-before-doctor-06.json',
    'pack-gui-recovery-resources-before-worker-06.json','tui-feedback-delivered-extract-02.json',
    'joined-final-input-resource-probe-02.ps1'):
    add(E/name)
for name in ('result.json','launcher-admission.raw.json'): add(E/'pack-gui-recovery-raw-06'/name)
for number in range(5):
    for name in ('receipt.json','stdout.raw','stderr.raw'):
        add(E/f'pack-gui-recovery-raw-06/command-{number:03}/{name}')
for path in (E/'pack-gui-recovery-raw-06/cas').iterdir(): assert path.is_file(); add(path)
for group in ('worker','identity','paths','doctor'):
    for name in ('receipt.json','stdout.raw','stderr.raw'): add(E/f'pack-gui-recovery-{group}-06/{name}')
for name in ('tests/test_windows_delivered_joined_gui.py','tests/test_portable_modpack_import.py',
    'tests/native_cli.py','tests/test_local_modset_solver.py','tests/test_make_ready_joined.py'):
    assert sha(R/name)==plan['source_inputs'][name]; add(R/name,'source-authority/'+name)
add(Path(__file__),'custody-builder.py')

failures=[]
for version in ('03','04','05'):
    launch=E/f'pack-gui-interrupted-launch-result-{version}.json'
    entry=dict(attempt=version,launch_result_sha256=sha(launch),
        worker_receipt_sha256=sha(E/f'pack-gui-interrupted-worker-{version}/receipt.json'),
        worker_stdout_sha256=sha(E/f'pack-gui-interrupted-worker-{version}/stdout.raw'),
        worker_stderr_sha256=sha(E/f'pack-gui-interrupted-worker-{version}/stderr.raw'))
    if version=='03':
        entry.update(classification='Helper failed before fixture/product dispatch; original exception swallowed. Missing-proof read masked failure. Read-only directory diagnosis retained; no original exception invented.',raw_result_existed=False)
    else:
        p=E/f'pack-gui-interrupted-raw-{version}/result.json'; old=json.loads(p.read_bytes())
        entry.update(result_sha256=sha(p),status=old['status'],error=old.get('error'),cleanup_errors=old.get('cleanup_errors'))
        if version=='04': entry['classification']='Owned tab class selector rejected WinForms family before import; seven setup/query CLI calls and normal GUI retained. No import/fault/stage/target.'
        else: entry['classification']='Legitimate template_id vanilla rejected by probe after verified import. No intentional fault. GUI primary exit0; original child drain unqualified and cleanup failed. Retained owner effect recovered only by06.'
    failures.append(entry)
binding=dict(schema='facman.ordinary_gui_recovery.custody_binding.v1',
    evidence_scope='new ordinary packaged Windows GUI recovery of retained failed05 only',
    result_sha256=sha(result_path),independent_review_sha256=sha(review_path),
    execution_head=plan['execution_head'],execution_tree=plan['execution_tree'],artifact_source=plan['artifact_source'],
    artifact=plan['artifact'],prior05_child_drain_qualified=False,intentional_fault_journey_qualified=False,
    failure_history=failures)
files['binding.json']=(json.dumps(binding,indent=2)+'\n').encode()
manifest=dict(schema='facman.compact_evidence_custody.v1',files={n:dict(size_bytes=len(v),sha256=dig(v)) for n,v in sorted(files.items())},
    source_map=source_map,excluded=['delivery executables/libraries','build outputs','package payloads','repository/source clone','full filesystem/root dumps'],
    note='Only bounded fixture CAS/preimage bytes, raw streams/receipts, exact scripts/plans/reviews and five source helper/oracle files are included. Fixture ZIP/settings bytes are retained; no real game binary is included.')
manifest_raw=(json.dumps(manifest,indent=2)+'\n').encode()
archive=E/'ordinary-gui-pack-recovery-custody.v1.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in sorted(dict(files,**{'manifest.v1.json':manifest_raw}).items()):
        info=zipfile.ZipInfo(name,(2026,10,16,0,0,0)); info.compress_type=zipfile.ZIP_DEFLATED; info.external_attr=0o100644<<16
        z.writestr(info,raw)
assert archive.stat().st_size<=2*1024**2
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(files)+1 and len(set(z.namelist()))==len(z.namelist())
    assert z.read('manifest.v1.json')==manifest_raw
    for name,raw in files.items(): assert z.read(name)==raw
terminal=result['sessions'][0]['terminal']; roles={}
for row in terminal['backend_processes']: assert row['exit_code']==0; roles[row['role']]=roles.get(row['role'],0)+1
receipt=dict(schema='facman.delivered_gui_pack_recovery_accepted_slice.v1',
    verdict='INDEPENDENTLY_ACCEPTED_SCOPED_ORDINARY_GUI_RECOVERY_ONLY',
    recorded_at_utc='2026-10-16T09:54:48Z',work_item='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01',
    scope='One new ordinary packaged Windows GUI Activity recovery from the honestly failed retained05 verified import; original import/fault/lifetime journey remains unqualified.',
    execution=dict(head=plan['execution_head'],tree=plan['execution_tree'],branch_at_execution='dev',
        artifact_source=plan['artifact_source'],producer_run=plan['producer_run'],artifact=plan['artifact'],
        package_files=599,backend_sha256=plan['backend_sha256'],gui_sha256=plan['gui_sha256'],provider_pins=plan['provider_pins'],
        result_sha256=sha(result_path),plan_sha256=sha(E/'pack-gui-recovery-plan-06.json'),scripts=plan['prepared_scripts']),
    ordinary_recovery=dict(transaction_id=result['transaction_id'],action_id='recovery.apply_supported',
        scope='activity_recovery',explicit_confirmation=True,owner_state='complete',selected_instance='reconstructed',
        expected_staged_files=9,before_entries=106,after_entries=104,elapsed_seconds=result['elapsed_seconds'],
        exact_archive_settings_provenance_and_rebound_lock=True,unrelated_bytes_and_native_identities_preserved=True,
        original_semantic_state='accepted_outcome_unknown',original_semantic_sha256=result['original_uncertainty_sha256'],
        original_request_replayed=False,import_replayed=False,setup_replayed=False,release_marker_created=False,
        intentional_fault_applied=False,terminal_inspection_read_only=True),
    process_lifetime=dict(gui_pid=terminal['pid'],gui_exit_code=terminal['exit_code'],
        original_strict_helper=True,created_suspended=terminal['launch']['created_suspended'],
        exact_job_before_resume=terminal['launch']['exact_job_membership_before_resume'],
        packaged_backends=roles['packaged_backend'],conhosts=roles['windows_console_host'],all_observed_child_exits=0,
        gui_safety_termination=False,normal_empty_gui_jobs=1,read_only_cli_commands=5,all_cli_normal_empty_jobs=True),
    independent_review=dict(verdict=review['verdict'],reviewer=review['reviewer'],
        file_in_custody='evidence/'+review_path.name,sha256=sha(review_path),exact_bytes_copied=True,findings=[]),
    earlier_failures=failures,
    retained_boundaries=dict(prior05_child_drain_qualified=False,planned_intentional_fault_journey_qualified=False,
        original_failed_attempt_relabelled=False,torn_file_repair=False,full_F09=False,full_F11=False,workunit_closed=False,
        real_game=False,human=False,named_or_minimum_host=False,canonical_installed_desktop=False,
        PR404_owner_gate_changed=False,Beta=False,RC=False,release=False,
        historical_pack_partial_gui_interrupted_import_qualified_flag_edited=False),
    custody=dict(file=archive.name,sha256=sha(archive),size_bytes=archive.stat().st_size,
        entries=len(files)+1,uncompressed_bytes=sum(map(len,files.values()))+len(manifest_raw),manifest_sha256=dig(manifest_raw),
        includes_exact_independent_review=True,all_entries_reopened_and_hash_checked=True),
    integration=dict(status='pending_normal_checked_documentation_integration',
        branch='task/facman-gui-pack-recovery-proof-01',
        branch_plan_sha256='e77043656631af84288070174255f2ed8646890854b6b5972a16e502c547ca38',
        runtime_or_product_source_changed=False,new_build_or_download=False,new_fixture_or_task_root=False))
out=E/'ordinary-gui-pack-recovery.v1.draft.json'
with out.open('x',encoding='utf-8',newline='\n') as stream: json.dump(receipt,stream,indent=2); stream.write('\n')
paragraph=('2026-10-16: The existing artifact12027606187/source3ba5e00f (same tree as executiondevc46534db) '
    'qualified one new ordinary Windows packaged GUI Activity recovery from retained failed05. Explicit confirmation named '
    'the exact transaction; the original native owner completed publication of nine verified files and selected the reconstructed instance. '
    'Exact settings/archive/provenance/rebound-lock bytes and native identities, unrelated inputs and original accepted_outcome_unknown '
    'receipt bytes remain preserved. One strict original-helper GUI session exits0 with33backend and33conhost exits0, natural empty-job proof '
    'and five normal read-only CLI jobs; terminal inspect/plan cause no mutation. Independent exact-byte review accepts this recovery slice only. '
    'Earlier03 directory-helper and04 navigation failures remain retained. Failed05 rejected legitimate template_id vanilla after staging; '
    'no intentional fault occurred, and its child-drain failure remains unqualified. No import/setup/release/fault replay, new fixture, '
    'product build or source fix occurred. The planned intentional-fault/lifetime journey remains unqualified; historical pack-partial-produced '
    'acceptance is unchanged. Full F09/F11, canonical installed Desktop/PR404 owner control, real game, human/named-host and Beta/RC gates '
    'remain open. Receipt and compact hash-closed custody: evidence/ordinary-gui-pack-recovery.v1.json and '
    'evidence/ordinary-gui-pack-recovery-custody.v1.zip.\n')
text=E/'ordinary-gui-pack-recovery-execplan-append-06.md'
with text.open('x',encoding='utf-8',newline='\n') as stream: stream.write('\n'+paragraph)
report=dict(status='DRAFT_RECEIPT_PARAGRAPH_AND_CUSTODY_READY',receipt=str(out),receipt_sha256=sha(out),
    append_paragraph=str(text),append_paragraph_sha256=sha(text),custody=str(archive),custody_sha256=sha(archive),
    custody_bytes=archive.stat().st_size,custody_entries=len(files)+1,uncompressed_bytes=receipt['custody']['uncompressed_bytes'],
    exact_independent_review_sha256=sha(review_path),repository_mutations=0,product_reruns=0)
with (E/'pack-gui-recovery-acceptance-draft-packet-06.json').open('x',encoding='utf-8',newline='\n') as stream: json.dump(report,stream,indent=2); stream.write('\n')
print(json.dumps(report),flush=True)
