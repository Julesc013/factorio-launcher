import hashlib,json,os,subprocess,sys,traceback,zipfile
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.safecrlf',GIT_CONFIG_VALUE_0='false')
sys.dont_write_bytecode=True;sys.path.insert(0,str(R));from tools import provider_canary_process as owned
BASE='9b53b5bfa1c84f29a44bbd878a73a2a7612e43e8';BRANCH='task/facman-darwin-existing-ini-01';Q='.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
out=E/'darwin-existing-ini-fixture-correction-commit-result-01.json';assert not out.exists()
record=dict(status='SEALING_REVIEWED_DARWIN_CANDIDATE_REQUIRED_MAC_RUNTIME_PENDING',commands=[],goal_status_mutated=False,new_optional_campaigns=0)
def save():out.write_text(json.dumps(record,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
def run(label,args,timeout=180):
    r=owned.command(args,cwd=R,environment=dict(os.environ),timeout=timeout,directory=E/('darwin-existing-ini-fixture-fixture-correction-commit01-'+label),output_limit=2*1024*1024)
    record['commands'].append(dict(label=label,exit=r.returncode,receipt_sha256=sha(r.directory/'receipt.json')));save()
    assert r.ok and r.receipt['primary_stopped'] and r.receipt['job_empty_observed'],(label,r.stderr[-1600:].decode(errors='replace'));return r
try:
    assert git('rev-parse','HEAD')==BASE and git('branch','--show-current')==BRANCH and not git('diff','--cached','--name-only')
    summary_path=E/'darwin-existing-ini-nonmac-qualification-03.json';assert sha(summary_path)=='5686c6ac54a95c48a12c7dc32e0b8114a2a9d73b6d7b7de3c581c094d2200ba0'
    a=json.loads(summary_path.read_bytes());assert a['status']=='PASS_SCOPED_DARWIN_OWNER_NON_MAC_QUALIFICATION' and a['base_head']==BASE
    for n,h in a['candidate_files_sha256'].items():assert sha(R/n)==h,n
    assurance_path=E/'darwin-existing-ini-nonmac-source-assurance-03.json';assert sha(assurance_path)==a['source_assurance_sha256']
    assurance=json.loads(assurance_path.read_bytes())
    for n,h in assurance['source_files_sha256'].items():assert sha(R/n)==h,n
    assert len(assurance['source_files_sha256'])==1947
    assert hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=R)).hexdigest()==a['staged_entries_sha256']
    assert len(a['proofs'])==4 and all(x['tokens_unchanged'] and x['scope']=='actual full translation-unit preprocessing' for x in a['proofs'])
    assert a['linux_runtime_tokens_unchanged'] and a['windows_runtime_tokens_unchanged'] and a['actual_linux_boundary_passed']==1
    assert not a['actual_macos_native_qualification'] and a['mandatory_mac_methods_pending']==14 and a['mac_static_validation']['mac_test_methods_executed']==0
    assert all(a['drain'][k] for k in ('namespace_empty','private_fixture_unmounted','private_native_bind_unmounted')) and a['source_binary_windows_cache_provider_hashes_preserved']
    review_source=E/'darwin-existing-ini-independent-source-review-04.json';review_data=json.loads(review_source.read_bytes());assert sha(review_source)=='7f787f85a9fd88aceee6290eb7a7f6344012c4f8575d1c05023911d80883693b' and review_data['frozen_packet_sha256']==a['frozen_packet_sha256']
    task_paths={'tests/test_macos_configuration_reconciliation.py'};assert set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())==task_paths
    archive=R/Q/'evidence/darwin-existing-ini-denial-fixture-custody.v1.zip';evidence=R/Q/'evidence/darwin-existing-ini-denial-fixture.v1.json';assert not archive.exists() and not evidence.exists()
    manifest={}
    for item in a['custody']:
        p=Path(item['path']);assert p.is_relative_to(E) and sha(p)==item['sha256'];manifest[p.relative_to(E).as_posix()]=item['sha256']
    for name in (summary_path.name,review_source.name,'darwin-existing-ini-frozen-04.json','darwin-existing-ini-frozen-04.patch','darwin-existing-ini-ci-root-diagnosis-02.json','darwin-existing-ini-ci-job-115150309851.json','darwin-existing-ini-ci-job-115150309851.log','darwin-existing-ini-checked-integration-result-02.json','darwin-existing-ini-fixture-correction-commit-01.py'):manifest[name]=sha(E/name)
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr('custody-manifest.json',json.dumps(manifest,indent=2,sort_keys=True)+'\n')
        for n in sorted(manifest):z.write(E/n,'evidence/'+n)
    with zipfile.ZipFile(archive) as z:
        for n,h in manifest.items():assert hashlib.sha256(z.read('evidence/'+n)).hexdigest()==h
    evidence.write_text(json.dumps(dict(schema='facman.darwin_existing_ini_denial_fixture_candidate.v1',original_failed_candidate=BASE,prior_source_mac_methods_passed=13,production_source_unchanged=True,fresh_native_tests=0,fresh_compiler_commands=0,original_mac_job=115150309851,root_diagnosis_sha256=sha(E/'darwin-existing-ini-ci-root-diagnosis-02.json'),fresh_full_tu_comparisons=0,unchanged_full_tu_comparisons_retained=4,base_head=BASE,files_sha256=a['candidate_files_sha256'],independent_review_sha256=sha(review_source),nonmac_qualification_sha256=sha(summary_path),actual_full_tu_proofs=[dict(platform=x['platform'],path=x['path'],token_sha256=x['token_sha256'],token_count=x['token_count']) for x in a['proofs']],actual_linux_boundary_passed=1,nonmac_images_unchanged=True,no_rebuild=True,actual_mac_methods_run=0,mandatory_mac_methods_pending=14,actual_mac_runtime_qualified=False,required_new_source_ci_pending=True,admission_merge_requires_actual_mac_pass=True,custody=archive.name,custody_sha256=sha(archive),custody_members=len(manifest)+1,authority_delta='Darwin confirmed existing-INI reconciliation and journal recovery candidate via existing owner guards',darwin_missing_file_publication_admitted=False,physical_apfs=False,power_loss=False,game=False,human=False,full_make_ready=False,beta=False,rc=False),indent=2)+'\n')
    with (R/Q/'ExecPlan.md').open('a',encoding='utf-8',newline='\n') as f:
        f.write('\n### Darwin denied-metadata fixture correction\n\nThe corrected admission campaign onsource9b53b5bf passed13of14actualMacowner methods and the native suite. The remaining readsecurity subcase failed in its oracle before backend execution: generic snapshot called stat on the deliberately denied inode. Only that method body changes. The exact target is excluded before status queries; all other owned fixture bytes and the durable journal are compared while the identical actual unprivileged metadata/xattr PermissionError probe runs before and after backend code3refusal. Originalbytes/inode/ownership/mode/birthtime/flags/xattrs and known prior ACLabsence are compared after test-owned ACL removal. Inaccessible ACL bytes during denial are not claimed observed, and cleanup failures preserve the primary failure. Runtime source,13otherMacmethods, providers and compiledimages are unchanged. All prior non-Mac compiler/Linuxtest proof is explicitly retained; no local native job or rebuild repeats. The failed source job and root diagnosis remain preserved; actualall14success at corrected source and every requiredcheck are mandatory beforeintegration. Broaderhost/game/human/MakeReady/Beta/RC clauses stay open.\n\nEvidence: `evidence/darwin-existing-ini-denial-fixture.v1.json` and hash-closed custody.\n')
    paths=task_paths|{Q+'/ExecPlan.md',Q+'/evidence/'+evidence.name,Q+'/evidence/'+archive.name};assert set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())==paths
    for label in ('policy','detect','plan'):run(label,['py','-3','-B','.aide/scripts/aide_lite.py','git',label])
    run('strict',['py','-3','-B','tools/strict_check.py'],1800)
    message='test(readiness): observe denied Mac metadata without stat\n\nPreserve real denial and refusal probes, comparing the protected inode\nonly after removing the test-owned ACL.\n\nWork-Item: FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01\nEvidence-Ref: '+Q+'/evidence/'+evidence.name+'\n'
    msg=E/'darwin-existing-ini-fixture-correction-commit-message-01.txt';msg.write_text(message,encoding='utf-8',newline='\n');run('message',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--message',message])
    changes=[dict(path=n,state='content',sha256=sha(R/n),git_blob_oid=git('hash-object','--path',n,str(R/n)),ownership='task_owned') for n in sorted(paths)]
    snapshot=hashlib.sha256((json.dumps(changes,indent=2,sort_keys=True,separators=(',',': '))+'\n').encode()).hexdigest()
    review=E/'darwin-existing-ini-fixture-correction-commit-review-01.json';review.write_text(json.dumps(dict(schema_version='aide.git-commit-review.v1',verdict='PASS',reviewer='/root',runtime_author='/root/darwin_existing_ini_implementation',non_authoring=True,branch=BRANCH,base_commit=BASE,snapshot_sha256=snapshot,message_sha256=sha(msg),independent_source_review_sha256=sha(review_source),nonmac_qualification_sha256=sha(summary_path),review='Only one denied-metadata oracle changes; production/provider/images and13otherMacmethods bytebound unchanged; repeated actualdenial required before/after refusal; observablemetadata compared afterownedACLcleanup; priornonMacproof reused; all14correctedsourceMacsuccess and requiredCI mandatory'),indent=2)+'\n')
    classification=E/'darwin-existing-ini-fixture-correction-commit-classification-01.json';classification.write_text(json.dumps(dict(schema_version='aide.git-commit-classification.v1',branch=BRANCH,base_commit=BASE,work_item='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01',snapshot_sha256=snapshot,message_sha256=sha(msg),changed_paths=changes,reviews=[dict(path=str(review),sha256=sha(review),verdict='PASS')]),indent=2)+'\n')
    helper=['py','-3','-B','.aide/scripts/aide_lite.py','git','commit-plan','--classification',str(classification),'--message-file',str(msg)]
    run('plan-stage',helper);run('stage',['git','add','--',*sorted(paths)]);run('diff',['git','diff','--cached','--check']);run('plan-commit',helper)
    assert git('rev-parse','HEAD')==BASE;run('commit',['git','commit','-F',str(msg)])
    run('range',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--range',BASE+'..HEAD']);assert not git('status','--porcelain')
    record.update(status='COMMITTED_REVIEWED_DARWIN_DENIAL_FIXTURE_CORRECTION',source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),review_sha256=sha(review),evidence_sha256=sha(evidence),actual_mac_runtime_qualified=False,remote_not_pushed=True)
except BaseException as exc:record.update(status='ACTIONABLE_DARWIN_CANDIDATE_COMMIT_FAILURE',error=str(exc),traceback=traceback.format_exc())
finally:save();print(json.dumps({k:v for k,v in record.items() if k!='commands'},indent=2))
raise SystemExit(0 if record['status']=='COMMITTED_REVIEWED_DARWIN_DENIAL_FIXTURE_CORRECTION' else 1)
