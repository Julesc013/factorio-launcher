import ast,hashlib,importlib,json,os,re,subprocess,sys
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent;S='9b53b5bfa1c84f29a44bbd878a73a2a7612e43e8';N='tests/test_macos_configuration_reconciliation.py'
sys.dont_write_bytecode=True;os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();git=lambda *args:subprocess.check_output(['git',*args],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==S and not git('diff','--cached','--name-only') and not git('ls-files','--others','--exclude-standard')
assert git('diff','--name-only').decode().splitlines()==[N]
prior_path=E/'darwin-existing-ini-nonmac-qualification-02.json';assert sha(prior_path)=='5991e30cd2809e452d35861beee22d2ce938afc9fa8949c4ed32e63bbdfff04a'
prior=json.loads(prior_path.read_bytes());old_assurance_path=E/'darwin-existing-ini-nonmac-source-assurance-02.json';assert sha(old_assurance_path)==prior['source_assurance_sha256'];guard=json.loads(old_assurance_path.read_bytes())
for n,h in guard['source_files_sha256'].items():
 if n!=N:assert sha(R/n)==h,n
for n,h in guard['preserved_windows_and_provider_files_sha256'].items():assert sha(n)==h,n
for n,h in prior['linux_config_sha256'].items():assert sha(n)==h,n
reuse=prior['linux_prior_qualification_reuse'];assert sha(W/'native-save-context-linux/facman')==reuse['cli_sha256']
for n,h in reuse['native_images_sha256'].items():assert sha(W/'native-save-context-linux'/n)==h,n
old=ast.parse(git('show',S+':'+N));new=ast.parse((R/N).read_text());name='test_unreadable_acl_and_xattrs_under_unprivileged_owner_are_preserved'
old_cls=next(x for x in old.body if isinstance(x,ast.ClassDef) and x.name=='MacOSExistingConfigurationTests');cls=next(x for x in new.body if isinstance(x,ast.ClassDef) and x.name=='MacOSExistingConfigurationTests')
old_method=next(x for x in old_cls.body if isinstance(x,ast.FunctionDef) and x.name==name);method=next(x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name==name)
old_cls.body.remove(old_method);cls.body.remove(method);assert ast.dump(old)==ast.dump(new),'outside-method AST changed';cls.body.append(method)
methods=sorted(x.name for x in cls.body if isinstance(x,ast.FunctionDef) and x.name.startswith('test_'));assert len(methods)==14
assert len([x for x in ast.walk(method) if isinstance(x,ast.Call) and isinstance(x.func,ast.Name) and x.func.id=='assert_permission_denied'])==2
sys.path[:0]=[str(R/'tests'),str(R)];m=importlib.import_module('test_macos_configuration_reconciliation');assert m.MacOSExistingConfigurationTests.__unittest_skip__
frozen_path=E/'darwin-existing-ini-frozen-04.json';frozen=json.loads(frozen_path.read_bytes());assert frozen['base_head']==S and sha(E/'darwin-existing-ini-frozen-04.patch')=='8205544c0db67ec5032c301b53203a412115385aca12f733fc1a3fe57c54bf56'
review_path=E/'darwin-existing-ini-independent-source-review-04.json';assert not review_path.exists()
review=dict(schema='facman.independent_darwin_existing_ini_fixture_review.v1',reviewer='/root',runtime_author='/root/darwin_existing_ini_implementation',non_authoring=True,base_head=S,frozen_packet_sha256=sha(frozen_path),verdict='PASS_FOR_REQUIRED_CORRECTED_MAC_CANDIDATE',findings=['Only the denial fixture body changes; all production/runtime, the other13Macmethods and externalprovider/images remain hashbound unchanged.','The exact target is excluded before is_file/stat; every other owned fixture byte and durable journal is compared during the denial.','The actual identical unprivileged readsecurity/readextattr probe must fail withPermissionError before and after backend code3refusal; no unsupported skip or opaque metadata equality is assumed.','Readable originalbytes/device/inode/mode/ownership/birthtime/flags/xattrs and prior ACLabsence are compared after test-owned denyACL cleanup. Inaccessible ACL bytes during denial are not claimed observed.','Cleanup propagates its failure; an existing primary failure is preserved with an additional cleanup note.','All14Macmethods remain required on the corrected source;13actual previous-source successes are evidence of progress, not corrected-source acceptance.'],actual_corrected_mac_methods_qualified=0)
review_path.write_text(json.dumps(review,indent=2)+'\n')
guard.update(base=S,staged_tree=git('write-tree').decode().strip(),staged_entries_sha256=hashlib.sha256(git('ls-files','--stage','-z')).hexdigest(),frozen_sha256=sha(frozen_path),root_diagnosis_sha256=sha(E/'darwin-existing-ini-ci-root-diagnosis-02.json'))
guard['source_files_sha256'][N]=sha(R/N);guard['frozen_files_sha256'][N]=sha(R/N)
assurance_path=E/'darwin-existing-ini-nonmac-source-assurance-03.json';assert not assurance_path.exists();assurance_path.write_text(json.dumps(guard,indent=2)+'\n')
a=dict(prior);a.update(base_head=S,frozen_packet_sha256=sha(frozen_path),source_assurance_sha256=sha(assurance_path),staged_entries_sha256=guard['staged_entries_sha256'],commands=[],fresh_compiler_proofs=0,retained_compiler_proofs=4,prior_nonmac_qualification_sha256=sha(prior_path),root_diagnosis_sha256=guard['root_diagnosis_sha256'],fresh_linux_boundary_tests=0,linux_boundary_pass_explicitly_retained=True,no_tests_or_builds_rerun=True,prior_source_actual_mac_passed=13,corrected_source_actual_mac_methods_run=0)
a['candidate_files_sha256']=dict(prior['candidate_files_sha256']);a['candidate_files_sha256'][N]=sha(R/N)
a['mac_static_validation'].update(imported_on_linux=False,imported_on_windows=True,mac_test_methods_executed=0,mac_skips_counted_as_acceptance=0)
a['custody']=[]
for p in (prior_path,old_assurance_path,assurance_path,frozen_path,E/'darwin-existing-ini-frozen-04.patch',review_path,E/'darwin-existing-ini-ci-root-diagnosis-02.json',E/'darwin-existing-ini-ci-job-115150309851.json',E/'darwin-existing-ini-ci-job-115150309851.log',Path(__file__)):
 a['custody'].append(dict(path=str(p),sha256=sha(p)))
assert git('rev-parse','HEAD').decode().strip()==S and git('diff','--name-only').decode().splitlines()==[N] and not git('diff','--cached','--name-only')
summary_path=E/'darwin-existing-ini-nonmac-qualification-03.json';assert not summary_path.exists();summary_path.write_text(json.dumps(a,indent=2)+'\n')
print(json.dumps({'status':a['status'],'summary_sha256':sha(summary_path),'review_sha256':sha(review_path),'all_runtime_source_and_images_unchanged':True,'fresh_native_tests':0,'actual_corrected_mac_methods_pending':14}))