"""Finish deterministic generation with independently admitted retained qualification."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,time,traceback
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent
F=E/'selected-save-source-freeze-08.json';V=E/'selected-save-source-review-08.json'
OUT=E/'selected-save-qualification-05.json';previous_path=E/'selected-save-qualification-04.json'
env=dict(os.environ,FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',FACMAN_TASK_ROOT=str(E.parent),
    TEMP=str(E.parent/'t'),TMP=str(E.parent/'t'),PYTHONOPTIMIZE='0',PYTHONPATH=os.pathsep.join([str(R/'tests'),str(R)]))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
freeze=read(F);previous=read(previous_path)
record={**previous,'status':'running','source_freeze_sha256':sha(F),'source_review_sha256':'',
    'compiled_source_freeze_sha256':previous['source_freeze_sha256'],
    'retained_qualified_campaign_sha256':sha(previous_path),
    'retained_failed_generated_step':[s for s in previous['steps'] if s['name']=='generated'],
    'steps':[s for s in previous['steps'] if s['name']!='generated'],
    'new_native_builds':0,'repeated_native_or_focused_or_historical_jobs':0}
record.pop('error',None);record.pop('traceback',None)
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).rstrip('\r\n')
def save():OUT.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
def frozen():
    assert git('rev-parse','HEAD')==freeze['base'] and git('branch','--show-current')==freeze['branch']
    assert not git('diff','--cached','--name-only')
    assert {r[3:] for r in git('status','--porcelain','--untracked-files=all').splitlines()}==set(freeze['changed_paths_raw_sha256'])
    assert {p:sha(R/p) for p in freeze['changed_paths_raw_sha256']}==freeze['changed_paths_raw_sha256']
    for value in previous['binaries'].values():assert sha(Path(value['path']))==value['sha256']
    legacy=read(E/'presentation-intent-legacy-frozen.json');workspace=Path(legacy['workspace'])
    assert sha(Path(legacy['receipt_path']))==legacy['receipt_sha256']
    assert {p.relative_to(workspace).as_posix():sha(p) for p in workspace.rglob('*') if p.is_file()}==legacy['workspace_inventory_sha256']
def step(name,args,timeout=600):
    frozen();log=E/('selected-save-q05-'+name+'.log');started=time.monotonic();print('START '+name,flush=True)
    with log.open('xb') as out:
        child=subprocess.run(args,cwd=R,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=timeout)
    record['steps'].append(dict(name=name,command=args,exit_code=child.returncode,seconds=round(time.monotonic()-started,3),log=str(log),log_sha256=sha(log)))
    save();print('DONE '+name+': '+str(child.returncode),flush=True)
    if child.returncode:
        print('\n'.join(log.read_text(errors='replace').splitlines()[-35:]),flush=True)
        raise RuntimeError(name+' failed; immutable full log retained')
    return log
assert __debug__ and not OUT.exists()
try:
    review=read(V)
    assert review['verdict']=='PASS' and review['independent'] and review['non_authoring']
    assert review['retain_previous_native_focused_and_historical_qualification'] is True
    assert review['freeze_sha256']==sha(F) and review['changed_paths_raw_sha256']==freeze['changed_paths_raw_sha256']
    record['source_review_sha256']=sha(V)
    assert previous['status']=='ACTIONABLE_FAILURE' and previous['tests']==dict(native_passed=3,focused_passed=46,skipped=0,new_methods=10)
    assert len(previous['historical_replays'])==3
    assert {s['name']:s['exit_code'] for s in previous['steps']}==dict(paths=0,doctor=1,strict=0,configure=0,build=0,native=0,focused=0,generated=1)
    for entry in previous['steps']:assert sha(Path(entry['log']))==entry['log_sha256']
    for replay in previous['historical_replays']:
        assert replay['workspace_unchanged']
        for stream in replay['streams'].values():assert sha(Path(stream['path']))==stream['sha256']
    compiled=read(E/'selected-save-source-freeze-07.json')
    assert sha(E/'selected-save-source-freeze-07.json')==previous['source_freeze_sha256']
    for p,value in compiled['changed_paths_raw_sha256'].items():
        if not p.endswith('/ExecPlan.md'):assert sha(R/p)==value
    old='de9292a34796820270758d55570467a65cb0172e2c561bb62afa6867eaea31ff';new='82f220f37c72e2736ce767538988bd5a2c7c60ae2d7cf2a2c45940c20f10f0cb'
    for p in ('runtime/core/generated/presentation_contracts.v1.h','apps/gui/windows/winforms/GeneratedPresentationContracts.cs',
            'tests/generated/presentation_contracts.py','docs/generated/contracts/presentation-foundation.md'):
        assert (R/p).read_text().replace(new,old)==subprocess.check_output(['git','show',freeze['base']+':'+p],cwd=R,text=True)
    frozen()
    with (E/'selected-save-qualification-05.claim.json').open('x') as out:json.dump(dict(pid=os.getpid(),review_sha256=sha(V),source_freeze_sha256=sha(F)),out)
    step('generated',['py','-3','tools/codegen/generate_contracts.py','--check'])
    log=step('contract_compiler',['py','-3','-B','-m','unittest','-v','test_contract_compiler'])
    text=log.read_text();match=re.search(r'Ran (\d+) tests in ',text);assert match and '\nOK\n' in text and 'skipped=' not in text
    record['tests']['contract_compiler_passed']=int(match.group(1))
    step('strict',['py','-3','tools/strict_check.py'])
    step('diff',['git','diff','--check'])
    frozen();record.update(status='PASS',retained_qualification_independently_admitted=True,
        resources={**previous['resources'],'free_after_bytes':shutil.disk_usage(E.parent).free})
    save();print(json.dumps(dict(status='PASS',tests=record['tests'],historical_replays=3,new_native_builds=0)),flush=True)
except Exception as error:
    record.update(status='ACTIONABLE_FAILURE',error=str(error),traceback=traceback.format_exc());save();print(traceback.format_exc(),flush=True);raise
