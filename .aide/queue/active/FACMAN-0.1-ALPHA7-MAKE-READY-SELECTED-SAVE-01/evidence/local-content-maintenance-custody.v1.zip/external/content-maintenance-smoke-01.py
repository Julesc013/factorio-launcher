from pathlib import Path
import hashlib,json,os,sys
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent;B=W/'native-developer/Release';sys.path.insert(0,str(R))
from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
build=json.loads((E/'content-maintenance-build-03.json').read_bytes());assert build['ok'] and sha(B/'facman.exe')==build['cli_sha256']
env=dict(os.environ,FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',TEMP=str(W/'t'),TMP=str(W/'t'))
rows=[]
for name in ('facman_tui_product_model_smoke','flb_factorio_instance_model_smoke'):
 exe=B/(name+'.exe');digest=sha(exe);cap=owned.command([str(exe)],cwd=R,environment=env,timeout=180,directory=E/('content-maintenance-'+name+'-01'),output_limit=4*1024**2,wait_for_job_empty_after_primary=True)
 row=dict(name=name,binary_sha256=digest,receipt=str(cap.directory/'receipt.json'),receipt_sha256=sha(cap.directory/'receipt.json'),ok=cap.ok,exit_code=cap.returncode,termination=cap.receipt['termination'],primary_stopped=cap.receipt['primary_stopped'],empty_job=cap.receipt['job_empty_observed'],safety_cleanup=cap.receipt['job_terminated']);rows.append(row)
 (E/'content-maintenance-smoke-01.json').write_text(json.dumps(dict(rows=rows),indent=2)+'\n',encoding='utf-8')
 assert cap.ok and cap.receipt['primary_stopped'] and cap.receipt['job_empty_observed'] and not cap.receipt['job_terminated'] and sha(exe)==digest,(row,cap.stdout.decode(errors='replace')[-4000:],cap.stderr.decode(errors='replace')[-1000:])
assert sha(B/'facman.exe')==build['cli_sha256']
print(json.dumps(dict(status='PASS_NORMAL_OWNED_NATIVE_SMOKES',checks=len(rows))))
