from pathlib import Path
import contextlib, hashlib, importlib.util, io, json, os, stat, subprocess, sys, tempfile, time, traceback, unittest
from unittest.mock import patch
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
sys.path[:0]=[str(R/'tests'),str(R)];sys.dont_write_bytecode=True
from tools import provider_canary_process as owned, development_layout
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
mode=sys.argv[1];attempt=sys.argv[2];assert mode in ('baseline','native') and attempt.isdecimal()
assert sha(W/development_layout.MARKER_NAME)=='30d72706c486ff20eed8b1947a920caa0a4e2d43820abbaf0ff78d12ab9f697c';development_layout.read_marker(W,R)
F=W/'t/j3'/('cm-'+mode+'-'+attempt);RAW=E/('content-maintenance-'+mode+'-raw-'+attempt)
OUT=E/('content-maintenance-'+mode+'-proof-'+attempt+'.json')
assert not any(p.exists() for p in (F,RAW,OUT))
for parent in (F.parent,RAW.parent):
 assert all(p.is_dir() and not p.is_symlink() and not getattr(p.lstat(),'st_file_attributes',0)&0x400 for p in (parent,*parent.parents))
admission=json.loads((E/'joined-content-package-extract-01.json').read_bytes());G=Path(admission['package_root'])
inventory=lambda root:{p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file()}
if mode=='baseline':assert inventory(G)==admission['file_inventory']
EXE=G/'bin/facman.exe' if mode=='baseline' else W/'native-developer/Release/facman.exe'
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',FACMAN_CLI_EXE=str(EXE),FACMAN_TUI_EXE=str(EXE))
import native_cli, test_presentation_content_maintenance as maintenance
spec=importlib.util.spec_from_file_location('cm_directory_observer',E/'joined-content-directory-observer-01.py');observer=importlib.util.module_from_spec(spec);spec.loader.exec_module(observer)
source_paths=['runtime/factorio/application/presentation_service.cpp','runtime/factorio/modsets/flb_factorio_modset_solver.cpp','runtime/factorio/modsets/flb_factorio_modset_solver.h','runtime/factorio/mods/flb_factorio_mods.cpp','runtime/factorio/mods/flb_factorio_mods.h','apps/tui/tui_product_shell.cpp','tests/test_presentation_content_maintenance.py','tests/test_presentation_service.py']
source={n:sha(R/n) for n in source_paths};exe_sha=sha(EXE)
F.mkdir();RAW.mkdir();(RAW/'cas').mkdir();C=F/'cwd';C.mkdir();marker=F/'.facman-content-maintenance-fixture.v1.json';marker.write_text(json.dumps(dict(owner='local-content-maintenance',mode=mode,attempt=attempt)),encoding='utf-8');marker_sha=sha(marker)
result=dict(schema='facman.local_content_maintenance_observation.v1',status='RUNNING',mode=mode,attempt=attempt,source_files=source,backend=str(EXE),backend_sha256=exe_sha,original_package_source=admission['source'] if mode=='baseline' else None,calls=[],new_downloads=0,new_task_roots=0,real_game=False,human=False,fixture=str(F),raw=str(RAW))
start=time.monotonic();deadline=start+900
def raw_size():
 files=[p for p in RAW.rglob('*') if p.is_file()];assert len(files)<=12000
 return sum(p.stat().st_size for p in files)
def save():
 data=(json.dumps(result,indent=2)+'\n').encode();assert len(data)<=8*1024**2 and raw_size()+len(data)<=128*1024**2;OUT.write_bytes(data)
def capture():
 rows={};total=0
 for p in F.rglob('*'):
  st=p.lstat();assert not p.is_symlink() and not getattr(st,'st_file_attributes',0)&0x400
  if not stat.S_ISREG(st.st_mode):continue
  assert st.st_size<=16*1024**2 and len(rows)<4096;total+=st.st_size;assert total<=64*1024**2
  data=p.read_bytes();assert len(data)==st.st_size;digest=hashlib.sha256(data).hexdigest();target=RAW/'cas'/digest
  if not target.exists():assert raw_size()+len(data)+16*1024**2<=128*1024**2;target.write_bytes(data)
  else:assert sha(target)==digest
  rows[p.relative_to(F).as_posix()]=dict(bytes=len(data),sha256=digest,native_file_identity=maintenance.joined.file_identity(p))
 return rows
def product_run(args,**kwargs):
 assert str(args[0])==str(EXE) and sha(EXE)==exe_sha and sha(marker)==marker_sha
 assert time.monotonic()<deadline and len(result['calls'])<200 and raw_size()+16*1024**2<=128*1024**2
 supplied=kwargs.get('env')
 assert supplied is None or not any(k.startswith(('FACMAN_TEST_','FACMAN_MODSET_FAULT')) for k in supplied)
 env={k:v for k,v in os.environ.items() if not k.startswith(('FACMAN_','FLAUNCH_','ULK_','USK_','LD_','DYLD_'))}
 env.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',PATH='',TEMP=str(F),TMP=str(F))
 data=kwargs.get('input');input_bytes=data.encode('utf-8') if isinstance(data,str) else (b'' if data is None else data)
 before=capture();directory=RAW/f'call-{len(result["calls"]):03d}'
 cap=owned.command(list(args),cwd=C,environment=env,input_bytes=input_bytes,directory=directory,timeout=min(float(kwargs.get('timeout') or 45),45,deadline-time.monotonic()),output_limit=4*1024**2,wait_for_job_empty_after_primary=True)
 assert len(cap.stdout)+len(cap.stderr)<=4*1024**2
 row=dict(argv=list(args),requested_cwd=str(kwargs.get('cwd')),cwd=str(C),stdin_sha256=hashlib.sha256(input_bytes).hexdigest(),receipt=str(directory/'receipt.json'),receipt_sha256=sha(directory/'receipt.json'),exit_code=cap.returncode,before=before,after=capture());result['calls'].append(row);save()
 assert cap.receipt['termination']=='completed' and cap.receipt['primary_stopped'] and cap.receipt['job_empty_observed'] and not cap.receipt['job_terminated'],directory
 return subprocess.CompletedProcess(list(args),cap.returncode,cap.stdout.decode('utf-8').replace('\r\n','\n'),cap.stderr.decode('utf-8').replace('\r\n','\n'))
class RetainedDirectory:
 count=0
 def __init__(self,*args,**kwargs):
  assert not args and kwargs.get('prefix','').startswith('content-maintenance-') and len(kwargs)==1
  type(self).count+=1;assert type(self).count<=12;self.path=F/f'case-{type(self).count:02d}';self.path.mkdir();self.name=str(self.path)
 def __enter__(self):return self.name
 def __exit__(self,*args):return False
 def cleanup(self):raise AssertionError('Retained fixture must not be removed')
try:
 save();methods=['test_exact_version_preview_apply_replay_history_rollback_preserves_original'] if mode=='baseline' else sorted(n for n in dir(maintenance.ContentMaintenanceTests) if n.startswith('test_'))
 suite=unittest.TestSuite(maintenance.ContentMaintenanceTests(n) for n in methods);stream=io.StringIO()
 with patch.object(subprocess,'run',product_run),patch.object(tempfile,'TemporaryDirectory',RetainedDirectory):
  outcome=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
 result.update(methods=methods,tests_run=outcome.testsRun,failures=[dict(test=str(t),traceback=x) for t,x in outcome.failures],errors=[dict(test=str(t),traceback=x) for t,x in outcome.errors],skips=outcome.skipped,unittest_output=stream.getvalue())
 if mode=='baseline':
  assert outcome.testsRun==1 and not outcome.errors and len(outcome.failures)==1 and "'simple@1.0.0' not found" in outcome.failures[0][1],stream.getvalue()
  result['status']='OBSERVED_ORIGINAL_PACKAGE_MISSING_EXACT_VERSION_SELECTION'
 else:
  assert outcome.wasSuccessful() and not outcome.skipped,stream.getvalue();result['status']='PASS_SOURCE_BOUND_NORMAL_OWNED_MAINTENANCE'
except BaseException:
 result.update(status='FAIL_RETAINED',error=traceback.format_exc());raise
finally:
 try:
  result['final_files']=capture();result['final_directories']=observer.collect(F)
  assert sha(marker)==marker_sha and sha(EXE)==exe_sha and all(sha(R/n)==h for n,h in source.items())
  if mode=='baseline':assert inventory(G)==admission['file_inventory']
  assert sha(W/development_layout.MARKER_NAME)=='30d72706c486ff20eed8b1947a920caa0a4e2d43820abbaf0ff78d12ab9f697c'
  result['elapsed_seconds']=time.monotonic()-start;assert result['elapsed_seconds']<=900;save()
 except BaseException:
  result.update(status='FAIL_RETAINED_FINAL_GUARD',final_guard_error=traceback.format_exc())
  try:save()
  except BaseException:OUT.write_text(json.dumps(dict(status='FAIL_RETAINED_BUDGET',raw=str(RAW),fixture=str(F))),encoding='utf-8')
  raise
 print(json.dumps(dict(status=result['status'],calls=len(result['calls']),proof=str(OUT))))
