from pathlib import Path
import hashlib,json,os,sys
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent;B=W/'native-developer';sys.path.insert(0,str(R))
from tools import native_build,provider_canary_process as owned,development_layout
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source_paths=['runtime/factorio/application/presentation_service.cpp','runtime/factorio/modsets/flb_factorio_modset_solver.cpp','runtime/factorio/modsets/flb_factorio_modset_solver.h','runtime/factorio/mods/flb_factorio_mods.cpp','runtime/factorio/mods/flb_factorio_mods.h','apps/tui/tui_product_shell.cpp','tests/test_presentation_content_maintenance.py','tests/test_presentation_service.py']
source={n:sha(R/n) for n in source_paths};script_sha=sha(__file__)
assert sha(W/development_layout.MARKER_NAME)=='30d72706c486ff20eed8b1947a920caa0a4e2d43820abbaf0ff78d12ab9f697c';development_layout.read_marker(W,R)
env=dict(os.environ,FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
measurement=owned.command([sys.executable,str(E/'content-activation-resource-observer-02.py')],cwd=R,environment=env,timeout=900,directory=E/'content-maintenance-build-doctor-01',output_limit=4*1024**2,wait_for_job_empty_after_primary=True)
assert measurement.returncode in (0,1) and measurement.receipt['termination']=='completed' and measurement.receipt['primary_stopped'] and measurement.receipt['job_empty_observed'] and not measurement.receipt['job_terminated']
h=json.loads(measurement.stdout);assert h['violations']==['unmanaged_secondary_worktrees_present'] and len(h['task_roots'])<=8 and h['task_root_bytes']+4*1024**3<=20*1024**3
ps="[pscustomobject]@{AvailablePhysicalBytes=([long](Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory*1024);FreeDiskBytes=(Get-PSDrive D).Free;Toolchains=@(Get-Process -Name cl,link,MSBuild,ninja,cmake,dotnet,VBCSCompiler -ErrorAction SilentlyContinue | Select-Object Id,ProcessName,WorkingSet64)} | ConvertTo-Json -Depth 4"
resources=owned.command(['powershell','-NoProfile','-Command',ps],cwd=R,environment=env,timeout=120,directory=E/'content-maintenance-build-resources-01',output_limit=1024**2,wait_for_job_empty_after_primary=True)
assert resources.ok and resources.receipt['primary_stopped'] and resources.receipt['job_empty_observed'] and not resources.receipt['job_terminated']
r=json.loads(resources.stdout.decode('utf-8-sig'));assert not r['Toolchains'] and r['AvailablePhysicalBytes']>=3*1024**3 and r['FreeDiskBytes']-4*1024**3>=12*1024**3
env.update(CMAKE_BUILD_PARALLEL_LEVEL='2',TEMP=str(W/'t'),TMP=str(W/'t'),MSBUILDDISABLENODEREUSE='1',FACMAN_MIN_FREE_GIB='12');os.environ.update(env)
native_build.require_disk_reserve(B);command=native_build.command(B,'Release',['facman_cli','flb_factorio_instance_model_smoke','facman_tui_product_model_smoke'],{})
assert '--clean-first' in command and '/p:TrackFileAccess=false' in command and command[command.index('--parallel')+1]=='2'
cap=owned.command(command,cwd=R,environment=env,timeout=900,directory=E/'content-maintenance-build-owned-01',output_limit=8*1024**2,wait_for_job_empty_after_primary=False)
result=dict(command=command,ok=cap.ok,receipt=str(cap.directory/'receipt.json'),exit_code=cap.returncode,termination=cap.receipt['termination'],primary_stopped=cap.receipt['primary_stopped'],job_empty=cap.receipt['job_empty_observed'],job_terminated=cap.receipt['job_terminated'],compiler_natural_descendant_lifetime_qualified=False,marker_unchanged=sha(W/development_layout.MARKER_NAME)=='30d72706c486ff20eed8b1947a920caa0a4e2d43820abbaf0ff78d12ab9f697c',cli_sha256=sha(B/'Release/facman.exe') if (B/'Release/facman.exe').is_file() else None)
result.update(source_files=source,source_unchanged=all(sha(R/n)==h for n,h in source.items()),script_sha256=script_sha,script_unchanged=sha(__file__)==script_sha)
result['ok']=bool(result['ok'] and result['marker_unchanged'] and result['source_unchanged'] and result['script_unchanged'])
(E/'content-maintenance-build-01.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result))
if not cap.ok:print(cap.stdout.decode('utf-8',errors='replace')[-8000:]);print(cap.stderr.decode('utf-8',errors='replace')[-2000:])
sys.exit(0 if result['ok'] else 1)
