from pathlib import Path
import hashlib,json,os,sys
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;sys.path.insert(0,str(R))
from tools import provider_canary_process as owned
env=dict(os.environ,FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
rows=[]
for label,args in [('metadata',['tools/codegen/generate_metadata.py','--check']),('strict',['tools/strict_check.py']),('aide',['.aide/scripts/aide_lite.py','test'])]:
 cap=owned.command([sys.executable,*args],cwd=R,environment=env,timeout=300,directory=E/('content-maintenance-static-'+label+'-04'),output_limit=4*1024**2,wait_for_job_empty_after_primary=True)
 rows.append(dict(label=label,command=cap.command if hasattr(cap,'command') else [sys.executable,*args],receipt=str(cap.directory/'receipt.json'),receipt_sha256=hashlib.sha256((cap.directory/'receipt.json').read_bytes()).hexdigest(),ok=cap.ok,exit_code=cap.returncode,termination=cap.receipt['termination'],primary_stopped=cap.receipt['primary_stopped'],empty_job=cap.receipt['job_empty_observed'],safety_cleanup=cap.receipt['job_terminated']))
 (E/'content-maintenance-static-04.json').write_text(json.dumps(dict(rows=rows),indent=2)+'\n',encoding='utf-8')
 if not(cap.ok and cap.receipt['termination']=='completed' and cap.receipt['primary_stopped'] and cap.receipt['job_empty_observed'] and not cap.receipt['job_terminated']):
  print(cap.stdout.decode(errors='replace')[-8000:]);print(cap.stderr.decode(errors='replace')[-2000:]);sys.exit(1)
print(json.dumps(dict(status='PASS_NORMAL_OWNED_STATIC_CHECKS',checks=len(rows))))
