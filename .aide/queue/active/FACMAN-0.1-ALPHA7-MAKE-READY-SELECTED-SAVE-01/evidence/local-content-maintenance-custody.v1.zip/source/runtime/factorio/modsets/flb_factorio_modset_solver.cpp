// SPDX-FileCopyrightText: 2026 Jules C
// SPDX-License-Identifier: MIT

#include "flb_factorio_modset_solver.h"

#include "fl_file_io.h"
#include "fl_json.h"
#include "fl_path_safety.h"
#include "fl_sha256.h"
#include "fl_transaction.h"
#include "fl_workspace_store.h"
#include "flb_factorio_modsets.h"
#include "flb_factorio_content_records.h"
#include "flb_factorio_modset_operations.h"

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cstdlib>
#include <map>
#include <set>
#include <system_error>
#include <thread>
#include <utility>

namespace facman::factorio::modsets::solver {
namespace fs = std::filesystem;
namespace json = facman::core::json;
namespace tx = facman::transaction;
namespace {

constexpr std::uint64_t kMaximumStateFileBytes = 16U * 1024U * 1024U;

struct Instance {
    facman::workspace::InstanceRecord record;
    fs::path local_lock;
    fs::path shared_lock;
    fs::path mod_list;
};

struct CurrentEntry {
    std::string version;
    bool enabled = true;
};

struct ResolvedPlan {
    Instance instance;
    std::vector<facman::factorio::mods::ModRef> inventory;
    std::map<std::string, const facman::factorio::mods::ModRef*> selected;
    std::map<std::string, CurrentEntry> current;
    std::vector<std::string> explanation;
    std::string current_state_sha256;
    std::string plan_id;
    std::string transaction_id;
    std::uint32_t states = 0;
    std::uint32_t backtracks = 0;
    std::uint32_t edges = 0;
    std::string locked_plan;
    std::string preserved_lock;
    std::string operation_id;
    std::string attempt_id;
    std::function<facman::core::Result<std::string>()> protected_inputs;
};

template<typename T>
facman::core::Result<T> failure(
    const std::string& code,
    const std::string& message,
    const fs::path& path = {},
    facman::core::OutcomeKind kind = facman::core::OutcomeKind::refused)
{
    facman::core::Error error {code, message, facman::platform::path_to_utf8(path), kind};
    error.recoverable = kind != facman::core::OutcomeKind::recovery_required;
    error.retryable = error.recoverable;
    return facman::core::Result<T>::failure(std::move(error));
}

std::string sha256_text(const std::string& text)
{
    facman::base::Sha256Hasher hash;
    hash.update(reinterpret_cast<const unsigned char*>(text.data()), text.size());
    return hash.finish();
}

facman::core::Result<std::string> stable_text(const fs::path& path, bool allow_missing = false)
{
    std::error_code error;
    if (allow_missing && !fs::exists(path, error) && !error) {
        return facman::core::Result<std::string>::success({});
    }
    facman::platform::StableInputFile input;
    auto status = input.open_no_follow(path);
    if (!status.ok()) return failure<std::string>("modset_state_read_failed", status.detail, path);
    if (!input.identity().regular_file || input.identity().link_count != 1U || input.size() > kMaximumStateFileBytes) {
        return failure<std::string>("modset_state_read_failed", "State is not a bounded singly-linked regular file", path);
    }
    std::string text(static_cast<std::size_t>(input.size()), '\0');
    std::uint64_t offset = 0;
    while (offset < input.size()) {
        const std::size_t count = input.read_at(
            offset, text.data() + offset, text.size() - static_cast<std::size_t>(offset));
        if (count == 0) return failure<std::string>("modset_state_read_failed", "Stable read ended before EOF", path);
        offset += count;
    }
    status = input.revalidate();
    if (!status.ok()) return failure<std::string>("modset_external_drift", status.detail, path);
    return facman::core::Result<std::string>::success(std::move(text));
}

facman::core::Result<Instance> load_instance(const fs::path& workspace, const std::string& id)
{
    auto parsed = facman::core::InstanceId::parse(id);
    if (!parsed) return failure<Instance>("unknown_instance", "Instance identifier is invalid");
    facman::workspace::WorkspaceLayout layout(workspace);
    auto record = facman::workspace::InstanceRepository(layout).load(parsed.value());
    if (!record) return failure<Instance>("unknown_instance", "Instance is not registered");
    auto local = layout.instance_modset_lock(parsed.value());
    auto shared = facman::workspace::ModsetRepository(layout).canonical_lock(parsed.value());
    if (!local || !shared) return failure<Instance>("modset_path_invalid", "Modset state paths could not be resolved");
    Instance instance;
    instance.record = record.take_value();
    instance.local_lock = local.take_value();
    instance.shared_lock = shared.take_value();
    instance.mod_list = instance.record.root / "mods" / "mod-list.json";
    return facman::core::Result<Instance>::success(std::move(instance));
}

std::string field_string(const json::Value& object, const char* key)
{
    const json::Value* field = object.find(key);
    if (field == nullptr) return {};
    auto value = field->string_value();
    return value ? value.take_value() : std::string {};
}

std::map<std::string, CurrentEntry> current_lock(const std::string& text)
{
    std::map<std::string, CurrentEntry> output;
    if (text.empty()) return output;
    json::Limits limits;
    limits.maximum_bytes = kMaximumStateFileBytes;
    limits.maximum_depth = 32;
    limits.maximum_nodes = 100000;
    auto document = json::parse(text, limits);
    if (!document || !document.value().is_object()) return {};
    const json::Value* mods = document.value().find("mods");
    if (mods == nullptr || !mods->is_array()) return {};
    for (std::size_t index = 0; index < mods->size(); ++index) {
        const json::Value* item = mods->at(index);
        if (item == nullptr || !item->is_object()) return {};
        const std::string name = field_string(*item, "name");
        const std::string version = field_string(*item, "version");
        if (name.empty()) return {};
        CurrentEntry entry;
        entry.version = version;
        const json::Value* enabled = item->find("enabled");
        if (enabled != nullptr) {
            auto value = enabled->bool_value();
            if (!value) return {};
            entry.enabled = value.value();
        }
        output[name] = entry;
    }
    return output;
}

facman::core::Result<std::map<std::string, bool>> activation_entries(
    const std::string& text, bool exact_fields = false)
{
    using Entries = std::map<std::string, bool>;
    json::Limits limits;
    limits.maximum_bytes = kMaximumStateFileBytes;
    limits.maximum_depth = 24U;
    limits.maximum_nodes = 100000U;
    auto document = json::parse(text, limits);
    const auto* mods = document ? document.value().find("mods") : nullptr;
    if (!document || !document.value().is_object() || !mods || !mods->is_array())
        return failure<Entries>("modset_activation_invalid", "Mod list must contain a mods array");
    if (exact_fields && document.value().object_keys() != std::vector<std::string>{"mods"})
        return failure<Entries>("modset_activation_foreign", "Preserve unrecognized mod-list fields for explicit content repair");
    Entries entries;
    for (std::size_t index = 0; index < mods->size(); ++index) {
        const auto* item = mods->at(index);
        const auto name = item ? field_string(*item, "name") : std::string();
        const auto* flag = item ? item->find("enabled") : nullptr;
        auto active = flag ? flag->bool_value() : facman::core::Result<bool>::success(false);
        std::string detail;
        auto keys = item && item->is_object() ? item->object_keys() : std::vector<std::string>{};
        std::sort(keys.begin(), keys.end());
        if (!item || !item->is_object() || !facman::base::validate_identifier(name, detail) ||
            !flag || !active || !entries.emplace(name, active.value()).second)
            return failure<Entries>("modset_activation_invalid", "Mod list entries require unique names and boolean enabled flags");
        if (exact_fields && keys != std::vector<std::string>{"enabled", "name"})
            return failure<Entries>("modset_activation_foreign", "Preserve unrecognized mod-list fields for explicit content repair");
    }
    return facman::core::Result<Entries>::success(std::move(entries));
}

std::string state_fingerprint(
    const std::string& mod_list,
    const std::string& local_lock,
    const std::string& shared_lock)
{
    return sha256_text("mod-list\n" + mod_list + "\nlocal-lock\n" + local_lock +
        "\nshared-lock\n" + shared_lock);
}

bool contains(const std::vector<std::string>& values, const std::string& value)
{
    return std::find(values.begin(), values.end(), value) != values.end();
}

struct Engine {
    Engine(
        const Request& request_value,
        const std::string& factorio_version_value,
        const std::map<std::string, CurrentEntry>& current_value)
        : request(request_value), factorio_version(factorio_version_value), current(current_value)
    {
    }

    const Request& request;
    const std::string& factorio_version;
    const std::map<std::string, CurrentEntry>& current;
    std::map<std::string, std::vector<const facman::factorio::mods::ModRef*>> candidates;
    std::map<std::string, std::string> preferences;
    std::set<std::string> disabled;
    std::map<std::string, const facman::factorio::mods::ModRef*> selected;
    std::vector<std::string> explanation;
    std::string failure_detail;
    std::uint32_t states = 0;
    std::uint32_t backtracks = 0;
    std::uint32_t edges = 0;
    std::chrono::steady_clock::time_point started = std::chrono::steady_clock::now();

    bool budget()
    {
        const auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now() - started).count();
        if (states > request.budgets.maximum_solver_states ||
            backtracks > request.budgets.maximum_backtracks ||
            edges > request.budgets.maximum_graph_edges ||
            explanation.size() > request.budgets.maximum_explanation_nodes ||
            elapsed > request.budgets.maximum_elapsed_ms) {
            failure_detail = "The deterministic solver exhausted a configured resource budget";
            return false;
        }
        return true;
    }

    bool compatible_with_selected(const facman::factorio::mods::ModRef& candidate) const
    {
        auto conflicts = [&](const facman::factorio::mods::ModRef& source, const std::string& target, const std::string& version) {
            return std::any_of(source.incompatibilities.begin(), source.incompatibilities.end(),
                [&](const auto& dependency) {
                    return dependency.name == target && version_constraint_satisfied(
                        version, dependency.oper, dependency.version);
                });
        };
        for (const auto& item : selected) {
            if (item.first == candidate.name) continue;
            if (std::any_of(candidate.incompatibilities.begin(), candidate.incompatibilities.end(),
                    [&](const auto& dependency) {
                        return dependency.name == item.first && version_constraint_satisfied(
                            item.second->version, dependency.oper, dependency.version);
                    }) || conflicts(*item.second, candidate.name, candidate.version)) return false;
        }
        return true;
    }

    bool resolve(const std::string& name, const std::string& oper, const std::string& version, const std::string& parent)
    {
        ++states;
        if (!budget()) return false;
        if (disabled.count(name) != 0) {
            failure_detail = parent + " requires disabled package " + name;
            return false;
        }
        auto chosen = selected.find(name);
        if (chosen != selected.end()) {
            if (version_constraint_satisfied(chosen->second->version, oper, version)) return true;
            failure_detail = name + " " + chosen->second->version + " violates " + oper + " " + version;
            return false;
        }
        if (name == "base" && candidates.count(name) == 0) {
            if (!version_constraint_satisfied(factorio_version, oper, version)) {
                failure_detail = "Factorio " + factorio_version + " does not satisfy base " + oper + " " + version;
                return false;
            }
            explanation.push_back("base is satisfied by the registered instance Factorio version " + factorio_version);
            return budget();
        }
        auto available = candidates.find(name);
        if (available == candidates.end() || available->second.empty()) {
            failure_detail = "No compatible local artifact is available for " + name;
            return false;
        }
        for (const auto* candidate : available->second) {
            if (!version_constraint_satisfied(candidate->version, oper, version) || !compatible_with_selected(*candidate)) continue;
            const auto selected_before = selected;
            const std::size_t explanation_before = explanation.size();
            selected[name] = candidate;
            explanation.push_back(name + "@" + candidate->version + " selected from " + candidate->file_name +
                (parent.empty() ? " by request or current state" : " because required by " + parent));
            bool valid = budget();
            for (const auto& dependency : candidate->dependencies) {
                ++edges;
                if (valid) valid = resolve(dependency.name, dependency.oper, dependency.version, candidate->name);
            }
            auto optional_valid = [&](const std::vector<facman::factorio::mods::DependencyRef>& dependencies) {
                for (const auto& dependency : dependencies) {
                    ++edges;
                    auto present = selected.find(dependency.name);
                    if (present != selected.end() && !version_constraint_satisfied(
                            present->second->version, dependency.oper, dependency.version)) return false;
                }
                return true;
            };
            valid = valid && optional_valid(candidate->optional_dependencies) &&
                optional_valid(candidate->hidden_optional_dependencies) && compatible_with_selected(*candidate) && budget();
            if (valid) return true;
            selected = selected_before;
            explanation.resize(explanation_before);
            ++backtracks;
            if (!budget()) return false;
        }
        if (failure_detail.empty()) failure_detail = "No compatible local version satisfies the dependency set for " + name;
        return false;
    }
};

facman::core::Result<std::map<std::string, std::string>> preferences(const Request& request)
{
    std::map<std::string, std::string> output;
    for (const std::string& value : request.version_preferences) {
        const std::size_t equals = value.find('=');
        if (equals == std::string::npos || equals == 0 || equals + 1 >= value.size()) {
            return failure<std::map<std::string, std::string>>(
                "modset_version_preference_invalid", "Version preferences must use name=version");
        }
        const std::string name = value.substr(0, equals);
        const std::string version = value.substr(equals + 1);
        if (!output.emplace(name, version).second) return failure<std::map<std::string, std::string>>(
            "modset_version_preference_invalid", "A package has more than one version preference");
    }
    return facman::core::Result<std::map<std::string, std::string>>::success(std::move(output));
}

facman::core::Result<ResolvedPlan> resolve_plan(const fs::path& workspace, const Request& request)
{
    if (request.instance_id.empty()) return failure<ResolvedPlan>("unknown_instance", "Instance is required");
    if (request.budgets.maximum_packages == 0 || request.budgets.maximum_versions_per_package == 0 ||
        request.budgets.maximum_graph_edges == 0 || request.budgets.maximum_solver_states == 0 ||
        request.budgets.maximum_backtracks == 0 || request.budgets.maximum_elapsed_ms == 0 ||
        request.budgets.maximum_explanation_nodes == 0) {
        return failure<ResolvedPlan>("solver_budget_exceeded", "Solver budgets must be positive");
    }
    auto instance = load_instance(workspace, request.instance_id);
    if (!instance) return failure<ResolvedPlan>(instance.error().code, instance.error().message);
    auto local_text = stable_text(instance.value().local_lock, true);
    auto shared_text = stable_text(instance.value().shared_lock, true);
    auto mod_list_text = stable_text(instance.value().mod_list, true);
    if (!local_text || !shared_text || !mod_list_text) {
        const auto& error = !local_text ? local_text.error() : !shared_text ? shared_text.error() : mod_list_text.error();
        return failure<ResolvedPlan>(error.code, error.message, fs::u8path(error.path));
    }
    if (!local_text.value().empty() && !shared_text.value().empty() && local_text.value() != shared_text.value()) {
        return failure<ResolvedPlan>("modset_external_drift", "Instance and shared modset locks disagree");
    }
    const std::string& lock_text = !local_text.value().empty() ? local_text.value() : shared_text.value();
    const auto current = current_lock(lock_text);
    if (!lock_text.empty() && current.empty()) {
        auto document = json::parse(lock_text);
        const json::Value* mods = document && document.value().is_object() ? document.value().find("mods") : nullptr;
        if (mods == nullptr || !mods->is_array() || mods->size() != 0U) return failure<ResolvedPlan>(
            "modset_external_drift", "Current lock cannot be parsed as trusted local state");
    }
    auto inventory = facman::factorio::mods::local_inventory(workspace, {},
        request.exact_selection.name.empty() ? std::string() : request.instance_id);
    if (!inventory) return failure<ResolvedPlan>(inventory.error().code, inventory.error().message, fs::u8path(inventory.error().path));
    auto preferred = preferences(request);
    if (!preferred) return failure<ResolvedPlan>(preferred.error().code, preferred.error().message);
    Engine engine(request, instance.value().record.factorio_version, current);
    engine.preferences = preferred.take_value();
    engine.disabled.insert(request.disabled_mods.begin(), request.disabled_mods.end());
    for (const std::string& enabled : request.enabled_mods) if (engine.disabled.count(enabled) != 0) {
        return failure<ResolvedPlan>("modset_request_conflict", "A package cannot be both enabled and disabled");
    }
    const std::string install_source = "install-data:" + instance.value().record.install_ref.str();
    std::vector<facman::factorio::mods::ModRef> filtered;
    for (const auto& mod : inventory.value()) {
        const bool admitted = mod.virtual_package ? mod.source == install_source : contains(mod.instance_references, request.instance_id);
        const auto& exact = request.exact_selection;
        if (!exact.name.empty() && mod.name == exact.name &&
            (mod.virtual_package || mod.version != exact.version ||
                mod.file_name != exact.file_name || mod.source != exact.source ||
                mod.sha256 != exact.sha256 ||
                mod.file_path != instance.value().record.root / "mods" / exact.file_name)) continue;
        if (admitted && mod.valid && factorio_versions_compatible(mod.factorio_version, instance.value().record.factorio_version)) {
            filtered.push_back(mod);
        }
    }
    for (const auto& mod : filtered) engine.candidates[mod.name].push_back(&mod);
    if (!request.exact_selection.name.empty() && engine.candidates.count(request.exact_selection.name) == 0) {
        return failure<ResolvedPlan>("modset_exact_selection_unavailable", "The confirmed selected-instance artifact is unavailable");
    }
    if (engine.candidates.size() > request.budgets.maximum_packages) {
        return failure<ResolvedPlan>("solver_budget_exceeded", "Local package count exceeds maximum_packages");
    }
    for (auto& group : engine.candidates) {
        if (group.second.size() > request.budgets.maximum_versions_per_package) {
            return failure<ResolvedPlan>("solver_budget_exceeded", group.first + " exceeds maximum_versions_per_package");
        }
        std::sort(group.second.begin(), group.second.end(), [&](const auto* left, const auto* right) {
            const auto locked = current.find(group.first);
            const bool left_locked = locked != current.end() && left->version == locked->second.version;
            const bool right_locked = locked != current.end() && right->version == locked->second.version;
            if (left_locked != right_locked) return left_locked;
            const auto preference = engine.preferences.find(group.first);
            const bool left_preferred = preference != engine.preferences.end() && left->version == preference->second;
            const bool right_preferred = preference != engine.preferences.end() && right->version == preference->second;
            if (left_preferred != right_preferred) return left_preferred;
            const int version_order = compare_versions(left->version, right->version);
            if (version_order != 0) return version_order > 0;
            return left->file_name < right->file_name;
        });
    }
    std::set<std::string> seeds(request.enabled_mods.begin(), request.enabled_mods.end());
    if (!request.exact_selection.name.empty()) {
        // Version maintenance retains the other declared enabled packages.
        // Its exact artifact is a hard constraint; dependency failure refuses.
        seeds.insert(request.exact_selection.name);
        for (const auto& entry : current) if (entry.second.enabled) seeds.insert(entry.first);
    }
    if (seeds.empty()) for (const auto& entry : current) if (entry.second.enabled) seeds.insert(entry.first);
    if (seeds.empty()) for (const auto& mod : filtered) if (!mod.virtual_package) seeds.insert(mod.name);
    for (const std::string& seed : seeds) if (engine.disabled.count(seed) == 0 && !engine.resolve(seed, {}, {}, {})) {
        const std::string code = engine.failure_detail.find("budget") != std::string::npos
            ? "solver_budget_exceeded" : "local_dependency_unavailable";
        return failure<ResolvedPlan>(code, engine.failure_detail);
    }
    if (!request.exact_selection.name.empty() && engine.selected.count(request.exact_selection.name) == 0) {
        return failure<ResolvedPlan>("modset_exact_selection_unavailable", "The confirmed artifact was not selected");
    }
    ResolvedPlan output;
    output.instance = instance.take_value();
    output.inventory = std::move(filtered);
    for (const auto& selected : engine.selected) {
        const auto found = std::find_if(output.inventory.begin(), output.inventory.end(), [&](const auto& mod) {
            return mod.name == selected.second->name && mod.version == selected.second->version &&
                mod.file_name == selected.second->file_name && mod.sha256 == selected.second->sha256;
        });
        if (found != output.inventory.end()) output.selected[selected.first] = &*found;
    }
    output.current = current;
    output.explanation = std::move(engine.explanation);
    output.current_state_sha256 = state_fingerprint(
        mod_list_text.value(), local_text.value(), shared_text.value());
    output.states = engine.states;
    output.backtracks = engine.backtracks;
    output.edges = engine.edges;
    return facman::core::Result<ResolvedPlan>::success(std::move(output));
}

json::ObjectBuilder selected_entry(const facman::factorio::mods::ModRef& mod)
{
    json::ObjectBuilder entry;
    entry.add_string("name", mod.name);
    entry.add_string("version", mod.version);
    entry.add_string("file_name", mod.file_name);
    entry.add_string("sha1", mod.sha1);
    entry.add_string("sha256", mod.sha256);
    entry.add_bool("enabled", true);
    entry.add_bool("virtual_package", mod.virtual_package);
    entry.add_string("source", mod.source);
    return entry;
}

std::string plan_core_json(const ResolvedPlan& plan)
{
    json::ArrayBuilder desired;
    for (const auto& item : plan.selected) desired.add_object(selected_entry(*item.second));
    json::ObjectBuilder core;
    core.add_string("instance_id", plan.instance.record.id.str());
    core.add_string("factorio_version", plan.instance.record.factorio_version);
    core.add_string("current_state_sha256", plan.current_state_sha256);
    core.add_array("desired_mods", desired);
    return core.serialize();
}

std::string serialize_plan(ResolvedPlan& plan, const std::string& command, bool applied = false)
{
    if (plan.plan_id.empty()) plan.plan_id = sha256_text(plan_core_json(plan));
    json::ArrayBuilder desired;
    for (const auto& item : plan.selected) desired.add_object(selected_entry(*item.second));
    json::ArrayBuilder changes;
    for (const auto& current : plan.current) {
        auto desired_entry = plan.selected.find(current.first);
        if (desired_entry == plan.selected.end()) {
            json::ObjectBuilder change;
            change.add_string("action", "disable"); change.add_string("name", current.first);
            change.add_string("from_version", current.second.version); change.add_null("to_version"); changes.add_object(change);
        } else if (current.second.version != desired_entry->second->version) {
            json::ObjectBuilder change;
            change.add_string("action", "change_version"); change.add_string("name", current.first);
            change.add_string("from_version", current.second.version); change.add_string("to_version", desired_entry->second->version);
            changes.add_object(change);
        }
    }
    for (const auto& desired_entry : plan.selected) if (plan.current.count(desired_entry.first) == 0) {
        json::ObjectBuilder change;
        change.add_string("action", "enable"); change.add_string("name", desired_entry.first);
        change.add_null("from_version"); change.add_string("to_version", desired_entry.second->version); changes.add_object(change);
    }
    json::ArrayBuilder explanation;
    for (const std::string& node : plan.explanation) explanation.add_string(node);
    json::ObjectBuilder usage;
    (void)usage.add_unsigned_integer("solver_states", plan.states);
    (void)usage.add_unsigned_integer("backtracks", plan.backtracks);
    (void)usage.add_unsigned_integer("graph_edges", plan.edges);
    (void)usage.add_unsigned_integer("explanation_nodes", plan.explanation.size());
    json::ObjectBuilder output;
    output.add_string("schema", applied ? "factorio.modset_apply.v1" : "factorio.modset_plan.v1");
    output.add_string("command", command);
    output.add_string("status", applied ? "applied" : "ok");
    output.add_string("instance_id", plan.instance.record.id.str());
    output.add_string("factorio_version", plan.instance.record.factorio_version);
    output.add_string("plan_id", plan.plan_id);
    if (applied) output.add_string("transaction_id", plan.transaction_id);
    output.add_string("current_state_sha256", plan.current_state_sha256);
    output.add_array("desired_mods", desired);
    output.add_array("changes", changes);
    output.add_array("explanation", explanation);
    output.add_object("budget_usage", usage);
    output.add_bool("local_artifacts_only", true);
    output.add_bool("portal_access", false);
    output.add_bool("mutation_executed", applied);
    return output.serialize();
}

facman::core::Result<std::string> read_plan(const fs::path& workspace, const Request& request, const char* command)
{
    auto resolved = resolve_plan(workspace, request);
    if (!resolved) return failure<std::string>(resolved.error().code, resolved.error().message, fs::u8path(resolved.error().path));
    ResolvedPlan value = resolved.take_value();
    return facman::core::Result<std::string>::success(serialize_plan(value, command));
}

std::string mod_list_json(const ResolvedPlan& plan)
{
    json::ArrayBuilder mods;
    std::set<std::string> names;
    names.insert("base");
    for (const auto& item : plan.selected) names.insert(item.first);
    for (const std::string& name : names) {
        json::ObjectBuilder entry;
        entry.add_string("name", name);
        entry.add_bool("enabled", true);
        mods.add_object(entry);
    }
    json::ObjectBuilder output;
    output.add_array("mods", mods);
    return output.serialize() + "\n";
}

std::string lock_json(const ResolvedPlan& plan)
{
    json::ArrayBuilder mods;
    for (const auto& item : plan.selected) {
        auto value = json::parse(facman::factorio::mods::mod_ref_json(*item.second));
        if (value) mods.add_value(value.value());
    }
    json::ObjectBuilder output;
    (void)output.add_unsigned_integer("lockfile_version", 1);
    output.add_string("schema", "factorio.modset_lock.v1");
    output.add_string("instance_id", plan.instance.record.id.str());
    output.add_string("factorio_version", plan.instance.record.factorio_version);
    output.add_array("mods", mods);
    return output.serialize() + "\n";
}

struct StateFile {
    std::string key;
    fs::path target;
    std::string before;
    std::string after;
    bool before_present = false;
};

facman::core::Result<StateFile> state_file(
    const std::string& key,
    const fs::path& target,
    std::string after)
{
    StateFile file;
    file.key = key;
    file.target = target;
    file.after = std::move(after);
    std::error_code error;
    file.before_present = fs::exists(target, error) && !error;
    if (error) return failure<StateFile>("modset_state_read_failed", error.message(), target);
    if (file.before_present) {
        auto text = stable_text(target);
        if (!text) return failure<StateFile>(text.error().code, text.error().message, target);
        file.before = text.take_value();
    }
    return facman::core::Result<StateFile>::success(std::move(file));
}

std::string history_manifest(const ResolvedPlan& plan, const std::vector<StateFile>& files)
{
    json::ArrayBuilder entries;
    for (const StateFile& file : files) {
        json::ObjectBuilder entry;
        entry.add_string("key", file.key);
        entry.add_string("target", facman::platform::path_to_utf8(file.target));
        entry.add_bool("before_present", file.before_present);
        entry.add_string("before_sha256", file.before_present ? sha256_text(file.before) : "");
        entry.add_string("after_sha256", sha256_text(file.after));
        entries.add_object(entry);
    }
    json::ObjectBuilder output;
    output.add_string("schema", "factorio.modset_activation_history.v1");
    output.add_string("transaction_id", plan.transaction_id);
    output.add_string("plan_id", plan.plan_id);
    output.add_string("instance_id", plan.instance.record.id.str());
    output.add_string("current_state_sha256", plan.current_state_sha256);
    output.add_array("files", entries);
    output.add_bool("rolled_back", false);
    return output.serialize() + "\n";
}

bool write_new(const fs::path& path, const std::string& text, std::string& detail)
{
    std::error_code error;
    fs::create_directories(path.parent_path(), error);
    return !error && facman::base::write_text_new_atomic(path, text, detail);
}

bool pause_before_apply_publication(const fs::path& stage, std::string& detail)
{
    const char* enabled = std::getenv("FACMAN_TEST_MODSET_APPLY_BEFORE_PUBLICATION_PAUSE");
    if (enabled == nullptr || std::string(enabled) != "1") return true;
    const fs::path marker = stage / ".facman-modset-apply-paused";
    const fs::path release = stage / ".facman-modset-apply-release";
    if (!write_new(marker, "ready\n", detail)) return false;
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(10);
    std::error_code error;
    while (!fs::exists(release, error) && !error && std::chrono::steady_clock::now() < deadline) {
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
    const bool released = fs::exists(release, error) && !error;
    if (!released) detail = "Modset apply publication test pause timed out";
    return released;
}

void clean_stage(const fs::path& stage)
{
    std::error_code error;
    for (const char* name : {"mod-list.json", "local-lock.json", "shared-lock.json"}) {
        fs::remove(stage / name, error);
        error.clear();
    }
    fs::remove(stage, error);
}

bool replace_from_text(const fs::path& target, const std::string& text, const fs::path& scratch, std::string& detail)
{
    std::error_code error;
    fs::create_directories(target.parent_path(), error);
    if (error) { detail = error.message(); return false; }
    if (fs::exists(target, error)) {
        fs::remove(target, error);
        if (error) { detail = error.message(); return false; }
    }
    if (!facman::base::write_text_new_atomic(scratch, text, detail)) return false;
    fs::rename(scratch, target, error);
    if (error) { detail = error.message(); return false; }
    return true;
}

bool restore_files(
    const std::vector<StateFile>& files,
    const fs::path& history,
    const std::string& suffix,
    std::string& detail,
    std::size_t stop_after = static_cast<std::size_t>(-1))
{
    std::size_t restored = 0;
    for (const StateFile& file : files) {
        std::error_code error;
        if (fs::exists(file.target, error)) {
            const fs::path displaced = history / (file.key + suffix);
            if (!fs::exists(displaced, error)) {
                auto current = stable_text(file.target);
                if (!current || !write_new(displaced, current.value(), detail)) return false;
            }
            fs::remove(file.target, error);
            if (error) { detail = error.message(); return false; }
        }
        if (file.before_present && !replace_from_text(
                file.target, file.before, history / (file.key + ".restore.tmp"), detail)) return false;
        if (++restored == stop_after) { detail = "fault injection after first rollback restore"; return false; }
    }
    return true;
}

bool restore_applied_files(const std::vector<StateFile>& files, const fs::path& history, std::string& detail)
{
    for (const StateFile& file : files) if (!replace_from_text(
            file.target, file.after, history / (file.key + ".reapply.tmp"), detail)) return false;
    return true;
}

bool restored_files_match(const std::vector<StateFile>& files)
{
    for (const StateFile& file : files) {
        auto current = state_file(file.key, file.target, "");
        if (!current || current.value().before_present != file.before_present ||
            current.value().before != file.before) return false;
    }
    return true;
}

bool verify_apply_staging(
    const tx::Record& transaction, const ResolvedPlan& plan,
    const std::vector<StateFile>& files, const fs::path& stage,
    const fs::path& history, std::string& detail)
{
    for (const fs::path& root : {stage, history}) {
        if (facman::base::path_crosses_link_or_reparse_point(root, detail) ||
            !tx::verify_staging_ownership(transaction, root, detail)) return false;
        std::map<std::string, std::string> expected;
        if (root == stage) {
            expected = {{"mod-list.json", files[0].after}, {"local-lock.json", files[1].after},
                {"shared-lock.json", files[2].after}};
            const char* pause = std::getenv("FACMAN_TEST_MODSET_APPLY_BEFORE_PUBLICATION_PAUSE");
            if (pause != nullptr && std::string(pause) == "1") {
                expected.emplace(".facman-modset-apply-paused", "ready\n");
                std::error_code error;
                if (fs::exists(stage / ".facman-modset-apply-release", error)) {
                    expected.emplace(".facman-modset-apply-release", "");
                }
                if (error) { detail = error.message(); return false; }
            }
        } else {
            expected.emplace("activation.v1.json", history_manifest(plan, files));
            for (const StateFile& file : files) if (file.before_present) {
                expected.emplace(file.key + ".before", file.before);
            }
        }
        std::error_code error;
        fs::directory_iterator iterator(root, error);
        if (error) { detail = error.message(); return false; }
        std::size_t observed = 0;
        for (; iterator != fs::directory_iterator(); iterator.increment(error)) {
            if (error) { detail = error.message(); return false; }
            const fs::path path = iterator->path();
            const std::string name = path.filename().string();
            if (facman::base::path_crosses_link_or_reparse_point(path, detail)) return false;
            if (name == tx::transaction_staging_marker_name()) continue;
            const auto found = expected.find(name);
            if (found == expected.end()) { detail = "Unexpected content in owned activation staging"; return false; }
            const auto text = stable_text(path);
            if (!text || text.value() != found->second) { detail = "Activation staging or backup bytes changed"; return false; }
            ++observed;
        }
        if (error || observed != expected.size()) { detail = "Activation staging is incomplete"; return false; }
    }
    return true;
}

facman::core::Result<std::string> activation_id(
    const fs::path& workspace, const ResolvedPlan& plan, const std::vector<StateFile>& files, const fs::path& mods_root)
{
    // Keep the original plan-id alias for first attempts. Retained attempts are
    // immutable; a retry receives a separate rollback identity only after the
    // complete original state and its backups have been verified.
    auto workspace_record = facman::workspace::WorkspaceRepository(facman::workspace::WorkspaceLayout(workspace)).load();
    if (!workspace_record) return failure<std::string>("workspace_state_invalid", workspace_record.error().message, workspace);
    for (unsigned attempt = 0; attempt < 100; ++attempt) {
        const std::string id = attempt == 0 ? plan.plan_id :
            sha256_text(plan.plan_id + ":attempt:" + std::to_string(attempt));
        const fs::path history = mods_root / ".facman-modset-history" / id;
        const fs::path stage = mods_root / (".facman-modset-stage-" + id);
        std::string detail;
        if (facman::base::path_crosses_link_or_reparse_point(history, detail) ||
            facman::base::path_crosses_link_or_reparse_point(stage, detail)) {
            return failure<std::string>("modset_path_unsafe", detail, history);
        }
        std::error_code error;
        const bool exists = fs::exists(history, error);
        if (error) return failure<std::string>("persistent_write_refused", error.message(), history);
        if (!exists) {
            if (fs::exists(stage, error) || error) return failure<std::string>(
                "transaction_recovery_required", "Unbound activation staging requires recovery", stage,
                facman::core::OutcomeKind::recovery_required);
            return facman::core::Result<std::string>::success(id);
        }
        auto text = stable_text(history / "activation.v1.json");
        auto document = text ? json::parse(text.value()) : json::parse("");
        if (!document || !document.value().is_object() ||
            field_string(document.value(), "schema") != "factorio.modset_activation_history.v1" ||
            field_string(document.value(), "transaction_id") != id ||
            field_string(document.value(), "instance_id") != plan.instance.record.id.str() ||
            field_string(document.value(), "current_state_sha256") != plan.current_state_sha256) {
            return failure<std::string>("modset_history_invalid", "Retained activation identity does not match", history);
        }
        if (document.value().find("plan_id") != nullptr && field_string(document.value(), "plan_id") != plan.plan_id) {
            return failure<std::string>("modset_history_invalid", "Retained activation plan identity does not match", history);
        }
        const json::Value* entries = document.value().find("files");
        if (entries == nullptr || !entries->is_array() || entries->size() != files.size()) return failure<std::string>(
            "modset_history_invalid", "Retained activation file set is incomplete", history);
        for (std::size_t index = 0; index < files.size(); ++index) {
            const StateFile& file = files[index];
            const json::Value* entry = entries->at(index);
            const json::Value* present = entry == nullptr ? nullptr : entry->find("before_present");
            if (entry == nullptr || !entry->is_object() || present == nullptr || !present->bool_value() ||
                present->bool_value().value() != file.before_present || field_string(*entry, "key") != file.key ||
                facman::platform::path_from_utf8(field_string(*entry, "target")).lexically_normal() != file.target.lexically_normal() ||
                field_string(*entry, "before_sha256") != (file.before_present ? sha256_text(file.before) : "") ||
                field_string(*entry, "after_sha256") != sha256_text(file.after)) {
                return failure<std::string>("modset_history_invalid", "Retained activation state does not match restored targets", history);
            }
            if (file.before_present) {
                auto backup = stable_text(history / (file.key + ".before"));
                if (!backup || backup.value() != file.before) return failure<std::string>(
                    "modset_history_invalid", "Retained activation backup does not match restored state", history);
            }
        }
        // Old apply failures may have a recovery-required journal despite
        // restoring all targets. Keep that journal and marker-only stage intact;
        // they may be reused as proof only when bound to this exact activation.
        auto marker_text = stable_text(history / tx::transaction_staging_marker_name());
        auto marker = marker_text ? json::parse(marker_text.value()) : json::parse("");
        tx::Record record;
        if (!marker || !marker.value().is_object() || !tx::read_record(workspace,
                field_string(marker.value(), "transaction_id"), record, detail) ||
            record.command_id != "modsets.apply" || record.target.lexically_normal() != plan.instance.mod_list.lexically_normal() ||
            record.workspace_id != workspace_record.value().id.str() ||
            record.staging_roots != std::vector<fs::path>{stage, history} ||
            !tx::verify_staging_ownership(record, history, detail) ||
            !tx::verify_staging_ownership(record, stage, detail)) {
            return failure<std::string>("modset_history_invalid", "Retained activation journal ownership does not match", history);
        }
        if (record.state != tx::State::refused && record.state != tx::State::complete &&
            record.state != tx::State::rolled_back && record.state != tx::State::recovery_required) {
            return failure<std::string>("transaction_recovery_required", "Retained activation is not an inactive restored attempt", history,
                facman::core::OutcomeKind::recovery_required);
        }
        fs::directory_iterator iterator(stage, error);
        if (error) return failure<std::string>("modset_history_invalid", error.message(), stage);
        std::size_t children = 0;
        for (; iterator != fs::directory_iterator(); iterator.increment(error)) {
            if (error || iterator->path().filename() != tx::transaction_staging_marker_name() || ++children != 1U) {
                return failure<std::string>("transaction_recovery_required", "Retained staging still contains uncommitted content", stage,
                    facman::core::OutcomeKind::recovery_required);
            }
        }
        if (error || children != 1U) return failure<std::string>(
            "modset_history_invalid", "Retained staging marker is incomplete", stage);
    }
    return failure<std::string>("persistent_target_exists", "Activation attempt limit reached", mods_root);
}

struct LockedObservation {
    bool present = false;
    std::string text;
    std::string identity = "absent";
};

facman::core::Result<LockedObservation> observe_locked_file(const fs::path& path, bool missing = false)
{
    std::string detail;
    if (facman::base::path_crosses_link_or_reparse_point(path, detail))
        return failure<LockedObservation>("modset_path_unsafe", detail, path);
    facman::platform::PathIdentity status;
    if (!facman::platform::inspect_path_no_follow(path, status).ok())
        return failure<LockedObservation>("modset_state_read_failed", "State path cannot be observed", path);
    if (!status.exists && missing) return facman::core::Result<LockedObservation>::success({});
    facman::platform::StableInputFile input;
    if (!input.open_no_follow_pinned(path).ok() || !input.identity().regular_file ||
        input.identity().link_count != 1U || input.size() > kMaximumStateFileBytes)
        return failure<LockedObservation>("modset_state_read_failed", "State is not a bounded singly-linked regular file", path);
    LockedObservation observed;
    observed.present = true;
    observed.text.resize(static_cast<std::size_t>(input.size()));
    std::uint64_t offset = 0;
    while (offset < input.size()) {
        const auto count = input.read_at(offset, observed.text.data() + offset,
            observed.text.size() - static_cast<std::size_t>(offset));
        if (count == 0U) return failure<LockedObservation>("modset_state_read_failed", "State read ended before EOF", path);
        offset += count;
    }
    if (!input.revalidate_path().ok() || facman::base::path_crosses_link_or_reparse_point(path, detail))
        return failure<LockedObservation>("modset_external_drift", "State changed during observation", path);
    observed.identity = "file:" + std::to_string(input.identity().device) + ":" +
        std::to_string(input.identity().object) + ":" + std::to_string(input.size()) + ":" + sha256_text(observed.text);
    return facman::core::Result<LockedObservation>::success(std::move(observed));
}

facman::core::Result<std::string> locked_parent_identity(const fs::path& path)
{
    facman::platform::StableDirectoryObject parent;
    std::string detail;
    if (facman::base::path_crosses_link_or_reparse_point(path, detail) || !parent.open_no_follow(path).ok() ||
        !parent.revalidate().ok() || facman::base::path_crosses_link_or_reparse_point(path, detail))
        return failure<std::string>("modset_path_unsafe", "Content parent is unavailable or unsafe", path);
    return facman::core::Result<std::string>::success(tx::directory_effect_identity(parent));
}

facman::core::Result<ResolvedPlan> locked_activation(const fs::path& workspace, const std::string& id)
{
    auto loaded = load_instance(workspace, id);
    if (!loaded) return facman::core::Result<ResolvedPlan>::failure(loaded.error());
    ResolvedPlan plan;
    plan.instance = loaded.take_value();
    auto root = locked_parent_identity(plan.instance.record.root);
    if (!root) return facman::core::Result<ResolvedPlan>::failure(root.error());
    const std::vector<fs::path> targets {plan.instance.mod_list, plan.instance.local_lock, plan.instance.shared_lock};
    const std::vector<std::string> keys {"mod-list", "local-lock", "shared-lock"};
    std::vector<LockedObservation> before;
    json::ObjectBuilder target_inputs;
    for (std::size_t index = 0; index < targets.size(); ++index) {
        auto observed = observe_locked_file(targets[index], index == 0U);
        auto parent = locked_parent_identity(targets[index].parent_path());
        if (!observed) return facman::core::Result<ResolvedPlan>::failure(observed.error());
        if (!parent) return facman::core::Result<ResolvedPlan>::failure(parent.error());
        json::ObjectBuilder entry;
        entry.add_string("path", facman::platform::path_to_utf8(targets[index]));
        entry.add_string("identity", observed.value().identity);
        entry.add_string("parent_identity", parent.value());
        entry.add_bool("present", observed.value().present);
        entry.add_string("sha256", observed.value().present ? sha256_text(observed.value().text) : "");
        target_inputs.add_object(keys[index], entry);
        before.push_back(observed.take_value());
    }
    if (before[1].text.empty() || before[1].text != before[2].text)
        return failure<ResolvedPlan>("modset_external_drift", "Exact instance and shared locks must agree");
    auto lock = facman::factorio::content::content_lock_from_modset_lock_json(before[1].text);
    if (!lock || lock.value().instance_id != id || lock.value().factorio_version != plan.instance.record.factorio_version)
        return failure<ResolvedPlan>("modset_lock_invalid", "Content lock does not describe the current instance");
    if (lock.value().entries.size() > Budgets{}.maximum_packages)
        return failure<ResolvedPlan>("solver_budget_exceeded", "Pinned package count exceeds the existing local content budget");
    const auto verified = facman::factorio::modsets::operations::verify_modset(workspace, {id});
    const auto* report = std::get_if<facman::factorio::modsets::operations::VerifyResult>(&verified);
    if (!report || !report->problems.empty())
        return failure<ResolvedPlan>("modset_locked_artifacts_unavailable", "The exact locked archives and metadata must verify before activation");
    auto inventory = facman::factorio::mods::local_inventory(workspace);
    if (!inventory) return facman::core::Result<ResolvedPlan>::failure(inventory.error());
    plan.inventory.reserve(lock.value().entries.size());
    std::set<std::string> expected {"base"};
    json::ArrayBuilder artifacts;
    for (const auto& entry : lock.value().entries) {
        if (!entry.enabled) continue;
        expected.insert(entry.name);
        const auto selected = std::find_if(inventory.value().begin(), inventory.value().end(), [&](const auto& mod) {
            return mod.valid && mod.name == entry.name && mod.version == entry.version &&
                mod.file_name == entry.file_name && mod.sha256 == entry.sha256 && mod.source == entry.source &&
                mod.virtual_package == entry.virtual_package &&
                (mod.virtual_package ? mod.source == "install-data:" + plan.instance.record.install_ref.str() &&
                    mod.metadata_source == "builtin_info_json" && mod.validation_status == "virtual" :
                    contains(mod.instance_references, id));
        });
        if (entry.virtual_package && selected == inventory.value().end())
            return failure<ResolvedPlan>("modset_locked_artifacts_unavailable", "A pinned local artifact or built-in provenance is unavailable");
        auto pinned = entry.virtual_package ? *selected : facman::factorio::mods::inspect_mod_zip(
            plan.instance.record.root / "mods" / fs::u8path(entry.file_name));
        if (!pinned.valid || pinned.name != entry.name || pinned.version != entry.version ||
            pinned.file_name != entry.file_name || pinned.sha256 != entry.sha256 ||
            pinned.source != entry.source || pinned.virtual_package != entry.virtual_package)
            return failure<ResolvedPlan>("modset_locked_artifacts_unavailable", "The instance's exact pinned artifact is unavailable");
        plan.inventory.push_back(std::move(pinned));
        const auto& owned = plan.inventory.back();
        plan.selected[entry.name] = &owned;
        const auto path = owned.virtual_package ? owned.file_path / "info.json" : owned.file_path;
        auto observed = observe_locked_file(path);
        if (!observed) return facman::core::Result<ResolvedPlan>::failure(observed.error());
        if (!owned.virtual_package && sha256_text(observed.value().text) != entry.sha256)
            return failure<ResolvedPlan>("modset_archive_changed", "A pinned archive changed during observation", path);
        json::ObjectBuilder artifact;
        artifact.add_string("path", facman::platform::path_to_utf8(path));
        artifact.add_string("identity", observed.value().identity);
        artifacts.add_object(artifact);
    }
    if (before[0].present) {
        auto entries = activation_entries(before[0].text, true);
        if (!entries) return facman::core::Result<ResolvedPlan>::failure(entries.error());
        std::set<std::string> enabled;
        for (const auto& entry : entries.value()) {
            if (!expected.count(entry.first))
                return failure<ResolvedPlan>("modset_activation_foreign", "Preserve unselected mod-list entries for explicit content repair");
            if (entry.second) enabled.insert(entry.first);
        }
        if (enabled == expected) return failure<ResolvedPlan>("modset_activation_already_current", "Locked activation is already current");
    }
    auto record = observe_locked_file(plan.instance.record.source_path);
    if (!record) return facman::core::Result<ResolvedPlan>::failure(record.error());
    plan.current = current_lock(before[1].text);
    plan.current_state_sha256 = state_fingerprint(before[0].text, before[1].text, before[2].text);
    plan.preserved_lock = before[1].text;
    plan.explanation.push_back("Activate only the exact already verified local lock; do not resolve a new selection");
    plan.plan_id = sha256_text(plan_core_json(plan));
    json::ArrayBuilder desired;
    for (const auto& selected : plan.selected) desired.add_object(selected_entry(*selected.second));
    json::ObjectBuilder output;
    output.add_string("schema", "factorio.locked_content_activation_plan.v1");
    output.add_string("instance_id", id);
    output.add_string("instance_identity", record.value().identity);
    output.add_string("root_identity", root.value());
    output.add_string("lock_sha256", sha256_text(plan.preserved_lock));
    output.add_string("mod_list_sha256", sha256_text(mod_list_json(plan)));
    output.add_string("owner_plan_id", plan.plan_id);
    output.add_array("desired_mods", desired);
    output.add_object("before_targets", target_inputs);
    output.add_array("artifact_inputs", artifacts);
    for (std::size_t index = 0; index < targets.size(); ++index) {
        auto observed = observe_locked_file(targets[index], index == 0U);
        if (!observed || observed.value().identity != before[index].identity)
            return failure<ResolvedPlan>("modset_external_drift", "Content inputs changed during activation planning");
    }
    auto after_record = observe_locked_file(plan.instance.record.source_path);
    auto after_instance = load_instance(workspace, id);
    if (!after_record || after_record.value().identity != record.value().identity || !after_instance ||
        after_instance.value().record.root != plan.instance.record.root ||
        after_instance.value().record.install_ref.str() != plan.instance.record.install_ref.str() ||
        after_instance.value().record.factorio_version != plan.instance.record.factorio_version ||
        after_instance.value().record.profile != plan.instance.record.profile)
        return failure<ResolvedPlan>("modset_external_drift", "Instance changed during activation planning");
    const auto reverified = facman::factorio::modsets::operations::verify_modset(workspace, {id});
    const auto* current_report = std::get_if<facman::factorio::modsets::operations::VerifyResult>(&reverified);
    auto artifact_document = json::parse(artifacts.serialize());
    if (!current_report || !current_report->problems.empty() || !artifact_document)
        return failure<ResolvedPlan>("modset_external_drift", "Locked metadata changed during activation planning");
    for (std::size_t index = 0; index < artifact_document.value().size(); ++index) {
        const auto* artifact = artifact_document.value().at(index);
        auto observed = observe_locked_file(facman::platform::path_from_utf8(field_string(*artifact, "path")));
        if (!observed || observed.value().identity != field_string(*artifact, "identity"))
            return failure<ResolvedPlan>("modset_external_drift", "Pinned artifact changed during activation planning");
    }
    for (std::size_t index = 0; index < targets.size(); ++index) {
        auto observed = observe_locked_file(targets[index], index == 0U);
        if (!observed || observed.value().identity != before[index].identity)
            return failure<ResolvedPlan>("modset_external_drift", "Content state changed during final activation observation");
    }
    auto final_record = observe_locked_file(plan.instance.record.source_path);
    auto final_root = locked_parent_identity(plan.instance.record.root);
    if (!final_record || final_record.value().identity != record.value().identity || !final_root || final_root.value() != root.value())
        return failure<ResolvedPlan>("modset_external_drift", "Instance changed during final activation observation");
    auto body = json::parse(output.serialize());
    auto canonical = body ? json::canonical_integer_json(body.value()) : json::canonical_integer_json(json::Value{});
    if (!canonical) return failure<ResolvedPlan>("modset_locked_plan_invalid", "Locked activation plan cannot be canonicalized");
    output.add_string("plan_sha256", sha256_text(canonical.value()));
    plan.locked_plan = output.serialize();
    return facman::core::Result<ResolvedPlan>::success(std::move(plan));
}

facman::core::Result<std::string> locked_commit_context(const ResolvedPlan& plan,
    const std::vector<StateFile>& files, const fs::path& stage, const fs::path& history)
{
    auto admitted = json::parse(plan.locked_plan);
    const auto* before = admitted ? admitted.value().find("before_targets") : nullptr;
    const auto* artifacts = admitted ? admitted.value().find("artifact_inputs") : nullptr;
    auto instance = observe_locked_file(plan.instance.record.source_path);
    auto root = locked_parent_identity(plan.instance.record.root);
    if (!before || !before->is_object() || !artifacts || !artifacts->is_array() || !instance ||
        instance.value().identity != field_string(admitted.value(), "instance_identity") || !root ||
        root.value() != field_string(admitted.value(), "root_identity"))
        return failure<std::string>("modset_external_drift", "Locked activation admission changed");
    for (std::size_t index = 0; index < artifacts->size(); ++index) {
        const auto* artifact = artifacts->at(index);
        if (!artifact || !artifact->is_object()) return failure<std::string>("modset_locked_plan_invalid", "Pinned input binding is invalid");
        auto current = observe_locked_file(facman::platform::path_from_utf8(field_string(*artifact, "path")));
        if (!current || current.value().identity != field_string(*artifact, "identity"))
            return failure<std::string>("modset_archive_changed", "A pinned content input changed before publication");
    }
    json::ArrayBuilder effects;
    for (std::size_t index = 0; index < files.size(); ++index) {
        const auto& file = files[index];
        const auto* original = before->find(file.key);
        auto current = observe_locked_file(file.target, !file.before_present);
        auto parent = locked_parent_identity(file.target.parent_path());
        const auto staged_path = stage / (index == 0U ? "mod-list.json" : index == 1U ? "local-lock.json" : "shared-lock.json");
        auto staged = observe_locked_file(staged_path);
        if (!original || !current || !parent || !staged || current.value().identity != field_string(*original, "identity") ||
            parent.value() != field_string(*original, "parent_identity") || staged.value().text != file.after)
            return failure<std::string>("modset_external_drift", "Exact content targets, parents or staged bytes changed");
        json::ObjectBuilder effect;
        effect.add_string("key", file.key);
        effect.add_string("target", facman::platform::path_to_utf8(file.target));
        effect.add_string("parent_identity", parent.value());
        effect.add_string("identity", staged.value().identity);
        effect.add_string("sha256", sha256_text(file.after));
        if (file.before_present) {
            auto backup = observe_locked_file(history / (file.key + ".before"));
            if (!backup || backup.value().text != file.before)
                return failure<std::string>("modset_history_invalid", "An exact retained backup changed");
            effect.add_string("backup_identity", backup.value().identity);
        } else effect.add_string("backup_identity", "absent");
        effects.add_object(effect);
    }
    auto manifest = observe_locked_file(history / "activation.v1.json");
    if (!manifest) return facman::core::Result<std::string>::failure(manifest.error());
    auto stage_identity = locked_parent_identity(stage);
    auto history_identity = locked_parent_identity(history);
    auto history_parent = locked_parent_identity(history.parent_path());
    if (!stage_identity || !history_identity || !history_parent)
        return failure<std::string>("modset_path_unsafe", "Activation staging or history custody is unavailable");
    json::ObjectBuilder context;
    context.add_string("schema", "factorio.locked_content_activation_commit.v1");
    context.add_string("operation_id", plan.operation_id);
    context.add_string("attempt_id", plan.attempt_id);
    context.add_string("history_id", plan.transaction_id);
    context.add_value("plan", admitted.value());
    context.add_array("effects", effects);
    context.add_string("history_identity", manifest.value().identity);
    context.add_string("stage_directory_identity", stage_identity.value());
    context.add_string("history_directory_identity", history_identity.value());
    context.add_string("history_parent_identity", history_parent.value());
    return facman::core::Result<std::string>::success(context.serialize());
}

facman::core::Result<std::string> apply_plan(const fs::path& workspace, ResolvedPlan plan)
{
    facman::base::StableLocalLock configuration_lock;
    const auto locked = tx::acquire_instance_configuration_lock(plan.instance.record.root, configuration_lock);
    if (!locked.acquired()) return failure<std::string>(
        locked.code == facman::base::StableLockCode::contended ? "instance_configuration_lock_contended" : "instance_configuration_lock_unsafe",
        locked.detail, plan.instance.record.root);
    if (plan.protected_inputs) {
        auto current = plan.protected_inputs();
        if (!current) return current;
    }
    plan.plan_id = sha256_text(plan_core_json(plan));
    for (const auto& selected : plan.selected) if (!selected.second->virtual_package) {
        auto current = facman::factorio::mods::inspect_mod_zip(selected.second->file_path);
        if (!current.valid || current.sha256 != selected.second->sha256 || current.sha1 != selected.second->sha1) {
            return failure<std::string>("modset_archive_changed", "A selected local archive changed before apply", selected.second->file_path);
        }
    }
    const std::string new_mod_list = mod_list_json(plan);
    const std::string new_lock = plan.locked_plan.empty() ? lock_json(plan) : plan.preserved_lock;
    std::vector<StateFile> files;
    for (auto result : {
            state_file("mod-list", plan.instance.mod_list, new_mod_list),
            state_file("local-lock", plan.instance.local_lock, new_lock),
            state_file("shared-lock", plan.instance.shared_lock, new_lock)}) {
        if (!result) return failure<std::string>(result.error().code, result.error().message, fs::u8path(result.error().path));
        files.push_back(result.take_value());
    }
    if (state_fingerprint(files[0].before, files[1].before, files[2].before) != plan.current_state_sha256) {
        return failure<std::string>("modset_external_drift", "Modset state changed after planning");
    }
    const fs::path mods_root = plan.instance.record.root / "mods";
    std::string link_detail;
    if (facman::base::path_crosses_link_or_reparse_point(mods_root, link_detail)) {
        return failure<std::string>("modset_path_unsafe", link_detail, mods_root);
    }
    auto attempt = activation_id(workspace, plan, files, mods_root);
    if (!attempt) return failure<std::string>(attempt.error().code, attempt.error().message,
        facman::platform::path_from_utf8(attempt.error().path), attempt.error().kind);
    plan.transaction_id = attempt.take_value();
    const fs::path history = mods_root / ".facman-modset-history" / plan.transaction_id;
    const fs::path stage = mods_root / (".facman-modset-stage-" + plan.transaction_id);
    std::error_code error;
    if (fs::exists(history, error) || fs::exists(stage, error)) {
        return failure<std::string>("persistent_target_exists", "Activation history or staging already exists", history);
    }
    fs::create_directories(history.parent_path(), error);
    if (error) return failure<std::string>("persistent_write_refused", error.message(), history);
    if (!fs::create_directory(history, error)) return failure<std::string>(
        "persistent_target_exists", error ? error.message() : "Activation attempt was claimed concurrently", history);
    std::string detail;
    for (const StateFile& file : files) if (file.before_present &&
        !write_new(history / (file.key + ".before"), file.before, detail)) {
        return failure<std::string>("persistent_write_refused", detail, history);
    }
    if (!write_new(history / "activation.v1.json", history_manifest(plan, files), detail)) {
        return failure<std::string>("persistent_write_refused", detail, history);
    }
    fs::create_directory(stage, error);
    if (error || !write_new(stage / "mod-list.json", new_mod_list, detail) ||
        !write_new(stage / "local-lock.json", new_lock, detail) ||
        !write_new(stage / "shared-lock.json", new_lock, detail)) {
        clean_stage(stage);
        return failure<std::string>("persistent_write_refused", error ? error.message() : detail, stage);
    }
    tx::Record transaction;
    transaction.command_id = "modsets.apply";
    transaction.target = plan.instance.mod_list;
    transaction.staging_roots = {stage, history};
    for (const auto& selected : plan.selected) if (!selected.second->virtual_package) {
        transaction.sources.push_back(selected.second->file_path);
    }
    transaction.commit_strategy = "backup_then_atomic_replace_with_rollback";
    if (!plan.locked_plan.empty()) {
        auto context = locked_commit_context(plan, files, stage, history);
        if (!context) return facman::core::Result<std::string>::failure(context.error());
        transaction.operation_context = context.take_value();
    }
    auto started = tx::TransactionSession::begin(workspace, std::move(transaction));
    if (!started) return failure<std::string>("recovery_write_refused", started.error().message);
    tx::TransactionSession session = started.take_value();
    if (!session.validated("local_archives_and_state_verified") || !session.planned("deterministic_plan_recorded") ||
        !session.staging("new_state_staged") || !session.staged("backups_and_new_state_verified")) {
        return failure<std::string>("recovery_write_refused", session.detail());
    }
    const char* fault = std::getenv("FACMAN_MODSET_FAULT");
    if (fault != nullptr && std::string(fault) == "after_backup") {
        clean_stage(stage);
        if (!restored_files_match(files) || !session.refused("fault injection after backup; original state verified")) {
            session.require_recovery("Original state or refusal journal could not be verified");
            return failure<std::string>("transaction_recovery_required", session.detail(), history,
                facman::core::OutcomeKind::recovery_required);
        }
        return failure<std::string>("modset_fault_injected", "Fault injected after backup");
    }
    const bool pause_completed = pause_before_apply_publication(stage, detail);
    const std::string pause_detail = detail;
    if (!verify_apply_staging(session.record(), plan, files, stage, history, detail)) {
        session.require_recovery(detail);
        return failure<std::string>("transaction_recovery_required", detail, stage,
            facman::core::OutcomeKind::recovery_required);
    }
    if (!plan.locked_plan.empty()) {
        auto context = locked_commit_context(plan, files, stage, history);
        if (!context || context.value() != session.record().operation_context) {
            session.require_recovery("Locked activation identities changed before publication; staging is retained");
            return failure<std::string>("transaction_recovery_required",
                "Locked activation identities changed before publication; preserve staging and inspect recovery", stage,
                facman::core::OutcomeKind::recovery_required);
        }
    }
    const char* pause_enabled = std::getenv("FACMAN_TEST_MODSET_APPLY_BEFORE_PUBLICATION_PAUSE");
    if (pause_enabled != nullptr && std::string(pause_enabled) == "1") {
        fs::remove(stage / ".facman-modset-apply-paused", error);
        if (!error) fs::remove(stage / ".facman-modset-apply-release", error);
        if (error) {
            session.require_recovery(error.message());
            return failure<std::string>("transaction_recovery_required", error.message(), stage,
                facman::core::OutcomeKind::recovery_required);
        }
    }
    if (!pause_completed) {
        clean_stage(stage);
        if (!session.refused(pause_detail)) return failure<std::string>("recovery_write_refused", session.detail());
        return failure<std::string>("modset_test_pause_failed", pause_detail, stage);
    }
    for (const auto& selected : plan.selected) if (!selected.second->virtual_package) {
        const auto current = facman::factorio::mods::inspect_mod_zip(selected.second->file_path);
        if (!current.valid || current.sha256 != selected.second->sha256 || current.sha1 != selected.second->sha1) {
            clean_stage(stage);
            if (!session.refused("Selected local archive changed before publication")) {
                return failure<std::string>("recovery_write_refused", session.detail());
            }
            return failure<std::string>("modset_archive_changed", "A selected local archive changed before publication", selected.second->file_path);
        }
    }
    const auto current_instance = load_instance(workspace, plan.instance.record.id.str());
    if (!current_instance || current_instance.value().record.root != plan.instance.record.root ||
        current_instance.value().record.install_ref.str() != plan.instance.record.install_ref.str() ||
        current_instance.value().record.factorio_version != plan.instance.record.factorio_version ||
        !restored_files_match(files)) {
        clean_stage(stage);
        if (!session.refused("Instance or managed modset state changed before publication")) {
            return failure<std::string>("recovery_write_refused", session.detail());
        }
        return failure<std::string>("modset_external_drift", "Instance or modset state changed before publication", mods_root);
    }
    if (!session.verified("publication_inputs_revalidated") || !session.committing("atomic_state_replacement_started")) {
        return failure<std::string>("recovery_write_refused", session.detail());
    }
    std::size_t committed = 0;
    for (std::size_t index = 0; index < files.size(); ++index) {
        const fs::path staged = stage / (index == 0 ? "mod-list.json" : index == 1 ? "local-lock.json" : "shared-lock.json");
        fs::create_directories(files[index].target.parent_path(), error);
        if (error) {
            detail = "Could not prepare modset target parent " +
                facman::platform::path_to_utf8(files[index].target.parent_path()) +
                ": " + error.message();
            break;
        }
        if (fs::exists(files[index].target, error)) fs::remove(files[index].target, error);
        if (error) {
            detail = "Could not replace modset target " +
                facman::platform::path_to_utf8(files[index].target) +
                ": " + error.message();
            break;
        }
        fs::rename(staged, files[index].target, error);
        if (error) {
            detail = "Could not commit staged modset target " +
                facman::platform::path_to_utf8(files[index].target) +
                ": " + error.message();
            break;
        }
        ++committed;
        if (fault != nullptr && std::string(fault) == "after_first_commit" && committed == 1U) {
            detail = "fault injection after first commit"; break;
        }
    }
    if (committed != files.size()) {
        const std::string failure_detail = detail;
        if (!restore_files(files, history, ".failed-new", detail)) {
            session.failed(detail);
            return failure<std::string>("transaction_recovery_required", detail, history,
                facman::core::OutcomeKind::recovery_required);
        }
        clean_stage(stage);
        if (!restored_files_match(files) || !session.refused(failure_detail + "; original state restored and verified")) {
            session.require_recovery("Restored state or refusal journal could not be verified");
            return failure<std::string>("transaction_recovery_required", session.detail(), history,
                facman::core::OutcomeKind::recovery_required);
        }
        return failure<std::string>(fault != nullptr ? "modset_fault_injected" : "persistent_write_refused", failure_detail);
    }
    clean_stage(stage);
    if (!session.committed("modset_state_committed") || !session.complete()) {
        return failure<std::string>("transaction_recovery_required", session.detail(), history,
            facman::core::OutcomeKind::recovery_required);
    }
    std::string output = serialize_plan(plan, "modsets.apply", true);
    auto document = json::parse(output);
    if (!document) return failure<std::string>("modset_result_invalid", "Applied result could not be serialized");
    if (!plan.locked_plan.empty()) {
        auto admitted = json::parse(plan.locked_plan);
        json::ObjectBuilder receipt;
        receipt.add_string("schema", "factorio.locked_content_activation_result.v1");
        receipt.add_string("command", "modsets.apply");
        receipt.add_string("instance_id", plan.instance.record.id.str());
        receipt.add_string("plan_sha256", field_string(admitted.value(), "plan_sha256"));
        receipt.add_string("transaction_id", session.record().transaction_id);
        receipt.add_string("history_id", plan.transaction_id);
        receipt.add_string("operation_id", plan.operation_id);
        receipt.add_string("attempt_id", plan.attempt_id);
        receipt.add_string("effect_binding_sha256", sha256_text(session.record().operation_context));
        receipt.add_value("apply_result", document.value());
        receipt.add_bool("execution_started", false);
        receipt.add_bool("permit_issued", false);
        return facman::core::Result<std::string>::success(receipt.serialize());
    }
    return facman::core::Result<std::string>::success(std::move(output));
}

struct HistoryEntry {
    std::string key;
    fs::path target;
    bool before_present = false;
    std::string before_hash;
    std::string after_hash;
};

facman::core::Result<std::vector<HistoryEntry>> read_history(
    const fs::path& manifest, const std::string& transaction_id, const std::string& instance_id)
{
    auto text = stable_text(manifest);
    if (!text) return failure<std::vector<HistoryEntry>>(text.error().code, text.error().message, manifest);
    auto document = json::parse(text.value());
    if (!document || !document.value().is_object() ||
        field_string(document.value(), "schema") != "factorio.modset_activation_history.v1" ||
        field_string(document.value(), "transaction_id") != transaction_id ||
        field_string(document.value(), "instance_id") != instance_id) {
        return failure<std::vector<HistoryEntry>>("modset_history_invalid", "Activation history manifest is invalid", manifest);
    }
    const json::Value* files = document.value().find("files");
    if (files == nullptr || !files->is_array() || files->size() != 3U) {
        return failure<std::vector<HistoryEntry>>("modset_history_invalid", "Activation history file set is incomplete", manifest);
    }
    std::vector<HistoryEntry> entries;
    for (std::size_t index = 0; index < files->size(); ++index) {
        const json::Value* item = files->at(index);
        if (item == nullptr || !item->is_object()) return failure<std::vector<HistoryEntry>>(
            "modset_history_invalid", "Activation history entry is invalid", manifest);
        HistoryEntry entry;
        entry.key = field_string(*item, "key");
        entry.target = facman::platform::path_from_utf8(field_string(*item, "target"));
        entry.before_hash = field_string(*item, "before_sha256");
        entry.after_hash = field_string(*item, "after_sha256");
        const json::Value* present = item->find("before_present");
        if (present == nullptr) return failure<std::vector<HistoryEntry>>(
            "modset_history_invalid", "before_present is missing", manifest);
        auto present_value = present->bool_value();
        if (!present_value || entry.key.empty() || entry.target.empty() || entry.after_hash.empty()) {
            return failure<std::vector<HistoryEntry>>("modset_history_invalid", "Activation history entry is incomplete", manifest);
        }
        entry.before_present = present_value.value();
        entries.push_back(std::move(entry));
    }
    return facman::core::Result<std::vector<HistoryEntry>>::success(std::move(entries));
}

facman::core::Result<std::string> rollback_history(const fs::path& workspace, const Request& request)
{
    if (request.transaction_id.size() != 64U || !std::all_of(
            request.transaction_id.begin(), request.transaction_id.end(), [](unsigned char ch) { return std::isxdigit(ch) != 0; })) {
        return failure<std::string>("modset_transaction_id_invalid", "Rollback requires a 64-character plan transaction id");
    }
    auto instance = load_instance(workspace, request.instance_id);
    if (!instance) return failure<std::string>(instance.error().code, instance.error().message);
    facman::base::StableLocalLock configuration_lock;
    const auto locked = tx::acquire_instance_configuration_lock(instance.value().record.root, configuration_lock);
    if (!locked.acquired()) return failure<std::string>(
        locked.code == facman::base::StableLockCode::contended ? "instance_configuration_lock_contended" : "instance_configuration_lock_unsafe",
        locked.detail, instance.value().record.root);
    const fs::path mods_root = instance.value().record.root / "mods";
    std::string link_detail;
    if (facman::base::path_crosses_link_or_reparse_point(mods_root, link_detail)) {
        return failure<std::string>("modset_path_unsafe", link_detail, mods_root);
    }
    const fs::path history = mods_root / ".facman-modset-history" / request.transaction_id;
    if (fs::exists(history / "rollback.v1.json")) {
        return failure<std::string>("modset_already_rolled_back", "This activation has already been rolled back", history);
    }
    auto entries = read_history(history / "activation.v1.json", request.transaction_id, request.instance_id);
    if (!entries) return failure<std::string>(entries.error().code, entries.error().message, history);
    const std::map<std::string, fs::path> expected_targets = {
        {"mod-list", instance.value().mod_list},
        {"local-lock", instance.value().local_lock},
        {"shared-lock", instance.value().shared_lock},
    };
    std::set<std::string> seen_targets;
    for (HistoryEntry& entry : entries.value()) {
        auto expected = expected_targets.find(entry.key);
        if (expected == expected_targets.end() || !seen_targets.insert(entry.key).second ||
            entry.target.lexically_normal() != expected->second.lexically_normal()) {
            return failure<std::string>("modset_history_invalid", "Activation history cannot redirect managed restore targets", history);
        }
        entry.target = expected->second;
    }
    std::vector<StateFile> files;
    for (const HistoryEntry& entry : entries.value()) {
        auto current = stable_text(entry.target);
        if (!current || sha256_text(current.value()) != entry.after_hash) {
            return failure<std::string>("modset_external_drift", "Current state does not match the applied activation", entry.target);
        }
        StateFile file;
        file.key = entry.key; file.target = entry.target; file.after = current.take_value(); file.before_present = entry.before_present;
        if (entry.before_present) {
            auto before = stable_text(history / (entry.key + ".before"));
            if (!before || sha256_text(before.value()) != entry.before_hash) {
                return failure<std::string>("modset_history_invalid", "Activation backup identity does not match", history);
            }
            file.before = before.take_value();
        }
        files.push_back(std::move(file));
    }
    tx::Record transaction;
    transaction.command_id = "modsets.rollback";
    transaction.target = instance.value().mod_list;
    transaction.sources = {history / "activation.v1.json"};
    transaction.staging_roots = {};
    transaction.commit_strategy = "verified_history_restore_with_reapply_backup";
    auto started = tx::TransactionSession::begin(workspace, std::move(transaction));
    if (!started) return failure<std::string>("recovery_write_refused", started.error().message);
    tx::TransactionSession session = started.take_value();
    if (!session.validated("activation_history_verified") || !session.planned("rollback_plan_recorded") ||
        !session.staging("applied_state_preservation_started")) return failure<std::string>("recovery_write_refused", session.detail());
    std::string detail;
    for (const StateFile& file : files) {
        const fs::path preserved = history / (file.key + ".applied");
        std::error_code preserved_error;
        if (fs::exists(preserved, preserved_error)) {
            auto existing = stable_text(preserved);
            if (!existing || existing.value() != file.after) {
                session.failed("preserved applied state disagrees with current state");
                return failure<std::string>("modset_history_invalid", "Preserved applied state disagrees with current state", preserved);
            }
        } else if (preserved_error || !write_new(preserved, file.after, detail)) {
            session.failed(detail); return failure<std::string>("persistent_write_refused", detail, history);
        }
    }
    if (!session.staged("applied_state_preserved") || !session.verified("rollback_sources_verified") ||
        !session.committing("rollback_restore_started")) return failure<std::string>("recovery_write_refused", session.detail());
    const char* fault = std::getenv("FACMAN_MODSET_FAULT");
    const bool inject = fault != nullptr && std::string(fault) == "rollback_after_first_restore";
    if (!restore_files(files, history, ".rollback-displaced", detail, inject ? 1U : static_cast<std::size_t>(-1))) {
        if (inject && restore_applied_files(files, history, detail)) {
            session.failed("fault injection after first rollback restore");
            return failure<std::string>("modset_fault_injected", "Fault injected during rollback and applied state was restored");
        }
        session.failed(detail);
        return failure<std::string>("transaction_recovery_required", detail, history,
            facman::core::OutcomeKind::recovery_required);
    }
    json::ObjectBuilder marker;
    marker.add_string("schema", "factorio.modset_rollback.v1");
    marker.add_string("transaction_id", request.transaction_id);
    marker.add_string("instance_id", request.instance_id);
    marker.add_string("status", "rolled_back");
    if (!write_new(history / "rollback.v1.json", marker.serialize() + "\n", detail) ||
        !session.committed("previous_state_restored") || !session.complete()) {
        return failure<std::string>("transaction_recovery_required", detail.empty() ? session.detail() : detail, history,
            facman::core::OutcomeKind::recovery_required);
    }
    json::ObjectBuilder output;
    output.add_string("schema", "factorio.modset_rollback.v1");
    output.add_string("command", "modsets.rollback");
    output.add_string("status", "rolled_back");
    output.add_string("instance_id", request.instance_id);
    output.add_string("transaction_id", request.transaction_id);
    output.add_bool("local_artifacts_only", true);
    output.add_bool("portal_access", false);
    output.add_bool("mutation_executed", true);
    return facman::core::Result<std::string>::success(output.serialize());
}

} // namespace

facman::core::Result<std::string> plan(const fs::path& workspace, const Request& request)
{
    return read_plan(workspace, request, "modsets.plan");
}

facman::core::Result<std::string> diff(const fs::path& workspace, const Request& request)
{
    return read_plan(workspace, request, "modsets.diff");
}

facman::core::Result<std::string> explain(const fs::path& workspace, const Request& request)
{
    return read_plan(workspace, request, "modsets.explain");
}

facman::core::Result<std::string> apply(const fs::path& workspace, const Request& request)
{
    auto resolved = resolve_plan(workspace, request);
    if (!resolved) return failure<std::string>(resolved.error().code, resolved.error().message, fs::u8path(resolved.error().path));
    return apply_plan(workspace, resolved.take_value());
}

facman::core::Result<std::string> verify_activation(const fs::path& mods_root,
    const std::string& verified_lock)
{
    const fs::path path = mods_root / "mod-list.json";
    std::string detail;
    if (facman::base::path_crosses_link_or_reparse_point(path, detail))
        return failure<std::string>("modset_activation_unsafe", detail, path);
    auto text = stable_text(path);
    if (!text) return text;
    auto entries = activation_entries(text.value());
    if (!entries) return failure<std::string>(entries.error().code, entries.error().message, path);
    std::set<std::string> enabled;
    for (const auto& entry : entries.value()) if (entry.second) enabled.insert(entry.first);
    // Apply always writes base as enabled, even for legacy locks that omit it.
    std::set<std::string> expected {"base"};
    auto lock = facman::factorio::content::content_lock_from_modset_lock_json(verified_lock);
    if (!lock) return failure<std::string>(lock.error().code, lock.error().message, path);
    for (const auto& entry : lock.value().entries)
        if (entry.enabled) expected.insert(entry.name);
    if (enabled != expected) return failure<std::string>("modset_activation_drift",
        "Enabled mod list differs from the verified lock; review and apply the instance modset", path);
    if (facman::base::path_crosses_link_or_reparse_point(path, detail))
        return failure<std::string>("modset_activation_unsafe", detail, path);
    return facman::core::Result<std::string>::success(text.take_value());
}

facman::core::Result<std::string> plan_locked_activation(const fs::path& workspace, const std::string& id)
{
    auto planned = locked_activation(workspace, id);
    if (!planned) return facman::core::Result<std::string>::failure(planned.error());
    return facman::core::Result<std::string>::success(planned.value().locked_plan);
}

facman::core::Result<std::string> verify_locked_activation(const fs::path& workspace, const std::string& id,
    const std::string& source, const std::string& receipt_text, const std::string& operation, const std::string& attempt)
{
    const auto refuse = [&]() { return failure<std::string>("modset_locked_effect_unverified",
        "Retained locked activation cannot be verified; inspect its domain journal before continuing", {},
        facman::core::OutcomeKind::recovery_required); };
    auto plan = json::parse(source);
    auto receipt = json::parse(receipt_text);
    auto instance = load_instance(workspace, id);
    const auto flag = [](const json::Value& value, const char* key, bool expected) {
        const auto* field = value.find(key);
        auto observed = field ? field->bool_value() : facman::core::Result<bool>::failure({"missing", "missing", {}});
        return observed && observed.value() == expected;
    };
    if (!plan || !receipt || !instance || operation.empty() || attempt.empty() ||
        field_string(plan.value(), "schema") != "factorio.locked_content_activation_plan.v1" ||
        field_string(plan.value(), "instance_id") != id ||
        field_string(receipt.value(), "schema") != "factorio.locked_content_activation_result.v1" ||
        field_string(receipt.value(), "command") != "modsets.apply" ||
        field_string(receipt.value(), "instance_id") != id ||
        field_string(receipt.value(), "plan_sha256") != field_string(plan.value(), "plan_sha256") ||
        field_string(receipt.value(), "operation_id") != operation || field_string(receipt.value(), "attempt_id") != attempt ||
        !flag(receipt.value(), "execution_started", false) || !flag(receipt.value(), "permit_issued", false))
        return refuse();
    auto unhashed = json::canonical_integer_object_without(plan.value(), "plan_sha256");
    if (!unhashed || sha256_text(unhashed.value()) != field_string(plan.value(), "plan_sha256")) return refuse();
    const auto history_id = field_string(receipt.value(), "history_id");
    if (history_id.size() != 64U || !std::all_of(history_id.begin(), history_id.end(), [](unsigned char c) { return std::isxdigit(c) != 0; }))
        return refuse();
    const auto mods = instance.value().record.root / "mods";
    const auto history = mods / ".facman-modset-history" / history_id;
    const auto stage = mods / (".facman-modset-stage-" + history_id);
    tx::Record journal;
    std::string detail;
    auto workspace_record = facman::workspace::WorkspaceRepository(facman::workspace::WorkspaceLayout(workspace)).load();
    if (!tx::read_record(workspace, field_string(receipt.value(), "transaction_id"), journal, detail) ||
        !workspace_record || journal.workspace_id != workspace_record.value().id.str() ||
        journal.state != tx::State::complete || journal.command_id != "modsets.apply" ||
        journal.target != instance.value().mod_list || journal.staging_roots != std::vector<fs::path>{stage, history} ||
        journal.commit_strategy != "backup_then_atomic_replace_with_rollback" ||
        !tx::verify_staging_ownership(journal, stage, detail) || !tx::verify_staging_ownership(journal, history, detail) ||
        sha256_text(journal.operation_context) != field_string(receipt.value(), "effect_binding_sha256")) return refuse();
    auto context = json::parse(journal.operation_context);
    const auto* admitted = context ? context.value().find("plan") : nullptr;
    const auto* effects = context ? context.value().find("effects") : nullptr;
    const auto* before = plan.value().find("before_targets");
    const auto* artifacts = plan.value().find("artifact_inputs");
    const auto* applied = receipt.value().find("apply_result");
    const auto* desired = plan.value().find("desired_mods");
    const auto* applied_desired = applied ? applied->find("desired_mods") : nullptr;
    if (!context || !admitted || admitted->serialize() != plan.value().serialize() || !effects || !effects->is_array() || effects->size() != 3U ||
        !before || !before->is_object() || !artifacts || !artifacts->is_array() || !applied || !applied->is_object() ||
        !desired || !desired->is_array() || !applied_desired || desired->serialize() != applied_desired->serialize() ||
        field_string(context.value(), "schema") != "factorio.locked_content_activation_commit.v1" ||
        field_string(context.value(), "operation_id") != operation || field_string(context.value(), "attempt_id") != attempt ||
        field_string(context.value(), "history_id") != history_id ||
        field_string(*applied, "schema") != "factorio.modset_apply.v1" || field_string(*applied, "command") != "modsets.apply" ||
        field_string(*applied, "instance_id") != id || field_string(*applied, "transaction_id") != history_id ||
        field_string(*applied, "status") != "applied" || field_string(*applied, "plan_id") != field_string(plan.value(), "owner_plan_id") ||
        !flag(*applied, "mutation_executed", true) || !flag(*applied, "local_artifacts_only", true) || !flag(*applied, "portal_access", false)) return refuse();
    auto manifest = observe_locked_file(history / "activation.v1.json");
    auto entries = read_history(history / "activation.v1.json", history_id, id);
    auto record = observe_locked_file(instance.value().record.source_path);
    auto root_identity = locked_parent_identity(instance.value().record.root);
    auto stage_identity = locked_parent_identity(stage);
    auto history_identity = locked_parent_identity(history);
    auto history_parent = locked_parent_identity(history.parent_path());
    if (!manifest || manifest.value().identity != field_string(context.value(), "history_identity") || !entries ||
        !record || record.value().identity != field_string(plan.value(), "instance_identity") ||
        !root_identity || root_identity.value() != field_string(plan.value(), "root_identity") ||
        !stage_identity || stage_identity.value() != field_string(context.value(), "stage_directory_identity") ||
        !history_identity || history_identity.value() != field_string(context.value(), "history_directory_identity") ||
        !history_parent || history_parent.value() != field_string(context.value(), "history_parent_identity")) return refuse();
    const std::vector<fs::path> targets {instance.value().mod_list, instance.value().local_lock, instance.value().shared_lock};
    const std::vector<std::string> keys {"mod-list", "local-lock", "shared-lock"};
    std::vector<std::string> identities;
    std::set<std::string> history_files {"activation.v1.json", tx::transaction_staging_marker_name()};
    for (std::size_t index = 0; index < targets.size(); ++index) {
        const auto* effect = effects->at(index);
        const auto* original = before->find(keys[index]);
        const auto& retained = entries.value()[index];
        auto current = observe_locked_file(targets[index]);
        auto parent = locked_parent_identity(targets[index].parent_path());
        const auto* present = original ? original->find("present") : nullptr;
        auto present_value = present ? present->bool_value() : facman::core::Result<bool>::failure({"missing", "missing", {}});
        const auto wanted_sha = field_string(plan.value(), index == 0U ? "mod_list_sha256" : "lock_sha256");
        if (!effect || !original || !current || !parent || !present_value || retained.key != keys[index] ||
            retained.target != targets[index] || retained.before_present != present_value.value() ||
            retained.before_hash != field_string(*original, "sha256") || retained.after_hash != wanted_sha ||
            field_string(*effect, "key") != keys[index] || field_string(*effect, "target") != facman::platform::path_to_utf8(targets[index]) ||
            current.value().identity != field_string(*effect, "identity") || sha256_text(current.value().text) != wanted_sha ||
            field_string(*effect, "sha256") != wanted_sha || parent.value() != field_string(*effect, "parent_identity") ||
            parent.value() != field_string(*original, "parent_identity")) return refuse();
        if (retained.before_present) {
            history_files.insert(keys[index] + ".before");
            auto backup = observe_locked_file(history / (keys[index] + ".before"));
            if (!backup || backup.value().identity != field_string(*effect, "backup_identity") ||
                sha256_text(backup.value().text) != retained.before_hash) return refuse();
        } else if (field_string(*effect, "backup_identity") != "absent") return refuse();
        identities.push_back(current.value().identity);
    }
    for (std::size_t index = 0; index < artifacts->size(); ++index) {
        const auto* artifact = artifacts->at(index);
        if (!artifact || !artifact->is_object()) return refuse();
        auto observed = observe_locked_file(facman::platform::path_from_utf8(field_string(*artifact, "path")));
        if (!observed || observed.value().identity != field_string(*artifact, "identity")) return refuse();
    }
    for (const auto& expected : {std::make_pair(history, history_files),
            std::make_pair(stage, std::set<std::string>{tx::transaction_staging_marker_name()})}) {
        std::error_code error;
        std::set<std::string> actual;
        fs::directory_iterator iterator(expected.first, error);
        if (error) return refuse();
        for (; iterator != fs::directory_iterator(); iterator.increment(error)) {
            if (error) return refuse();
            actual.insert(facman::platform::path_to_utf8(iterator->path().filename()));
        }
        if (error || actual != expected.second) return refuse();
    }
    auto lock = observe_locked_file(instance.value().local_lock);
    auto selected_lock = lock ? facman::factorio::content::content_lock_from_modset_lock_json(lock.value().text) :
        failure<facman::factorio::content::ContentLock>("unavailable", "unavailable");
    if (!selected_lock) return refuse();
    std::set<fs::path> expected_sources;
    for (const auto& entry : selected_lock.value().entries)
        if (entry.enabled && !entry.virtual_package) expected_sources.insert(mods / fs::u8path(entry.file_name));
    if (journal.sources.size() != expected_sources.size() ||
        std::set<fs::path>(journal.sources.begin(), journal.sources.end()) != expected_sources) return refuse();
    auto activation = lock ? verify_activation(mods, lock.value().text) : failure<std::string>("unavailable", "unavailable");
    const auto verified = facman::factorio::modsets::operations::verify_modset(workspace, {id});
    const auto* report = std::get_if<facman::factorio::modsets::operations::VerifyResult>(&verified);
    if (!activation || sha256_text(activation.value()) != field_string(plan.value(), "mod_list_sha256") || !report || !report->problems.empty()) return refuse();
    for (std::size_t index = 0; index < targets.size(); ++index) {
        auto current = observe_locked_file(targets[index]);
        if (!current || current.value().identity != identities[index]) return refuse();
    }
    return facman::core::Result<std::string>::success(receipt_text);
}

facman::core::Result<std::string> apply_locked_activation(const fs::path& workspace, const std::string& id,
    const std::string& expected, const std::string& operation, const std::string& attempt,
    const std::function<facman::core::Result<std::string>()>& protected_inputs)
{
    auto planned = locked_activation(workspace, id);
    if (!planned) return facman::core::Result<std::string>::failure(planned.error());
    auto document = json::parse(planned.value().locked_plan);
    if (!document || expected.empty() || field_string(document.value(), "plan_sha256") != expected || operation.empty() || attempt.empty())
        return failure<std::string>("modset_locked_plan_changed", "Exact locked activation changed; refresh before confirming");
    const auto source = planned.value().locked_plan;
    planned.value().operation_id = operation;
    planned.value().attempt_id = attempt;
    planned.value().protected_inputs = protected_inputs;
    auto applied = apply_plan(workspace, planned.take_value());
    if (!applied) return applied;
    return verify_locked_activation(workspace, id, source, applied.value(), operation, attempt);
}

facman::core::Result<std::string> rollback(const fs::path& workspace, const Request& request)
{
    return rollback_history(workspace, request);
}

} // namespace facman::factorio::modsets::solver
