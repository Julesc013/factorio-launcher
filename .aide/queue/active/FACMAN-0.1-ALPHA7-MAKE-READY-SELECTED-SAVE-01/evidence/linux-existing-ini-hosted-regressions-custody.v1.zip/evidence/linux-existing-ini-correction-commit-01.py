import hashlib,json,os,subprocess,sys,traceback,zipfile
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.safecrlf',GIT_CONFIG_VALUE_0='false')
sys.dont_write_bytecode=True;sys.path.insert(0,str(R));from tools import provider_canary_process as owned
BASE='504cb739f315e8fadaf1c11d8f09320a448b2bad';BRANCH='task/facman-linux-existing-ini-01';Q='.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
out=E/'linux-existing-ini-correction-commit-result-01.json';assert not out.exists()
record=dict(status='SEALING_QUALIFIED_HOSTED_TEST_CORRECTIONS',commands=[],goal_status_mutated=False,new_optional_campaigns=0)
def save():out.write_text(json.dumps(record,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
def run(label,args,timeout=180):
    r=owned.command(args,cwd=R,environment=dict(os.environ),timeout=timeout,directory=E/('linux-existing-ini-correction-commit01-'+label),output_limit=2*1024*1024)
    record['commands'].append(dict(label=label,exit=r.returncode,receipt_sha256=sha(r.directory/'receipt.json')));save()
    assert r.ok and r.receipt['primary_stopped'] and r.receipt['job_empty_observed'],(label,r.stderr[-1600:].decode(errors='replace'));return r
try:
    assert git('rev-parse','HEAD')==BASE and git('branch','--show-current')==BRANCH and not git('diff','--cached','--name-only') and not git('ls-files','--others','--exclude-standard')
    summary_path=E/'linux-existing-ini-qualification-summary-03.json';assert sha(summary_path)=='131a1203a962ea685c1cf9b320f403c1af644f4a24c97b92ea144ffbf43fd50c'
    a=json.loads(summary_path.read_bytes());assert a['status']=='PASS_LINUX_EXISTING_INI_SCOPED_TEST_CORRECTION' and a['base_head']==BASE
    for n,h in a['candidate_files_sha256'].items():assert sha(R/n)==h,n
    assurance_path=E/'linux-existing-ini-source-assurance-04.json';assert sha(assurance_path)==a['source_assurance_sha256']
    for n,h in json.loads(assurance_path.read_bytes())['source_files_sha256'].items():assert sha(R/n)==h,n
    assert hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=R)).hexdigest()==a['index_semantic_sha256'] and git('write-tree')==a['staged_tree']
    assert sha(W/'native-save-context-linux/facman')==a['cli_sha256']
    for n,h in a['native_images_sha256'].items():assert sha(W/'native-save-context-linux'/n)==h
    assert a['fresh_proof']['total_passed']==6 and not a['fresh_proof']['skips'] and a['accepted_reuse']['retained_passed']==56 and a['combined_accepted_counts']['total_passed']==62
    assert a['fresh_proof']['oversized_guard_proven'] and a['fresh_proof']['available_bound_existing_ini_plan_readonly_and_missing_confirmation_refusal_proven']
    assert all(a['drain'][k] for k in ('owned_primary_stopped','owned_windows_job_empty','linux_namespace_empty','private_fixture_unmounted','private_native_bind_unmounted','parent_fixture_empty'))
    assert all(c['exit']==0 and not c['execution_limit_exceeded'] for c in a['commands'])
    review_source=E/'linux-existing-ini-independent-source-review-06.json';review_data=json.loads(review_source.read_bytes());assert review_data['verdict']=='PASS_FOR_FOCUSED_CORRECTION_QUALIFICATION' and review_data['frozen_packet_sha256']==a['frozen_packet_sha256']
    task_paths={'tests/test_linux_configuration_reconciliation.py','tests/test_posix_preparation_publication.py'};assert set(git('diff','--name-only').splitlines())==task_paths
    archive=R/Q/'evidence/linux-existing-ini-hosted-regressions-custody.v1.zip';evidence=R/Q/'evidence/linux-existing-ini-hosted-regressions.v1.json';assert not archive.exists() and not evidence.exists()
    manifest={}
    for item in a['custody']:
        p=Path(item['path']);assert p.is_relative_to(E) and sha(p)==item['sha256'];manifest[p.relative_to(E).as_posix()]=item['sha256']
    for name in (summary_path.name,review_source.name,'linux-existing-ini-correction-commit-01.py'):manifest[name]=sha(E/name)
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr('custody-manifest.json',json.dumps(manifest,indent=2,sort_keys=True)+'\n')
        for n in sorted(manifest):z.write(E/n,'evidence/'+n)
    with zipfile.ZipFile(archive) as z:
        for n,h in manifest.items():assert hashlib.sha256(z.read('evidence/'+n)).hexdigest()==h
    evidence.write_text(json.dumps(dict(schema='facman.linux_existing_ini_hosted_regression_qualification.v1',base_head=BASE,files_sha256=a['candidate_files_sha256'],qualification_summary_sha256=sha(summary_path),independent_review_sha256=sha(review_source),combined_accepted_counts=a['combined_accepted_counts'],fresh_tests_passed=6,retained_passes=56,actual_readable_xattr_bytes=40000,verified_private_tmpfs=True,hosted_dev_shm_fallback_locally_executed=False,compiled_images_unchanged=True,linux_cli_sha256=a['cli_sha256'],no_rebuild=True,prior_hosted_failure_preserved=True,custody=archive.name,custody_sha256=sha(archive),custody_members=len(manifest)+1,required_new_source_ci_pending=True,authority_delta='none beyond prior Linux owner admission',darwin_owner_admitted=False,physical_ext4=False,apfs=False,power_loss=False,game=False,beta=False,rc=False),indent=2)+'\n')
    with (R/Q/'ExecPlan.md').open('a',encoding='utf-8',newline='\n') as f:
        f.write('\n### Required Linux hosted test compatibility correction\n\nThe first source campaign built and passed native checks but its 2062-test Python run found an obsolete Linux refusal expectation and an oversized xattr fixture its default filesystem could not represent. The Linux-only publication test now proves an admitted original-identity/metadata-bound plan, read-only query and exact refusal without explicit confirmation. The oversized guard still requires an actual readable 40000-byte xattr; it uses verified existing tmpfs, preferring private TMPDIR and otherwise the hosted /dev/shm mount, with actual device binding, no-link and free budget checks, and owned temporary-leaf cleanup. Six focused checks pass without skips, retaining 56 unchanged accepted passes for 62 total. Production source and compiled images are unchanged; no rebuild or completed campaign was duplicated. Actual hosted fallback and all fresh required source checks remain pending. The original CI failure is retained; broader product/host/release gates remain open.\n\nEvidence: `evidence/linux-existing-ini-hosted-regressions.v1.json` and its hash-closed custody archive.\n')
    paths=task_paths|{Q+'/ExecPlan.md',Q+'/evidence/'+evidence.name,Q+'/evidence/'+archive.name};assert set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())==paths
    for label in ('policy','detect','plan'):run(label,['py','-3','-B','.aide/scripts/aide_lite.py','git',label])
    run('strict',['py','-3','-B','tools/strict_check.py'],1800)
    message='test(readiness): qualify Linux owner on hosted filesystems\n\nRequire confirmation before admitted existing-INI effects and exercise\nthe oversized metadata guard on verified existing tmpfs storage.\n\nWork-Item: FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01\nEvidence-Ref: '+Q+'/evidence/'+evidence.name+'\n'
    msg=E/'linux-existing-ini-correction-commit-message-01.txt';msg.write_text(message,encoding='utf-8',newline='\n');run('message',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--message',message])
    changes=[dict(path=n,state='content',sha256=sha(R/n),git_blob_oid=git('hash-object','--path',n,str(R/n)),ownership='task_owned') for n in sorted(paths)]
    snapshot=hashlib.sha256((json.dumps(changes,indent=2,sort_keys=True,separators=(',',': '))+'\n').encode()).hexdigest()
    review=E/'linux-existing-ini-correction-commit-review-01.json';review.write_text(json.dumps(dict(schema_version='aide.git-commit-review.v1',verdict='PASS',reviewer='/root',runtime_author='/root/linux_existing_ini_implementation',non_authoring=True,branch=BRANCH,base_commit=BASE,snapshot_sha256=snapshot,message_sha256=sha(msg),independent_source_review_sha256=sha(review_source),qualification_summary_sha256=sha(summary_path),review='Only two reviewed test methods change; production source/images unchanged; actual6fresh plus56retained proof and no skips; actual huge readable xattr required; priorCI failure/custody/drain preserved; fresh requiredCI remains mandatory'),indent=2)+'\n')
    classification=E/'linux-existing-ini-correction-commit-classification-01.json';classification.write_text(json.dumps(dict(schema_version='aide.git-commit-classification.v1',branch=BRANCH,base_commit=BASE,work_item='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01',snapshot_sha256=snapshot,message_sha256=sha(msg),changed_paths=changes,reviews=[dict(path=str(review),sha256=sha(review),verdict='PASS')]),indent=2)+'\n')
    helper=['py','-3','-B','.aide/scripts/aide_lite.py','git','commit-plan','--classification',str(classification),'--message-file',str(msg)]
    run('plan-stage',helper);run('stage',['git','add','--',*sorted(paths)]);run('diff',['git','diff','--cached','--check']);run('plan-commit',helper)
    assert git('rev-parse','HEAD')==BASE;run('commit',['git','commit','-F',str(msg)])
    run('range',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--range',BASE+'..HEAD']);assert not git('status','--porcelain')
    record.update(status='COMMITTED_QUALIFIED_LINUX_HOSTED_TEST_CORRECTIONS',source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),review_sha256=sha(review),evidence_sha256=sha(evidence),remote_not_pushed=True)
except BaseException as exc:record.update(status='ACTIONABLE_LINUX_HOSTED_CORRECTION_COMMIT_FAILURE',error=str(exc),traceback=traceback.format_exc())
finally:save();print(json.dumps({k:v for k,v in record.items() if k!='commands'},indent=2))
raise SystemExit(0 if record['status']=='COMMITTED_QUALIFIED_LINUX_HOSTED_TEST_CORRECTIONS' else 1)
