from pathlib import Path
import os,sys,json,hashlib,subprocess,importlib,traceback,time,shutil,tempfile,contextlib,io,unittest
from unittest.mock import patch
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent;G=W/'native-developer';F=W/'t/j3/pt2';C=F/'c';I=F/'i';RAW=E/'tui-pack-import-source-raw-03';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sys.dont_write_bytecode=True;sys.path[:0]=[str(E),str(R/'tests'),str(R)]
from tools import provider_canary_process as owned
p=E/'tui-pack-import-source-plan-03.json';plan=json.loads(p.read_bytes());assert len(sys.argv)==3 and sys.argv[1]=='--reviewed-plan-sha256' and sha(p)==sys.argv[2]
probe=importlib.import_module('tui-pack-import-source-probe-03');probe.PLAN=p;probe.guard(plan)
out=E/'tui-pack-import-source-result-03.json';assert not out.exists();result=dict(status='SCRIPT_OWNED_RESOURCE_WAIT',plan_sha256=sha(p),execution_head=plan['execution_head'],producer=plan['artifact_source'],calls=[],fixture_created=False,new_builds=0,new_downloads=0,new_task_roots=0,real_game=False,human=False,fullscreen_terminal_qualified=False)
def save():out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
def plain(root):return {x.relative_to(root).as_posix():sha(x) for x in Path(root).rglob('*') if x.is_file()}
try:
 save();review=dict(verdict='ADMIT_SCOPED_TUI_PACK_SOURCE_REGRESSION',plan_sha256=sha(p),prepared_scripts=plan['prepared_scripts']);result['resource_admission']=probe.wait_for_resources(review,'before-worker');save()
 probe.guard(plan);build=json.loads((E/'tui-context-native-result-01.json').read_bytes());assert sha(E/'tui-context-native-result-01.json')==plan['native_result_sha256']
 assert build['status']=='PASS_REVIEWED_SOURCE_NATIVE_CONTROLS_COMPILER_LIFETIME_NOT_QUALIFIED'
 assert all(sha(Path(name))==row['sha256'] for name,row in build['outputs'].items())
 doctor=owned.command([sys.executable,'-B','tools/workspace_hygiene.py','doctor','--measure','--max-task-roots','8','--max-bytes',str(20*1024**3)],cwd=R,environment=dict(os.environ),directory=E/'tui-pack-import-source-doctor-03',timeout=600,output_limit=2*1024**2,wait_for_job_empty_after_primary=True)
 doc=json.loads(doctor.stdout);assert doctor.receipt['termination']=='completed' and doctor.receipt['job_empty_observed'] and not doctor.receipt['job_terminated'];assert set(doc['violations'])<={'unmanaged_secondary_worktrees_present'} and len(doc['task_roots'])<=8 and doc['task_root_bytes']+plan['limits']['new_total_bytes']<20*1024**3;result['doctor']=dict(bytes=doc['task_root_bytes'],receipt_sha256=sha(doctor.directory/'receipt.json'))
 for ancestor in [F.parent,*F.parent.parents]:assert ancestor.is_dir() and not ancestor.is_symlink() and not ancestor.lstat().st_file_attributes&0x400
 assert not F.exists() and not RAW.exists();F.mkdir();C.mkdir();RAW.mkdir();(RAW/'cas').mkdir();marker=F/'.facman-diagnostic-fixture.v1.json';marker.write_text(json.dumps(dict(owner='tui-pack-import-01',plan_sha256=sha(p),task_marker_sha256=plan['task_marker_sha256'])),encoding='utf-8');marker_sha=sha(marker);result['fixture_created']=True
 shutil.copytree(R/'tests/fixtures/fake_factorio_install',I)
 os.environ.update(FACMAN_CLI_EXE=str(G/'Release/facman.exe'),FACMAN_TUI_EXE=str(G/'Release/facman.exe'),TEMP=str(F),TMP=str(F),PYTHONDONTWRITEBYTECODE='1');tempfile.tempdir=None
 import native_cli,test_presentation_pack_import as presentation,test_local_modset_solver as solver,test_tui_product as tui
 start=time.monotonic();deadline=start+180
 def call(kind,argv,stdin=b''):
  assert sha(marker)==marker_sha and time.monotonic()<deadline and len(result['calls'])<32
  environment={k:v for k,v in os.environ.items() if not k.startswith('FACMAN_')};environment.update(PATH='',TEMP=str(F),TMP=str(F),PYTHONDONTWRITEBYTECODE='1')
  index=len(result['calls']);d=RAW/f'call-{index:03d}';cap=owned.command([str(G/'Release/facman.exe'),*argv],cwd=C,environment=environment,directory=d,input_bytes=stdin,timeout=min(15 if kind=='tui' else 30,deadline-time.monotonic()),output_limit=4*1024**2,wait_for_job_empty_after_primary=True)
  result['calls'].append(dict(kind=kind,argv=argv,receipt=str(d/'receipt.json'),receipt_sha256=sha(d/'receipt.json'),exit_code=cap.returncode));save();assert cap.receipt['termination']=='completed' and cap.receipt['primary_stopped'] and cap.receipt['job_empty_observed'] and not cap.receipt['job_terminated']
  assert sum(x.stat().st_size for x in RAW.rglob('*') if x.is_file())<=80*1024**2
  return cap
 def machine(args,env=None):
  assert not env,'Unexpected test-only child environment';c=call('cli',args);return c.returncode,c.stdout.decode('utf-8').replace('\r\n','\n'),c.stderr.decode('utf-8').replace('\r\n','\n')
 def terminal(self,args,*,stdin=None,environment=None):
  assert not environment and '--ordinary' in args and '--plain' in args and '--transport' in args
  c=call('tui',['tui',*args],(stdin or '').encode('utf-8'));return subprocess.CompletedProcess([str(G/'Release/facman.exe'),'tui',*args],c.returncode,c.stdout.decode('utf-8').replace('\r\n','\n'),c.stderr.decode('utf-8').replace('\r\n','\n'))
 class RetainedDirectory:
  count=0
  def __init__(self,*args,**kwargs):
   assert not args and kwargs==dict(prefix='tui offline pack Ω ')
   type(self).count+=1;assert type(self).count==1;self.path=F/'tui offline pack Ω case01';self.path.mkdir();self.name=str(self.path)
  def __enter__(self):return self.name
  def __exit__(self,*args):return False
  def cleanup(self):raise AssertionError('Retained proof fixture must not be deleted')
 # Preserve literal Unicode path used by the authored test.
 RetainedDirectory.__init__.__code__ # No product or test-source rewrite.
 with contextlib.ExitStack() as stack:
  stack.enter_context(patch.object(native_cli,'invoke_machine',machine));stack.enter_context(patch.object(presentation,'invoke_machine',machine));stack.enter_context(patch.object(native_cli,'ROOT',C));stack.enter_context(patch.object(presentation,'FIXTURE_INSTALL',I));stack.enter_context(patch.object(solver,'FIXTURE_INSTALL',I));stack.enter_context(patch.object(tui.TuiProductTests,'invoke',terminal));stack.enter_context(patch.object(tempfile,'TemporaryDirectory',RetainedDirectory))
  code,stdout,stderr=machine(['product','inspect','--json']);assert code==0 and not stderr;identity=json.loads(stdout)['payload'];result['backend_identity']=identity['backend_identity'];assert identity['backend_identity']==build['backend_identity'];assert identity['backend_identity']['build']['source_revision']==plan['execution_head'] and identity['backend_identity']['build']['source_dirty'] is True
  stream=io.StringIO();suite=unittest.TestSuite([tui.TuiProductTests('test_ordinary_offline_pack_import_cancels_then_reconstructs_without_selected_instance')]);tested=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite);text=stream.getvalue();assert len(text.encode())<2*1024**2;(RAW/'unittest.txt').write_text(text,encoding='utf-8');result.update(tests_run=tested.testsRun,skips=len(tested.skipped),failures=len(tested.failures),errors=len(tested.errors));assert tested.wasSuccessful() and tested.testsRun==1 and not tested.skipped,text
 result['status']='PASS_REVIEWED_SOURCE_LINEAR_TUI_OFFLINE_PACK_IMPORT';result['elapsed_seconds']=time.monotonic()-start
except BaseException as error:result.update(status='FAIL_RETAINED',error=repr(error),traceback=traceback.format_exc())
finally:
 if F.exists():
  inventory={}
  for path in F.rglob('*'):
   assert not path.is_symlink() and not path.lstat().st_file_attributes&0x400
   if path.is_file():
    raw=path.read_bytes();digest=hashlib.sha256(raw).hexdigest();inventory[path.relative_to(F).as_posix()]=dict(bytes=len(raw),sha256=digest)
    if RAW.exists() and not (RAW/'cas'/digest).exists():(RAW/'cas'/digest).write_bytes(raw)
  result['final_fixture_inventory']=inventory
 try:probe.guard(plan);assert all(sha(Path(name))==row['sha256'] for name,row in build['outputs'].items());result['final_guards']=dict(exact_source_and_native_outputs_unchanged=True,no_fixture_deletion=True)
 except BaseException as error:result.update(status='FAIL_RETAINED_FINAL_GUARD',final_guard_error=repr(error))
 save();print(json.dumps(dict(status=result['status'],tests_run=result.get('tests_run'),failures=result.get('failures'),errors=result.get('errors'),error_head=str(result.get('error',''))[:400]),ensure_ascii=False),flush=True)
raise SystemExit(0 if result['status'].startswith('PASS_') else 1)
