from pathlib import Path
import hashlib,json,os,sys,subprocess,importlib,shutil,time,traceback
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent;B=W/'native-developer';sys.dont_write_bytecode=True;sys.path[:0]=[str(E),str(R)]
from tools import provider_canary_process as owned,native_build
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
P=E/'tui-context-native-plan-01.json';plan=json.loads(P.read_bytes());assert len(sys.argv)==3 and sys.argv[1]=='--reviewed-plan-sha256' and sha(P)==sys.argv[2]
probe=importlib.import_module('tui-context-native-probe-01');probe.PLAN=P
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),TMPDIR=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',CMAKE_BUILD_PARALLEL_LEVEL='2',MSBUILDDISABLENODEREUSE='1',FACMAN_MIN_FREE_GIB='12')
out=E/'tui-context-native-result-01.json';assert not out.exists();result=dict(status='RESOURCE_WAIT',plan_sha256=sha(P),source_review_sha256=plan['source_review_sha256'],commands=[],new_roots=0,new_builds=0,compiler_natural_descendant_lifetime_qualified=False,scope='Reviewed source behavior only; no delivered artifact qualification')
def save():out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
def run(name,args,timeout=120,compiler=False,allow=(0,)):
 probe.guard(plan)
 c=owned.command(args,cwd=R,environment=dict(os.environ),directory=E/('tui-context-native-'+name+'-01'),timeout=timeout,output_limit=32*1024**2 if compiler else 8*1024**2,wait_for_job_empty_after_primary=not compiler)
 row=dict(name=name,receipt=str(c.directory/'receipt.json'),sha256=sha(c.directory/'receipt.json'),exit_code=c.returncode,termination=c.receipt['termination'],compiler_only_owned_cleanup=compiler,job_terminated=c.receipt['job_terminated'],active_at_primary_exit=c.receipt.get('active_processes_at_primary_exit'));result['commands'].append(row);save()
 assert c.returncode in allow and c.receipt['termination']=='completed' and c.receipt['primary_stopped'] and c.receipt['job_empty_observed'],(name,c.returncode)
 if compiler:
  assert args==plan['build_command'] and name=='build' and not c.receipt['waited_for_job_empty_after_primary'] and c.receipt.get('error') is None and c.receipt.get('cleanup_error') is None
 else:assert not c.receipt['job_terminated'] and c.receipt['waited_for_job_empty_after_primary']
 probe.guard(plan);return c
try:
 save();probe.guard(plan);grant=dict(verdict='ADMIT_SCOPED_TUI_CONTEXT_NATIVE_RESOURCE_PROBE',plan_sha256=sha(P),prepared_scripts=plan['prepared_scripts']);result['resource_before_doctor']=probe.wait_for_resources(grant,'before-doctor');save()
 run('paths',[sys.executable,'-B','tools/workspace_hygiene.py','paths'])
 d=run('doctor',[sys.executable,'-B','tools/workspace_hygiene.py','doctor','--measure','--max-task-roots','8','--max-bytes',str(20*1024**3)],600,allow=(0,1));doc=json.loads(d.stdout);assert set(doc['violations'])<={'unmanaged_secondary_worktrees_present'} and len(doc['task_roots'])<=8 and all(x['owned'] for x in doc['task_roots']);assert doc['task_root_bytes']+plan['limits']['new_total_bytes']<20*1024**3 and shutil.disk_usage(W).free-plan['limits']['new_total_bytes']>12*1024**3;result['storage_admission']=dict(task_roots=len(doc['task_roots']),bytes=doc['task_root_bytes'],violations=doc['violations']);save()
 run('strict',[sys.executable,'-B','tools/strict_check.py'],600)
 cache=B/'CMakeCache.txt';before=cache.read_bytes();(E/'tui-context-native-cache-before-01.txt').write_bytes(before)
 def profile():
  vals={}
  for line in cache.read_text(encoding='utf-8').splitlines():
   if ':' in line and '=' in line and not line.startswith(('//','#')):
    k=line.partition(':')[0]
    if k.startswith(('FACMAN_','ULK_BUILD_','USK_BUILD_','FLAUNCH_','CMAKE_GENERATOR','CMAKE_HOME_DIRECTORY')):vals[k]=line.partition('=')[2]
  return vals
 original=profile();assert original==plan['cache_profile'];run('configure',['cmake','-S',str(R),'-B',str(B)],300);assert profile()==original;(E/'tui-context-native-cache-after-01.txt').write_bytes(cache.read_bytes())
 result['resource_before_build']=probe.wait_for_resources(grant,'before-worker');save();native_build.require_disk_reserve(B);assert native_build.command(B,'Release',['facman_cli','facman_tui_product_model_smoke','facman_tui_smoke'],{})==plan['build_command'];result.update(status='BUILDING_EXISTING_REVIEWED_PROFILE',new_builds=1);save();started=time.time_ns();run('build',plan['build_command'],1200,compiler=True);ended=time.time_ns()
 outputs={}
 for name in ['facman.exe','facman_tui_product_model_smoke.exe','facman_tui_smoke.exe']:
  path=B/'Release'/name;assert path.is_file() and started<=path.stat().st_mtime_ns<=ended,name;outputs[str(path)]=dict(bytes=path.stat().st_size,sha256=sha(path),mtime_ns=path.stat().st_mtime_ns)
 result['outputs']=outputs;result['compiler_output_admitted_with_only_owned_cleanup']=True;save()
 run('ctest',['ctest','--test-dir',str(B),'-C','Release','--output-on-failure','-R','^(facman_tui_smoke|facman_tui_product_model_smoke)$'],120)
 identity=run('identity',[str(B/'Release/facman.exe'),'product','inspect','--json'],30);value=json.loads(identity.stdout)['payload']['backend_identity'];assert value['build']['source_revision']==plan['execution_head'] and value['build']['source_dirty'] is True;result['backend_identity']=value;assert all(sha(Path(name))==row['sha256'] for name,row in outputs.items())
 result.update(status='PASS_REVIEWED_SOURCE_NATIVE_CONTROLS_COMPILER_LIFETIME_NOT_QUALIFIED',native_tests=2,product_commands_strict_natural_empty_job=True)
except BaseException as error:result.update(status='FAIL_RETAINED_NATIVE_QUALIFICATION',error=repr(error),traceback=traceback.format_exc())
finally:save();print(json.dumps({k:v for k,v in result.items() if k not in ['commands','resource_before_doctor','resource_before_build','backend_identity']},indent=2),flush=True)
raise SystemExit(0 if result['status'].startswith('PASS_') else 1)
