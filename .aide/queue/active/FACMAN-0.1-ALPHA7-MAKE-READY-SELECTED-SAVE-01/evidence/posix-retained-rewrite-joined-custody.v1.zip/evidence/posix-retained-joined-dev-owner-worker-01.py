import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys
import unittest

R = Path('/mnt/d/Projects/Factorio/factorio-launcher')
E = Path(__file__).resolve().parent
assert os.getuid() == 65534 and os.getgid() == 65534 and os.getgroups() == []
assert os.environ['TMPDIR'] == str(E / 'posix-publication-private-fixtures-01')
sys.path[:0] = [str(R), str(R / 'tests')]
expected = {line.split('==')[0]: line.split('==')[1] for line in (R / 'tools/requirements-dev.lock').read_text().splitlines() if '==' in line}
versions = {name: importlib.metadata.version(name) for name in expected}
assert versions == expected
suite = unittest.defaultTestLoader.loadTestsFromNames([
    'test_configuration_preparation', 'test_selected_save_preparation',
    'test_posix_preparation_publication', 'test_posix_retained_rewrite_admission'])
result = unittest.TextTestRunner(verbosity=2).run(suite)
record = dict(schema='facman.posix_retained_combined_unprivileged_owner_tests.v1',
              status='PASS_COMBINED_LINUX_PUBLICATION_AND_CLOSED_REWRITE_ADMISSION' if result.wasSuccessful() and len(result.skipped) == 4 else 'ACTIONABLE_FIXTURE_FAILURE',
              tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
              skips=[(str(test), reason) for test,reason in result.skipped],
              cli_sha256=hashlib.sha256(Path(os.environ['FACMAN_CLI_EXE']).read_bytes()).hexdigest(),
              uid=os.getuid(), gid=os.getgid(), groups=os.getgroups(), locked_validators=versions,
              existing_ini_owner_admitted=False, physical_ext4=False, macos=False, game=False, power_loss=False)
out = E / 'posix-retained-joined-dev-owner-result-01.json'
with out.open('x') as stream:
    json.dump(record, stream, indent=2); stream.write('\n')
raise SystemExit(0 if record['status'].startswith('PASS_') else 1)
