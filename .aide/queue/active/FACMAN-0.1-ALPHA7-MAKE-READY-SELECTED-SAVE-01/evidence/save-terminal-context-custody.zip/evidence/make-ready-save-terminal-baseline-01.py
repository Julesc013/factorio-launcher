"""Observe a real declared-context drift through current public terminals."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

R=Path(r'D:\Projects\Factorio\factorio-launcher')
E=Path(__file__).resolve().parent
P='make-ready-save-terminal-baseline-01'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert __debug__ and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1'
marker=json.loads((E.parent/'.facman-development-root.v1.json').read_text(encoding='utf-8'))
assert Path(marker['canonical_path']).samefile(E.parent) and marker['task_id']=='task/facman-world-restore-retention-01'
binary=E.parent/'native-developer/Debug/facman.exe'
assert sha(binary)=='20dfe23fcbba828b5be23205fce74f59c458c9c94339f3c725515db4e2af2f42'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='291ad34f91fdea94d55255f6cc2de89da9342142'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()
fixture=E/(P+'-fixture'); assert not fixture.exists(); fixture.mkdir()
os.environ['FACMAN_CLI_EXE']=str(binary)
sys.path[:0]=[str(R/'tests'),str(R)]
import native_cli
from test_save_association_context import inventory
from test_save_index_retention import call,setup,write_save
commands=[]
original=native_cli.invoke_machine
def observed(args,env=None):
    result=original(args,env)
    commands.append(dict(argv=args,exit_code=result[0],stdout=result[1],stderr=result[2]))
    return result
native_cli.invoke_machine=observed
workspace=fixture/'workspace'
instance=setup(workspace)
save=instance/'saves/world.zip'; write_save(save,b'opaque terminal observation fixture')
(instance/'mods/modset-lock.v1.json').write_bytes(b'{"mods":[]}\n')
call(workspace,'saves','associate','world.zip','--instance','save-index')
manifest=instance/'instance.v1.json'
record=json.loads(manifest.read_text(encoding='utf-8')); record['factorio_version']='2.0.78'
manifest.write_text(json.dumps(record)+'\n',encoding='utf-8')
before=inventory(workspace)
report=call(workspace,'saves','verify','world.zip','--instance','save-index')
association=report['saves'][0]['association']
assert report['status']=='pass' and association['status']=='current' and association['context']['status']=='drifted'
human={}
for action in ('index','inspect','verify'):
    args=['--workspace',str(workspace),'saves',action]
    if action!='index': args.append('world.zip')
    args.extend(['--instance','save-index'])
    code,out,error=observed(args)
    assert code==0 and not error,(action,code,error)
    assert out.strip()==('Saves indexed' if action=='index' else 'Save '+action+' completed'),out
    human[action]=out
tui_argv=[str(binary),'tui','--workspace',str(workspace),'--ordinary','--plain']
tui=subprocess.run(tui_argv,input='5\nq\n',cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=30)
commands.append(dict(argv=tui_argv,stdin='5\nq\n',exit_code=tui.returncode,stdout=tui.stdout,stderr=tui.stderr))
assert tui.returncode==0 and not tui.stderr,(tui.returncode,tui.stderr)
assert 'world.zip' in tui.stdout and 'Opened Saves' in tui.stdout
assert 'Declared context:' not in tui.stdout and 'version drifted' not in tui.stdout
assert before==inventory(workspace),'Observation changed workspace'
(fixture/'machine-save-verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
(fixture/'human-output.json').write_text(json.dumps(human,indent=2)+'\n',encoding='utf-8')
(fixture/'tui-linear.log').write_text(tui.stdout,encoding='utf-8')
ledger=E/(P+'-commands.jsonl')
with ledger.open('x',encoding='utf-8',newline='\n') as f:
    for command in commands:f.write(json.dumps(command,ensure_ascii=False)+'\n')
leaves=['apps/cli/report_text.cpp','apps/cli/report_text.h','apps/cli/command_dispatch.cpp','apps/tui/tui_product_model.cpp']
receipt=dict(status='DEMONSTRATED_DECLARED_SAVE_CONTEXT_NOT_VISIBLE_IN_ORDINARY_TERMINALS',observed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),checkout_head='291ad34f91fdea94d55255f6cc2de89da9342142',retained_native_producer='4b32a15a59777911fe3911c55b5bc1f2be4c7ec5',binary_sha256=sha(binary),source_git_blobs={p:subprocess.check_output(['git','rev-parse','HEAD:'+p],cwd=R,text=True).strip() for p in leaves},outer_public_commands=len(commands),commands_sha256=sha(ledger),fixture=str(fixture),observed=dict(save_bytes='current',declared_context='drifted',factorio_version='drifted',modset_lock='match',CLI_human_only_generic_success=True,TUI_linear_context_absent=True),workspace_read_only=True,native_builds=0,new_task_roots=0,human_experience=False,actual_Factorio=False,whole_workunit_closed=False)
with (E/(P+'.json')).open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
