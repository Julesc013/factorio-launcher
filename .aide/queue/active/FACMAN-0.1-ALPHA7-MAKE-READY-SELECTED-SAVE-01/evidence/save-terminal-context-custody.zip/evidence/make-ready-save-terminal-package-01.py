"""Preserve terminal proof, append scoped evidence, classify normal commit input."""
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tomllib
import zipfile

R=Path(r'D:\Projects\Factorio\factorio-launcher')
E=Path(__file__).resolve().parent
P='make-ready-save-terminal'
U='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
BASE='ec4bac351aa8714e9b5cdd4d337edb8a8686d9a1'
B='task/facman-world-restore-retention-01'
Q=R/'.aide/queue/active'/U/'evidence'
sys.path.insert(0,str(R/'.aide/scripts'))
import aide_lite as aide
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(v,indent=2)+'\n')
def out(*args): return subprocess.check_output(args,cwd=R,text=True,encoding='utf-8').strip()
def check(name,args):
    log=E/(P+'-precommit-'+name+'.log')
    with log.open('x',encoding='utf-8') as f:r=subprocess.run(args,cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=900)
    entry=dict(check=name,argv=args,exit_code=r.returncode,log=str(log),sha256=sha(log))
    assert r.returncode==0,entry
    return entry
assert __debug__ and os.environ.get('PYTHONOPTIMIZE')=='0'
assert out('git','rev-parse','HEAD')==BASE and out('git','branch','--show-current')==B
assert not out('git','diff','--cached','--name-only')
proof_path=E/(P+'-source-proof-02.json'); proof=json.loads(proof_path.read_text(encoding='utf-8'))
assert proof['status']=='PASS_SCOPED_WINDOWS_PUBLIC_SAVE_TERMINALS' and proof['native_builds']==1
assert proof['real_owner_context_cases']==6 and proof['full_screen_render_model_cases']==2
assert len(proof['checks'])==10 and all(c['exit_code']==0 for c in proof['checks'])
for c in proof['checks']:assert sha(Path(c['log']))==c['sha256']
functional=proof['source_hashes']; assert len(functional)==8
for p,digest in functional.items():assert sha(R/p)==digest,p
images={'facman.exe':proof['CLI_sha256'],'facman_tui_product_model_smoke.exe':proof['native_TUI_model_sha256']}
for p,digest in images.items():assert sha(E.parent/'native-developer/Debug'/p)==digest
public_path=E/(P+'-public-01.json'); public=json.loads(public_path.read_text(encoding='utf-8'))
assert public['status']=='PASS_AFFECTED_PUBLIC_TERMINALS' and public['tests']==9 and not public['skips']
assert public['CLI_sha256']==proof['CLI_sha256'] and public['observed_outer_native_subprocess_run_commands']==59
assert sha(E/(P+'-public-01-commands.jsonl'))==public['commands_sha256']
regression_path=E/(P+'-emitter-regression-01.json'); regression=json.loads(regression_path.read_text(encoding='utf-8'))
assert regression['status']=='PASS' and regression['profile_human_test_methods']==1 and regression['readiness_and_describe_human_forms']==2
assert regression['CLI_sha256']==proof['CLI_sha256'] and regression['actual_outer_native_commands']==11
assert sha(E/(P+'-emitter-regression-01-commands.jsonl'))==regression['commands_sha256']
canonical=R/'release/index/plan.v1.toml'; original=canonical.read_text(encoding='utf-8'); plan=tomllib.loads(original)
unit=next(x for x in plan['workunit'] if x['id']==U); assert unit['status']=='active' and len(unit['acceptance'])==2 and len(unit['close_after'])==5
archive=Q/'save-terminal-context-custody.zip'; assert not archive.exists()
files=sorted(p for p in E.glob(P+'-*') if p.is_file() and p.suffix in {'.py','.json','.jsonl','.log'})
members={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for p in files:
        name='evidence/'+p.name; z.write(p,name); members[name]=sha(p)
    for p,digest in functional.items():
        name='source/'+p; z.write(R/p,name); members[name]=digest
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(members)
    for p,digest in members.items():assert hashlib.sha256(z.read(p)).hexdigest()==digest
receipt=Q/'save-terminal-context.v1.json'
write(receipt,dict(schema='facman.partial_acceptance.v1',status='PASS_SCOPED_WINDOWS_SOURCE_TERMINALS',work_item=U,base=BASE,
    source_hashes=functional,binary_identities=images,source_proof_sha256=sha(proof_path),public_proof_sha256=sha(public_path),emitter_regression_sha256=sha(regression_path),
    acceptance_scope=dict(real_owner_context_cases=6,matching_context=True,version_drift=True,content_drift=True,unknown_legacy_evidence=True,unavailable_context=True,byte_drift_with_matching_context=True,readable_index_inspect_verify_associate=True,empty_index=True,ordinary_TUI_linear=True,full_screen_native_render_model=True,full_screen_render_model_cases=2,optional_context_absent_compatibility=True,public_test_methods=10,skips=0,outer_native_commands=70,command_capture_scope=public['command_capture_scope'],existing_profile_and_readiness_human_output_preserved=True,observations_read_only=True,backend_states_forwarded_without_recomputation=True),
    custody=dict(path=archive.relative_to(R).as_posix(),sha256=sha(archive),members=members),
    retained_failures=['Initial baseline used an incorrect TUI status-label assertion after successful generic CLI assertions; preserved failure and actual subsequent owner snapshot/linear output. No complete initial command-ledger claim.', 'Dispatcher frozen size/complexity preflight refused the first source before any native build; shared existing report emitter reduced duplication with policy unchanged.'],
    resource_use=dict(native_builds=1,maximum_workers=2,maximum_heavy_local_jobs=1,new_task_roots=0,new_worktrees=0,optional_candidate_dispatches=0,CI_reruns=0,unchanged_wait_model_calls=0,prior_qualified_native_images=proof['preserved_qualified_images']),
    original_acceptance=unit['acceptance'],close_after=unit['close_after'],
    qualification=dict(source_fixture=True,produced_package=False,actual_Factorio=False,human_experience=False,physical_fullscreen_experience=False,gameplay_compatibility=False,selected_save_launch=False,full_windows_backend_link_qualification=False,release=False,whole_workunit=False,full_programme=False,exact_current_source_CI='pending'),
    external_gates_preserved=['PR343 protected-control owner authorization','Genuine distinct-version Linux Setup A5 update/rollback','MakeReady five original close-after prerequisites','Windows backend required link cell remains host blocked'],finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
start=original.index('id = "'+U+'"'); end=original.index('\n\n[[workunit]]',start)
section=original[start:end]; needle='\n]\nqueue_task = '; assert section.count(needle)==1
section=section.replace(needle,'\n  '+json.dumps(receipt.relative_to(R).as_posix())+',\n]\nqueue_task = ',1)
canonical.write_text(original[:start]+section+original[end:],encoding='utf-8',newline='\n')
expected=copy.deepcopy(plan); next(x for x in expected['workunit'] if x['id']==U)['evidence'].append(receipt.relative_to(R).as_posix()); assert tomllib.loads(canonical.read_text(encoding='utf-8'))==expected
checks=[]
for name,args in [('plan-generate',['tools/generate_plan_views.py']),('state-generate',['tools/project_state.py','--write']),('plan-check',['tools/generate_plan_views.py','--check']),('state-check',['tools/project_state.py','--validate']),('state-tests',['-m','unittest','tests.test_plan_views','tests.test_current_truth_roles','tests.test_aide_target_truth','tests.test_aide_compaction']),('strict',['tools/strict_check.py']),('format',['tools/source_format_check.py'])]:checks.append(check(name,[sys.executable,'-B',*args]))
checks.append(check('diff',['git','diff','--check']))
for p,digest in functional.items():assert sha(R/p)==digest,p
message=E/(P+'-commit.txt'); text='fix(cli): expose declared save context in terminal views\n\nWork-Item: '+U+'\nEvidence-Ref: '+receipt.relative_to(R).as_posix()+'\nChangelog: Fixed: Explain save bytes and declared context in ordinary terminal views\n'
with message.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
checks.append(check('template',[sys.executable,'-B','.aide/scripts/aide_lite.py','commit','template']))
checks.append(check('message',[sys.executable,'-B','.aide/scripts/aide_lite.py','commit','check','--message',text]))
paths=set(out('git','diff','--name-only').splitlines())|set(out('git','ls-files','--others','--exclude-standard').splitlines())
allowed=set(functional)|{canonical.relative_to(R).as_posix(),receipt.relative_to(R).as_posix(),archive.relative_to(R).as_posix(),'README.md','docs/roadmap.md','docs/release/checkpoints/README.md','release/index/current_state.v1.toml','release/index/project_status.v2.toml','.aide/memory/project-state.md','.aide/memory/project-state.v2.json','todo.md'}
assert paths<=allowed,sorted(paths-allowed)
changed=[dict(path=p,state='content',sha256=sha(R/p),git_blob_oid=out('git','hash-object','--path',p,p),ownership='task_owned') for p in sorted(paths)]
classification=dict(schema_version=aide.GIT_COMMIT_CLASSIFICATION_SCHEMA,branch=B,base_commit=BASE,work_item=U,message_sha256=sha(message),snapshot_sha256=aide.helper_commit_snapshot_sha256(changed),changed_paths=changed,reviews=[])
write(E/(P+'-commit-classification.json'),classification)
write(E/(P+'-precommit-QA.json'),dict(status='PASS',metadata_checks=checks,source_QA_sha256=sha(proof_path),receipt_sha256=sha(receipt),snapshot_sha256=classification['snapshot_sha256'],functional_source_hashes=functional,new_native_builds=0,whole_workunit_closed=False))
print(json.dumps(dict(status='PASS_PACKAGED_AND_CLASSIFIED',changed_paths=len(changed),custody_members=len(members),receipt_sha256=sha(receipt),custody_sha256=sha(archive),classification_sha256=sha(E/(P+'-commit-classification.json')),source_proof_sha256=sha(proof_path))))
