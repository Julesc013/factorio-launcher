"""Preflight, preserve useful native images, then one admitted build and proof."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

R=Path(r'D:\Projects\Factorio\factorio-launcher')
E=Path(__file__).resolve().parent
B=E.parent/'native-developer'
CLI=B/'Debug/facman.exe'
P='make-ready-save-terminal-source-proof-02'
OUT=E/(P+'.json')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(v,indent=2)+'\n')
def update():
    temp=OUT.with_suffix('.writing'); write(temp,record); temp.replace(OUT)
def output(*args): return subprocess.check_output(args,cwd=R,text=True,encoding='utf-8').strip()
def check(name,args,timeout=900):
    log=E/(P+'-'+name+'.log')
    with log.open('x',encoding='utf-8') as f:r=subprocess.run(args,cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
    record['checks'].append(dict(check=name,argv=args,exit_code=r.returncode,log=str(log),sha256=sha(log))); update()
    assert r.returncode==0,(name,r.returncode,str(log))
assert __debug__ and os.environ.get('PYTHONOPTIMIZE')=='0' and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1'
assert not OUT.exists() and output('git','rev-parse','HEAD')=='ec4bac351aa8714e9b5cdd4d337edb8a8686d9a1'
assert output('git','branch','--show-current')=='task/facman-world-restore-retention-01'
assert not output('git','diff','--cached','--name-only')
marker_path=E.parent/'.facman-development-root.v1.json'
marker=json.loads(marker_path.read_text(encoding='utf-8'))
assert marker['task_id']=='task/facman-world-restore-retention-01' and Path(marker['canonical_path']).samefile(E.parent) and Path(marker['source_root']).samefile(R)
terminal=E/'make-ready-save-view-integration-02.json'
assert sha(terminal)=='8162974b62c66b66f690388619a10df801c2dc0ab7dedd1e62f4a7ad890dde68'
t=json.loads(terminal.read_text(encoding='utf-8')); assert t['merge_CI_pass'] and t['merge']==output('git','rev-parse','HEAD')
paths={'apps/cli/command_dispatch.cpp','apps/cli/report_text.cpp','apps/cli/report_text.h','apps/tui/tui_product_model.cpp','apps/tui/tui_product_model.hpp','docs/product/save_intelligence.md','tests/native/facman_tui_product_model_smoke.cpp','tests/test_save_terminal_context.py'}
actual=set(output('git','diff','--name-only').splitlines())|set(output('git','ls-files','--others','--exclude-standard').splitlines()); assert actual==paths,actual
source={p:sha(R/p) for p in sorted(paths)}
assert sha(CLI)=='20dfe23fcbba828b5be23205fce74f59c458c9c94339f3c725515db4e2af2f42'
record=dict(prior_prebuild_failure='make-ready-save-terminal-source-proof-01.json',status='SOURCE_PREFLIGHT_PENDING',base=t['merge'],source_hashes=source,checks=[],native_builds=0,new_task_roots=0,new_worktrees=0,candidate_dispatches=0,CI_reruns=0,model_wait_calls=0,whole_workunit_closed=False)
write(E/(P+'.claim.json'),dict(PID=os.getpid(),source_hashes=source,no_automatic_replay=True)); update()
try:
    for name,args in [('format',['tools/source_format_check.py']),('metadata',['-m','tools.codegen.generate_metadata','--check']),('compiler',['-m','tools.codegen.generate_contracts','--check']),('gui-contract',['tools/facman_winforms_c1_check.py']),('contracts',['tools/command_contract_check.py']),('strict',['tools/strict_check.py']),('portable',['.aide/scripts/aide_lite.py','test'])]:
        check(name,[sys.executable,'-B',*args])
    for path,digest in source.items(): assert sha(R/path)==digest,path
    for name,extra in [('paths',[]),('doctor',['--measure'])]:
        r=subprocess.run([sys.executable,'-B','tools/workspace_hygiene.py',name,*extra],cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
        data=json.loads(r.stdout); write(E/(P+'-'+name+'.json'),data)
        if name=='doctor':
            assert r.returncode in {0,1} and set(data['violations'])<={'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
            assert len(data['task_roots'])<=8 and data['task_root_bytes']+2*1024**3+64*1024**2<=20*1024**3
        else: assert r.returncode==0
    assert shutil.disk_usage(E).free>=10*1024**3+64*1024**2
    jobs=output('powershell','-NoProfile','-Command',"Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(MSBuild|cmake|ninja|cl|link)\\.exe$' } | Select-Object Name,ProcessId | ConvertTo-Json -Compress")
    assert not jobs,jobs
    assert int(output('powershell','-NoProfile','-Command','(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory'))*1024>=4*1024**3
    images={p.name:sha(p) for p in (B/'Debug').iterdir() if p.is_file() and p.suffix in {'.exe','.dll'}}
    capsule=E/'native-save-context-qualified-images.zip'; assert not capsule.exists()
    with zipfile.ZipFile(capsule,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for name in images:z.write(B/'Debug'/name,name)
        z.writestr('identities.json',json.dumps(dict(producer='4b32a15a59777911fe3911c55b5bc1f2be4c7ec5',images=images),indent=2)+'\n')
    with zipfile.ZipFile(capsule) as z:
        assert z.testzip() is None
        for name,digest in images.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
    record['preserved_qualified_images']=dict(path=str(capsule),sha256=sha(capsule),images=images)
    temp=E/'make-ready-save-terminal-proof-01-temp'; assert not temp.exists(); temp.mkdir()
    os.environ.update(CMAKE_BUILD_PARALLEL_LEVEL='2',MSBUILDDISABLENODEREUSE='1',PYTHONUTF8='1',FACMAN_CLI_EXE=str(CLI),FACMAN_TUI_EXE=str(CLI),TMP=str(temp),TEMP=str(temp),PYTHONPATH=os.pathsep.join([str(R/'tests'),str(R)]))
    record['native_builds']=1; update()
    check('build',[sys.executable,'-B','tools/dev.py','build','developer','--task-root',str(E.parent),'--build-root',str(B),'--configuration','Debug','--target','facman_cli','--target','facman_tui_product_model_smoke'],1800)
    record['CLI_sha256']=sha(CLI); record['native_TUI_model_sha256']=sha(B/'Debug/facman_tui_product_model_smoke.exe'); update()
    check('native-TUI-model',['ctest','--test-dir',str(B),'-C','Debug','-R','^facman_tui_product_model_smoke$','--output-on-failure','--no-tests=error'],180)
    check('public',[sys.executable,'-B',str(E/'make-ready-save-terminal-public-01.py')],900)
    public=json.loads((E/'make-ready-save-terminal-public-01.json').read_text(encoding='utf-8')); assert public['status']=='PASS_AFFECTED_PUBLIC_TERMINALS' and public['CLI_sha256']==sha(CLI)
    for path,digest in source.items():assert sha(R/path)==digest,path
    renewed=json.loads(marker_path.read_text(encoding='utf-8')); assert all(renewed[k]==marker[k] for k in marker if k!='last_used_at')
    assert not list(temp.iterdir())
    record.update(status='PASS_SCOPED_WINDOWS_PUBLIC_SAVE_TERMINALS',public_suite=public,native_TUI_model_tests=1,real_owner_context_cases=6,full_screen_render_model_cases=2,actual_Factorio=False,produced_package=False,human_experience=False,full_programme_complete=False,temp_parent_empty=True)
except BaseException as error:record.update(status='stopped_for_actionable_failure',error=repr(error))
record['finished_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat(); update()
print(json.dumps({k:record.get(k) for k in ['status','CLI_sha256','native_builds','public_suite','error','finished_at_utc']}))
raise SystemExit(0 if record['status']=='PASS_SCOPED_WINDOWS_PUBLIC_SAVE_TERMINALS' else 1)
