"""Affected genuine public terminal tests with logs retained outside context."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

R=Path(r'D:\Projects\Factorio\factorio-launcher')
E=Path(__file__).resolve().parent
P='make-ready-save-terminal-public-01'
sys.path[:0]=[str(R/'tests'),str(R)]
cli=Path(os.environ['FACMAN_CLI_EXE'])
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
original=subprocess.run
count=0
with (E/(P+'-commands.jsonl')).open('x',encoding='utf-8',newline='\n') as capture:
    def observed(args,*positional,**kwargs):
        global count
        result=original(args,*positional,**kwargs)
        if isinstance(args,(list,tuple)) and args and Path(str(args[0])).resolve()==cli.resolve():
            count+=1
            def text(v): return v.decode('utf-8',errors='replace') if isinstance(v,bytes) else v
            capture.write(json.dumps(dict(sequence=count,argv=[str(x) for x in args],stdin=text(kwargs.get('input')),exit_code=result.returncode,stdout=text(result.stdout),stderr=text(result.stderr)),ensure_ascii=False)+'\n')
            capture.flush()
        return result
    subprocess.run=observed
    modules=['test_save_terminal_context','test_cli_machine_result','test_tui_product']
    suite=unittest.TestLoader().loadTestsFromNames(modules)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
record=dict(status='PASS_AFFECTED_PUBLIC_TERMINALS' if result.wasSuccessful() and not result.skipped else 'actionable_public_failure',tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skips=[dict(test=str(t),reason=r) for t,r in result.skipped],tested_modules=modules,CLI_sha256=sha(cli),observed_outer_native_subprocess_run_commands=count,command_capture_scope='CLI subprocess.run only; Popen and internal in-process presentation calls not separately counted',commands_sha256=sha(E/(P+'-commands.jsonl')),actual_Factorio=False,produced_package=False,human_experience=False,whole_workunit_closed=False)
with (E/(P+'.json')).open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
raise SystemExit(0 if record['status']=='PASS_AFFECTED_PUBLIC_TERMINALS' else 1)
