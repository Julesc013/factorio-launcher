import hashlib,json,os,shutil,subprocess,sys,time,traceback,re
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
sys.path.insert(0,str(R))
from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',CMAKE_BUILD_PARALLEL_LEVEL='2')
out=E/'posix-retained-darwin-absence-equivalence-01.json';assert not out.exists()
linux_e='/mnt/d/'+str(E)[3:].replace('\\','/')
record=dict(status='PREFLIGHT',commands=[],reserve_bytes=12*1024**3,planned_peak_bytes=2*1024**3,new_roots=0,new_clones=0,new_worktrees=0)
def save():out.write_text(json.dumps(record,indent=2)+'\n')
probe='''import os,json
names={'cmake','ninja','g++','c++','cc1plus','clang','clang++','ctest','facman'};active=[]
for name in os.listdir('/proc'):
 if name.isdigit():
  try:
   if open('/proc/'+name+'/comm').read().strip() in names:active.append(dict(pid=int(name),command=open('/proc/'+name+'/cmdline','rb').read().decode(errors='replace').replace(chr(0),' ')))
  except FileNotFoundError:pass
print(json.dumps(dict(mount_namespace=os.readlink('/proc/self/ns/mnt'),active=active)))'''
query="$all=@(Get-CimInstance Win32_Process); @($all | Where-Object { $_.Name -match '^(cl|clang|link|ninja|ctest)\\.exe$' -or ($_.Name -eq 'cmake.exe' -and $_.CommandLine -like '*--build*') -or ($_.Name -eq 'MSBuild.exe' -and $_.CommandLine -notlike '*/nodemode:*') } | Select-Object Name,ProcessId,ParentProcessId,CommandLine) | ConvertTo-Json -Depth 4 -Compress -AsArray"
def census():
 windows=json.loads(subprocess.check_output(['pwsh','-NoProfile','-Command',query],text=True,timeout=45) or '[]')
 linux=json.loads(subprocess.check_output(['wsl','-d','Ubuntu-24.04','-u','root','--','python3','-B','-c',probe],text=True,timeout=45))
 return dict(windows=windows,linux=linux)
F=E/'posix-retained-darwin-absence-frozen-01.json';f=json.loads(F.read_bytes());assert sha(F)=='bcaee015913263b8967cfd6a041cae89b098d311c1f69e395536926581610e25'
old=json.loads((E/'posix-retained-joined-dev-source-assurance-02.json').read_bytes())
expected=dict(old['source_files_sha256']);expected.update({i['path']:i['candidate_sha256'] for i in f['files']})
staged=hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=R)).hexdigest()
B=W/'native-developer';L=W/'native-save-context-linux'
providers=[W/'providers/universal-launcher-5479939ca5cb',W.parent/'task-facman-u-507ecf4b41/providers/universal-setup-2749a15b835a']
# No source/compiler/cache/provider writes occur: all preprocessing is stdout-only.
def inventory(roots):
 result={}
 for root in roots:
  for path in sorted(root.rglob('*')):
   if path.is_file() and '.git' not in path.relative_to(root).parts:
    h=hashlib.sha256()
    with path.open('rb') as stream:
     for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    result[str(path)]=h.hexdigest()
 return result
preserved=inventory([B,L,*providers])
def bound():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==f['base_head']
 assert hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=R)).hexdigest()==staged
 assert subprocess.run(['git','diff','--cached','--quiet','HEAD','--'],cwd=R).returncode==0
 for n,h in expected.items():assert sha(R/n)==h,n
 assert set(subprocess.check_output(['git','-c','core.safecrlf=false','diff','--name-only'],cwd=R,text=True,stderr=subprocess.DEVNULL).splitlines())==set(f['scope'])
 assert not subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R).strip()
 for root in providers:assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=root,text=True).strip()
lexer=re.compile(json.loads((E/'posix-retained-rewrite-windows-scoped-reuse-01.json').read_bytes())['corrected_runtime_preprocessed_proofs'][0]['lexer_pattern'])
def run(label,argv):
 bound()
 result=owned.command([str(x) for x in argv],cwd=R,environment=dict(os.environ),timeout=240,budget=budget,directory=E/('posix-retained-darwin-absence-'+label+'-execution-01'),output_limit=32*1024*1024)
 item=dict(label=label,argv=[str(x) for x in argv],exit=result.returncode,receipt=str(result.directory/'receipt.json'),receipt_sha256=sha(result.directory/'receipt.json'),stdout_sha256=sha(result.directory/'stdout.raw'),primary_stopped=result.receipt['primary_stopped'],job_empty=result.receipt['job_empty_observed'])
 record['commands'].append(item);save();assert result.ok and item['primary_stopped'] and item['job_empty'],label
 bound();return result.directory/'stdout.raw'
try:
 record.update(schema='facman.posix_retained.darwin_absence_scoped_equivalence.v1',base=f['base_head'],frozen_sha256=sha(F),source_files=len(expected),staged_entries_sha256=staged,cache_provider_files=len(preserved),cache_provider_inventory_sha256=hashlib.sha256(json.dumps(preserved,sort_keys=True).encode()).hexdigest(),proofs=[],no_rebuild=True,no_native_test_repeat=True,new_source_macos_ci_required=True)
 bound();record['admission_wait_observations']=[];deadline=time.monotonic()+7200
 while True:
  record['before']=census()
  if not record['before']['windows'] and not record['before']['linux']['active']:break
  record['status']='WAITING_FOREIGN_NATIVE_UNTOUCHED';record['admission_wait_observations'].append(dict(at=time.time(),census=record['before']));save();assert time.monotonic()<deadline;time.sleep(60)
 record['free_bytes_before']=shutil.disk_usage(W).free;assert record['free_bytes_before']>=record['reserve_bytes']+record['planned_peak_bytes'];budget=owned.Budget(2400,2200)
 metadata_path=next((B/'CMakeFiles').glob('*/CMakeCXXCompiler.cmake'));metadata=metadata_path.read_text();cl=Path(re.search(r'set\(CMAKE_CXX_COMPILER "([^"]+)"\)',metadata)[1]);vc=next(p for p in cl.parents if p.name.upper()=='VC');vcvars=vc/'Auxiliary/Build/vcvarsall.bat'
 record['windows_compiler_sha256']=sha(cl);record['windows_compiler_metadata_sha256']=sha(metadata_path)
 for item in f['files']:
  relative=item['path'];name=Path(relative).stem;baseline=E/('posix-retained-darwin-absence-'+name+'-baseline-01.cpp');assert not baseline.exists();baseline.write_bytes(subprocess.check_output(['git','show',f['base_head']+':'+relative],cwd=R));assert sha(baseline)==item['base_sha256']
  platforms=('linux','windows') if name=='fl_file_io' else ('linux',)
  for platform in platforms:
   captures=[]
   for kind,source in (('baseline',baseline),('candidate',R/relative)):
    label=platform+'-'+name+'-'+kind
    if platform=='linux':
     source_linux='/mnt/d/'+str(source)[3:].replace('\\','/');argv=['wsl','-d','Ubuntu-24.04','-u','root','--','env','TMPDIR='+('/mnt/d/'+str(W/'t')[3:].replace('\\','/')),'c++','-E','-P','-std=c++17',*['-I/mnt/d/Projects/Factorio/factorio-launcher/runtime/'+n for n in ('platform','core','base')],source_linux]
    else:
     flags=[str(cl),'/nologo','/EP','/TP','/std:c++17',*['/I'+str(R/'runtime'/n) for n in ('platform','core','base')],str(source)];assert all(not any(c in arg for c in '%!\r\n&|<>^') for arg in flags)
     helper=E/('posix-retained-darwin-absence-'+label+'-01.cmd');assert not helper.exists();helper.write_bytes(('@echo off\r\ncall "'+str(vcvars)+'" x64 >nul\r\nif errorlevel 1 exit /b %errorlevel%\r\n'+' '.join('"'+x+'"' for x in flags)+'\r\nexit /b %errorlevel%\r\n').encode());argv=['cmd.exe','/d','/c',helper]
    captures.append(run(label,argv))
   before=lexer.findall(captures[0].read_text());after=lexer.findall(captures[1].read_text());assert before==after,(platform,relative,'preprocessed token drift')
   record['proofs'].append(dict(platform=platform,path=relative,tokens_unchanged=True,token_count=len(after),token_sha256=hashlib.sha256(json.dumps(after,separators=(',',':')).encode()).hexdigest(),captures=[dict(path=str(p),sha256=sha(p)) for p in captures]));save()
 assert len(record['proofs'])==3
 assert inventory([B,L,*providers])==preserved,'cache/provider drift'
 record.update(status='PASS_SCOPED_NON_APPLE_EQUIVALENCE',base_head=f['base_head'],frozen_packet_sha256=sha(F),linux_runtime_tokens_unchanged=True,linux_native_test_tokens_unchanged=True,windows_runtime_tokens_unchanged=True,candidate_files_sha256={i['path']:i['candidate_sha256'] for i in f['files']},custody=[dict(path=str(Path(__file__).resolve()),sha256=sha(__file__)),*[dict(path=c['receipt'],sha256=c['receipt_sha256']) for c in record['commands']]],all_source_cache_provider_hashes_preserved=True,scoped_linux_43_pass_qualification_reused_sha256=sha(E/'posix-retained-joined-dev-qualification-summary-02.json'),scoped_windows_reuse_sha256=sha(E/'posix-retained-rewrite-windows-scoped-reuse-01.json'),lexer_pattern=lexer.pattern)
except BaseException as exc:record.update(status='ACTIONABLE_DARWIN_ABSENCE_EQUIVALENCE_FAILURE',error=str(exc),traceback=traceback.format_exc())
finally:
 bound();record['after']=census();record['free_bytes_after']=shutil.disk_usage(W).free;save();print(json.dumps({k:v for k,v in record.items() if k not in ('commands','admission_wait_observations','lexer_pattern')},indent=2));raise SystemExit(0 if record['status'].startswith('PASS_') else 1)
