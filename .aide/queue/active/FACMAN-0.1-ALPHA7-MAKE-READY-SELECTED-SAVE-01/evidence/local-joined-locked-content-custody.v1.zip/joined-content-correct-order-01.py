from pathlib import Path
r=Path(r'D:\Projects\Factorio\factorio-launcher');p=r/'runtime/factorio/modsets/flb_factorio_modset_solver.cpp';s=p.read_text(encoding='utf-8');start=s.index('    if (!plan.locked_plan.empty()) {\n        auto context = locked_commit_context(plan, files, stage, history);',s.index('const bool pause_completed'))
end=s.index('    if (!session.verified(',start);block=s[start:end];s=s[:start]+s[end:];position=s.index('    const char* pause_enabled =',s.index('const bool pause_completed'));s=s[:position]+block+s[position:];p.write_text(s,encoding='utf-8',newline='\n')
e=Path(__file__).resolve().parent;s=(e/'joined-content-static-03.py').read_text();(e/'joined-content-static-04.py').write_text(s.replace('source-draft-03.json','source-draft-04.json'),encoding='utf-8')
