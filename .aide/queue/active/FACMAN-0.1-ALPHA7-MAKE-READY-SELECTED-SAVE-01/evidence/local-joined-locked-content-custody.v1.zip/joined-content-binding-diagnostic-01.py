from pathlib import Path
import hashlib,json,os,sys
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent;sys.path[:0]=[str(R/'tests'),str(R)];os.environ.update(FACMAN_CLI_EXE=str(W/'native-developer/Release/facman.exe'),TEMP=str(W/'t'),TMP=str(W/'t'))
import test_make_ready_locked_content as content
from native_cli import invoke_machine
F=W/'t/jcdiag01';assert not F.exists();F.mkdir();(F/'owner.json').write_text(json.dumps(dict(owner='joined-content-binding-diagnostic-01',source_packet_sha256=hashlib.sha256((E/'joined-content-source-draft-07.json').read_bytes()).hexdigest(),cli_sha256=hashlib.sha256(Path(os.environ['FACMAN_CLI_EXE']).read_bytes()).hexdigest())),encoding='utf-8')
t=content.LockedContentMakeReadyTests();workspace=F/'workspace';instance=t.prepare(workspace);before=t.query(workspace,'instances','load_save');args=t.arguments(workspace,before,'binding-diagnostic');response=invoke_machine(args);assert response[0]==3 and not response[2];result=json.loads(response[1])['payload'];assert result['problems'][0]['code']=='make_ready_inputs_changed';t.assert_content_effect(workspace,result);after=t.query(workspace,'instances','load_save')
(E/'joined-content-binding-diagnostic-01.json').write_text(json.dumps(dict(status='DIAGNOSTIC_CONFIRMED_VERIFIED_CONTENT_THEN_PROTECTED_BINDING_REFUSAL_NOT_QUALIFICATION',fixture=str(F),before=before,result=result,after=after),indent=2)+'\n',encoding='utf-8')
def changes(a,b,path=''):
 if isinstance(a,dict) and isinstance(b,dict):
  for key in sorted(set(a)|set(b)):yield from changes(a.get(key),b.get(key),path+'.'+key)
 elif a!=b:yield dict(path=path,before=str(a)[:160],after=str(b)[:160])
for row in changes(before['readiness']['preparation_preview'],after['readiness']['preparation_preview']):print(json.dumps(row))
print('DEPENDENCY CHANGES')
for row in changes(before['dependency_identities'],after['dependency_identities']):
 if 'joined_preparation' not in row['path']:print(json.dumps(row))
