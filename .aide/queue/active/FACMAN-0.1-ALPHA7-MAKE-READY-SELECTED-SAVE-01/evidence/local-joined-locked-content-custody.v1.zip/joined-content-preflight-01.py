from pathlib import Path
import os,json,sys
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;sys.path.insert(0,str(R));from tools import provider_canary_process as owned
base=[sys.executable,'-B','.aide/scripts/aide_lite.py'];task='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01';env=dict(os.environ,FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1');rows=[]
for name,args,limit in [('paths',[sys.executable,'-B','tools/workspace_hygiene.py','paths'],120),('doctor',[sys.executable,str(E/'content-activation-resource-observer-02.py')],900),('inspect',base+['task','inspect','--task-id',task],120),('noop',base+['task','noop-check','--task-id',task],120),('recover',base+['task','recover','--task-id',task],120),('policy',base+['git','policy'],120),('detect',base+['git','detect'],120),('plan',base+['git','plan'],120)]:
 c=owned.command(args,cwd=R,environment=env,timeout=limit,directory=E/('joined-content-preflight-'+name+'-01'),output_limit=4*1024**2,wait_for_job_empty_after_primary=True)
 assert c.receipt['termination']=='completed' and c.receipt['primary_stopped'] and c.receipt['job_empty_observed'] and not c.receipt['job_terminated'],name
 if name=='doctor':
  d=json.loads(c.stdout);assert c.returncode==1 and d['violations']==['unmanaged_secondary_worktrees_present'] and len(d['task_roots'])<=8 and d['task_root_bytes']<20*1024**3
 else:assert c.returncode==0,(name,c.stderr.decode('utf-8'))
 rows.append(dict(name=name,exit=c.returncode,seconds=c.receipt['elapsed_seconds']))
print(json.dumps(rows,indent=2))
