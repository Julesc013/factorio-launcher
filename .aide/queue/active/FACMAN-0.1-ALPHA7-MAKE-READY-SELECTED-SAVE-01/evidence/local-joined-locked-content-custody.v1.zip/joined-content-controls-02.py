import hashlib
import json,os,sys
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');sys.path.insert(0,str(R));from tools import provider_canary_process as owned
E=Path(__file__).resolve().parent;W=E.parent
source_packet=E/'joined-content-source-draft-12.json';source=json.loads(source_packet.read_bytes());assert all(hashlib.sha256((R/n).read_bytes()).hexdigest()==h for n,h in source['files'].items());build=json.loads((E/'joined-content-build-07.json').read_bytes());assert build['ok'] and hashlib.sha256((W/'native-developer/Release/facman.exe').read_bytes()).hexdigest()==build['cli_sha256']
env=dict(os.environ,FACMAN_CLI_EXE=str(W/'native-developer/Release/facman.exe'),TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONPATH=str(R/'tests')+os.pathsep+str(R),UseSharedCompilation='false',MSBUILDDISABLENODEREUSE='1')
commands=[('instance-model-smoke',[str(W/'native-developer/Release/flb_factorio_instance_model_smoke.exe')]),('tui-model-smoke',[str(W/'native-developer/Release/facman_tui_product_model_smoke.exe')]),('strict',[sys.executable,'-B','tools/strict_check.py']),('aide-lite',[sys.executable,'-B','.aide/scripts/aide_lite.py','test'])]
rows=[]
for label,command in commands:
 result=owned.command(command,cwd=R,environment=env,timeout=900,directory=E/('joined-content-'+label+'-owned-02'),output_limit=8*1024**2,wait_for_job_empty_after_primary=True)
 row=dict(source_packet_sha256=hashlib.sha256(source_packet.read_bytes()).hexdigest(),cli_sha256=build['cli_sha256'],label=label,command=command,ok=result.ok,receipt=str(result.directory/'receipt.json'),exit_code=result.returncode,termination=result.receipt['termination'],primary_stopped=result.receipt['primary_stopped'],job_empty=result.receipt['job_empty_observed'],job_terminated=result.receipt['job_terminated']);rows.append(row)
 (E/'joined-content-controls-02.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print(json.dumps(row),flush=True)
 if not result.ok:
  print(result.stdout.decode('utf-8')[-4000:]);print(result.stderr.decode('utf-8')[-14000:]);sys.exit(1)
print('Appropriate native/static controls completed normally')
