from pathlib import Path
import hashlib,json
E=Path(__file__).resolve().parent;p=E/'joined-content-build-owned-04';r=json.loads((p/'receipt.json').read_bytes());assert r['exit_code']==1 and r['termination']=='completed' and r['primary_stopped'] and r['job_empty_observed'] and r['job_terminated']
for stream in ['stdout','stderr']:
 data=(p/r[stream]['file']).read_bytes();assert len(data)==r[stream]['captured_bytes'] and hashlib.sha256(data).hexdigest()==r[stream]['sha256']
row=dict(status='FAILED_COMPILE_NO_PRODUCT_EXECUTION',source_packet='joined-content-source-draft-06.json',source_packet_sha256=hashlib.sha256((E/'joined-content-source-draft-06.json').read_bytes()).hexdigest(),compiler_receipt=r,compiler_natural_descendant_lifetime_qualified=False,cli_present=False,wrapper_failure='FileNotFoundError hashing the absent CLI after native compile failure; original owned receipt/raw remain authoritative',product_execution=False)
(E/'joined-content-build-04.json').write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(status=row['status'],exit_code=r['exit_code'],elapsed_seconds=r['elapsed_seconds'],raw_hashes_verified=True)))
s=(E/'joined-content-static-06.py').read_text();(E/'joined-content-static-07.py').write_text(s.replace('source-draft-06.json','source-draft-07.json'),encoding='utf-8')
s=(E/'joined-content-build-04.py').read_text().replace('preexecution-review-04.json','preexecution-review-05.json').replace('source-draft-06.json','source-draft-07.json').replace('build-doctor-04','build-doctor-05').replace('build-resources-04','build-resources-05').replace('build-owned-04','build-owned-05').replace('joined-content-build-04.json','joined-content-build-05.json')
s=s.replace("cli_sha256=hashlib.sha256((B/'Release/facman.exe').read_bytes()).hexdigest()", "cli_sha256=hashlib.sha256((B/'Release/facman.exe').read_bytes()).hexdigest() if (B/'Release/facman.exe').is_file() else None")
(E/'joined-content-build-05.py').write_text(s,encoding='utf-8')
