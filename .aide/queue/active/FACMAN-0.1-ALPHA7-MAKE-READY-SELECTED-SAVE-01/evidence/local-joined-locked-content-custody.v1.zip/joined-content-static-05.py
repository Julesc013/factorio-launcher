from pathlib import Path
import ast,hashlib,json,subprocess
import jsonschema
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent
files=['runtime/factorio/application/presentation_action_support.cpp','runtime/factorio/application/presentation_action_support.h','runtime/factorio/application/presentation_joined_preparation.cpp','runtime/factorio/instance/flb_factorio_instance_model.cpp','runtime/factorio/instance/flb_factorio_instance_model.h','runtime/factorio/modsets/flb_factorio_modset_solver.cpp','runtime/factorio/modsets/flb_factorio_modset_solver.h','tests/test_readiness_content_activation.py','tests/test_make_ready_locked_content.py']
files += ['apps/gui/windows/winforms/PresentationModels.cs','apps/tui/tui_product_shell.cpp','tests/native/facman_tui_product_model_smoke.cpp','tests/winforms_control_gallery/SelectedSaveHarness.cs']
files += ['contracts/schema/factorio/'+n for n in ['factorio_locked_content_activation_plan.v1.schema.json','factorio_locked_content_activation_result.v1.schema.json','factorio_make_ready_joined_plan.v2.schema.json','factorio_make_ready_joined_result.v2.schema.json']]
for n in files:
 if n.endswith('.py'):ast.parse((R/n).read_text(encoding='utf-8-sig'))
 if n.endswith('.json'):jsonschema.Draft202012Validator.check_schema(json.loads((R/n).read_bytes()))
v1={}
for name in ['factorio_make_ready_joined_plan.v1.schema.json','factorio_make_ready_joined_result.v1.schema.json']:
 n='contracts/schema/factorio/'+name;base=subprocess.check_output(['git','show','e45e5ec6893ebc3b7a004db0664b69f2ee6d9d2c:'+n],cwd=R);assert base==(R/n).read_bytes();v1[n]=hashlib.sha256(base).hexdigest()
record=dict(status='DRAFT_STATIC_AST_AND_SCHEMA_CHECKED_NATIVE_NOT_BUILT',base='e45e5ec6893ebc3b7a004db0664b69f2ee6d9d2c',branch='task/facman-joined-locked-content-01',files={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in files},v1_schema_bytes_unchanged=v1,native_product_execution=False)
(E/'joined-content-source-draft-05.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(status=record['status'],files=len(files),new_schemas=4,python_AST=2,v1_schemas_unchanged=2)))

