from pathlib import Path
p=Path(__file__).resolve().parent/'joined-content-write-schemas-01.py';s=p.read_text(encoding='utf-8-sig').replace('modsets.apply_locked','modsets.apply').replace('instance_identity=text,lock_sha256','instance_identity=text,root_identity=text,lock_sha256');p.write_text(s,encoding='utf-8')
