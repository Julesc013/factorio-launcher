import json,os,sys
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R))
from tools import provider_canary_process as owned
E=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e\evidence');W=E.parent
os.environ.update(FACMAN_CLI_EXE=str(W/'native-developer/Release/facman.exe'),TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONPATH=str(R/'tests')+os.pathsep+str(R))
result=owned.command([sys.executable,'-m','unittest','test_make_ready_locked_content','-v'],cwd=R,environment=dict(os.environ),timeout=600,directory=E/'joined-content-focused-owned-01',output_limit=4*1024**2,wait_for_job_empty_after_primary=True)
row=dict(ok=result.ok,receipt=str(result.directory/'receipt.json'),exit_code=result.returncode,termination=result.receipt['termination'],primary_stopped=result.receipt['primary_stopped'],job_empty=result.receipt['job_empty_observed'])
(E/'joined-content-focused-01.json').write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8');print(json.dumps(row));print(result.stdout.decode('utf-8'));print(result.stderr.decode('utf-8'));sys.exit(0 if result.ok else 1)
