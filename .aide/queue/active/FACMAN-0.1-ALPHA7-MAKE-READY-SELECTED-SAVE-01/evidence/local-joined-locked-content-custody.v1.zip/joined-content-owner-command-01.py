from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher')
for n in ['runtime/factorio/modsets/flb_factorio_modset_solver.cpp','runtime/factorio/application/presentation_action_support.cpp','contracts/schema/factorio/factorio_locked_content_activation_result.v1.schema.json','contracts/schema/factorio/factorio_make_ready_joined_result.v2.schema.json']:
 p=R/n;s=p.read_text(encoding='utf-8').replace('"modsets.apply_locked"','"modsets.apply"');p.write_text(s,encoding='utf-8')
print('locked internal path retains existing modsets.apply owner command ID and recovery route')
