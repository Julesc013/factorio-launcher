import hashlib
import ast,json,os,sys
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent;sys.path.insert(0,str(R));from tools import provider_canary_process as owned
source_packet=E/'joined-content-source-draft-12.json';source=json.loads(source_packet.read_bytes());assert all(hashlib.sha256((R/n).read_bytes()).hexdigest()==h for n,h in source['files'].items());build=json.loads((E/'joined-content-build-07.json').read_bytes());assert build['ok'] and hashlib.sha256((W/'native-developer/Release/facman.exe').read_bytes()).hexdigest()==build['cli_sha256']
env=dict(os.environ,FACMAN_CLI_EXE=str(W/'native-developer/Release/facman.exe'),TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONPATH=str(R/'tests')+os.pathsep+str(R),UseSharedCompilation='false',MSBUILDDISABLENODEREUSE='1')
modules=['test_readiness_content_activation','test_local_modset_solver','test_make_ready_joined']
result=owned.command([sys.executable,'-m','unittest',*modules,'-v'],cwd=R,environment=env,timeout=900,directory=E/'joined-content-legacy-owned-02',output_limit=4*1024**2,wait_for_job_empty_after_primary=True)
row=dict(source_packet_sha256=hashlib.sha256(source_packet.read_bytes()).hexdigest(),cli_sha256=build['cli_sha256'],ok=result.ok,receipt=str(result.directory/'receipt.json'),exit_code=result.returncode,termination=result.receipt['termination'],primary_stopped=result.receipt['primary_stopped'],job_empty=result.receipt['job_empty_observed'],job_terminated=result.receipt['job_terminated'],modules=modules)
(E/'joined-content-legacy-02.json').write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8');print(json.dumps(row));print(result.stdout.decode('utf-8',errors='replace')[-2000:]);print('\n'.join(line[:500] for line in result.stderr.decode('utf-8',errors='replace').splitlines())[-12000:]);sys.exit(0 if result.ok else 1)
