from pathlib import Path
import json,os,sys
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;sys.path.insert(0,str(R));from tools import provider_canary_process as owned
r=owned.command([sys.executable,str(E/'joined-content-binding-diagnostic-01.py')],cwd=R,environment=dict(os.environ),timeout=120,directory=E/'joined-content-binding-diagnostic-owned-01',output_limit=4*1024**2,wait_for_job_empty_after_primary=True)
print(json.dumps(dict(ok=r.ok,termination=r.receipt['termination'],primary_stopped=r.receipt['primary_stopped'],job_empty=r.receipt['job_empty_observed'],job_terminated=r.receipt['job_terminated'])));print(r.stdout.decode('utf-8'));print(r.stderr.decode('utf-8'));sys.exit(0 if r.ok else 1)
