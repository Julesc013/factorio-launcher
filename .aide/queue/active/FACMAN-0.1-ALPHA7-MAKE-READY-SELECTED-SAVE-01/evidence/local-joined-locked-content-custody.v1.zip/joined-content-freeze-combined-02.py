from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'joined-content-static-05.py').read_text();s=s.replace("files += ['apps/gui/", "files += ['docs/development/make-ready-preparation.md']\nfiles += ['apps/gui/");(p/'joined-content-static-06.py').write_text(s.replace('source-draft-05.json','source-draft-06.json'),encoding='utf-8')
