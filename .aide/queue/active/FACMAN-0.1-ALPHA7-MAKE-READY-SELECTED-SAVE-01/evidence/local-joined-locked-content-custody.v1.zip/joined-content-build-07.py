from pathlib import Path
import datetime,hashlib,json,os,sys
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent;B=W/'native-developer';sys.path.insert(0,str(R));from tools import native_build,provider_canary_process as owned,development_layout
review=json.loads((E/'joined-content-source-preexecution-review-09.json').read_bytes());assert review['verdict']=='ADMIT_BOUNDED_LOCKED_CONTENT_JOINED_NATIVE_PROOF' and not review['findings']
packet=json.loads((E/'joined-content-source-draft-12.json').read_bytes());assert all(hashlib.sha256((R/n).read_bytes()).hexdigest()==h for n,h in packet['files'].items())
env=dict(os.environ,FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
measurement=owned.command([sys.executable,str(E/'content-activation-resource-observer-02.py')],cwd=R,environment=env,timeout=900,directory=E/'joined-content-build-doctor-07',output_limit=4*1024**2,wait_for_job_empty_after_primary=True)
assert measurement.returncode in (0,1) and measurement.receipt['termination']=='completed' and measurement.receipt['primary_stopped'] and measurement.receipt['job_empty_observed'] and not measurement.receipt['job_terminated']
h=json.loads(measurement.stdout);assert h['violations']==['unmanaged_secondary_worktrees_present'] and len(h['task_roots'])<=8 and h['task_root_bytes']+4*1024**3<=20*1024**3
ps="[pscustomobject]@{ObservedAtUtc=[datetime]::UtcNow.ToString('o');AvailablePhysicalBytes=([long](Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory*1024);FreeDiskBytes=(Get-PSDrive D).Free;Toolchains=@(Get-Process -Name cl,link,MSBuild,ninja,cmake,dotnet,VBCSCompiler -ErrorAction SilentlyContinue | Select-Object Id,ProcessName,WorkingSet64)} | ConvertTo-Json -Depth 4"
resources=owned.command(['powershell','-NoProfile','-Command',ps],cwd=R,environment=env,timeout=120,directory=E/'joined-content-build-resources-07',output_limit=1024**2,wait_for_job_empty_after_primary=True)
assert resources.ok and resources.receipt['primary_stopped'] and resources.receipt['job_empty_observed'] and not resources.receipt['job_terminated']
r=json.loads(resources.stdout.decode('utf-8-sig'));assert not r['Toolchains'] and r['AvailablePhysicalBytes']>=3*1024**3 and r['FreeDiskBytes']-4*1024**3>=12*1024**3
marker=W/development_layout.MARKER_NAME;assert hashlib.sha256(marker.read_bytes()).hexdigest()=='30d72706c486ff20eed8b1947a920caa0a4e2d43820abbaf0ff78d12ab9f697c';development_layout.read_marker(W,R)
env.update(CMAKE_BUILD_PARALLEL_LEVEL='2',TEMP=str(W/'t'),TMP=str(W/'t'),MSBUILDDISABLENODEREUSE='1',FACMAN_MIN_FREE_GIB='12');os.environ.update(env)
native_build.require_disk_reserve(B);command=native_build.command(B,'Release',['facman_cli','flb_factorio_instance_model_smoke','facman_tui_product_model_smoke'],{})
assert '--clean-first' in command and '/p:TrackFileAccess=false' in command and command[command.index('--parallel')+1]=='2'
cap=owned.command(command,cwd=R,environment=env,timeout=900,directory=E/'joined-content-build-owned-07',output_limit=8*1024**2,wait_for_job_empty_after_primary=False)
row=dict(command=command,ok=cap.ok,receipt=str(cap.directory/'receipt.json'),exit_code=cap.returncode,termination=cap.receipt['termination'],primary_stopped=cap.receipt['primary_stopped'],job_empty=cap.receipt['job_empty_observed'],job_terminated=cap.receipt['job_terminated'],compiler_natural_descendant_lifetime_qualified=False,source_packet_sha256=hashlib.sha256((E/'joined-content-source-draft-12.json').read_bytes()).hexdigest(),marker_unchanged=hashlib.sha256(marker.read_bytes()).hexdigest()=='30d72706c486ff20eed8b1947a920caa0a4e2d43820abbaf0ff78d12ab9f697c',cli_sha256=hashlib.sha256((B/'Release/facman.exe').read_bytes()).hexdigest() if (B/'Release/facman.exe').is_file() else None)
(E/'joined-content-build-07.json').write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8');print(json.dumps(row))
if not cap.ok:print(cap.stdout.decode('utf-8',errors='replace')[-8000:]);print(cap.stderr.decode('utf-8',errors='replace')[-2000:])
sys.exit(0 if cap.ok else 1)
