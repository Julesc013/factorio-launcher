from pathlib import Path
import subprocess,json,hashlib
E=Path(__file__).resolve().parent;R=Path(r'D:\Projects\Factorio\factorio-launcher');S='e45e5ec6893ebc3b7a004db0664b69f2ee6d9d2c';branch='task/facman-joined-locked-content-01'
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True,encoding='utf-8').strip()
assert git('rev-parse','HEAD')==S and git('rev-parse','dev')==S and git('rev-parse','origin/dev')==S and git('branch','--show-current')=='dev' and not git('status','--porcelain')
assert 'result: ready_dry_run' in (E/'joined-content-preflight-plan-01/stdout.raw').read_text(encoding='utf-8')
record=dict(base=S,branch=branch,task_root_reused=True,new_roots=0,new_caches=0,new_clones=0,authorization='Root standing explicit next sequential task branch and bounded implementation/integration instruction',helper_plan_sha256=hashlib.sha256((E/'joined-content-preflight-plan-01/stdout.raw').read_bytes()).hexdigest())
(E/'joined-content-branch-admission-01.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
subprocess.run(['git','switch','-c',branch],cwd=R,check=True);assert git('rev-parse','HEAD')==S and not git('status','--porcelain');print(branch)
