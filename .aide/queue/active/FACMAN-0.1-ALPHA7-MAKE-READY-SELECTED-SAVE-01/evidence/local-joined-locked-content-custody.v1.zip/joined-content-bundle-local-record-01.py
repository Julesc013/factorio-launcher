import hashlib,json,stat,zipfile
from pathlib import Path
R=Path('D:/Projects/Factorio/factorio-launcher');E=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
proof=json.loads((E/'joined-content-native-proof-01.json').read_bytes());review=json.loads((E/'joined-content-local-actual-review-01.json').read_bytes())
assert review['verdict']=='PASS_LOCAL_JOINED_LOCKED_CONTENT_SOURCE_AND_SCOPED_NATIVE_PROOF' and not review['findings']
assert sha(E/'joined-content-native-proof-01.json')==review['reviewed_proof']['sha256']
assert proof['source_packet_sha256']==review['source_packet']['sha256']==sha(E/review['source_packet']['path'])
assert proof['status']=='LOCAL_NATIVE_FIXTURE_QUALIFIED_DELIVERY_PENDING' and all(sha(R/r['path'])==r['sha256'] for r in proof['candidate_paths'])
Q=R/'.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01';Z=Q/'evidence/local-joined-locked-content-custody.v1.zip';J=Q/'evidence/local-joined-locked-content.v1.json'
assert not Z.exists() and not J.exists()
files=[p for p in E.glob('joined-content-*') if p.is_file() and p.suffix in {'.py','.json','.txt','.md'}]
for directory in E.glob('joined-content-*'):
 if directory.is_dir() and (directory/'receipt.json').is_file():
  files.extend(directory/n for n in ['receipt.json','stdout.raw','stderr.raw','stdin.raw'])
files=sorted(set(files),key=lambda p:p.relative_to(E).as_posix());assert len(files)<512
assert all(p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(E.resolve()) and stat.S_ISREG(p.stat(follow_symlinks=False).st_mode) for p in files)
assert sum(p.stat().st_size for p in files)<32*1024**2
inventory=[]
with zipfile.ZipFile(Z,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in files:
  name=p.relative_to(E).as_posix();data=p.read_bytes();info=zipfile.ZipInfo(name,date_time=(2026,10,18,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;archive.writestr(info,data);inventory.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
assert Z.stat().st_size<4*1024**2
record=dict(schema='facman.local_joined_locked_content.v1',status='LOCAL_NATIVE_FIXTURE_QUALIFIED_DELIVERY_PENDING',work_item='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01',workunit_closed=False,base=proof['base'],branch=proof['branch'],outcome='One explicit ordinary Make Ready reconciles only exact verified local locked content through its existing owner, then joins configuration and selected-save owners; healthy content keeps v1.',predecessor=dict(pr=438,source='80f7a3f1aa7644ab7ab09d76fea90fe9f7784952',integrated='e45e5ec6893ebc3b7a004db0664b69f2ee6d9d2c',receipt='https://github.com/Julesc013/factorio-launcher/pull/438#issuecomment-6243846986',scope='Activation truth closed; ordinary explicit Content Apply then joined v1 was proven. Same-request reconciliation deliberately remained open for this bounded successor.'),candidate_paths=proof['candidate_paths'],local_native_proof=proof,independent_local_review=dict(verdict=review['verdict'],receipt='joined-content-local-actual-review-01.json',sha256=sha(E/'joined-content-local-actual-review-01.json')),custody=dict(path=Z.relative_to(R).as_posix(),bytes=Z.stat().st_size,sha256=sha(Z),entries=len(inventory),inventory_sha256=hashlib.sha256(json.dumps(inventory,sort_keys=True,separators=(',',':')).encode()).hexdigest(),scope='Exact retained local receipts/raw/scripts/reviews, including failed attempts and unexecuted drafts; archive membership is not execution or acceptance.'),integration_gate=dict(required='Fresh exact-head required CI and independently reviewed original newly produced Windows CLI, actual ordinary TUI and actual ordinary WinForms locked-content Make Ready proof',delivered_proof_pending=True,resolution='A later exact-source PR receipt must explicitly resolve this historical pending field before normal checked merge.'),authority_delta='none',boundaries=proof['boundaries'])
J.write_text(json.dumps(record,indent=2)+chr(10),encoding='utf-8');(E/'joined-content-local-custody-inventory-01.json').write_text(json.dumps(inventory,indent=2)+chr(10),encoding='utf-8')
entry="""

2026-10-18: One explicitly confirmed ordinary Make Ready now reconciles missing
or safely understood activation drift from the exact already verified local
lock through the existing content owner, retaining raw lock bytes and its real
TransactionSession receipt before configuration and exact selected-save owners.
Healthy content retains joined v1; eligible pending content uses additive v2.
The shared TUI and WinForms consumers validate completion and verified partial
continuations, including zero further nested effects, while uncertainty stays
held. There is no re-resolution, acquisition, installation/profile reconstruction
or provider/pin change. Narrow16MiB physical artifact observation eligibility and
external-drift partial-stop limits remain explicit.
Local feature semantics cover14 methods across their recorded developer images;
final refreshed metadata has3 CLI/TUI/WinForms boundary methods plus native smoke,
strict and AIDE controls with normal primaries and empty owned Jobs. Compatibility
coverage is37 completed methods with semantic-only scope from the declared900s
forced batch, then3 unfinished methods passing normally;3 file/directory symlink
privilege subcases remain skipped. This is not a full40-test natural-lifetime
claim. Compiler primary success uses exact owned cleanup; natural compiler
descendant lifetime remains unqualified. Failed source, oracle, feedback and
stale-generated attempts remain retained with their original limits.
Fresh exact-head CI and independent original newly produced Windows CLI, actual
ordinary TUI and actual ordinary WinForms proof remain pending in this historical
local record. A later exact-source PR receipt must resolve that field before
merge. Whole Make Ready/F09/F11, real-game/human/canonical Desktop/PR404 and
Beta/RC/release gates remain open; the WorkUnit and programme remain active.
Scoped receipt and compact custody: evidence/local-joined-locked-content.v1.json
and evidence/local-joined-locked-content-custody.v1.zip.
"""
with (Q/'ExecPlan.md').open('a',encoding='utf-8',newline=chr(10)) as f:f.write(entry)
print(json.dumps(dict(record=J.relative_to(R).as_posix(),record_sha256=sha(J),custody_sha256=sha(Z),custody_bytes=Z.stat().st_size,entries=len(inventory))))
