from pathlib import Path
p=Path(r'D:\Projects\Factorio\factorio-launcher\apps\gui\windows\winforms\PresentationModels.cs');s=p.read_text(encoding='utf-8');a=s.index('                if (!Exact(payload,',s.index('internal static bool CanStartFreshRequest'));b=s.index('\n            }\n            catch (InvalidDataException)',a);body=s[a:b].replace('receipt.ActionId','"readiness.prepare_joined"');replacement='''                return PresentationJson.Text(payload, "schema") == "factorio.make_ready_joined_result.v2"
                    ? ValidContentPartial(payload, input, identity) : ValidV1Partial(payload, input);''';s=s[:a]+replacement+s[b:];i=s.index('        internal static string Summary(',a);s=s[:i]+'''        private static bool ValidV1Partial(IDictionary<string, object> payload, IDictionary<string, object> input)
        {
'''+body+'''
        }

'''+s[i:];p.write_text(s,encoding='utf-8',newline='\n')
