from pathlib import Path
import json,os,subprocess,sys
E=Path(__file__).resolve().parent
phases=['joined-content-focused-05.py','joined-content-legacy-02.py','joined-content-controls-02.py']
rows=[]
for phase in phases:
 print('Starting '+phase,flush=True)
 result=subprocess.run([sys.executable,str(E/phase)],cwd=Path(r'D:\Projects\Factorio\factorio-launcher'),env=dict(os.environ))
 rows.append(dict(phase=phase,exit_code=result.returncode))
 (E/'joined-content-qualification-sequence-01.json').write_text(json.dumps(rows,indent=2)+chr(10),encoding='utf-8')
 if result.returncode:sys.exit(result.returncode)
print('Bounded focused, legacy and native/static controls finished',flush=True)
