import hashlib,json,os,sys,ast
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent;sys.path.insert(0,str(R));from tools import provider_canary_process as owned
packet=E/'joined-content-source-draft-09.json';source=json.loads(packet.read_bytes());assert all(hashlib.sha256((R/n).read_bytes()).hexdigest()==h for n,h in source['files'].items());build=json.loads((E/'joined-content-build-06.json').read_bytes());assert build['ok'] and build['exit_code']==0 and build['source_packet_sha256']==hashlib.sha256((E/'joined-content-source-draft-08.json').read_bytes()).hexdigest();old=json.loads((E/'joined-content-source-draft-08.json').read_bytes());assert all(source['files'][n]==h for n,h in old['files'].items() if n!='tests/test_make_ready_locked_content.py');cli=W/'native-developer/Release/facman.exe';assert hashlib.sha256(cli.read_bytes()).hexdigest()==build['cli_sha256']
env=dict(os.environ,FACMAN_CLI_EXE=str(cli),TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONPATH=str(R/'tests')+os.pathsep+str(R),UseSharedCompilation='false',MSBUILDDISABLENODEREUSE='1')
tree=ast.parse((R/'tests/test_make_ready_locked_content.py').read_text(encoding='utf-8'));names=['test_make_ready_locked_content.'+c.name+'.'+m.name for c in tree.body if isinstance(c,ast.ClassDef) for m in c.body if isinstance(m,ast.FunctionDef) and m.name.startswith('test_') and m.name!='test_changed_protected_inputs_and_unverifiable_content_stop_before_later_owners'];assert len(names)==13
r=owned.command([sys.executable,'-m','unittest',*names,'-v','-f'],cwd=R,environment=env,timeout=600,directory=E/'joined-content-focused-owned-03',output_limit=4*1024**2,wait_for_job_empty_after_primary=True)
row=dict(ok=r.ok,receipt=str(r.directory/'receipt.json'),exit_code=r.returncode,termination=r.receipt['termination'],primary_stopped=r.receipt['primary_stopped'],job_empty=r.receipt['job_empty_observed'],job_terminated=r.receipt['job_terminated'],cli_sha256=build['cli_sha256'],source_packet_sha256=hashlib.sha256(packet.read_bytes()).hexdigest(),mode='remaining13_fail_fast',reused_pass='focused02 unchanged protected-input method six subcases; normal empty Job',native_source_packet_sha256=build['source_packet_sha256'],test_names=names)
(E/'joined-content-focused-03.json').write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8');print(json.dumps(row))
for line in r.stderr.decode('utf-8',errors='replace').splitlines():
 if line:print(line[:500])
 if len(line)>500:print('[Long diagnostic line truncated here; complete bytes retained in stderr.raw]')
if r.stdout:print(r.stdout.decode('utf-8',errors='replace')[-2000:])
sys.exit(0 if r.ok else 1)
