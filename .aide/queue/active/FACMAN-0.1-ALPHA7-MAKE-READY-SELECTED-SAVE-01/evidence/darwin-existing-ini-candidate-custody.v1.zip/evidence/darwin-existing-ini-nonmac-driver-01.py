import hashlib,json,os,shutil,subprocess,sys,time,traceback,re,shlex,xml.etree.ElementTree as ET
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
sys.path.insert(0,str(R))
from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',CMAKE_BUILD_PARALLEL_LEVEL='2')
out=E/'darwin-existing-ini-nonmac-pipeline-01.json';assert not out.exists()
linux_e='/mnt/d/'+str(E)[3:].replace('\\','/')
record=dict(status='PREFLIGHT',commands=[],reserve_bytes=12*1024**3,planned_peak_bytes=2*1024**3,new_roots=0,new_clones=0,new_worktrees=0)
def save():out.write_text(json.dumps(record,indent=2)+'\n')
probe='''import os,json
names={'cmake','ninja','g++','c++','cc1plus','clang','clang++','ctest','facman'};active=[]
for name in os.listdir('/proc'):
 if name.isdigit():
  try:
   if open('/proc/'+name+'/comm').read().strip() in names:active.append(dict(pid=int(name),command=open('/proc/'+name+'/cmdline','rb').read().decode(errors='replace').replace(chr(0),' ')))
  except FileNotFoundError:pass
print(json.dumps(dict(mount_namespace=os.readlink('/proc/self/ns/mnt'),active=active)))'''
query="$all=@(Get-CimInstance Win32_Process); @($all | Where-Object { $_.Name -match '^(cl|clang|link|ninja|ctest)\\.exe$' -or ($_.Name -eq 'cmake.exe' -and $_.CommandLine -like '*--build*') -or ($_.Name -eq 'MSBuild.exe' -and $_.CommandLine -notlike '*/nodemode:*') } | Select-Object Name,ProcessId,ParentProcessId,CommandLine) | ConvertTo-Json -Depth 4 -Compress -AsArray"
def census():
 windows=json.loads(subprocess.check_output(['pwsh','-NoProfile','-Command',query],text=True,timeout=45) or '[]')
 linux=json.loads(subprocess.check_output(['wsl','-d','Ubuntu-24.04','-u','root','--','python3','-B','-c',probe],text=True,timeout=45))
 return dict(windows=windows,linux=linux)
a=json.loads((E/'darwin-existing-ini-nonmac-source-assurance-01.json').read_bytes());F=E/'darwin-existing-ini-frozen-02.json';assert sha(F)=='0cecaeca2c60d5ca289afc0ae0b323414e4152d3e7bb1f18a7f8c7f90154c9a4'
B=W/'native-developer';L=W/'native-save-context-linux';budget=None
lexer=re.compile(json.loads((E/'posix-retained-rewrite-windows-scoped-reuse-01.json').read_bytes())['corrected_runtime_preprocessed_proofs'][0]['lexer_pattern'])
def bound():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==a['base']
 assert hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=R)).hexdigest()==a['staged_entries_sha256']
 assert subprocess.run(['git','diff','--cached','--quiet',a['staged_tree'],'--'],cwd=R).returncode==0
 assert not (R/'.git/MERGE_HEAD').exists()
 for n,h in a['source_files_sha256'].items():assert sha(R/n)==h,n
 assert sha(L/'facman')==a['reuse']['cli_sha256']
 for n,h in a['reuse']['native_images_sha256'].items():assert sha(L/n)==h,n
 for root,pin in ((W/'providers/universal-launcher-5479939ca5cb','5479939ca5cb'),(W.parent/'task-facman-u-507ecf4b41/providers/universal-setup-2749a15b835a','2749a15b835a')):
  assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip().startswith(pin)
  assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=root,text=True).strip()
def run(label,argv,timeout=240):
 bound();result=owned.command([str(x) for x in argv],cwd=R,environment=dict(os.environ),timeout=timeout,budget=budget,directory=E/('darwin-existing-ini-nonmac-'+label+'-execution-01'),output_limit=32*1024*1024)
 record['commands'].append(dict(label=label,argv=[str(x) for x in argv],exit=result.returncode,receipt=str(result.directory/'receipt.json'),receipt_sha256=sha(result.directory/'receipt.json'),stdout_sha256=sha(result.directory/'stdout.raw'),stderr_sha256=sha(result.directory/'stderr.raw'),primary_stopped=result.receipt['primary_stopped'],job_empty=result.receipt['job_empty_observed']));save()
 assert result.ok and result.receipt['primary_stopped'] and result.receipt['job_empty_observed'],label
 bound();return result.directory/'stdout.raw'
try:
 record.update(status='PREFLIGHT_NON_MAC_REUSE',base_head=a['base'],frozen_packet_sha256=sha(F),source_assurance_sha256=sha(E/'darwin-existing-ini-nonmac-source-assurance-01.json'),candidate_files_sha256=a['frozen_files_sha256'],source_files=1947,staged_entries_sha256=a['staged_entries_sha256'],proofs=[],no_configure_or_build=True,actual_macos_native_qualification=False,mandatory_mac_methods_pending=14,linux_prior_qualification_reuse=a['reuse'])
 bound();record['admission_wait_observations']=[];deadline=time.monotonic()+7200
 while True:
  record['before']=census()
  if not record['before']['windows'] and not record['before']['linux']['active']:break
  record['status']='WAITING_FOREIGN_NATIVE_UNTOUCHED';record['admission_wait_observations'].append(dict(at=time.time(),census=record['before']));save();assert time.monotonic()<deadline;time.sleep(60)
 record['free_bytes_before']=shutil.disk_usage(W).free;assert record['free_bytes_before']>=record['reserve_bytes']+record['planned_peak_bytes'];budget=owned.Budget(2700,2400)
 ninja=L/'build.ninja';rules=L/'CMakeFiles/rules.ninja';ninja_lines=ninja.read_text().splitlines();record['linux_config_sha256']={str(ninja):sha(ninja),str(rules):sha(rules)}
 metadata_path=next((B/'CMakeFiles').glob('*/CMakeCXXCompiler.cmake'));cl=Path(re.search(r'set\(CMAKE_CXX_COMPILER "([^"]+)"\)',metadata_path.read_text())[1]);vcvars=next(p for p in cl.parents if p.name.upper()=='VC')/'Auxiliary/Build/vcvarsall.bat'
 project=B/'runtime/factorio/flb_factorio_instance_static.vcxproj';ns={'m':'http://schemas.microsoft.com/developer/msbuild/2003'};xml=ET.parse(project).getroot();group=next(n for n in xml.findall('m:ItemDefinitionGroup',ns) if "Release|x64" in n.get('Condition',''));cc=group.find('m:ClCompile',ns)
 includes=[n for n in cc.find('m:AdditionalIncludeDirectories',ns).text.split(';') if not n.startswith('%(')];defines=[n for n in cc.find('m:PreprocessorDefinitions',ns).text.split(';') if not n.startswith('%(')];assert all('$(' not in n and '%' not in n for n in includes+defines)
 record['windows_config']=dict(vcxproj_sha256=sha(project),compiler=str(cl),compiler_sha256=sha(cl),compiler_metadata_sha256=sha(metadata_path),configuration='Release|x64',include_directories=includes,defines=defines)
 for relative in ('runtime/factorio/instance/flb_factorio_instance_model.cpp','runtime/factorio/instance/flb_factorio_configuration_preparation.cpp'):
  name=Path(relative).stem;baseline=E/('darwin-existing-ini-nonmac-'+name+'-baseline-01.cpp');assert not baseline.exists();baseline.write_bytes(subprocess.check_output(['git','show',a['base']+':'+relative],cwd=R))
  line=next(i for i,n in enumerate(ninja_lines) if n.startswith('build runtime/factorio/CMakeFiles/flb_factorio_instance_static.dir/instance/'+name+'.cpp.o:'));fields={}
  for text in ninja_lines[line+1:]:
   if not text:break
   key,value=text.strip().split(' = ',1);fields[key]=value
  linux_flags=shlex.split(fields.get('DEFINES',''))+shlex.split(fields['INCLUDES'])+shlex.split(fields['FLAGS'])
  for platform in ('linux','windows'):
   captures=[]
   for kind,source in (('baseline',baseline),('candidate',R/relative)):
    label=platform+'-'+name+'-'+kind
    if platform=='linux':
     source_linux='/mnt/d/'+str(source)[3:].replace('\\','/');argv=['wsl','-d','Ubuntu-24.04','-u','root','--','env','TMPDIR='+('/mnt/d/'+str(W/'t')[3:].replace('\\','/')),'/usr/bin/c++',*linux_flags,'-E','-P',source_linux]
    else:
     flags=[str(cl),'/nologo','/EP','/TP','/std:c++17',*['/I'+n for n in includes],*['/D'+n for n in defines],str(source)]
     assert all(not any(c in arg for c in '%!\r\n&|<>^') for arg in flags)
     helper=E/('darwin-existing-ini-nonmac-'+label+'-01.cmd');assert not helper.exists();helper.write_bytes(('@echo off\r\ncall "'+str(vcvars)+'" x64 >nul\r\nif errorlevel 1 exit /b %errorlevel%\r\n'+subprocess.list2cmdline(flags)+'\r\nexit /b %errorlevel%\r\n').encode());argv=['cmd.exe','/d','/c',helper]
    captures.append(run(label,argv))
   before=lexer.findall(captures[0].read_text());after=lexer.findall(captures[1].read_text());assert before==after,(platform,relative,'preprocessed token drift')
   record['proofs'].append(dict(platform=platform,path=relative,scope='actual full translation-unit preprocessing',tokens_unchanged=True,token_count=len(after),token_sha256=hashlib.sha256(json.dumps(after,separators=(',',':')).encode()).hexdigest(),captures=[dict(path=str(p),sha256=sha(p)) for p in captures],baseline_source_sha256=sha(baseline),candidate_source_sha256=sha(R/relative)));save()
 assert len(record['proofs'])==4
 argv=['wsl','-d','Ubuntu-24.04','-u','root','--','env','FACMAN_PARENT_MOUNT_NAMESPACE='+record['before']['linux']['mount_namespace'],'timeout','--signal=TERM','--kill-after=15s','1200s','unshare','--mount','--pid','--fork','--mount-proc','--kill-child=SIGKILL','python3','-B',linux_e+'/darwin-existing-ini-boundary-linux-driver-01.py']
 run('boundary',argv,1260)
 boundary=json.loads((E/'darwin-existing-ini-boundary-linux-result-01.json').read_bytes());tests=json.loads((E/'darwin-existing-ini-boundary-result-01.json').read_bytes());assert boundary['status'].startswith('PASS_') and tests['tests']==1 and not tests['skips'] and tests['failures']==tests['errors']==0
 record.update(status='PASS_SCOPED_DARWIN_OWNER_NON_MAC_QUALIFICATION',linux_runtime_tokens_unchanged=True,windows_runtime_tokens_unchanged=True,actual_linux_boundary_passed=1,mac_static_validation=tests['mac_static_validation'],boundary_result_sha256=sha(E/'darwin-existing-ini-boundary-linux-result-01.json'),boundary_worker_result_sha256=sha(E/'darwin-existing-ini-boundary-result-01.json'),drain=dict(namespace_empty=not boundary['remaining_namespace_processes'],private_fixture_unmounted=boundary['private_mount_absent'],private_native_bind_unmounted=boundary['native_parent_unmounted'],fixture_custody_sha256=boundary['fixture_custody_sha256']))
except BaseException as exc:record.update(status='ACTIONABLE_DARWIN_OWNER_NON_MAC_QUALIFICATION_FAILURE',error=str(exc),traceback=traceback.format_exc())
finally:
 bound()
 for path,h in a['preserved_windows_and_provider_files_sha256'].items():assert sha(path)==h,path
 record['source_binary_windows_cache_provider_hashes_preserved']=True;record['after']=census();record['free_bytes_after']=shutil.disk_usage(W).free
 record['custody']=[dict(path=str(F),sha256=sha(F)),dict(path=str(E/'darwin-existing-ini-independent-source-review-02.json'),sha256=sha(E/'darwin-existing-ini-independent-source-review-02.json')),dict(path=str(E/'darwin-existing-ini-nonmac-source-assurance-01.json'),sha256=sha(E/'darwin-existing-ini-nonmac-source-assurance-01.json')),dict(path=str(Path(__file__).resolve()),sha256=sha(__file__)),*[dict(path=c['receipt'],sha256=c['receipt_sha256']) for c in record['commands']]]
 for filename in ('darwin-existing-ini-boundary-linux-driver-01.py','darwin-existing-ini-boundary-worker-01.py','darwin-existing-ini-boundary-linux-result-01.json','darwin-existing-ini-boundary-result-01.json','darwin-existing-ini-boundary-fixture-custody-01.tar'):
  path=E/filename
  if path.exists():record['custody'].append(dict(path=str(path),sha256=sha(path)))
 save();terminal=E/'darwin-existing-ini-nonmac-qualification-01.json';assert not terminal.exists();terminal.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(dict(status=record['status'],terminal_sha256=sha(terminal),proof_count=len(record['proofs']),boundary=record.get('actual_linux_boundary_passed',0),error=record.get('error'))));raise SystemExit(0 if record['status'].startswith('PASS_') else 1)
