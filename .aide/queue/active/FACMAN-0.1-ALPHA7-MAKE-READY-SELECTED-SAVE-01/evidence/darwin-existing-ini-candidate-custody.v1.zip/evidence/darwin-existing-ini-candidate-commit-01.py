import hashlib,json,os,subprocess,sys,traceback,zipfile
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.safecrlf',GIT_CONFIG_VALUE_0='false')
sys.dont_write_bytecode=True;sys.path.insert(0,str(R));from tools import provider_canary_process as owned
BASE='7f4df34e66dbefed970c00d02b858929191955d9';BRANCH='task/facman-darwin-existing-ini-01';Q='.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
out=E/'darwin-existing-ini-candidate-commit-result-01.json';assert not out.exists()
record=dict(status='SEALING_REVIEWED_DARWIN_CANDIDATE_REQUIRED_MAC_RUNTIME_PENDING',commands=[],goal_status_mutated=False,new_optional_campaigns=0)
def save():out.write_text(json.dumps(record,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
def run(label,args,timeout=180):
    r=owned.command(args,cwd=R,environment=dict(os.environ),timeout=timeout,directory=E/('darwin-existing-ini-candidate-commit01-'+label),output_limit=2*1024*1024)
    record['commands'].append(dict(label=label,exit=r.returncode,receipt_sha256=sha(r.directory/'receipt.json')));save()
    assert r.ok and r.receipt['primary_stopped'] and r.receipt['job_empty_observed'],(label,r.stderr[-1600:].decode(errors='replace'));return r
try:
    assert git('rev-parse','HEAD')==BASE and git('branch','--show-current')==BRANCH and not git('diff','--cached','--name-only')
    summary_path=E/'darwin-existing-ini-nonmac-qualification-01.json';assert sha(summary_path)=='1acc5ade7afbb13831df11475d0527df2078ce000ba1cf35361e59ce7f028369'
    a=json.loads(summary_path.read_bytes());assert a['status']=='PASS_SCOPED_DARWIN_OWNER_NON_MAC_QUALIFICATION' and a['base_head']==BASE
    for n,h in a['candidate_files_sha256'].items():assert sha(R/n)==h,n
    assurance_path=E/'darwin-existing-ini-nonmac-source-assurance-01.json';assert sha(assurance_path)==a['source_assurance_sha256']
    assurance=json.loads(assurance_path.read_bytes())
    for n,h in assurance['source_files_sha256'].items():assert sha(R/n)==h,n
    assert len(assurance['source_files_sha256'])==1947
    assert hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=R)).hexdigest()==a['staged_entries_sha256']
    assert len(a['proofs'])==4 and all(x['tokens_unchanged'] and x['scope']=='actual full translation-unit preprocessing' for x in a['proofs'])
    assert a['linux_runtime_tokens_unchanged'] and a['windows_runtime_tokens_unchanged'] and a['actual_linux_boundary_passed']==1
    assert not a['actual_macos_native_qualification'] and a['mandatory_mac_methods_pending']==14 and a['mac_static_validation']['mac_test_methods_executed']==0
    assert all(a['drain'][k] for k in ('namespace_empty','private_fixture_unmounted','private_native_bind_unmounted')) and a['source_binary_windows_cache_provider_hashes_preserved']
    review_source=E/'darwin-existing-ini-independent-source-review-02.json';review_data=json.loads(review_source.read_bytes());assert sha(review_source)=='d292d431c2cf23e2039aef30d04c7dc33f12df767149d07a0a903d58d6bfba2e' and review_data['frozen_packet_sha256']==a['frozen_packet_sha256']
    task_paths=set(a['candidate_files_sha256']);assert set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())==task_paths
    archive=R/Q/'evidence/darwin-existing-ini-candidate-custody.v1.zip';evidence=R/Q/'evidence/darwin-existing-ini-candidate.v1.json';assert not archive.exists() and not evidence.exists()
    manifest={}
    for item in a['custody']:
        p=Path(item['path']);assert p.is_relative_to(E) and sha(p)==item['sha256'];manifest[p.relative_to(E).as_posix()]=item['sha256']
    for name in (summary_path.name,review_source.name,'darwin-existing-ini-frozen-01.json','darwin-existing-ini-frozen-01.patch','darwin-existing-ini-candidate-commit-01.py'):manifest[name]=sha(E/name)
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr('custody-manifest.json',json.dumps(manifest,indent=2,sort_keys=True)+'\n')
        for n in sorted(manifest):z.write(E/n,'evidence/'+n)
    with zipfile.ZipFile(archive) as z:
        for n,h in manifest.items():assert hashlib.sha256(z.read('evidence/'+n)).hexdigest()==h
    evidence.write_text(json.dumps(dict(schema='facman.darwin_existing_ini_reviewed_candidate.v1',base_head=BASE,files_sha256=a['candidate_files_sha256'],independent_review_sha256=sha(review_source),nonmac_qualification_sha256=sha(summary_path),actual_full_tu_proofs=[dict(platform=x['platform'],path=x['path'],token_sha256=x['token_sha256'],token_count=x['token_count']) for x in a['proofs']],actual_linux_boundary_passed=1,nonmac_images_unchanged=True,no_rebuild=True,actual_mac_methods_run=0,mandatory_mac_methods_pending=14,actual_mac_runtime_qualified=False,required_new_source_ci_pending=True,admission_merge_requires_actual_mac_pass=True,custody=archive.name,custody_sha256=sha(archive),custody_members=len(manifest)+1,authority_delta='Darwin confirmed existing-INI reconciliation and journal recovery candidate via existing owner guards',darwin_missing_file_publication_admitted=False,physical_apfs=False,power_loss=False,game=False,human=False,full_make_ready=False,beta=False,rc=False),indent=2)+'\n')
    with (R/Q/'ExecPlan.md').open('a',encoding='utf-8',newline='\n') as f:
        f.write('\n### Darwin existing-INI reviewed candidate\n\nContinue from checked Linux owner dev7f4df34e. The candidate expands the same planner/reconcile/recovery and POSIX pause guards to Apple without changing the retained primitive. Four actual full translation-unit preprocessing comparisons (GNU and pinned MSVC, both affected runtime units) have identical tokens; one affected Linux admission boundary passes on the preserved image. Other successful non-Mac campaigns are reused rather than rebuilt. Independent review corrected an ACL oracle that assumed normalized presence; pinned Apple Libc returns a nonzero bitmask, now handled without masking failed reads. Fourteen mandatory Mac methods cover ordinary intent/scopes, full-nanosecond birthtime/flags/xattr/ACL absence/presence, all durable boundaries and real SIGKILL, current and unsafe inputs, terminal no-write and demonstrated metadata/checkpoint denial. None has run locally. The existing mandatory macOS native/promotion job must actually run and pass them before integration. Unsupported platform skips, source review and non-Mac equality do not qualify Mac behavior. Missing-file publication on Darwin, named APFS hosts, power loss, game, human, full Make Ready/Beta/RC remain open.\n\nEvidence: `evidence/darwin-existing-ini-candidate.v1.json` and its hash-closed custody archive.\n')
    paths=task_paths|{Q+'/ExecPlan.md',Q+'/evidence/'+evidence.name,Q+'/evidence/'+archive.name};assert set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())==paths
    for label in ('policy','detect','plan'):run(label,['py','-3','-B','.aide/scripts/aide_lite.py','git',label])
    run('strict',['py','-3','-B','tools/strict_check.py'],1800)
    message='feat(readiness): reconcile existing macOS INI in place\n\nReuse retained original custody and durable owner recovery. Actual Mac\nruntime qualification remains mandatory before checked integration.\n\nWork-Item: FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01\nEvidence-Ref: '+Q+'/evidence/'+evidence.name+'\n'
    msg=E/'darwin-existing-ini-candidate-commit-message-01.txt';msg.write_text(message,encoding='utf-8',newline='\n');run('message',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--message',message])
    changes=[dict(path=n,state='content',sha256=sha(R/n),git_blob_oid=git('hash-object','--path',n,str(R/n)),ownership='task_owned') for n in sorted(paths)]
    snapshot=hashlib.sha256((json.dumps(changes,indent=2,sort_keys=True,separators=(',',': '))+'\n').encode()).hexdigest()
    review=E/'darwin-existing-ini-candidate-commit-review-01.json';review.write_text(json.dumps(dict(schema_version='aide.git-commit-review.v1',verdict='PASS',reviewer='/root',runtime_author='/root/darwin_existing_ini_implementation',non_authoring=True,branch=BRANCH,base_commit=BASE,snapshot_sha256=snapshot,message_sha256=sha(msg),independent_source_review_sha256=sha(review_source),nonmac_qualification_sha256=sha(summary_path),review='Apple-only owner reuse and14mandatoryMacoracles independently reviewed; actualGNU/MSVCfullTUequality and1Linuxboundary; no Macruntimeclaim; requiredMacnative/promotion qualification beforeintegration'),indent=2)+'\n')
    classification=E/'darwin-existing-ini-candidate-commit-classification-01.json';classification.write_text(json.dumps(dict(schema_version='aide.git-commit-classification.v1',branch=BRANCH,base_commit=BASE,work_item='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01',snapshot_sha256=snapshot,message_sha256=sha(msg),changed_paths=changes,reviews=[dict(path=str(review),sha256=sha(review),verdict='PASS')]),indent=2)+'\n')
    helper=['py','-3','-B','.aide/scripts/aide_lite.py','git','commit-plan','--classification',str(classification),'--message-file',str(msg)]
    run('plan-stage',helper);run('stage',['git','add','--',*sorted(paths)]);run('diff',['git','diff','--cached','--check']);run('plan-commit',helper)
    assert git('rev-parse','HEAD')==BASE;run('commit',['git','commit','-F',str(msg)])
    run('range',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--range',BASE+'..HEAD']);assert not git('status','--porcelain')
    record.update(status='COMMITTED_REVIEWED_DARWIN_OWNER_CANDIDATE',source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),review_sha256=sha(review),evidence_sha256=sha(evidence),actual_mac_runtime_qualified=False,remote_not_pushed=True)
except BaseException as exc:record.update(status='ACTIONABLE_DARWIN_CANDIDATE_COMMIT_FAILURE',error=str(exc),traceback=traceback.format_exc())
finally:save();print(json.dumps({k:v for k,v in record.items() if k!='commands'},indent=2))
raise SystemExit(0 if record['status']=='COMMITTED_REVIEWED_DARWIN_OWNER_CANDIDATE' else 1)
