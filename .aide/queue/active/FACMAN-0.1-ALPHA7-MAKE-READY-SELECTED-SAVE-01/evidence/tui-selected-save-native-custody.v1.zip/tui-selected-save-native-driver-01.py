import hashlib,json,os,subprocess,sys,time,traceback
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e');E=W/'evidence';B=W/'native-developer'
sys.path.insert(0,str(R));from tools import native_build,provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads((E/'tui-selected-save-source-assurance-01.json').read_bytes())
assert a['verdict']=='PASS_FOR_SCOPED_NATIVE_QUALIFICATION' and a['independent'] and a['non_authoring']
def bound():
 assert subprocess.check_output(['git','branch','--show-current'],cwd=R,text=True).strip()==a['branch']
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==a['base']
 for n,h in a['source_files_sha256'].items():assert sha(R/n)==h,n
bound()
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',CMAKE_BUILD_PARALLEL_LEVEL='2',FACMAN_MIN_FREE_GIB='12',MSBUILDDISABLENODEREUSE='1')
out=E/'tui-selected-save-native-result-01.json';assert not out.exists()
result=dict(schema='facman.tui_selected_save_native_qualification.v1',status='waiting_for_foreign_native_work',source_assurance_sha256=sha(E/'tui-selected-save-source-assurance-01.json'),commands=[],new_roots=0,new_worktrees=0,new_clones=0,product_candidates=0,goal_status_mutated=False)
def save():out.write_text(json.dumps(result,indent=2)+'\n')
save();counter=0;previous=None
try:
 while True:
  counter+=1
  query="$p=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(cl|clang|link|ninja|ctest)\\.exe$' -or ($_.Name -eq 'cmake.exe' -and $_.CommandLine -like '*--build*') -or ($_.Name -eq 'MSBuild.exe' -and $_.CommandLine -notlike '*/nodemode:*') } | Select-Object Name,ProcessId,CreationDate); ConvertTo-Json -InputObject $p -Compress"
  check=owned.command(['pwsh','-NoProfile','-Command',query],cwd=R,timeout=45,directory=E/f'tui-selected-save-native-preflight01-{counter:03d}')
  assert check.ok;active=json.loads(check.stdout)
  if not active:break
  if active!=previous:result['foreign_native_jobs']=active;save();previous=active;print('Waiting for foreign native job; preserved untouched.',flush=True)
  time.sleep(min(60*counter,600))
 native_build.require_disk_reserve(B);bound()
 for claim in a['preserved_qualified_images']:
  source=Path(claim['source']);target=Path(claim['destination'])
  assert source.resolve().is_relative_to(W.resolve()) and target.parent.resolve()==E.resolve() and not target.exists()
  assert not source.is_symlink() and sha(source)==claim['sha256']
  moved=subprocess.run(['pwsh','-NoProfile','-Command','param($s,$t) Move-Item -LiteralPath $s -Destination $t',str(source),str(target)],capture_output=True,text=True)
  assert moved.returncode==0,moved.stderr
  assert sha(target)==claim['sha256'] and not source.exists()
 result['preserved_prior_images_by_move']=a['preserved_qualified_images'];result['status']='qualifying_header_safe_consumer_rebuild';save()
 budget=owned.Budget(7200,3600)
 def run(name,args,timeout):
  r=owned.command([str(x) for x in args],cwd=R,environment=dict(os.environ),timeout=timeout,budget=budget,output_limit=8*1024*1024,directory=E/f'tui-selected-save-{name}-execution-01',wait_for_job_empty_after_primary=False)
  result['commands'].append(dict(name=name,exit=r.returncode,termination=r.receipt['termination'],primary_stopped=r.receipt['primary_stopped'],job_empty=r.receipt['job_empty_observed'],receipt=str(r.directory/'receipt.json'),sha256=sha(r.directory/'receipt.json')));save()
  assert r.ok and r.receipt['primary_stopped'] and r.receipt['job_empty_observed'],name
  return r
 run('build',a['build_command'],3600)
 bound()
 exe=B/'Release/facman.exe';result['cli_sha256']=sha(exe)
 for n,h in a['provider_sha256'].items():assert sha(B/'Release'/n)==h,n
 result['provider_sha256']=a['provider_sha256'];save()
 run('native',['ctest','--test-dir',B,'-C','Release','-R','^(facman_frontend_session_smoke|facman_tui_product_model_smoke|facman_tui_smoke)$','--output-on-failure'],600)
 os.environ.update(FACMAN_CLI_EXE=str(exe),FACMAN_TUI_EXE=str(exe),PYTHONPATH=os.pathsep.join([str(R),str(R/'tests')]))
 run('ordinary',['py','-3','-B','-m','unittest','-v','test_tui_product.TuiProductTests.test_ordinary_observation_choice_preserves_empty_workspace','test_tui_product.TuiProductTests.test_ordinary_selected_save_preparation_and_changed_observation_confirmation','test_tui_product.TuiProductTests.test_ordinary_shell_pages_launch_deck_and_advanced_handoff'],600)
 run('conpty',['py','-3','-B','-m','unittest','-v','test_tui_conpty'],600)
 run('strict',['py','-3','-B','tools/strict_check.py'],1800)
 run('aide',['py','-3','-B','.aide/scripts/aide_lite.py','test'],600)
 bound();result.update(status='PASS_SCOPED_NATIVE_ORDINARY_TUI_SELECTED_SAVE',human_qualified=False,produced_package_qualified=False,other_host_qualified=False,game_executed=False,play_qualified=False,workunit_closed=False,beta_qualified=False)
except BaseException as error:result.update(status='ACTIONABLE_FAILURE_RETAIN_OWNED_EVIDENCE',error=str(error),traceback=traceback.format_exc())
finally:save();print(json.dumps({k:v for k,v in result.items() if k not in ('commands','foreign_native_jobs')},indent=2))
