import hashlib,json,zipfile
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e\evidence');B=E.parent/'native-developer';Q=R/'.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads((E/'tui-selected-save-source-assurance-03.json').read_bytes());n=json.loads((E/'tui-selected-save-native-result-05.json').read_bytes());g=json.loads((E/'tui-selected-save-repository-result-06.json').read_bytes())
assert a['verdict']=='PASS_SKIP_LABEL_ONLY_REUSE' and g['status']=='PASS_REPOSITORY_GATES_WITH_REUSED_NATIVE_ORDINARY_AND_CONPTY'
for name,digest in a['source_files_sha256'].items():assert sha(R/name)==digest,name
assert sha(B/'Release/facman.exe')==g['cli_sha256']==n['cli_sha256']
for c in [x for x in n['commands'] if x['name']!='strict']+g['commands']:
 assert c['exit']==0 and c['primary_stopped'] and c['job_empty']
 assert sha(c['receipt'])==c['sha256']
archive=Q/'evidence/tui-selected-save-native-custody.v1.zip';receipt=Q/'evidence/tui-selected-save-native.v1.json';assert not archive.exists() and not receipt.exists()
inputs={};omitted=[]
for top in sorted(E.glob('tui-selected-save-*')):
 for f in sorted(top.rglob('*')) if top.is_dir() else [top]:
  if not f.is_file():continue
  assert f.resolve().is_relative_to(E.parent.resolve()) and not f.is_symlink()
  size=f.stat().st_size
  if f.suffix.lower()=='.exe' or size>1024*1024:omitted.append(dict(path=str(f),sha256=sha(f),bytes=size));continue
  inputs[f.relative_to(E).as_posix()]=f
assert sum(f.stat().st_size for f in inputs.values())<8*1024*1024
manifest={name:dict(bytes=f.stat().st_size,sha256=sha(f)) for name,f in inputs.items()}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,f in inputs.items():z.writestr(name,f.read_bytes())
 z.writestr('custody-manifest.v1.json',json.dumps(dict(schema='facman.tui_selected_save_custody.v1',files=manifest,local_only=omitted),indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,claim in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==claim['sha256']
payload=dict(schema='facman.tui_selected_save_native_acceptance.v1',status='PASS_SCOPED_SOURCE_NATIVE_ORDINARY_TUI',
 work_item=Q.name,base=a['base'],branch=a['branch'],source_files_sha256=a['source_files_sha256'],cli_sha256=n['cli_sha256'],provider_sha256=n['provider_sha256'],
 source_review=dict(reviewer='/root',author='/root/tui_selected_save_impl',independent=True,non_authoring=True,assurance_sha256=sha(E/'tui-selected-save-source-assurance-03.json')),
 observations=['Ordinary linear and fullscreen m/s controls select Menu/Selected Save; typed frontend query and action carry exact backend observation/revision.',
 'Changing observation clears form, revision and pending confirmation. Returning to Selected Save requires another explicit confirmation.',
 'Actual ordinary Selected Save MakeReady completes routing then context in fresh sessions. Requests, receipts and complete owner journals bind intent/revision/plan/operation/attempt; config bytes/inode and save/profile/version/lock match, other input bytes preserved.',
 'Menu still permits routing repair and then refuses selected-save preparation. Empty-workspace observation/navigation does not create workspace.',
 'Three native frontend/TUI smokes, three focused ordinary tests, both ConPTY navigation/resize/cancel/no-color tests, strict and AIDE pass.'],
 qualification=dict(native_result_sha256=sha(E/'tui-selected-save-native-result-05.json'),repository_result_sha256=sha(E/'tui-selected-save-repository-result-06.json'),native_smokes=3,ordinary_methods=3,conpty_methods=2,additional_builds_after_label_only_fix=0),
 failures=['Source review corrected test navigation from Refresh to actual MakeReady and fixed Menu oracle before build.',
 'Three root runner preflights failed before native dispatch (PowerShell argument binding/retained output name); all records preserved.',
 'First header-safe consumer build failed sole C2110 in observation text; one std::string conversion corrected, successful backend/frontend libraries reused.',
 'First strict gate rejected unlabeled platform skip; only unsupported label corrected, identical condition and passing native/function/ConPTY evidence reused.'],
 compatibility='Experimental static C++ FrontendSession request layout extended; all current consumers rebuilt. Existing string negotiation/default Menu and normative CLI/RPC/provider ABI/pins preserved.',
 limitations=['Source-native synthetic engineering acceptance only; corrected produced TUI package, exact Linux/Intelmac packages/PTY hosts, human and game acceptance remain open.',
 'Configuration and selected-context owner effects remain Windows qualified. POSIX publication identity/recovery and existing-INI behavior remain missing; no gate simply enabled.',
 'Full readiness, Play/permit, complete MakeReady WorkUnit and Beta remain unqualified.'],
 custody=dict(path=archive.relative_to(R).as_posix(),sha256=sha(archive),bytes=archive.stat().st_size,members=len(inputs)+1),
 workunit_closed=False,beta_qualified=False,release_qualified=False)
receipt.write_text(json.dumps(payload,indent=2)+'\n',encoding='utf-8',newline='\n')
with (Q/'ExecPlan.md').open('a',encoding='utf-8',newline='\n') as f:
 f.write('\n## 2026-10-13 — ordinary TUI selected-save observation\n\n'
 '- Added Menu/Selected Save controls to both renderers, optional typed frontend query intent, backend-selected snapshot intent and revision-bound action dispatch. Observation changes invalidate confirmation and form; default Menu remains compatible.\n'
 '- Three native smokes, three focused ordinary tests and both fullscreen ConPTY tests pass. Real ordinary inputs perform the two selected-save preparation owners with fresh confirmations and exact receipt/journal/plan identities, while preserving config inode and unrelated inputs. Menu routing and subsequent refusal, cancellation, empty workspace, resize and no-color behavior are retained.\n'
 '- Independent review, failed source/runner/build/skip-label stages and exact images/postimages are in evidence/tui-selected-save-native.v1.json and hash-closed custody. Experimental C++ frontend consumers were rebuilt; no normative CLI/RPC/provider ABI or pin changed.\n'
 '- This accepts source-native Windows behavior only. Produced corrected TUI and Linux/Intel-mac host/package acceptance, POSIX owner implementation, real Play/human experience and complete MakeReady/Beta remain open.\n')
out=E/'tui-selected-save-persistence-review-06.json';assert not out.exists()
out.write_text(json.dumps(dict(schema='facman.tui_selected_save_persistence_review.v1',verdict='PASS',reviewer='/root',runtime_author='/root/tui_selected_save_impl',receipt_sha256=sha(receipt),archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,members=len(inputs)+1,status_or_authority_promoted=False),indent=2)+'\n')
print(json.dumps(dict(receipt=receipt.relative_to(R).as_posix(),archive_bytes=archive.stat().st_size,members=len(inputs)+1)))
