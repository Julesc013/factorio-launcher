import hashlib,json,os,sys
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e\evidence');W=E.parent
sys.path.insert(0,str(R));from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads((E/'pack-partial-recovery-original-portable-admission-06.json').read_bytes());exe=Path(a['executable']);case=W/'make-ready-delivered-live-ui-proof-01/consumer'
assert sha(exe)==a['executable_sha256']
tree=lambda:{p.relative_to(case).as_posix():sha(p) for p in case.rglob('*') if p.is_file()}
before=tree()
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1')
r=owned.command([str(exe),'tui','--ordinary','--plain','--workspace',str(case),'--transport','direct'],cwd=R,environment=dict(os.environ),timeout=60,input_bytes=b'2\nq\n',directory=E/'tui-selected-save-produced-baseline-execution-01')
assert r.ok and r.receipt['primary_stopped'] and r.receipt['job_empty_observed']
assert tree()==before
text=r.stdout.decode('utf-8')
out=E/'tui-selected-save-produced-baseline-result-01.json';assert not out.exists()
out.write_text(json.dumps(dict(schema='facman.tui_selected_save_produced_baseline.v1',source=a['source_commit'],cli_sha256=sha(exe),input='2\\nq\\n',receipt_sha256=sha(r.directory/'receipt.json'),retained_workspace_unchanged=True,stdout_sha256=sha(r.directory/'stdout.raw'),diagnosis='Ordinary Instances TUI has no Selected Save observation selector; no action dispatched in this baseline.',accepted_behavior=False),indent=2)+'\n')
print(text[-6000:])
