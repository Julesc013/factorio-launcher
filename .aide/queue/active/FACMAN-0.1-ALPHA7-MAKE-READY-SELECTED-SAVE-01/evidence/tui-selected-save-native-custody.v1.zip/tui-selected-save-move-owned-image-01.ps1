param([string]$s,[string]$t)
$ErrorActionPreference='Stop'
$rootPath='D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e'
$sourcePath=[IO.Path]::GetFullPath($s)
$targetPath=[IO.Path]::GetFullPath($t)
if(-not $sourcePath.StartsWith($rootPath+'\native-developer\Release\',[StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetDirectoryName($targetPath) -ne $rootPath+'\evidence'){throw 'Move containment refused'}
if(Test-Path -LiteralPath $targetPath){throw 'Preserve existing target'}
Move-Item -LiteralPath $sourcePath -Destination $targetPath
