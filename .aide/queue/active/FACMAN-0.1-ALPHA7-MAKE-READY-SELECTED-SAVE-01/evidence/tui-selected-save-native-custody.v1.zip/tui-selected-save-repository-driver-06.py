import json,hashlib,os,sys
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e\evidence');B=E.parent/'native-developer';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads((E/'tui-selected-save-source-assurance-02.json').read_bytes());p=json.loads((E/'tui-selected-save-source-review-04.json').read_bytes())
files={x['path']:x['sha256'] for x in p['files']}
assert [n for n,h in files.items() if a['source_files_sha256'][n]!=h]==['tests/test_tui_product.py']
for n,h in files.items():assert sha(R/n)==h,n;a['source_files_sha256'][n]=h
a.update(verdict='PASS_SKIP_LABEL_ONLY_REUSE',prior_assurance_sha256=sha(E/'tui-selected-save-source-assurance-02.json'),packet_sha256=sha(E/'tui-selected-save-source-review-04.json'),reuse_native_qualification_sha256=sha(E/'tui-selected-save-native-result-05.json'),
 reuse_reason='The unsupported prefix changes only the declared skip obligation label; os.name condition, source13 compiled runtime, ordinary test inputs/assertions and ConPTY behavior unchanged. Reuse actual passing native/ordinary/fullscreen results; rerun repository gates only.')
out=E/'tui-selected-save-source-assurance-03.json';assert not out.exists();out.write_text(json.dumps(a,indent=2)+'\n')
previous=json.loads((E/'tui-selected-save-native-result-05.json').read_bytes())
assert previous['error']=='strict' and sha(B/'Release/facman.exe')==previous['cli_sha256']
for c in previous['commands']:
 if c['name']!='strict':assert c['exit']==0 and c['primary_stopped'] and c['job_empty']
sys.path.insert(0,str(R));from tools import provider_canary_process as owned
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(E.parent/'t'),TMP=str(E.parent/'t'),PYTHONDONTWRITEBYTECODE='1')
result=dict(schema='facman.tui_selected_save_repository_qualification.v1',status='qualifying_label_only_correction',commands=[],reused_native_result_sha256=sha(E/'tui-selected-save-native-result-05.json'),source_assurance_sha256=sha(out),cli_sha256=previous['cli_sha256'],additional_builds=0,repeated_native_or_functional_tests=0,goal_status_mutated=False)
out=E/'tui-selected-save-repository-result-06.json';assert not out.exists()
def save():out.write_text(json.dumps(result,indent=2)+'\n')
save()
for label,args in [('strict',['py','-3','-B','tools/strict_check.py']),('aide',['py','-3','-B','.aide/scripts/aide_lite.py','test'])]:
 r=owned.command(args,cwd=R,timeout=1800,directory=E/f'tui-selected-save-{label}-execution-06',output_limit=1024*1024)
 result['commands'].append(dict(name=label,exit=r.returncode,primary_stopped=r.receipt['primary_stopped'],job_empty=r.receipt['job_empty_observed'],receipt=str(r.directory/'receipt.json'),sha256=sha(r.directory/'receipt.json')));save()
 assert r.ok and r.receipt['primary_stopped'] and r.receipt['job_empty_observed'],label
for n,h in a['source_files_sha256'].items():assert sha(R/n)==h,n
result.update(status='PASS_REPOSITORY_GATES_WITH_REUSED_NATIVE_ORDINARY_AND_CONPTY',workunit_closed=False,beta_qualified=False);save()
print(json.dumps(result,indent=2))
