"""Consume the completed twelve-command baseline; do not replay setup or queries."""
import hashlib
import json
from pathlib import Path

E = Path(__file__).resolve().parent
W = E/'make-ready-save-context-baseline-01-fixture'
LOG = E/'make-ready-save-context-baseline-01-commands.jsonl'
OUT = E/'make-ready-save-context-baseline-01.json'
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
entries = [json.loads(line) for line in LOG.read_text(encoding='utf-8').splitlines()]
assert len(entries) == 12 and [v['sequence'] for v in entries] == list(range(1,13))
assert all(v['exit_code'] == 0 for v in entries)
payloads = [json.loads(v['stdout'])['payload'] for v in entries]
association = json.loads((W/'instances/save-context/metadata/save-refs/world.zip.save-ref.v1.json').read_text(encoding='utf-8'))
assert association['factorio_version'] == '2.0.77'
assert association['modset_lock_sha256'] != sha(W/'instances/save-context/mods/modset-lock.v1.json')
observations = []
for i,case in enumerate(('unchanged','factorio_version_changed','modset_lock_changed')):
    group = entries[3+i*3:6+i*3]
    reports = payloads[3+i*3:6+i*3]
    assert [v['argv'][4] for v in group] == ['index','inspect','verify']
    assert all(v['saves'][0]['association']['status'] == 'current' for v in reports)
    assert reports[-1]['status'] == 'pass'
    assert all(v['deep_factorio_save_metadata'] == 'unsupported' and not v['mutation_executed'] for v in reports)
    assert all(v['saves'][0]['sha256'] == association['save_sha256'] for v in reports)
    assert not any('context' in key or 'compatibility' in key for key in reports[1]['saves'][0]['association'])
    observations.append(dict(case=case,association_status='current',structural_verify_status='pass',
        context_observation_present=False,save_sha256=association['save_sha256'],
        readonly_inventory_assertions_completed=True))
record = dict(status='CONFIRMED_MISSING_ASSOCIATION_CONTEXT_OBSERVATION',
    inspected_dev='9339459e669f37ad1a5cc09394e3a05eef9350d0',
    CLI_sha256='bc60a62920d48173f743a68cc5dfcd7929598c344c38bc117d48346b1ddf3254',
    original_CLI_producer='b4becdf2e6f0963edf9943a239c591029fe670b7',exact_current_source_native_build=False,
    observed_public_commands=12,commands_sha256=sha(LOG),observations=observations,fixture=str(W),
    adapter_failures_preserved=['Initial adapter did not unwrap normative transport envelope after completed association; setup recovered from three issued commands without replay',
        'All twelve observations and read-only assertions completed; final receipt serialization shadowed argparse namespace with list. This finalizer consumes retained results without command replay'],
    native_builds=0,new_roots=0,new_worktrees=0,candidate_dispatches=0,
    actual_Factorio=False,whole_workunit_closed=False,full_programme_complete=False)
with OUT.open('x',encoding='utf-8',newline='\n') as f:
    f.write(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(status=record['status'],observed_public_commands=12,receipt_sha256=sha(OUT),commands_sha256=sha(LOG))))
