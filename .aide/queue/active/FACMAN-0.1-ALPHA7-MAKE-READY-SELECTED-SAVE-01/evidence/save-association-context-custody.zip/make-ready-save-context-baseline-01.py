"""Observe the missing association-context check through the retained public CLI."""
import hashlib
import argparse
import json
from pathlib import Path
import subprocess
import zipfile

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
CLI = E.parent/'native-developer/Debug/facman.exe'
HEAD = '9339459e669f37ad1a5cc09394e3a05eef9350d0'
W = E/'make-ready-save-context-baseline-01-fixture'
OUT = E/'make-ready-save-context-baseline-01.json'
LOG = E/'make-ready-save-context-baseline-01-commands.jsonl'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(['git',*args],cwd=R).decode('utf-8').strip()


def inventory():
    return {p.relative_to(W).as_posix():sha(p) for p in W.rglob('*') if p.is_file()}


count = 0
def call(*args):
    global count
    argv = [str(CLI),'--workspace',str(W),*args,'--json']
    p = subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=90)
    count += 1
    with LOG.open('a',encoding='utf-8',newline='\n') as f:
        f.write(json.dumps(dict(sequence=count,argv=argv,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr))+'\n')
    assert p.returncode == 0, (args,p.stdout,p.stderr)
    envelope = json.loads(p.stdout)
    assert envelope['schema'] == 'facman.transport_response.v2' and envelope['outcome'] == 'ok'
    return envelope['payload']


assert git('rev-parse','HEAD') == git('rev-parse','origin/dev') == HEAD
assert git('branch','--show-current') == 'dev' and not git('status','--porcelain')
assert sha(CLI) == 'bc60a62920d48173f743a68cc5dfcd7929598c344c38bc117d48346b1ddf3254'
owner = 'runtime/factorio/saves/flb_factorio_save_index.cpp'
assert git('rev-parse',HEAD+':'+owner) == git('rev-parse','b4becdf2e6f0963edf9943a239c591029fe670b7:'+owner)
parser = argparse.ArgumentParser()
parser.add_argument('--resume-after-envelope-projection',action='store_true')
args = parser.parse_args()
assert not OUT.exists()
if args.resume_after_envelope_projection:
    issued = [json.loads(line) for line in LOG.read_text(encoding='utf-8').splitlines()]
    assert len(issued) == 3 and [v['sequence'] for v in issued] == [1,2,3]
    assert all(v['exit_code'] == 0 and v['argv'][0] == str(CLI) and v['argv'][2] == str(W) for v in issued)
    assert issued[-1]['argv'][3:] == ['saves','associate','world.zip','--instance','save-context','--json']
    associated = json.loads(issued[-1]['stdout'])['payload']
    assert associated['status'] == 'associated' and associated['mutation_executed']
    count = 3
else:
    assert not W.exists() and not LOG.exists()
    W.mkdir()
    with LOG.open('x',encoding='utf-8'):
        pass
    call('installs','import',str(R/'tests/fixtures/fake_factorio_install'),'--id','fixture')
    call('instances','create','Save Context','--id','save-context','--install','fixture')
I = W/'instances/save-context'
save = I/'saves/world.zip'
if not args.resume_after_envelope_projection:
    with zipfile.ZipFile(save,'x',compression=zipfile.ZIP_DEFLATED) as z:
        entry = zipfile.ZipInfo('world/level-init.dat',(2026,7,12,0,0,0))
        entry.external_attr = 0o644 << 16
        z.writestr(entry,b'opaque structural save fixture')
manifest = I/'instance.v1.json'
original_manifest = manifest.read_bytes()
lock = I/'mods/modset-lock.v1.json'
if not args.resume_after_envelope_projection:
    assert not lock.exists()
    lock.write_text('{"schema":"factorio.modset_lock.v1","mods":[]}\n',encoding='utf-8',newline='\n')
    associated = call('saves','associate','world.zip','--instance','save-context')
else:
    assert lock.read_text(encoding='utf-8') == '{"schema":"factorio.modset_lock.v1","mods":[]}\n'
assert associated['saves'][0]['association']['status'] == 'current'
sidecar = I/'metadata/save-refs/world.zip.save-ref.v1.json'
original_sidecar = sidecar.read_bytes()
association = json.loads(original_sidecar)
assert association['factorio_version'] == '2.0.77' and association['modset_lock_sha256'] == sha(lock)
observations = []
for case in ('unchanged','factorio_version_changed','modset_lock_changed'):
    if case == 'factorio_version_changed':
        record = json.loads(original_manifest)
        record['factorio_version'] = '2.0.78'
        manifest.write_text(json.dumps(record,separators=(',',':'))+'\n',encoding='utf-8',newline='\n')
    elif case == 'modset_lock_changed':
        manifest.write_bytes(original_manifest)
        lock.write_text('{"schema":"factorio.modset_lock.v1","mods":[],"fixture_change":true}\n',encoding='utf-8',newline='\n')
    before = inventory()
    reports = {}
    for action in ('index','inspect','verify'):
        args = ['saves',action]
        if action != 'index':
            args.append('world.zip')
        reports[action] = call(*args,'--instance','save-context')
        assert reports[action]['saves'][0]['association']['status'] == 'current'
        assert reports[action]['deep_factorio_save_metadata'] == 'unsupported'
    assert reports['verify']['status'] == 'pass' and inventory() == before
    assert sidecar.read_bytes() == original_sidecar
    observations.append(dict(case=case,association_status='current',structural_verify_status='pass',
        context_observation_present=any('context' in key or 'compatibility' in key for key in reports['inspect']['saves'][0]['association']),
        save_sha256=sha(save),association_sha256=sha(sidecar),current_modset_lock_sha256=sha(lock),
        current_factorio_version=json.loads(manifest.read_text(encoding='utf-8'))['factorio_version'],read_only=True))
assert not any(o['context_observation_present'] for o in observations)
record = dict(status='CONFIRMED_MISSING_ASSOCIATION_CONTEXT_OBSERVATION',inspected_dev=HEAD,
    CLI_sha256=sha(CLI),original_CLI_producer='b4becdf2e6f0963edf9943a239c591029fe670b7',
    exact_current_source_native_build=False,save_owner_git_blob=git('rev-parse',HEAD+':'+owner),
    observed_public_commands=count,commands_sha256=sha(LOG),observations=observations,
    fixture=str(W),new_roots=0,new_worktrees=0,native_builds=0,candidate_dispatches=0,
    fixture_setup_reused_after_envelope_projection=args.resume_after_envelope_projection,
    actual_Factorio=False,whole_workunit_closed=False,full_programme_complete=False)
with OUT.open('x',encoding='utf-8',newline='\n') as f:
    f.write(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(status=record['status'],observed_public_commands=count,receipt_sha256=sha(OUT),
    commands_sha256=sha(LOG))))
