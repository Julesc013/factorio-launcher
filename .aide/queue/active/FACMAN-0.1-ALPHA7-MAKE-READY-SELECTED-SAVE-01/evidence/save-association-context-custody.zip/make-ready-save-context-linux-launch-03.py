"""Await one private Linux fixture worker and consume terminal evidence once."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

E = Path(__file__).resolve().parent
R = Path('/mnt/d/Projects/Factorio/factorio-launcher')
OUT = E/'make-ready-save-context-linux-launch-03.json'
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
assert not OUT.exists() and __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0'
prior = json.loads((E/'make-ready-save-context-linux-proof-02.json').read_text(encoding='utf-8'))
assert prior['status'] == 'stopped_for_actionable_failure'
assert prior['checks'][0]['exit_code'] == prior['checks'][1]['exit_code'] == 0
assert prior['native_builds'] == 1 and all(sha(R/p) == d for p,d in prior['source_hashes'].items())
namespace = os.readlink('/proc/self/ns/mnt')
env = dict(os.environ,FACMAN_PARENT_MOUNT_NAMESPACE=namespace,PYTHONOPTIMIZE='0',PYTHONDONTWRITEBYTECODE='1')
command = ['unshare','--mount','--pid','--fork','--kill-child=SIGKILL','--mount-proc','--propagation','private',
    sys.executable,'-B',str(E/'make-ready-save-context-linux-private-02.py')]
with (E/'make-ready-save-context-linux-launch-03.claim.json').open('x',encoding='utf-8') as f:
    json.dump(dict(PID=os.getpid(),no_automatic_replay=True,argv=command,source_hashes=prior['source_hashes']),f,indent=2)
with (E/'make-ready-save-context-linux-launch-03.log').open('x',encoding='utf-8') as f:
    result = subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=660)
temp = E/'make-ready-save-context-linux-public-02-private'
assert os.readlink('/proc/self/ns/mnt') == namespace and not os.path.ismount(temp)
assert temp.is_dir() and not list(temp.iterdir())
public_path = E/'make-ready-save-context-linux-public-02.json'
public = json.loads(public_path.read_text(encoding='utf-8')) if public_path.exists() else None
record = dict(status='PASS_REQUIRED_LINUX_SAVE_CONTEXT' if result.returncode == 0 else 'actionable_linux_fixture_failure',
    exit_code=result.returncode,source_hashes=prior['source_hashes'],public_suite=public,
    public_receipt_sha256=sha(public_path) if public else None,
    mount_receipt_sha256=sha(E/'make-ready-save-context-linux-public-02-mount.json') if (E/'make-ready-save-context-linux-public-02-mount.json').exists() else None,
    private_mount_absent=True,original_namespace_preserved=True,native_builds=0,model_wait_calls=0,
    new_roots=0,new_worktrees=0,candidate_dispatches=0,whole_workunit_closed=False)
with OUT.open('x',encoding='utf-8',newline='\n') as f:
    f.write(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(status=record['status'],public_suite=public,receipt_sha256=sha(OUT))))
raise SystemExit(result.returncode)
