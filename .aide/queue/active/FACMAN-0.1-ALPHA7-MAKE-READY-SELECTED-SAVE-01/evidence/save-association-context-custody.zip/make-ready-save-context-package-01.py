"""Package completed source fixture observations without widening their claims."""
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tomllib
import zipfile

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
P = 'make-ready-save-context'
U = 'FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
B = 'task/facman-world-restore-retention-01'
BASE = '9339459e669f37ad1a5cc09394e3a05eef9350d0'
Q = R/'.aide/queue/active'/U/'evidence'
sys.path.insert(0, str(R/'.aide/scripts'))
import aide_lite as aide

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def load(name):
    return json.loads((E/(P+'-'+name+'.json')).read_text(encoding='utf-8'))

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        f.write(json.dumps(value, indent=2)+'\n')

def out(*args):
    result = subprocess.run(args, cwd=R, capture_output=True, text=True, encoding='utf-8', timeout=120)
    assert result.returncode == 0, (args, result.returncode, result.stderr[:500])
    return result.stdout.strip()

def check(name, args):
    log = E/(P+'-precommit-'+name+'.log')
    with log.open('x', encoding='utf-8') as f:
        result = subprocess.run(args, cwd=R, stdout=f, stderr=subprocess.STDOUT, timeout=900)
    entry = dict(check=name, argv=args, exit_code=result.returncode, log=str(log), sha256=sha(log))
    assert result.returncode == 0, entry
    return entry

assert __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0'
assert out('git', 'rev-parse', 'HEAD') == BASE and out('git', 'branch', '--show-current') == B
windows, linux, terminal = load('public-01'), load('linux-public-02'), load('linux-launch-03')
wp, lp = load('source-proof-02'), load('linux-proof-02')
assert windows['status'] == 'actionable_public_failure'
assert (windows['tests'], windows['failures'], windows['errors'], len(windows['skips']), windows['observed_public_commands']) == (47, 0, 0, 2, 367)
assert windows['skips'][0]['reason'].startswith('required_blocked:')
assert windows['skips'][1]['reason'].startswith('not_applicable:')
assert terminal['status'] == linux['status'] == 'PASS_REQUIRED_LINUX_SAVE_CONTEXT'
assert (linux['tests'], linux['failures'], linux['errors'], linux['skips'], linux['observed_public_commands']) == (6, 0, 0, [], 93)
assert terminal['private_mount_absent'] and terminal['original_namespace_preserved']
assert sha(E/(P+'-linux-public-02.json')) == terminal['public_receipt_sha256']
assert sha(E/(P+'-linux-public-02-mount.json')) == terminal['mount_receipt_sha256']
assert sha(E/(P+'-public-01-commands.jsonl')) == windows['commands_sha256']
assert sha(E/(P+'-linux-public-02-commands.jsonl')) == linux['commands_sha256']
functional = wp['source_hashes']
assert len(functional) == 7 and functional == lp['source_hashes'] == terminal['source_hashes']
for path, digest in functional.items():
    assert sha(R/path) == digest, path
assert sha(E.parent/'native-developer/Debug/facman.exe') == windows['cli_sha256'] == wp['CLI_sha256']
assert sha(E.parent/'native-save-context-linux/facman') == linux['CLI_sha256'] == lp['CLI_sha256']
assert all(c['exit_code'] == 0 for c in wp['checks'][:2])
assert all(c['exit_code'] == 0 for c in lp['checks'][:2])
canonical = R/'release/index/plan.v1.toml'
original = canonical.read_text(encoding='utf-8')
plan = tomllib.loads(original)
unit = next(x for x in plan['workunit'] if x['id'] == U)
assert unit['status'] == 'active' and len(unit['close_after']) == 5 and len(unit['acceptance']) == 2
archive = Q/'save-association-context-custody.zip'
files = sorted(p for p in E.glob(P+'-*') if p.is_file() and p.suffix in {'.json', '.jsonl', '.log', '.py'})
assert len(files) > 30 and sum(p.stat().st_size for p in files) < 16*1024**2
members = {p.name: sha(p) for p in files}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for p in files:
        z.write(p, p.name)
    for path, digest in functional.items():
        z.write(R/path, 'source/'+path)
        members['source/'+path] = digest
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist()) == set(members)
    for name, digest in members.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == digest, name
receipt = Q/'save-association-context.v1.json'
public = dict(
    schema='facman.save_association_context.v1',
    status='PASS_SCOPED_SOURCE_FIXTURE_WITH_WINDOWS_LINK_HOST_BLOCK',
    work_item=U, base=BASE,
    behavior='Save index/inspect/verify expose declared version and modset-lock drift separately from legacy save-byte status; ordinary Saves snapshots forward that owner observation.',
    source_hashes=functional,
    source_proofs={name: dict(member=P+'-'+name+'.json', sha256=sha(E/(P+'-'+name+'.json'))) for name in ['source-proof-02', 'linux-proof-02', 'linux-launch-03']},
    windows=dict(public_suite=windows, actual_passes=45, native_presentation_tests=1, native_build_passed=True, required_link_cell='host_blocked_WinError_1314'),
    linux=dict(public_suite=linux, native_build_passed=True, private_tmpfs=True, tmpfs_limit_bytes=134217728, private_mount_absent=True, original_namespace_preserved=True),
    acceptance_scope=dict(
        old_byte_status_and_verify_outcome_preserved=True, declared_version_and_lock_drift=True,
        legacy_missing_evidence_unknown=True, empty_file_distinct_from_absence=True,
        historical_profile_is_provenance=True, repeated_queries_read_only=True,
        nonregular_hardlinked_oversize_context_unavailable=True, linux_live_broken_final_and_parent_links_unavailable=True,
        snapshot_revision_changes_with_owner_context=True),
    source_reviews=[dict(member=P+'-'+name+'.json', sha256=sha(E/(P+'-'+name+'.json'))) for name in ['decision-01', 'source-review-01', 'source-review-02']],
    review_binding='Static review02 predates one query argv correction and two compile API corrections; final independent commit review must bind final bytes and actual qualification.',
    custody=dict(path=archive.relative_to(R).as_posix(), sha256=sha(archive), members=members),
    retained_failures=[
        'Baseline public observations demonstrated missing declared context; two extractor failures consumed retained observations without query replay.',
        'Reviewer rejected broken-parent link handling; local no-follow component checks corrected it before build.',
        'First Windows build failed two API names; second build and native smoke passed after exact API corrections.',
        'Windows public suite retained required WinError1314 link host block and existing Windows directory-rename not-applicable cell.',
        'First Linux configure stopped on checkout EOL interpretation; process-only core.autocrlf=true matched authoritative Windows filtered provider bytes without persistent settings.',
        'First Linux public attempt refused the unreviewed 9p temporary filesystem; exact ELF reused in bounded private tmpfs without policy change or rebuild.'],
    resource_use=dict(native_build_attempts=3, successful_native_builds=2, windows_build_attempts=2, linux_build_attempts=1,
        linux_configure_attempts=2, public_suite_attempts=3, maximum_native_workers=2, maximum_heavy_local_jobs=1,
        optional_candidate_dispatches=0, CI_reruns=0, new_task_roots=0, new_worktrees=0, unchanged_wait_model_calls=0,
        prior_qualified_images_and_failure_evidence_preserved=True),
    original_acceptance=unit['acceptance'], close_after=unit['close_after'],
    qualification=dict(source_fixture=True, full_windows_link_qualification=False, produced_package=False, actual_Factorio=False,
        gameplay_compatibility=False, atomic_game_content_snapshot=False, hostile_concurrent_writer=False,
        selected_save_launch=False, human_experience=False, release=False, whole_workunit=False, full_programme=False,
        exact_current_source_CI='pending'),
    external_gates_preserved=['PR343 protected-control owner authorization', 'Genuine distinct-version Linux Setup A5 update/rollback', 'MakeReady five original close-after prerequisites', 'Windows required link cell needs a capable host'],
    next_acceptance='Compose owned multi-domain preparation and selected-save Play with current revisions through ordinary workflows.',
    finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
write(receipt, public)
start = original.index('id = "'+U+'"')
end = original.index('\n\n[[workunit]]', start)
section = original[start:end]
needle = '\n]\nqueue_task = '
assert section.count(needle) == 1
section = section.replace(needle, '\n  '+json.dumps(receipt.relative_to(R).as_posix())+',\n]\nqueue_task = ', 1)
canonical.write_text(original[:start]+section+original[end:], encoding='utf-8', newline='\n')
expected = copy.deepcopy(plan)
next(x for x in expected['workunit'] if x['id'] == U)['evidence'].append(receipt.relative_to(R).as_posix())
assert tomllib.loads(canonical.read_text(encoding='utf-8')) == expected
checks = []
for name, args in [
    ('plan-generate', ['tools/generate_plan_views.py']), ('state-generate', ['tools/project_state.py', '--write']),
    ('plan-check', ['tools/generate_plan_views.py', '--check']), ('state-check', ['tools/project_state.py', '--validate']),
    ('state-tests', ['-m', 'unittest', 'tests.test_plan_views', 'tests.test_current_truth_roles', 'tests.test_aide_target_truth', 'tests.test_aide_compaction']),
    ('metadata', ['-m', 'tools.codegen.generate_metadata', '--check']), ('compiler', ['-m', 'tools.codegen.generate_contracts', '--check']),
    ('contracts', ['tools/command_contract_check.py']), ('strict', ['tools/strict_check.py']),
    ('format', ['tools/source_format_check.py']), ('portable', ['.aide/scripts/aide_lite.py', 'test'])]:
    checks.append(check(name, [sys.executable, '-B', *args]))
checks.append(check('diff', ['git', 'diff', '--check']))
for path, digest in functional.items():
    assert sha(R/path) == digest, path
message = E/(P+'-commit.txt')
text = ('feat(saves): report declared association context drift\n\n'
    'Keep save-byte verification separate from declared version and content context.\n\n'
    f'Work-Item: {U}\nEvidence-Ref: {receipt.relative_to(R).as_posix()}\n'
    'Changelog: Added: Show declared version and content drift for associated saves\n')
with message.open('x', encoding='utf-8', newline='\n') as f:
    f.write(text)
checks.append(check('template', [sys.executable, '-B', '.aide/scripts/aide_lite.py', 'commit', 'template']))
checks.append(check('message', [sys.executable, '-B', '.aide/scripts/aide_lite.py', 'commit', 'check', '--message', text]))
paths = set(out('git', 'diff', '--name-only').splitlines()) | set(out('git', 'ls-files', '--others', '--exclude-standard').splitlines())
allowed = set(functional) | {canonical.relative_to(R).as_posix(), receipt.relative_to(R).as_posix(), archive.relative_to(R).as_posix(),
    'README.md', 'docs/roadmap.md', 'docs/release/checkpoints/README.md', 'release/index/current_state.v1.toml',
    'release/index/project_status.v2.toml', '.aide/memory/project-state.md', '.aide/memory/project-state.v2.json', 'todo.md'}
assert paths <= allowed, sorted(paths-allowed)
changed = [dict(path=p, state='content', sha256=sha(R/p), git_blob_oid=out('git', 'hash-object', '--path', p, p), ownership='task_owned') for p in sorted(paths)]
classification = dict(schema_version=aide.GIT_COMMIT_CLASSIFICATION_SCHEMA, branch=B, base_commit=BASE, work_item=U,
    message_sha256=sha(message), snapshot_sha256=aide.helper_commit_snapshot_sha256(changed), changed_paths=changed, reviews=[])
write(E/(P+'-commit-classification.json'), classification)
write(E/(P+'-precommit-QA.json'), dict(status='PASS_PACKAGED_SOURCE_QA_WITH_WINDOWS_LINK_HOST_BLOCK', metadata_checks=checks,
    receipt_sha256=sha(receipt), snapshot_sha256=classification['snapshot_sha256'], functional_source_hashes=functional,
    new_native_builds=0, whole_workunit_closed=False))
print(json.dumps(dict(status='PASS_PACKAGED_AND_CLASSIFIED', changed_paths=len(changed), custody_members=len(members),
    receipt_sha256=sha(receipt), custody_sha256=sha(archive), classification_sha256=sha(E/(P+'-commit-classification.json')))))
