"""One affected public suite, retaining command envelopes outside model context."""
import hashlib
import json
import os
from pathlib import Path
import sys
import unittest

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
OUT = E/'make-ready-save-context-public-01.json'
COMMANDS = E/'make-ready-save-context-public-01-commands.jsonl'
sys.path[:0] = [str(R/'tests'),str(R)]
import native_cli
cli = native_cli.facman_executable()
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
assert not OUT.exists() and not COMMANDS.exists() and __debug__
assert os.environ.get('PYTHONOPTIMIZE') == '0' and Path(os.environ['FACMAN_CLI_EXE']).samefile(cli)
original = native_cli.invoke_machine
count = 0
with COMMANDS.open('x',encoding='utf-8',newline='\n') as capture:
    def observe(args,env=None):
        global count
        result = original(args,env)
        count += 1
        capture.write(json.dumps(dict(sequence=count,argv=[str(cli),*args],exit_code=result[0],stdout=result[1],stderr=result[2]))+'\n')
        capture.flush()
        return result
    native_cli.invoke_machine = observe
    names = ['test_save_association_context','test_save_index_retention','test_save_transfer','test_presentation_service']
    suite = unittest.TestLoader().loadTestsFromNames(names)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
qualified = result.wasSuccessful() and not any(reason.startswith('required_blocked:') for _, reason in result.skipped)
record = dict(status='PASS_AFFECTED_PUBLIC_SUITE' if qualified else 'actionable_public_failure',
    tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skips=[dict(test=str(t),reason=r) for t,r in result.skipped],
    cli_sha256=sha(cli),observed_public_commands=count,commands_sha256=sha(COMMANDS),
    command_capture_scope='native_cli.invoke_machine only; direct subprocess calls are not separately counted',
    tested_modules=names,actual_Factorio=False,produced_package=False,whole_workunit_closed=False)
with OUT.open('x',encoding='utf-8',newline='\n') as f:
    f.write(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
raise SystemExit(0 if qualified else 1)
