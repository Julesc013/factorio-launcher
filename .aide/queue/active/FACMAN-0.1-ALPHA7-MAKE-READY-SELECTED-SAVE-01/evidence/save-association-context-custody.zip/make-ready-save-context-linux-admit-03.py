"""Admit one real missing fixture cell; reuse the already built Linux source binary."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
assert __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0'
marker = json.loads((E.parent/'.facman-development-root.v1.json').read_text(encoding='utf-8'))
assert marker['task_id'] == 'task/facman-world-restore-retention-01' and Path(marker['canonical_path']).samefile(E.parent)
result = subprocess.run([sys.executable,'-B','tools/workspace_hygiene.py','doctor','--measure'],cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
data = json.loads(result.stdout)
assert result.returncode in {0,1} and set(data['violations']) <= {'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
assert len(data['task_roots']) <= 8 and data['task_root_bytes']+128*1024**2 <= 20*1024**3
assert shutil.disk_usage(E).free >= 8*1024**3+128*1024**2
with (E/'make-ready-save-context-linux-admission-03.json').open('x',encoding='utf-8') as f:
    json.dump(dict(doctor=data,peak_tmpfs_bytes=128*1024**2,native_builds=0,new_roots=0,
        launcher_sha256=sha(E/'make-ready-save-context-linux-launch-03.py'),worker_sha256=sha(E/'make-ready-save-context-linux-private-02.py')),f,indent=2)
jobs = subprocess.check_output(['powershell','-NoProfile','-Command',"@(Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('MSBuild.exe','cl.exe','ninja.exe','cmake.exe','wsl.exe') } | Select-Object ProcessId,Name) | ConvertTo-Json -Compress"],text=True).strip()
assert jobs in {'','[]'}
script = '/mnt/d/'+str(E/'make-ready-save-context-linux-launch-03.py')[3:].replace('\\','/')
with (E/'make-ready-save-context-linux-admit-03.log').open('x',encoding='utf-8') as f:
    completed = subprocess.run(['wsl.exe','-d','Ubuntu-24.04','-u','root','--','env','PYTHONOPTIMIZE=0','PYTHONDONTWRITEBYTECODE=1',
        'python3','-B',script],cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=720)
terminal = E/'make-ready-save-context-linux-launch-03.json'
assert terminal.exists(), 'Inspect issued launcher before any recovery; never replay'
record = json.loads(terminal.read_text(encoding='utf-8'))
print(json.dumps(dict(status=record['status'],public_suite=record['public_suite'],terminal_sha256=sha(terminal))))
raise SystemExit(completed.returncode)
