"""One owned, reviewed native build and affected source-fixture qualification."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
B = E.parent/'native-developer'
CLI = B/'Debug/facman.exe'
P = 'make-ready-save-context-source-proof-01'
OUT = E/(P+'.json')
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:
        f.write(json.dumps(v,indent=2)+'\n')
def update():
    temporary = OUT.with_suffix('.writing')
    write(temporary,record)
    temporary.replace(OUT)
def out(*argv):
    result = subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
    assert result.returncode == 0,(argv[:4],result.returncode,result.stderr[:300])
    return result.stdout.strip()
def check(name,argv,timeout=900):
    log = E/(P+'-'+name+'.log')
    with log.open('x',encoding='utf-8') as f:
        result = subprocess.run(argv,cwd=R,env=os.environ.copy(),stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
    record['checks'].append(dict(check=name,argv=argv,exit_code=result.returncode,log=str(log),sha256=sha(log)))
    update()
    assert result.returncode == 0,(name,result.returncode,str(log))

assert __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0' and not OUT.exists()
assert out('git','branch','--show-current') == 'task/facman-world-restore-retention-01'
assert out('git','rev-parse','HEAD') == '9339459e669f37ad1a5cc09394e3a05eef9350d0'
marker_path = E.parent/'.facman-development-root.v1.json'
marker = json.loads(marker_path.read_text(encoding='utf-8'))
assert marker['task_id'] == 'task/facman-world-restore-retention-01'
preflight_path = E/'make-ready-save-context-preflight-03.json'
preflight = json.loads(preflight_path.read_text(encoding='utf-8'))
assert sha(preflight_path) == 'e728114fff5775762aff3358f96b79a3c03fa9d84f54ef989bcb61267a624395'
assert preflight['status'] == 'PASS_SOURCE_PREFLIGHT' and len(preflight['checks']) == 9
review_path = E/'make-ready-save-context-source-review-02.json'
assert sha(review_path) == 'c643c3fe80e3346ad68d8058a1c2fc7526464bafcba3fab4e1280bbcfb74b3ca'
review = json.loads(review_path.read_text(encoding='utf-8'))
assert review['verdict'] == 'PASS_STATIC_SOURCE' and review['independent'] and review['non_authoring']
source = dict(preflight['source_hashes'])
test = 'tests/test_save_association_context.py'
test_text = (R/test).read_text(encoding='utf-8')
before_test = test_text.replace('"query", "saves", "--instance"','"query", "--scope", "saves", "--instance"')
assert before_test != test_text and hashlib.sha256(before_test.encode('utf-8')).hexdigest() == source[test] == review['source_sha256'][test]
source[test] = sha(R/test)
for path,digest in source.items():
    assert sha(R/path) == digest
    if path != test:
        assert review['source_sha256'][path] == digest
for check_record in preflight['checks']:
    assert check_record['exit_code'] == 0 and sha(Path(check_record['log'])) == check_record['sha256']
write(E/(P+'.claim.json'),dict(pid=os.getpid(),source_hashes=source,no_automatic_replay=True))
record = dict(status='running_owned_save_context_source_proof',base=out('git','rev-parse','HEAD'),
    source_hashes=source,source_review_sha256=sha(review_path),preflight_sha256=sha(preflight_path),
    test_query_argv_only_delta_since_review=True,native_builds=0,new_roots=0,new_worktrees=0,
    candidate_dispatches=0,CI_reruns=0,model_wait_calls=0,checks=[],whole_workunit_closed=False)
update()
temp = E/'make-ready-save-context-proof-01-temp'
try:
    heavy = out('powershell','-NoProfile','-Command',"@(Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('MSBuild.exe','cl.exe','ninja.exe','cmake.exe') } | Select-Object ProcessId,Name) | ConvertTo-Json -Compress")
    assert heavy in {'','[]'}
    memory = int(out('powershell','-NoProfile','-Command','(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory'))*1024
    assert memory >= 4*1024**3
    for name,extra in [('paths',[]),('doctor',['--measure'])]:
        p = subprocess.run([sys.executable,'-B','tools/workspace_hygiene.py',name,*extra],cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
        data = json.loads(p.stdout)
        write(E/(P+'-'+name+'.json'),data)
        if name == 'doctor':
            assert p.returncode in {0,1} and set(data['violations']) <= {'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
            assert len(data['task_roots']) <= 8 and data['task_root_bytes']+2*1024**3+64*1024**2 <= 20*1024**3
        else:
            assert p.returncode == 0
    assert shutil.disk_usage(E).free >= 8*1024**3+2*1024**3+64*1024**2
    assert sha(CLI) == 'bc60a62920d48173f743a68cc5dfcd7929598c344c38bc117d48346b1ddf3254'
    prior = json.loads((E/'make-ready-presentation-source-proof-02.json').read_text(encoding='utf-8'))
    images = prior['preserved_qualified_images']
    assert sha(Path(images['path'])) == images['sha256']
    with zipfile.ZipFile(images['path']) as archive:
        assert archive.testzip() is None and hashlib.sha256(archive.read('facman.exe')).hexdigest() == sha(CLI)
    record['prior_qualified_images_preserved'] = images
    temp.mkdir()
    os.environ.update(CMAKE_BUILD_PARALLEL_LEVEL='2',MSBUILDDISABLENODEREUSE='1',PYTHONOPTIMIZE='0',
        PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',FACMAN_CLI_EXE=str(CLI),TMP=str(temp),TEMP=str(temp),
        PYTHONPATH=os.pathsep.join([str(R/'tests'),str(R)]))
    record['native_builds'] = 1; update()
    check('build',[sys.executable,'-B','tools/dev.py','build','developer','--task-root',str(E.parent),
        '--build-root',str(B),'--configuration','Debug','--target','facman_cli','--target','facman_presentation_service_smoke'],1800)
    record['CLI_sha256'] = sha(CLI); update()
    check('native-presentation',['ctest','--test-dir',str(B),'-C','Debug','-R','^facman_presentation_service_smoke$',
        '--output-on-failure','--no-tests=error'],180)
    check('public',[sys.executable,'-B',str(E/'make-ready-save-context-public-01.py')],1200)
    public = json.loads((E/'make-ready-save-context-public-01.json').read_text(encoding='utf-8'))
    assert public['status'] == 'PASS_AFFECTED_PUBLIC_SUITE' and public['cli_sha256'] == sha(CLI)
    assert not any(v['reason'].startswith('required_blocked:') for v in public['skips'])
    assert not list(temp.iterdir())
    for path,digest in source.items():
        assert sha(R/path) == digest
    renewed = json.loads(marker_path.read_text(encoding='utf-8'))
    assert all(renewed[k] == marker[k] for k in marker if k != 'last_used_at')
    record.update(status='PASS_SCOPED_WINDOWS_SAVE_CONTEXT',native_presentation_tests=1,public_suite=public,
        required_save_context_methods=6,required_save_context_skips=0,actual_Factorio=False,produced_package=False,
        human_experience=False,full_programme_complete=False,temp_parent_empty=True)
except BaseException as error:
    record.update(status='stopped_for_actionable_failure',error=repr(error))
finally:
    record['finished_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    update()
print(json.dumps({k:record.get(k) for k in ['status','CLI_sha256','native_builds','error','public_suite','finished_at_utc']}))
raise SystemExit(0 if record['status'] == 'PASS_SCOPED_WINDOWS_SAVE_CONTEXT' else 1)
