"""Capture focused source and generator QA for the existing save owner change."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
P = 'make-ready-save-context-preflight-01'
OUT = E/(P+'.json')
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
checks = []
for name,argv in [
    ('format',['tools/source_format_check.py']),
    ('metadata',['-m','tools.codegen.generate_metadata','--check']),
    ('compiler',['-m','tools.codegen.generate_contracts','--check']),
    ('compiler-tests',['-m','unittest','tests.test_contract_compiler','-v']),
    ('contracts',['tools/command_contract_check.py']),
    ('strict',['tools/strict_check.py']),
    ('state',['tools/project_state.py','--validate']),
    ('plan',['tools/generate_plan_views.py','--check']),
    ('portable',['.aide/scripts/aide_lite.py','test'])]:
    log = E/(P+'-'+name+'.log')
    with log.open('x',encoding='utf-8') as f:
        result = subprocess.run([sys.executable,'-B',*argv],cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=900)
    checks.append(dict(check=name,exit_code=result.returncode,log=str(log),sha256=sha(log)))
    if result.returncode:
        with OUT.open('x',encoding='utf-8') as f:
            json.dump(dict(status='stopped_for_actionable_failure',checks=checks),f,indent=2)
        raise SystemExit(name+' failed: '+str(log))
paths = set(subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines()) | set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R,text=True).splitlines())
assert len(paths) == 7
record = dict(status='PASS_SOURCE_PREFLIGHT',checks=checks,source_hashes={p:sha(R/p) for p in sorted(paths)},
    native_builds=0,candidate_dispatches=0,whole_workunit_closed=False)
with OUT.open('x',encoding='utf-8',newline='\n') as f:
    f.write(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(status=record['status'],source_paths=len(paths),sha256=sha(OUT))))
