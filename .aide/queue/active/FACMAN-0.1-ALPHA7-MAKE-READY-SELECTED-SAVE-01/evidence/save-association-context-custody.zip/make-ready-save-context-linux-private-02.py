"""Private bounded tmpfs for synthetic fixtures; persistent evidence stays outside it."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

E = Path(__file__).resolve().parent
TEMP = E/'make-ready-save-context-linux-public-02-private'
CLI = E.parent/'native-save-context-linux/facman'
HOST_NAMESPACE = os.environ['FACMAN_PARENT_MOUNT_NAMESPACE']
assert os.readlink('/proc/self/ns/mnt') != HOST_NAMESPACE
assert hashlib.sha256(CLI.read_bytes()).hexdigest() == 'db457a867fdce7773e84db77cfb16b61cd4874d67d9ef96aa14cab23ffed69f9'
assert __debug__ and not TEMP.exists()
TEMP.mkdir()
mounted = False
try:
    subprocess.run(['mount','-t','tmpfs','-o','size=128m,nosuid,nodev','facman-save-context',str(TEMP)],check=True,timeout=30)
    mounted = True
    info = subprocess.check_output(['findmnt','-J','-M',str(TEMP),'-o','TARGET,FSTYPE,OPTIONS'],text=True)
    mount = json.loads(info)['filesystems'][0]
    assert mount['fstype'] == 'tmpfs' and mount['target'] == str(TEMP)
    env = dict(os.environ,TMPDIR=str(TEMP),TMP=str(TEMP),TEMP=str(TEMP),FACMAN_CLI_EXE=str(CLI),
        PYTHONPATH='/mnt/d/Projects/Factorio/factorio-launcher/tests:/mnt/d/Projects/Factorio/factorio-launcher',
        PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='0')
    result = subprocess.run([sys.executable,'-B',str(E/'make-ready-save-context-linux-public-02.py')],env=env,timeout=600)
    assert not list(TEMP.iterdir()), 'Preserve remaining synthetic fixture state before recovery'
    with (E/'make-ready-save-context-linux-public-02-mount.json').open('x',encoding='utf-8') as f:
        json.dump(dict(private_mount_namespace=True,mount=mount,peak_tmpfs_bytes=128*1024**2,
            fixture_parent_empty=True,exit_code=result.returncode,new_roots=0),f,indent=2)
finally:
    if mounted:
        subprocess.run(['umount',str(TEMP)],check=True,timeout=30)
raise SystemExit(result.returncode)
