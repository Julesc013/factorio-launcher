"""Run only the six required context cases against the actual Linux executable."""
import hashlib
import json
import os
from pathlib import Path
import sys
import unittest

R = Path('/mnt/d/Projects/Factorio/factorio-launcher')
E = Path(__file__).resolve().parent
sys.path[:0] = [str(R/'tests'),str(R)]
import native_cli
CLI = native_cli.facman_executable()
OUT = E/'make-ready-save-context-linux-public-02.json'
LOG = E/'make-ready-save-context-linux-public-02-commands.jsonl'
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
assert __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0' and not OUT.exists()
count = 0
original = native_cli.invoke_machine
with LOG.open('x',encoding='utf-8',newline='\n') as f:
    def observe(args,env=None):
        global count
        result = original(args,env)
        count += 1
        f.write(json.dumps(dict(sequence=count,argv=[str(CLI),*args],exit_code=result[0],stdout=result[1],stderr=result[2]))+'\n')
        f.flush()
        return result
    native_cli.invoke_machine = observe
    suite = unittest.TestLoader().loadTestsFromName('test_save_association_context')
    result = unittest.TextTestRunner(verbosity=2).run(suite)
qualified = result.wasSuccessful() and result.testsRun == 6 and not result.skipped
record = dict(status='PASS_REQUIRED_LINUX_SAVE_CONTEXT' if qualified else 'actionable_required_failure',
    tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skips=[dict(test=str(t),reason=r) for t,r in result.skipped],
    observed_public_commands=count,commands_sha256=sha(LOG),CLI_sha256=sha(CLI),actual_Factorio=False,
    produced_package=False,whole_workunit_closed=False)
with OUT.open('x',encoding='utf-8',newline='\n') as f:
    f.write(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
raise SystemExit(0 if qualified else 1)
