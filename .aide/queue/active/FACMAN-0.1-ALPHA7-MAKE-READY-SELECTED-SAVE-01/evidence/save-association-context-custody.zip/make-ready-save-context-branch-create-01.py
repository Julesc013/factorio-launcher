"""Reuse the retired owned branch at the next qualified dev, preserving root ownership."""
import ast
from pathlib import Path

E = Path(__file__).resolve().parent
t = (E/'make-ready-presentation-branch-01.py').read_text(encoding='utf-8')
t = t.replace('make-ready-presentation', 'make-ready-save-context')
t = t.replace('1c8638bb0d7cc484963c4324fe6e564a0748b468', '9339459e669f37ad1a5cc09394e3a05eef9350d0')
t = t.replace('make-ready-profile-revision-integration-03.json', 'make-ready-presentation-integration-02.json')
t = t.replace('8c6ea2793abb021bed72801c68f3545a809e2c3943cb2747d071140afd129b47', '1b55202124ca8213936f4eb90cae67b108aac65cd28c4d7036eb9deaa8467f3c')
t = t.replace('d4ac98befdca5c5c449ea28479896fc6c86e24b0e7bcac8b11d4368d8203114a', '907e728fee9125559570f30ab26ca4db3ec725b2ea890133bf3714487c502a7a')
needle = "helper = aide_lite.make_git_helper_plan(R, 'plan')"
assert t.count(needle) == 1
t = t.replace(needle, '''for name, extra in [('paths', []), ('doctor', ['--measure'])]:
    p = subprocess.run([sys.executable,'-B','tools/workspace_hygiene.py',name,*extra],cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
    hygiene = json.loads(p.stdout)
    write(E/('make-ready-save-context-prebranch-'+name+'.json'),hygiene)
    if name == 'doctor':
        assert p.returncode in {0,1} and set(hygiene['violations']) <= {'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
        assert len(hygiene['task_roots']) <= 8 and hygiene['task_root_bytes'] <= 20*1024**3
    else:
        assert p.returncode == 0
for category, operations in [('task',['inspect','noop-check','recover']),('git',['policy','detect','plan'])]:
    for operation in operations:
        argv = [sys.executable,'-B','.aide/scripts/aide_lite.py',category,operation]
        if category == 'task':
            argv += ['--task-id',U]
        with (E/('make-ready-save-context-prebranch-'+category+'-'+operation+'.log')).open('x',encoding='utf-8') as f:
            p = subprocess.run(argv,cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=120)
        assert p.returncode == 0
helper = aide_lite.make_git_helper_plan(R, 'plan')''')
ast.parse(t)
with (E/'make-ready-save-context-branch-01.py').open('x',encoding='utf-8',newline='\n') as f:
    f.write(t)
