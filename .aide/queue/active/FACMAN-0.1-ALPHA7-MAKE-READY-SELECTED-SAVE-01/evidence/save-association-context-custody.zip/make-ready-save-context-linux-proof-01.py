"""One guarded Linux source build in the existing Windows-owned task root."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
TASK = E.parent
B = TASK/'native-save-context-linux'
P = 'make-ready-save-context-linux-proof-01'
OUT = E/(P+'.json')
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def linux(p):
    text = str(p.resolve()).replace('\\','/')
    assert text.startswith('D:/')
    return '/mnt/d/'+text[3:]
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:
        f.write(json.dumps(v,indent=2)+'\n')
def update():
    temp = OUT.with_suffix('.writing')
    write(temp,record); temp.replace(OUT)
def run(name,argv,timeout=1800):
    path = E/(P+'-'+name+'.log')
    with path.open('x',encoding='utf-8') as f:
        result = subprocess.run(argv,cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
    record['checks'].append(dict(check=name,exit_code=result.returncode,log=str(path),sha256=sha(path),argv=argv))
    update()
    assert result.returncode == 0,(name,result.returncode,str(path))

assert __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0'
assert not OUT.exists() and not B.exists() and B.resolve().is_relative_to(TASK.resolve())
marker_path = TASK/'.facman-development-root.v1.json'
marker = json.loads(marker_path.read_text(encoding='utf-8'))
assert marker['task_id'] == 'task/facman-world-restore-retention-01' and Path(marker['canonical_path']).samefile(TASK)
prior_path = E/'make-ready-save-context-source-proof-02.json'
prior = json.loads(prior_path.read_text(encoding='utf-8'))
assert prior['status'] == 'stopped_for_actionable_failure' and prior['CLI_sha256'] == '20dfe23fcbba828b5be23205fce74f59c458c9c94339f3c725515db4e2af2f42'
assert all(sha(R/p) == d for p,d in prior['source_hashes'].items())
assert prior['checks'][0]['exit_code'] == prior['checks'][1]['exit_code'] == 0
cache = (TASK/'native-developer/CMakeCache.txt').read_text(encoding='utf-8')
providers = {}
for variable in ('FLAUNCH_UNIVERSAL_LAUNCHER_ROOT','FLAUNCH_UNIVERSAL_SETUP_ROOT'):
    path = Path(re.search('^'+variable+':PATH=(.+)$',cache,re.MULTILINE).group(1))
    assert path.resolve().is_relative_to((TASK/'providers').resolve()) and path.is_dir()
    providers[variable] = path
record = dict(status='admitting_linux_required_cell',base=prior['base'],source_hashes=prior['source_hashes'],
    prior_windows_proof_sha256=sha(prior_path),new_roots=0,new_worktrees=0,native_builds=0,
    candidate_dispatches=0,CI_reruns=0,checks=[],marker_sha256=sha(marker_path),whole_workunit_closed=False)
update()
try:
    for name,extra in [('paths',[]),('doctor',['--measure'])]:
        result = subprocess.run([sys.executable,'-B','tools/workspace_hygiene.py',name,*extra],cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
        data = json.loads(result.stdout); write(E/(P+'-'+name+'.json'),data)
        if name == 'doctor':
            assert result.returncode in {0,1} and set(data['violations']) <= {'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
            assert len(data['task_roots']) <= 8 and data['task_root_bytes']+2*1024**3 <= 20*1024**3
        else:
            assert result.returncode == 0
    assert shutil.disk_usage(E).free >= 8*1024**3+2*1024**3
    heavy = subprocess.check_output(['powershell','-NoProfile','-Command',"@(Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('MSBuild.exe','cl.exe','ninja.exe','cmake.exe','wsl.exe') } | Select-Object ProcessId,Name) | ConvertTo-Json -Compress"],text=True).strip()
    assert heavy in {'','[]'}
    probe = 'import json,pathlib,shutil; print(json.dumps({"memory":int(next(x.split()[1] for x in pathlib.Path("/proc/meminfo").read_text().splitlines() if x.startswith("MemAvailable:")))*1024,"jobs":[p.name for p in pathlib.Path("/proc").iterdir() if p.name.isdigit() and (p/"comm").exists() and (p/"comm").read_text().strip() in ("cmake","ninja","cc1plus","g++")]}))'
    wsl = ['wsl.exe','-d','Ubuntu-24.04','-u','root','--']
    host = json.loads(subprocess.check_output([*wsl,'python3','-B','-c',probe],text=True,encoding='utf-8',timeout=30))
    assert not host['jobs'] and host['memory'] >= 4*1024**3
    record['linux_admission'] = host; record['output_directory'] = str(B); update()
    write(E/(P+'-build-plan.json'),dict(task_root=str(TASK),build_root=str(B),marker_sha256=sha(marker_path),
        source_root=str(R),native_workers=2,source_providers={k:str(v) for k,v in providers.items()},new_roots=0,
        rationale='Actual Windows symlink fixture blocked by privilege; exact Linux source build qualifies the missing required cell without changing host privileges or test obligations'))
    run('configure',[*wsl,'env','PYTHONDONTWRITEBYTECODE=1','cmake','-S',linux(R),'-B',linux(B),'-G','Ninja',
        '-DCMAKE_BUILD_TYPE=Debug','-DFACMAN_BUILD_TESTS=ON','-DFACMAN_BUILD_TUI=ON','-DFACMAN_PROVIDER_MODE=source',
        '-DFACMAN_PROVIDER_LOCK_FILE='+linux(R/'release/index/workspace_lock.v1.toml'),
        *['-D'+key+'='+linux(value) for key,value in providers.items()]])
    record['native_builds'] = 1; update()
    run('build',[*wsl,'cmake','--build',linux(B),'--parallel','2','--target','facman_cli'])
    executables = [p for p in B.rglob('facman') if p.is_file() and p.read_bytes()[:4] == b'\x7fELF']
    assert len(executables) == 1
    cli = executables[0]
    temp = E/'make-ready-save-context-linux-01-temp'; temp.mkdir()
    record['CLI_sha256'] = sha(cli); record['CLI_path'] = str(cli); update()
    run('public',[*wsl,'env','PYTHONOPTIMIZE=0','PYTHONDONTWRITEBYTECODE=1','PYTHONUTF8=1',
        'FACMAN_CLI_EXE='+linux(cli),'TMPDIR='+linux(temp),'PYTHONPATH='+linux(R/'tests')+':'+linux(R),
        'python3','-B',linux(E/'make-ready-save-context-linux-public-01.py')],600)
    public = json.loads((E/'make-ready-save-context-linux-public-01.json').read_text(encoding='utf-8'))
    assert public['status'] == 'PASS_REQUIRED_LINUX_SAVE_CONTEXT' and public['tests'] == 6 and not public['skips']
    assert public['CLI_sha256'] == sha(cli) and not list(temp.iterdir())
    assert all(sha(R/p) == d for p,d in record['source_hashes'].items())
    assert sha(marker_path) == record['marker_sha256']
    record.update(status='PASS_REQUIRED_LINUX_SAVE_CONTEXT',public_suite=public,actual_Factorio=False,
        produced_package=False,human_experience=False,full_programme_complete=False)
except BaseException as error:
    record.update(status='stopped_for_actionable_failure',error=repr(error))
finally:
    record['finished_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat(); update()
print(json.dumps({k:record.get(k) for k in ('status','native_builds','CLI_sha256','public_suite','error','finished_at_utc')}))
raise SystemExit(0 if record['status'] == 'PASS_REQUIRED_LINUX_SAVE_CONTEXT' else 1)
