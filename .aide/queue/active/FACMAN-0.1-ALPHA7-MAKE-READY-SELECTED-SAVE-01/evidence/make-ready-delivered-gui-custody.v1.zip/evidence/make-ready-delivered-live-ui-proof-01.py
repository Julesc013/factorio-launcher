"""Admitted actual GUI -> two ordinary Make Ready stages -> existing preparation oracles.

Requires completed checked integration, accepted delivered CLI proof, and an
independent exact parent/helper/artifact decision. Never builds a product or
changes a delivered byte. Every command owns a finite Windows Job Object.
"""
import ctypes,datetime,hashlib,json,os,shutil,stat,subprocess,sys,traceback,zipfile
from ctypes import wintypes
sys.dont_write_bytecode=True
from pathlib import Path
from types import SimpleNamespace
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
SOURCE='5cb795a12521e926d9335da9cc66b6868a2319c8'
SCENARIO=W/'make-ready-delivered-live-ui-proof-01'
OUTPUT=E/'make-ready-delivered-live-ui-result-01.json'
HELPER=E/'make-ready-delivered-live-ui-driver-01.ps1'
HELPER_SHA='6d418b8f0dd832146c41db3c5650b4d8e9dd4fd3490f4272dc3c98a91098059a'
REVIEW=E/'make-ready-delivered-live-ui-execution-review-01.json'
ADMISSION=E/'pack-partial-recovery-original-portable-admission-06.json'
CORE=E/'pack-partial-recovery-produced-result.json'
CORE_REVIEW=E/'pack-partial-recovery-produced-final-review.json'
COMPLETION=E/'pack-partial-recovery-postintegration-completion-04.json'
assert __debug__ and os.name=='nt'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sha_bytes=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
def tree(p):
 result={}
 for f in sorted(Path(p).rglob('*')):
  assert not getattr(f.stat(follow_symlinks=False),'st_file_attributes',0)&stat.FILE_ATTRIBUTE_REPARSE_POINT
  if f.is_file():result[f.relative_to(p).as_posix()]=sha(f)
 return result
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True,timeout=30).strip()
def exclusive(p,v):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
# All evidence decisions precede every directory/effect creation.
a=load(ADMISSION);core=load(CORE);cr=load(CORE_REVIEW);c=load(COMPLETION);review=load(REVIEW)
assert a['status']=='ADMITTED_EXISTING_WINDOWS_PRODUCED_PACKAGE' and a['source_commit']==SOURCE
assert core['status']=='PASS_SCOPED_WINDOWS_PRODUCED_PARTIAL_PACK_RECOVERY' and core['producer_source']==SOURCE
assert core['product_did_not_change_producers_or_delivery'] and core['clean_consumer_workspaces']==13
assert {cell['kind'] for cell in core['negative_preservation_cells']}=={'changed_source','conflicting_raw_entry','torn_generated_entry'}
assert cr['verdict']=='PASS' and cr['independent'] and cr['non_authoring']
assert cr['approve_scoped_produced_partial_pack_recovery'] and cr['result_sha256']==sha(CORE)
assert c['status']=='reviewed_pack_partial_recovery_integrated_and_clean_primaries_synchronized' and c['source']==SOURCE
assert review['verdict']=='PASS' and review['independent'] and review['non_authoring'] and review['approve_exact_make_ready_gui_proof']
assert review['script_sha256']==sha(__file__) and review['helper_sha256']==sha(HELPER)==HELPER_SHA
for key,p in [('admission_sha256',ADMISSION),('core_result_sha256',CORE),('core_review_sha256',CORE_REVIEW),('completion_sha256',COMPLETION)]:
 assert review[key]==sha(p)
assert review['source']==SOURCE and review['delivery_files']==a['delivery_files']
assert not OUTPUT.exists() and not SCENARIO.exists() and not SCENARIO.is_symlink()
head=git('rev-parse','HEAD')
frozen_status=git('status','--porcelain')
frozen_diff=hashlib.sha256(subprocess.check_output(['git','diff','HEAD','--binary'],cwd=R,timeout=30)).hexdigest()
assert review['frozen_head']==head and review['frozen_status']==frozen_status and review['frozen_diff_sha256']==frozen_diff
required_files={
 'tests/native_cli.py','tests/test_make_ready_preparation.py','tests/test_configuration_reconciliation.py',
 'tests/test_configuration_preparation.py','tests/test_selected_save_preparation.py','tests/test_readiness_builtin_content.py',
 'tests/test_local_modset_solver.py','tests/test_save_index_retention.py','tests/test_presentation_profile_preparation.py',
 'tests/test_profiles_templates.py','tests/test_cli.py','tests/windows_junction.py','tools/json_contract.py',
 'tools/winforms_build.py','tools/provider_canary_process.py','tools/provider_canary_process_windows.py',
 'apps/gui/windows/winforms/Program.cs','apps/gui/windows/winforms/C1ShellForm.cs','apps/gui/windows/winforms/C1LivePresentationStore.cs',
 'runtime/factorio/application/presentation_service.cpp','runtime/factorio/application/presentation_action_support.cpp',
 'runtime/factorio/instance/flb_factorio_configuration_preparation.cpp','runtime/factorio/instance/flb_factorio_selected_save_preparation.cpp'}
required_files.update(p.relative_to(R).as_posix() for root in (R/'tests/fixtures/fake_factorio_install',) for p in root.rglob('*') if p.is_file())
assert required_files.issubset(review['source_files']),required_files-set(review['source_files'])
for name,digest in review['source_files'].items():
 assert sha(R/name)==digest==hashlib.sha256(subprocess.check_output(['git','show',SOURCE+':'+name],cwd=R,timeout=30)).hexdigest()
subprocess.run(['git','merge-base','--is-ancestor',SOURCE,head],cwd=R,check=True,timeout=30)
marker=load(W/'.facman-development-root.v1.json')
assert Path(marker['source_root']).resolve()==R and Path(marker['canonical_path']).resolve()==W
assert marker['task_id']=='task/facman-world-restore-retention-01'
for parent in [W,*W.parents]:assert not getattr(parent.stat(follow_symlinks=False),'st_file_attributes',0)&stat.FILE_ATTRIBUTE_REPARSE_POINT
cli=Path(a['executable']).resolve(strict=True);delivery=Path(a['delivery_root']).resolve(strict=True)
assert delivery.is_relative_to(W) and cli.is_relative_to(delivery) and sha(cli)==a['executable_sha256']
assert tree(delivery)==a['delivery_files']
guis=[delivery/leaf for leaf in a['delivery_files'] if Path(leaf).name.lower()=='facman.winforms.exe']
assert len(guis)==1;gui=guis[0];assert sha(gui)==review['gui_sha256']
os.environ['FACMAN_DEV_ROOT']=r'D:\Projects\Factorio\.task-builds'
os.environ['TEMP']=os.environ['TMP']=str(W/'t');os.environ['PYTHONDONTWRITEBYTECODE']='1'
for key in list(os.environ):
 if key.startswith('FACMAN_TEST_') or key.endswith('_FAULT') or key in ('FACMAN_PRESENTATION_MODE','FACMAN_CLI_PATH'):
  os.environ.pop(key)
os.environ['FACMAN_CLI_EXE']=str(cli)
os.environ['PYTHONPATH']=os.pathsep.join([str(R),str(R/'tests')])
sys.path[:0]=[str(R),str(R/'tests')]
from tools import provider_canary_process as owned
budget=owned.Budget(600,180);records=[]
record=dict(status='ADMITTING_EXACT_LIVE_UI_PROOF',source=SOURCE,head=head,commands=records,
 new_task_roots=0,new_clones=0,new_worktrees=0,product_builds=0,optional_candidates=0,
 helper_utility_compilations=2,setup_executed=False,factorio_executed=False,human_qualified=False,
 legacy_portable_profile=True,canonical_installed_setup_qualified=False,
 whole_workunit_closed=False,beta_qualified=False,review_sha256=sha(REVIEW))
# Retain each ancestor without delete sharing before any effect; reparse
# directories are rejected by the handle, not solely by path inspection.
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.CreateFileW.argtypes=[wintypes.LPCWSTR,wintypes.DWORD,wintypes.DWORD,ctypes.c_void_p,wintypes.DWORD,wintypes.DWORD,ctypes.c_void_p]
kernel.CreateFileW.restype=wintypes.HANDLE
kernel.GetFileInformationByHandleEx.argtypes=[wintypes.HANDLE,ctypes.c_int,ctypes.c_void_p,wintypes.DWORD]
kernel.GetFileInformationByHandleEx.restype=wintypes.BOOL
kernel.CloseHandle.argtypes=[wintypes.HANDLE];kernel.CloseHandle.restype=wintypes.BOOL
class AttributeTag(ctypes.Structure):
 _fields_=[('attributes',wintypes.DWORD),('tag',wintypes.DWORD)]
leases=[]
def retain_ancestry(path):
 for directory in [path,*path.parents]:
  handle=kernel.CreateFileW(str(directory),0x80,3,None,3,0x02200000,None)
  assert handle not in (None,ctypes.c_void_p(-1).value),ctypes.WinError(ctypes.get_last_error())
  info=AttributeTag()
  if not kernel.GetFileInformationByHandleEx(handle,9,ctypes.byref(info),ctypes.sizeof(info)) or not info.attributes&0x10 or info.attributes&0x400:
   kernel.CloseHandle(handle);raise AssertionError('Unsafe output ancestor')
  leases.append(handle)
retain_ancestry(E)
# A unique external attempt claim prevents silent replay; all outputs remain.
exclusive(E/'make-ready-delivered-live-ui-proof-01.claim.json',dict(pid=os.getpid(),review_sha256=sha(REVIEW),source=SOURCE,no_replay=True))
SCENARIO.mkdir();retain_ancestry(SCENARIO);(SCENARIO/'commands').mkdir()
output_stream=OUTPUT.open('x+',encoding='utf-8',newline='\n')
def save():
 output_stream.seek(0);json.dump(record,output_stream,indent=2);output_stream.write('\n');output_stream.truncate();output_stream.flush();os.fsync(output_stream.fileno())
def command(label,argv,timeout=60,environment=None,allowed=(0,)):
 result=owned.command([str(x) for x in argv],cwd=R,environment=dict(os.environ) if environment is None else environment,
  timeout=timeout,budget=budget,output_limit=256*1024,directory=SCENARIO/'commands'/f'{len(records)+1:03d}-{label}',wait_for_job_empty_after_primary=True)
 p=result.directory/'receipt.json';records.append(dict(name=label,path=str(p),sha256=sha(p),exit=result.returncode));save()
 assert result.receipt['primary_stopped'] and result.receipt['job_empty_observed']
 assert result.receipt['termination']=='completed' and result.returncode in allowed
 return result
try:
 identity=command('identity',['powershell','-NoProfile','-Command','[Security.Principal.WindowsIdentity]::GetCurrent().Name']).stdout.decode().strip()
 assert identity.casefold()==r'BLACKGLASS-WIN1\Jules'.casefold()
 import native_cli
 def logged_run(argv,**kw):
  assert Path(argv[0]).samefile(cli) and '--workspace' in argv
  assert Path(argv[argv.index('--workspace')+1]).resolve().is_relative_to(SCENARIO)
  index=argv.index('--workspace')
  route=tuple(argv[index+2:index+4])
  assert route in {('installs','import'),('instances','create'),('modsets','apply'),('modsets','verify'),('profiles','apply'),('presentation','query')}
  result=command('fixture-or-query-cli',argv,environment=kw.get('env'))
  encoding=kw.get('encoding') or ('utf-8' if kw.get('text') else None)
  return subprocess.CompletedProcess(argv,result.returncode,result.stdout.decode(encoding) if encoding else result.stdout,result.stderr.decode(encoding) if encoding else result.stderr)
 native_cli.subprocess=SimpleNamespace(run=logged_run,PIPE=subprocess.PIPE)
 import test_make_ready_preparation as make
 import test_local_modset_solver as solver
 import test_presentation_profile_preparation as schema_helpers
 # Keep the existing validator implementation; read immutable delivered schemas, never dirty primary schemas.
 schema_helpers.ROOT=delivery
 fixture_before=tree(solver.FIXTURE_INSTALL)
 consumer=SCENARIO/'consumer';oracle=make.MakeReadyPreparationTests()
 instance,original,expected=oracle.prepare(consumer,'load_save',raw=True,crlf=True)
 target=instance/'config/config.ini';sidecar=instance/'metadata/save-refs/selected.zip.save-ref.v1.json'
 file_identity=(target.stat().st_dev,target.stat().st_ino)
 preserved=oracle.preserved_inputs(instance)
 before=tree(consumer);exclusive(SCENARIO/'workspace-preimage.json',before)
 exclusive(SCENARIO/'fixture-preimage.json',fixture_before)
 initial=oracle.query(consumer,'instances','load_save');assert tree(consumer)==before
 assert not sidecar.exists()
 prior_receipts=set((consumer/'.facman/action-receipts-v2').glob('*.v2.json'))
 effects=[]
 for number,component in enumerate(('routing_configuration','selected_save_declared_context'),1):
  current=oracle.query(consumer,'instances','load_save')
  descriptor=next(x for x in current['available_semantic_actions'] if x['action_id']=='readiness.prepare')
  assert descriptor['availability']=='available' and descriptor['effects']==['workspace_write'] and descriptor['confirmation']=='explicit'
  stage_before=tree(consumer)
  # Separate retained UI outputs; both stages target the same owned workspace.
  stage=SCENARIO/f'stage-{number:02d}';stage.mkdir()
  output=stage/'ui-result.json'
  binding=dict(schema='facman.produced_live_ui_ownership.v1',source=SOURCE,scenario=str(SCENARIO),gui=str(gui),gui_sha256=sha(gui),workspace=str(consumer),output=str(output),action_label='Make Ready',admission_sha256=sha(ADMISSION),execution_review_sha256=sha(REVIEW))
  owner=SCENARIO/f'.facman-live-ui-owner-{number:02d}.v1.json'
  exclusive(owner,binding)
  command('actual-gui-'+component,['powershell','-NoProfile','-ExecutionPolicy','RemoteSigned','-MTA','-File',str(HELPER),'-Gui',str(gui),'-GuiSha256',sha(gui),'-Workspace',str(consumer),'-ActionLabel','Make Ready','-Output',str(output),'-Scenario',str(SCENARIO),'-OwnershipSha256',sha(owner),'-OwnerFile',str(owner)],180)
  ui=load(output);assert ui['status']=='PASS_ACTUAL_PRODUCT_UI_MAKE_READY_TRANSPORT_REQUIRES_DOMAIN_ORACLE_REVIEW' and ui['gui_terminal'] is True
  added=set((consumer/'.facman/action-receipts-v2').glob('*.v2.json'))-prior_receipts
  matching=[(p,load(p)) for p in added if load(p)['action_id']=='readiness.prepare']
  assert len(added)==len(matching)==1
  path,semantic=matching[0];prior_receipts|=added
  request=json.loads(semantic['request_json']);result=json.loads(semantic['result_json'])
  assert semantic['state']=='terminal' and semantic['scope']=='instances'
  assert semantic['request_fingerprint']==hashlib.sha256(semantic['request_json'].encode()).hexdigest()
  assert semantic['result_digest']==hashlib.sha256(semantic['result_json'].encode()).hexdigest() and semantic['result_length']==len(semantic['result_json'].encode())
  assert semantic['idempotency_key']=='winforms-'+request['request_id']
  assert semantic['key_digest']==sha_bytes(semantic['idempotency_key'].encode()) and path.name==semantic['key_digest']+'.v2.json'
  assert result['action_id']==request['action_id']==semantic['action_id']=='readiness.prepare'
  assert request['selected_instance_id']=='main' and request['launch_intent']=='load_save' and request['confirmation']=='explicit'
  assert request['expected_snapshot_revision']==current['revision']
  assert result['schema']=='facman.semantic_action_result.v1' and result['command']=='presentation.action'
  assert result['outcome']=='completed' and result['operation']['outcome']=='completed' and result['effects']==['workspace_write']
  assert result['request_id']==request['request_id']==semantic['request_id']
  assert result['operation']['durable_operation_id']==semantic['operation_id']
  for rk,qk in [('request_id','request_id'),('operation_id','durable_operation_id'),('attempt_id','attempt_id')]:
   assert result['operation'][rk]==semantic[rk]==request[qk] and request[qk]
  payload=result['action_payload'];make.factorio_validator('factorio_make_ready_preparation_result.v1.schema.json').validate(payload)
  assert payload['composition']=='partial' and payload['fresh_revision_required'] and not any(payload[k] for k in ('execution_started','permit_issued','readiness_complete'))
  assert len(payload['completed_components'])==1 and payload['completed_components'][0]['component']==component
  effect=payload['completed_components'][0]
  journal=load(consumer/'transactions'/ (effect['transaction_id']+'.transaction.v1.json'))
  assert journal['state']=='complete' and journal['command_id']==effect['owner_command'] and effect['owner_result']['transaction_id']==journal['transaction_id'] and effect['owner_result']['instance_id']=='main'
  assert target.read_bytes()==expected and (target.stat().st_dev,target.stat().st_ino)==file_identity and oracle.preserved_inputs(instance)==preserved
  ready=result['replacement_snapshot']['readiness'];assert not ready['execution_available'] and ready['play_authority_state']=='unavailable'
  if number==1:
   assert payload['deferred_components']==[dict(component='selected_save_declared_context',reason='fresh_revision_required')] and not sidecar.exists()
   after=oracle.query(consumer,'instances','load_save');assert after['revision']!=current['revision']
  else:
   assert payload['deferred_components']==[]
   document=load(sidecar);make.factorio_validator('factorio_save_ref.v1.schema.json').validate(document)
   plan=current['dependency_identities']['selected_save_preparation']['plan']
   assert plan['target']==str(sidecar) and document['save_sha256']==sha(instance/'saves'/plan['selected_save']) and document['profile_id']==plan['profile_id']
   assert document['factorio_version']==load(instance/'instance.v1.json')['factorio_version'] and document['modset_lock_sha256']==sha(instance/'mods/modset-lock.v1.json') and document['source_operation']=='readiness.prepare_selected_save'
  after_tree=tree(consumer)
  changes={name for name in set(stage_before)|set(after_tree) if stage_before.get(name)!=after_tree.get(name)}
  # Only product config/context plus owner bookkeeping may change. Bind full preimages and retain exact changes.
  product={'instances/main/config/config.ini','instances/main/metadata/save-refs/selected.zip.save-ref.v1.json'}
  assert all(name in product or name.startswith(('transactions/','audit/','.facman/action-receipts-v2/','instances/main/locks/')) for name in changes),changes
  effects.append(dict(component=component,receipt_path=str(path),receipt_sha256=sha(path),operation_id=semantic['operation_id'],transaction_id=journal['transaction_id'],ui_output_sha256=sha(output),display_truncated=ui['display_receipt_truncated'],workspace_changes=sorted(changes)))
  exclusive(SCENARIO/f'workspace-post-stage-{number:02d}.json',after_tree)
 assert tree(solver.FIXTURE_INSTALL)==fixture_before and tree(delivery)==a['delivery_files']
 assert git('rev-parse','HEAD')==head and git('status','--porcelain')==frozen_status
 assert hashlib.sha256(subprocess.check_output(['git','diff','HEAD','--binary'],cwd=R,timeout=30)).hexdigest()==frozen_diff
 assert sum(f.stat().st_size for f in SCENARIO.rglob('*') if f.is_file())<64*1024**2
 record.update(status='PASS_SCOPED_ACTUAL_DELIVERED_GUI_MAKE_READY_REQUIRES_INDEPENDENT_RESULT_REVIEW',effects=effects,visible_partial_fields_accepted=False,human_qualified=False,whole_workspace_preimages_bound=True,delivery_and_fixture_unchanged=True,source_gameplay_claim='unclaimed')
except BaseException as error:
 record.update(status='ACTIONABLE_FAILURE_RETAIN_ALL_OWNED_EVIDENCE',error=repr(error),traceback=traceback.format_exc())
finally:
 record['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 try:save()
 finally:
  output_stream.close()
  for handle in reversed(leases):kernel.CloseHandle(handle)
print(json.dumps(dict(status=record['status'],receipt_sha256=sha(OUTPUT),commands=len(records))),flush=True)
if not record['status'].startswith('PASS_'):raise SystemExit(1)
