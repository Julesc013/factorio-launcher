param(
    [Parameter(Mandatory=$true)][string]$Gui,
    [Parameter(Mandatory=$true)][string]$GuiSha256,
    [Parameter(Mandatory=$true)][string]$Workspace,
    [Parameter(Mandatory=$true)][string]$ActionLabel,
    [Parameter(Mandatory=$true)][string]$Output,
    [Parameter(Mandatory=$true)][string]$Scenario,
    [Parameter(Mandatory=$true)][string]$OwnerFile,
    [Parameter(Mandatory=$true)][string]$OwnershipSha256
)
$ErrorActionPreference='Stop'
# Use this Desktop host's own built-ins rather than inherited PowerShell 7 discovery.
Import-Module "$PSHOME\Modules\Microsoft.PowerShell.Utility\Microsoft.PowerShell.Utility.psd1" -ErrorAction Stop
Import-Module "$PSHOME\Modules\Microsoft.PowerShell.Management\Microsoft.PowerShell.Management.psd1" -ErrorAction Stop
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
$scenarioPath=[IO.Path]::GetFullPath($Scenario).TrimEnd('\')
$taskPath=[IO.Path]::GetDirectoryName([IO.Path]::GetDirectoryName($PSCommandPath))
if(-not $scenarioPath.StartsWith($taskPath+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Unowned scenario'}
foreach($value in @($Workspace,$Output)){
    if(-not [IO.Path]::GetFullPath($value).StartsWith($scenarioPath+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Path outside owned scenario'}
}
if(Test-Path -LiteralPath $Output){throw 'Never replay or overwrite a retained UI attempt'}
if((Get-FileHash -LiteralPath $Gui -Algorithm SHA256).Hash.ToLower() -ne $GuiSha256){throw 'GUI bytes changed'}
$env:FACMAN_WORKSPACE=[IO.Path]::GetFullPath($Workspace)
Remove-Item Env:FACMAN_PRESENTATION_MODE -ErrorAction SilentlyContinue
Remove-Item Env:FACMAN_CLI_EXE -ErrorAction SilentlyContinue
Remove-Item Env:FACMAN_CLI_PATH -ErrorAction SilentlyContinue
$ownerPath=[IO.Path]::GetFullPath($OwnerFile)
if([IO.Path]::GetDirectoryName($ownerPath) -ne $scenarioPath){throw 'Owner file outside scenario'}
if((Get-FileHash -LiteralPath $ownerPath -Algorithm SHA256).Hash.ToLower() -ne $OwnershipSha256){throw 'Unknown attempt ownership'}
$owner=Get-Content -LiteralPath $ownerPath -Raw | ConvertFrom-Json
if($owner.schema -ne 'facman.produced_live_ui_ownership.v1' -or $owner.source -ne '5cb795a12521e926d9335da9cc66b6868a2319c8' -or
    $owner.scenario -ne $scenarioPath -or $owner.gui -ne [IO.Path]::GetFullPath($Gui) -or $owner.gui_sha256 -ne $GuiSha256 -or
    $owner.workspace -ne [IO.Path]::GetFullPath($Workspace) -or
    $owner.output -ne [IO.Path]::GetFullPath($Output) -or $owner.action_label -ne $ActionLabel){throw 'Attempt binding changed'}
if([Security.Principal.WindowsIdentity]::GetCurrent().Name -ne 'BLACKGLASS-WIN1\Jules' -or
    -not [Environment]::UserInteractive -or [Diagnostics.Process]::GetCurrentProcess().SessionId -eq 0){throw 'Interactive Jules desktop unavailable'}
# Retain the complete output ancestry without delete-sharing. The parent must
# independently bind this attempt and own all launched processes in one job.
$interop=@"
using System;
using System.Runtime.CompilerServices;
using System.Windows.Automation;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.Win32.SafeHandles;
public static class FacmanLiveUiNative {
 [MethodImpl(MethodImplOptions.NoInlining)]
 public static void InitializeAutomation() {
  ClientSettings.RegisterClientSideProviders(new ClientSideProviderDescription[0]);
 }
 [StructLayout(LayoutKind.Sequential)] struct Info {
  public uint Attributes, CreationLow, CreationHigh, AccessLow, AccessHigh,
   WriteLow, WriteHigh, Volume, SizeHigh, SizeLow, Links, IndexHigh, IndexLow;
 }
 [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
 static extern SafeFileHandle CreateFileW(string p,uint access,uint share,IntPtr security,uint disposition,uint flags,IntPtr template);
 [DllImport("kernel32.dll", SetLastError=true)] static extern bool GetFileInformationByHandle(SafeFileHandle h,out Info i);
 [DllImport("user32.dll", SetLastError=true)] static extern uint GetWindowThreadProcessId(IntPtr h,out uint pid);
 [DllImport("user32.dll", CharSet=CharSet.Unicode,SetLastError=true)]
 static extern IntPtr SendMessageTimeoutW(IntPtr h,uint message,UIntPtr size,StringBuilder text,uint flags,uint timeout,out UIntPtr result);
 public static SafeFileHandle HoldDirectory(string p) {
  var h=CreateFileW(p,0x80,3,IntPtr.Zero,3,0x02200000,IntPtr.Zero);
  Info i;
  if(h.IsInvalid || !GetFileInformationByHandle(h,out i) || (i.Attributes&0x10)==0 || (i.Attributes&0x400)!=0) {
   h.Dispose();throw new InvalidOperationException("Unsafe or unavailable output ancestor");
  }
  return h;
 }
 public static string ReadOwnedText(int handle,int expectedPid,uint timeout) {
  var h=new IntPtr(handle);uint pid;
  if(handle==0 || GetWindowThreadProcessId(h,out pid)==0 || pid!=(uint)expectedPid || timeout==0)
   throw new InvalidOperationException("Unowned text control");
  var text=new StringBuilder(2048);UIntPtr result;
  if(SendMessageTimeoutW(h,0x000D,new UIntPtr(2048),text,3,timeout,out result)==IntPtr.Zero)
   throw new Win32Exception(Marshal.GetLastWin32Error());
  return text.ToString();
 }
}
"@
Add-Type -TypeDefinition $interop -ReferencedAssemblies @('System.dll',[Windows.Automation.AutomationElement].Assembly.Location,[Windows.Automation.ControlType].Assembly.Location)
if([Threading.Thread]::CurrentThread.ApartmentState -ne 'MTA'){throw 'UIA client requires MTA'}
[FacmanLiveUiNative]::InitializeAutomation()
$leases=[Collections.Generic.List[IDisposable]]::new()
$outputStream=$null
try {
    $ancestor=[IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($Output))
    while(-not [string]::IsNullOrEmpty($ancestor)){
        $leases.Add([FacmanLiveUiNative]::HoldDirectory($ancestor))
        $ancestor=[IO.Path]::GetDirectoryName($ancestor)
    }
    # The original file handle remains held across every receipt update;
    # no path replacement, forced rename or deletion is used by this helper.
    $outputStream=[IO.FileStream]::new($Output,[IO.FileMode]::CreateNew,[IO.FileAccess]::ReadWrite,[IO.FileShare]::Read)
}
catch {
    foreach($lease in $leases){$lease.Dispose()}
    throw
}
$started=[DateTime]::UtcNow
$watch=[Diagnostics.Stopwatch]::StartNew()
$guiProcess=$null
$steps=[Collections.Generic.List[object]]::new()
$record=[ordered]@{status='RUNNING';human_qualification=$false;setup_executed=$false;factorio_executed=$false;steps=$steps}
function Save-Record {
    $bytes=[Text.UTF8Encoding]::new($false).GetBytes(($record | ConvertTo-Json -Depth 8))
    $outputStream.Position=0;$outputStream.SetLength(0)
    $outputStream.Write($bytes,0,$bytes.Length);$outputStream.Flush($true)
}
function Guard {
    if($watch.Elapsed.TotalSeconds -ge 150){throw 'Owned UI interaction deadline reached'}
    if($guiProcess.HasExited){throw 'Owned product GUI exited before completion'}
    if((Get-Process -Id $guiProcess.Id -ErrorAction Stop).StartTime.ToUniversalTime() -ne $guiBirth){throw 'GUI process identity changed'}
    if($watch.Elapsed.TotalSeconds -ge 150){throw 'Owned UI interaction deadline reached'}
}
function Owned-Windows {
    Guard
    $condition=[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$guiProcess.Id)
    $roots=[Windows.Automation.AutomationElement]::RootElement.FindAll([Windows.Automation.TreeScope]::Children,$condition)
    $windows=[Collections.Generic.List[Windows.Automation.AutomationElement]]::new()
    $seen=[Collections.Generic.HashSet[int]]::new()
    $nestedCondition=[Windows.Automation.AndCondition]::new($condition,
        [Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ControlTypeProperty,[Windows.Automation.ControlType]::Window))
    foreach($root in $roots){
        Guard
        if($seen.Add($root.Current.NativeWindowHandle)){$windows.Add($root)}
        foreach($window in $root.FindAll([Windows.Automation.TreeScope]::Descendants,$nestedCondition)){
            Guard
            if($seen.Add($window.Current.NativeWindowHandle)){$windows.Add($window)}
        }
    }
    return $windows
}
function Named($root,[string]$name,$kind) {
    $conditions=[Windows.Automation.AndCondition]::new(
        [Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::NameProperty,$name),
        [Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ControlTypeProperty,$kind))
    $items=$root.FindAll([Windows.Automation.TreeScope]::Descendants,$conditions)
    if($items.Count -gt 1){throw ('Ambiguous owned control '+$name)}
    if($items.Count -eq 1){return $items.Item(0)}
    return $null
}
function Wait-Element([scriptblock]$probe,[string]$stage) {
    while($true){
        Guard
        $item=& $probe
        if($null -ne $item){Guard;$steps.Add(@{stage=$stage;seconds=$watch.Elapsed.TotalSeconds});Save-Record;return $item}
        Start-Sleep -Milliseconds 100
    }
}
function Invoke-Button($root,[string]$name) {
    Guard
    $button=Named $root $name ([Windows.Automation.ControlType]::Button)
    if($null -eq $button -or -not $button.Current.IsEnabled){throw ('Missing or disabled owned button '+$name)}
    ([Windows.Automation.InvokePattern]$button.GetCurrentPattern([Windows.Automation.InvokePattern]::Pattern)).Invoke()
}
function Dialog([bool]$editors) {
    foreach($window in (Owned-Windows)){
        if($window.Current.Name -ne $ActionLabel){continue}
        $field=Named $window 'Selected instance' ([Windows.Automation.ControlType]::ComboBox)
        if(($null -ne $field) -eq $editors){return $window}
    }
    return $null
}
try {
    # Always launch the actual admitted executable. No gallery, source harness,
    # transport factory substitution, injected semantic action or package edits.
    $guiProcess=Start-Process -FilePath $Gui -WorkingDirectory ([IO.Path]::GetDirectoryName($Gui)) -WindowStyle Normal -PassThru
    $guiBirth=$guiProcess.StartTime.ToUniversalTime()
    $record.pid=$guiProcess.Id;$record.process_birth=$guiBirth.ToString('o');$record.gui_sha256=$GuiSha256
    Save-Record
    $main=Wait-Element {foreach($w in (Owned-Windows)){if($w.Current.Name -in @('FacMan C1 product window','FacMan')){return $w}}} 'actual_owned_product_window'
    $settings=Wait-Element {Named $main 'Settings / About' ([Windows.Automation.ControlType]::TabItem)} 'settings_page'
    ([Windows.Automation.SelectionItemPattern]$settings.GetCurrentPattern([Windows.Automation.SelectionItemPattern]::Pattern)).Select()
    Guard
    $steps.Add(@{stage='settings_selection_pattern_supported'});Save-Record
    $observedWorkspace=Wait-Element {
        $node=Named $main 'Workspace identity and health' ([Windows.Automation.ControlType]::Text)
        if($null -ne $node){
            $remaining=[Math]::Floor((150-$watch.Elapsed.TotalSeconds)*1000)
            if($remaining -le 0){throw 'UI interaction deadline reached'}
            $text=[FacmanLiveUiNative]::ReadOwnedText($node.Current.NativeWindowHandle,$guiProcess.Id,[uint32][Math]::Min(1000,$remaining))
            if($text.Contains([IO.Path]::GetFullPath($Workspace))){return $node}
        }
    } 'backend_observed_owned_workspace'
    $steps.Add(@{stage='owned_workspace_text_handle_supported';handle=$observedWorkspace.Current.NativeWindowHandle});Save-Record
    $page=Wait-Element {Named $main 'Instances' ([Windows.Automation.ControlType]::TabItem)} 'instances_page'
    ([Windows.Automation.SelectionItemPattern]$page.GetCurrentPattern([Windows.Automation.SelectionItemPattern]::Pattern)).Select()
    $observation=Wait-Element {Named $main 'Readiness observation' ([Windows.Automation.ControlType]::ComboBox)} 'ordinary_observation_control'
    ([Windows.Automation.ExpandCollapsePattern]$observation.GetCurrentPattern([Windows.Automation.ExpandCollapsePattern]::Pattern)).Expand()
    $saveChoice=Wait-Element {foreach($w in (Owned-Windows)){$item=Named $w 'Selected Save' ([Windows.Automation.ControlType]::ListItem);if($null -ne $item){return $item}}} 'selected_save_observation_choice'
    ([Windows.Automation.SelectionItemPattern]$saveChoice.GetCurrentPattern([Windows.Automation.SelectionItemPattern]::Pattern)).Select()
    $button=Wait-Element {
        $value=[Windows.Automation.ValuePattern]$observation.GetCurrentPattern([Windows.Automation.ValuePattern]::Pattern)
        $candidate=Named $main 'Prepare this instance' ([Windows.Automation.ControlType]::Button)
        if($observation.Current.IsEnabled -and $value.Current.Value -eq 'Selected Save' -and $null -ne $candidate -and $candidate.Current.IsEnabled){return $candidate}
    } 'fresh_selected_save_backend_observation'
    ([Windows.Automation.InvokePattern]$button.GetCurrentPattern([Windows.Automation.InvokePattern]::Pattern)).Invoke()
    $input=Wait-Element {Dialog $true} 'typed_make_ready_input_dialog'
    $instance=Named $input 'Selected instance' ([Windows.Automation.ControlType]::ComboBox)
    $selected=[Windows.Automation.ValuePattern]$instance.GetCurrentPattern([Windows.Automation.ValuePattern]::Pattern)
    if($selected.Current.Value -ne 'main'){throw 'Wrong selected instance; never change unknown target'}
    Invoke-Button $input 'Continue'
    $confirm=Wait-Element {Dialog $false} 'explicit_make_ready_confirmation'
    if($null -eq (Named $confirm ('Apply '+$ActionLabel+' using the reviewed values?') ([Windows.Automation.ControlType]::Text))){throw 'Unknown confirmation'}
    Invoke-Button $confirm 'OK'
    $result=Wait-Element {
        $dialog=Dialog $false
        if($null -ne $dialog -and $null -eq (Named $dialog ('Apply '+$ActionLabel+' using the reviewed values?') ([Windows.Automation.ControlType]::Text))){return $dialog}
    } 'actual_backend_result_dialog'
    $texts=$result.FindAll([Windows.Automation.TreeScope]::Descendants,[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ControlTypeProperty,[Windows.Automation.ControlType]::Text))
    $resultText=(@($texts | ForEach-Object {$_.Current.Name}) -join "`n")
    if($resultText -notmatch 'factorio.make_ready_preparation_result.v1' -or $resultText -notmatch 'readiness.prepare'){throw 'No actual Make Ready result'}
    $record.displayed_result=$resultText
    $record.display_receipt_truncated=$resultText.EndsWith('...')
    $record.visible_partial_fields_claim=$false
    Invoke-Button $result 'OK'
    $record.status='PASS_ACTUAL_PRODUCT_UI_MAKE_READY_TRANSPORT_REQUIRES_DOMAIN_ORACLE_REVIEW'

}
catch {
    $record.status='ACTIONABLE_UI_FAILURE_RETAIN_WORKSPACE'
    $record.error=$_.Exception.ToString()
}
finally {
    if($null -ne $guiProcess){
        if(-not $guiProcess.HasExited){$null=$guiProcess.CloseMainWindow();$null=$guiProcess.WaitForExit(5000)}
        if(-not $guiProcess.HasExited){$guiProcess.Kill();$guiProcess.WaitForExit(5000) | Out-Null;$record.gui_forced_stop=$true}
        $record.gui_terminal=$guiProcess.HasExited
        if(-not $guiProcess.HasExited){$record.status='ACTIONABLE_UI_FAILURE_GUI_NOT_TERMINAL'}
    }
    $record.elapsed_seconds=$watch.Elapsed.TotalSeconds;$record.finished_at=[DateTime]::UtcNow.ToString('o')
    try {Save-Record} finally {$outputStream.Dispose();foreach($lease in $leases){$lease.Dispose()}}
}
if(-not $record.status.StartsWith('PASS_')){exit 1}
