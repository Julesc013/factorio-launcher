"""Reuse the retired owned branch at qualified dev; no WorkUnit/root admission."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tomllib

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
H = 'be3f5f47cb555661cd15ed2c96c475fd412c578d'
B = 'task/facman-world-restore-retention-01'
U = 'FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
sys.path.insert(0, str(R/'.aide/scripts'))
import aide_lite

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def run(*args):
    p = subprocess.run(args, cwd=R, capture_output=True, text=True, encoding='utf-8', timeout=120)
    assert p.returncode == 0, (args, p.returncode, p.stderr[:500])
    return p.stdout.strip()

def write(p, v):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        f.write(json.dumps(v, indent=2)+'\n')

assert __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0'
assert run('git', 'branch', '--show-current') == 'dev'
assert run('git', 'rev-parse', 'HEAD') == run('git', 'rev-parse', 'origin/dev') == H
assert not run('git', 'status', '--porcelain')
terminal = E/'make-ready-save-context-integration-01.json'
assert sha(terminal) == 'c44b05c7737b4afe33c134c4074fd9defeba7d63426db285f98f39022d2ba460'
t = json.loads(terminal.read_text(encoding='utf-8'))
assert t['status'] == 'integration_and_automatic_merge_CI_pass' and t['merge'] == H and t['branch_retired']
marker = E.parent/'.facman-development-root.v1.json'
m = json.loads(marker.read_text(encoding='utf-8'))
assert m['task_id'] == B and Path(m['canonical_path']).samefile(E.parent) and Path(m['source_root']).samefile(R)
plan = tomllib.loads((R/'release/index/plan.v1.toml').read_text(encoding='utf-8'))
unit = next(x for x in plan['workunit'] if x['id'] == U)
assert unit['status'] == 'active' and len(unit['close_after']) == 5
assert run('powershell', '-NoProfile', '-Command', '[System.Security.Principal.WindowsIdentity]::GetCurrent().Name') == 'BLACKGLASS-WIN1\\Jules'
run('gh', 'auth', 'status')
assert run('gh', 'api', 'user', '--jq', '.login') == 'Julesc013'
assert run('gh', 'api', 'repos/Julesc013/factorio-launcher/git/ref/heads/dev', '--jq', '.object.sha') == H
assert not run('git', 'ls-remote', '--heads', 'origin', 'refs/heads/'+B)
assert subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/'+B],cwd=R).returncode == 1
assert json.loads(run('gh', 'pr', 'list', '--head', B, '--state', 'open', '--json', 'number')) == []
for name, extra in [('paths', []), ('doctor', ['--measure'])]:
    p = subprocess.run([sys.executable,'-B','tools/workspace_hygiene.py',name,*extra],cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
    hygiene = json.loads(p.stdout)
    write(E/('make-ready-save-view-prebranch-'+name+'.json'),hygiene)
    if name == 'doctor':
        assert p.returncode in {0,1} and set(hygiene['violations']) <= {'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
        assert len(hygiene['task_roots']) <= 8 and hygiene['task_root_bytes'] <= 20*1024**3
    else:
        assert p.returncode == 0
for category, operations in [('task',['inspect','noop-check','recover']),('git',['policy','detect','plan'])]:
    for operation in operations:
        argv = [sys.executable,'-B','.aide/scripts/aide_lite.py',category,operation]
        if category == 'task':
            argv += ['--task-id',U]
        with (E/('make-ready-save-view-prebranch-'+category+'-'+operation+'.log')).open('x',encoding='utf-8') as f:
            p = subprocess.run(argv,cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=120)
        assert p.returncode == 0
helper = aide_lite.make_git_helper_plan(R, 'plan')
assert helper['status'] == 'ready_dry_run' and not helper['blockers']
review = E/'make-ready-save-context-final-commit.review.json'
assert sha(review) == '6ebd8de6085714eb1043c337698bee4a7d3c759ac8371a17b00f6ef99126f142'
argv = ['git','switch','--no-track','-c',B,H]
write(E/'make-ready-save-view-branch-01-plan.json', dict(
    schema='facman.exact-base-task-branch-plan.v1', work_item=U, branch=B, start_commit=H,
    helper_plan=helper, planned_command=argv,
    operator_authority='Standing compact-restart authorization: new sequential task from latest qualified dev, same active MakeReady outcome and retired immutable owned-root branch identifier.',
    prior_integration_sha256=sha(terminal), qualified_owner_contract_review_sha256=sha(review),
    root=str(E.parent), marker_sha256=sha(marker), original_acceptance=unit['acceptance'],
    close_after=unit['close_after'], new_roots=0, new_worktrees=0, task_start_repeated=False,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
write(E/'make-ready-save-view-branch-01.claim.json', dict(pid=os.getpid(), no_automatic_replay=True))
run(*argv)
assert sha(marker) == json.loads((E/'make-ready-save-view-branch-01-plan.json').read_text())['marker_sha256']
write(E/'make-ready-save-view-branch-01.json', dict(status='branch_created_from_qualified_dev',branch=B,base=H,work_item=U,new_roots=0,new_worktrees=0,acceptance_complete=False))
print(json.dumps(dict(status='branch_created_from_qualified_dev', branch=B, base=H)))
