"""Preserve bounded GUI rendering proof and classify exact normal commit input."""
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tomllib
import zipfile

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
P = 'make-ready-save-view'
U = 'FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
BASE = 'be3f5f47cb555661cd15ed2c96c475fd412c578d'
B = 'task/facman-world-restore-retention-01'
Q = R/'.aide/queue/active'/U/'evidence'
sys.path.insert(0, str(R/'.aide/scripts'))
import aide_lite as aide

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f: f.write(json.dumps(value, indent=2)+'\n')
def out(*args):
    result = subprocess.run(args, cwd=R, capture_output=True, text=True, encoding='utf-8', timeout=120)
    assert result.returncode == 0, (args, result.returncode, result.stderr[:500])
    return result.stdout.strip()
def check(name, args):
    log = E/(P+'-precommit-'+name+'.log')
    with log.open('x', encoding='utf-8') as f:
        result = subprocess.run(args, cwd=R, stdout=f, stderr=subprocess.STDOUT, timeout=900)
    entry = dict(check=name, argv=args, exit_code=result.returncode, log=str(log), sha256=sha(log))
    assert result.returncode == 0, entry
    return entry

assert __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0'
assert out('git','rev-parse','HEAD') == BASE and out('git','branch','--show-current') == B
proof_path = E/(P+'-source-proof-03.json')
assert sha(proof_path) == 'a6c31c97c763aa8cbc202c55430d4873aafec1acf71f834e9b9f1d7f1ae567d2'
proof = json.loads(proof_path.read_text(encoding='utf-8'))
assert proof['status'] == 'PASS_SCOPED_WINDOWS_OWNER_CONTEXT_RENDERING' and proof['runtime_cases'] == 7
assert proof['actual_backend_cases'] == 6 and proof['optional_context_absent_compatibility_cases'] == 1 and proof['runtime_skips'] == 0
assert proof['GUI_builds'] == 1 and proof['native_builds'] == 0 and not proof['owner_query_replay']
assert len(proof['checks']) == 9 and all(x['exit_code'] == 0 for x in proof['checks'])
for check_record in proof['checks']: assert sha(Path(check_record['log'])) == check_record['sha256']
functional = proof['source_hashes']
assert len(functional) == 7
for path, digest in functional.items(): assert sha(R/path) == digest, path
for name, digest in proof['binary_identities'].items(): assert sha(E.parent/'winforms-save-view/bin'/name) == digest
baseline = json.loads((E/(P+'-baseline-01.json')).read_text(encoding='utf-8'))
fixture_dir = E/(P+'-baseline-01-fixture')
assert sha(fixture_dir/'cases.json') == proof['reused_owner_cases_sha256'] == baseline['cases_sha256']
canonical = R/'release/index/plan.v1.toml'
original = canonical.read_text(encoding='utf-8')
plan = tomllib.loads(original)
unit = next(x for x in plan['workunit'] if x['id'] == U)
assert unit['status'] == 'active' and len(unit['close_after']) == 5 and len(unit['acceptance']) == 2
archive = Q/'save-context-rendering-custody.zip'
files = sorted(p for p in E.glob(P+'-*') if p.is_file() and p.suffix in {'.json','.jsonl','.log','.py'})
assert len(files) >= 25 and sum(p.stat().st_size for p in files) < 8*1024**2
members = {p.name: sha(p) for p in files}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for p in files: z.write(p, p.name)
    for name in ['cases.json','build.log','run.log','binary-identities.json']:
        z.write(fixture_dir/name, 'baseline-fixture/'+name)
        members['baseline-fixture/'+name] = sha(fixture_dir/name)
    for path, digest in functional.items():
        z.write(R/path, 'source/'+path); members['source/'+path] = digest
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist()) == set(members)
    for name, digest in members.items(): assert hashlib.sha256(z.read(name)).hexdigest() == digest, name
receipt = Q/'save-context-rendering.v1.json'
public = dict(schema='facman.save_context_rendering.v1', status='PASS_SCOPED_WINDOWS_SOURCE_RENDERING', work_item=U, base=BASE,
    behavior='Windows Saves rows retain owner-reported overall/version/content context states and display declared context separately from save-byte status; absent optional context remains Not observed.',
    source_hashes=functional, binary_identities=proof['binary_identities'], source_proof_sha256=sha(proof_path), baseline_sha256=sha(E/(P+'-baseline-01.json')),
    acceptance_scope=dict(runtime_cases=7, actual_backend_cases=6, optional_context_absent_compatibility_cases=1, skips=0,
        match=True, version_drift=True, content_drift=True, unknown_legacy_evidence=True, unavailable_context=True,
        byte_drift_with_matching_context=True, distinct_columns=True, backend_states_forwarded_without_recomputation=True,
        gallery_action_count_zero=True, actual_rendered_ListView_rows=True, windows_hidden_form=True,
        Python_test_method_rerun=False, corrected_GUI_uses_exact_retained_backend_cases=True),
    owner_producer=dict(integrated_source='4b32a15a59777911fe3911c55b5bc1f2be4c7ec5', integrated_dev=BASE,
        CLI_sha256=proof['reused_owner_CLI_sha256'], retained_public_commands=16, new_public_commands=0,
        cases_sha256=proof['reused_owner_cases_sha256'], exact_Git_and_LF_source_bindings=proof['owner_source_EOL_bindings']),
    custody=dict(path=archive.relative_to(R).as_posix(), sha256=sha(archive), members=members),
    retained_failures=['Actual compiled baseline dropped owner association_context_status before rendering.',
        'Preclaim guard stopped on generated-file checkout CRLF; exact filtered Git objects and LF producer bytes verified, with no semantic change.',
        'Strict language policy rejected a new C# test root; unchanged harness moved into existing admitted WinForms control-gallery test root. Policy unchanged.'],
    resource_use=dict(GUI_builds=2, corrected_GUI_builds=1, native_builds=0, owner_query_replays=0, maximum_workers=2,
        maximum_heavy_local_jobs=1, new_task_roots=0, new_worktrees=0, optional_candidate_dispatches=0, CI_reruns=0,
        unchanged_wait_model_calls=0, prior_producer_images_and_evidence_preserved=True),
    original_acceptance=unit['acceptance'], close_after=unit['close_after'],
    qualification=dict(source_fixture=True, produced_package=False, actual_Factorio=False, human_experience=False,
        gameplay_compatibility=False, selected_save_launch=False, full_windows_backend_link_qualification=False,
        release=False, whole_workunit=False, full_programme=False, exact_current_source_CI='pending'),
    external_gates_preserved=['PR343 protected-control owner authorization', 'Genuine distinct-version Linux Setup A5 update/rollback',
        'MakeReady five original close-after prerequisites', 'Windows backend required link cell remains host blocked'],
    finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
write(receipt, public)
start = original.index('id = "'+U+'"'); end = original.index('\n\n[[workunit]]', start)
section = original[start:end]; needle = '\n]\nqueue_task = '
assert section.count(needle) == 1
section = section.replace(needle, '\n  '+json.dumps(receipt.relative_to(R).as_posix())+',\n]\nqueue_task = ', 1)
canonical.write_text(original[:start]+section+original[end:], encoding='utf-8', newline='\n')
expected = copy.deepcopy(plan)
next(x for x in expected['workunit'] if x['id'] == U)['evidence'].append(receipt.relative_to(R).as_posix())
assert tomllib.loads(canonical.read_text(encoding='utf-8')) == expected
checks = []
for name, args in [('plan-generate',['tools/generate_plan_views.py']), ('state-generate',['tools/project_state.py','--write']),
    ('plan-check',['tools/generate_plan_views.py','--check']), ('state-check',['tools/project_state.py','--validate']),
    ('state-tests',['-m','unittest','tests.test_plan_views','tests.test_current_truth_roles','tests.test_aide_target_truth','tests.test_aide_compaction']),
    ('strict',['tools/strict_check.py']), ('format',['tools/source_format_check.py'])]:
    checks.append(check(name,[sys.executable,'-B',*args]))
checks.append(check('diff',['git','diff','--check']))
for path,digest in functional.items(): assert sha(R/path) == digest,path
message = E/(P+'-commit.txt')
text = ('fix(winforms): retain declared save association context\n\n'
    f'Work-Item: {U}\nEvidence-Ref: {receipt.relative_to(R).as_posix()}\n'
    'Changelog: Fixed: Show declared save context separately from save-byte status\n')
with message.open('x',encoding='utf-8',newline='\n') as f: f.write(text)
checks.append(check('template',[sys.executable,'-B','.aide/scripts/aide_lite.py','commit','template']))
checks.append(check('message',[sys.executable,'-B','.aide/scripts/aide_lite.py','commit','check','--message',text]))
paths = set(out('git','diff','--name-only').splitlines()) | set(out('git','ls-files','--others','--exclude-standard').splitlines())
allowed = set(functional) | {canonical.relative_to(R).as_posix(),receipt.relative_to(R).as_posix(),archive.relative_to(R).as_posix(),
    'README.md','docs/roadmap.md','docs/release/checkpoints/README.md','release/index/current_state.v1.toml','release/index/project_status.v2.toml',
    '.aide/memory/project-state.md','.aide/memory/project-state.v2.json','todo.md'}
assert paths <= allowed,sorted(paths-allowed)
changed = [dict(path=p,state='content',sha256=sha(R/p),git_blob_oid=out('git','hash-object','--path',p,p),ownership='task_owned') for p in sorted(paths)]
classification = dict(schema_version=aide.GIT_COMMIT_CLASSIFICATION_SCHEMA,branch=B,base_commit=BASE,work_item=U,
    message_sha256=sha(message),snapshot_sha256=aide.helper_commit_snapshot_sha256(changed),changed_paths=changed,reviews=[])
write(E/(P+'-commit-classification.json'),classification)
write(E/(P+'-precommit-QA.json'),dict(status='PASS',metadata_checks=checks,source_QA_sha256=sha(proof_path),receipt_sha256=sha(receipt),
    snapshot_sha256=classification['snapshot_sha256'],functional_source_hashes=functional,new_GUI_builds=0,new_native_builds=0,whole_workunit_closed=False))
print(json.dumps(dict(status='PASS_PACKAGED_AND_CLASSIFIED',changed_paths=len(changed),custody_members=len(members),
    receipt_sha256=sha(receipt),custody_sha256=sha(archive),classification_sha256=sha(E/(P+'-commit-classification.json')))))
