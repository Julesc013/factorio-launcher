// SPDX-FileCopyrightText: 2026 Jules C
// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static FacMan.WinForms.C1PresentationText;

namespace FacMan.WinForms
{
    /// <summary>
    /// Windows 10/11 x64 reference presentation for the deterministic C1
    /// journey. Backend behavior stays in FacMan; this form renders the
    /// FacMan-local presentation record and never starts Factorio directly.
    /// </summary>
    public sealed class C1ShellForm : Form
    {
        private readonly C1FixturePresentationStore fixtureStore;
        private readonly C1LivePresentationStore liveStore;
        private readonly CancellationTokenSource lifetime = new CancellationTokenSource();
        private readonly bool evidenceMode;
        private readonly C1GallerySession gallery;
        private readonly ToolTip toolTip;
        private TabControl pages;
        private ListView instancesList;
        private Label instancesSummary;
        private Label readinessSummary;
        private TextBox refusalDetail;
        private Label installationsSummary;
        private ListView installationsList;
        private TextBox installationDetail;
        private Label contentSummary;
        private ListView contentList;
        private Label savesSummary;
        private ListView savesList;
        private Label activitySummary;
        private ListView activityList;
        private FlowLayoutPanel activityActions;
        private ComboBox evidenceState;
        private Label evidenceScope;
        private Label workspaceSummary;
        private TextBox doctorSummary;
        private FlowLayoutPanel settingsActions;
        private Label deckInstance;
        private Label deckStatus;
        private Label deckReadiness;
        private Label deckLastRun;
        private Label deckRefusal;
        private Label deckSourceNotice;
        private Button primaryAction;
        private Button secondaryAction;
        private ToolStripStatusLabel statusLabel;
        private bool rendering;

        public C1ShellForm() : this(null) { }

        public C1ShellForm(C1GallerySession gallery)
        {
            this.gallery = gallery;
            evidenceMode = gallery == null && String.Equals(
                Environment.GetEnvironmentVariable("FACMAN_PRESENTATION_MODE"),
                "evidence",
                StringComparison.OrdinalIgnoreCase);
            fixtureStore = new C1FixturePresentationStore();
            liveStore = gallery == null ? new C1LivePresentationStore() : null;
            toolTip = new ToolTip();

            Text = gallery == null ? "FacMan" : "FacMan control gallery";
            System.Drawing.Icon applicationIcon =
                System.Drawing.Icon.ExtractAssociatedIcon(Application.ExecutablePath);
            if (applicationIcon != null) Icon = applicationIcon;
            ClientSize = new Size(1040, 720);
            MinimumSize = new Size(960, 640);
            StartPosition = FormStartPosition.CenterScreen;
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            Font = SystemFonts.MessageBoxFont;
            AccessibleName = "FacMan C1 product window";
            AccessibleDescription =
                "Instances, Installations, Content, Saves, Activity, Settings and About, a persistent Launch Deck, and Advanced commands.";
            KeyPreview = true;

            BuildLayout();
            RenderPresentation();
            Shown += async delegate { if (gallery == null && !evidenceMode) await RefreshLiveAsync(); };
            FormClosing += delegate { lifetime.Cancel(); };
            FormClosed += delegate { lifetime.Dispose(); };
        }

        private void BuildLayout()
        {
            TableLayoutPanel root = new TableLayoutPanel();
            root.Dock = DockStyle.Fill;
            root.ColumnCount = 1;
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            root.RowCount = 4;
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            Controls.Add(root);

            MenuStrip menu = BuildMenu();
            MainMenuStrip = menu;
            root.Controls.Add(menu, 0, 0);

            pages = new TabControl();
            pages.Dock = DockStyle.Fill;
            pages.AccessibleName = "FacMan product pages";
            pages.AccessibleDescription = "Six player-facing pages followed by the Advanced command explorer entry.";
            root.Controls.Add(pages, 0, 1);

            pages.TabPages.Add(BuildInstancesPage());
            pages.TabPages.Add(BuildInstallationsPage());
            pages.TabPages.Add(BuildContentPage());
            pages.TabPages.Add(BuildSavesPage());
            pages.TabPages.Add(BuildActivityPage());
            pages.TabPages.Add(BuildSettingsPage());
            pages.TabPages.Add(BuildAdvancedPage());

            root.Controls.Add(BuildLaunchDeck(), 0, 2);

            StatusStrip status = new StatusStrip();
            statusLabel = new ToolStripStatusLabel("Ready");
            statusLabel.AccessibleName = "FacMan status announcement";
            status.Items.Add(statusLabel);
            root.Controls.Add(status, 0, 3);
        }

        private MenuStrip BuildMenu()
        {
            MenuStrip menu = new MenuStrip();
            ToolStripMenuItem navigate = new ToolStripMenuItem("&Navigate");
            navigate.DropDownItems.Add(NavigationItem("&Instances", Keys.Control | Keys.D1, 0));
            navigate.DropDownItems.Add(NavigationItem("Insta&llations", Keys.Control | Keys.D2, 1));
            navigate.DropDownItems.Add(NavigationItem("&Content", Keys.Control | Keys.D3, 2));
            navigate.DropDownItems.Add(NavigationItem("Sa&ves", Keys.Control | Keys.D4, 3));
            navigate.DropDownItems.Add(NavigationItem("&Activity", Keys.Control | Keys.D5, 4));
            navigate.DropDownItems.Add(NavigationItem("&Settings / About", Keys.Control | Keys.D6, 5));
            navigate.DropDownItems.Add(new ToolStripSeparator());
            navigate.DropDownItems.Add(NavigationItem("A&dvanced", Keys.Control | Keys.D7, 6));
            menu.Items.Add(navigate);

            if (evidenceMode)
            {
                ToolStripMenuItem evidence = new ToolStripMenuItem("&Evidence mode");
                evidence.DropDownItems.Add(EvidenceItem("&Ready", "positive"));
                evidence.DropDownItems.Add(EvidenceItem("Stale &readiness", "refused"));
                evidence.DropDownItems.Add(EvidenceItem("R&unning", "running"));
                evidence.DropDownItems.Add(EvidenceItem("E&xited / Last Run", "exited"));
                evidence.DropDownItems.Add(EvidenceItem("&Interrupted / recovery", "interrupted"));
                menu.Items.Add(evidence);
            }
            else
            {
                ToolStripMenuItem live = new ToolStripMenuItem(gallery == null ? "&Live backend" : "&Gallery actions");
                ToolStripMenuItem refresh = new ToolStripMenuItem(gallery == null ? "&Refresh workspace" : "&Record refresh");
                refresh.ShortcutKeys = Keys.F5;
                refresh.Click += async delegate { await RefreshLiveAsync(); };
                live.DropDownItems.Add(refresh);
                menu.Items.Add(live);
            }
            menu.AccessibleName = "FacMan application menu";
            return menu;
        }

        private ToolStripMenuItem NavigationItem(string text, Keys shortcut, int pageIndex)
        {
            ToolStripMenuItem item = new ToolStripMenuItem(text);
            item.ShortcutKeys = shortcut;
            item.ShowShortcutKeys = true;
            item.Click += delegate { pages.SelectedIndex = pageIndex; pages.Focus(); };
            return item;
        }

        private ToolStripMenuItem EvidenceItem(string text, string state)
        {
            ToolStripMenuItem item = new ToolStripMenuItem(text);
            item.Tag = state;
            item.Click += delegate { SelectEvidenceState(state); };
            return item;
        }

        private TabPage BuildInstancesPage()
        {
            TabPage page = Page("Instances", "Instances page");
            TableLayoutPanel layout = PageLayout(5);
            page.Controls.Add(layout);

            layout.Controls.Add(Heading("Instances", "Choose an isolated instance and check readiness before Play."), 0, 0);
            instancesSummary = BodyLabel("Instances summary");
            layout.Controls.Add(instancesSummary, 0, 1);

            instancesList = new ListView();
            instancesList.MinimumSize = new Size(0, 120);
            instancesList.Dock = DockStyle.Fill;
            instancesList.View = View.Details;
            instancesList.FullRowSelect = true;
            instancesList.HideSelection = false;
            instancesList.MultiSelect = false;
            instancesList.AccessibleName = "Instances";
            instancesList.AccessibleDescription = "Available isolated Factorio instances and their readiness state.";
            instancesList.Columns.Add("Name", 220);
            instancesList.Columns.Add("Readiness", 130);
            instancesList.Columns.Add("Journey state", 150);
            instancesList.Columns.Add("Installation", 360);
            instancesList.SelectedIndexChanged += async delegate
            {
                if (rendering || evidenceMode || instancesList.SelectedItems.Count == 0) return;
                string instanceId = Convert.ToString(instancesList.SelectedItems[0].Tag);
                if (String.IsNullOrWhiteSpace(instanceId)) return;
                if (RecordGalleryAction("instance.select_context")) return;
                await liveStore.SelectInstanceAsync(instanceId, lifetime.Token);
                RenderPresentation();
            };
            layout.Controls.Add(instancesList, 0, 2);

            readinessSummary = BodyLabel("Selected instance readiness");
            readinessSummary.BorderStyle = BorderStyle.FixedSingle;
            readinessSummary.Padding = new Padding(8);
            layout.Controls.Add(readinessSummary, 0, 3);

            TableLayoutPanel actions = new TableLayoutPanel();
            actions.AutoSize = true;
            actions.Dock = DockStyle.Fill;
            actions.ColumnCount = 3;
            actions.RowCount = 2;
            actions.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            actions.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            actions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            Button create = ActionButton("&Create instance", "Create instance", "instance.create");
            Button rescan = ActionButton("&Rescan readiness", "Rescan readiness", "instance.readiness.refresh");
            actions.Controls.Add(create, 0, 0);
            actions.Controls.Add(rescan, 1, 0);
            FlowLayoutPanel planningActions = ActionRow();
            planningActions.Controls.Add(ActionButton("Create &profile", "Create launch profile", "profile.create"));
            planningActions.Controls.Add(ActionButton("Select p&rofile", "Select launch profile", "profile.select"));
            planningActions.Controls.Add(ActionButton("E&xplain config", "Explain effective configuration", "configuration.explain_effective"));
            planningActions.Controls.Add(ActionButton("Preview &menu", "Preview menu launch", "launch.menu_plan"));
            actions.Controls.Add(planningActions, 0, 1);
            actions.SetColumnSpan(planningActions, 3);
            refusalDetail = new TextBox();
            refusalDetail.Multiline = true;
            refusalDetail.ReadOnly = true;
            refusalDetail.Dock = DockStyle.Fill;
            refusalDetail.Height = 62;
            refusalDetail.BackColor = SystemColors.Info;
            refusalDetail.ForeColor = SystemColors.InfoText;
            refusalDetail.AccessibleName = "Structured Play refusal";
            refusalDetail.AccessibleDescription = "Exact refusal code, readiness revisions, explanation, and safe action.";
            actions.Controls.Add(refusalDetail, 2, 0);
            actions.SetRowSpan(refusalDetail, 1);
            layout.Controls.Add(actions, 0, 4);
            return page;
        }

        private TabPage BuildInstallationsPage()
        {
            TabPage page = Page("Installations", "Installations page");
            TableLayoutPanel layout = PageLayout(5);
            page.Controls.Add(layout);
            layout.Controls.Add(Heading("Installations", "Inspect existing Factorio installations without repairing or updating them."), 0, 0);
            installationsSummary = BodyLabel("Installations summary");
            layout.Controls.Add(installationsSummary, 0, 1);
            installationsList = new ListView();
            installationsList.MinimumSize = new Size(0, 120);
            installationsList.Dock = DockStyle.Fill;
            installationsList.View = View.Details;
            installationsList.FullRowSelect = true;
            installationsList.AccessibleName = "Detected installations";
            installationsList.Columns.Add("Installation", 250);
            installationsList.Columns.Add("Ownership", 130);
            installationsList.Columns.Add("Layout", 170);
            installationsList.Columns.Add("Version", 110);
            installationsList.SelectedIndexChanged += delegate
            {
                if (installationsList.SelectedItems.Count == 0) return;
                installationDetail.Text = InstallationDetail(
                    installationsList.SelectedItems[0].Tag as IDictionary<string, object>);
            };
            layout.Controls.Add(installationsList, 0, 2);
            installationDetail = new TextBox();
            installationDetail.Multiline = true;
            installationDetail.ReadOnly = true;
            installationDetail.Dock = DockStyle.Fill;
            installationDetail.Height = 74;
            installationDetail.AccessibleName = "Installation identity and ownership detail";
            layout.Controls.Add(installationDetail, 0, 3);
            FlowLayoutPanel actions = ActionRow();
            actions.Controls.Add(ActionButton("&Scan for installations", "Scan for installations", "installation.scan"));
            actions.Controls.Add(ActionButton("&Register read-only", "Register a read-only installation", "installation.register_read_only"));
            layout.Controls.Add(actions, 0, 4);
            return page;
        }

        private TabPage BuildContentPage()
        {
            TabPage page = Page("Content", "Instance-local content page");
            TableLayoutPanel layout = PageLayout(4);
            page.Controls.Add(layout);
            layout.Controls.Add(Heading(
                "Content",
                "Inspect local mods and apply only reviewed instance-local modset changes."), 0, 0);
            contentSummary = BodyLabel("Local content summary");
            layout.Controls.Add(contentSummary, 0, 1);
            contentList = new ListView();
            contentList.MinimumSize = new Size(0, 120);
            contentList.Dock = DockStyle.Fill;
            contentList.View = View.Details;
            contentList.FullRowSelect = true;
            contentList.HideSelection = false;
            contentList.MultiSelect = false;
            contentList.AccessibleName = "Local mods and profiles";
            contentList.AccessibleDescription =
                "Backend-observed local content; Mod Portal and global mod folders are never accessed.";
            contentList.Columns.Add("Content", 250);
            contentList.Columns.Add("Kind", 140);
            contentList.Columns.Add("Version", 110);
            contentList.Columns.Add("Status", 170);
            contentList.Columns.Add("Identity", 300);
            layout.Controls.Add(contentList, 0, 2);
            FlowLayoutPanel actions = ActionRow();
            actions.AccessibleName = "Instance-local content actions";
            actions.Controls.Add(ScopedActionButton(
                "&Inspect mod", "Inspect local mod", "content", "mods.inspect"));
            actions.Controls.Add(ScopedActionButton(
                "&Plan modset", "Plan instance-local modset", "content", "modsets.plan"));
            actions.Controls.Add(ScopedActionButton(
                "&Apply modset", "Apply instance-local modset", "content", "modsets.apply"));
            actions.Controls.Add(ScopedActionButton(
                "&Verify modset", "Verify instance-local modset", "content", "modsets.verify"));
            actions.Controls.Add(ScopedActionButton(
                "&Roll back", "Roll back instance-local modset", "content", "modsets.rollback"));
            layout.Controls.Add(actions, 0, 3);
            return page;
        }

        private TabPage BuildSavesPage()
        {
            TabPage page = Page("Saves", "Instance-local saves page");
            TableLayoutPanel layout = PageLayout(4);
            page.Controls.Add(layout);
            layout.Controls.Add(Heading(
                "Saves",
                "Discover, inspect, associate, back up, and restore saves for the selected instance."), 0, 0);
            savesSummary = BodyLabel("Save inventory summary");
            layout.Controls.Add(savesSummary, 0, 1);
            savesList = new ListView();
            savesList.MinimumSize = new Size(0, 120);
            savesList.Dock = DockStyle.Fill;
            savesList.View = View.Details;
            savesList.FullRowSelect = true;
            savesList.HideSelection = false;
            savesList.MultiSelect = false;
            savesList.AccessibleName = "Selected instance saves";
            savesList.AccessibleDescription =
                "Structurally inspected local saves with save-byte, declared context and backup observations.";
            savesList.Columns.Add("Save", 250);
            savesList.Columns.Add("Status", 140);
            savesList.Columns.Add("Save bytes", 140);
            savesList.Columns.Add("Declared context", 330);
            savesList.Columns.Add("Backup", 120);
            savesList.Columns.Add("SHA-256", 330);
            layout.Controls.Add(savesList, 0, 2);
            FlowLayoutPanel actions = ActionRow();
            actions.AccessibleName = "Save inspection and backup actions";
            actions.Controls.Add(ScopedActionButton(
                "&Inspect", "Inspect selected local save", "saves", "saves.inspect"));
            actions.Controls.Add(ScopedActionButton(
                "&Associate", "Associate selected local save", "saves", "saves.associate"));
            actions.Controls.Add(ScopedActionButton(
                "&Back up", "Back up selected local save", "saves", "saves.backup"));
            actions.Controls.Add(ScopedActionButton(
                "&Restore", "Restore a verified owned backup to a new save", "saves", "saves.restore"));
            layout.Controls.Add(actions, 0, 3);
            return page;
        }

        private TabPage BuildActivityPage()
        {
            TabPage page = Page("Activity", "Activity page");
            TableLayoutPanel layout = PageLayout(4);
            page.Controls.Add(layout);
            layout.Controls.Add(Heading("Activity", "Observe backend-owned operations, ordinary exits, and recovery state."), 0, 0);
            activitySummary = BodyLabel("Activity summary");
            layout.Controls.Add(activitySummary, 0, 1);
            activityList = new ListView();
            activityList.MinimumSize = new Size(0, 120);
            activityList.Dock = DockStyle.Fill;
            activityList.View = View.Details;
            activityList.FullRowSelect = true;
            activityList.AccessibleName = "Operation activity";
            activityList.AccessibleDescription = "Running, exited, or interrupted backend operation records.";
            activityList.Columns.Add("Operation", 220);
            activityList.Columns.Add("Status", 120);
            activityList.Columns.Add("Progress", 120);
            activityList.Columns.Add("Summary", 430);
            layout.Controls.Add(activityList, 0, 2);
            activityActions = ActionRow();
            activityActions.AccessibleName = "Recovery actions";
            layout.Controls.Add(activityActions, 0, 3);
            return page;
        }

        private TabPage BuildSettingsPage()
        {
            TabPage page = Page("Settings / About", "Settings and About page");
            TableLayoutPanel layout = PageLayout(7);
            page.Controls.Add(layout);
            layout.Controls.Add(Heading("Settings / About", "System Native appearance and bounded C1 reference-lane information."), 0, 0);

            Label about = BodyLabel("About FacMan C1");
            about.Text =
                GeneratedProductMetadata.AboutLead + " | Windows 10/11 x64 | .NET Framework 4.8\r\n" +
                "Identity: provisional FacMan gear mark; unofficial and pending final human brand review.\r\n" +
                "Appearance: System Native. Layout: Per-Monitor V2 DPI-aware at 100%, 150%, and 200%.\r\n" +
                "Transport: bounded process RPC. Advanced commands remain a thin client of the FacMan backend.";
            layout.Controls.Add(about, 0, 1);

            workspaceSummary = BodyLabel("Workspace identity and health");
            workspaceSummary.BorderStyle = BorderStyle.FixedSingle;
            workspaceSummary.Padding = new Padding(8);
            layout.Controls.Add(workspaceSummary, 0, 2);

            settingsActions = ActionRow();
            settingsActions.AccessibleName = "Workspace and Doctor actions";
            layout.Controls.Add(settingsActions, 0, 3);

            doctorSummary = new TextBox();
            doctorSummary.Multiline = true;
            doctorSummary.ReadOnly = true;
            doctorSummary.Dock = DockStyle.Fill;
            doctorSummary.Height = 80;
            doctorSummary.AccessibleName = "Doctor diagnostic report";
            layout.Controls.Add(doctorSummary, 0, 4);

            evidenceScope = BodyLabel("Presentation authority scope");
            evidenceScope.BorderStyle = BorderStyle.FixedSingle;
            evidenceScope.Padding = new Padding(8);
            layout.Controls.Add(evidenceScope, 0, 5);

            FlowLayoutPanel chooser = ActionRow();
            Label chooserLabel = new Label();
            chooserLabel.Text = "&Deterministic evidence state:";
            chooserLabel.AutoSize = true;
            chooserLabel.Padding = new Padding(0, 8, 4, 0);
            evidenceState = new ComboBox();
            evidenceState.DropDownStyle = ComboBoxStyle.DropDownList;
            evidenceState.Width = 220;
            evidenceState.AccessibleName = "Deterministic evidence state";
            evidenceState.AccessibleDescription =
                "Selects one embedded fixture for presentation review; it is not a live product action.";
            foreach (string state in fixtureStore.States) evidenceState.Items.Add(state);
            chooserLabel.Click += delegate { evidenceState.Focus(); };
            evidenceState.SelectedIndexChanged += delegate
            {
                if (!rendering && evidenceState.SelectedItem != null)
                    SelectEvidenceState(Convert.ToString(evidenceState.SelectedItem));
            };
            chooser.Controls.Add(chooserLabel);
            chooser.Controls.Add(evidenceState);
            chooser.Visible = evidenceMode;
            layout.Controls.Add(chooser, 0, 6);

            Label boundary = BodyLabel("C1 authority boundary");
            boundary.Text = evidenceMode
                ? "Explicit evidence/development mode uses unchanged deterministic fixtures and starts no live process."
                : "Live mode derives state from bounded process RPC. It grants no route, permit, verdict, promotion, publication, daemon, direct-client, transport rewrite, or Universal Launcher ABI authority.";
            layout.Controls.Add(boundary, 0, 6);
            boundary.Visible = !evidenceMode;
            return page;
        }

        private TabPage BuildAdvancedPage()
        {
            TabPage page = Page("Advanced", "Advanced page");
            TableLayoutPanel layout = PageLayout(3);
            page.Controls.Add(layout);
            layout.Controls.Add(Heading("Advanced", "Open the generated command explorer for exhaustive backend commands and diagnostics."), 0, 0);
            Label explanation = BodyLabel("Generated command explorer boundary");
            explanation.Text =
                "The generated explorer is retained here for command/result/refusal parity. It is not the product home, " +
                "does not reinterpret backend state, and uses the existing bounded process RPC client.";
            layout.Controls.Add(explanation, 0, 1);
            FlowLayoutPanel actions = ActionRow();
            Button open = new Button();
            open.Text = "&Open command explorer";
            open.AutoSize = true;
            open.MinimumSize = new Size(190, 36);
            open.AccessibleName = "Open generated command explorer";
            open.AccessibleDescription = "Opens generated fields and backend results in an Advanced child window.";
            open.Click += delegate
            {
                if (RecordGalleryAction("advanced.open")) return;
                MainForm explorer = new MainForm();
                explorer.Text = "FacMan Advanced Command Explorer";
                explorer.Show(this);
            };
            actions.Controls.Add(open);
            layout.Controls.Add(actions, 0, 2);
            return page;
        }

        private Control BuildLaunchDeck()
        {
            GroupBox deck = new GroupBox();
            deck.Text = "Launch Deck";
            deck.Dock = DockStyle.Top;
            deck.AutoSize = true;
            deck.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            deck.Padding = new Padding(10);
            deck.AccessibleName = "Persistent Launch Deck";
            deck.AccessibleDescription = "Selected instance readiness, primary action, Last Run, refusal, and recovery truth.";

            TableLayoutPanel layout = new TableLayoutPanel();
            layout.Dock = DockStyle.Top;
            layout.AutoSize = true;
            layout.ColumnCount = 4;
            layout.RowCount = 3;
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 28F));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 28F));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 24F));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            deck.Controls.Add(layout);

            deckInstance = DeckLabel("Selected instance");
            deckStatus = DeckLabel("Launch status");
            deckReadiness = DeckLabel("Readiness status");
            deckLastRun = DeckLabel("Last Run");
            layout.Controls.Add(deckInstance, 0, 0);
            layout.Controls.Add(deckStatus, 1, 0);
            layout.Controls.Add(deckReadiness, 2, 0);
            layout.Controls.Add(deckLastRun, 3, 0);

            deckRefusal = DeckLabel("Launch Deck refusal and recovery detail");
            deckRefusal.ForeColor = SystemColors.ControlText;
            layout.SetColumnSpan(deckRefusal, 3);
            layout.Controls.Add(deckRefusal, 0, 1);

            FlowLayoutPanel actions = ActionRow();
            primaryAction = ActionButton("&Play", "Launch Deck primary action", "instance.play");
            primaryAction.Font = new Font(SystemFonts.MessageBoxFont, FontStyle.Bold);
            primaryAction.MinimumSize = new Size(150, 38);
            secondaryAction = ActionButton("&Rescan readiness", "Launch Deck secondary action", "instance.readiness.refresh");
            actions.Controls.Add(primaryAction);
            actions.Controls.Add(secondaryAction);
            layout.Controls.Add(actions, 3, 1);

            deckSourceNotice = DeckLabel("Presentation source and authority notice");
            deckSourceNotice.ForeColor = SystemColors.GrayText;
            layout.SetColumnSpan(deckSourceNotice, 4);
            layout.Controls.Add(deckSourceNotice, 0, 2);
            return deck;
        }

        private void RenderPresentation()
        {
            rendering = true;
            try
            {
                C1Presentation view = CurrentView;
                string name = view.Text("selected_instance", "name");
                string journey = view.Text("selected_instance", "journey_state");
                string readiness = view.Text("selected_instance", "readiness", "state");
                string readinessText = view.Text("selected_instance", "readiness", "summary");
                string installation = view.Text("selected_instance", "installation", "label");

                instancesSummary.Text = view.Text("pages", "instances", "summary");
                instancesList.Items.Clear();
                IList<object> instanceItems = view.Records("pages", "instances", "items");
                foreach (object value in instanceItems)
                {
                    IDictionary<string, object> item = value as IDictionary<string, object>;
                    if (item == null) continue;
                    string itemName = RecordText(item, "name");
                    string itemJourney = RecordText(item, "journey_state");
                    bool selected = String.Equals(RecordText(item, "instance_id"), view.Text("selected_instance", "instance_id"), StringComparison.Ordinal);
                    ListViewItem instance = new ListViewItem(itemName);
                    instance.Name = RecordText(item, "instance_id");
                    instance.Tag = RecordText(item, "instance_id");
                    instance.SubItems.Add(selected ? readiness : "Select to inspect");
                    instance.SubItems.Add(itemJourney);
                    instance.SubItems.Add(selected ? installation : "Backend record");
                    instance.Selected = selected;
                    instancesList.Items.Add(instance);
                }
                readinessSummary.Text = "Readiness: " + readiness + " (revision " +
                    view.Number("selected_instance", "readiness", "revision") + ")\r\n" + readinessText;

                string refusalCode = view.Text("refusal", "code");
                refusalDetail.Visible = !String.IsNullOrWhiteSpace(refusalCode);
                refusalDetail.Text = RefusalText(view);

                installationsSummary.Text = view.Text("pages", "installations", "summary");
                installationsList.Items.Clear();
                IList<object> installItems = view.Records("pages", "installations", "items");
                if (installItems.Count == 0)
                {
                    if (evidenceMode)
                    {
                        ListViewItem install = new ListViewItem(installation);
                        install.SubItems.Add(view.Text("selected_instance", "installation", "kind"));
                        install.SubItems.Add("unknown");
                        install.SubItems.Add(view.Text("selected_instance", "installation", "version"));
                        installationsList.Items.Add(install);
                    }
                    installationDetail.Text = "No registered installation identity is available.";
                }
                else
                {
                    foreach (object value in installItems)
                    {
                        IDictionary<string, object> item = value as IDictionary<string, object>;
                        if (item == null) continue;
                        string installId = FirstRecordText(item, "installation_id", "install_id", "id");
                        ListViewItem install = new ListViewItem(installId);
                        install.Tag = item;
                        install.SubItems.Add(FirstRecordText(item, "ownership", "kind"));
                        install.SubItems.Add(FirstRecordText(item, "installation_layout", "layout"));
                        install.SubItems.Add(FirstRecordText(item, "version", "observed_version"));
                        installationsList.Items.Add(install);
                    }
                    installationsList.Items[0].Selected = true;
                    installationDetail.Text = InstallationDetail(
                        installItems[0] as IDictionary<string, object>);
                }

                contentSummary.Text = view.Text("pages", "content", "summary");
                contentList.Items.Clear();
                foreach (object value in view.Records("pages", "content", "items"))
                {
                    IDictionary<string, object> item = value as IDictionary<string, object>;
                    if (item == null) continue;
                    ListViewItem content = new ListViewItem(
                        FirstRecordText(item, "name", "id"));
                    content.Tag = RecordText(item, "id");
                    content.SubItems.Add(RecordText(item, "kind"));
                    content.SubItems.Add(RecordText(item, "version"));
                    content.SubItems.Add(RecordText(item, "status"));
                    content.SubItems.Add(FirstRecordText(item, "identity", "sha256"));
                    contentList.Items.Add(content);
                }

                savesSummary.Text = view.Text("pages", "saves", "summary");
                savesList.Items.Clear();
                foreach (object value in view.Records("pages", "saves", "items"))
                {
                    IDictionary<string, object> item = value as IDictionary<string, object>;
                    if (item == null) continue;
                    ListViewItem save = new ListViewItem(
                        FirstRecordText(item, "name", "id"));
                    save.Tag = RecordText(item, "id");
                    save.SubItems.Add(RecordText(item, "status"));
                    save.SubItems.Add(RecordText(item, "association_status"));
                    save.SubItems.Add(FirstRecordText(item, "association_context_summary", "association_context_status"));
                    save.SubItems.Add(RecordText(item, "backup_status"));
                    save.SubItems.Add(RecordText(item, "sha256"));
                    savesList.Items.Add(save);
                }

                activitySummary.Text = view.Text("pages", "activity", "summary");
                RenderOperations(view);
                RenderRecoveryActions(view);
                RenderSettings(view);

                deckInstance.Text = "Instance\r\n" + name;
                deckStatus.Text = "Status\r\n" + view.Text("launch_deck", "status_text");
                deckReadiness.Text = "Readiness\r\n" + readiness + " · revision " +
                    view.Number("selected_instance", "readiness", "revision");
                deckLastRun.Text = "Last Run\r\n" + LastRunText(view);
                deckRefusal.Text = String.IsNullOrWhiteSpace(refusalCode)
                    ? RecoveryText(view) : RefusalText(view);

                IDictionary<string, object> primary = view.Record("launch_deck", "primary_action");
                ConfigureAction(primaryAction, primary, true);
                IList<object> secondaries = view.Records("launch_deck", "secondary_actions");
                ConfigureAction(secondaryAction,
                    secondaries.Count == 0 ? null : secondaries[0] as IDictionary<string, object>, false);
                AcceptButton = primaryAction;

                evidenceScope.Text = "Presentation: " + view.Contract + "\r\n" +
                    "Source mode: " + view.SourceMode + "\r\nAuthority scope: " + view.AuthorityScope;
                if (evidenceMode) evidenceState.SelectedItem = view.FixtureState;
                deckSourceNotice.Text = gallery != null
                    ? "CONTROL GALLERY — " + gallery.ScenarioId + "; actions are recorded only."
                    : evidenceMode
                    ? "EXPLICIT EVIDENCE / DEVELOPMENT MODE — unchanged deterministic fixture; no live Play authority."
                    : "LIVE BACKEND MODE — state is derived from registered bounded RPC commands; Play remains backend gated.";
                Announce(gallery != null ? "Showing " + gallery.ScenarioId + "; recording only." :
                    evidenceMode ? "Showing " + view.FixtureState + " evidence fixture." : "Showing backend-derived workspace state.");
            }
            finally
            {
                rendering = false;
            }
        }

        private void RenderOperations(C1Presentation view)
        {
            activityList.Items.Clear();
            foreach (object value in view.Records("pages", "activity", "operations"))
            {
                IDictionary<string, object> operation = value as IDictionary<string, object>;
                if (operation == null) continue;
                ListViewItem item = new ListViewItem(RecordText(operation, "operation_id"));
                item.SubItems.Add(RecordText(operation, "status"));
                IDictionary<string, object> progress = Record(operation, "progress");
                item.SubItems.Add(RecordText(progress, "completed") + "/" + RecordText(progress, "total") +
                    " " + RecordText(progress, "unit"));
                item.SubItems.Add(RecordText(operation, "summary"));
                activityList.Items.Add(item);
            }
        }

        private void RenderRecoveryActions(C1Presentation view)
        {
            activityActions.Controls.Clear();
            foreach (object value in view.Records("pages", "activity", "actions"))
            {
                IDictionary<string, object> action = value as IDictionary<string, object>;
                if (action == null) continue;
                activityActions.Controls.Add(ActionButton(
                    "&" + RecordText(action, "label"),
                    RecordText(action, "accessibility_label"),
                    RecordText(action, "action_id")));
            }
            if (activityActions.Controls.Count == 0)
            {
                Label none = BodyLabel("No recovery action required");
                none.Text = "No recovery action is required.";
                activityActions.Controls.Add(none);
            }
        }

        private void RenderSettings(C1Presentation view)
        {
            string workspaceStatus = view.Text("pages", "settings_about", "workspace", "status");
            string workspacePath = view.Text("pages", "settings_about", "workspace", "path");
            string workspaceId = view.Text("pages", "settings_about", "workspace", "workspace_id");
            workspaceSummary.Text = evidenceMode
                ? "Evidence fixtures do not inspect or initialize a live workspace."
                : "Workspace: " + EmptyText(workspacePath, "not selected") +
                    "\r\nStatus: " + EmptyText(workspaceStatus, "uninitialized") +
                    " · ID: " + EmptyText(workspaceId, "not allocated") +
                    " · layout " + view.Number(
                        "pages", "settings_about", "workspace", "layout_version");

            string doctorStatus = view.Text("pages", "settings_about", "doctor", "status");
            doctorSummary.Text = evidenceMode
                ? "Doctor is unavailable in deterministic evidence mode."
                : "Doctor: " + EmptyText(doctorStatus, "not_run") + "\r\n" +
                    view.Text("pages", "settings_about", "doctor", "summary") +
                    JoinLines("\r\nProblems: ", view.Records(
                        "pages", "settings_about", "doctor", "problems")) +
                    JoinLines("\r\nSuggested fixes: ", view.Records(
                        "pages", "settings_about", "doctor", "suggested_fixes"));

            settingsActions.Controls.Clear();
            if (evidenceMode) return;
            settingsActions.Controls.Add(ActionButton(
                "&Choose workspace", "Choose workspace to inspect", "workspace.choose"));
            foreach (object value in view.Records("pages", "settings_about", "actions"))
            {
                IDictionary<string, object> action = value as IDictionary<string, object>;
                if (action == null) continue;
                settingsActions.Controls.Add(ActionButton(
                    "&" + RecordText(action, "label"),
                    RecordText(action, "accessibility_label"),
                    RecordText(action, "action_id")));
            }
        }

        private void ConfigureAction(Button button, IDictionary<string, object> action, bool primary)
        {
            if (action == null)
            {
                button.Visible = false;
                return;
            }
            string label = RecordText(action, "label");
            string availability = RecordText(action, "availability");
            button.Visible = true;
            button.Text = "&" + label + (availability == "refused" ? " (refused)" : String.Empty);
            button.Tag = RecordText(action, "action_id");
            button.AccessibleName = RecordText(action, "accessibility_label");
            button.AccessibleDescription = primary
                ? (evidenceMode
                    ? "Launch Deck primary action in explicit deterministic evidence mode."
                    : "Launch Deck primary action. Exact backend-owned command and refusal semantics.")
                : "Launch Deck secondary action. Backend-owned semantics.";
            button.Enabled = availability == "available" || availability == "refused";
            toolTip.SetToolTip(button, RecordText(action, "command_id") + " | " + availability);
        }

        private async void InvokeAction(string actionId)
        {
            if (RecordGalleryAction(actionId)) return;
            C1Presentation view = CurrentView;
            if (!evidenceMode)
            {
                await InvokeLiveActionAsync(actionId);
                return;
            }
            if (actionId == "instance.play" && view.FixtureState == "refused")
            {
                string message = RefusalText(view);
                Announce("Play refused: stale_readiness. No process was started.");
                MessageBox.Show(this, message, "Play refused", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (actionId == "instance.create")
            {
                DialogResult answer = MessageBox.Show(this,
                    "Select the deterministic C1 Vanilla fixture instance? No live files will be changed.",
                    "Create fixture instance", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (answer != DialogResult.OK) return;
                fixtureStore.Select("positive");
            }
            else if (actionId == "activity.show_operation" || actionId == "recovery.inspect")
            {
                pages.SelectedIndex = 4;
                activityList.Focus();
                Announce("Showing the exact backend operation and recovery identity in Activity.");
                return;
            }
            else if (actionId == "recovery.apply")
            {
                DialogResult answer = MessageBox.Show(this,
                    "Recover the deterministic fixture record? Recovery does not auto-launch.",
                    "Recover operation", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                if (answer != DialogResult.OK) return;
                fixtureStore.Apply(actionId);
            }
            else
            {
                fixtureStore.Apply(actionId);
            }
            RenderPresentation();
        }

        private void SelectEvidenceState(string state)
        {
            if (!evidenceMode) return;
            fixtureStore.Select(state);
            RenderPresentation();
        }

        private C1Presentation CurrentView
        {
            get { return gallery != null ? gallery.Current : evidenceMode ? fixtureStore.Current : liveStore.Current; }
        }

        private async Task RefreshLiveAsync()
        {
            if (RecordGalleryAction("presentation.refresh")) return;
            Announce("Inspecting backend workspace...");
            UseWaitCursor = true;
            try
            {
                await liveStore.RefreshAsync(lifetime.Token);
                RenderPresentation();
            }
            finally
            {
                if (!IsDisposed && !Disposing) UseWaitCursor = false;
            }
        }

        private async Task InvokeLiveActionAsync(string actionId)
        {
            if (await InvokeDescriptorActionAsync("instances", actionId)) return;
            if (actionId == "support.export_redacted_bundle" &&
                await InvokeDescriptorActionAsync("settings_support", actionId)) return;
            if (actionId == "workspace.choose")
            {
                using (FolderBrowserDialog chooser = new FolderBrowserDialog())
                {
                    chooser.Description = "Choose a FacMan workspace to inspect. Choosing does not initialize or modify it.";
                    chooser.ShowNewFolderButton = true;
                    if (chooser.ShowDialog(this) != DialogResult.OK) return;
                    await liveStore.SelectWorkspaceAsync(
                        chooser.SelectedPath, CancellationToken.None);
                }
                if (!CanUpdateWindow) return;
                RenderPresentation();
                return;
            }
            if (actionId == "workspace.initialize")
            {
                DialogResult answer = MessageBox.Show(this,
                    "Initialize the selected FacMan workspace? This creates only FacMan workspace metadata; it does not install, repair, update, or start Factorio.",
                    "Initialize workspace", MessageBoxButtons.OKCancel,
                    MessageBoxIcon.Question);
                if (answer != DialogResult.OK) return;
                CommandResult initialized = await liveStore.InitializeWorkspaceAsync(
                    CancellationToken.None);
                if (!CanUpdateWindow) return;
                ShowResultIfRefused(initialized, "Workspace initialization refused");
                RenderPresentation();
                return;
            }
            if (actionId == "doctor.run")
            {
                CommandResult diagnosed = await liveStore.RunDoctorAsync(
                    CancellationToken.None);
                if (!CanUpdateWindow) return;
                ShowResultIfRefused(diagnosed, "Doctor refused");
                RenderPresentation();
                Announce(diagnosed.Success
                    ? "Doctor completed without changing the workspace."
                    : "Doctor could not complete.");
                return;
            }
            if (actionId == "activity.show_operation" || actionId == "recovery.inspect")
            {
                pages.SelectedIndex = 4;
                await RefreshLiveAsync();
                activityList.Focus();
                return;
            }
            if (actionId == "instance.readiness.refresh" || actionId == "readiness.refresh")
            {
                CommandResult refreshed = await liveStore.RefreshReadinessAsync(CancellationToken.None);
                if (!CanUpdateWindow) return;
                ShowResultIfRefused(refreshed, "Readiness refresh refused");
                RenderPresentation();
                return;
            }
            if (actionId == "installation.scan" || actionId == "installations.scan")
            {
                string root = Prompt("Scan installations", "Root directory to inspect:", Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles));
                if (root == null) return;
                CommandResult scanned = await liveStore.ScanInstallationsAsync(root, CancellationToken.None);
                if (!CanUpdateWindow) return;
                ShowResultIfRefused(scanned, "Installation scan refused");
                RenderPresentation();
                return;
            }
            if (actionId == "installation.register_read_only")
            {
                string path = Prompt("Register installation", "Existing installation directory:", String.Empty);
                if (path == null) return;
                string installId = Prompt("Register installation", "Portable installation ID:", "factorio-standalone");
                if (installId == null) return;
                DialogResult answer = MessageBox.Show(this,
                    "Register " + path + " as read-only installation " + installId + "? FacMan will not modify the external installation.",
                    "Register read-only installation", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (answer != DialogResult.OK) return;
                CommandResult registered = await liveStore.RegisterInstallationAsync(
                    installId, path, CancellationToken.None);
                if (!CanUpdateWindow) return;
                ShowResultIfRefused(registered, "Installation registration refused");
                RenderPresentation();
                return;
            }
            if (actionId == "instance.create" || actionId == "instance.create_isolated")
            {
                string installId = liveStore.FirstInstallId;
                if (String.IsNullOrWhiteSpace(installId))
                {
                    MessageBox.Show(this, "Scan and register a supported installation before creating an instance.", "No installation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                string instanceId = Prompt("New instance", "Portable instance ID:", "c1-vanilla");
                if (instanceId == null) return;
                string displayName = Prompt("New instance", "Display name:", "C1 Vanilla");
                if (displayName == null) return;
                DialogResult answer = MessageBox.Show(this,
                    "Create " + displayName + " from backend installation " + installId + "?",
                    "Create instance", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (answer != DialogResult.OK) return;
                CommandResult created = await liveStore.CreateInstanceAsync(
                    instanceId, displayName, installId, CancellationToken.None);
                if (!CanUpdateWindow) return;
                ShowResultIfRefused(created, "Instance creation refused");
                RenderPresentation();
                return;
            }
            if (actionId == "recovery.apply" || actionId == "recovery.apply_supported")
            {
                string transactionId = liveStore.RecoveryTransactionId;
                if (String.IsNullOrWhiteSpace(transactionId)) return;
                DialogResult answer = MessageBox.Show(this,
                    "Apply the backend recovery plan for " + transactionId + "? Recovery will not auto-launch Factorio.",
                    "Recover operation", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                if (answer != DialogResult.OK) return;
                CommandResult recovered = await liveStore.ApplyRecoveryAsync(
                    transactionId, CancellationToken.None);
                if (!CanUpdateWindow) return;
                ShowResultIfRefused(recovered, "Recovery refused");
                RenderPresentation();
                return;
            }
            if (actionId == "sessions.stop")
            {
                DialogResult answer = MessageBox.Show(this,
                    "Request a bounded stop for the active fixture session? The backend and ULK Last Run remain authoritative for the terminal outcome.",
                    "Stop fixture session", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                if (answer != DialogResult.OK) return;
                CommandResult stopped = await liveStore.StopSessionAsync(
                    CancellationToken.None);
                if (!CanUpdateWindow) return;
                ShowResultIfRefused(stopped, "Session stop refused");
                await RefreshLiveAsync();
                return;
            }
            if (actionId == "instance.play" || actionId == "launch.play")
            {
                Announce("Revalidating backend readiness before Play...");
                CommandResult result;
                if (liveStore.HasUncertainAction)
                {
                    DialogResult inspect = MessageBox.Show(this,
                        "The prior " + liveStore.UncertainActionId + " request may have reached the backend. Inspect and explicitly replay operation " +
                        liveStore.UncertainOperationId + " using its original identity? No new Play identity will be created.",
                        "Inspect uncertain operation", MessageBoxButtons.OKCancel,
                        MessageBoxIcon.Warning);
                    if (inspect != DialogResult.OK) return;
                    result = await liveStore.InspectUncertainActionAsync(
                        CancellationToken.None);
                }
                else
                {
                    result = await liveStore.PlayAsync(CancellationToken.None);
                }
                if (!CanUpdateWindow) return;
                if (result.Refused)
                    MessageBox.Show(this, result.RefusalCode + "\r\n" + result.RefusalReason, "Play refused", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                RenderPresentation();
            }
        }

        private async Task<bool> InvokeDescriptorActionAsync(
            string scope, string actionId)
        {
            PresentationActionDescriptor descriptor =
                liveStore.ActionDescriptor(scope, actionId);
            if (descriptor == null ||
                descriptor.InputContract != "facman.semantic_action_input.v1" ||
                descriptor.InputFields.Count == 0)
                return false;
            IDictionary<string, object> input = PromptActionInputs(descriptor);
            if (input == null) return true;
            if (descriptor.Effectful)
            {
                DialogResult answer = MessageBox.Show(this,
                    "Apply " + descriptor.Label + " using the reviewed values?",
                    descriptor.Label, MessageBoxButtons.OKCancel,
                    MessageBoxIcon.Question);
                if (answer != DialogResult.OK) return true;
            }
            CommandResult result = await liveStore.ExecuteDescriptorActionAsync(
                scope, actionId, input, CancellationToken.None);
            if (!CanUpdateWindow) return true;
            ShowResultIfRefused(result, descriptor.Label + " refused");
            if (result.Success &&
                !String.IsNullOrWhiteSpace(liveStore.LastActionPayload))
            {
                string detail = liveStore.LastActionPayload;
                if (detail.Length > 6000) detail = detail.Substring(0, 6000) + "...";
                MessageBox.Show(this, detail, descriptor.Label,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            RenderPresentation();
            return true;
        }

        private bool CanUpdateWindow
        {
            get { return !IsDisposed && !Disposing; }
        }

        private void ShowResultIfRefused(CommandResult result, string title)
        {
            if (result != null && result.Refused)
                MessageBox.Show(this, result.RefusalCode + "\r\n" + result.RefusalReason, title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private string Prompt(string title, string label, string initialValue)
        {
            using (Form prompt = new Form())
            {
                prompt.Text = title;
                prompt.ClientSize = new Size(430, 118);
                prompt.StartPosition = FormStartPosition.CenterParent;
                prompt.FormBorderStyle = FormBorderStyle.FixedDialog;
                prompt.MaximizeBox = false;
                prompt.MinimizeBox = false;
                Label caption = new Label { Text = label, Left = 12, Top = 14, Width = 400 };
                TextBox value = new TextBox { Text = initialValue, Left = 12, Top = 40, Width = 400 };
                Button ok = new Button { Text = "OK", DialogResult = DialogResult.OK, Left = 250, Top = 76, Width = 75 };
                Button cancel = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel, Left = 337, Top = 76, Width = 75 };
                prompt.Controls.Add(caption); prompt.Controls.Add(value); prompt.Controls.Add(ok); prompt.Controls.Add(cancel);
                prompt.AcceptButton = ok; prompt.CancelButton = cancel;
                return prompt.ShowDialog(this) == DialogResult.OK && !String.IsNullOrWhiteSpace(value.Text) ? value.Text.Trim() : null;
            }
        }

        private IDictionary<string, object> PromptActionInputs(
            PresentationActionDescriptor action)
        {
            using (Form prompt = new Form())
            {
                prompt.Text = action.Label;
                prompt.ClientSize = new Size(500, 90 + action.InputFields.Count * 54);
                prompt.StartPosition = FormStartPosition.CenterParent;
                prompt.FormBorderStyle = FormBorderStyle.FixedDialog;
                prompt.MaximizeBox = false;
                prompt.MinimizeBox = false;
                TableLayoutPanel layout = new TableLayoutPanel();
                layout.Dock = DockStyle.Fill;
                layout.Padding = new Padding(12);
                layout.ColumnCount = 2;
                layout.RowCount = action.InputFields.Count + 1;
                layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 170F));
                layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
                Dictionary<PresentationActionInputField, Control> controls =
                    new Dictionary<PresentationActionInputField, Control>();
                int row = 0;
                foreach (PresentationActionInputField field in action.InputFields)
                {
                    Label label = new Label();
                    label.Text = field.Label + (field.Required ? " *" : String.Empty);
                    label.AutoSize = true;
                    label.Anchor = AnchorStyles.Left;
                    Control editor;
                    if (field.Choices.Count != 0)
                    {
                        ComboBox choices = new ComboBox();
                        choices.DropDownStyle = ComboBoxStyle.DropDownList;
                        foreach (string choice in field.Choices) choices.Items.Add(choice);
                        if (!String.IsNullOrWhiteSpace(field.DefaultValue))
                            choices.SelectedItem = field.DefaultValue;
                        if (choices.SelectedIndex < 0 && choices.Items.Count != 0)
                            choices.SelectedIndex = 0;
                        editor = choices;
                    }
                    else
                    {
                        editor = new TextBox { Text = field.DefaultValue };
                    }
                    editor.Dock = DockStyle.Fill;
                    editor.AccessibleName = field.Label;
                    layout.Controls.Add(label, 0, row);
                    layout.Controls.Add(editor, 1, row);
                    controls[field] = editor;
                    ++row;
                }
                FlowLayoutPanel buttons = new FlowLayoutPanel();
                buttons.FlowDirection = FlowDirection.RightToLeft;
                buttons.Dock = DockStyle.Fill;
                Button ok = new Button { Text = "Continue", DialogResult = DialogResult.OK };
                Button cancel = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel };
                buttons.Controls.Add(ok);
                buttons.Controls.Add(cancel);
                layout.Controls.Add(buttons, 0, row);
                layout.SetColumnSpan(buttons, 2);
                prompt.Controls.Add(layout);
                prompt.AcceptButton = ok;
                prompt.CancelButton = cancel;
                if (prompt.ShowDialog(this) != DialogResult.OK) return null;
                Dictionary<string, object> values = new Dictionary<string, object>();
                foreach (KeyValuePair<PresentationActionInputField, Control> pair in controls)
                {
                    string value = pair.Value is ComboBox
                        ? Convert.ToString(((ComboBox)pair.Value).SelectedItem)
                        : pair.Value.Text;
                    value = value == null ? String.Empty : value.Trim();
                    if (pair.Key.Required && String.IsNullOrWhiteSpace(value))
                    {
                        MessageBox.Show(this, pair.Key.Label + " is required.",
                            action.Label, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return null;
                    }
                    if (!String.IsNullOrWhiteSpace(value)) values[pair.Key.FieldId] = value;
                }
                return values;
            }
        }

        private bool RecordGalleryAction(string actionId)
        {
            if (gallery == null) return false;
            gallery.RecordAction(actionId);
            Announce("Gallery recorded " + actionId + "; no backend action was dispatched.");
            return true;
        }

        private void Announce(string message)
        {
            statusLabel.Text = message;
            statusLabel.AccessibleName = "FacMan status: " + message;
            AccessibilityNotifyClients(AccessibleEvents.NameChange, -1);
        }

        private Button ActionButton(string text, string accessibleName, string actionId)
        {
            Button button = new Button();
            button.Text = text;
            button.AutoSize = true;
            button.MinimumSize = new Size(140, 36);
            button.Margin = new Padding(0, 0, 8, 0);
            button.Tag = actionId;
            button.AccessibleName = accessibleName;
            button.AccessibleDescription = "FacMan presentation action " + actionId + ".";
            button.Click += delegate { InvokeAction(Convert.ToString(button.Tag)); };
            return button;
        }

        private Button ScopedActionButton(
            string text, string accessibleName, string scope, string actionId)
        {
            Button button = new Button();
            button.Text = text;
            button.AutoSize = true;
            button.MinimumSize = new Size(140, 36);
            button.Margin = new Padding(0, 0, 8, 0);
            button.AccessibleName = accessibleName;
            button.AccessibleDescription =
                "Backend-owned " + scope + " semantic action " + actionId + ".";
            button.Enabled = !evidenceMode;
            button.Click += async delegate
            {
                if (RecordGalleryAction(actionId)) return;
                if (!evidenceMode)
                    await InvokeDescriptorActionAsync(scope, actionId);
            };
            return button;
        }

        private static TabPage Page(string title, string accessibleName)
        {
            TabPage page = new TabPage(title);
            page.Padding = new Padding(12);
            page.AutoScroll = true;
            page.AccessibleName = accessibleName;
            return page;
        }

        private static TableLayoutPanel PageLayout(int rows)
        {
            TableLayoutPanel layout = new TableLayoutPanel();
            layout.Dock = DockStyle.Top;
            layout.AutoSize = true;
            layout.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            layout.ColumnCount = 1;
            layout.RowCount = rows;
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            for (int i = 0; i < rows; ++i)
                layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            return layout;
        }

        private static Control Heading(string title, string explanation)
        {
            TableLayoutPanel heading = new TableLayoutPanel();
            heading.Dock = DockStyle.Top;
            heading.AutoSize = true;
            heading.RowCount = 2;
            Label titleLabel = new Label();
            titleLabel.Text = title;
            titleLabel.Font = new Font(SystemFonts.MessageBoxFont.FontFamily, 15F, FontStyle.Bold);
            titleLabel.AutoSize = true;
            titleLabel.AccessibleName = title + " heading";
            Label explanationLabel = new Label();
            explanationLabel.Text = explanation;
            explanationLabel.AutoSize = true;
            explanationLabel.ForeColor = SystemColors.GrayText;
            explanationLabel.AccessibleName = title + " explanation";
            heading.Controls.Add(titleLabel, 0, 0);
            heading.Controls.Add(explanationLabel, 0, 1);
            return heading;
        }

        private static Label BodyLabel(string accessibleName)
        {
            Label label = new Label();
            label.AutoSize = true;
            label.MaximumSize = new Size(900, 0);
            label.Margin = new Padding(0, 8, 0, 8);
            label.AccessibleName = accessibleName;
            return label;
        }

        private static Label DeckLabel(string accessibleName)
        {
            Label label = BodyLabel(accessibleName);
            label.Dock = DockStyle.Fill;
            label.AutoSize = false;
            label.AutoEllipsis = true;
            label.MinimumSize = new Size(0, 54);
            label.Margin = new Padding(6);
            label.TextChanged += delegate { label.AccessibleDescription = label.Text; };
            return label;
        }

        private static FlowLayoutPanel ActionRow()
        {
            FlowLayoutPanel row = new FlowLayoutPanel();
            row.Dock = DockStyle.Fill;
            row.AutoSize = true;
            row.WrapContents = true;
            row.FlowDirection = FlowDirection.LeftToRight;
            row.Padding = new Padding(0, 8, 0, 4);
            return row;
        }

    }
}
