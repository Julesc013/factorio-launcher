"""Demonstrate the actual owner-to-WinForms projection gap once."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
P = 'make-ready-save-view-baseline-01'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f: f.write(json.dumps(value, indent=2)+'\n')
assert __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == 'be3f5f47cb555661cd15ed2c96c475fd412c578d'
marker = json.loads((E.parent/'.facman-development-root.v1.json').read_text(encoding='utf-8'))
assert marker['task_id'] == 'task/facman-world-restore-retention-01' and Path(marker['source_root']).samefile(R)
doctor = subprocess.run([sys.executable, '-B', 'tools/workspace_hygiene.py', 'doctor', '--measure'], cwd=R, capture_output=True, text=True, encoding='utf-8', timeout=120)
resource = json.loads(doctor.stdout)
assert doctor.returncode in {0, 1} and set(resource['violations']) <= {'unmanaged_secondary_worktrees_present', 'merged_local_task_branches_present'}
assert len(resource['task_roots']) <= 8 and resource['task_root_bytes'] <= 20*1024**3
write(E/(P+'-doctor.json'), resource)
jobs = subprocess.check_output(['powershell', '-NoProfile', '-Command', "Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(MSBuild|cmake|ninja|cl|link)\\.exe$' } | Select-Object Name,ProcessId | ConvertTo-Json -Compress"], text=True).strip()
assert not jobs, jobs
temporary, evidence = E/(P+'-temp'), E/(P+'-fixture')
temporary.mkdir(); evidence.mkdir()
tempfile.tempdir = str(temporary)
os.environ['FACMAN_CLI_EXE'] = str(E.parent/'native-developer/Debug/facman.exe')
assert sha(Path(os.environ['FACMAN_CLI_EXE'])) == '20dfe23fcbba828b5be23205fce74f59c458c9c94339f3c725515db4e2af2f42'
os.environ['FACMAN_WINFORMS_SAVE_CONTEXT_EVIDENCE_DIR'] = str(evidence)
sys.path[:0] = [str(R/'tests'), str(R)]
import native_cli
invoke = native_cli.invoke_machine
commands = E/(P+'-commands.jsonl')
observations = []
def capture(args, env=None):
    result = invoke(args, env)
    entry = dict(argv=args, exit_code=result[0], stdout=result[1], stderr=result[2])
    observations.append(entry)
    with commands.open('a', encoding='utf-8', newline='\n') as f: f.write(json.dumps(entry)+'\n')
    return result
assert not commands.exists()
native_cli.invoke_machine = capture
suite = unittest.defaultTestLoader.loadTestsFromName('test_winforms_save_association_context')
log = E/(P+'.log')
with log.open('x', encoding='utf-8') as f:
    result = unittest.TextTestRunner(stream=f, verbosity=2).run(suite)
assert result.testsRun == 1 and len(result.failures) == 1 and not result.errors and not result.skipped
assert 'owner observation lost: association_context_status' in result.failures[0][1]
assert (evidence/'FacMan.exe').is_file() and (evidence/'FacMan.SaveContext.Harness.exe').is_file()
assert len(observations) == 16 and all(x['exit_code'] == 0 for x in observations)
write(E/(P+'.json'), dict(status='DEMONSTRATED_OWNER_CONTEXT_DROPPED_BY_WINFORMS', base='be3f5f47cb555661cd15ed2c96c475fd412c578d',
    tests=1, expected_assertion_failures=1, unexpected_errors=0, skips=0, native_public_commands=len(observations),
    commands_sha256=sha(commands), log_sha256=sha(log), cases_sha256=sha(evidence/'cases.json'),
    runtime_failure_sha256=sha(evidence/'run.log'), binary_identities=json.loads((evidence/'binary-identities.json').read_text(encoding='utf-8')),
    GUI_builds=1, native_builds=0, new_task_roots=0, new_worktrees=0, candidate_dispatches=0, whole_workunit_closed=False))
print(json.dumps(dict(status='DEMONSTRATED_OWNER_CONTEXT_DROPPED_BY_WINFORMS', native_public_commands=len(observations), GUI_builds=1, native_builds=0)))
