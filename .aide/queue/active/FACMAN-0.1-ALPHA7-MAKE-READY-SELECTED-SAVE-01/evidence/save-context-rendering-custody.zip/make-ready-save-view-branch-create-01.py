"""Reuse the retired owned branch at the newly qualified dev for Saves rendering."""
import ast
from pathlib import Path

E = Path(__file__).resolve().parent
text = (E/'make-ready-save-context-branch-01.py').read_text(encoding='utf-8')
text = text.replace('make-ready-save-context', 'make-ready-save-view')
text = text.replace('9339459e669f37ad1a5cc09394e3a05eef9350d0', 'be3f5f47cb555661cd15ed2c96c475fd412c578d')
text = text.replace('make-ready-presentation-integration-02.json', 'make-ready-save-context-integration-01.json')
text = text.replace('1b55202124ca8213936f4eb90cae67b108aac65cd28c4d7036eb9deaa8467f3c', 'c44b05c7737b4afe33c134c4074fd9defeba7d63426db285f98f39022d2ba460')
text = text.replace('make-ready-save-view-decision-01.json', 'make-ready-save-context-final-commit.review.json')
text = text.replace('907e728fee9125559570f30ab26ca4db3ec725b2ea890133bf3714487c502a7a', '6ebd8de6085714eb1043c337698bee4a7d3c759ac8371a17b00f6ef99126f142')
text = text.replace('decision_review_sha256=sha(review)', 'qualified_owner_contract_review_sha256=sha(review)')
ast.parse(text)
with (E/'make-ready-save-view-branch-01.py').open('x', encoding='utf-8', newline='\n') as f:
    f.write(text)
print('Created next exact-base branch helper; not executed')
