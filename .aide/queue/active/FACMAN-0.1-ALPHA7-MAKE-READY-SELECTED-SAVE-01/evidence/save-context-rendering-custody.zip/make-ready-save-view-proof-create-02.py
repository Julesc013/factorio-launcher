"""Preserve the preclaim guard failure and verify exact checkout EOL round trips."""
import hashlib
import json
from pathlib import Path

E = Path(__file__).resolve().parent
prior = E/'make-ready-save-view-source-proof-01.py'
failure = E/'make-ready-save-view-source-proof-01-preclaim-failure.json'
with failure.open('x', encoding='utf-8', newline='\n') as f:
    f.write(json.dumps(dict(status='STOPPED_PRECLAIM_RAW_SHA_GUARD', source_script_sha256=hashlib.sha256(prior.read_bytes()).hexdigest(),
        mismatch='apps/gui/windows/winforms/GeneratedCommandCatalog.cs', reason='Normal Git checkout restored CRLF in generated catalog/version header; exact filtered Git objects and LF bytes require verification',
        GUI_builds=0, native_builds=0, public_query_replay=0, claim_created=False), indent=2)+'\n')
text = prior.read_text(encoding='utf-8').replace("P = 'make-ready-save-view-source-proof-01'", "P = 'make-ready-save-view-source-proof-02'")
text = text.replace('import unittest\n', 'import unittest\n')
needle = "for name, digest in owner['source_hashes'].items():\n    if name != 'docs/product/save_intelligence.md': assert sha(R/name) == digest, name"
assert text.count(needle) == 1
text = text.replace(needle, """import zipfile
owner_archive = R/'.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01/evidence/save-association-context-custody.zip'
assert sha(owner_archive) == '2d48076cc22ed20c9f0210f4d1822210f96608f781fbf57e7a0979d0e9f5b011'
owner_bindings = []
with zipfile.ZipFile(owner_archive) as z:
    for name, digest in owner['source_hashes'].items():
        if name == 'docs/product/save_intelligence.md': continue
        original, current = z.read('source/'+name), (R/name).read_bytes()
        assert hashlib.sha256(original).hexdigest() == digest
        assert current.replace(b'\\r\\n', b'\\n') == original.replace(b'\\r\\n', b'\\n'), name
        original_oid = out('git', 'rev-parse', '4b32a15a59777911fe3911c55b5bc1f2be4c7ec5:'+name)
        assert out('git', 'hash-object', '--path', name, name) == original_oid
        owner_bindings.append(dict(path=name, raw_equal=current == original, git_blob_oid=original_oid,
            canonical_LF_sha256=hashlib.sha256(current.replace(b'\\r\\n', b'\\n')).hexdigest()))""")
needle = "retained_owner_native_public_commands=16,"
assert text.count(needle) == 1
text = text.replace(needle, "retained_owner_native_public_commands=16, owner_source_EOL_bindings=owner_bindings, prior_preclaim_failure_sha256=sha(E/'make-ready-save-view-source-proof-01-preclaim-failure.json'),")
with (E/'make-ready-save-view-source-proof-02.py').open('x', encoding='utf-8', newline='\n') as f:
    f.write(text)
print('Created guarded source proof02; no builds or queries replayed')
