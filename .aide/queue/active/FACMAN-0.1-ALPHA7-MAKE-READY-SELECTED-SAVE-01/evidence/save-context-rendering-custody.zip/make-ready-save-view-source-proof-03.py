"""Qualify the corrected GUI against retained real owner snapshots, without query replay."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
P = 'make-ready-save-view-source-proof-03'
BASE = 'be3f5f47cb555661cd15ed2c96c475fd412c578d'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f: f.write(json.dumps(value, indent=2)+'\n')
def out(*args): return subprocess.check_output(args, cwd=R, text=True, encoding='utf-8').strip()
def check(name, args, timeout=900):
    log = E/(P+'-'+name+'.log')
    with log.open('x', encoding='utf-8') as f:
        result = subprocess.run(args, cwd=R, stdout=f, stderr=subprocess.STDOUT, timeout=timeout)
    entry = dict(check=name, argv=args, exit_code=result.returncode, log=str(log), sha256=sha(log))
    record['checks'].append(entry)
    assert result.returncode == 0, entry
    return log
assert __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0'
assert out('git', 'rev-parse', 'HEAD') == BASE and out('git', 'branch', '--show-current') == 'task/facman-world-restore-retention-01'
assert not out('git', 'diff', '--cached', '--name-only')
marker_path = E.parent/'.facman-development-root.v1.json'
marker = json.loads(marker_path.read_text(encoding='utf-8'))
assert marker['task_id'] == 'task/facman-world-restore-retention-01' and Path(marker['source_root']).samefile(R)
prior = E/'make-ready-save-context-integration-01.json'
assert sha(prior) == 'c44b05c7737b4afe33c134c4074fd9defeba7d63426db285f98f39022d2ba460'
terminal = json.loads(prior.read_text(encoding='utf-8'))
assert terminal['status'] == 'integration_and_automatic_merge_CI_pass' and terminal['merge_CI_pass'] and terminal['merge'] == BASE
consumed = json.loads((E/'make-ready-save-context-integration-launch-01.json').read_text(encoding='utf-8'))
assert consumed['status'] == 'observer_terminal_consumed' and consumed['observer_receipt_sha256'] == sha(prior)
baseline_path = E/'make-ready-save-view-baseline-01.json'
baseline = json.loads(baseline_path.read_text(encoding='utf-8'))
assert baseline['status'] == 'DEMONSTRATED_OWNER_CONTEXT_DROPPED_BY_WINFORMS' and baseline['native_public_commands'] == 16
fixture = E/'make-ready-save-view-baseline-01-fixture/cases.json'
assert sha(fixture) == baseline['cases_sha256']
assert sha(E/'make-ready-save-view-baseline-01-commands.jsonl') == baseline['commands_sha256']
paths = set(out('git', 'diff', '--name-only').splitlines()) | set(out('git', 'ls-files', '--others', '--exclude-standard').splitlines())
allowed = {'apps/gui/windows/winforms/C1ShellForm.cs', 'apps/gui/windows/winforms/C1SnapshotProjection.cs',
    'apps/gui/windows/winforms/PresentationModels.cs', 'docs/product/save_intelligence.md',
    'tests/test_winforms_save_association_context.py', 'tests/winforms_control_gallery/FacMan.SaveContext.Harness.csproj',
    'tests/winforms_control_gallery/SaveContextHarness.cs'}
assert paths == allowed, sorted(paths)
hashes = {name: sha(R/name) for name in sorted(paths)}
owner = json.loads((E/'make-ready-save-context-source-proof-02.json').read_text(encoding='utf-8'))
import zipfile
owner_archive = R/'.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01/evidence/save-association-context-custody.zip'
assert sha(owner_archive) == '2d48076cc22ed20c9f0210f4d1822210f96608f781fbf57e7a0979d0e9f5b011'
owner_bindings = []
with zipfile.ZipFile(owner_archive) as z:
    for name, digest in owner['source_hashes'].items():
        if name == 'docs/product/save_intelligence.md': continue
        original, current = z.read('source/'+name), (R/name).read_bytes()
        assert hashlib.sha256(original).hexdigest() == digest
        assert current.replace(b'\r\n', b'\n') == original.replace(b'\r\n', b'\n'), name
        original_oid = out('git', 'rev-parse', '4b32a15a59777911fe3911c55b5bc1f2be4c7ec5:'+name)
        assert out('git', 'hash-object', '--path', name, name) == original_oid
        owner_bindings.append(dict(path=name, raw_equal=current == original, git_blob_oid=original_oid,
            canonical_LF_sha256=hashlib.sha256(current.replace(b'\r\n', b'\n')).hexdigest()))
assert sha(E.parent/'native-developer/Debug/facman.exe') == owner['CLI_sha256']
doctor = subprocess.run([sys.executable, '-B', 'tools/workspace_hygiene.py', 'doctor', '--measure'], cwd=R, capture_output=True, text=True, encoding='utf-8', timeout=120)
resource = json.loads(doctor.stdout)
assert doctor.returncode in {0, 1} and set(resource['violations']) <= {'unmanaged_secondary_worktrees_present', 'merged_local_task_branches_present'}
assert len(resource['task_roots']) <= 8 and resource['task_root_bytes'] <= 20*1024**3
write(E/(P+'-doctor.json'), resource)
jobs = subprocess.check_output(['powershell', '-NoProfile', '-Command', "Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(MSBuild|cmake|ninja|cl|link)\\.exe$' } | Select-Object Name,ProcessId | ConvertTo-Json -Compress"], text=True).strip()
assert not jobs, jobs
record = dict(status='running_source_QA', base=BASE, source_hashes=hashes, checks=[], baseline_sha256=sha(baseline_path),
    reused_owner_cases_sha256=sha(fixture), reused_owner_CLI_sha256=owner['CLI_sha256'], retained_owner_native_public_commands=16, owner_source_EOL_bindings=owner_bindings, prior_preclaim_failure_sha256=sha(E/'make-ready-save-view-source-proof-01-preclaim-failure.json'),
    new_native_public_commands=0, GUI_builds=0, native_builds=0, new_task_roots=0, new_worktrees=0,
    candidate_dispatches=0, CI_reruns=0, model_wait_calls=0, whole_workunit_closed=False, prior_strict_failure_sha256=sha(E/'make-ready-save-view-source-proof-02.json'), language_policy_unchanged=True)
write(E/(P+'.claim.json'), dict(PID=os.getpid(), no_automatic_replay=True, source_hashes=hashes))
try:
    for name, args in [('format', ['tools/source_format_check.py']), ('metadata', ['-m', 'tools.codegen.generate_metadata', '--check']),
        ('compiler', ['-m', 'tools.codegen.generate_contracts', '--check']), ('gui-contract', ['tools/facman_winforms_c1_check.py']),
        ('contracts', ['tools/command_contract_check.py']), ('strict', ['tools/strict_check.py']), ('portable', ['.aide/scripts/aide_lite.py', 'test'])]:
        check(name, [sys.executable, '-B', *args])
    sys.path.insert(0, str(R))
    from tools.winforms_build import msbuild_executable
    product = E.parent/'winforms-save-view'
    output, intermediate = product/'bin', product/'obj'
    assert not product.exists(), 'Preserve prior output; no blind overwrite'
    product.mkdir(); output.mkdir(); intermediate.mkdir()
    record['GUI_builds'] = 1
    check('build', [msbuild_executable(), str(R/'tests/winforms_control_gallery/FacMan.SaveContext.Harness.csproj'),
        '/m:2', '/nr:false', '/p:Configuration=Debug', '/p:Platform=x64', f'/p:OutputPath={output}{os.sep}',
        f'/p:IntermediateOutputPath={intermediate}{os.sep}', f'/p:BaseIntermediateOutputPath={intermediate}{os.sep}'], 180)
    log = check('render', [str(output/'FacMan.SaveContext.Harness.exe'), str(fixture)], 60)
    assert log.read_text(encoding='utf-8').count('PASS ') == 7
    assert sha(fixture) == baseline['cases_sha256']
    assert {name: sha(R/name) for name in hashes} == hashes
    record.update(status='PASS_SCOPED_WINDOWS_OWNER_CONTEXT_RENDERING', runtime_cases=7, actual_backend_cases=6,
        optional_context_absent_compatibility_cases=1, runtime_skips=0, native_build_replay=False, owner_query_replay=False,
        binary_identities={name: sha(output/name) for name in ['FacMan.exe', 'FacMan.SaveContext.Harness.exe']},
        actual_Factorio=False, produced_package=False, human_experience=False, backend_windows_link_host_block_preserved=True,
        finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
except BaseException as error:
    record.update(status='stopped_for_actionable_failure', error=repr(error), finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    write(E/(P+'.json'), record)
    raise
write(E/(P+'.json'), record)
print(json.dumps(dict(status=record['status'], runtime_cases=7, GUI_builds=1, native_builds=0, owner_query_replay=False, sha256=sha(E/(P+'.json')))))
