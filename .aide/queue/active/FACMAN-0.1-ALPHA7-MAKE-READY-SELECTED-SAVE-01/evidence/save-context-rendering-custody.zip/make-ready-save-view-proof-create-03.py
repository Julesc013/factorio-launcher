"""Keep strict failure; put the renderer harness in the existing admitted C# test root."""
import ast
import hashlib
import json
from pathlib import Path

E = Path(__file__).resolve().parent
prior_path = E/'make-ready-save-view-source-proof-02.json'
prior = json.loads(prior_path.read_text(encoding='utf-8'))
assert prior['status'] == 'stopped_for_actionable_failure' and prior['GUI_builds'] == 0
assert prior['checks'][-1]['check'] == 'strict' and prior['checks'][-1]['exit_code'] == 1
text = (E/'make-ready-save-view-source-proof-02.py').read_text(encoding='utf-8')
text = text.replace("P = 'make-ready-save-view-source-proof-02'", "P = 'make-ready-save-view-source-proof-03'")
text = text.replace('tests/winforms_save_context_harness/', 'tests/winforms_control_gallery/')
needle = "candidate_dispatches=0, CI_reruns=0, model_wait_calls=0, whole_workunit_closed=False)"
assert text.count(needle) == 1
text = text.replace(needle, "candidate_dispatches=0, CI_reruns=0, model_wait_calls=0, whole_workunit_closed=False, prior_strict_failure_sha256=sha(E/'make-ready-save-view-source-proof-02.json'), language_policy_unchanged=True)")
ast.parse(text)
with (E/'make-ready-save-view-source-proof-03.py').open('x', encoding='utf-8', newline='\n') as f:
    f.write(text)
print(json.dumps(dict(status='CREATED_AFTER_GENUINE_STRICT_FAILURE', prior_receipt_sha256=hashlib.sha256(prior_path.read_bytes()).hexdigest(), GUI_builds_replayed=0, native_builds_replayed=0, policies_changed=0)))
