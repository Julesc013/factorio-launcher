"""Compile the proposed maintained regression against exact privately qualified product bytes."""
from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time
R=Path(r'D:\Projects\Factorio\factorio-launcher'); E=Path(__file__).resolve().parent; W=E.parent; B=W/'native-developer'
D=E/'retained-extraction-maintained-smoke-02'; OUT=E/'retained-extraction-maintained-smoke-02.json'
P=E/'retained-extraction-relative-proposal-02'; T=E/'retained-extraction-relative-proposal-05'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).rstrip('\r\n')
env=dict(os.environ,FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='0')
assert __debug__ and not OUT.exists() and not D.exists()
assert W.resolve().is_relative_to(Path(r'D:\Projects\Factorio').resolve())
marker=json.loads((W/'.facman-development-root.v1.json').read_text())
assert marker['kind']=='task-root' and Path(marker['canonical_path']).resolve()==W.resolve()
assert Path(marker['source_root']).resolve()==R.resolve()
publication=json.loads((E/'existing-configuration-py311-published.json').read_text())
assert not git('status','--porcelain')
assert git('rev-parse','HEAD^{tree}')==git('rev-parse',publication['source']+'^{tree}')

q=json.loads((E/'existing-configuration-py311-qualification-01.json').read_text())
assert q['status']=='PASS', 'Do not overlap the owned native-consumer test campaign'
proposal=json.loads((E/'retained-extraction-relative-proposal-05.json').read_text())
prior=json.loads((E/'retained-extraction-corrected-private-proof-04.json').read_text())
assert prior['status']=='PASS_PRIVATE_CORRECTED_HANDLE_EXTRACTION'
assert json.loads((E/'retained-extraction-corrected-private-acceptance-review-01.json').read_text())['verdict']=='PASS'
before=git('status','--porcelain'); source_head=git('rev-parse','HEAD')
for relative,binding in proposal['source_paths'].items():
    assert sha(R/relative)==binding['original_sha256']
    target=(T if relative.startswith('tests/') else P)/Path(relative).name
    assert sha(target)==binding['proposed_sha256']
libs=[Path(p) for p in prior['input_libraries_sha256']]
assert {str(p):sha(p) for p in libs}==prior['input_libraries_sha256']
D.mkdir(); temporary=D/'temporary';temporary.mkdir()
record=dict(status='STARTED',source_head=source_head,source_status_before=before,
    proposal_sha256=sha(E/'retained-extraction-relative-proposal-05.json'),
    prior_private_proof_sha256=sha(E/'retained-extraction-corrected-private-proof-04.json'),
    input_libraries_sha256={str(p):sha(p) for p in libs},source_paths=proposal['source_paths'],
    new_task_roots=0,new_clones=0,new_worktrees=0,new_candidates=0,product_source_mutated=False,
    public_workflow_qualified=False,process_loss_qualified=False,full_F09_qualified=False,POSIX_qualified=False,commands=[])
def save():
    pending=OUT.with_suffix('.pending.json');pending.write_text(json.dumps(record,indent=2)+'\n');os.replace(pending,OUT)
def run(name,args,timeout,child_env=None,accepted=(0,)):
    log=D/(name+'.log')
    with log.open('xb') as stream:
        child=subprocess.Popen(args,cwd=D,env=child_env or env,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        record.update(active_pid=child.pid,active_command=name);save()
        try:child.wait(timeout=timeout)
        except BaseException:
            if child.poll() is None:child.kill()
            child.wait(timeout=10);record['status']='STOP_REQUIRES_EXACT_DESCENDANT_CENSUS';save();raise
    record['commands'].append(dict(name=name,args=args,exit_code=child.returncode,log=str(log),log_sha256=sha(log)));save()
    assert child.returncode in accepted,(name,child.returncode,str(log))
    return log
save()
try:
    paths=run('paths',['py','-3',str(R/'tools/workspace_hygiene.py'),'paths'],180)
    doctor=run('doctor',['py','-3',str(R/'tools/workspace_hygiene.py'),'doctor','--measure'],600,accepted=(0,1))
    resources=json.loads(doctor.read_text());record['resource_measurement']=resources
    assert set(resources['violations'])<={'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
    assert len(resources['task_roots'])<=8 and resources['task_root_bytes']+20*1024**2+2*1024**3<20*1024**3
    assert shutil.disk_usage(W).free>=10*1024**3+20*1024**2
    census_script="""$p=@(Get-CimInstance Win32_Process); $ids=@($p.ProcessId); @($p | Where-Object {$_.Name -in @('cl.exe','MSBuild.exe','link.exe','cmake.exe','ctest.exe')} | ForEach-Object {$cpu=Get-Process -Id $_.ProcessId -ErrorAction SilentlyContinue; [pscustomobject]@{pid=$_.ProcessId;parent=$_.ParentProcessId;name=$_.Name;created=$_.CreationDate;command=$_.CommandLine;parent_live=($ids -contains $_.ParentProcessId);cpu=$cpu.CPU}}) | ConvertTo-Json -Compress"""
    def census():
        result=subprocess.run(['powershell','-NoProfile','-Command',census_script],capture_output=True,text=True,timeout=30)
        assert result.returncode==0
        rows=json.loads(result.stdout) if result.stdout.strip() else []
        return [rows] if isinstance(rows,dict) else rows
    resource_deadline=time.monotonic()+1800
    previous_active=None
    while True:
        first=census();time.sleep(2);second=census();indexed={p['pid']:p for p in first};active=[];ignored=[]
        for p in second:
            old=indexed.get(p['pid'])
            if old and p['name'].lower()=='msbuild.exe' and not p['parent_live'] and not old['parent_live'] and \
                '/nodemode:1' in (p['command'] or '') and '/nodeReuse:true' in (p['command'] or '') and \
                p['created']==old['created'] and p['cpu']==old['cpu']:ignored.append(p)
            else:active.append(p)
        record['resource_census']=dict(first=first,second=second,idle_orphan_nodes_preserved=ignored,active=active);save()
        signature=tuple(sorted((p['pid'],p['created'],p['name']) for p in active))
        if signature!=previous_active:
            print(json.dumps(dict(phase='resource_admission',active_native_workers=[p['pid'] for p in active])),flush=True)
            previous_active=signature
        if not active:break
        assert time.monotonic()<resource_deadline,'Resource deadline: preserve foreign work; no duplicate compile'
        time.sleep(15)
    assert not git('status','--porcelain')
    for relative,binding in proposal['source_paths'].items():assert sha(R/relative)==binding['original_sha256']
    assert {str(p):sha(p) for p in libs}==record['input_libraries_sha256']
    record['source_head_at_compile']=git('rev-parse','HEAD');save()
    vc=Path(r'C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Auxiliary\Build\vcvars64.bat')
    compiler=Path(r'C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.51.36231\bin\Hostx64\x64\cl.exe')
    setup=D/'compiler-environment.cmd'
    setup.write_text('@echo off\ncall "'+str(vc)+'" >nul\nif errorlevel 1 exit /b 1\nset INCLUDE\nset LIB\nset PATH\n',encoding='utf-8')
    result=subprocess.run(['cmd','/d','/c',str(setup)],capture_output=True,text=True,env=env,timeout=30)
    assert result.returncode==0
    native_env=dict(env,TEMP=str(temporary),TMP=str(temporary))
    for row in result.stdout.splitlines():
        if '=' in row:
            key,value=row.split('=',1)
            if key.upper() in {'INCLUDE','LIB','LIBPATH','PATH'}:native_env[key]=value
    executable=D/'fl_archive_core_smoke.exe'
    manifest=R/'apps/cli/facman.manifest';record['manifest_sha256']=sha(manifest)
    args=[str(compiler),'/nologo','/std:c++17','/EHsc','/utf-8','/MT','/O2','/DNDEBUG','/W4','/WX','/I'+str(P),
        *['/I'+str(R/'runtime'/p) for p in ('archive','base','platform','core')],
        '/Fe:'+str(executable),str(T/'fl_archive_core_smoke.cpp'),str(P/'fl_archive_retained_extraction.cpp'),
        str(P/'fl_file_io.cpp'),*map(str,libs),'Advapi32.lib','Bcrypt.lib','Shell32.lib','Ole32.lib',
        '/link','/INCREMENTAL:NO','/MANIFEST:EMBED','/MANIFESTINPUT:'+str(manifest)]
    run('compile',args,120,native_env)
    run('smoke',[str(executable)],120,native_env)
    assert {str(p):sha(p) for p in libs}==record['input_libraries_sha256']
    assert not git('status','--porcelain')
    record['source_head_after']=git('rev-parse','HEAD')
    record['scoped_source_and_libraries_unchanged']=True
    for relative,binding in proposal['source_paths'].items():assert sha(R/relative)==binding['original_sha256']
    record.update(status='PASS_PRIVATE_MAINTAINED_NATIVE_SMOKE',executable_sha256=sha(executable),
        active_pid=None,active_command=None,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
    print(json.dumps(dict(status=record['status'],receipt_sha256=sha(OUT),new_product_builds=0)),flush=True)
except BaseException as error:
    record.update(status=record['status'] if record['status'].startswith('STOP_') else 'FAILED_RETAINED',error=repr(error));save();raise
