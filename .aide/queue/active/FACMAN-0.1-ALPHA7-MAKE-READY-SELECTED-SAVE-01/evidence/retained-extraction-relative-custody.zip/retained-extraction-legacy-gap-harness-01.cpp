#include "fl_archive.h"
#include "fl_file_io.h"
#include "fl_sha256.h"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <limits>
namespace fs=std::filesystem;
std::string bytes(const fs::path& p) {
    std::ifstream f(p,std::ios::binary);
    return {std::istreambuf_iterator<char>(f),std::istreambuf_iterator<char>()};
}
int main(int argc,char** argv) {
    if(argc!=2) return 10;
    const auto base=fs::u8path(argv[1]);
    const auto staging=base/"staging", retained=base/"owned-retained", foreign=base/"foreign";
    facman::archive::Limits limits;
    facman::archive::Plan plan;
    auto status=facman::archive::inspect_archive(base/"payload.zip",limits,plan);
    if(!status.ok() || plan.entries.size()!=1) return 11;
    facman::base::Sha256Hasher hash;
    std::uint64_t size=0;
    status=facman::archive::stream_entry(plan,0,limits,[&](const unsigned char* p,std::size_t n){
        hash.update(p,n); size+=n; return true;
    });
    if(!status.ok()) return 12;
    const std::vector<facman::archive::VerifiedEntry> expected={{plan.entries[0].path,size,hash.finish()}};
    facman::platform::PathIdentity created, foreign_before, foreign_after, retained_after;
    if(!facman::platform::inspect_path_no_follow(foreign,foreign_before).ok()) return 13;
    bool substituted=false;
    facman::archive::ExtractionObservation observation;
    status=facman::archive::extract_verified_to_new_retained_staging(plan,staging,limits,expected,
        [&](std::uint32_t index,const char* name) {
            if(index!=std::numeric_limits<std::uint32_t>::max() ||
                std::string(name)!="root_created_unbound_for_testing") return true;
            if(!facman::platform::inspect_path_no_follow(staging,created).ok()) return false;
            std::error_code error;
            fs::rename(staging,retained,error); if(error) return false;
            fs::rename(foreign,staging,error); if(error) return false;
            substituted=true; return true;
        },&observation);
    const bool observed=facman::platform::inspect_path_no_follow(staging,foreign_after).ok() &&
        facman::platform::inspect_path_no_follow(retained,retained_after).ok();
    const bool sentinel_unchanged=bytes(staging/"foreign-sentinel.bin")=="FOREIGN\n";
    const bool foreign_output=bytes(staging/"nested"/"consumed.txt")=="VERIFIED PAYLOAD\n";
    const bool marker_written=bytes(staging/facman::archive::owned_staging_marker_name())==
        "schema=facman.archive_staging.v1\n";
    const bool original_empty=fs::is_empty(retained);
    const bool reproduced=status.ok() && substituted && observed &&
        !created.same_object(foreign_before) && foreign_before.same_object(foreign_after) &&
        created.same_object(retained_after) && sentinel_unchanged && foreign_output &&
        marker_written && original_empty && observation.effects_possible();
    std::cout<<"{\"status\":\""<<(reproduced?"REPRODUCED_FOREIGN_WRITES":"BASELINE_NOT_REPRODUCED")
        <<"\",\"extraction_code\":\""<<status.code<<"\",\"created_device\":\""<<created.device
        <<"\",\"created_object\":\""<<created.object<<"\",\"foreign_device\":\""<<foreign_before.device
        <<"\",\"foreign_object\":\""<<foreign_before.object<<"\",\"sentinel_unchanged\":"
        <<(sentinel_unchanged?"true":"false")<<",\"foreign_output_written\":"
        <<(foreign_output?"true":"false")<<",\"foreign_marker_written\":"
        <<(marker_written?"true":"false")<<",\"original_empty\":"
        <<(original_empty?"true":"false")<<"}\n";
    return reproduced?0:20;
}
