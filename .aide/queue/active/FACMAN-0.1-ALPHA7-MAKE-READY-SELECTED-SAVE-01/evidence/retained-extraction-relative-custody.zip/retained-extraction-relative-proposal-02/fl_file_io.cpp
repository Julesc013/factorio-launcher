// SPDX-FileCopyrightText: 2026 Jules C
// SPDX-License-Identifier: MIT

#include "fl_file_io.h"
#include "fl_retained_rewrite_state.h"

#include "fl_system_services.h"
#include "fl_windows_path.h"

#include <algorithm>
#include <cerrno>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <cwchar>
#include <limits>
#include <vector>

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <winternl.h>
#else
#include <dirent.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#if defined(__linux__)
#include <sys/syscall.h>
#elif defined(__APPLE__)
#include <sys/clonefile.h>
#endif
#endif

namespace facman::platform {
namespace {

thread_local bool relative_publish_post_rename_fault_for_testing = false;
thread_local unsigned relative_publish_pre_rename_fault_countdown_for_testing = 0U;
thread_local testing::RelativePublishBeforeReopenHook
    relative_publish_before_reopen_hook_for_testing = nullptr;

IoStatus published_unverified_failure(const IoStatus& underlying)
{
    return IoStatus::failure(
        "output_published_unverified",
        underlying.code + ": " + underlying.detail);
}

bool portable_leaf(const std::filesystem::path& leaf, std::string& value)
{
    value = leaf.generic_u8string();
    if (value.empty() || value.size() > 255U || value == "." || value == ".." || leaf.has_root_path() ||
        leaf.has_parent_path() || value.find_first_of("\\\\/:") != std::string::npos ||
        value.back() == '.' || value.back() == ' ') return false;
    for (const unsigned char character : value) {
        if (character < 0x21U || character > 0x7eU ||
            std::strchr("<>\"|?*", static_cast<int>(character)) != nullptr) return false;
    }
    std::string base = value.substr(0, value.find('.'));
    std::transform(base.begin(), base.end(), base.begin(), [](unsigned char character) {
        return static_cast<char>(std::toupper(character));
    });
    if (base == "CON" || base == "PRN" || base == "AUX" || base == "NUL") return false;
    return base.size() == 4U &&
        (base.rfind("COM", 0U) == 0U || base.rfind("LPT", 0U) == 0U) &&
        base[3] >= '1' && base[3] <= '9' ? false : true;
}

// A namespace component, rather than the stricter portable identifier contract.
bool relative_utf8_leaf(const std::string& name)
{
    if (name.empty() || name == "." || name == ".." ||
        name.find_first_of("\\/:") != std::string::npos ||
        name.find('\0') != std::string::npos) return false;
    for (std::size_t index = 0; index < name.size();) {
        const auto first = static_cast<unsigned char>(name[index]);
        std::size_t count = 1;
        std::uint32_t value = first;
        if (first >= 0x80U) {
            if ((first & 0xe0U) == 0xc0U) { count = 2; value = first & 0x1fU; }
            else if ((first & 0xf0U) == 0xe0U) { count = 3; value = first & 0x0fU; }
            else if ((first & 0xf8U) == 0xf0U) { count = 4; value = first & 0x07U; }
            else return false;
        }
        if (count > name.size() - index) return false;
        for (std::size_t offset = 1; offset < count; ++offset) {
            const auto next = static_cast<unsigned char>(name[index + offset]);
            if ((next & 0xc0U) != 0x80U) return false;
            value = (value << 6U) | (next & 0x3fU);
        }
        if ((count == 2 && value < 0x80U) || (count == 3 && value < 0x800U) ||
            (count == 4 && value < 0x10000U) || value > 0x10ffffU ||
            (value >= 0xd800U && value <= 0xdfffU)) return false;
        index += count;
    }
    return true;
}

#ifdef _WIN32
using NativeHandle = HANDLE;
const NativeHandle kInvalidHandle = INVALID_HANDLE_VALUE;
using OpenRelative = NTSTATUS (NTAPI*)(PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES,
    PIO_STATUS_BLOCK, PLARGE_INTEGER, ULONG, ULONG, ULONG, ULONG, PVOID, ULONG);
using SetRelativeInformation = NTSTATUS (NTAPI*)(HANDLE, PIO_STATUS_BLOCK, PVOID, ULONG,
    FILE_INFORMATION_CLASS);

OpenRelative nt_create_file()
{
    const HMODULE module = GetModuleHandleW(L"ntdll.dll");
    const FARPROC address = module ? GetProcAddress(module, "NtCreateFile") : nullptr;
    OpenRelative result = nullptr;
    static_assert(sizeof(result) == sizeof(address));
    std::memcpy(&result, &address, sizeof(address));
    return result;
}

SetRelativeInformation nt_set_information_file()
{
    const HMODULE module = GetModuleHandleW(L"ntdll.dll");
    const FARPROC address = module ? GetProcAddress(module, "NtSetInformationFile") : nullptr;
    SetRelativeInformation result = nullptr;
    static_assert(sizeof(result) == sizeof(address));
    std::memcpy(&result, &address, sizeof(address));
    return result;
}

IoStatus nt_rename_status(NTSTATUS status)
{
    const ULONG value = static_cast<ULONG>(status);
    if (value == 0xc0000035UL) return IoStatus::failure("commit_no_replace_collision", "destination exists");
    if (value == 0xc000000dUL) return IoStatus::failure("relative_publish_unavailable", "NtSetInformationFile rejected relative rename");
    if (value == 0xc00000d4UL) return IoStatus::failure("commit_cross_device", "relative rename crossed devices");
    if (value == 0xc000050bUL) return IoStatus::failure("commit_reparse_refused", "reparse encountered during relative rename");
    char detail[32] {};
    std::snprintf(detail, sizeof(detail), "NtSetInformationFile status 0x%08lx", value);
    return IoStatus::failure("commit_no_replace_failed", detail);
}

IoStatus open_relative_windows(
    HANDLE parent, const std::string& leaf, ACCESS_MASK access, ULONG disposition,
    ULONG options, HANDLE& result,
    ULONG share = FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE)
{
    const OpenRelative open_relative = nt_create_file();
    if (!open_relative) return IoStatus::failure("relative_open_unavailable", "NtCreateFile unavailable");
    if (leaf.size() > static_cast<std::size_t>((std::numeric_limits<int>::max)()))
        return IoStatus::failure("relative_leaf_too_long", "UTF-8 input length is not representable");
    const int count = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, leaf.data(),
        static_cast<int>(leaf.size()), nullptr, 0);
    if (count <= 0)
        return IoStatus::failure("relative_leaf_invalid", "Invalid UTF-8 filename");
    if (static_cast<std::size_t>(count) >
        (std::numeric_limits<USHORT>::max)() / sizeof(wchar_t))
        return IoStatus::failure("relative_leaf_too_long", "UTF-16 filename exceeds native length");
    std::wstring name(static_cast<std::size_t>(count), L'\0');
    if (MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, leaf.data(),
        static_cast<int>(leaf.size()), name.data(), count) != count)
        return IoStatus::failure("relative_leaf_invalid", "UTF-8 filename conversion failed");
    UNICODE_STRING unicode {};
    unicode.Buffer = name.data();
    unicode.Length = static_cast<USHORT>(name.size() * sizeof(wchar_t));
    unicode.MaximumLength = unicode.Length;
    OBJECT_ATTRIBUTES attributes {};
    attributes.Length = sizeof(attributes);
    attributes.RootDirectory = parent;
    attributes.ObjectName = &unicode;
    attributes.Attributes = 0x1040; // OBJ_DONT_REPARSE | OBJ_CASE_INSENSITIVE
    IO_STATUS_BLOCK io {};
    result = kInvalidHandle;
    const NTSTATUS status = open_relative(&result, access | SYNCHRONIZE, &attributes, &io,
        nullptr, FILE_ATTRIBUTE_NORMAL, share,
        disposition, options | 0x00000020, nullptr, 0);
    if (status < 0) {
        result = kInvalidHandle;
        return IoStatus::failure("relative_open_failed", "NtCreateFile failed with status " +
            std::to_string(static_cast<ULONG>(status)));
    }
    return IoStatus::success();
}

bool duplicate_handle(HANDLE source, HANDLE& target)
{
    return DuplicateHandle(GetCurrentProcess(), source, GetCurrentProcess(), &target, 0,
        FALSE, DUPLICATE_SAME_ACCESS) != 0;
}

std::string windows_error(const char* operation)
{
    return std::string(operation) + " failed with error " + std::to_string(GetLastError());
}

FileIdentity identity_from_info(const BY_HANDLE_FILE_INFORMATION& info)
{
    FileIdentity identity;
    identity.device = info.dwVolumeSerialNumber;
    identity.object = (static_cast<std::uint64_t>(info.nFileIndexHigh) << 32) | info.nFileIndexLow;
    identity.size = (static_cast<std::uint64_t>(info.nFileSizeHigh) << 32) | info.nFileSizeLow;
    identity.link_count = info.nNumberOfLinks;
    identity.regular_file = (info.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == 0 &&
        (info.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) == 0;
    return identity;
}

PathIdentity path_identity_from_info(
    const std::filesystem::path& path,
    HANDLE handle,
    const BY_HANDLE_FILE_INFORMATION& info)
{
    PathIdentity identity;
    identity.exists = true;
    identity.reparse_or_link =
        (info.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) != 0;
    identity.kind = (info.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0
        ? PathObjectKind::directory
        : (identity.reparse_or_link ? PathObjectKind::other : PathObjectKind::regular_file);
    identity.device = info.dwVolumeSerialNumber;
    identity.object =
        (static_cast<std::uint64_t>(info.nFileIndexHigh) << 32U) |
        static_cast<std::uint64_t>(info.nFileIndexLow);
    identity.size =
        (static_cast<std::uint64_t>(info.nFileSizeHigh) << 32U) |
        static_cast<std::uint64_t>(info.nFileSizeLow);
    identity.last_write_ticks =
        (static_cast<std::uint64_t>(info.ftLastWriteTime.dwHighDateTime) << 32U) |
        static_cast<std::uint64_t>(info.ftLastWriteTime.dwLowDateTime);
    wchar_t filesystem[64] {};
    if (GetVolumeInformationByHandleW(
            handle, nullptr, 0, nullptr, nullptr, nullptr,
            filesystem, static_cast<DWORD>(sizeof(filesystem) / sizeof(filesystem[0])))) {
        const int characters = static_cast<int>(std::wcslen(filesystem));
        const int bytes = WideCharToMultiByte(
            CP_UTF8, WC_ERR_INVALID_CHARS, filesystem, characters,
            nullptr, 0, nullptr, nullptr);
        if (bytes > 0) {
            identity.filesystem_name.resize(static_cast<std::size_t>(bytes));
            (void)WideCharToMultiByte(
                CP_UTF8, WC_ERR_INVALID_CHARS, filesystem, characters,
                identity.filesystem_name.data(), bytes, nullptr, nullptr);
        }
    }
    const std::filesystem::path root = std::filesystem::absolute(path).root_path();
    identity.fixed_local_volume = !root.empty() &&
        GetDriveTypeW(root.c_str()) == DRIVE_FIXED;
    return identity;
}
#else
using NativeHandle = int;
constexpr NativeHandle kInvalidHandle = -1;

FileIdentity identity_from_stat(const struct stat& info)
{
    FileIdentity identity;
    identity.device = static_cast<std::uint64_t>(info.st_dev);
    identity.object = static_cast<std::uint64_t>(info.st_ino);
    identity.size = static_cast<std::uint64_t>(info.st_size);
    identity.link_count = static_cast<std::uint64_t>(info.st_nlink);
    identity.regular_file = S_ISREG(info.st_mode);
    return identity;
}

PathIdentity path_identity_from_stat(const struct stat& info)
{
    PathIdentity identity;
    identity.exists = true;
    identity.reparse_or_link = S_ISLNK(info.st_mode);
    identity.kind = S_ISREG(info.st_mode)
        ? PathObjectKind::regular_file
        : (S_ISDIR(info.st_mode) ? PathObjectKind::directory : PathObjectKind::other);
    identity.device = static_cast<std::uint64_t>(info.st_dev);
    identity.object = static_cast<std::uint64_t>(info.st_ino);
    identity.size = static_cast<std::uint64_t>(info.st_size);
#if defined(__APPLE__)
    identity.last_write_ticks =
        static_cast<std::uint64_t>(info.st_mtimespec.tv_sec) * 1000000000ULL +
        static_cast<std::uint64_t>(info.st_mtimespec.tv_nsec);
#else
    identity.last_write_ticks =
        static_cast<std::uint64_t>(info.st_mtim.tv_sec) * 1000000000ULL +
        static_cast<std::uint64_t>(info.st_mtim.tv_nsec);
#endif
    identity.filesystem_name = "posix";
    return identity;
}

IoStatus flush_directory(const std::filesystem::path& directory)
{
    const int handle = ::open(directory.c_str(), O_RDONLY | O_DIRECTORY | O_CLOEXEC);
    if (handle < 0) return IoStatus::failure("directory_open_failed", std::strerror(errno));
    const int result = ::fsync(handle);
    const int error = errno;
    ::close(handle);
    return result == 0
        ? IoStatus::success(DurabilityLevel::file_and_directory_flushed)
        : IoStatus::failure("directory_flush_failed", std::strerror(error));
}

bool duplicate_handle(int source, int& target)
{
    target = ::fcntl(source, F_DUPFD_CLOEXEC, 0);
    return target >= 0;
}

IoStatus flush_directory_handle(int handle)
{
    if (::fsync(handle) != 0) return IoStatus::failure("directory_flush_failed", std::strerror(errno));
    return IoStatus::success(DurabilityLevel::file_and_directory_flushed);
}
#endif

IoStatus close_native_handle(NativeHandle& handle, const char* code)
{
    if (handle == kInvalidHandle) return IoStatus::success();
#ifdef _WIN32
    if (!CloseHandle(handle)) {
        handle = kInvalidHandle;
        return IoStatus::failure(code, windows_error("CloseHandle"));
    }
#else
    if (::close(handle) != 0) {
        const std::string detail = std::strerror(errno);
        handle = kInvalidHandle;
        return IoStatus::failure(code, detail);
    }
#endif
    handle = kInvalidHandle;
    return IoStatus::success();
}

void close_native_handle_noexcept(NativeHandle& handle) noexcept
{
    if (handle == kInvalidHandle) return;
#ifdef _WIN32
    (void)CloseHandle(handle);
#else
    (void)::close(handle);
#endif
    handle = kInvalidHandle;
}

} // namespace

namespace testing {

void set_relative_publish_post_rename_fault(bool enabled) noexcept
{
    relative_publish_post_rename_fault_for_testing = enabled;
}

void set_relative_publish_pre_rename_fault_countdown(unsigned count) noexcept
{
    relative_publish_pre_rename_fault_countdown_for_testing = count;
}

void set_relative_publish_before_reopen_hook(RelativePublishBeforeReopenHook hook) noexcept
{
    relative_publish_before_reopen_hook_for_testing = hook;
}

} // namespace testing

struct StableInputFile::Impl {
    NativeHandle handle = kInvalidHandle;
    FileIdentity identity;
    std::filesystem::path path;
    ~Impl()
    {
#ifdef _WIN32
        if (handle != kInvalidHandle) CloseHandle(handle);
#else
        if (handle != kInvalidHandle) ::close(handle);
#endif
    }
};

StableInputFile::StableInputFile() : impl_(std::make_unique<Impl>()) {}
StableInputFile::StableInputFile(StableInputFile&&) noexcept = default;
StableInputFile& StableInputFile::operator=(StableInputFile&&) noexcept = default;
StableInputFile::~StableInputFile() = default;

IoStatus StableInputFile::open_no_follow(const std::filesystem::path& path)
{
    return open_no_follow_impl(path, false);
}

IoStatus StableInputFile::open_no_follow_pinned(const std::filesystem::path& path)
{
    return open_no_follow_impl(path, true);
}

IoStatus StableInputFile::open_no_follow_impl(
    const std::filesystem::path& path,
    bool pinned)
{
    if (open()) return IoStatus::failure("input_already_open", path_to_utf8(path));
#ifdef _WIN32
    const std::wstring native_path = windows_extended_path(path);
    impl_->handle = CreateFileW(
        native_path.c_str(), GENERIC_READ,
        pinned ? FILE_SHARE_READ : FILE_SHARE_READ | FILE_SHARE_DELETE,
        nullptr, OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OPEN_REPARSE_POINT | FILE_FLAG_RANDOM_ACCESS, nullptr);
    if (impl_->handle == kInvalidHandle) return IoStatus::failure("input_open_failed", windows_error("CreateFileW"));
    BY_HANDLE_FILE_INFORMATION info {};
    if (!GetFileInformationByHandle(impl_->handle, &info)) {
        const std::string detail = windows_error("GetFileInformationByHandle");
        CloseHandle(impl_->handle);
        impl_->handle = kInvalidHandle;
        return IoStatus::failure("input_identity_failed", detail);
    }
    impl_->identity = identity_from_info(info);
#else
    impl_->handle = ::open(path.c_str(), O_RDONLY | O_NOFOLLOW | O_CLOEXEC);
    if (impl_->handle < 0) return IoStatus::failure("input_open_failed", std::strerror(errno));
    struct stat info {};
    if (::fstat(impl_->handle, &info) != 0) {
        const std::string detail = std::strerror(errno);
        ::close(impl_->handle);
        impl_->handle = kInvalidHandle;
        return IoStatus::failure("input_identity_failed", detail);
    }
    impl_->identity = identity_from_stat(info);
#endif
    if (!impl_->identity.regular_file || (pinned && impl_->identity.link_count != 1U)) {
#ifdef _WIN32
        CloseHandle(impl_->handle);
#else
        ::close(impl_->handle);
#endif
        impl_->handle = kInvalidHandle;
        return IoStatus::failure(
            impl_->identity.regular_file ? "input_multiple_links" : "input_not_regular",
            path_to_utf8(path));
    }
    impl_->path = path;
    return IoStatus::success();
}

std::size_t StableInputFile::read_at(std::uint64_t offset, void* buffer, std::size_t size) const
{
    if (!open() || offset >= impl_->identity.size) return 0;
    size = static_cast<std::size_t>(std::min<std::uint64_t>(size, impl_->identity.size - offset));
#ifdef _WIN32
    LARGE_INTEGER position {};
    position.QuadPart = static_cast<LONGLONG>(offset);
    if (!SetFilePointerEx(impl_->handle, position, nullptr, FILE_BEGIN)) return 0;
    DWORD read = 0;
    const DWORD requested = static_cast<DWORD>(std::min<std::size_t>(size, std::numeric_limits<DWORD>::max()));
    if (!ReadFile(impl_->handle, buffer, requested, &read, nullptr)) return 0;
    return read;
#else
    const ssize_t count = ::pread(impl_->handle, buffer, size, static_cast<off_t>(offset));
    return count > 0 ? static_cast<std::size_t>(count) : 0;
#endif
}

IoStatus StableInputFile::revalidate() const
{
    if (!open()) return IoStatus::failure("input_not_open", "");
    FileIdentity current;
#ifdef _WIN32
    BY_HANDLE_FILE_INFORMATION info {};
    if (!GetFileInformationByHandle(impl_->handle, &info)) return IoStatus::failure("input_revalidate_failed", windows_error("GetFileInformationByHandle"));
    current = identity_from_info(info);
#else
    struct stat info {};
    if (::fstat(impl_->handle, &info) != 0) return IoStatus::failure("input_revalidate_failed", std::strerror(errno));
    current = identity_from_stat(info);
#endif
    return impl_->identity.unchanged(current) ? IoStatus::success() : IoStatus::failure("input_identity_changed", "stable input identity changed while open");
}

IoStatus StableInputFile::revalidate_path() const
{
    const IoStatus held = revalidate();
    if (!held.ok()) return held;
    PathIdentity current;
    const IoStatus observed = inspect_path_no_follow(impl_->path, current);
    if (!observed.ok()) return observed;
    if (!current.exists || current.reparse_or_link ||
        current.kind != PathObjectKind::regular_file ||
        current.device != impl_->identity.device ||
        current.object != impl_->identity.object ||
        current.size != impl_->identity.size) {
        return IoStatus::failure(
            "input_path_identity_changed", path_to_utf8(impl_->path));
    }
    return IoStatus::success();
}
const FileIdentity& StableInputFile::identity() const noexcept { return impl_->identity; }
std::uint64_t StableInputFile::size() const noexcept { return impl_->identity.size; }
bool StableInputFile::open() const noexcept { return impl_ && impl_->handle != kInvalidHandle; }

struct StableDirectoryObject::Impl {
    NativeHandle handle = kInvalidHandle;
    PathIdentity identity;
    std::filesystem::path path;
    ~Impl()
    {
#ifdef _WIN32
        if (handle != kInvalidHandle) CloseHandle(handle);
#else
        if (handle != kInvalidHandle) ::close(handle);
#endif
    }
};

StableDirectoryObject::StableDirectoryObject() : impl_(std::make_unique<Impl>()) {}
StableDirectoryObject::StableDirectoryObject(StableDirectoryObject&&) noexcept = default;
StableDirectoryObject& StableDirectoryObject::operator=(StableDirectoryObject&&) noexcept = default;

StableDirectoryObject::~StableDirectoryObject() = default;

IoStatus StableDirectoryObject::open_no_follow(const std::filesystem::path& path)
{
    return open_no_follow_impl(path, false);
}

IoStatus StableDirectoryObject::open_no_follow_for_relative_writes(const std::filesystem::path& path)
{
    return open_no_follow_impl(path, true);
}

IoStatus StableDirectoryObject::open_no_follow_for_publication_verification(const std::filesystem::path& path)
{
    return open_no_follow_impl(path, false, true);
}

IoStatus StableDirectoryObject::open_no_follow_impl(
    const std::filesystem::path& path, bool relative_writes, bool allow_publication_handle)
{
    if (!impl_ || impl_->handle != kInvalidHandle) {
        return IoStatus::failure("directory_object_already_open", path_to_utf8(path));
    }
    std::error_code absolute_error;
    const std::filesystem::path absolute =
        std::filesystem::absolute(path, absolute_error).lexically_normal();
    if (absolute_error || absolute.empty()) {
        return IoStatus::failure("directory_object_path_invalid", path_to_utf8(path));
    }
#ifndef _WIN32
    (void)relative_writes;
    (void)allow_publication_handle;
#endif
#ifdef _WIN32
    const std::wstring native_path = windows_extended_path(absolute);
    impl_->handle = CreateFileW(
        native_path.c_str(), FILE_READ_ATTRIBUTES | FILE_LIST_DIRECTORY |
            (relative_writes ? FILE_ADD_FILE | FILE_ADD_SUBDIRECTORY | FILE_TRAVERSE | SYNCHRONIZE : 0),
        FILE_SHARE_READ | FILE_SHARE_WRITE | (allow_publication_handle ? FILE_SHARE_DELETE : 0),
        nullptr, OPEN_EXISTING,
        FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OPEN_REPARSE_POINT,
        nullptr);
    if (impl_->handle == kInvalidHandle) {
        return IoStatus::failure(
            "directory_object_open_failed", windows_error("CreateFileW"));
    }
    BY_HANDLE_FILE_INFORMATION info {};
    if (!GetFileInformationByHandle(impl_->handle, &info)) {
        const std::string detail = windows_error("GetFileInformationByHandle");
        CloseHandle(impl_->handle);
        impl_->handle = kInvalidHandle;
        return IoStatus::failure("directory_object_identity_failed", detail);
    }
    impl_->identity = path_identity_from_info(absolute, impl_->handle, info);
#else
    impl_->handle =
        ::open(absolute.c_str(), O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
    if (impl_->handle == kInvalidHandle) {
        return IoStatus::failure("directory_object_open_failed", std::strerror(errno));
    }
    struct stat info {};
    if (::fstat(impl_->handle, &info) != 0) {
        const std::string detail = std::strerror(errno);
        ::close(impl_->handle);
        impl_->handle = kInvalidHandle;
        return IoStatus::failure("directory_object_identity_failed", detail);
    }
    impl_->identity = path_identity_from_stat(info);
#endif
    if (!impl_->identity.exists ||
        impl_->identity.kind != PathObjectKind::directory ||
        impl_->identity.reparse_or_link) {
#ifdef _WIN32
        CloseHandle(impl_->handle);
#else
        ::close(impl_->handle);
#endif
        impl_->handle = kInvalidHandle;
        impl_->identity = {};
        return IoStatus::failure(
            "directory_object_not_plain_directory", path_to_utf8(absolute));
    }
    impl_->path = absolute;
    return IoStatus::success();
}

IoStatus StableDirectoryObject::revalidate() const
{
    if (!open()) return IoStatus::failure("directory_object_not_open", "");
    PathIdentity held;
#ifdef _WIN32
    BY_HANDLE_FILE_INFORMATION info {};
    if (!GetFileInformationByHandle(impl_->handle, &info)) {
        return IoStatus::failure(
            "directory_object_revalidate_failed",
            windows_error("GetFileInformationByHandle"));
    }
    held = path_identity_from_info(impl_->path, impl_->handle, info);
#else
    struct stat info {};
    if (::fstat(impl_->handle, &info) != 0) {
        return IoStatus::failure(
            "directory_object_revalidate_failed", std::strerror(errno));
    }
    held = path_identity_from_stat(info);
#endif
    if (!held.same_object(impl_->identity) ||
        held.kind != PathObjectKind::directory ||
        held.reparse_or_link) {
        return IoStatus::failure(
            "directory_object_handle_identity_changed", path_to_utf8(impl_->path));
    }
    PathIdentity current;
    const IoStatus observed = inspect_path_no_follow(impl_->path, current);
    if (!observed.ok()) return observed;
    if (!current.same_object(impl_->identity) ||
        current.kind != PathObjectKind::directory ||
        current.reparse_or_link) {
        return IoStatus::failure(
            "directory_object_path_identity_changed", path_to_utf8(impl_->path));
    }
    return IoStatus::success();
}

IoStatus StableDirectoryObject::validate_descendant(
    const std::filesystem::path& path,
    bool allow_absent_leaf) const
{
    const IoStatus before = revalidate();
    if (!before.ok()) return before;
    std::error_code absolute_error;
    const std::filesystem::path absolute =
        std::filesystem::absolute(path, absolute_error).lexically_normal();
    if (absolute_error || absolute.empty()) {
        return IoStatus::failure("directory_descendant_path_invalid", path_to_utf8(path));
    }
    const std::filesystem::path relative = absolute.lexically_relative(impl_->path);
    if (relative.empty() || relative.is_absolute()) {
        return IoStatus::failure(
            "directory_descendant_escape", path_to_utf8(absolute));
    }
    const std::string relative_text = relative.generic_string();
    if (relative_text == ".." || relative_text.rfind("../", 0U) == 0U) {
        return IoStatus::failure(
            "directory_descendant_escape", path_to_utf8(absolute));
    }
    std::filesystem::path current = impl_->path;
    std::size_t index = 0U;
    const std::size_t component_count =
        static_cast<std::size_t>(std::distance(relative.begin(), relative.end()));
    for (const auto& component : relative) {
        if (component == "." || component.empty()) continue;
        if (component == "..") {
            return IoStatus::failure(
                "directory_descendant_escape", path_to_utf8(absolute));
        }
        current /= component;
        PathIdentity identity;
        const IoStatus observed = inspect_path_no_follow(current, identity);
        if (!observed.ok()) return observed;
        const bool final_component = ++index == component_count;
        if (!identity.exists) {
            if (allow_absent_leaf && final_component) break;
            return IoStatus::failure(
                "directory_descendant_missing", path_to_utf8(current));
        }
        if (identity.reparse_or_link || identity.kind == PathObjectKind::other) {
            return IoStatus::failure(
                "directory_descendant_reparse_refused", path_to_utf8(current));
        }
        if (!final_component && identity.kind != PathObjectKind::directory) {
            return IoStatus::failure(
                "directory_descendant_ancestor_not_directory", path_to_utf8(current));
        }
    }
    return revalidate();
}

const PathIdentity& StableDirectoryObject::identity() const noexcept
{
    return impl_->identity;
}

const std::filesystem::path& StableDirectoryObject::path() const noexcept
{
    return impl_->path;
}

bool StableDirectoryObject::open() const noexcept
{
    return impl_ && impl_->handle != kInvalidHandle;
}

IoStatus StableDirectoryObject::remove_child_file_no_follow_if_matches(
    const std::filesystem::path& leaf, const FileIdentity& expected,
    const std::function<bool(const StableInputFile&)>& verify_content) const
{
    std::string name;
    if (!portable_leaf(leaf, name) || !verify_content || !expected.regular_file || expected.link_count != 1U)
        return IoStatus::failure("relative_cleanup_identity_invalid", path_to_utf8(leaf));
    const IoStatus valid = revalidate();
    if (!valid.ok()) return valid;
#ifdef _WIN32
    NativeHandle handle = kInvalidHandle;
    auto opened = open_relative_windows(impl_->handle, name,
        GENERIC_READ | DELETE | FILE_READ_ATTRIBUTES, 1, 0x00200040, handle, 0);
    if (!opened.ok()) return opened;
    StableInputFile file;
    file.impl_->handle = handle;
    file.impl_->path = impl_->path / leaf;
    BY_HANDLE_FILE_INFORMATION info {};
    if (!GetFileInformationByHandle(handle, &info))
        return IoStatus::failure("relative_cleanup_identity_failed", windows_error("GetFileInformationByHandle"));
    file.impl_->identity = identity_from_info(info);
    if (!expected.unchanged(file.identity()) || !verify_content(file) || !file.revalidate().ok())
        return IoStatus::failure("relative_cleanup_identity_changed", name);
    FILE_DISPOSITION_INFO disposition {};
    disposition.DeleteFile = TRUE;
    if (!SetFileInformationByHandle(handle, FileDispositionInfo, &disposition,
            static_cast<DWORD>(sizeof(disposition))))
        return IoStatus::failure("relative_cleanup_remove_failed", windows_error("SetFileInformationByHandle"));
    return close_native_handle(file.impl_->handle, "relative_cleanup_close_failed");
#else
    StableInputFile file;
    auto opened = open_child_file_no_follow_pinned(leaf, file);
    if (!opened.ok()) return opened;
    if (!expected.unchanged(file.identity()) || !verify_content(file) || !file.revalidate().ok())
        return IoStatus::failure("relative_cleanup_identity_changed", name);
    struct stat current {};
    if (::fstatat(impl_->handle, name.c_str(), &current, AT_SYMLINK_NOFOLLOW) != 0 ||
        !expected.unchanged(identity_from_stat(current)))
        return IoStatus::failure("relative_cleanup_identity_changed", name);
    // Bounded unlink, not atomic compare-and-unlink: a final-leaf concurrent
    // replacement after fstatat is a retained platform acceptance limitation.
    if (::unlinkat(impl_->handle, name.c_str(), 0) != 0)
        return IoStatus::failure("relative_cleanup_remove_failed", std::strerror(errno));
    return flush_directory_handle(impl_->handle);
#endif
}

IoStatus StableDirectoryObject::remove_child_empty_directory_no_follow_if_matches(
    const std::filesystem::path& leaf, const PathIdentity& expected) const
{
    std::string name;
    if (!portable_leaf(leaf, name) || !expected.exists || expected.reparse_or_link || expected.kind != PathObjectKind::directory)
        return IoStatus::failure("relative_cleanup_identity_invalid", path_to_utf8(leaf));
    const IoStatus valid = revalidate();
    if (!valid.ok()) return valid;
#ifdef _WIN32
    NativeHandle handle = kInvalidHandle;
    auto opened = open_relative_windows(impl_->handle, name,
        DELETE | FILE_READ_ATTRIBUTES | FILE_LIST_DIRECTORY, 1, 0x00200001, handle, 0);
    if (!opened.ok()) return opened;
    BY_HANDLE_FILE_INFORMATION info {};
    if (!GetFileInformationByHandle(handle, &info)) {
        const std::string detail = windows_error("GetFileInformationByHandle");
        CloseHandle(handle);
        return IoStatus::failure("relative_cleanup_identity_failed", detail);
    }
    const PathIdentity current = path_identity_from_info(impl_->path / leaf, handle, info);
    if (!current.same_object(expected) || current.reparse_or_link) {
        CloseHandle(handle);
        return IoStatus::failure("relative_cleanup_identity_changed", name);
    }
    // Native disposition is nonrecursive and refuses a nonempty directory,
    // including a foreign child inserted after any earlier enumeration.
    FILE_DISPOSITION_INFO disposition {};
    disposition.DeleteFile = TRUE;
    const bool removed = SetFileInformationByHandle(handle, FileDispositionInfo, &disposition,
        static_cast<DWORD>(sizeof(disposition))) != 0;
    const std::string detail = removed ? std::string {} : windows_error("SetFileInformationByHandle");
    const IoStatus closed = close_native_handle(handle, "relative_cleanup_close_failed");
    if (!removed) return IoStatus::failure("relative_cleanup_remove_failed", detail);
    return closed;
#else
    struct stat current {};
    if (::fstatat(impl_->handle, name.c_str(), &current, AT_SYMLINK_NOFOLLOW) != 0 ||
        !path_identity_from_stat(current).same_object(expected) || !S_ISDIR(current.st_mode))
        return IoStatus::failure("relative_cleanup_identity_changed", name);
    // Nonrecursive rmdir refuses foreign children inserted after enumeration.
    if (::unlinkat(impl_->handle, name.c_str(), AT_REMOVEDIR) != 0)
        return IoStatus::failure("relative_cleanup_remove_failed", std::strerror(errno));
    return flush_directory_handle(impl_->handle);
#endif
}

IoStatus StableDirectoryObject::flush_metadata() const
{
    const IoStatus valid = revalidate();
    if (!valid.ok()) return valid;
#ifdef _WIN32
    // Windows does not provide a supported directory-flush contract.
    return IoStatus::success(DurabilityLevel::best_effort_platform_limit);
#else
    return flush_directory_handle(impl_->handle);
#endif
}

IoStatus StableDirectoryObject::open_child_directory_no_follow(
    const std::filesystem::path& leaf, StableDirectoryObject& child) const
{
    return open_child_directory_no_follow_impl(leaf, child, false);
}

IoStatus StableDirectoryObject::open_child_directory_no_follow_for_relative_writes(
    const std::filesystem::path& leaf, StableDirectoryObject& child) const
{
    return open_child_directory_no_follow_impl(leaf, child, true);
}

IoStatus StableDirectoryObject::open_child_directory_no_follow_impl(
    const std::filesystem::path& leaf,
    StableDirectoryObject& child,
    bool relative_writes) const
{
    std::string name;
    if (!portable_leaf(leaf, name)) return IoStatus::failure("relative_leaf_invalid", path_to_utf8(leaf));
    if (!child.impl_ || child.open()) return IoStatus::failure("directory_object_already_open", name);
    const IoStatus valid = revalidate();
    if (!valid.ok()) return valid;
    NativeHandle handle = kInvalidHandle;
#ifndef _WIN32
    (void)relative_writes;
#endif
#ifdef _WIN32
    IoStatus status = open_relative_windows(impl_->handle, name,
        FILE_READ_ATTRIBUTES | FILE_LIST_DIRECTORY |
            (relative_writes ? FILE_ADD_FILE | FILE_ADD_SUBDIRECTORY | FILE_TRAVERSE : 0),
        1, 0x00200001, handle,
        FILE_SHARE_READ | FILE_SHARE_WRITE);
    if (!status.ok()) return status;
    BY_HANDLE_FILE_INFORMATION info {};
    if (!GetFileInformationByHandle(handle, &info)) {
        const std::string detail = windows_error("GetFileInformationByHandle");
        CloseHandle(handle);
        return IoStatus::failure("directory_object_identity_failed", detail);
    }
    child.impl_->identity = path_identity_from_info(impl_->path / leaf, handle, info);
#else
    handle = ::openat(impl_->handle, name.c_str(), O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
    if (handle < 0) return IoStatus::failure("relative_open_failed", std::strerror(errno));
    struct stat info {};
    if (::fstat(handle, &info) != 0) {
        const std::string detail = std::strerror(errno);
        ::close(handle);
        return IoStatus::failure("directory_object_identity_failed", detail);
    }
    child.impl_->identity = path_identity_from_stat(info);
#endif
    if (child.impl_->identity.kind != PathObjectKind::directory || child.impl_->identity.reparse_or_link) {
#ifdef _WIN32
        CloseHandle(handle);
#else
        ::close(handle);
#endif
        child.impl_->identity = {};
        return IoStatus::failure("relative_child_not_plain_directory", name);
    }
    child.impl_->handle = handle;
    child.impl_->path = impl_->path / leaf;
    return IoStatus::success();
}

IoStatus StableDirectoryObject::create_child_directory_exclusive(
    const std::filesystem::path& leaf, StableDirectoryObject& child) const
{
    std::string name;
    if (!portable_leaf(leaf, name)) return IoStatus::failure("relative_leaf_invalid", path_to_utf8(leaf));
    return create_child_directory_exclusive_impl(leaf, name, child);
}

IoStatus StableDirectoryObject::create_child_directory_exclusive_utf8(
    const std::string& leaf, StableDirectoryObject& child) const
{
    if (!relative_utf8_leaf(leaf)) return IoStatus::failure("relative_leaf_invalid", "Invalid UTF-8 component");
    return create_child_directory_exclusive_impl(path_from_utf8(leaf), leaf, child);
}

IoStatus StableDirectoryObject::create_child_directory_exclusive_impl(
    const std::filesystem::path& leaf, const std::string& name, StableDirectoryObject& child) const
{
    if (!child.impl_ || child.open()) return IoStatus::failure("directory_object_already_open", name);
    const IoStatus valid = revalidate();
    if (!valid.ok()) return valid;
#ifdef _WIN32
    HANDLE created = kInvalidHandle;
    IoStatus status = open_relative_windows(impl_->handle, name,
        FILE_READ_ATTRIBUTES | FILE_LIST_DIRECTORY | FILE_ADD_FILE | FILE_ADD_SUBDIRECTORY |
            FILE_TRAVERSE,
        2, 0x00200001, created, FILE_SHARE_READ | FILE_SHARE_WRITE);
    if (!status.ok()) return IoStatus::failure("relative_directory_create_failed", status.detail);
    child.impl_->handle = created;
    BY_HANDLE_FILE_INFORMATION info {};
    if (!GetFileInformationByHandle(created, &info)) {
        const std::string detail = windows_error("GetFileInformationByHandle");
        CloseHandle(created);
        child.impl_->handle = kInvalidHandle;
        return IoStatus::failure("directory_object_identity_failed", detail);
    }
    child.impl_->identity = path_identity_from_info(impl_->path / leaf, created, info);
#else
    if (::mkdirat(impl_->handle, name.c_str(), 0700) != 0)
        return IoStatus::failure("relative_directory_create_failed", std::strerror(errno));
    const int opened = ::openat(impl_->handle, name.c_str(), O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
    if (opened < 0) return IoStatus::failure("relative_directory_open_failed", std::strerror(errno));
    child.impl_->handle = opened;
    struct stat info {};
    if (::fstat(opened, &info) != 0) {
        const std::string detail = std::strerror(errno);
        ::close(opened);
        child.impl_->handle = kInvalidHandle;
        return IoStatus::failure("directory_object_identity_failed", detail);
    }
    child.impl_->identity = path_identity_from_stat(info);
#endif
    child.impl_->path = impl_->path / leaf;
    return child.revalidate();
}

IoStatus StableDirectoryObject::open_child_file_no_follow_pinned(
    const std::filesystem::path& leaf, StableInputFile& child) const
{
    std::string name;
    if (!portable_leaf(leaf, name)) return IoStatus::failure("relative_leaf_invalid", path_to_utf8(leaf));
    if (!child.impl_ || child.open()) return IoStatus::failure("input_already_open", name);
    const IoStatus valid = revalidate();
    if (!valid.ok()) return valid;
    NativeHandle handle = kInvalidHandle;
#ifdef _WIN32
    IoStatus status = open_relative_windows(impl_->handle, name, GENERIC_READ, 1, 0x00200040, handle,
        FILE_SHARE_READ);
    if (!status.ok()) return status;
    BY_HANDLE_FILE_INFORMATION info {};
    if (!GetFileInformationByHandle(handle, &info)) {
        const std::string detail = windows_error("GetFileInformationByHandle");
        CloseHandle(handle);
        return IoStatus::failure("input_identity_failed", detail);
    }
    child.impl_->identity = identity_from_info(info);
#else
    handle = ::openat(impl_->handle, name.c_str(), O_RDONLY | O_NOFOLLOW | O_CLOEXEC);
    if (handle < 0) return IoStatus::failure("relative_open_failed", std::strerror(errno));
    struct stat info {};
    if (::fstat(handle, &info) != 0) {
        const std::string detail = std::strerror(errno);
        ::close(handle);
        return IoStatus::failure("input_identity_failed", detail);
    }
    child.impl_->identity = identity_from_stat(info);
#endif
    if (!child.impl_->identity.regular_file || child.impl_->identity.link_count != 1U) {
#ifdef _WIN32
        CloseHandle(handle);
#else
        ::close(handle);
#endif
        return IoStatus::failure(child.impl_->identity.regular_file ? "input_multiple_links" : "input_not_regular", name);
    }
    child.impl_->handle = handle;
    child.impl_->path = impl_->path / leaf;
    return IoStatus::success();
}

IoStatus StableDirectoryObject::list_child_names_bounded(
    std::size_t maximum_entries,
    std::vector<std::filesystem::path>& names) const
{
    names.clear();
    const IoStatus before = revalidate();
    if (!before.ok()) return before;
#ifdef _WIN32
    HANDLE duplicate = kInvalidHandle;
    if (!duplicate_handle(impl_->handle, duplicate))
        return IoStatus::failure("directory_enumerate_failed", windows_error("DuplicateHandle"));
    std::vector<unsigned char> buffer(64U * 1024U);
    bool more = true;
    bool restart = true;
    while (more) {
        if (!GetFileInformationByHandleEx(duplicate,
                restart ? FileIdBothDirectoryRestartInfo : FileIdBothDirectoryInfo,
                buffer.data(), static_cast<DWORD>(buffer.size()))) {
            const DWORD error = GetLastError();
            if (error == ERROR_NO_MORE_FILES) break;
            CloseHandle(duplicate);
            names.clear();
            return IoStatus::failure("directory_enumerate_failed", windows_error("GetFileInformationByHandleEx"));
        }
        restart = false;
        std::size_t offset = 0U;
        for (;;) {
            const auto* entry = reinterpret_cast<const FILE_ID_BOTH_DIR_INFO*>(buffer.data() + offset);
            const std::size_t chars = entry->FileNameLength / sizeof(wchar_t);
            const std::wstring value(entry->FileName, chars);
            if (value != L"." && value != L"..") {
                const std::filesystem::path leaf(value);
                std::string portable;
                if (!portable_leaf(leaf, portable) || names.size() >= maximum_entries) {
                    CloseHandle(duplicate);
                    names.clear();
                    return IoStatus::failure("directory_enumerate_invalid", "directory contains an invalid or excessive leaf");
                }
                names.push_back(leaf);
            }
            if (entry->NextEntryOffset == 0U) break;
            offset += entry->NextEntryOffset;
            if (offset >= buffer.size()) {
                CloseHandle(duplicate);
                names.clear();
                return IoStatus::failure("directory_enumerate_failed", "directory entry offset is invalid");
            }
        }
    }
    CloseHandle(duplicate);
#else
    const int duplicate = ::openat(impl_->handle, ".", O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
    if (duplicate < 0) return IoStatus::failure("directory_enumerate_failed", std::strerror(errno));
    DIR* directory = ::fdopendir(duplicate);
    if (directory == nullptr) {
        const std::string detail = std::strerror(errno);
        ::close(duplicate);
        return IoStatus::failure("directory_enumerate_failed", detail);
    }
    errno = 0;
    while (dirent* entry = ::readdir(directory)) {
        const std::string value(entry->d_name);
        if (value == "." || value == "..") continue;
        std::string portable;
        if (!portable_leaf(std::filesystem::path(value), portable) ||
            names.size() >= maximum_entries) {
            ::closedir(directory);
            names.clear();
            return IoStatus::failure("directory_enumerate_invalid", "directory contains an invalid or excessive leaf");
        }
        names.emplace_back(value);
    }
    const int enumeration_error = errno;
    if (::closedir(directory) != 0 && enumeration_error == 0) {
        names.clear();
        return IoStatus::failure("directory_enumerate_failed", std::strerror(errno));
    }
    if (enumeration_error != 0) {
        names.clear();
        return IoStatus::failure("directory_enumerate_failed", std::strerror(enumeration_error));
    }
#endif
    std::sort(names.begin(), names.end(), [](const auto& left, const auto& right) {
        return left.generic_u8string() < right.generic_u8string();
    });
    const IoStatus after = revalidate();
    if (!after.ok()) names.clear();
    return after;
}

struct DurableOutputFile::Impl {
    enum class RelativeNamespaceState { none, staging, published_unverified };
    NativeHandle handle = kInvalidHandle;
    NativeHandle parent_handle = kInvalidHandle;
    std::filesystem::path path;
    std::string staging_leaf;
    FileIdentity identity;
    bool relative_created = false;
    bool relative_reopened = false;
    RelativeNamespaceState relative_state = RelativeNamespaceState::none;
    std::uint64_t next_offset = 0;
    std::uint64_t maximum_size = 0;
    void reset_relative_state() noexcept
    {
        relative_created = false;
        relative_reopened = false;
        relative_state = RelativeNamespaceState::none;
        staging_leaf.clear();
        parent_handle = kInvalidHandle;
        identity = {};
        next_offset = 0;
        maximum_size = 0;
    }
    void close_owned_handles_noexcept() noexcept
    {
        close_native_handle_noexcept(handle);
        close_native_handle_noexcept(parent_handle);
    }
    ~Impl()
    {
#ifdef _WIN32
        if (handle != kInvalidHandle) CloseHandle(handle);
        if (parent_handle != kInvalidHandle) CloseHandle(parent_handle);
#else
        if (handle != kInvalidHandle) ::close(handle);
        if (parent_handle != kInvalidHandle) ::close(parent_handle);
#endif
    }
};

DurableOutputFile::DurableOutputFile() : impl_(std::make_unique<Impl>()) {}
DurableOutputFile::DurableOutputFile(DurableOutputFile&&) noexcept = default;
DurableOutputFile& DurableOutputFile::operator=(DurableOutputFile&&) noexcept = default;
DurableOutputFile::~DurableOutputFile() = default;

IoStatus testing_close_relative_staging_for_recovery(DurableOutputFile& output)
{
    auto& state = *output.impl_;
    if (state.handle == kInvalidHandle || state.parent_handle == kInvalidHandle ||
        !state.relative_created ||
        state.relative_state != DurableOutputFile::Impl::RelativeNamespaceState::staging)
        return IoStatus::failure("relative_recovery_not_staging", "");
#ifdef _WIN32
    if (!FlushFileBuffers(state.handle))
        return IoStatus::failure("output_flush_failed", windows_error("FlushFileBuffers"));
#else
    if (::fsync(state.handle) != 0)
        return IoStatus::failure("output_flush_failed", std::strerror(errno));
    const IoStatus flushed = flush_directory_handle(state.parent_handle);
    if (!flushed.ok()) return flushed;
#endif
    const IoStatus file_closed = close_native_handle(state.handle, "output_close_failed");
    if (!file_closed.ok()) return file_closed;
    return close_native_handle(state.parent_handle, "output_parent_close_failed");
}

IoStatus DurableOutputFile::create_exclusive(const std::filesystem::path& path, std::uint64_t maximum_size)
{
    if (impl_->handle != kInvalidHandle || impl_->parent_handle != kInvalidHandle ||
        impl_->relative_state != Impl::RelativeNamespaceState::none)
        return IoStatus::failure("output_already_open", path_to_utf8(path));
#ifdef _WIN32
    const std::wstring native_path = windows_extended_path(path);
    impl_->handle = CreateFileW(native_path.c_str(), GENERIC_WRITE | DELETE, 0,
        nullptr, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (impl_->handle == kInvalidHandle) return IoStatus::failure("output_create_failed", windows_error("CreateFileW"));
#else
    impl_->handle = ::open(path.c_str(), O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, 0600);
    if (impl_->handle < 0) return IoStatus::failure("output_create_failed", std::strerror(errno));
#endif
    impl_->path = path;
    impl_->identity = {};
    impl_->next_offset = 0;
    impl_->maximum_size = maximum_size;
    return IoStatus::success();
}

IoStatus StableDirectoryObject::create_child_file_exclusive(
    const std::filesystem::path& leaf,
    std::uint64_t maximum_size,
    DurableOutputFile& child) const
{
    std::string name;
    if (!portable_leaf(leaf, name)) return IoStatus::failure("relative_leaf_invalid", path_to_utf8(leaf));
    return create_child_file_exclusive_impl(leaf, name, maximum_size, child);
}

IoStatus StableDirectoryObject::create_child_file_exclusive_utf8(
    const std::string& leaf, std::uint64_t maximum_size, DurableOutputFile& child) const
{
    if (!relative_utf8_leaf(leaf)) return IoStatus::failure("relative_leaf_invalid", "Invalid UTF-8 component");
    return create_child_file_exclusive_impl(path_from_utf8(leaf), leaf, maximum_size, child);
}

IoStatus StableDirectoryObject::create_child_file_exclusive_impl(
    const std::filesystem::path& leaf, const std::string& name,
    std::uint64_t maximum_size, DurableOutputFile& child) const
{
    if (!child.impl_ || child.impl_->handle != kInvalidHandle ||
        child.impl_->parent_handle != kInvalidHandle ||
        child.impl_->relative_state != DurableOutputFile::Impl::RelativeNamespaceState::none)
        return IoStatus::failure("output_already_open", name);
    const IoStatus valid = revalidate();
    if (!valid.ok()) return valid;
    NativeHandle parent = kInvalidHandle;
    if (!duplicate_handle(impl_->handle, parent)) {
#ifdef _WIN32
        return IoStatus::failure("relative_parent_duplicate_failed", windows_error("DuplicateHandle"));
#else
        return IoStatus::failure("relative_parent_duplicate_failed", std::strerror(errno));
#endif
    }
    NativeHandle file = kInvalidHandle;
#ifdef _WIN32
    IoStatus status = open_relative_windows(parent, name,
        GENERIC_WRITE | DELETE | FILE_READ_ATTRIBUTES, 2, 0x00200040, file, 0);
    if (!status.ok()) {
        CloseHandle(parent);
        return IoStatus::failure("relative_file_create_failed", status.detail);
    }
    BY_HANDLE_FILE_INFORMATION info {};
    if (!GetFileInformationByHandle(file, &info)) {
        const std::string detail = windows_error("GetFileInformationByHandle");
        CloseHandle(file);
        CloseHandle(parent);
        return IoStatus::failure("output_identity_failed", detail);
    }
    child.impl_->identity = identity_from_info(info);
#else
    file = ::openat(parent, name.c_str(), O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0600);
    if (file < 0) {
        const std::string detail = std::strerror(errno);
        ::close(parent);
        return IoStatus::failure("relative_file_create_failed", detail);
    }
    struct stat info {};
    if (::fstat(file, &info) != 0) {
        const std::string detail = std::strerror(errno);
        ::close(file);
        ::close(parent);
        return IoStatus::failure("output_identity_failed", detail);
    }
    child.impl_->identity = identity_from_stat(info);
#endif
    if (!child.impl_->identity.regular_file || child.impl_->identity.link_count != 1U) {
#ifdef _WIN32
        CloseHandle(file);
        CloseHandle(parent);
#else
        ::close(file);
        ::close(parent);
#endif
        return IoStatus::failure("output_not_regular", name);
    }
    child.impl_->handle = file;
    child.impl_->parent_handle = parent;
    child.impl_->path = impl_->path / leaf;
    child.impl_->staging_leaf = name;
    child.impl_->next_offset = 0;
    child.impl_->maximum_size = maximum_size;
    child.impl_->relative_created = true;
    child.impl_->relative_state = DurableOutputFile::Impl::RelativeNamespaceState::staging;
    return IoStatus::success();
}

IoStatus StableDirectoryObject::reopen_child_file_no_follow_for_relative_publish(
    const std::filesystem::path& leaf, const FileIdentity& expected,
    std::uint64_t maximum_size, DurableOutputFile& child) const
{
    std::string name;
    if (!portable_leaf(leaf, name)) return IoStatus::failure("relative_leaf_invalid", path_to_utf8(leaf));
    if (!expected.regular_file || expected.link_count != 1U || expected.size > maximum_size)
        return IoStatus::failure("relative_publish_identity_invalid", name);
    if (!child.impl_ || child.impl_->handle != kInvalidHandle ||
        child.impl_->parent_handle != kInvalidHandle ||
        child.impl_->relative_state != DurableOutputFile::Impl::RelativeNamespaceState::none)
        return IoStatus::failure("output_already_open", name);
    const IoStatus valid = revalidate();
    if (!valid.ok()) return valid;
    if (relative_publish_before_reopen_hook_for_testing != nullptr)
        relative_publish_before_reopen_hook_for_testing(impl_->path / leaf);
    NativeHandle parent = kInvalidHandle;
    if (!duplicate_handle(impl_->handle, parent)) {
#ifdef _WIN32
        return IoStatus::failure("relative_parent_duplicate_failed", windows_error("DuplicateHandle"));
#else
        return IoStatus::failure("relative_parent_duplicate_failed", std::strerror(errno));
#endif
    }
    NativeHandle file = kInvalidHandle;
    FileIdentity actual;
#ifdef _WIN32
    IoStatus opened = open_relative_windows(parent, name,
        GENERIC_WRITE | DELETE | FILE_READ_ATTRIBUTES | SYNCHRONIZE,
        1, 0x00200040, file, 0);
    if (!opened.ok()) { CloseHandle(parent); return IoStatus::failure("relative_publish_reopen_failed", opened.detail); }
    BY_HANDLE_FILE_INFORMATION info {};
    if (!GetFileInformationByHandle(file, &info)) {
        const std::string detail = windows_error("GetFileInformationByHandle");
        CloseHandle(file); CloseHandle(parent);
        return IoStatus::failure("relative_publish_identity_failed", detail);
    }
    actual = identity_from_info(info);
#else
#ifdef __APPLE__
    file = ::openat(parent, name.c_str(), O_RDWR | O_NOFOLLOW | O_CLOEXEC);
#else
    file = ::openat(parent, name.c_str(), O_WRONLY | O_NOFOLLOW | O_CLOEXEC);
#endif
    if (file < 0) { const std::string detail = std::strerror(errno); ::close(parent);
        return IoStatus::failure("relative_publish_reopen_failed", detail); }
    struct stat info {};
    if (::fstat(file, &info) != 0) { const std::string detail = std::strerror(errno);
        ::close(file); ::close(parent); return IoStatus::failure("relative_publish_identity_failed", detail); }
    actual = identity_from_stat(info);
#endif
    if (!expected.unchanged(actual) || !actual.regular_file || actual.link_count != 1U ||
        actual.size > maximum_size) {
#ifdef _WIN32
        CloseHandle(file); CloseHandle(parent);
#else
        ::close(file); ::close(parent);
#endif
        return IoStatus::failure("relative_publish_identity_changed", name);
    }
    // write_at tracks a logical offset; the reopened native handle must start
    // at the same offset before an interrupted relative copy can append.
    if (actual.size > static_cast<std::uint64_t>(
            std::numeric_limits<std::int64_t>::max())) {
#ifdef _WIN32
        CloseHandle(file); CloseHandle(parent);
#else
        ::close(file); ::close(parent);
#endif
        return IoStatus::failure("relative_publish_size_invalid", name);
    }
#ifdef _WIN32
    LARGE_INTEGER position {};
    position.QuadPart = static_cast<LONGLONG>(actual.size);
    if (!SetFilePointerEx(file, position, nullptr, FILE_BEGIN)) {
        const std::string detail = windows_error("SetFilePointerEx");
        CloseHandle(file); CloseHandle(parent);
        return IoStatus::failure("relative_publish_seek_failed", detail);
    }
#else
    if (::lseek(file, static_cast<off_t>(actual.size), SEEK_SET) < 0) {
        const std::string detail = std::strerror(errno);
        ::close(file); ::close(parent);
        return IoStatus::failure("relative_publish_seek_failed", detail);
    }
#endif
    child.impl_->handle = file;
    child.impl_->parent_handle = parent;
    child.impl_->path = impl_->path / leaf;
    child.impl_->staging_leaf = name;
    child.impl_->identity = actual;
    child.impl_->next_offset = actual.size;
    child.impl_->maximum_size = maximum_size;
    child.impl_->relative_created = true;
    child.impl_->relative_reopened = true;
    child.impl_->relative_state = DurableOutputFile::Impl::RelativeNamespaceState::staging;
    return IoStatus::success();
}

std::size_t DurableOutputFile::write_at(std::uint64_t offset, const void* buffer, std::size_t size)
{
    if (impl_->handle == kInvalidHandle || offset != impl_->next_offset ||
        offset > impl_->maximum_size || size > impl_->maximum_size - offset) return 0;
#ifdef _WIN32
    DWORD written = 0;
    const DWORD requested = static_cast<DWORD>(std::min<std::size_t>(size, std::numeric_limits<DWORD>::max()));
    if (!WriteFile(impl_->handle, buffer, requested, &written, nullptr)) return 0;
    impl_->next_offset += written;
    return written;
#else
    const ssize_t written = ::write(impl_->handle, buffer, size);
    if (written <= 0) return 0;
    impl_->next_offset += static_cast<std::size_t>(written);
    return static_cast<std::size_t>(written);
#endif
}

IoStatus DurableOutputFile::flush_file_and_parent()
{
    if (impl_->handle == kInvalidHandle) {
        if (impl_->relative_created &&
            impl_->relative_state != Impl::RelativeNamespaceState::published_unverified) {
            const IoStatus parent_closed =
                close_native_handle(impl_->parent_handle, "output_parent_close_failed");
            impl_->reset_relative_state();
            if (!parent_closed.ok()) return parent_closed;
        }
        return IoStatus::failure("output_not_open", "");
    }
    IoStatus status;
#ifdef _WIN32
    if (!FlushFileBuffers(impl_->handle)) {
        status = IoStatus::failure("output_flush_failed", windows_error("FlushFileBuffers"));
    } else {
        status = IoStatus::success(DurabilityLevel::best_effort_platform_limit);
    }
#else
    if (::fsync(impl_->handle) != 0) {
        status = IoStatus::failure("output_flush_failed", std::strerror(errno));
    } else {
        status = IoStatus::success(DurabilityLevel::file_flushed);
    }
#endif
    const IoStatus file_closed = close_native_handle(impl_->handle, "output_close_failed");
    if (status.ok() && !file_closed.ok()) status = file_closed;

    if (impl_->relative_created) {
#ifndef _WIN32
        if (status.ok() && impl_->parent_handle != kInvalidHandle) {
            const IoStatus parent_flushed = flush_directory_handle(impl_->parent_handle);
            if (!parent_flushed.ok()) status = parent_flushed;
            else status = parent_flushed;
        }
#endif
        const IoStatus parent_closed = close_native_handle(impl_->parent_handle, "output_parent_close_failed");
        if (status.ok() && !parent_closed.ok()) status = parent_closed;
        impl_->reset_relative_state();
        return status;
    }
#ifdef _WIN32
    return status;
#else
    if (!status.ok()) return status;
    return flush_directory(impl_->path.parent_path());
#endif
}

IoStatus DurableOutputFile::publish_no_replace(
    const std::filesystem::path& destination)
{
    if (impl_->handle == kInvalidHandle) return IoStatus::failure("output_not_open", "");
#ifdef _WIN32
    if (!FlushFileBuffers(impl_->handle)) {
        return IoStatus::failure("output_flush_failed", windows_error("FlushFileBuffers"));
    }
    const std::wstring native_destination = windows_extended_path(destination);
    const std::size_t name_bytes = native_destination.size() * sizeof(wchar_t);
    std::vector<unsigned char> storage(sizeof(FILE_RENAME_INFO) + name_bytes, 0U);
    auto* rename = reinterpret_cast<FILE_RENAME_INFO*>(storage.data());
    rename->ReplaceIfExists = FALSE;
    rename->RootDirectory = nullptr;
    rename->FileNameLength = static_cast<DWORD>(name_bytes);
    std::memcpy(rename->FileName, native_destination.data(), name_bytes);
    if (!SetFileInformationByHandle(
            impl_->handle, FileRenameInfo, rename,
            static_cast<DWORD>(storage.size()))) {
        return IoStatus::failure(
            "commit_no_replace_failed",
            windows_error("SetFileInformationByHandle(FileRenameInfo)"));
    }
    if (!CloseHandle(impl_->handle)) {
        return IoStatus::failure("output_close_failed", windows_error("CloseHandle"));
    }
    impl_->handle = kInvalidHandle;
    impl_->path = destination;
    return IoStatus::success(DurabilityLevel::best_effort_platform_limit);
#else
    if (::fsync(impl_->handle) != 0) {
        return IoStatus::failure("output_flush_failed", std::strerror(errno));
    }
    struct stat held {};
    struct stat named {};
    if (::fstat(impl_->handle, &held) != 0 || ::lstat(impl_->path.c_str(), &named) != 0 ||
        held.st_dev != named.st_dev || held.st_ino != named.st_ino) {
        return IoStatus::failure(
            "commit_source_identity_changed", path_to_utf8(impl_->path));
    }
    if (::link(impl_->path.c_str(), destination.c_str()) != 0) {
        return IoStatus::failure("commit_no_replace_failed", std::strerror(errno));
    }
    struct stat published {};
    if (::fstat(impl_->handle, &held) != 0 || ::lstat(destination.c_str(), &published) != 0 ||
        held.st_dev != published.st_dev || held.st_ino != published.st_ino) {
        return IoStatus::failure(
            "commit_destination_identity_changed", path_to_utf8(destination));
    }
    if (::unlink(impl_->path.c_str()) != 0) {
        return IoStatus::failure("commit_source_remove_failed", std::strerror(errno));
    }
    if (::close(impl_->handle) != 0) {
        return IoStatus::failure("output_close_failed", std::strerror(errno));
    }
    impl_->handle = kInvalidHandle;
    const std::filesystem::path source_parent = impl_->path.parent_path();
    IoStatus source_flush = flush_directory(source_parent);
    if (!source_flush.ok()) return source_flush;
    impl_->path = destination;
    if (destination.parent_path() != source_parent) {
        return flush_directory(destination.parent_path());
    }
    return source_flush;
#endif
}

IoStatus DurableOutputFile::publish_sibling_no_replace(
    const std::filesystem::path& destination_leaf)
{
    return publish_relative_no_replace(nullptr, destination_leaf);
}

IoStatus DurableOutputFile::publish_in_directory_no_replace(
    const StableDirectoryObject& destination_parent,
    const std::filesystem::path& destination_leaf)
{
    return publish_relative_no_replace(&destination_parent, destination_leaf);
}

IoStatus DurableOutputFile::publish_relative_no_replace(
    const StableDirectoryObject* destination_parent,
    const std::filesystem::path& destination_leaf)
{
    std::string destination;
    if (!portable_leaf(destination_leaf, destination))
        return IoStatus::failure("relative_leaf_invalid", path_to_utf8(destination_leaf));
    if (impl_->handle == kInvalidHandle || !impl_->relative_created ||
        impl_->relative_state != Impl::RelativeNamespaceState::staging ||
        impl_->parent_handle == kInvalidHandle)
        return IoStatus::failure("relative_output_not_open", destination);
    if (destination_parent != nullptr &&
        (!destination_parent->open() || !destination_parent->revalidate().ok()))
        return IoStatus::failure("relative_destination_parent_changed", destination);
    const NativeHandle target_parent = destination_parent == nullptr
        ? impl_->parent_handle : destination_parent->impl_->handle;
    const std::filesystem::path target_path = destination_parent == nullptr
        ? impl_->path.parent_path() / destination_leaf
        : destination_parent->path() / destination_leaf;
#ifdef _WIN32
    if (!FlushFileBuffers(impl_->handle))
        return IoStatus::failure("output_flush_failed", windows_error("FlushFileBuffers"));
    if (relative_publish_pre_rename_fault_countdown_for_testing != 0U &&
        --relative_publish_pre_rename_fault_countdown_for_testing == 0U)
        return IoStatus::failure("output_pre_rename_fault_injected", "test seam");
    BY_HANDLE_FILE_INFORMATION source_info {};
    if (!GetFileInformationByHandle(impl_->handle, &source_info) ||
        (destination_parent != nullptr && impl_->relative_reopened &&
         !impl_->identity.unchanged(identity_from_info(source_info))) ||
        !identity_from_info(source_info).regular_file || source_info.nNumberOfLinks != 1U)
        return IoStatus::failure("commit_source_identity_changed", impl_->staging_leaf);
    std::wstring name(destination.begin(), destination.end());
    const std::size_t name_bytes = name.size() * sizeof(wchar_t);
    std::vector<unsigned char> storage(sizeof(FILE_RENAME_INFO) + name_bytes, 0U);
    auto* rename = reinterpret_cast<FILE_RENAME_INFO*>(storage.data());
    rename->ReplaceIfExists = FALSE;
    rename->RootDirectory = target_parent;
    if (name_bytes > std::numeric_limits<DWORD>::max())
        return IoStatus::failure("relative_publish_unavailable", "destination leaf is too large");
    rename->FileNameLength = static_cast<DWORD>(name_bytes);
    std::memcpy(rename->FileName, name.data(), name_bytes);
    if (storage.size() > std::numeric_limits<ULONG>::max())
        return IoStatus::failure("relative_publish_unavailable", "rename information is too large");
    const SetRelativeInformation set_information = nt_set_information_file();
    if (!set_information)
        return IoStatus::failure("relative_publish_unavailable", "NtSetInformationFile unavailable");
    IO_STATUS_BLOCK rename_io {};
    const NTSTATUS rename_status = set_information(
        impl_->handle, &rename_io, rename, static_cast<ULONG>(storage.size()),
        static_cast<FILE_INFORMATION_CLASS>(10)); // FileRenameInformation
    if (rename_status < 0) return nt_rename_status(rename_status);
    impl_->relative_state = Impl::RelativeNamespaceState::published_unverified;
    impl_->staging_leaf = destination;
    impl_->path = target_path;
    const auto fail_after_namespace_rename = [&](IoStatus failure) {
        impl_->close_owned_handles_noexcept();
        return published_unverified_failure(failure);
    };
    if (relative_publish_post_rename_fault_for_testing) {
        return fail_after_namespace_rename(
            IoStatus::failure("output_post_rename_fault_injected", "test seam"));
    }
    if (!FlushFileBuffers(impl_->handle)) {
        return fail_after_namespace_rename(
            IoStatus::failure("output_flush_failed", windows_error("FlushFileBuffers")));
    }
    const IoStatus file_closed = close_native_handle(impl_->handle, "output_close_failed");
    if (!file_closed.ok()) return fail_after_namespace_rename(file_closed);
    HANDLE published = kInvalidHandle;
    IoStatus published_status = open_relative_windows(target_parent, destination,
        FILE_READ_ATTRIBUTES, 1, 0x00200040, published);
    if (!published_status.ok()) return fail_after_namespace_rename(published_status);
    BY_HANDLE_FILE_INFORMATION published_info {};
    const bool published_ok = GetFileInformationByHandle(published, &published_info) != 0;
    const IoStatus published_closed = close_native_handle(published, "output_close_failed");
    const FileIdentity published_identity = identity_from_info(published_info);
    if (!published_ok || !impl_->identity.same_object(published_identity) ||
        !published_identity.regular_file || published_identity.link_count != 1U) {
        return fail_after_namespace_rename(
            IoStatus::failure("commit_destination_identity_changed", destination));
    }
    if (!published_closed.ok()) return fail_after_namespace_rename(published_closed);
    const IoStatus parent_closed = close_native_handle(impl_->parent_handle, "output_parent_close_failed");
    if (!parent_closed.ok()) return fail_after_namespace_rename(parent_closed);
    impl_->reset_relative_state();
    return IoStatus::success(DurabilityLevel::best_effort_platform_limit);
#else
    if (::fsync(impl_->handle) != 0)
        return IoStatus::failure("output_flush_failed", std::strerror(errno));
    if (relative_publish_pre_rename_fault_countdown_for_testing != 0U &&
        --relative_publish_pre_rename_fault_countdown_for_testing == 0U)
        return IoStatus::failure("output_pre_rename_fault_injected", "test seam");
    struct stat held {};
    struct stat named {};
    const bool by_open_inode = destination_parent != nullptr;
    if (::fstat(impl_->handle, &held) != 0 || !S_ISREG(held.st_mode) || held.st_nlink != 1 ||
        (!by_open_inode &&
         (::fstatat(impl_->parent_handle, impl_->staging_leaf.c_str(), &named, AT_SYMLINK_NOFOLLOW) != 0 ||
          held.st_dev != named.st_dev || held.st_ino != named.st_ino ||
          !S_ISREG(named.st_mode) || named.st_nlink != 1)) ||
        (destination_parent != nullptr && impl_->relative_reopened &&
         !impl_->identity.unchanged(identity_from_stat(held))))
        return IoStatus::failure("commit_source_identity_changed", impl_->staging_leaf);
#if defined(__linux__) && defined(SYS_renameat2)
    if (destination_parent != nullptr) {
        // Follow the proc descriptor symlink to the opened inode. AT_EMPTY_PATH
        // requires CAP_DAC_READ_SEARCH and cannot serve ordinary users.
        const std::string held_source = "/proc/self/fd/" + std::to_string(impl_->handle);
        if (::linkat(AT_FDCWD, held_source.c_str(), target_parent,
                destination.c_str(), AT_SYMLINK_FOLLOW) != 0)
            return IoStatus::failure("commit_no_replace_failed", std::strerror(errno));
    } else if (::syscall(SYS_renameat2, impl_->parent_handle, impl_->staging_leaf.c_str(),
            target_parent, destination.c_str(), 1U) != 0) {
        return IoStatus::failure("commit_no_replace_failed", std::strerror(errno));
    }
#elif defined(__APPLE__)
    if (destination_parent != nullptr) {
        // APFS creates the target atomically from the opened source descriptor.
        // A source-name rename here would reintroduce the substitution race.
        if (::fclonefileat(impl_->handle, target_parent, destination.c_str(), 0) != 0)
            return IoStatus::failure("commit_no_replace_failed", std::strerror(errno));
    } else if (::renameatx_np(impl_->parent_handle, impl_->staging_leaf.c_str(),
            target_parent, destination.c_str(), RENAME_EXCL) != 0) {
        return IoStatus::failure("commit_no_replace_failed", std::strerror(errno));
    }
#else
    return IoStatus::failure("commit_no_replace_unsupported", "atomic relative no-replace rename unavailable");
#endif
    impl_->relative_state = Impl::RelativeNamespaceState::published_unverified;
    impl_->staging_leaf = destination;
    impl_->path = target_path;
    const auto fail_after_namespace_rename = [&](IoStatus failure) {
        impl_->close_owned_handles_noexcept();
        return published_unverified_failure(failure);
    };
    if (relative_publish_post_rename_fault_for_testing) {
        return fail_after_namespace_rename(
            IoStatus::failure("output_post_rename_fault_injected", "test seam"));
    }
    struct stat published {};
    nlink_t expected_links = 1;
#ifdef __linux__
    if (destination_parent != nullptr) expected_links = 2;
#endif
    bool cloned_output = false;
#ifdef __APPLE__
    cloned_output = destination_parent != nullptr;
#endif
    if (::fstatat(target_parent, destination.c_str(), &published, AT_SYMLINK_NOFOLLOW) != 0 ||
        held.st_dev != published.st_dev ||
        (cloned_output ? held.st_size != published.st_size : held.st_ino != published.st_ino) ||
        !S_ISREG(published.st_mode) ||
        published.st_nlink != expected_links) {
        return fail_after_namespace_rename(
            IoStatus::failure("commit_destination_identity_changed", destination));
    }
    const IoStatus file_closed = close_native_handle(impl_->handle, "output_close_failed");
    if (!file_closed.ok()) return fail_after_namespace_rename(file_closed);
    IoStatus flushed = flush_directory_handle(impl_->parent_handle);
    if (!flushed.ok()) return fail_after_namespace_rename(flushed);
    if (target_parent != impl_->parent_handle) {
        flushed = flush_directory_handle(target_parent);
        if (!flushed.ok()) return fail_after_namespace_rename(flushed);
    }
    const IoStatus parent_closed = close_native_handle(impl_->parent_handle, "output_parent_close_failed");
    if (!parent_closed.ok()) return fail_after_namespace_rename(parent_closed);
    impl_->reset_relative_state();
    return flushed;
#endif
}

IoStatus DurableOutputFile::discard_open()
{
    if (impl_->relative_state == Impl::RelativeNamespaceState::published_unverified) {
        impl_->close_owned_handles_noexcept();
        return IoStatus::failure("output_published_unverified", "published output requires manual recovery");
    }
    if (impl_->handle == kInvalidHandle && impl_->parent_handle == kInvalidHandle) {
        impl_->reset_relative_state();
        return IoStatus::success();
    }
    IoStatus status = IoStatus::success();
#ifdef _WIN32
    FILE_DISPOSITION_INFO disposition {};
    disposition.DeleteFile = TRUE;
    if (impl_->handle != kInvalidHandle && !SetFileInformationByHandle(
            impl_->handle, FileDispositionInfo, &disposition,
            static_cast<DWORD>(sizeof(disposition)))) {
        status = IoStatus::failure(
            "output_discard_failed",
            windows_error("SetFileInformationByHandle(FileDispositionInfo)"));
    }
    const IoStatus file_closed = close_native_handle(impl_->handle, "output_close_failed");
    if (status.ok() && !file_closed.ok()) status = file_closed;
    if (status.ok()) status = IoStatus::success(DurabilityLevel::best_effort_platform_limit);
#else
    const IoStatus file_closed = close_native_handle(impl_->handle, "output_close_failed");
    if (!file_closed.ok()) status = file_closed;
    if (status.ok()) status = IoStatus::failure(
        "output_discard_preserved",
        impl_->relative_created
            ? "relative staging file is preserved for recovery"
            : "open temporary is preserved because handle-owned unlink is unavailable");
#endif
    const IoStatus parent_closed = close_native_handle(impl_->parent_handle, "output_parent_close_failed");
    if (status.ok() && !parent_closed.ok()) status = parent_closed;
    impl_->reset_relative_state();
    return status;
}
void DurableOutputFile::close_without_flush() noexcept
{
    impl_->close_owned_handles_noexcept();
    if (impl_->relative_state != Impl::RelativeNamespaceState::published_unverified)
        impl_->reset_relative_state();
}
const std::filesystem::path& DurableOutputFile::path() const noexcept { return impl_->path; }
const FileIdentity& DurableOutputFile::identity() const noexcept { return impl_->identity; }

#ifndef _WIN32
struct PrivatePublicationFile::Impl {
    int file = -1;
    int target_parent = -1;
    std::uint64_t next_offset = 0;
    std::uint64_t maximum_size = 0;
    bool published_unverified = false;
    ~Impl()
    {
        if (file >= 0) ::close(file);
        if (target_parent >= 0) ::close(target_parent);
    }
};

PrivatePublicationFile::PrivatePublicationFile() : impl_(std::make_unique<Impl>()) {}
PrivatePublicationFile::~PrivatePublicationFile() = default;

IoStatus PrivatePublicationFile::create(
    const StableDirectoryObject& staging_parent,
    const StableDirectoryObject& destination_parent,
    std::uint64_t maximum_size)
{
    if (impl_->file >= 0 || impl_->target_parent >= 0)
        return IoStatus::failure("private_output_already_open", "");
    if (!staging_parent.open() || !staging_parent.revalidate().ok() ||
        !destination_parent.open() || !destination_parent.revalidate().ok())
        return IoStatus::failure("private_output_parent_changed", "");
    if (!duplicate_handle(destination_parent.impl_->handle, impl_->target_parent))
        return IoStatus::failure("private_output_parent_duplicate_failed", std::strerror(errno));
#ifdef __linux__
    impl_->file = ::openat(impl_->target_parent, ".", O_TMPFILE | O_RDWR | O_CLOEXEC, 0600);
    if (impl_->file < 0)
        return IoStatus::failure("private_output_create_failed", std::strerror(errno));
#elif defined(__APPLE__)
    RandomIdGenerator random;
    const std::string name = ".facman-private-" + random.next("archive");
    impl_->file = ::openat(staging_parent.impl_->handle, name.c_str(),
        O_RDWR | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW, 0600);
    if (impl_->file < 0)
        return IoStatus::failure("private_output_create_failed", std::strerror(errno));
    if (::unlinkat(staging_parent.impl_->handle, name.c_str(), 0) != 0)
        return IoStatus::failure("private_output_unlink_failed", std::strerror(errno));
    const IoStatus removed = staging_parent.flush_metadata();
    if (!removed.ok()) return removed;
#endif
    impl_->next_offset = 0;
    impl_->maximum_size = maximum_size;
    return IoStatus::success();
}

std::size_t PrivatePublicationFile::write_at(
    std::uint64_t offset, const void* data, std::size_t size)
{
    if (impl_->file < 0 || impl_->published_unverified ||
        offset != impl_->next_offset || offset > impl_->maximum_size ||
        size > impl_->maximum_size - offset) return 0;
    const ssize_t written = ::pwrite(impl_->file, data, size, static_cast<off_t>(offset));
    if (written > 0) impl_->next_offset += static_cast<std::uint64_t>(written);
    return written > 0 ? static_cast<std::size_t>(written) : 0;
}

IoStatus PrivatePublicationFile::publish_no_replace(const std::filesystem::path& destination_leaf)
{
    std::string destination;
    if (!portable_leaf(destination_leaf, destination) || impl_->file < 0 ||
        impl_->target_parent < 0 || impl_->published_unverified)
        return IoStatus::failure("private_output_not_ready", path_to_utf8(destination_leaf));
    if (::fsync(impl_->file) != 0)
        return IoStatus::failure("private_output_flush_failed", std::strerror(errno));
    struct stat held {};
    if (::fstat(impl_->file, &held) != 0 || !S_ISREG(held.st_mode) ||
        held.st_nlink != 0 || held.st_size != static_cast<off_t>(impl_->next_offset))
        return IoStatus::failure("private_output_identity_changed", destination);
#ifdef __linux__
    if (::linkat(impl_->file, "", impl_->target_parent, destination.c_str(), AT_EMPTY_PATH) != 0)
        return IoStatus::failure("private_output_publish_failed", std::strerror(errno));
#elif defined(__APPLE__)
    if (::fclonefileat(impl_->file, impl_->target_parent, destination.c_str(), 0) != 0)
        return IoStatus::failure("private_output_publish_failed", std::strerror(errno));
#endif
    impl_->published_unverified = true;
    struct stat published {};
    if (::fstatat(impl_->target_parent, destination.c_str(), &published, AT_SYMLINK_NOFOLLOW) != 0 ||
        !S_ISREG(published.st_mode) || published.st_nlink != 1 ||
        published.st_size != held.st_size ||
#ifdef __linux__
        published.st_dev != held.st_dev || published.st_ino != held.st_ino ||
#endif
        false)
        return published_unverified_failure(
            IoStatus::failure("private_output_destination_changed", destination));
    const IoStatus flushed = flush_directory_handle(impl_->target_parent);
    if (!flushed.ok()) return published_unverified_failure(flushed);
    impl_->published_unverified = false;
    return IoStatus::success(DurabilityLevel::best_effort_platform_limit);
}
#endif

IoStatus commit_no_replace(const std::filesystem::path& source, const std::filesystem::path& destination)
{
#ifdef _WIN32
    const std::wstring native_source = windows_extended_path(source);
    const std::wstring native_destination = windows_extended_path(destination);
    if (!MoveFileExW(native_source.c_str(), native_destination.c_str(), MOVEFILE_WRITE_THROUGH)) {
        return IoStatus::failure("commit_no_replace_failed", windows_error("MoveFileExW"));
    }
    return IoStatus::success(DurabilityLevel::best_effort_platform_limit);
#else
    if (::link(source.c_str(), destination.c_str()) != 0) return IoStatus::failure("commit_no_replace_failed", std::strerror(errno));
    if (::unlink(source.c_str()) != 0) return IoStatus::failure("commit_source_remove_failed", std::strerror(errno));
    IoStatus source_flush = flush_directory(source.parent_path());
    if (!source_flush.ok()) return source_flush;
    if (destination.parent_path() != source.parent_path()) return flush_directory(destination.parent_path());
    return source_flush;
#endif
}

IoStatus replace_existing_durable(const std::filesystem::path& source, const std::filesystem::path& destination)
{
#ifdef _WIN32
    const std::wstring native_source = windows_extended_path(source);
    const std::wstring native_destination = windows_extended_path(destination);
    if (!MoveFileExW(native_source.c_str(), native_destination.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) {
        return IoStatus::failure("replace_existing_failed", windows_error("MoveFileExW"));
    }
    return IoStatus::success(DurabilityLevel::best_effort_platform_limit);
#else
    if (::rename(source.c_str(), destination.c_str()) != 0) {
        return IoStatus::failure("replace_existing_failed", std::strerror(errno));
    }
    IoStatus source_flush = flush_directory(source.parent_path());
    if (!source_flush.ok()) return source_flush;
    if (destination.parent_path() != source.parent_path()) return flush_directory(destination.parent_path());
    return source_flush;
#endif
}

IoStatus remove_exact_object(const std::filesystem::path& path, const FileIdentity& expected)
{
    StableInputFile current;
    IoStatus status = current.open_no_follow(path);
    if (!status.ok()) return status;
    if (!current.identity().same_object(expected)) return IoStatus::failure("remove_identity_mismatch", path_to_utf8(path));
#ifdef _WIN32
    const std::wstring native_path = windows_extended_path(path);
    if (!DeleteFileW(native_path.c_str())) return IoStatus::failure("remove_failed", windows_error("DeleteFileW"));
#else
    if (::unlink(path.c_str()) != 0) return IoStatus::failure("remove_failed", std::strerror(errno));
    return flush_directory(path.parent_path());
#endif
    return IoStatus::success(DurabilityLevel::best_effort_platform_limit);
}

IoStatus inspect_path_no_follow(
    const std::filesystem::path& path,
    PathIdentity& identity)
{
    identity = {};
#ifdef _WIN32
    const std::wstring native_path = windows_extended_path(path);
    HANDLE handle = CreateFileW(
        native_path.c_str(), FILE_READ_ATTRIBUTES,
        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
        nullptr, OPEN_EXISTING,
        FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OPEN_REPARSE_POINT,
        nullptr);
    if (handle == INVALID_HANDLE_VALUE) {
        const DWORD error = GetLastError();
        if (error == ERROR_FILE_NOT_FOUND || error == ERROR_PATH_NOT_FOUND) {
            identity.kind = PathObjectKind::absent;
            return IoStatus::success();
        }
        return IoStatus::failure("path_identity_failed", windows_error("CreateFileW"));
    }
    BY_HANDLE_FILE_INFORMATION info {};
    if (!GetFileInformationByHandle(handle, &info)) {
        const std::string detail = windows_error("GetFileInformationByHandle");
        CloseHandle(handle);
        return IoStatus::failure("path_identity_failed", detail);
    }
    identity = path_identity_from_info(path, handle, info);
    CloseHandle(handle);
#else
    struct stat info {};
    if (::lstat(path.c_str(), &info) != 0) {
        if (errno == ENOENT || errno == ENOTDIR) {
            identity.kind = PathObjectKind::absent;
            return IoStatus::success();
        }
        return IoStatus::failure("path_identity_failed", std::strerror(errno));
    }
    identity = path_identity_from_stat(info);
#endif
    return IoStatus::success();
}

std::filesystem::path path_from_utf8(const std::string& value) { return std::filesystem::u8path(value); }
std::string path_to_utf8(const std::filesystem::path& value) { return value.u8string(); }

// Append inside facman::platform in a private derivative for qualification.
// No read-only input acquires write rights; no rename/security/ADS setter.
namespace {
thread_local void (*retained_stream_rewrite_phase_hook)(const char*) = nullptr;
#ifdef _WIN32
thread_local bool retained_stream_rewrite_flush_fault = false;
bool flush_retained_rewrite(HANDLE handle)
{
    if (retained_stream_rewrite_flush_fault) {
        retained_stream_rewrite_flush_fault = false;
        SetLastError(ERROR_WRITE_FAULT); return false;
    }
    return FlushFileBuffers(handle) != 0;
}
#endif

}

struct RetainedStreamRewriteFile::Impl {
    NativeHandle handle = kInvalidHandle;
    NativeHandle parent = kInvalidHandle;
    FileIdentity original_identity;
    PathIdentity parent_identity;
    std::filesystem::path path, parent_path;
    std::string original, intended;
    RetainedStreamRewriteState state = RetainedStreamRewriteState::original_only;
    ~Impl()
    {
#ifdef _WIN32
        if (handle != kInvalidHandle) CloseHandle(handle);
        if (parent != kInvalidHandle) CloseHandle(parent);
#else
        if (handle != kInvalidHandle) ::close(handle);
        if (parent != kInvalidHandle) ::close(parent);
#endif
    }
};
RetainedStreamRewriteFile::RetainedStreamRewriteFile() : impl_(std::make_unique<Impl>()) {}
RetainedStreamRewriteFile::RetainedStreamRewriteFile(RetainedStreamRewriteFile&&) noexcept = default;
RetainedStreamRewriteFile& RetainedStreamRewriteFile::operator=(RetainedStreamRewriteFile&&) noexcept = default;
RetainedStreamRewriteFile::~RetainedStreamRewriteFile() = default;
bool RetainedStreamRewriteFile::open() const noexcept
{
    return impl_ && impl_->handle != kInvalidHandle;
}

IoStatus RetainedStreamRewriteFile::observe(std::string& bytes, FileIdentity& identity) const
{
    bytes.clear(); identity = {};
#ifdef _WIN32
    if (!open()) return IoStatus::failure("retained_rewrite_not_open", "");
    BY_HANDLE_FILE_INFORMATION parent {}, file {};
    PathIdentity named_parent, named_file;
    if (!GetFileInformationByHandle(impl_->parent, &parent) ||
        !impl_->parent_identity.same_object(path_identity_from_info(impl_->parent_path, impl_->parent, parent)) ||
        !inspect_path_no_follow(impl_->parent_path, named_parent).ok() ||
        named_parent.reparse_or_link || !impl_->parent_identity.same_object(named_parent))
        return IoStatus::failure("retained_rewrite_parent_changed", "Held parent no longer has the original namespace identity");
    if (!GetFileInformationByHandle(impl_->handle, &file))
        return IoStatus::failure("retained_rewrite_identity_failed", windows_error("GetFileInformationByHandle"));
    identity = identity_from_info(file);
    if (!identity.regular_file || identity.link_count != 1U || identity.size > 65536U ||
        !impl_->original_identity.same_object(identity) || (file.dwFileAttributes & FILE_ATTRIBUTE_READONLY) != 0 ||
        !inspect_path_no_follow(impl_->path, named_file).ok() || named_file.reparse_or_link ||
        named_file.kind != PathObjectKind::regular_file || named_file.device != identity.device ||
        named_file.object != identity.object || named_file.size != identity.size)
        return IoStatus::failure("retained_rewrite_identity_changed", "Original stream/file identity or attributes changed");
    bytes.resize(static_cast<std::size_t>(identity.size));
    LARGE_INTEGER offset {};
    DWORD count = 0;
    if (!SetFilePointerEx(impl_->handle, offset, nullptr, FILE_BEGIN) ||
        !ReadFile(impl_->handle, bytes.data(), static_cast<DWORD>(bytes.size()), &count, nullptr) ||
        count != bytes.size()) {
        bytes.clear(); return IoStatus::failure("retained_rewrite_read_failed", windows_error("ReadFile"));
    }
    BY_HANDLE_FILE_INFORMATION after {};
    if (!GetFileInformationByHandle(impl_->handle, &after) || !identity.unchanged(identity_from_info(after))) {
        bytes.clear(); return IoStatus::failure("retained_rewrite_observation_changed", "Held stream changed during read");
    }
    return IoStatus::success();
#else
    return IoStatus::failure("retained_rewrite_unsupported", "Windows-only retained stream capability");
#endif
}

IoStatus StableDirectoryObject::open_child_file_no_follow_for_retained_rewrite(
    const std::filesystem::path& leaf, const FileIdentity& original_identity,
    const std::string& original, const std::string& intended,
    RetainedStreamRewriteState state, RetainedStreamRewriteFile& file) const
{
    std::string name;
    if (!portable_leaf(leaf, name) || !original_identity.regular_file || original_identity.link_count != 1U ||
        original_identity.size != original.size() || original.empty() || intended.empty() ||
        original.size() > 65536U || intended.size() > 65536U || file.open() ||
        !impl_ || !impl_->identity.fixed_local_volume || impl_->identity.filesystem_name != "NTFS")
        return IoStatus::failure("retained_rewrite_admission_invalid", "Bound original/intended stream inputs are invalid");
    const auto valid = revalidate(); if (!valid.ok()) return valid;
#ifdef _WIN32
    RetainedStreamRewriteFile candidate;
    auto status = open_relative_windows(impl_->handle, name,
        GENERIC_READ | GENERIC_WRITE | FILE_READ_ATTRIBUTES, 1, 0x00200040, candidate.impl_->handle, 0);
    if (!status.ok()) return status;
    if (!duplicate_handle(impl_->handle, candidate.impl_->parent))
        return IoStatus::failure("retained_rewrite_parent_duplicate_failed", windows_error("DuplicateHandle"));
    candidate.impl_->path = impl_->path / leaf;
    candidate.impl_->parent_path = impl_->path;
    candidate.impl_->parent_identity = impl_->identity;
    candidate.impl_->original_identity = original_identity;
    candidate.impl_->original = original; candidate.impl_->intended = intended;
    candidate.impl_->state = state;
    std::string observed; FileIdentity current;
    status = candidate.observe(observed, current); if (!status.ok()) return status;
    const bool authorized = state == RetainedStreamRewriteState::original_only ? observed == original :
        state == RetainedStreamRewriteState::mutation_authorized ?
            detail::retained_rewrite_bytes_admissible(original, intended, observed) :
        state == RetainedStreamRewriteState::terminal_verify_only && observed == intended;
    if (!authorized)
        return IoStatus::failure("retained_rewrite_foreign_bytes_preserved", "Observed stream is outside its journal-authorized byte state");
    file = std::move(candidate);
    return IoStatus::success();
#else
    (void)state;
    return IoStatus::failure("retained_rewrite_unsupported", "Windows-only retained stream capability");
#endif
}

IoStatus RetainedStreamRewriteFile::verify_intended() const
{
    std::string observed; FileIdentity current;
    const auto status = observe(observed, current); if (!status.ok()) return status;
    return observed == impl_->intended ? IoStatus::success() :
        IoStatus::failure("retained_rewrite_intended_not_observed", "Held exact stream is not the intended complete effect");
}

IoStatus RetainedStreamRewriteFile::rewrite_to_intended()
{
    if (!open() || impl_->state != RetainedStreamRewriteState::mutation_authorized)
        return IoStatus::failure("retained_rewrite_mutation_not_admitted", "Durable domain pre-write authority is required");
    std::string observed; FileIdentity current;
    const auto admitted = observe(observed, current); if (!admitted.ok()) return admitted;
    if (!detail::retained_rewrite_bytes_admissible(impl_->original, impl_->intended, observed))
        return IoStatus::failure("retained_rewrite_foreign_bytes_preserved", "Held stream is outside its bound byte states");
    if (observed == impl_->intended) {
#ifdef _WIN32
        if (!flush_retained_rewrite(impl_->handle))
            return IoStatus::failure("retained_rewrite_effect_uncertain", "Intended cached bytes could not be flushed; preserve stream and journal");
        return verify_intended();
#else
        return IoStatus::failure("retained_rewrite_unsupported", "Windows-only retained stream capability");
#endif
    }
#ifdef _WIN32
    if (retained_stream_rewrite_phase_hook) retained_stream_rewrite_phase_hook("before_write");
    for (std::size_t written = 0; written < impl_->intended.size();) {
        const auto count = std::min<std::size_t>(4096U, impl_->intended.size() - written);
        LARGE_INTEGER offset {}; offset.QuadPart = static_cast<LONGLONG>(written);
        DWORD actual = 0;
        if (!SetFilePointerEx(impl_->handle, offset, nullptr, FILE_BEGIN) ||
            !WriteFile(impl_->handle, impl_->intended.data() + written, static_cast<DWORD>(count), &actual, nullptr) ||
            actual != count || !flush_retained_rewrite(impl_->handle))
            return IoStatus::failure("retained_rewrite_effect_uncertain", "A prefix write/flush failed; preserve stream and journal");
        written += count;
        if (written < impl_->intended.size() && retained_stream_rewrite_phase_hook)
            retained_stream_rewrite_phase_hook("after_prefix");
    }
    if (retained_stream_rewrite_phase_hook) retained_stream_rewrite_phase_hook("after_write");
    LARGE_INTEGER end {}; end.QuadPart = static_cast<LONGLONG>(impl_->intended.size());
    if (!SetFilePointerEx(impl_->handle, end, nullptr, FILE_BEGIN) ||
        !SetEndOfFile(impl_->handle) || !flush_retained_rewrite(impl_->handle))
        return IoStatus::failure("retained_rewrite_effect_uncertain", "Exact truncation/flush failed; preserve stream and journal");
    if (retained_stream_rewrite_phase_hook) retained_stream_rewrite_phase_hook("after_truncate");
    return verify_intended();
#else
    return IoStatus::failure("retained_rewrite_unsupported", "Windows-only retained stream capability");
#endif
}

namespace testing {
void set_retained_stream_rewrite_phase_hook(void (*hook)(const char*)) { retained_stream_rewrite_phase_hook = hook; }
void set_retained_stream_rewrite_flush_fault(bool enabled)
{
#ifdef _WIN32
    retained_stream_rewrite_flush_fault = enabled;
#else
    (void)enabled;
#endif
}
}

// Additive retained capability methods needed by its durable domain owner.
const std::filesystem::path& RetainedStreamRewriteFile::path() const noexcept
{
    static const std::filesystem::path empty;
    return impl_ ? impl_->path : empty;
}

IoStatus RetainedStreamRewriteFile::admit_durable_mutation()
{
    if (!open() || impl_->state != RetainedStreamRewriteState::original_only)
        return IoStatus::failure("retained_rewrite_admission_invalid", "Only the same held original can be admitted");
    std::string observed; FileIdentity identity;
    const auto status = observe(observed, identity);
    if (!status.ok()) return status;
    if (observed != impl_->original)
        return IoStatus::failure("retained_rewrite_foreign_bytes_preserved", "Original bytes changed before durable admission");
    // The caller must already have persisted its complete domain pre-write phase.
    // This method neither creates that authority nor releases/reopens the file.
    impl_->state = RetainedStreamRewriteState::mutation_authorized;
    return IoStatus::success();
}

IoStatus RetainedStreamRewriteFile::readable_metadata_identity(std::string& identity) const
{
    identity.clear();
#ifdef _WIN32
    if (!open()) return IoStatus::failure("retained_rewrite_not_open", "");
    BY_HANDLE_FILE_INFORMATION file {};
    if (!GetFileInformationByHandle(impl_->handle, &file))
        return IoStatus::failure("retained_rewrite_metadata_unavailable", windows_error("GetFileInformationByHandle"));
    constexpr SECURITY_INFORMATION wanted = OWNER_SECURITY_INFORMATION | GROUP_SECURITY_INFORMATION | DACL_SECURITY_INFORMATION;
    DWORD required = 0;
    if (GetKernelObjectSecurity(impl_->handle, wanted, nullptr, 0, &required) ||
        GetLastError() != ERROR_INSUFFICIENT_BUFFER || required == 0 || required > 65536U)
        return IoStatus::failure("retained_rewrite_metadata_unavailable", "Readable security descriptor is unavailable or exceeds its bound");
    std::vector<unsigned char> descriptor(required);
    DWORD actual = 0;
    if (!GetKernelObjectSecurity(impl_->handle, wanted,
            reinterpret_cast<PSECURITY_DESCRIPTOR>(descriptor.data()), required, &actual) || actual != required)
        return IoStatus::failure("retained_rewrite_metadata_unavailable", windows_error("GetKernelObjectSecurity"));
    // Content writes may change archive/write/access metadata. Do not reset them.
    // Owner/group/DACL, creation and all other readable attributes remain inputs.
    identity = std::to_string(file.ftCreationTime.dwHighDateTime) + ":" +
        std::to_string(file.ftCreationTime.dwLowDateTime) + ":" +
        std::to_string(file.dwFileAttributes & ~static_cast<DWORD>(FILE_ATTRIBUTE_ARCHIVE | FILE_ATTRIBUTE_NORMAL)) + ":";
    constexpr char hex[] = "0123456789abcdef";
    for (const unsigned char byte : descriptor) {
        identity.push_back(hex[byte >> 4]); identity.push_back(hex[byte & 15U]);
    }
    return IoStatus::success();
#else
    return IoStatus::failure("retained_rewrite_unsupported", "Windows-only retained stream capability");
#endif
}

} // namespace facman::platform
