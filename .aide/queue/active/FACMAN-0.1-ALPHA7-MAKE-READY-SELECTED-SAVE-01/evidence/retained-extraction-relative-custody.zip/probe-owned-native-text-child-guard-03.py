"""Real owned child probes for startup audit, failed kill and partial-drain paths."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess,sys,threading,time
from unittest import mock
E=Path(__file__).resolve().parent;W=E.parent;D=E/'legacy-child-guard-fault-probes-03';OUT=E/'legacy-child-guard-fault-probes-03.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
helper_path=E/'owned-native-text-child-custody-02.py'
assert sha(helper_path)=='1994238215a0adfa9c848dd3da39c42d3480b7e7222c6ce77b15eb5df69f2825'
assert not D.exists() and not OUT.exists()
marker=json.loads((W/'.facman-development-root.v1.json').read_text())
assert marker['kind']=='task-root' and Path(marker['canonical_path']).resolve()==W.resolve()
assert W.resolve().is_relative_to(Path(r'D:\Projects\Factorio').resolve())
os.environ['FACMAN_DEV_ROOT']=r'D:\Projects\Factorio\.task-builds'
D.mkdir();original=subprocess.Popen
spec=importlib.util.spec_from_file_location('native_child_guard',helper_path);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
result=dict(status='RUNNING_REAL_OWNED_CHILD_FAULT_PROBES',helper_sha256=sha(helper_path),cases=[],native_product_tests_run=0,builds=0,foreign_processes_changed=False)
worker="import os,sys,time;from pathlib import Path;os.write(1,b'raw stdout\\r\\n');os.write(2,b'raw stderr\\r\\n');Path(sys.argv[-1]).joinpath('ready').write_text('ready');time.sleep(10)"
lock=threading.RLock()
def publish():
 with lock:
  pending=OUT.with_suffix('.pending.json');pending.write_text(json.dumps(result,indent=2)+'\n');os.replace(pending,OUT)
def ready(child,space):
 deadline=time.monotonic()+5
 while not (space/'ready').exists():
  assert child.poll() is None and time.monotonic()<deadline
  time.sleep(.01)
def case(name,kind):
 space=D/name;space.mkdir();streams=space/'streams';streams.mkdir();record={};calls=[0]
 def save():
  calls[0]+=1
  if kind=='constructor' and calls[0]==1:raise OSError('injected constructor receipt write failure')
  (space/'child-record.json').write_text(json.dumps(record,indent=2)+'\n')
 helper.install(sys.executable,space,streams,record,save,limit=.5 if kind=='manual-kill' else 5)
 child=None
 try:
  try:child=subprocess.Popen([sys.executable,'-B','-c',worker,'--workspace',str(space)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8')
  except OSError as error:
   assert kind=='constructor' and 'injected constructor' in str(error)
  if kind=='constructor':
   entry=record['legacy_direct_children'][0]
   assert entry['exit_code'] is not None and entry['status']=='FAILED_DRAINED' and entry['raw_streams_complete']
  else:
   ready(child,space)
   if kind=='normal':
    child.kill();out,err=child.communicate(timeout=2)
    assert out=='raw stdout\r\n'.replace('\r\n','\n') and err=='raw stderr\r\n'.replace('\r\n','\n')
   elif kind=='manual-kill':
    original_kill=original.kill;attempts=[0]
    def denied_once(instance):
     attempts[0]+=1
     if attempts[0]==1:raise OSError('injected manual native kill failure')
     return original_kill(instance)
    with mock.patch.object(original,'kill',denied_once):
     try:child.kill();raise AssertionError('Expected owned kill failure')
     except OSError as error:assert 'injected manual' in str(error)
    assert attempts[0]>=2
   elif kind=='partial-drain':
    original_communicate=original.communicate;attempts=[0]
    def fail_drain(instance,*args,**kwargs):
     attempts[0]+=1
     if attempts[0]==1:
      # Use real pipe bytes; Windows's original thread timeout may return none.
      out=instance.stdout.read(len(b'raw stdout\r\n'));err=instance.stderr.read(len(b'raw stderr\r\n'))
      raise subprocess.TimeoutExpired(instance.args,.1,output=out,stderr=err)
     if attempts[0]==2:raise OSError('injected non-timeout drain failure')
     return original_communicate(instance,*args,**kwargs)
    with mock.patch.object(original,'communicate',fail_drain):
     try:child.communicate(timeout=.1);raise AssertionError('Expected timeout')
     except subprocess.TimeoutExpired:pass
    child.wait(timeout=2);original_communicate(child,timeout=2)
    entry=record['legacy_direct_children'][0]
    assert 'injected non-timeout' in entry['drain_error'] and not entry['raw_streams_complete']
    assert Path(entry['initial_timeout_streams']['stdout']['path']).read_bytes()==b'raw stdout\r\n'
    assert Path(entry['streams']['stdout']['path']).read_bytes()==b'raw stdout\r\n'
    assert Path(entry['streams']['stderr']['path']).read_bytes()==b'raw stderr\r\n'
   assert child.poll() is not None
   entry=record['legacy_direct_children'][0]
   if kind=='manual-kill':assert entry['kill_error'] and entry['deadline_exceeded'] and entry['status']=='FAILED_DRAINED' and entry['raw_streams_complete']
  for category in ('streams','initial_timeout_streams'):
   for item in entry.get(category,{}).values():assert sha(Path(item['path']))==item['sha256']
  result['cases'].append(dict(name=name,status='PASS_EXPECTED_REAL_CHILD_BEHAVIOR',child=entry,constructor_child_terminal=entry['exit_code'] is not None));publish()
 finally:
  subprocess.Popen=original
  if child is not None:
   if child.poll() is None:original.kill(child)
   original.communicate(child,timeout=2)
try:
 for name,kind in [('partial-buffer-drain-failure','partial-drain')]:case(name,kind)
 assert sha(helper_path)==result['helper_sha256']
 prior=E/'legacy-child-guard-fault-probes-02.json';historical=json.loads(prior.read_text());assert historical['status']=='FAILED_RETAINED' and len(historical['cases'])==3
 result['retained_prior_three_passes_receipt_sha256']=sha(prior)
 result.update(status='PASS_REAL_OWNED_CHILD_INITIAL_RAW_BUFFER_WITH_FAILED_DRAIN_PROBE',cases_passed=1,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());publish()
 print(json.dumps({'status':result['status'],'cases':1,'receipt_sha256':sha(OUT)}),flush=True)
except BaseException as error:
 result.update(status='FAILED_RETAINED',error=repr(error));publish();raise
