"""Apply one reviewed archive prerequisite only after actual predecessor acceptance."""
from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
UNIT='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
BRANCH='task/facman-world-restore-retention-01'
P='retained-extraction-admission-08';OUT=E/(P+'.json')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
env=dict(os.environ,FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='0')
record=dict(status='STARTED_GATED_SOURCE_ADMISSION',pid=os.getpid(),commands=[],new_roots=0,new_worktrees=0,new_clones=0,new_candidates=0,
    full_F09_closed=False,full_F11_closed=False,beta_qualified=False,POSIX_qualified=False,source_product_qualification_pending=True)
def save():
    pending=OUT.with_suffix('.pending.json');pending.write_text(json.dumps(record,indent=2)+'\n');os.replace(pending,OUT)
def run(name,args,accepted=(0,)):
    log=E/(P+'-'+name+'.log')
    with log.open('xb') as stream:
        child=subprocess.Popen(args,cwd=R,env=env,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        try:
            record.update(active_pid=child.pid,active_command=name);save()
            child.wait(timeout=600)
        except BaseException:
            if child.poll() is None:
                try:child.kill()
                except BaseException as error:record['owned_child_kill_error']=repr(error)
            try:child.wait(timeout=10)
            except BaseException as error:record['owned_child_drain_error']=repr(error)
            record['status']='STOP_REQUIRES_EXACT_OWNED_DESCENDANT_CENSUS';save();raise
    record['commands'].append(dict(name=name,args=args,exit_code=child.returncode,log=str(log),sha256=sha(log)));save()
    assert child.returncode in accepted,(name,child.returncode,str(log))
    return log.read_text(encoding='utf-8').rstrip('\r\n')
def git(*args):
    return subprocess.check_output(['git',*args],cwd=R,env=env,text=True).rstrip('\r\n')
assert __debug__ and not OUT.exists() and not git('status','--porcelain')
# No wait loop and no predecessor replay: missing/unfinished receipts stop before mutations.
completion=read(E/'existing-configuration-py311-postintegration-completion.json')
controller=read(E/'existing-configuration-py311-controller-06.json')
proof_path=E/'produced-existing-configuration-proof-06.json';proof=read(proof_path)
actual_path=E/'produced-existing-configuration-acceptance-review-06.json';actual=read(actual_path)
private_path=E/'retained-extraction-public-owner-private-02.json';private=read(private_path)
private_review_path=E/'retained-extraction-public-owner-acceptance-review-02.json';private_review=read(private_review_path)
proposal_path=E/'retained-extraction-relative-proposal-05.json';proposal=read(proposal_path)
patch=E/'retained-extraction-relative-proposal-05/correction.patch'
admission_path=E/'retained-extraction-source-admission-review-08.json';admission=read(admission_path)
assert controller['status']=='integrated_synchronized_produced_pass_requires_independent_acceptance'
assert controller['proof_sha256']==sha(proof_path)
assert proof['status']=='PASS_EXACT_PRODUCED_WINDOWS_EXISTING_CONFIGURATION'
assert actual['verdict']=='PASS' and actual['independent'] and actual['non_authoring']
assert actual['proof_sha256']==sha(proof_path)
assert private['status']=='FAILED_RETAINED' and private['error']=='AssertionError()'
assert private['tests_run']==17 and private['skipped']==1
assert private_review['acceptance_status']=='PRIVATE_CALLER_COMPATIBILITY_PARTIAL_WITH_EXPLICIT_HOST_AND_UNEXECUTED_CELLS'
assert private_review['tests']['fully_passing_methods']==16 and private_review['tests']['aborted_partial_methods']==1
assert private_review['tests']['failures']==private_review['tests']['errors']==0
assert private_review['tests']['reported_skipped_subcases']==1 and private_review['tests']['additional_unexecuted_subcases']==3
assert private_review['tests']['recorded_invoke_calls']==305 and private_review['tests']['recorded_raw_streams_verified']==610
assert private_review['source_admission_decision']['approve_bounded_F11_source_qualification_with_partial_private_compatibility'] is True
assert 'WinError 1314' in (E/'retained-extraction-public-owner-private-02/tests.log').read_text()
assert private_review['test_log_sha256']==sha(E/'retained-extraction-public-owner-private-02/tests.log')
assert private_review['supplemental_final_custody_sha256']==sha(E/'retained-extraction-public-owner-final-custody-02.json')
narrow_path=E/'retained-extraction-marker-cells-private-05.json';narrow=read(narrow_path)
narrow_review_path=E/'retained-extraction-marker-cells-acceptance-review-05.json';narrow_review=read(narrow_review_path)
assert narrow['status']=='PASS_PRIVATE_TWO_PREVIOUSLY_UNEXECUTED_FOREIGN_MARKER_CELLS'
assert narrow['tests_run']==1 and narrow['skipped']==0 and narrow['new_links']==0
assert narrow['parent_private_result_sha256']==sha(private_path)
assert narrow['selected_subcases']==[dict(point=p,substitution='foreign_bytes') for p in ('published','committed')]
assert narrow['retained_host_gaps']==['published dangling_symlink','committed dangling_symlink']
assert narrow_review['verdict']=='PASS' and narrow_review['independent'] and narrow_review['non_authoring']
assert narrow_review['proof_sha256']==sha(narrow_path)
assert len(narrow['legacy_direct_children'])==2
assert all(x['status']=='TERMINAL' and not x['deadline_exceeded'] and not x['kill_error'] and 'drain_error' not in x for x in narrow['legacy_direct_children'])
assert sha(E/'retained-extraction-corrected-private-proof-04.json')=='b8fed5b8efd78233616d7b2abc92fe3b2d52217d0fc0cb42bc586179063a6951'
assert sha(E/'retained-extraction-corrected-private-acceptance-review-01.json')=='3490f9899399668bc2719e80c0849e0d09de692f7d1ff375908261033a3cc48f'
assert sha(E/'retained-extraction-maintained-smoke-02.json')=='2bb8a2546cd3ba440288896feba415105b6cbe5b14ae0eb7aeb34b52ac0fe7c6'
assert sha(E/'retained-extraction-maintained-smoke-acceptance-review-02.json')=='03f1f6af255f4fa99d433342ce5fc638d7df6ed7fced8cc05b58a66d6f6ec720'
assert private_review['verdict']=='PASS' and private_review['independent'] and private_review['non_authoring']
assert private_review['proof_sha256']==sha(private_path)
assert admission['verdict']=='PASS' and admission['independent'] and admission['non_authoring']
assert admission['approve_bounded_F11_archive_prerequisite'] is True
assert admission['script_sha256']==sha(Path(__file__)) and admission['proposal_sha256']==sha(proposal_path)
assert sha(patch)==proposal['patch_sha256']
assert completion['source']=='353c007cd933e518e59551d54a52dfe5b27d53b3'
assert completion['status']=='reviewed_existing_configuration_integrated_and_clean_primaries_synchronized'
assert completion['task_refs_retired'] is True and completion['unique_work_deleted'] is False
marker=read(W/'.facman-development-root.v1.json')
assert marker['kind']=='task-root' and Path(marker['source_root']).resolve()==R.resolve()
assert Path(marker['canonical_path']).resolve()==W.resolve() and W.resolve().is_relative_to(Path(r'D:\Projects\Factorio').resolve())
try:
    save()
    run('paths',['py','-3','tools/workspace_hygiene.py','paths'])
    resources=json.loads(run('doctor',['py','-3','tools/workspace_hygiene.py','doctor','--measure'],accepted=(0,1)))
    assert set(resources['violations'])<={'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
    assert len(resources['task_roots'])<=8 and resources['task_root_bytes']+64*1024**2+2*1024**3<20*1024**3
    assert shutil.disk_usage(W).free>=10*1024**3+64*1024**2
    for relative,binding in proposal['source_paths'].items():assert sha(R/relative)==binding['original_sha256']
    assert git('branch','--show-current')=='dev' and git('rev-parse','HEAD')==completion['facman_dev']
    assert git('status','--porcelain')==''
    identity=run('identity',['powershell','-NoProfile','-Command','[System.Security.Principal.WindowsIdentity]::GetCurrent().Name'])
    assert identity.casefold()==r'BLACKGLASS-WIN1\Jules'.casefold()
    run('auth',['gh','auth','status']);assert run('account',['gh','api','user','--jq','.login'])=='Julesc013'
    run('fresh-dev',['git','fetch','origin','dev'])
    assert git('rev-parse','HEAD')==git('rev-parse','origin/dev'),'A newer integrated target requires explicit requalification of scoped source'
    record.update(base=git('rev-parse','HEAD'),base_tree=git('rev-parse','HEAD^{tree}'),proposal_sha256=sha(proposal_path),
        predecessor_completion_sha256=sha(E/'existing-configuration-py311-postintegration-completion.json'),
        predecessor_actual_produced_acceptance_sha256=sha(actual_path),private_caller_proof_sha256=sha(private_path),
        private_caller_acceptance_sha256=sha(private_review_path),missing_available_cells_proof_sha256=sha(narrow_path),missing_available_cells_acceptance_sha256=sha(narrow_review_path),
        retained_host_gaps=narrow['retained_host_gaps'],all17_zero_skip_qualification=False,independent_admission_sha256=sha(admission_path));save()
    task_path=R/'.aide/queue/active'/UNIT/'task.yaml';task_text=task_path.read_text()
    assert 'status: active' in task_text and '  - "runtime/**"' in task_text and '  - "tests/**"' in task_text
    for name in ('inspect','noop-check','recover'):
        run('task-'+name,['py','-3','.aide/scripts/aide_lite.py','task',name,'--task-id',UNIT])
    for name in ('policy','detect','plan'):
        run('git-'+name,['py','-3','.aide/scripts/aide_lite.py','git',name])
    assert not git('for-each-ref','--format=%(refname)','refs/heads/'+BRANCH,'refs/remotes/origin/'+BRANCH)
    assert git('status','--porcelain')=='' and git('branch','--show-current')=='dev'
    for relative,binding in proposal['source_paths'].items():assert sha(R/relative)==binding['original_sha256']
    assert sha(patch)==proposal['patch_sha256'] and sha(Path(__file__))==admission['script_sha256']
    run('apply-check',['git','apply','--check',str(patch)])
    assert git('rev-parse','HEAD')==record['base']==completion['facman_dev']==git('rev-parse','origin/dev')
    record['branch_plan']=dict(exact_base=record['base'],target='origin/dev',task_branch=BRANCH,new_secondary_worktree=False,predecessor_refs_retired=True,dirty_paths=[],operator_authority='Standing explicit go/commit/normal checked merge/synchronize instruction');save()
    record.update(status='APPLYING_REVIEWED_ARCHIVE_PREREQUISITE',operator_authority='Standing user instruction: implement, commit, checked merge, synchronize and keep going.',branch=BRANCH);save()
    assert git('status','--porcelain')=='' and git('branch','--show-current')=='dev'
    assert git('rev-parse','HEAD')==record['base']==completion['facman_dev']==git('rev-parse','origin/dev')
    run('branch',['git','switch','-c',BRANCH,record['base']])
    assert git('branch','--show-current')==BRANCH and git('rev-parse','HEAD')==record['base']
    assert not git('status','--porcelain')
    for relative,binding in proposal['source_paths'].items():assert sha(R/relative)==binding['original_sha256']
    run('apply',['git','apply',str(patch)])
    assert git('branch','--show-current')==BRANCH and git('rev-parse','HEAD')==record['base']
    for relative,binding in proposal['source_paths'].items():assert sha(R/relative)==binding['proposed_sha256']
    plan=R/'.aide/queue/active'/UNIT/'ExecPlan.md'
    with plan.open('ab') as stream:
        stream.write(b'\n2026-10-10 bounded Content reconstruction prerequisite: repair retained archive namespace creation using exclusive held-parent operations. The actual legacy foreign-root adoption failure, exact Windows private adversarial proof, maintained native regression and16 fully passing private public caller methods plus two recovered foreign-marker cells are preserved. Original17-method run had one host skip and failfast-aborted cells; both dangling-symlink cells remain host-unqualified. Current source/merge CI and produced consumers remain mandatory. Strict UTF8 conversion supports existing admitted filenames while the conservative portable API remains unchanged. This fresh-dev slice requires current source/merge CI and artifact qualification; POSIX uncooperative namespace writers, partial-extraction resumption, original F09 task admission/closure, full Make Ready, real game, human and Beta gates remain open. No cloned repository, new task root, worktree, optional candidate or provider-pin update.\n')
    changed={line[3:] for line in git('-c','core.quotePath=false','status','--porcelain','--untracked-files=all').splitlines()}
    expected=set(proposal['source_paths'])|{plan.relative_to(R).as_posix()}
    assert changed==expected
    record.update(status='APPLIED_EXACT_REVIEWED_SOURCE_REQUIRES_SOURCE_QUALIFICATION',changed_paths={p:sha(R/p) for p in sorted(expected)},active_pid=None,active_command=None,
        finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
    print(json.dumps({'status':record['status'],'paths':len(expected),'base':record['base']}),flush=True)
except BaseException as error:
    record.update(status=record['status'] if record['status'].startswith('STOP_') else 'ACTIONABLE_STOP_PRESERVE_SOURCE',error=repr(error));save();raise
