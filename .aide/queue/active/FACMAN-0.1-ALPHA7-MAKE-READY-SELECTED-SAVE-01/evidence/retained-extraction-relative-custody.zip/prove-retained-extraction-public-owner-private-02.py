"""Relink a private diagnostic CLI from qualified cached inputs; exercise real import owners."""
from pathlib import Path
import ast,datetime,hashlib,importlib,json,os,re,shutil,subprocess,sys,tempfile,time,unittest
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent;B=W/'native-developer'
D=E/'retained-extraction-public-owner-private-02';OUT=E/'retained-extraction-public-owner-private-02.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).rstrip('\r\n')
assert __debug__ and not OUT.exists() and not D.exists() and not git('status','--porcelain')
marker=json.loads((W/'.facman-development-root.v1.json').read_text())
assert marker['kind']=='task-root' and Path(marker['canonical_path']).resolve()==W.resolve()
assert Path(marker['source_root']).resolve()==R.resolve() and W.resolve().is_relative_to(Path(r'D:\Projects\Factorio').resolve())
smoke_path=E/'retained-extraction-maintained-smoke-02.json';smoke=json.loads(smoke_path.read_text())
acceptance_path=E/'retained-extraction-maintained-smoke-acceptance-review-02.json';acceptance=json.loads(acceptance_path.read_text())
assert smoke['status']=='PASS_PRIVATE_MAINTAINED_NATIVE_SMOKE'
assert acceptance['verdict']=='PASS' and acceptance['independent'] and acceptance['non_authoring']
assert sha(smoke_path) in json.dumps(acceptance),'Actual maintained-smoke receipt must be bound by acceptance'
proposal=json.loads((E/'retained-extraction-relative-proposal-05.json').read_text())
for relative,binding in proposal['source_paths'].items():assert sha(R/relative)==binding['original_sha256']
original_cli=B/'Release/facman.exe'
assert sha(original_cli)==json.loads((E/'existing-configuration-py311-qualification-01.json').read_text())['CLI_sha256']
link_record=B/'apps/cli/facman_cli.dir/Release/facman_cli.tlog/link.command.1.tlog'
recipe=link_record.read_text(encoding='utf-16')
rows=recipe.splitlines();assert rows[0].startswith('^')
objects=[Path(p) for p in rows[0][1:].split('|')]
assert len(objects)==8 and all(p.resolve().is_relative_to(B.resolve()) and p.is_file() for p in objects)
# Dependencies precede linker options; /IMPLIB names an OUTPUT, never an input.
assert rows[1].count(' /MANIFEST ')==1
library_segment=rows[1].split(' /MANIFEST ',1)[0]
assert '/IMPLIB:' not in library_segment
libraries=re.findall(r'(?:\.\.\\\.\.\\RELEASE\\[A-Z0-9_]+\.LIB|(?<![A-Z0-9_\\])[A-Z0-9_]+\.LIB)',library_segment)
assert 'FACMAN.LIB' not in libraries
assert len(libraries)>=40 and any('FLB_FACTORIO_STATIC' in p for p in libraries)
native_libraries=[B/'Release'/Path(p).name for p in libraries if p.startswith('..')]
system_libraries=[p for p in libraries if not p.startswith('..')]
assert all(p.is_file() for p in native_libraries)
private_objects=[E/'retained-extraction-maintained-smoke-02'/name for name in ('fl_archive_retained_extraction.obj','fl_file_io.obj')]
assert all(p.is_file() for p in private_objects)
donor_files=list(dict.fromkeys([*objects,*native_libraries,*private_objects,B/'Release/ulk.dll',B/'Release/usk.dll']))
donor_hashes={str(p):sha(p) for p in donor_files}
source_files=['tests/test_portable_modpack_import.py','tests/test_presentation_pack_import.py',
    'tests/test_local_modset_solver.py','tests/native_cli.py','runtime/factorio/modsets/flb_factorio_modpack_import.cpp',
    'runtime/transaction/fl_transaction_pack_import.cpp','apps/cli/facman.manifest']
source_hashes={p:sha(R/p) for p in source_files}
fixture=R/'tests/fixtures/fake_factorio_install'
inventory=lambda root:{p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file()}
fixture_before=inventory(fixture)
D.mkdir();temporary=D/'temporary';temporary.mkdir();streams=D/'commands';streams.mkdir()
env=dict(os.environ,FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='0',
    TEMP=str(temporary),TMP=str(temporary),PATH=str(B/'Release')+os.pathsep+os.environ.get('PATH',''))
for key in list(env):
    if key.startswith('FACMAN_TEST_'):env.pop(key)
record=dict(status='STARTED_PRIVATE_PUBLIC_OWNER',pid=os.getpid(),source_head=git('rev-parse','HEAD'),
    maintained_smoke_sha256=sha(smoke_path),actual_acceptance_sha256=sha(acceptance_path),
    link_recipe_sha256=sha(link_record),input_files_sha256=donor_hashes,source_files_sha256=source_hashes,
    fixture_input_sha256=fixture_before,
    proposal_sha256=sha(E/'retained-extraction-relative-proposal-05.json'),commands=[],
    new_task_roots=0,new_clones=0,new_worktrees=0,new_candidates=0,product_source_mutated=False,
    full_cached_build_repeated=False,private_link_only=True,produced_package_qualified=False,
    public_checkout_product_qualified=False,full_F09_qualified=False,POSIX_qualified=False,real_game_qualified=False)
def save():
    pending=OUT.with_suffix('.pending.json');pending.write_text(json.dumps(record,indent=2)+'\n');os.replace(pending,OUT)
def command(name,args,timeout,child_env=None,accepted=(0,)):
    log=D/(name+'.log')
    with log.open('xb') as stream:
        child=subprocess.Popen(args,cwd=D,env=child_env or env,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        record.update(active_pid=child.pid,active_command=name);save()
        try:child.wait(timeout=timeout)
        except BaseException:
            if child.poll() is None:child.kill()
            child.wait(timeout=10);record['status']='STOP_REQUIRES_EXACT_DESCENDANT_CENSUS';save();raise
    record.setdefault('setup_commands',[]).append(dict(name=name,args=args,exit_code=child.returncode,log=str(log),log_sha256=sha(log)));save()
    assert child.returncode in accepted,(name,child.returncode,str(log))
    return log
save()
try:
    command('paths',['py','-3',str(R/'tools/workspace_hygiene.py'),'paths'],180)
    doctor=command('doctor',['py','-3',str(R/'tools/workspace_hygiene.py'),'doctor','--measure'],600,accepted=(0,1))
    resources=json.loads(doctor.read_text());record['resources']=resources;save()
    assert set(resources['violations'])<={'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
    assert len(resources['task_roots'])<=8 and resources['task_root_bytes']+64*1024**2+2*1024**3<20*1024**3
    assert shutil.disk_usage(W).free>=10*1024**3+64*1024**2
    # Reuse the actual resource-admission function, without invoking its build.
    census_source=(E/'qualify-retained-extraction-maintained-smoke-02.py').read_text()
    census_match=re.search(r'    census_script=(""".*?""")',census_source,re.S);assert census_match
    census_script=ast.literal_eval(census_match.group(1))
    def census():
        result=subprocess.run(['powershell','-NoProfile','-Command',census_script],capture_output=True,text=True,timeout=30)
        assert result.returncode==0
        rows=json.loads(result.stdout) if result.stdout.strip() else []
        return [rows] if isinstance(rows,dict) else rows
    deadline=time.monotonic()+1800
    while True:
        first=census();time.sleep(2);second=census();old={p['pid']:p for p in first};active=[];ignored=[]
        for p in second:
            previous=old.get(p['pid'])
            if previous and p['name'].lower()=='msbuild.exe' and not p['parent_live'] and not previous['parent_live'] and \
                '/nodemode:1' in (p['command'] or '') and '/nodeReuse:true' in (p['command'] or '') and \
                p['created']==previous['created'] and p['cpu']==previous['cpu']:ignored.append(p)
            else:active.append(p)
        record['resource_census']=dict(first=first,second=second,active=active,idle_orphans_preserved=ignored);save()
        if not active:break
        assert time.monotonic()<deadline,'Resource deadline: preserve foreign work'
        time.sleep(15)
    assert {str(p):sha(p) for p in donor_files}==donor_hashes
    compiler_directory=Path(r'C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.51.36231\bin\Hostx64\x64')
    vc=Path(r'C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Auxiliary\Build\vcvars64.bat')
    setup=D/'linker-environment.cmd'
    setup.write_text('@echo off\ncall "'+str(vc)+'" >nul\nif errorlevel 1 exit /b 1\nset LIB\nset PATH\n',encoding='utf-8')
    configured=subprocess.run(['cmd','/d','/c',str(setup)],capture_output=True,text=True,env=env,timeout=30)
    assert configured.returncode==0;link_env=dict(env)
    for row in configured.stdout.splitlines():
        if '=' in row:
            key,value=row.split('=',1)
            if key.upper() in {'LIB','LIBPATH','PATH'}:link_env[key]=value
    cli=D/'facman.exe';mapping=D/'facman.map'
    args=[str(compiler_directory/'link.exe'),'/NOLOGO','/OUT:'+str(cli),'/INCREMENTAL:NO','/SUBSYSTEM:CONSOLE',
        '/MACHINE:X64','/DYNAMICBASE','/NXCOMPAT','/GUARD:CF','/BREPRO','/MANIFEST:EMBED',
        '/MANIFESTINPUT:'+str(R/'apps/cli/facman.manifest'),'/MAP:'+str(mapping),
        *map(str,objects),*map(str,private_objects),*map(str,native_libraries),*system_libraries]
    command('private-link',args,120,link_env)
    map_text=mapping.read_text(errors='replace')
    assert 'extract_verified_to_new_retained_staging' in map_text
    assert 'create_child_directory_exclusive_utf8' in map_text
    record.update(executable=str(cli),executable_sha256=sha(cli),link_map_sha256=sha(mapping));save()
    for key in list(os.environ):
        if key.startswith('FACMAN_TEST_'):os.environ.pop(key)
    os.environ.update(env,FACMAN_CLI_EXE=str(cli),FACMAN_NATIVE_BUILD_ROOT=str(B),FACMAN_NATIVE_CONFIGURATION='Release')
    tempfile.tempdir=str(temporary);sys.path[:0]=[str(R/'tests'),str(R)]
    original_temporary=tempfile.TemporaryDirectory
    class OwnedTemporaryDirectory(original_temporary):
        def __init__(self,*args,**kwargs):
            kwargs['dir']=str(temporary);kwargs['delete']=False;super().__init__(*args,**kwargs)
            assert Path(self.name).resolve().is_relative_to(temporary.resolve())
        def __exit__(self,kind,error,traceback):
            if kind is None:self.cleanup()
            else:record.setdefault('preserved_failed_workspaces',[]).append(dict(path=self.name,error=repr(error)));save()
            return False
    tempfile.TemporaryDirectory=OwnedTemporaryDirectory
    modules=[importlib.import_module(name) for name in ('native_cli','test_local_modset_solver','test_portable_modpack_import','test_presentation_pack_import')]
    native=modules[0];old_invoke=native.invoke_machine
    original_run=subprocess.run
    def bounded_run(args,*positional,**kwargs):
        if isinstance(args,(list,tuple)) and args and Path(str(args[0])).resolve()==cli.resolve():
            assert '--workspace' in args
            workspace=Path(str(args[args.index('--workspace')+1])).resolve()
            assert workspace.is_relative_to(temporary.resolve())
            kwargs['timeout']=min(kwargs.get('timeout',45),45)
        return original_run(args,*positional,**kwargs)
    subprocess.run=bounded_run
    def invoke(args,env=None):
        assert '--workspace' in args
        workspace=Path(args[args.index('--workspace')+1]).resolve()
        assert workspace.is_relative_to(temporary.resolve())
        index=len(record['commands'])+1;entry=dict(index=index,argv=[str(cli),*args],status='RUNNING');record['commands'].append(entry);save()
        started=time.monotonic();out=b'';err=b'';failure=None
        process=subprocess.Popen(entry['argv'],cwd=R,env=dict(os.environ) if env is None else env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=subprocess.CREATE_NO_WINDOW)
        entry['pid']=process.pid;save()
        try:out,err=process.communicate(timeout=45)
        except BaseException as error:
            failure=error
            if process.poll() is None:process.kill()
            try:out,err=process.communicate(timeout=10)
            except BaseException as drain:entry['drain_error']=repr(drain)
        finally:
            entry['streams']={}
            for name,data in [('stdout',out),('stderr',err)]:
                path=streams/(f'{index:04d}.'+name)
                with path.open('xb') as f:f.write(data)
                entry['streams'][name]=dict(path=str(path),sha256=sha(path),bytes=len(data))
            entry.update(status='FAILED_PROCESS' if failure else 'TERMINAL',exit_code=process.poll(),seconds=round(time.monotonic()-started,3));save()
        if failure:raise failure
        return process.returncode,out.decode('utf-8'),err.decode('utf-8')
    for module in modules:
        for name,value in list(vars(module).items()):
            if value is old_invoke:setattr(module,name,invoke)
    portable=modules[2].PortableModpackImportTests;presentation=modules[3].PresentationPackImportTests
    selected=[(portable,n) for n in vars(portable) if n.startswith('test_')]+[(presentation,n) for n in vars(presentation)
        if n.startswith('test_') and n!='test_compiled_content_entry_preserves_inputs_and_adopts_returned_selection']
    assert len(selected)==17
    record.update(status='RUNNING_PRIVATE_PUBLIC_OWNER_TESTS',selected_methods=[c.__name__+'.'+n for c,n in selected],
        excluded_method='Compiled C1 harness retained as separate existing qualification; this private actor runs public runtime owners only.');save()
    with (D/'tests.log').open('x',encoding='utf-8') as stream:
        result=unittest.TextTestRunner(stream=stream,verbosity=2,failfast=True).run(unittest.TestSuite(c(n) for c,n in selected))
    record.update(test_log_sha256=sha(D/'tests.log'),tests_run=result.testsRun,skipped=len(result.skipped));save()
    assert result.wasSuccessful() and result.testsRun==17 and not result.skipped
    assert {str(p):sha(p) for p in donor_files}==donor_hashes
    assert {p:sha(R/p) for p in source_files}==source_hashes
    assert inventory(fixture)==fixture_before
    for relative,binding in proposal['source_paths'].items():assert sha(R/relative)==binding['original_sha256']
    assert sha(cli)==record['executable_sha256'] and not git('status','--porcelain')
    record.update(status='PASS_PRIVATE_PUBLIC_PACK_IMPORT_OWNERS',commands_total=len(record['commands']),
        source_head_after=git('rev-parse','HEAD'),active_pid=None,active_command=None,
        finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
    print(json.dumps(dict(status=record['status'],methods=17,skipped=0,commands=len(record['commands']),receipt_sha256=sha(OUT))),flush=True)
except BaseException as error:
    record.update(status=record['status'] if record['status'].startswith('STOP_') else 'FAILED_RETAINED',error=repr(error));save();raise
