"""Bind an admitted checkout to accepted exact-byte private evidence; no rebuild."""
from pathlib import Path
import dataclasses, datetime, hashlib, json, os, shutil, subprocess, sys, zipfile

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
W = E.parent
P = 'retained-extraction-source-packet-03'
OUT = E / (P + '.json')
UNIT = 'FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
BRANCH = 'task/facman-world-restore-retention-01'
PREDECESSOR = '353c007cd933e518e59551d54a52dfe5b27d53b3'
env = dict(os.environ, FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',
           PYTHONDONTWRITEBYTECODE='1', PYTHONOPTIMIZE='0')
os.environ.update(env)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
record = dict(status='STARTED_GATED_SOURCE_PACKET', commands=[], new_builds=0,
              new_roots=0, new_worktrees=0, new_clones=0, new_candidates=0)

def save():
    pending = OUT.with_suffix('.pending.json')
    pending.write_text(json.dumps(record, indent=2) + '\n')
    os.replace(pending, OUT)

def write(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def run(name, args, accepted=(0,)):
    log = E / (P + '-' + name + '.log')
    with log.open('xb') as stream:
        child = subprocess.Popen(args, cwd=R, env=env, stdout=stream,
                                 stderr=subprocess.STDOUT,
                                 creationflags=subprocess.CREATE_NO_WINDOW)
        try:
            record.update(active_pid=child.pid, active_command=name)
            save()
            child.wait(timeout=900)
        except BaseException:
            if child.poll() is None:
                try:
                    child.kill()
                except BaseException as error:
                    record['owned_child_kill_error'] = repr(error)
            try:
                child.wait(timeout=10)
            except BaseException as error:
                record['owned_child_drain_error'] = repr(error)
            record['status'] = 'STOP_REQUIRES_EXACT_OWNED_DESCENDANT_CENSUS'
            save()
            raise
    record['commands'].append(dict(name=name, args=args, exit_code=child.returncode,
                                   log=str(log), log_sha256=sha(log)))
    record.update(active_pid=None, active_command=None)
    save()
    assert child.returncode in accepted, (name, child.returncode, str(log))
    return log.read_text(encoding='utf-8').rstrip('\r\n')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=R, env=env, text=True,
                                   encoding='utf-8', timeout=60).rstrip('\r\n')

assert __debug__ and not OUT.exists()
marker = read(W / '.facman-development-root.v1.json')
assert marker['kind'] == 'task-root'
assert Path(marker['source_root']).resolve() == R.resolve()
assert Path(marker['canonical_path']).resolve() == W.resolve()
assert W.resolve().is_relative_to(Path(r'D:\Projects\Factorio').resolve())
review = read(E / 'retained-extraction-source-packet-driver-review-03.json')
assert review['verdict'] == 'PASS' and review['independent'] and review['non_authoring']
assert review['script_sha256'] == sha(Path(__file__))
assert review['approve_prepare_exact_source_packet'] is True
admission = read(E / 'retained-extraction-admission-08.json')
assert admission['status'] == 'APPLIED_EXACT_REVIEWED_SOURCE_REQUIRES_SOURCE_QUALIFICATION'
assert git('branch', '--show-current') == BRANCH and git('rev-parse', 'HEAD') == admission['base']
assert not git('diff', '--cached', '--name-only')
# A tree match binds all cached caller/provider inputs to this integrated source.
# Changed target source requires requalification instead of silently reusing proof.
assert git('rev-parse', 'HEAD^{tree}') == git('rev-parse', PREDECESSOR + '^{tree}')
proposal_path = E / 'retained-extraction-relative-proposal-05.json'
proposal = read(proposal_path)
assert sha(proposal_path) == admission['proposal_sha256']
plan = R / '.aide/queue/active' / UNIT / 'ExecPlan.md'
expected = set(proposal['source_paths']) | {plan.relative_to(R).as_posix()}
changed = lambda: {line[3:] for line in git('-c', 'core.quotePath=false', 'status',
                    '--porcelain', '--untracked-files=all').splitlines()}
assert changed() == expected
assert {p: sha(R / p) for p in expected} == admission['changed_paths']
for p, binding in proposal['source_paths'].items():
    assert sha(R / p) == binding['proposed_sha256']
fixed = {
    'retained-extraction-legacy-gap-02.json': 'c1e9e975f01b0129058fff42e25b368c52acf9f68aa38d789e39894ada693274',
    'retained-extraction-corrected-private-proof-04.json': 'b8fed5b8efd78233616d7b2abc92fe3b2d52217d0fc0cb42bc586179063a6951',
    'retained-extraction-corrected-private-acceptance-review-01.json': '3490f9899399668bc2719e80c0849e0d09de692f7d1ff375908261033a3cc48f',
    'retained-extraction-maintained-smoke-02.json': '2bb8a2546cd3ba440288896feba415105b6cbe5b14ae0eb7aeb34b52ac0fe7c6',
    'retained-extraction-maintained-smoke-acceptance-review-02.json': '03f1f6af255f4fa99d433342ce5fc638d7df6ed7fced8cc05b58a66d6f6ec720',
    'retained-extraction-public-owner-private-02.json': 'c504fe4954fa56b34487febffb4fffdf6c8e958249b9da79eb0a1de0fc40013a',
    'retained-extraction-public-owner-final-custody-02.json': 'd5cee2b49661e69299ce7c83299e3f7635cec0fdda3b288ac935cb659cbb3cb1',
    'retained-extraction-public-owner-acceptance-review-02.json': 'dfcb3d7de53ab88f37c6abcb599ede402f416771d3ffa077a4405f62d48364ac',
    'retained-extraction-marker-cells-private-05.json': 'c9a78d30b9945b30503d75b3e7efa417a7184e10c3a7ab9f63424fe2d74617b7',
    'legacy-child-guard-fault-probes-acceptance-review-03.json': '282766d7a545ad3dc6eaa5bde0100329aa7cfc04efec37418899f01a1d3dacd4',
}
for name, digest in fixed.items():
    assert sha(E / name) == digest
narrow = read(E / 'retained-extraction-marker-cells-private-05.json')
actual_path = E / 'retained-extraction-marker-cells-acceptance-review-05.json'
actual = read(actual_path)
assert actual['verdict'] == 'PASS' and actual['independent'] and actual['non_authoring']
assert actual['proof_sha256'] == fixed['retained-extraction-marker-cells-private-05.json']
assert narrow['status'] == 'PASS_PRIVATE_TWO_PREVIOUSLY_UNEXECUTED_FOREIGN_MARKER_CELLS'
assert narrow['tests_run'] == 1 and narrow['skipped'] == narrow['new_links'] == 0
assert len(narrow['legacy_direct_children']) == 2
assert all(c['status'] == 'TERMINAL' and c['raw_streams_complete'] and
           not c['deadline_exceeded'] and not c['kill_error'] and
           'drain_error' not in c for c in narrow['legacy_direct_children'])
public = read(E / 'retained-extraction-public-owner-private-02.json')
assert public['status'] == 'FAILED_RETAINED' and public['tests_run'] == 17 and public['skipped'] == 1
for p, digest in public['source_files_sha256'].items():
    assert sha(R / p) == digest
for p, digest in public['input_files_sha256'].items():
    assert sha(Path(p)) == digest
for p, digest in public['fixture_input_sha256'].items():
    assert sha(R / 'tests/fixtures/fake_factorio_install' / p) == digest

members = {}
def add(path, digest=None, size=None):
    path = Path(path).resolve()
    assert path.is_relative_to(E.resolve()), path
    assert path.suffix.lower() not in {'.exe', '.dll', '.lib', '.obj', '.pdb'}, path
    value = sha(path)
    if digest is not None:
        assert value == digest, path
    if size is not None:
        assert path.stat().st_size == size, path
    name = path.relative_to(E).as_posix()
    assert name not in members or members[name]['sha256'] == value
    members[name] = dict(path=path, sha256=value, bytes=path.stat().st_size)

for name in fixed:
    add(E / name, fixed[name])
for name in ('retained-extraction-legacy-gap-acceptance-review-01.json',
             'retained-extraction-relative-proposal-02.json',
             'retained-extraction-relative-proposal-05.json',
             'retained-extraction-regression-proposal-review-05.json',
             'retained-extraction-admission-08.json',
             'retained-extraction-source-admission-review-08.json',
             'retained-extraction-marker-cells-private-driver-review-05.json',
             'retained-extraction-marker-cells-acceptance-review-05.json',
             'legacy-child-guard-fault-probes-02.json', 'legacy-child-guard-fault-probes-03.json',
             'probe-owned-native-text-child-guard-02.py', 'probe-owned-native-text-child-guard-03.py',
             'owned-native-text-child-custody-02.py',
             'prove-retained-extraction-public-owner-private-02.py',
             'prove-retained-extraction-marker-cells-private-05.py',
             'qualify-retained-extraction-maintained-smoke-02.py',
             'apply-retained-extraction-from-qualified-dev-08.py',
             'retained-extraction-source-packet-driver-review-03.json'):
    add(E / name)
add(Path(__file__))
add(E / 'retained-extraction-relative-proposal-05/correction.patch', proposal['patch_sha256'])
for p, binding in proposal['source_paths'].items():
    donor = E / ('retained-extraction-relative-proposal-05' if p.startswith('tests/')
                 else 'retained-extraction-relative-proposal-02') / Path(p).name
    add(donor, binding['proposed_sha256'])
for proof_name in ('retained-extraction-legacy-gap-02.json',
                   'retained-extraction-corrected-private-proof-04.json'):
    proof = read(E / proof_name)
    compile_step = next(c for c in proof['commands'] if c['name'] == 'compile')
    cpp_inputs = [Path(a) for a in compile_step['args'] if a.lower().endswith('.cpp')]
    assert len(cpp_inputs) >= 2
    add(cpp_inputs[0], proof['harness_sha256'])
    # The second input is instrumented legacy source, or exact corrected source.
    add(cpp_inputs[1], proof['instrumented_sha256'])
    archive_fixture = E / proof_name.removesuffix('.json') / 'fixture/payload.zip'
    add(archive_fixture, proof['archive_sha256'])
    if 'unicode_archive_sha256' in proof:
        add(archive_fixture.with_name('unicode.zip'), proof['unicode_archive_sha256'])
for proof_name in ('retained-extraction-legacy-gap-02.json',
                   'retained-extraction-corrected-private-proof-04.json',
                   'retained-extraction-maintained-smoke-02.json',
                   'retained-extraction-public-owner-private-02.json',
                   'retained-extraction-marker-cells-private-05.json'):
    proof = read(E / proof_name)
    for c in proof['commands'] + proof.get('setup_commands', []) + proof.get('legacy_direct_children', []):
        if 'log' in c:
            add(c['log'], c.get('log_sha256', c.get('sha256')))
        for stream in c.get('streams', {}).values():
            add(stream['path'], stream['sha256'], stream['bytes'])
    if 'test_log_sha256' in proof:
        add(E / proof_name.removesuffix('.json') / 'tests.log', proof['test_log_sha256'])
add(E / 'retained-extraction-marker-cells-private-05/selected-marker-cells.py', narrow['selector_sha256'])
custody_bytes = sum(v['bytes'] for v in members.values())
assert custody_bytes < 32 * 1024 ** 2
assert shutil.disk_usage(W).free >= 10 * 1024 ** 3 + 2 * custody_bytes
ref_path = plan.parent / 'evidence/retained-extraction-relative.v1.json'
archive_path = plan.parent / 'evidence/retained-extraction-relative-custody.zip'
assert not ref_path.exists() and not archive_path.exists()
try:
    save()
    run('paths', ['py', '-3', 'tools/workspace_hygiene.py', 'paths'])
    resources = json.loads(run('doctor', ['py', '-3', 'tools/workspace_hygiene.py',
                                        'doctor', '--measure'], accepted=(0, 1)))
    assert set(resources['violations']) <= {'unmanaged_secondary_worktrees_present', 'merged_local_task_branches_present'}
    assert len(resources['task_roots']) <= 8
    assert resources['task_root_bytes'] + 2 * custody_bytes + 2 * 1024 ** 3 < 20 * 1024 ** 3
    for name in ('inspect', 'noop-check', 'recover'):
        run('task-' + name, ['py', '-3', '.aide/scripts/aide_lite.py', 'task', name, '--task-id', UNIT])
    for name in ('policy', 'detect', 'plan'):
        run('git-' + name, ['py', '-3', '.aide/scripts/aide_lite.py', 'git', name])
    run('generated', ['py', '-3', 'tools/codegen/generate_contracts.py', '--check'])
    run('strict', ['py', '-3', 'tools/strict_check.py'])
    run('diff', ['git', 'diff', '--check'])
    assert git('rev-parse', 'HEAD') == admission['base'] and git('branch', '--show-current') == BRANCH
    assert changed() == expected and not git('diff', '--cached', '--name-only')
    assert {p: sha(R / p) for p in expected} == admission['changed_paths']
    for v in members.values():
        assert sha(v['path']) == v['sha256'] and v['path'].stat().st_size == v['bytes']
    for c in record['commands']:
        add(c['log'], c['log_sha256'])
    custody_bytes = sum(v['bytes'] for v in members.values())
    assert custody_bytes < 32 * 1024 ** 2
    assert shutil.disk_usage(W).free >= 10 * 1024 ** 3 + 2 * custody_bytes
    with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, v in sorted(members.items()):
            archive.writestr(name, v['path'].read_bytes())
    with zipfile.ZipFile(archive_path) as archive:
        assert set(archive.namelist()) == set(members)
        for name, v in members.items():
            data = archive.read(name)
            assert hashlib.sha256(data).hexdigest() == v['sha256'] and len(data) == v['bytes']
    ref = ref_path.relative_to(R).as_posix()
    write(ref_path, dict(schema='facman.retained_extraction_relative.v1', work_item=UNIT,
        source_parent=admission['base'], source_parent_tree=git('rev-parse', 'HEAD^{tree}'),
        verdict='EXACT_APPLIED_SOURCE_BOUND_TO_ACCEPTED_PRIVATE_WINDOWS_EVIDENCE',
        source_paths=proposal['source_paths'], evidence_receipts=fixed,
        admission_sha256=sha(E / 'retained-extraction-admission-08.json'),
        available_marker_cells_acceptance_sha256=sha(actual_path),
        private_adversarial_assertions=118, maintained_native_smoke_passed=True,
        public_complete_methods=16, public_partial_methods=1,
        additional_foreign_marker_cells_passed=2,
        host_gaps=narrow['retained_host_gaps'], all17_zero_skip_qualification=False,
        old_direct_child_stream_custody_exhaustive=False,
        cached_inputs_and_callers_exact_bound=True, checkout_rebuild_performed=False,
        custody=dict(path=archive_path.relative_to(R).as_posix(), sha256=sha(archive_path),
                     bytes=archive_path.stat().st_size,
                     members={n: dict(sha256=v['sha256'], bytes=v['bytes']) for n, v in sorted(members.items())}),
        boundaries=dict(new_builds=0, new_roots=0, new_clones=0, new_worktrees=0, new_candidates=0,
                        required_source_and_merge_CI_pending=True, produced_package_acceptance_pending=True,
                        full_F09_closed=False, full_F11_closed=False, POSIX_qualified=False,
                        real_game_qualified=False, human_qualified=False, beta_qualified=False)))
    with plan.open('ab') as stream:
        stream.write(b'\nExact applied retained-extraction source is bound to independently accepted private Windows evidence and unchanged cached callers. Accepted evidence is118 adversarial assertions, the maintained native regression,16 complete public methods and two additional foreign-marker cells. Both dangling-symlink cells remain host-unqualified; the original partial run and limited direct-child custody are preserved in evidence/retained-extraction-relative.v1.json. Generated-state and strict validation passed without another native build. Current required source/merge CI and genuine produced-package acceptance remain mandatory; no original F09/full F11/game/human/Beta closure.\n')
    expected |= {ref, archive_path.relative_to(R).as_posix()}
    assert changed() == expected
    for p, binding in proposal['source_paths'].items():
        assert sha(R / p) == binding['proposed_sha256']
    sys.path.insert(0, str(R / '.aide/scripts'))
    import aide_lite as aide
    message = ('fix(archive): retain extraction namespace ownership\n\n'
               'Create archive children relative to held parent handles and retain\n'
               'Windows rename exclusion through extraction.\n\n'
               'Work-Item: ' + UNIT + '\nEvidence-Ref: ' + ref + '\n')
    message_path = E / (P + '-commit.txt')
    with message_path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(message)
    checks = aide.validate_commit_message_text(message, repo_root=R)
    verdict = aide.commit_message_result(checks)
    assert verdict != 'FAIL'
    write(E / (P + '-message-validation.json'), dict(verdict=verdict, checks=[dataclasses.asdict(c) for c in checks]))
    paths = [dict(path=p, state='content', sha256=sha(R / p), ownership='task_owned',
                  git_blob_oid=git('hash-object', '--path=' + p, p)) for p in sorted(expected)]
    classification = dict(schema_version='aide.git-commit-classification.v1', branch=BRANCH,
        base_commit=admission['base'], work_item=UNIT,
        snapshot_sha256=aide.helper_commit_snapshot_sha256(paths),
        message_sha256=sha(message_path), changed_paths=paths, reviews=[])
    write(E / (P + '-commit-classification.json'), classification)
    record.update(status='PASS_EXACT_SOURCE_PACKET_REQUIRES_INDEPENDENT_COMMIT_REVIEW',
        base=admission['base'], changed_paths=paths,
        classification_sha256=sha(E / (P + '-commit-classification.json')),
        snapshot_sha256=classification['snapshot_sha256'], message_sha256=sha(message_path),
        custody_sha256=sha(archive_path), custody_members=len(members), custody_uncompressed_bytes=custody_bytes,
        required_source_and_merge_CI_pending=True, produced_package_acceptance_pending=True,
        finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
    print(json.dumps(dict(status=record['status'], paths=len(paths), custody_members=len(members),
                          new_builds=0)), flush=True)
except BaseException as error:
    record.update(status=record['status'] if record['status'].startswith('STOP_') else 'ACTIONABLE_STOP_PRESERVE_SOURCE',
                  error=repr(error))
    save()
    raise
