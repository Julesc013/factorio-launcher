"""Guard and record legacy native text children; retain raw bytes on partial failure."""
from pathlib import Path
import hashlib,subprocess,threading,time

def install(cli, temporary, streams, record, save, limit=45):
    original=subprocess.Popen
    cli=Path(cli).resolve();temporary=Path(temporary).resolve()
    record['legacy_direct_children']=[]
    class OwnedTextChild(original):
        def __init__(self,args,*positional,**kwargs):
            self._owned_legacy=isinstance(args,(list,tuple)) and bool(args) and Path(str(args[0])).resolve()==cli and bool(kwargs.get('text') or kwargs.get('universal_newlines') or kwargs.get('encoding'))
            if not self._owned_legacy:
                super().__init__(args,*positional,**kwargs);return
            assert not positional and '--workspace' in args
            workspace=Path(str(args[args.index('--workspace')+1])).resolve()
            assert workspace.is_relative_to(temporary)
            assert kwargs.get('stdout')==subprocess.PIPE and kwargs.get('stderr')==subprocess.PIPE
            self._encoding=kwargs.pop('encoding',None) or 'utf-8';self._errors=kwargs.pop('errors',None) or 'strict'
            kwargs.pop('text',None);kwargs.pop('universal_newlines',None)
            kwargs['creationflags']=kwargs.get('creationflags',0)|getattr(subprocess,'CREATE_NO_WINDOW',0)
            self._started=time.monotonic();self._captured=None;self._deadline=None;self._finalized=False
            self._entry=dict(index=len(record['legacy_direct_children'])+1,argv=list(map(str,args)),status='STARTING',kill_error=None,deadline_exceeded=False,streams={})
            super().__init__(args,**kwargs)
            self._entry.update(pid=self.pid,status='RUNNING')
            record['legacy_direct_children'].append(self._entry)
            def expired():
                if self.poll() is None:
                    self._entry['deadline_exceeded']=True
                    try:original.kill(self)
                    except BaseException as error:self._entry['kill_error']=repr(error)
                    try:save()
                    except BaseException as error:self._entry['audit_error']=repr(error)
            try:
                # Arm lifetime control before any fallible external receipt write.
                self._deadline=threading.Timer(limit,expired);self._deadline.daemon=True;self._deadline.start()
                save()
            except BaseException as error:
                self._entry['constructor_error']=repr(error)
                self._kill_if_running()
                self._drain_failure(error,b'',b'')
                raise
        def _kill_if_running(self):
            if self.poll() is None:
                try:original.kill(self)
                except BaseException as error:self._entry['kill_error']=repr(error)
        def _write_stream(self,label,name,data):
            path=Path(streams)/('legacy-'+str(self._entry['index']).zfill(4)+'.'+label+name)
            with path.open('xb') as stream:stream.write(data)
            return dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
        def _finish(self,out,err,error,complete):
            if self._finalized:return
            out=out or b'';err=err or b''
            if self.poll() is not None and self._deadline is not None:self._deadline.cancel()
            # Record state before writes, so an audit failure cannot imply success.
            self._entry.update(status='STOP_POSSIBLY_LIVE' if self.poll() is None else ('FAILED_DRAINED' if error else 'TERMINAL'),exit_code=self.poll(),raw_streams_complete=bool(complete),seconds=round(time.monotonic()-self._started,3))
            for name,data in [('stdout',out),('stderr',err)]:self._entry['streams'][name]=self._write_stream('',name,data)
            self._finalized=True
            def decode(data):return data.decode(self._encoding,self._errors).replace('\r\n','\n').replace('\r','\n')
            self._captured=(decode(out),decode(err));save()
        def _drain_failure(self,error,out,err):
            complete=False
            try:
                out,err=original.communicate(self,timeout=10);complete=True
            except BaseException as drain:
                self._entry['drain_error']=repr(drain)
                # A non-timeout drain failure must not erase initial raw buffers.
                if isinstance(drain,subprocess.TimeoutExpired):
                    if drain.output is not None:out=drain.output
                    if drain.stderr is not None:err=drain.stderr
            self._finish(out,err,error,complete)
        def kill(self):
            if not self._owned_legacy:return original.kill(self)
            try:return original.kill(self)
            except BaseException as error:
                self._entry['kill_error']=repr(error)
                self._drain_failure(error,b'',b'')
                raise
        def communicate(self,input=None,timeout=None):
            if not self._owned_legacy:return original.communicate(self,input,timeout)
            if self._captured is not None:return self._captured
            if isinstance(input,str):input=input.encode(self._encoding,self._errors)
            remaining=max(.001,limit-(time.monotonic()-self._started))
            try:out,err=original.communicate(self,input,min(remaining,timeout) if timeout is not None else remaining)
            except BaseException as error:
                out=error.output or b'' if isinstance(error,subprocess.TimeoutExpired) else b''
                err=error.stderr or b'' if isinstance(error,subprocess.TimeoutExpired) else b''
                self._kill_if_running()
                try:
                    if isinstance(error,subprocess.TimeoutExpired):
                        self._entry['initial_timeout_streams']={name:self._write_stream('initial-',name,data) for name,data in [('stdout',out),('stderr',err)]}
                finally:
                    # Failed stream custody must still attempt bounded child drain.
                    self._drain_failure(error,out,err)
                raise
            self._finish(out,err,None,True);return self._captured
    subprocess.Popen=OwnedTextChild
    return original
