#include "fl_archive.h"
#include "fl_file_io.h"
#include "fl_sha256.h"
#include "fl_windows_path.h"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <stdexcept>
#include <string>
#include <vector>
namespace fs=std::filesystem;
using namespace facman;
int checks=0, substitution_attempts=0;
void need(bool value,const char* label) {
    ++checks;if(!value) throw std::runtime_error(label);
}
std::string bytes(const fs::path& p) {
#ifdef _WIN32
    std::ifstream f(fs::path(platform::windows_extended_path(p)),std::ios::binary);
#else
    std::ifstream f(p,std::ios::binary);
#endif
    if(!f) throw std::runtime_error("independent reader could not open expected output");
    return {std::istreambuf_iterator<char>(f),std::istreambuf_iterator<char>()};
}
void write(const fs::path& p,const std::string& value) {
    std::ofstream f(p,std::ios::binary);f<<value;need(static_cast<bool>(f),"write fixture");
}
std::vector<archive::VerifiedEntry> expected(const archive::Plan& plan,const archive::Limits& limits) {
    std::vector<archive::VerifiedEntry> result;
    for(const auto& entry:plan.entries) {
        base::Sha256Hasher hash;std::uint64_t size=0;
        const auto status=archive::stream_entry(plan,entry.index,limits,
            [&](const unsigned char* p,std::size_t n) {hash.update(p,n);size+=n;return true;});
        need(status.ok(),"preverify same reader");result.push_back({entry.path,size,hash.finish()});
    }
    return result;
}
std::size_t count(const fs::path& p) {
    std::size_t n=0;for(const auto& entry:fs::recursive_directory_iterator(p)) {
        (void)entry;++n;
    }return n;
}
int main(int argc,char** argv) {
    try {
        need(argc==2,"arguments");
        const auto work=fs::u8path(argv[1]);
        archive::Limits limits;archive::Plan plan;
        need(archive::inspect_archive(work/"payload.zip",limits,plan).ok(),"inspect");
        const auto verified=expected(plan,limits);
        const auto foreign=work/"foreign";
        fs::create_directory(foreign);write(foreign/"sentinel","FOREIGN\n");
        platform::PathIdentity foreign_before;
        need(platform::inspect_path_no_follow(foreign,foreign_before).ok(),"foreign identity");
        const auto staging=work/"staging";
        std::vector<std::string> checkpoints;
        archive::ExtractionObservation observation;
        const auto status=archive::extract_verified_to_new_retained_staging(plan,staging,limits,verified,
            [&](std::uint32_t,const char* point) {
                const std::string name=point;checkpoints.push_back(name);
                fs::path target;
                if(name=="root_created")target=staging;
                else if(name=="directory_created")target=staging/"nested";
                else if(name=="output_created")target=staging/"nested"/"consumed.txt";
                else return true;
                // This fixture contains exactly one nested payload.
                ++substitution_attempts;
                std::error_code error;fs::rename(target,work/("displaced-"+name),error);
                need(static_cast<bool>(error),"returned handle must refuse namespace rename");
                need(error.value()==32 || error.value()==5,"Windows sharing/access refusal");
                need(!fs::exists(work/("displaced-"+name)),"no owned object displaced");
                need(bytes(foreign/"sentinel")=="FOREIGN\n" && count(foreign)==1,"foreign untouched");
                return true;
            },&observation);
        need(status.ok(),"corrected extraction succeeds");
        need(substitution_attempts==3,"root child output checkpoints");
        need(observation.effects_possible(),"retained observation");
        need(bytes(staging/"nested"/"consumed.txt")=="VERIFIED PAYLOAD\n","exact output");
        need(bytes(staging/archive::owned_staging_marker_name())=="schema=facman.archive_staging.v1\n","exact marker");
        platform::PathIdentity foreign_after;
        need(platform::inspect_path_no_follow(foreign,foreign_after).ok() &&
            foreign_before.same_object(foreign_after),"foreign identity unchanged");
        need(count(foreign)==1,"foreign inventory exact");
        // Legal archive names remain full UTF-8 code points, never byte-widened.
        const auto names_root=work/"utf8";
        fs::create_directory(names_root);
        platform::StableDirectoryObject parent;
        need(parent.open_no_follow_for_relative_writes(names_root).ok(),"UTF8 parent");
        std::string long_name;for(int i=0;i<100;++i)long_name+="\xE4\xB8\xAD";
        const std::vector<std::string> legal={"with spaces.txt","caf\xC3\xA9.txt",
            "cafe\xCC\x81.txt","emoji-\xF0\x9F\x98\x80.txt",long_name};
        for(const auto& name:legal) {
            platform::DurableOutputFile file;
            need(parent.create_child_file_exclusive_utf8(name,10,file).ok(),"UTF8 create file");
            need(file.write_at(0,"exact",5)==5,"UTF8 write");
            need(file.flush_file_and_parent().ok(),"UTF8 flush");
            need(bytes(names_root/fs::u8path(name))=="exact","UTF8 filename unchanged");
            platform::StableDirectoryObject directory;
            need(parent.create_child_directory_exclusive_utf8("d-"+name,directory).ok(),"UTF8 create dir");
            need(directory.revalidate().ok(),"UTF8 dir identity");
        }
        need(long_name.size()>255U,"multibyte component exceeds old byte cap");
        archive::Plan unicode_plan;
        need(archive::inspect_archive(work/"unicode.zip",limits,unicode_plan).ok(),"inspect Unicode archive");
        const auto unicode_verified=expected(unicode_plan,limits);
        const auto unicode_root=work/"unicode-extracted";
        need(archive::extract_verified_to_new_retained_staging(unicode_plan,unicode_root,limits,
            unicode_verified).ok(),"extract Unicode archive");
        for(const auto& entry:unicode_plan.entries)
            need(bytes(unicode_root/fs::u8path(entry.path))=="UNICODE PAYLOAD\n","archive UTF8 exact output");
        const auto original_count=count(names_root);
        const std::vector<std::string> invalid={"",".","..","a/b","a\\b","a:b",std::string("a\0b",3),
            "\xC0\xAF","\xED\xA0\x80","\xF4\x90\x80\x80","\xE2\x82","\x80"};
        for(const auto& name:invalid) {
            platform::DurableOutputFile file;platform::StableDirectoryObject directory;
            need(parent.create_child_file_exclusive_utf8(name,10,file).code=="relative_leaf_invalid","invalid UTF8 file refused");
            need(parent.create_child_directory_exclusive_utf8(name,directory).code=="relative_leaf_invalid","invalid UTF8 dir refused");
        }
        need(count(names_root)==original_count,"invalid inputs pre-effect");
        {
            platform::DurableOutputFile file;
            need(!parent.create_child_file_exclusive_utf8(legal[0],10,file).ok(),"existing Unicode output refused");
            need(bytes(names_root/fs::u8path(legal[0]))=="exact","existing output preserved");
            platform::StableDirectoryObject directory;
            need(!parent.create_child_directory_exclusive_utf8("d-"+legal[0],directory).ok(),"existing directory refused");
            const std::string huge(33000,'a');
            need(parent.create_child_file_exclusive_utf8(huge,10,file).code=="relative_file_create_failed",
                "native UNICODE_STRING length refusal");
            need(count(names_root)==original_count,"length and collision refusals pre-effect");
        }
        for(const auto& name:legal) {
            platform::DurableOutputFile file;platform::StableDirectoryObject directory;
            need(parent.create_child_file_exclusive(fs::u8path("portable-"+name),10,file).code=="relative_leaf_invalid",
                "portable file contract unchanged");
            need(parent.create_child_directory_exclusive(fs::u8path("portable-"+name),directory).code=="relative_leaf_invalid",
                "portable dir contract unchanged");
        }
        // Returned files are retained empty if the per-call checkpoint refuses before bytes.
        archive::ExtractionObservation interrupted;
        const auto partial=work/"partial";
        const auto partial_status=archive::extract_verified_to_new_retained_staging(plan,partial,limits,verified,
            [](std::uint32_t,const char* point){return std::string(point)!="output_created";},&interrupted);
        need(partial_status.code=="archive_extract_fault_injected","typed pre-write interruption");
        need(interrupted.effects_possible(),"interruption possible effects");
        need(fs::exists(partial/"nested"/"consumed.txt") && fs::file_size(partial/"nested"/"consumed.txt")==0,
            "empty partial output retained");
        need(fs::exists(partial/archive::owned_staging_marker_name()),"partial marker retained");
        auto wrong=verified;wrong[0].sha256=std::string(64,'0');
        const auto bad_root=work/"bad-hash";
        const auto bad=archive::extract_verified_to_new_retained_staging(plan,bad_root,limits,wrong);
        need(bad.code=="archive_consumed_digest_mismatch","consumed byte integrity refusal");
        need(bytes(bad_root/"nested"/"consumed.txt")=="VERIFIED PAYLOAD\n","bad-hash exact partial retained");
        const auto refused=archive::extract_verified_to_new_retained_staging(plan,foreign,limits,verified);
        need(refused.code=="archive_staging_root_exists","foreign root refused");
        need(bytes(foreign/"sentinel")=="FOREIGN\n" && count(foreign)==1,"foreign refusal preserves exact");
        archive::ExtractionObservation timed;
        auto deadline=limits;deadline.maximum_read_milliseconds=0;
        const auto timed_root=work/"timed";
        const auto timed_status=archive::extract_verified_to_new_retained_staging(plan,timed_root,deadline,verified,{},&timed);
        need(timed_status.code=="archive_read_limit_or_sink_failed","time budget refusal");
        need(timed.effects_possible() && fs::is_directory(timed_root),"timed root retained");
        std::cout<<"{\"status\":\"PASS_PRIVATE_CORRECTED_HANDLE_EXTRACTION\",\"assertions\":"<<checks
            <<",\"substitution_attempts\":"<<substitution_attempts<<",\"legal_utf8_names\":"<<legal.size()
            <<",\"invalid_utf8_names\":"<<invalid.size()<<",\"full_F09_qualified\":false}\n";
        return 0;
    } catch(const std::exception& error) {std::cerr<<error.what()<<'\n';return 20;}
}
