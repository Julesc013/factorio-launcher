def test_published_marker_substitution_refuses_and_preserves_incomplete_journal(self) -> None:
    for point in ('published', 'committed'):
        for substitution in ('foreign_bytes',):
            with self.subTest(point=point, substitution=substitution), tempfile.TemporaryDirectory() as value:
                workspace = Path(value)
                _, pack = self.make_pack(workspace)
                tx = self.interrupt(workspace, pack, point)
                target = workspace / 'instances/reconstructed'
                marker = target / '.facman-transaction-staging.v2.json'
                if substitution == 'dangling_symlink':
                    marker.unlink()
                    try:
                        marker.symlink_to(workspace / 'foreign-missing-marker')
                    except OSError as error:
                        if error.errno in (errno.EPERM, errno.ENOSYS, errno.EOPNOTSUPP) or getattr(error, 'winerror', None) in (50, 1314):
                            self.skipTest(f'not_applicable: host cannot create symbolic links: {error}')
                        raise
                    link_before = os.readlink(marker)
                else:
                    marker.write_bytes(b'foreign marker bytes')
                before = snapshot(target)
                journal = workspace / 'transactions' / f'{tx}.transaction.v1.json'
                journal_before = journal.read_bytes()
                refused = call(workspace, 'workspace', 'recovery', 'apply', tx, success=False)
                self.assertEqual('recovery_modpack_import_unsafe', refused['refusal']['code'])
                self.assertEqual(before, snapshot(target))
                self.assertEqual(journal_before, journal.read_bytes())
                self.assertNotEqual('complete', json.loads(journal.read_bytes())['state'])
                if substitution == 'dangling_symlink':
                    self.assertTrue(marker.is_symlink())
                    self.assertEqual(link_before, os.readlink(marker))
