import hashlib,json,os,subprocess,sys,traceback,zipfile
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
BASE='3b12f8e36786ef8cdb5c3bb897440d1566b91c51';DEV='3b12f8e36786ef8cdb5c3bb897440d1566b91c51';BRANCH='task/facman-windows-delivered-joined-gui-01'
Q='.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.safecrlf',GIT_CONFIG_VALUE_0='false')
sys.path.insert(0,str(R))
from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
out=E/'windows-delivered-joined-candidate-commit-result-02.json';assert not out.exists()
record=dict(status='SEALING_REVIEWED_FIXTURE_CORRECTION',commands=[],new_roots=0,new_clones=0,new_worktrees=0,new_optional_campaigns=0,goal_status_mutated=False)
def save():out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
def run(label,args,timeout=180):
 r=owned.command(args,cwd=R,environment=dict(os.environ),timeout=timeout,directory=E/('windows-delivered-joined-commit02-'+label),output_limit=8*1024**2)
 record['commands'].append(dict(label=label,exit_code=r.returncode,receipt_sha256=sha(r.directory/'receipt.json')));save()
 assert r.ok and r.receipt['primary_stopped'] and r.receipt['job_empty_observed'],(label,(r.stdout[-1000:]+r.stderr[-1500:]).decode('utf-8','replace'))
 return r
try:
 assert git('rev-parse','HEAD')==BASE and git('branch','--show-current')==BRANCH and not git('diff','--cached','--name-only')
 packet=E/'windows-delivered-joined-author-packet.v2.json';p=json.loads(packet.read_bytes())
 frozen=E/'windows-delivered-joined-frozen-source.v2.json';f=json.loads(frozen.read_bytes())
 review=E/'windows-delivered-joined-independent-review-02.json';v=json.loads(review.read_bytes())
 assert v['verdict']=='PASS_LIVE_LEGACY_GUI_SOURCE_FOR_REQUIRED_CURRENT_CI' and v['non_authoring']
 assert v['author_packet_sha256']==sha(packet) and v['frozen_source_sha256']==sha(frozen)
 initial=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
 assert initial==set(p['authored_paths'])|{Q+'/ExecPlan.md',Q+'/evidence/produced-joined-make-ready.v1.json',Q+'/evidence/produced-joined-make-ready-custody.v1.zip'}
 for path,row in f['files'].items():assert sha(R/path)==row['sha256']
 for label in ('policy','detect','plan'):run(label,['py','-3','-B','.aide/scripts/aide_lite.py','git',label])
 evidence=R/Q/'evidence/windows-live-joined-gui-source.v1.json'
 archive=R/Q/'evidence/windows-live-joined-gui-source-custody.v1.zip'
 assert not evidence.exists() and not archive.exists()
 names={Path(__file__).name,packet.name,frozen.name,review.name,'windows-delivered-joined-independent-review-01.json',
  'windows-delivered-joined-author-packet.v1.json','windows-delivered-joined-custody-review-01.json','windows-delivered-joined-log-custody-01.py'}
 for path,row in p['files'].items():
  path=Path(path)
  if path.is_relative_to(E) and path.suffix.lower() not in ('.zip','.exe','.dll'):
   assert sha(path)==row['sha256'];names.add(path.relative_to(E).as_posix())
 accepted=json.loads(Path(p['accepted_result']['result']).read_bytes())
 raw_root=Path(p['accepted_result']['result']).parent
 external={str(raw_root/'result.json'):Path(p['accepted_result']['result'])}
 external.update({'actual-GUI/objects/'+path.name:path for path in (raw_root/'objects').iterdir() if path.is_file()})
 external={'actual-GUI/result.json':Path(p['accepted_result']['result']),**{k:v for k,v in external.items() if k.startswith('actual-GUI/')}}
 manifest={'evidence/'+name:sha(E/name) for name in sorted(names)}
 manifest.update({name:sha(path) for name,path in external.items()})
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
  z.writestr('custody-manifest.json',json.dumps(manifest,indent=2,sort_keys=True)+'\n')
  for name in sorted(names):z.write(E/name,'evidence/'+name)
  for name,path in external.items():z.write(path,name)
 with zipfile.ZipFile(archive) as z:
  for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
 proof=json.loads((E/'windows-delivered-joined-custody-review-01.json').read_bytes())
 evidence.write_text(json.dumps(dict(schema='facman.windows_live_joined_gui_source_qualification.v1',
  base_head=BASE,author_packet_sha256=sha(packet),frozen_source_sha256=sha(frozen),review_sha256=sha(review),
  authored_files_sha256={n:x['sha256'] for n,x in f['files'].items()},actual_local_proof=proof,
  artifact=p['artifact'],source_revisions=p['candidate_source_revisions'],
  produced_generation_refusal=p['actual_produced_generation_failure'],
  original_portable_layout_reconstructed=True,portable_ZIP_custody=False,installed_generation_accepted=False,
  required_current_checks_pending=True,actual_current_factory_GUI_proof_pending=True,
  required_current_GUI_test='tests.test_windows_delivered_joined_gui.WindowsDeliveredJoinedGuiTests.test_actual_joined_controls_dispatch_production_packaged_backend',
  custody=archive.name,custody_sha256=sha(archive),custody_files=len(manifest),
  raw_package_inputs_retained_in_owned_root=True,full_package_backup_archived=False,
  runtime_provider_policy_changes=False,native_rebuild=False,new_roots=0,new_clones=0,new_worktrees=0,
  canonical_installed_desktop=False,minimum_mac13_physical_host=False,named_physical_host=False,
  real_game=False,human=False,whole_workunit=False,full_make_ready=False,beta=False,rc=False),indent=2)+'\n',encoding='utf-8')
 with (R/Q/'ExecPlan.md').open('a',encoding='utf-8',newline='\n') as stream:
  stream.write('\n### Live Windows GUI to packaged backend candidate\n\nThe existing passed Windows artifact supplies the exact produced legacy WinForms bytes. Actual setup-generation execution refuses its relocated GUI because closure differs from the preserved manifest; that is the retained PR404 owner-only integration dependency. A single inverse GUI-leaf move restores the original598file portable closure with all original bytes/hashes. This qualifies neither the original portable ZIP nor an installed/canonical Desktop.\n\nTwo actual offscreen GUI sessions drive native typed selected-save inputs, both cancellations, stale confirmation refusal and one fresh confirmed joined request through the live store and production backend. Eight fixture/query CLI calls use the same admitted produced executable. Independent receipt, completed owner journals, target bytes/identity and whole-workspace preservation pass. The read-only package closure remains unchanged with empty PATH and cleared source/backend overrides. Review found an initial postlaunch job-assignment race: historicalrun10 is retained and superseded. Correctedrun11 creates the primary suspended, binds its exact job before resuming the retained initial thread, checks membership/creation identity of opened descendant handles and proves normal exit with zero active owned processes. It independently observes68packaged backend processes across the two sessions. Full byte/CAS and native control frames survive cleanup in bounded hashed custody.\n\nThe existing required Windows Python stage can use its already built matching shared/Release product with the unchanged normal clean-source package factory. The actual new-head GUI method and independently decoded factory-produced custody must pass before normal checked integration; unsupported or required_blocked skips grant no GUI acceptance. No runtime, provider, workflow or policy changes, native rebuild, new root, clone, worktree or full package backup occurred locally. Live legacy portable GUI acceptance remains separate from canonical installed Desktop, approved real Factorio/human/minimum/named-host journeys, complete Make Ready/Play and Beta/RC.\n\nEvidence: evidence/windows-live-joined-gui-source.v1.json and hash-closed custody; consumed PR417 proof at evidence/produced-joined-make-ready.v1.json.\n')
 paths=initial|{Q+'/evidence/'+evidence.name,Q+'/evidence/'+archive.name}
 run('project-state',['py','-3','-B','tools/project_state.py','--write'],600);run('metadata',['py','-3','-B','tools/codegen/generate_metadata.py','--write'])
 dirty=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
 assert paths<=dirty<=paths|{'.aide/memory/project-state.md','.aide/memory/project-state.v2.json','README.md'}
 assert all(sha(R/path)==row['sha256'] for path,row in f['files'].items())
 run('strict',['py','-3','-B','tools/strict_check.py'],1800);run('portable-aide',['py','-3','-B','.aide/scripts/aide_lite.py','test'],1800)
 message='test(gui): qualify live packaged joined preparation controls\n\nDrive actual typed inputs and confirmation through production transport\nwith exact file preservation and owned process lifetime evidence.\n\nWork-Item: FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01\nEvidence-Ref: '+Q+'/evidence/'+evidence.name+'\n'
 msg=E/'windows-delivered-joined-candidate-commit-message-02.txt';msg.write_text(message,encoding='utf-8',newline='\n')
 run('message',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--message',message])
 changes=[dict(path=n,state='content',sha256=sha(R/n),git_blob_oid=git('hash-object','--path',n,str(R/n)),ownership='task_owned') for n in sorted(dirty)]
 snapshot=hashlib.sha256((json.dumps(changes,indent=2,sort_keys=True,separators=(',',': '))+'\n').encode()).hexdigest()
 commit_review=E/'windows-delivered-joined-candidate-commit-review-02.json'
 commit_review.write_text(json.dumps(dict(schema_version='aide.git-commit-review.v1',verdict='PASS',reviewer='/root',author='/root/windows_delivered_joined_gui_implementation',non_authoring=True,branch=BRANCH,base_commit=BASE,snapshot_sha256=snapshot,message_sha256=sha(msg),independent_source_review_sha256=sha(review),review='Actual native GUI controls, production package identity/transport, exact journals/bytes and suspended owned process launch; installed refusal remains an explicit owner gate. Current required CI and factory-produced GUI custody remain mandatory.'),indent=2)+'\n',encoding='utf-8')
 classification=E/'windows-delivered-joined-candidate-commit-classification-02.json'
 classification.write_text(json.dumps(dict(schema_version='aide.git-commit-classification.v1',branch=BRANCH,base_commit=BASE,work_item='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01',snapshot_sha256=snapshot,message_sha256=sha(msg),changed_paths=changes,reviews=[dict(path=str(commit_review),sha256=sha(commit_review),verdict='PASS')]),indent=2)+'\n',encoding='utf-8')
 helper=['py','-3','-B','.aide/scripts/aide_lite.py','git','commit-plan','--classification',str(classification),'--message-file',str(msg)]
 run('plan-stage',helper);run('stage',['git','add','--',*sorted(dirty)]);run('staged-diff',['git','diff','--cached','--check']);run('plan-commit',helper)
 assert git('rev-parse','HEAD')==BASE
 run('commit',['git','commit','-F',str(msg)]);run('range',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--range',BASE+'..HEAD'])
 assert not git('status','--porcelain')
 record.update(status='COMMITTED_REVIEWED_LIVE_WINDOWS_GUI_CANDIDATE',source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),review_sha256=sha(commit_review),evidence_sha256=sha(evidence),actual_windows_factory_GUI_pending=True,required_checks_pending=True,remote_not_pushed=True)
except BaseException as error:record.update(status='ACTIONABLE_JOINED_COMMIT_FAILURE',error=str(error),traceback=traceback.format_exc())
finally:save();print(json.dumps({k:v for k,v in record.items() if k not in ('commands','traceback')},indent=2),flush=True)
raise SystemExit(0 if record['status']=='COMMITTED_REVIEWED_LIVE_WINDOWS_GUI_CANDIDATE' else 1)
