import base64,hashlib,json,re,zlib
from pathlib import Path
sha=lambda data:hashlib.sha256(data).hexdigest()
def extract(log_path,expected_source,output=None,expected_qualification=None):
 text=Path(log_path).read_text(encoding='utf-8',errors='replace')
 result_rows=[json.loads(x.split('delivered-windows-gui-result ',1)[1]) for x in text.splitlines() if 'delivered-windows-gui-result ' in x]
 custody_rows=[json.loads(x.split('delivered-windows-gui-custody ',1)[1]) for x in text.splitlines() if 'delivered-windows-gui-custody ' in x]
 assert len(result_rows)==len(custody_rows)==1
 compact,custody=result_rows[0],custody_rows[0]
 assert compact['result']=='PASS' and compact['source']==expected_source
 assert custody['schema']=='facman.windows_delivered_gui_custody.v1'
 encoded=custody['payload_base64'];assert len(encoded)<512*1024
 compressed=base64.b64decode(encoded,validate=True);assert sha(compressed)==custody['compressed_sha256']
 decoder=zlib.decompressobj();canonical=decoder.decompress(compressed,12*1024**2+1)
 assert decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail and len(canonical)<12*1024**2
 assert sha(canonical)==custody['canonical_sha256']==compact['custody_sha256']
 manifest=json.loads(canonical);files={}
 for name,item in manifest.items():
  assert name=='result.json' or re.fullmatch(r'objects/[0-9a-f]{64}',name)
  data=base64.b64decode(item['bytes_base64'],validate=True)
  assert len(data)==item['size_bytes'] and sha(data)==item['sha256']
  if name!='result.json':assert name=='objects/'+sha(data)
  files[name]=data
 assert len(files)==custody['file_count'] and sum(map(len,files.values()))<12*1024**2
 assert sha(files['result.json'])==compact['result_sha256']
 r=json.loads(files['result.json'])
 assert r['schema']=='facman.windows_delivered_joined_gui.v1' and r['result']=='PASS'
 assert r['qualification']==compact['qualification'] and r['package_closure_unchanged'] and r['elapsed_seconds']<300
 if expected_qualification is not None:assert r['qualification']==expected_qualification
 info=r['build_info']
 assert info['profile_id']=='windows_legacy_winforms_x64' and not info['source_dirty'] and info['source_commit']==expected_source
 assert info['source_revisions']==dict(factorio_launcher=expected_source,universal_launcher='5479939ca5cbc9ee0f901608a92012778b4752ae',universal_setup='2749a15b835a6c1c9968598a2b434d85809691ad')
 assert r['backend_sha256']==compact['backend_sha256'] and r['gui_sha256']==compact['gui_sha256']
 assert r['environment']['PATH']=='' and not r['environment']['source_backend_provider_overrides']
 assert r['package_file_count']>=500 and 0<len(r['calls'])<=64 and len(r['sessions'])==2
 streams=0
 for call in r['calls']:
  assert Path(call['argv'][0]).name=='facman.exe' and Path(call['argv'][0]).parent==Path(r['package'])/'bin'
  assert call['exit_code']==0 and not call['stderr']
  streams+=len(call['stdout'].encode('utf-8'))+len(call['stderr'].encode('utf-8'))
 assert streams<4*1024**2
 observed=0
 for session in r['sessions']:
  t=session['terminal'];launch=t['launch']
  assert t['exit_code']==0 and not t['stdout'] and not t['stderr'] and not t['safety_termination']
  assert t['owned_job_active_processes']==0 and launch['pid']==t['pid'] and launch['created_suspended']
  assert launch['exact_job_membership_before_resume'] and launch['resume_previous_suspend_count']==1
  records=t['backend_processes'];assert any(x['role']=='packaged_backend' for x in records)
  assert len({x['process_identity'] for x in records})==len(records)<=128
  for child in records:
   assert child['gui_pid']==t['pid'] and child['exact_job_membership'] and child['exit_code'] in (0,1)
   assert child['process_identity'].split(':')[0]==str(child['pid'])
   if child['role']=='packaged_backend':
    assert Path(child['image'])==Path(r['package'])/'bin/facman.exe' and child['image_sha256']==r['backend_sha256']
    observed+=1
   else:assert child['role']=='windows_console_host' and Path(child['image']).name.lower()=='conhost.exe'
  for event in session['events']:assert event['pid']==t['pid']
 first={x['stage'] for x in r['sessions'][0]['events']}
 second={x['stage'] for x in r['sessions'][1]['events']}
 assert {'typed semantic inputs','explicit confirmation cancelled','stale confirmation','actual backend stale refusal'}<=first
 assert {'typed semantic inputs','explicit confirmation accepted','actual completed joined result'}<=second
 assert any(x.get('stage')=='BM_CLICK' and x.get('text')=='Cancel' for x in r['sessions'][0]['events'])
 snapshots={x['stage']:x['inventory'] for x in r['snapshots']}
 assert snapshots.keys()=={'prepared fixture','both cancellation routes unchanged','stale refused before effects','joined completion independently verified'}
 for inventory in snapshots.values():
  for item in inventory.values():
   data=files['objects/'+item['sha256']];assert len(data)==item['size_bytes']
 before=snapshots['prepared fixture'];cancel=snapshots['both cancellation routes unchanged']
 assert before==cancel
 final=snapshots['joined completion independently verified']
 ledger=r['receipt'];request=json.loads(ledger['request_json']);outcome=r['outcome']
 assert ledger['schema']=='facman.presentation_action_receipt.v2' and ledger['state']=='terminal' and ledger['action_id']=='readiness.prepare_joined'
 assert ledger['effect_set']==['workspace_write']
 assert json.loads(ledger['result_json'])==outcome and sha(ledger['result_json'].encode())==ledger['result_digest']
 assert request['action_id']==ledger['action_id'] and request['scope']=='instances' and request['confirmation']=='explicit'
 assert request['selected_instance_id']=='main' and request['installation_id']=='fixture' and request['profile_id']=='gui' and request['save']=='selected.zip' and request['launch_intent']=='load_save'
 assert request['request_id']==ledger['request_id']==outcome['request_id']
 assert request['durable_operation_id']==ledger['operation_id'] and request['attempt_id']==ledger['attempt_id']
 assert outcome['outcome']=='completed' and not outcome['problems']
 payload=outcome['action_payload']
 assert payload['schema']=='factorio.make_ready_joined_result.v1' and payload['continuation']=='observe_readiness' and payload['completed_effects_verified']
 assert all(payload[k] is False for k in ('preparation_complete','readiness_complete','execution_started','permit_issued'))
 components=payload['completed_components']
 assert [x['owner_command'] for x in components]==['readiness.prepare_configuration','readiness.prepare_selected_save']
 targets={'instances/main/config/config.ini','instances/main/metadata/save-refs/selected.zip.save-ref.v1.json'}
 allowed=targets|{'.facman/action-receipts-v2/workspace-admission.v1.json','.facman/action-receipts-v2/'+ledger['key_digest']+'.v2.json'}
 for component in components:
  name='transactions/'+component['transaction_id']+'.transaction.v1.json';allowed.add(name)
  journal=json.loads(files['objects/'+final[name]['sha256']]);context=json.loads(journal['operation_context'])
  assert journal['state']=='complete' and journal['command_id']==component['owner_command']
  assert context['operation_id']==ledger['operation_id'] and context['attempt_id']==ledger['attempt_id']
  target=Path(journal['target']).relative_to(Path(r['environment']['workspace'])).as_posix()
  assert target in targets and journal['effect_file_identity']==final[target]['file_identity']
  intended=context['config_text'] if component['owner_command']=='readiness.prepare_configuration' else context['sidecar_text']
  assert files['objects/'+final[target]['sha256']]==intended.encode('utf-8')
 for name,item in before.items():
  if name not in targets:assert final[name]==item,('preserved input',name)
 assert set(final)-set(before)<=allowed and not set(before)-set(final)
 assert before['instances/main/config/config.ini']['file_identity']==final['instances/main/config/config.ini']['file_identity']
 ledger_name='.facman/action-receipts-v2/'+ledger['key_digest']+'.v2.json'
 assert json.loads(files['objects/'+final[ledger_name]['sha256']])==ledger
 assert r['observation']['readiness']['selected_save']['state']=='satisfied' and not r['observation']['readiness']['execution_available']
 if output is not None:
  output=Path(output);output.mkdir();(output/'objects').mkdir()
  for name,data in files.items():
   with (output/name).open('xb') as f:f.write(data)
 return dict(status='PASS_INDEPENDENT_ACTUAL_GUI_CUSTODY',source=expected_source,qualification=r['qualification'],
  profile=info['profile_id'],result_sha256=compact['result_sha256'],custody_canonical_sha256=compact['custody_sha256'],
  actual_GUI_sessions=2,observed_packaged_backend_processes=observed,complete_owner_effects=2,
  fixture_CLI_calls=len(r['calls']),decoded_files=len(files),decoded_bytes=sum(map(len,files.values())),
  GUI_sha256=r['gui_sha256'],backend_sha256=r['backend_sha256'],package_file_count=r['package_file_count'],
  all_owned_jobs_empty=True,ordinary_cancellations_and_stale_refusal=True,whole_workspace_inputs_preserved=True,
  canonical_installed_desktop=False,real_game=False,human=False,full_make_ready=False,beta=False,rc=False)
