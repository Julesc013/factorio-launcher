import hashlib,json,os,subprocess,sys,time,traceback
from pathlib import Path
R=Path(r"D:\Projects\Factorio\factorio-launcher");W=Path(r"D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e");E=W/"evidence";B=W/"native-developer"
sys.path.insert(0,str(R));from tools import native_build,provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads((E/"posix-preparation-publication-source-assurance-04.json").read_bytes())
def bound():
 assert subprocess.check_output(["git","branch","--show-current"],cwd=R,text=True).strip()==a["branch"]
 assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=R,text=True).strip()==a["base"]
 for n,h in a["source_files_sha256"].items():assert sha(R/n)==h,n
bound()
linux=json.loads((E/"posix-preparation-publication-linux-result-06.json").read_bytes())
assert linux["status"]=="PASS_LINUX_SOURCE_PUBLICATION_AND_RECOVERY"
os.environ.update(FACMAN_DEV_ROOT=r"D:\Projects\Factorio\.task-builds",TEMP=str(W/"t"),TMP=str(W/"t"),PYTHONDONTWRITEBYTECODE="1",CMAKE_BUILD_PARALLEL_LEVEL="2",FACMAN_MIN_FREE_GIB="12",MSBUILDDISABLENODEREUSE="1")
out=E/"posix-preparation-publication-windows-result-02.json";assert not out.exists()
v=dict(schema="facman.posix_publication_windows_regression.v1",status="ADMITTING_ONE_NATIVE_JOB",commands=[],source_assurance_sha256=sha(E/"posix-preparation-publication-source-assurance-04.json"),linux_qualification_sha256=sha(E/"posix-preparation-publication-linux-result-06.json"),new_roots=0,new_worktrees=0,new_clones=0,goal_status_mutated=False)
def save():out.write_text(json.dumps(v,indent=2)+"\n")
save();budget=owned.Budget(7200,3600)
def run(label,args,timeout):
 q=owned.command([str(x) for x in args],cwd=R,environment=dict(os.environ),timeout=timeout,budget=budget,directory=E/("posix-publication-windows02-"+label),output_limit=8*1024*1024)
 v["commands"].append(dict(label=label,exit=q.returncode,termination=q.receipt["termination"],primary_stopped=q.receipt["primary_stopped"],job_empty=q.receipt["job_empty_observed"],receipt_sha256=sha(q.directory/"receipt.json")));save()
 assert q.ok and q.receipt["primary_stopped"] and q.receipt["job_empty_observed"],label
 return q
try:
 count=0
 while True:
  count+=1
  query="$p=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(cl|clang|link|ninja|ctest)\\.exe$' -or ($_.Name -eq 'cmake.exe' -and $_.CommandLine -like '*--build*') -or ($_.Name -eq 'MSBuild.exe' -and $_.CommandLine -notlike '*/nodemode:*') } | Select-Object Name,ProcessId,CreationDate); ConvertTo-Json -InputObject $p -Compress"
  q=owned.command(["pwsh","-NoProfile","-Command",query],cwd=R,timeout=45,directory=E/f"posix-publication-windows-preflight02-{count:03d}")
  assert q.ok;active=json.loads(q.stdout)
  if not active:break
  v["foreign_native_jobs_preserved"]=active;save();time.sleep(min(count*60,600))
 native_build.require_disk_reserve(B);bound()
 assert sha(E/"tui-selected-save-qualified-native-facman-06.exe")=="5971757ced6529032c04b12d28128494d26ba5fadc8852f7f2ec0cf81922bf8e"
 run("reconfigure-checked-upstream",["cmake","-S",R,"-B",B],600)
 v["status"]="REBUILDING_CURRENT_WINDOWS_HEADER_CONSUMERS";save()
 run("build",native_build.command(B,"Release",["facman_cli","fl_platform_io_smoke","facman_abi_layout_smoke"],{}),3600)
 exe=B/"Release/facman.exe";v["cli_sha256"]=sha(exe);save()
 run("native",["ctest","--test-dir",B,"-C","Release","-R","^(fl_platform_io_smoke|facman_abi_layout_smoke)$","--output-on-failure"],300)
 os.environ.update(FACMAN_CLI_EXE=str(exe),PYTHONPATH=os.pathsep.join([str(R),str(R/"tests")]))
 run("owners",["py","-3","-B","-m","unittest","-v","test_configuration_preparation","test_selected_save_preparation","test_configuration_reconciliation"],900)
 run("strict",["py","-3","-B","tools/strict_check.py"],1800)
 run("aide",["py","-3","-B",".aide/scripts/aide_lite.py","test"],600)
 bound();v.update(status="PASS_WINDOWS_NATIVE_AND_EXISTING_OWNER_REGRESSIONS",produced_package=False,macos=False,human=False,beta=False)
except BaseException as ex:v.update(status="ACTIONABLE_WINDOWS_QUALIFICATION_FAILURE",error=str(ex),traceback=traceback.format_exc())
finally:save();print(json.dumps({k:x for k,x in v.items() if k!="commands"},indent=2))
