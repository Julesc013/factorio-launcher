import hashlib,json,subprocess,zipfile
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher'); E=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a_path=E/'posix-preparation-publication-source-assurance-04.json'
a=json.loads(a_path.read_bytes())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==a['base']
assert subprocess.check_output(['git','branch','--show-current'],cwd=R,text=True).strip()==a['branch']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R)
for n,h in a['source_files_sha256'].items():assert sha(R/n)==h,n
l_path=E/'posix-preparation-publication-linux-result-06.json'
w_path=E/'posix-preparation-publication-windows-result-02.json'
l=json.loads(l_path.read_bytes());w=json.loads(w_path.read_bytes())
assert l['status']=='PASS_LINUX_SOURCE_PUBLICATION_AND_RECOVERY'
assert w['status']=='PASS_WINDOWS_NATIVE_AND_EXISTING_OWNER_REGRESSIONS'
assert l['source_assurance_sha256']==w['source_assurance_sha256']==sha(a_path)
assert w['linux_qualification_sha256']==sha(l_path)
assert all(x['exit']==0 and x['primary_stopped'] and x['job_empty'] for x in w['commands'])
f_path=E/'posix-preparation-publication-linux-fixtures-result-04.json'
f=json.loads(f_path.read_bytes())
assert f['status']=='PASS_LINUX_SOURCE_OWNERS' and f['tests']==28 and len(f['skips'])==4
assert f['failures']==f['errors']==0 and f['uid']==65534 and f['groups']==[]
assert l['private_mount_absent'] and l['fixture_result_sha256']==sha(f_path)
Q=R/'.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
archive=Q/'evidence/posix-publication-combined-custody.v1.zip'
out=Q/'evidence/posix-publication-combined.v1.json'
assert not archive.exists() and not out.exists()
files={a_path,l_path,w_path,f_path,Path(__file__).resolve()}
for name in ('managed-verify-02-checked-integration-result-02.json',
             'posix-publication-dev-sync-result-01.json',
             'posix-publication-obsolete-source-retirement-01.json',
             'posix-publication-qualified-pre-sync-images-move-01.json',
             'posix-preparation-publication-linux-driver-06.py',
             'posix-preparation-publication-linux-fixture-worker-04.py',
             'posix-preparation-publication-windows-driver-02.py'):
 files.add(E/name)
for pattern in ('posix-publication-linux-execution-06*','posix-publication-windows02-*',
                'posix-publication-promotion-failed-job-01'):
 for folder in E.glob(pattern):
  if folder.is_dir():files.update(p for p in folder.iterdir() if p.name in ('receipt.json','stdout.raw','stderr.raw'))
for pattern in ('posix-publication-linux06*.stdout','posix-publication-linux06*.stderr'):
 files.update(E.glob(pattern))
assert all(p.is_file() and p.resolve().is_relative_to(E.resolve()) for p in files)
assert all(p.suffix not in ('.exe','.dll','.bin','.a','.lib','.zip') for p in files)
manifest={p.relative_to(E).as_posix():sha(p) for p in sorted(files)}
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files):
  info=zipfile.ZipInfo('evidence/'+p.relative_to(E).as_posix(),(1980,1,1,0,0,0))
  info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,p.read_bytes())
 info=zipfile.ZipInfo('custody-manifest.json',(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
 z.writestr(info,json.dumps(manifest,indent=2)+'\n')
v=dict(schema='facman.posix_publication_checked_dev_requalification.v1',
 work_item=Q.name,branch=a['branch'],qualified_source=a['base'],
 integrated_managed_verification=a['upstream_integration'],
 original_scoped_acceptance='posix-publication-native.v1.json',
 source_files_sha256=a['source_files_sha256'],source_assurance_sha256=sha(a_path),
 linux_qualification_sha256=sha(l_path),linux_cli_sha256=l['cli_sha256'],
 linux_owner_tests=28,linux_passes=24,linux_windows_only_skips=4,
 linux_uid=65534,linux_groups=[],private_mount_absent=True,
 windows_qualification_sha256=sha(w_path),windows_cli_sha256=w['cli_sha256'],
 windows_native_and_owner_regressions='PASS',repository_checks='strict+AIDE PASS',
 custody_archive=archive.name,custody_sha256=sha(archive),custody_members=len(files)+1,
 failed_stale_base_promotion_preserved=True,obsolete_source_jobs_cancelled=True,
 published_history_preserved=True,new_roots=0,new_clones=0,new_worktrees=0,
 goal_status_mutated=False,required_ci_still_required=True,
 produced_package=False,macos=False,existing_posix_ini_rewrite=False,
 physical_ext4_host=False,power_loss=False,human=False,game=False,beta=False,
 workunit_closed=False)
out.write_text(json.dumps(v,indent=2)+'\n')
with (Q/'ExecPlan.md').open('a',encoding='utf-8') as p:
 p.write('\n### Checked dev integration and combined qualification\n\n'
 'PR408 is integrated at 0b8e8b6. PR410 originally used an older base;\n'
 'its promotion check correctly refused it. A normal merge retains both\n'
 'published histories. All ten preparation source hashes remain unchanged.\n'
 'The combined source passes 24 Linux owner tests, with four explicit\n'
 'Windows-only skips, plus the rebuilt Windows native and owner regressions\n'
 'and strict/AIDE checks. The stale-base failure and scoped requalification\n'
 'are bound in evidence/posix-publication-combined.v1.json and its custody\n'
 'archive. Required CI and exact packages remain required. Broader host,\n'
 'existing POSIX INI, game, human, full Make Ready and Beta gates remain open.\n')
print(json.dumps(dict(status='PERSISTED_COMBINED_QUALIFICATION',receipt_sha256=sha(out),
 archive_sha256=sha(archive),members=len(files)+1,bytes=archive.stat().st_size)))
