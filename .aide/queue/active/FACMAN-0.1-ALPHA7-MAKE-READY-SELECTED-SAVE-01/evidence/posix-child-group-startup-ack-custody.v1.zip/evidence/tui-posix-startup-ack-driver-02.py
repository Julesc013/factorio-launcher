import hashlib,json,os,signal,subprocess,traceback
from pathlib import Path
R=Path('/mnt/d/Projects/Factorio/factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent;L=W/'native-save-context-linux';M=E/'posix-publication-private-fixtures-01'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads((E/'tui-posix-startup-ack-source-assurance-03.json').read_bytes())
assert os.getpid()==1 and os.getuid()==0 and os.readlink('/proc/self/ns/mnt')!=os.environ['FACMAN_PARENT_MOUNT_NAMESPACE']
os.environ.update(GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.autocrlf',GIT_CONFIG_VALUE_0='true',PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='0',TMPDIR=str(W/'t'),TMP=str(W/'t'),TEMP=str(W/'t'),FACMAN_DEV_ROOT='/mnt/d/Projects/Factorio/.task-builds',CMAKE_BUILD_PARALLEL_LEVEL='2')
out=E/'tui-posix-startup-ack-linux-result-02.json';assert not out.exists()
record=dict(status='BUILDING_POSIX_CHILD_SETUP_ACK',base=a['base'],commands=[],source_assurance_sha256=sha(E/'tui-posix-startup-ack-source-assurance-03.json'),parallel=2,new_roots=0,new_clones=0,new_worktrees=0,new_candidates=0,beta=False,game=False,physical_ext4=False,macos_qualification=False,mount_namespace=os.readlink('/proc/self/ns/mnt'),pid_namespace=os.readlink('/proc/self/ns/pid'))
def save():out.write_text(json.dumps(record,indent=2)+'\n')
def bound():
    for n,h in a['source_files_sha256'].items():assert sha(R/n)==h,n
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==a['base']
    assert set(subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines())==set(a['source_files_sha256'])
def run(label,args,timeout=600,env=None):
    bound();stdout=E/('tui-posix-startup-ack02-'+label+'.stdout');stderr=E/('tui-posix-startup-ack02-'+label+'.stderr')
    with stdout.open('xb') as o,stderr.open('xb') as er:
        p=subprocess.Popen([str(x) for x in args],cwd=R,env=env,stdout=o,stderr=er,start_new_session=True);timed=False
        try:code=p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:timed=True;os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=30)
    record['commands'].append(dict(label=label,argv=[str(x) for x in args],exit=code,execution_limit_exceeded=timed,stdout_sha256=sha(stdout),stderr_sha256=sha(stderr)));save()
    assert code==0 and not timed,(label,code,str(stderr));bound()
mounted=False;shadow=False
try:
    prior=json.loads((E/'tui-posix-startup-ack-linux-result-01.json').read_bytes())
    old=json.loads((E/'tui-posix-startup-ack-source-assurance-02.json').read_bytes())
    assert {n for n,h in a['source_files_sha256'].items() if old['source_files_sha256'][n]!=h}=={'tests/native/facman_posix_process_pump_smoke.cpp'}
    assert all(c['exit']==0 for c in prior['commands'] if c['label'] in ('configure','build'))
    assert sha(L/'facman')==prior['cli_sha256']
    record['reuse']=dict(prior_result_sha256=sha(E/'tui-posix-startup-ack-linux-result-01.json'),runtime_hashes_unchanged=True,only_native_pump_test_rebuilt=True)
    ulk=W/'providers/universal-launcher-5479939ca5cb';usk=W.parent/'task-facman-u-507ecf4b41/providers/universal-setup-2749a15b835a'
    for root,pin in ((ulk,'5479939ca5cb'),(usk,'2749a15b835a')):
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip().startswith(pin)
        assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=root,text=True).strip()
    run('build',['cmake','--build',L,'--parallel','2','--target','facman_posix_process_pump_smoke'],2400)
    record['cli_sha256']=sha(L/'facman');record['status']='RUNNING_NATIVE_PROCESS_AND_ORDINARY_TUI_QUALIFICATION';save()
    assert M.is_dir() and not list(M.iterdir()) and not os.path.ismount(M)
    subprocess.run(['mount','-t','tmpfs','-o','size=128m,nosuid,nodev,mode=1777','facman-startup-ack',M],check=True,timeout=30);mounted=True
    assert os.statvfs(M).f_blocks*os.statvfs(M).f_frsize==134217728
    # Native presentation fixtures have a compiled cache-relative root. Shadow
    # its parent privately so no existing host fixture or evidence is touched.
    native_parent=L/'tests/native';assert native_parent.is_dir() and not native_parent.is_symlink()
    config=(native_parent/'CTestTestfile.cmake').read_bytes();record['native_ctest_config_sha256']=hashlib.sha256(config).hexdigest()
    temporary_parent=M/'native';temporary_parent.mkdir(mode=0o777);temporary_parent.chmod(0o777)
    (temporary_parent/'CTestTestfile.cmake').write_bytes(config)
    subprocess.run(['mount','--bind',temporary_parent,native_parent],check=True,timeout=30);shadow=True
    env=dict(os.environ,TMPDIR=str(M),TMP=str(M),TEMP=str(M),FACMAN_CLI_EXE=str(L/'facman'),FACMAN_TUI_EXE=str(L/'facman'),PYTHONPATH=str(W/'validators-linux')+':'+str(R)+':'+str(R/'tests'))
    privilege=['setpriv','--reuid=65534','--regid=65534','--clear-groups']
    regex='^(facman_posix_child_lifecycle_smoke|facman_posix_process_pump_smoke|facman_posix_process_pump_socket_smoke|facman_execution_foundation_smoke|facman_process_pre_resume_smoke|facman_presentation_service_smoke|facman_client_smoke|facman_frontend_session_smoke)$'
    run('native',[*privilege,'ctest','--test-dir',L,'-R',regex,'--output-on-failure'],900,env)
    assert '100% tests passed, 0 tests failed out of 8' in (E/'tui-posix-startup-ack02-native.stdout').read_text()
    run('fixtures',[*privilege,'python3','-B',E/'tui-linux-make-ready-worker-02.py'],900,env)
    line=next(s for s in (E/'tui-posix-startup-ack02-fixtures.stdout').read_text().splitlines() if s.startswith('FACMAN_FIXTURE_RESULT='));record['fixtures']=json.loads(line.split('=',1)[1])
    assert record['fixtures']['tests']==6 and not record['fixtures']['skips'] and record['fixtures']['failures']==record['fixtures']['errors']==0
    record['status']='PASS_POSIX_CHILD_SETUP_ACK_NATIVE_AND_ORDINARY_TUI'
except BaseException as exc:record.update(status='ACTIONABLE_POSIX_CHILD_SETUP_ACK_QUALIFICATION_FAILURE',error=str(exc),traceback=traceback.format_exc())
finally:
    if mounted and list(M.iterdir()):
        archive=E/'tui-posix-startup-ack-fixture-custody-02.tar'
        subprocess.run(['tar','-cf',archive,'-C',M,'.'],check=True,timeout=60);record['fixture_custody_sha256']=sha(archive)
    # This driver is PID1 in its owned private namespace. Reap only exact
    # terminal children reparented after the native adversarial tests exited.
    record['reaped_terminal_namespace_children']=[]
    for path in Path('/proc').iterdir():
        if path.name.isdigit() and path.name!='1':
            try:
                status=(path/'status').read_text()
                fields={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in status.splitlines() if ':' in line}
                if fields.get('PPid')=='1' and fields.get('State','').startswith('Z'):
                    waited,native_status=os.waitpid(int(path.name),os.WNOHANG)
                    assert waited==int(path.name)
                    record['reaped_terminal_namespace_children'].append(dict(pid=waited,native_status=native_status))
            except FileNotFoundError:pass
    if shadow:subprocess.run(['umount',L/'tests/native'],check=True,timeout=30)
    if mounted:subprocess.run(['umount',M],check=True,timeout=30)
    record['private_mount_absent']=not os.path.ismount(M);record['native_parent_unmounted']=not os.path.ismount(L/'tests/native');record['remaining_namespace_processes']=[]
    for path in Path('/proc').iterdir():
        if path.name.isdigit() and path.name!='1':
            try:record['remaining_namespace_processes'].append(dict(pid=int(path.name),command=(path/'cmdline').read_bytes().decode(errors='replace').replace('\0',' ')))
            except FileNotFoundError:pass
    bound();save();print(json.dumps({k:v for k,v in record.items() if k!='commands'},indent=2));raise SystemExit(0 if record['status'].startswith('PASS_') else 1)
