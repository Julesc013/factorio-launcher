import hashlib, json, os, sys
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher'); E=Path(__file__).resolve().parent; W=E.parent
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1')
sys.path.insert(0,str(R))
from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
out=E/'tui-posix-startup-ack-static-result-01.json'
assert not out.exists()
record=dict(status='RUNNING_SCOPED_STATIC_QUALIFICATION',commands=[],goal_status_mutated=False,new_candidates=0)
for label,args in [('diff',['git','diff','--check']),('staged-diff',['git','diff','--cached','--check']),('strict',['py','-3','-B','tools/strict_check.py']),('aide',['py','-3','-B','.aide/scripts/aide_lite.py','test'])]:
    r=owned.command(args,cwd=R,environment=dict(os.environ),timeout=1800,directory=E/('tui-posix-startup-ack-static01-'+label),output_limit=2*1024*1024)
    record['commands'].append(dict(label=label,exit=r.returncode,receipt_sha256=sha(r.directory/'receipt.json'),primary_stopped=r.receipt['primary_stopped'],job_empty=r.receipt['job_empty_observed']))
    out.write_text(json.dumps(record,indent=2)+'\n')
    if not(r.ok and r.receipt['primary_stopped'] and r.receipt['job_empty_observed']):
        record.update(status='ACTIONABLE_STATIC_QUALIFICATION_FAILURE',label=label,stderr_excerpt=r.stderr[-2000:].decode(errors='replace'));break
else:record['status']='PASS_SCOPED_COMBINED_STATIC_QUALIFICATION'
out.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
raise SystemExit(0 if record['status'].startswith('PASS_') else 1)
