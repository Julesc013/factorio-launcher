import hashlib,json,os,subprocess,sys,traceback,zipfile
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1')
sys.path.insert(0,str(R));from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
BASE='361776692c9a0fd3b54d67cf8607f6435ff772a9';DEV='9bb5eef08b3ebf633dd32667e31ab701fed2a122';BRANCH='task/facman-tui-selected-save-01'
Q='.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
out=E/'tui-posix-startup-ack-commit-result-01.json';assert not out.exists()
record=dict(status='SEALING_REVIEWED_POSIX_STARTUP_REPAIR',commands=[],goal_status_mutated=False,new_optional_campaigns=0)
def save():out.write_text(json.dumps(record,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
def run(label,args,timeout=180):
    r=owned.command(args,cwd=R,environment=dict(os.environ),timeout=timeout,directory=E/('tui-posix-startup-ack-commit01-'+label),output_limit=2*1024*1024)
    record['commands'].append(dict(label=label,exit=r.returncode,receipt_sha256=sha(r.directory/'receipt.json')));save()
    assert r.ok and r.receipt['primary_stopped'] and r.receipt['job_empty_observed'],(label,r.stderr[-2000:].decode(errors='replace'))
    return r
try:
    assert git('rev-parse','HEAD')==BASE and git('branch','--show-current')==BRANCH and not git('diff','--cached','--name-only')
    assurance=json.loads((E/'tui-posix-startup-ack-source-assurance-03.json').read_bytes())
    assert set(subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines())==set(assurance['source_files_sha256'])
    for n,h in assurance['source_files_sha256'].items():assert sha(R/n)==h,n
    review=json.loads((E/'tui-posix-startup-ack-independent-review-03.json').read_bytes())
    assert sha(E/'tui-posix-startup-ack-independent-review-03.json')=='0e2b3bcfe77224bd51f11a10b92a32d1604d8338e5d0f6b81839402b94ab1bf9'
    assert review['decision']=='pass' and review['source_files_sha256']==assurance['source_files_sha256']
    linux=json.loads((E/'tui-posix-startup-ack-linux-result-02.json').read_bytes());launch=json.loads((E/'tui-posix-startup-ack-launch-result-02.json').read_bytes())
    assert linux['status']=='PASS_POSIX_CHILD_SETUP_ACK_NATIVE_AND_ORDINARY_TUI' and launch['status']=='PASS_OWNED_POSIX_CHILD_SETUP_ACK_QUALIFICATION'
    assert linux['source_assurance_sha256']==sha(E/'tui-posix-startup-ack-source-assurance-03.json')
    assert launch['linux_result_sha256']==sha(E/'tui-posix-startup-ack-linux-result-02.json')
    assert linux['private_mount_absent'] and linux['native_parent_unmounted'] and not linux['remaining_namespace_processes']
    assert launch['parent_mount_after']==dict(mounted=False,empty=True)
    assert linux['fixtures']['tests']==6 and not linux['fixtures']['skips'] and linux['fixtures']['failures']==linux['fixtures']['errors']==0
    assert linux['fixtures']['uid']==linux['fixtures']['gid']==65534 and not linux['fixtures']['groups']
    assert '100% tests passed, 0 tests failed out of 8' in (E/'tui-posix-startup-ack02-native.stdout').read_text()
    assert sha(W/'native-save-context-linux/facman')==linux['cli_sha256']
    archive=R/Q/'evidence/posix-child-group-startup-ack-custody.v1.zip';evidence=R/Q/'evidence/posix-child-group-startup-ack.v1.json'
    assert not archive.exists() and not evidence.exists()
    selected=[p.name for p in E.iterdir() if p.is_file() and p.name.startswith('tui-posix-startup-ack') and p!=out and p.suffix in ('.json','.py','.patch','.stdout','.stderr')]
    selected+=['tui-combined-macos-job-115000832770.log','tui-combined-macos-job-115000832770.json','tui-posix-startup-ack-owned-execution-01/receipt.json','tui-posix-startup-ack-owned-execution-02/receipt.json']
    manifest={n:sha(E/n) for n in sorted(set(selected))}
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr('custody-manifest.json',json.dumps(manifest,indent=2,sort_keys=True)+'\n')
        for n in manifest:z.write(E/n,'evidence/'+n)
    with zipfile.ZipFile(archive) as z:
        for n,h in manifest.items():assert hashlib.sha256(z.read('evidence/'+n)).hexdigest()==h,n
    proof=dict(schema='facman.posix_child_group_startup_ack.v1',base=BASE,integration_parent=DEV,failed_job=115000832770,failed_run=38306229201,failed_source=BASE,failed_job_log_sha256=sha(E/'tui-combined-macos-job-115000832770.log'),scope='retain explicit child group-setup proof when parent group lookup fails for a short-lived child; fixed-width acknowledgement is independent of exec success; bounded follow-up observes buffered EOF/errno before cancellation; malformed/partial/duplicate/missing frames preserve uncertainty; consuming wait never reacquires numeric signal authority',source_files_sha256=assurance['source_files_sha256'],independent_review_sha256=sha(E/'tui-posix-startup-ack-independent-review-03.json'),linux_result_sha256=sha(E/'tui-posix-startup-ack-linux-result-02.json'),linux_cli_sha256=linux['cli_sha256'],native_tests=8,ordinary_and_pty_tests=6,skips=0,uid=65534,gid=65534,groups=[],private_tmpfs_bytes=134217728,namespace_drained=True,host_native_fixtures_preserved=True,custody=archive.name,custody_sha256=sha(archive),custody_members=len(manifest)+1,macos_runtime_qualified=False,windows_runtime_changed=False,required_hosted_checks_pending=True,authority_delta='none',beta=False,rc=False,game_execution=False,power_loss=False,physical_ext4=False)
    evidence.write_text(json.dumps(proof,indent=2)+'\n')
    notes=R/Q/'ExecPlan.md'
    with notes.open('a',encoding='utf-8',newline='\n') as f:
        f.write('\n### Required macOS short-lived-child startup repair\n\nThe combined-source macOS presentation fixture executed and exited zero, but parent process-group lookup had lost setup proof and cleanup recorded an unknown outcome. The child now emits a fixed-width acknowledgement after successful group setup. The supervisor retains that proof before callbacks, cancellation and cleanup; it remains separate from exec success. One immediate bounded nonblocking follow-up observes buffered EOF or errno before cancellation. Missing, partial, duplicate and malformed frames cannot grant dispatch authority, and no acknowledgement restores numeric signaling after consuming wait. Independent review and eight native plus six ordinary/PTY Linux checks pass without skips. Original failures and corrections remain in custody. macOS runtime qualification and all required combined-source checks remain pending; this closes no game, Beta or RC gate.\n\nEvidence: `evidence/posix-child-group-startup-ack.v1.json` and its hash-closed custody archive.\n')
    paths=set(assurance['source_files_sha256'])|{Q+'/ExecPlan.md',Q+'/evidence/'+archive.name,Q+'/evidence/'+evidence.name}
    actual=set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R,text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R,text=True).splitlines())
    assert actual==paths,(actual-paths,paths-actual)
    for label in ('policy','detect','plan'):run(label,['py','-3','-B','.aide/scripts/aide_lite.py','git',label])
    run('strict',['py','-3','-B','tools/strict_check.py'],1800)
    message='fix(process): retain explicit POSIX child group setup proof\n\nA short-lived child may be waitable after parent group lookup fails.\nKeep child setup proof separate from execution and consuming wait.\n\nWork-Item: FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01\nEvidence-Ref: '+Q+'/evidence/'+evidence.name+'\n'
    msg=E/'tui-posix-startup-ack-commit-message-01.txt';msg.write_text(message,encoding='utf-8',newline='\n')
    run('message',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--message',message])
    changes=[dict(path=n,state='content',sha256=sha(R/n),git_blob_oid=git('hash-object','--path',n,str(R/n)),ownership='task_owned') for n in sorted(paths)]
    snapshot=hashlib.sha256((json.dumps(changes,indent=2,sort_keys=True,separators=(',',': '))+'\n').encode()).hexdigest()
    commit_review=E/'tui-posix-startup-ack-commit-review-01.json'
    commit_review.write_text(json.dumps(dict(schema_version='aide.git-commit-review.v1',verdict='PASS',reviewer='/root',runtime_author='/root',source_reviewer='/root/macos_supervisor_failure_review',independent_source_review_sha256=proof['independent_review_sha256'],branch=BRANCH,base_commit=BASE,snapshot_sha256=snapshot,message_sha256=sha(msg),review='frozen runtime/test source independently accepted; exact Linux execution/drain/log/custody reviewed and original failures retained; added notes and receipt accurately leave macOS/required hosted checks pending',linux_result_sha256=proof['linux_result_sha256'],custody_sha256=proof['custody_sha256']),indent=2)+'\n')
    classification=E/'tui-posix-startup-ack-commit-classification-01.json'
    classification.write_text(json.dumps(dict(schema_version='aide.git-commit-classification.v1',branch=BRANCH,base_commit=BASE,work_item='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01',snapshot_sha256=snapshot,message_sha256=sha(msg),changed_paths=changes,reviews=[dict(path=str(commit_review),sha256=sha(commit_review),verdict='PASS')]),indent=2)+'\n')
    helper=['py','-3','-B','.aide/scripts/aide_lite.py','git','commit-plan','--classification',str(classification),'--message-file',str(msg)]
    run('plan-stage',helper);run('stage',['git','add','--',*sorted(paths)]);run('diff',['git','diff','--cached','--check']);run('plan-commit',helper)
    assert git('rev-parse','HEAD')==BASE
    run('commit',['git','commit','-F',str(msg)])
    run('range',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--range',DEV+'..HEAD'])
    assert not git('status','--porcelain')
    record.update(status='COMMITTED_QUALIFIED_POSIX_CHILD_SETUP_ACK',source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),evidence_sha256=sha(evidence),review_sha256=sha(commit_review),independent_review_sha256=proof['independent_review_sha256'],remote_not_pushed=True)
except BaseException as exc:record.update(status='ACTIONABLE_POSIX_CHILD_SETUP_ACK_COMMIT_FAILURE',error=str(exc),traceback=traceback.format_exc())
finally:save();print(json.dumps({k:v for k,v in record.items() if k!='commands'},indent=2))
raise SystemExit(0 if record['status']=='COMMITTED_QUALIFIED_POSIX_CHILD_SETUP_ACK' else 1)
