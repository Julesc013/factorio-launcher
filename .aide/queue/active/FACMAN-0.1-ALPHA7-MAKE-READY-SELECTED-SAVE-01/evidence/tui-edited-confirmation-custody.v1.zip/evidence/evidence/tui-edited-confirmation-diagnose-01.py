import datetime,hashlib,json,os,shutil,subprocess,sys,traceback,zipfile
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e');E=W/'evidence';G=W/'t/j3/ge1';F=W/'t/j3/edited-confirmation-e1';C=F/'consumer';workspace=F/'workspace';sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def inv(root):return {p.relative_to(root).as_posix():('directory' if p.is_dir() else sha(p)) for p in sorted(root.rglob('*'))}
def git(*args):return subprocess.check_output(['git','-c','core.safecrlf=false',*args],cwd=R).decode().strip()
assert git('rev-parse','HEAD')=='c51726567dd3bc4becd9afb80546b5a3ef2250bd' and git('rev-parse','HEAD^{tree}')=='9155a2905afbb2e10ac5a08aaaf1329704dd47af' and not git('status','--porcelain')
marker=W/'.facman-development-root.v1.json';marker_before=sha(marker);assert json.loads(marker.read_bytes())['task_id']=='task/facman-world-restore-retention-01'
binding=json.loads((E/'snapshot-producer-delivered-binding-01.json').read_bytes());extract=json.loads((E/binding['extract_result']).read_bytes());assert Path(binding['package_root'])==G and sha(G/'bin/facman.exe')==binding['backend_sha256']
package_before=inv(G);assert {n:h for n,h in package_before.items() if h!='directory'}==extract['file_inventory'] and extract['original_file_count']==599
source_names=['apps/tui/tui_product_model.cpp','apps/tui/tui_product_shell.cpp','tests/native/facman_tui_product_model_smoke.cpp','tests/test_tui_product.py'];source_before={n:sha(R/n) for n in source_names}
fixture_names=['tests/fixtures/fake_factorio_install/bin/x64/factorio.exe.stub','tests/fixtures/fake_factorio_install/data/base/info.json','tests/fixtures/factorio_saves/valid_simple_save/starter.zip'];fixtures_before={n:sha(R/n) for n in fixture_names}
assert not F.exists() and F.resolve().parent==(W/'t/j3').resolve() and shutil.disk_usage(W).free-16*1024**2>12*1024**3
F.mkdir();C.mkdir();owned.write_json(F/'.facman-stale-edit-fixture.v1.json',dict(owner='facman-development',kind='synthetic-diagnostic-fixture',parent_task_marker_sha256=marker_before,path=str(F),scope='retained Gge1 ordinary TUI edit-after-confirmation diagnosis only',source=git('rev-parse','HEAD')))
env={k:v for k,v in os.environ.items() if not k.upper().startswith(('FACMAN_','FLAUNCH_','ULK_','USK_'))};system=os.environ['SystemRoot'];env.update(PATH=str(Path(system)/'System32')+os.pathsep+system,TEMP=str(F),TMP=str(F),PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1')
out=E/'tui-edited-confirmation-diagnosis-01.json';assert not out.exists();record=dict(schema='facman.tui_edited_confirmation_diagnosis.v1',status='STARTED',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),local_source=git('rev-parse','HEAD'),package_source=binding['source'],tree=binding['tree'],backend_sha256=sha(G/'bin/facman.exe'),package_root=str(G),fixture_root=str(F),external_cwd=str(C),minimal_PATH=env['PATH'],runtime_provider_overrides=False,source_files_before=source_before,fixture_files_before=fixtures_before,commands=[]);budget=owned.Budget(180,40)
save=lambda:owned.write_json(out,record)
def run(label,args,stdin=None):
 assert len(record['commands'])<12
 cap=owned.command([str(G/'bin/facman.exe'),*map(str,args)],cwd=C,environment=env,timeout=40,budget=budget,directory=E/('tui-edited-confirmation-'+label+'-01'),input_bytes=(stdin or '').encode('utf-8'),output_limit=8*1024**2,wait_for_job_empty_after_primary=True)
 row=dict(label=label,argv=list(map(str,args)),stdin=stdin,exit_code=cap.returncode,termination=cap.receipt['termination'],job_empty=cap.receipt['job_empty_observed'],primary_stopped=cap.receipt['primary_stopped'],receipt_sha256=sha(cap.directory/'receipt.json'),stdout_sha256=sha(cap.directory/'stdout.raw'),stderr_sha256=sha(cap.directory/'stderr.raw'));record['commands'].append(row);save()
 assert cap.ok and not cap.stderr and cap.receipt['job_empty_observed'] and cap.receipt['primary_stopped'] and not cap.receipt['job_terminated'],label
 return cap.stdout.decode('utf-8').replace('\r\n','\n')
def machine(label,*args):return json.loads(run(label,['--workspace',str(workspace),*args,'--json']))['payload']
try:
 backend=machine('identity','product','inspect')['backend_identity'];assert backend['package']['verified'] and backend['package']['files_verified']==598 and backend['build']['source_revision']==binding['source'];record['actual_backend_identity']=backend
 machine('register','installs','import',R/'tests/fixtures/fake_factorio_install','--id','fixture')
 machine('instance','instances','create','Main','--id','main','--install','fixture')
 instance=workspace/'instances/main';shutil.copyfile(R/'tests/fixtures/factorio_saves/valid_simple_save/starter.zip',instance/'saves/starter.zip')
 projected=machine('query','presentation','query','saves','--instance','main');index=next(i for i,a in enumerate(projected['available_semantic_actions']) if a['action_id']=='snapshots.create')
 assert projected['available_semantic_actions'][index]['availability']=='available'
 opening='5\n'+'tab\n'*index+'space\nselected_instance_id=main\nsnapshot_id=first\nsave=starter.zip\nspace\n'
 before=inv(workspace);protected=inv(instance),inv(workspace/'installs');record['workspace_before']=before;record['protected_inputs_before']=protected;save()
 control=run('edit-then-cancel-control',['tui','--workspace',str(workspace),'--ordinary','--plain'],opening+'snapshot_id=second\n6\nq\n')
 assert 'Confirm Create instance snapshot' in control and 'snapshot_id=second (required)' in control and inv(workspace)==before
 record['control_edit_without_second_activation_cancel_unchanged']=True;save()
 text=run('edit-one-activation-then-cancel',['tui','--workspace',str(workspace),'--ordinary','--plain'],opening+'snapshot_id=second\nspace\n6\nq\n')
 receipts=[p for p in (workspace/'.facman/action-receipts-v2').glob('*.v2.json') if json.loads(p.read_bytes())['action_id']=='snapshots.create'];assert len(receipts)==1
 path=receipts[0];receipt=json.loads(path.read_bytes());request=json.loads(receipt['request_json']);outcome=json.loads(receipt['result_json'])
 (E/'tui-edited-confirmation-owner-receipt-01.json').write_bytes(path.read_bytes())
 assert request['snapshot_id']=='second' and request['confirmation']=='explicit' and request['save']=='starter.zip' and outcome['outcome']=='completed'
 assert (workspace/'snapshots/main/second.zip').is_file() and not (workspace/'snapshots/main/first.zip').exists()
 assert outcome['action_payload']['path']==str(workspace/'snapshots/main/second.zip')
 assert '  Operation: Snapshot created: '+outcome['action_payload']['path'] in text
 confirmations=[i for i,line in enumerate(text.splitlines()) if line.startswith('Status: Confirm Create instance snapshot')];assert len(confirmations)==1
 # Exactly one initial confirmation was rendered; after editing, one activation
 # published second.zip before navigation could cancel it.
 inspect=machine('inspect-second','snapshots','inspect','main','second');assert inspect['world_bundle_state']=='available'
 with zipfile.ZipFile(workspace/'snapshots/main/second.zip') as z:assert z.read('saves/starter.zip')==(R/'tests/fixtures/factorio_saves/valid_simple_save/starter.zip').read_bytes()
 assert protected==(inv(instance),inv(workspace/'installs')) and before!=inv(workspace)
 record.update(status='REPRODUCED_PRODUCT_CONFIRMATION_REUSED_AFTER_INPUT_EDIT',expected='Changed input requires a fresh confirmation. One activation after edit then Cancel should not dispatch or change workspace.',actual='Initial confirmation for first remains pending after editing snapshot_id to second. One subsequent activation dispatches second under explicit confirmation before Cancel/navigation.',initial_confirmation_lines=len(confirmations),owner_receipt=receipt,request=request,outcome=outcome,world_bundle_state=inspect['world_bundle_state'],archive_sha256=sha(workspace/'snapshots/main/second.zip'),workspace_after=inv(workspace),protected_inputs_after=protected)
except BaseException as error:record.update(status='DIAGNOSTIC_FAILURE_RETAINED',error=str(error),traceback=traceback.format_exc())
finally:
 record.update(package_inventory_before=package_before,package_inventory_after=inv(G),source_files_after={n:sha(R/n) for n in source_names},fixture_files_after={n:sha(R/n) for n in fixture_names},marker_unchanged=sha(marker)==marker_before,source_clean=not git('status','--porcelain'))
 assert record['package_inventory_before']==record['package_inventory_after'] and source_before==record['source_files_after'] and fixtures_before==record['fixture_files_after'] and record['marker_unchanged'] and record['source_clean'];save();print(json.dumps(dict(status=record['status'],calls=len(record['commands']),error=record.get('error'))),flush=True)
raise SystemExit(0 if record['status']=='REPRODUCED_PRODUCT_CONFIRMATION_REUSED_AFTER_INPUT_EDIT' else 1)
