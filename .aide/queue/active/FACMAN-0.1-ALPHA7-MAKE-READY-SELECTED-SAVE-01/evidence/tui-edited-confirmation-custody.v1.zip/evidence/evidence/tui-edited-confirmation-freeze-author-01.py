import datetime,difflib,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e');E=W/'evidence';B=W/'native-developer';sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git','-c','core.safecrlf=false',*a],cwd=R)
assert git('branch','--show-current').decode().strip()=='task/facman-tui-edited-confirmation-01'
assert git('rev-parse','HEAD').decode().strip()=='c51726567dd3bc4becd9afb80546b5a3ef2250bd'
pre=json.loads((E/'tui-edited-confirmation-prebuild-result-01.json').read_bytes());q=json.loads((E/'tui-edited-confirmation-qualification-result-02.json').read_bytes())
notes={'.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01/tui-edited-confirmation.md','.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01/ExecPlan.md'}
for n,v in pre['files'].items():
 if n not in notes:assert sha(R/n)==v['sha256'],n
assert q['source_fixture_before']=={p.relative_to(R).as_posix():sha(p) for p in (R/'tests/fixtures').rglob('*') if p.is_file()}
assert not git('diff','--name-only','HEAD','--','runtime','contracts','tests/golden','tests/fixtures','apps/tui/tui_product_shell.cpp').decode().strip()
marker=W/'.facman-development-root.v1.json';assert json.loads(marker.read_bytes())['task_id']=='task/facman-world-restore-retention-01'
env=dict(os.environ,FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',FACMAN_MIN_FREE_GIB='12')
checks=[]
for name,args in [('engineering',['py','-3','-B','tools/engineering_quality_check.py']),('source-format',['py','-3','-B','tools/source_format_check.py']),('metadata',['py','-3','-B','tools/codegen/generate_metadata.py','--check']),('contracts',['py','-3','-B','tools/codegen/generate_contracts.py','--check']),('truth',['py','-3','-B','tools/project_state.py','--validate']),('diff',['git','-c','core.safecrlf=false','diff','--check']),('strict',['py','-3','-B','tools/strict_check.py']),('portable-aide',['py','-3','-B','.aide/scripts/aide_lite.py','test'])]:
 cap=owned.command(args,cwd=R,environment=env,timeout=900,directory=E/('tui-edited-confirmation-frozen-'+name+'-01'),output_limit=8*1024**2,wait_for_job_empty_after_primary=True)
 checks.append(dict(name=name,exit_code=cap.returncode,receipt_sha256=sha(cap.directory/'receipt.json'),directory=str(cap.directory)))
 assert cap.ok and cap.receipt['job_empty_observed'] and cap.receipt['primary_stopped'] and not cap.receipt['job_terminated'],(name,(cap.stdout+cap.stderr).decode(errors='replace')[-5000:])
 print(name,cap.returncode,flush=True)
# Preserve original controller terminal error and incomplete metadata result without rewriting them.
error=E/'tui-edited-confirmation-runner02-terminal-error-01.json';assert not error.exists();owned.write_json(error,dict(schema='facman.external_qualification_controller_error.v1',observed_session=61380,controller_exit_code=1,error_type='FileNotFoundError',error_path=str(B/'tests/native/Release/facman_tui_smoke.exe'),phase='final_metadata_assembly_after_all_commands',actual_output_directory=str(B/'Release'),original_result=str(E/'tui-edited-confirmation-qualification-result-02.json'),original_result_sha256=sha(E/'tui-edited-confirmation-qualification-result-02.json'),product_or_test_failure=False,statement='The original runner returned exit 1 after all product and static commands completed; its unfinished result is preserved. Correct native output paths are independently inventoried here without rerunning those commands.'))
ordinary=(E/'tui-edited-confirmation-ordinary-02/stderr.raw').read_text();assert 'Ran 11 tests' in ordinary and 'OK (skipped=1)' in ordinary
native=(E/'tui-edited-confirmation-native-02/stdout.raw').read_text();assert '100% tests passed, 0 tests failed out of 2' in native
legacy=(E/'tui-edited-confirmation-legacy-receipt-02/stderr.raw').read_text();assert 'Ran 1 test' in legacy and 'OK' in legacy
for cmd in q['commands']:
 receipt=json.loads((Path(cmd['directory'])/'receipt.json').read_bytes());assert receipt['termination']=='completed' and receipt['job_empty_observed'] and receipt['primary_stopped'] and not receipt['job_terminated']
 if cmd['name'] not in ['doctor','final-doctor']:assert cmd['exit_code']==0
fd=json.loads((E/'tui-edited-confirmation-final-doctor-02/stdout.raw').read_bytes());assert set(fd['violations'])<={'unmanaged_secondary_worktrees_present'} and fd['task_root_bytes']<20*1024**3
assert shutil.disk_usage(W).free>=12*1024**3
names=sorted(set(git('diff','--name-only','HEAD').decode().splitlines()+git('ls-files','--others','--exclude-standard').decode().splitlines()));assert set(names)==set(pre['files'])
diff=git('diff','--binary','HEAD').decode()
for n in git('ls-files','--others','--exclude-standard').decode().splitlines():diff+=''.join(difflib.unified_diff([], (R/n).read_text(encoding='utf-8').splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+n))
diffpath=E/'tui-edited-confirmation-final-source-01.diff';assert not diffpath.exists();diffpath.write_text(diff,encoding='utf-8',newline='\n')
source={n:dict(sha256=sha(R/n),bytes=(R/n).stat().st_size) for n in names}
assert all(sha(R/n)==v['sha256'] for n,v in source.items())
compiled={n:dict(path=str(B/'Release'/n),sha256=sha(B/'Release'/n),bytes=(B/'Release'/n).stat().st_size) for n in ['facman.exe','facman_tui_smoke.exe','facman_tui_product_model_smoke.exe']}
identity=B/'generated/include/facman/build_identity.hpp';assert q['compiled_identity']['sha256']==sha(identity) and 'c51726567dd3bc4becd9afb80546b5a3ef2250bd' in identity.read_text()
for n,h in q['compiled_source_before'].items():assert sha(R/n)==h
# Raw custody includes the retained diagnosis, prebuild and failed/successful qualification paths, not products.
files=[]
for p in E.iterdir():
 if p.name.startswith('tui-edited-confirmation-') and p.name not in ['tui-edited-confirmation-author-packet-01.json','tui-edited-confirmation-author-raw-01.sha256']:
  files.extend([f for f in p.rglob('*') if f.is_file()] if p.is_dir() else [p])
files=sorted(set(files),key=lambda p:p.relative_to(E).as_posix())
custody=E/'tui-edited-confirmation-author-raw-01.sha256';assert not custody.exists();custody.write_text(''.join(sha(p)+'  '+p.relative_to(E).as_posix()+'\n' for p in files),encoding='utf-8',newline='\n')
receipts=[]
for p in files:
 if p.name=='receipt.json':
  j=json.loads(p.read_bytes())
  if 'job_empty_observed' in j:receipts.append(dict(path=p.relative_to(E).as_posix(),termination=j['termination'],exit_code=j.get('returncode',j.get('exit_code')),primary_stopped=j['primary_stopped'],job_empty=j['job_empty_observed'],job_terminated=j['job_terminated']))
assert all(p['primary_stopped'] and p['job_empty'] and not p['job_terminated'] for p in receipts)
packet=dict(schema='facman.tui_edited_confirmation_author_packet.v1',status='PASS_PRODUCT_AND_REQUIRED_LOCAL_CHECKS_WITH_RETAINED_CONTROLLER_FAILURES',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),branch=git('branch','--show-current').decode().strip(),source_base=git('rev-parse','HEAD').decode().strip(),source_files=source,compiled_source_hashes=q['compiled_source_before'],source_and_fixtures_unchanged_during_qualification=True,post_qualification_changes='Two current WorkUnit Markdown notes only; final static gates repeated on these final bytes.',diff=dict(path=str(diffpath),sha256=sha(diffpath),bytes=diffpath.stat().st_size),compiled_binaries=compiled,compiled_identity=q['compiled_identity'],cache=dict(path=str(B/'CMakeCache.txt'),sha256=sha(B/'CMakeCache.txt'),generator='Visual Studio 18 2026',configuration='Release',provider_roots=q['resource']['provider_roots'],provider_pins=q['resource']['provider_pins'],prepare=False),build=dict(successful_builds=1,retained_before_compilation_target_failure=True,normal_helper_clean_first=True,workers=2),qualification=dict(native_passed=2,native_controls='7 changed/empty/optional/no-op rows plus invalid-to-correct/re-arm/no-op sequence',ordinary_discovered=11,ordinary_passed=10,ordinary_skips=[dict(method='test_ordinary_selected_save_missing_configuration_then_context_linux',reason='unsupported: ordinary POSIX publication is Linux only')],new_ordinary_methods_passed=2,legacy_twenty_field_request_and_replay_passed=1,new_endurance_runs=0,prior_endurance_claim='Retained prior64-op result only; this edit did not rerun it.',final_static_checks=checks),retained_failures=[dict(path=str(E/'tui-edited-confirmation-qualification-result-01.json'),sha256=sha(E/'tui-edited-confirmation-qualification-result-01.json'),kind='wrong CMake target facman: MSB1009 before compilation; corrected to existing facman_cli'),dict(path=str(error),sha256=sha(error),kind='runner02 final native output metadata path; every build/test/static command already passed; original result remains incomplete')],qualification_commands=q['commands'],resources=dict(before=q['resource'],after_measured_bytes=fd['task_root_bytes'],after_free_bytes=shutil.disk_usage(W).free,roots=len(fd['task_roots']),reserve_bytes=12*1024**3,cap_bytes=20*1024**3,marker_sha256=sha(marker),marker_task_id='task/facman-world-restore-retention-01'),raw_custody=dict(path=str(custody),sha256=sha(custody),files=len(files),bytes=sum(p.stat().st_size for p in files)),process_receipts=receipts,process_receipt_count=len(receipts),all_recorded_jobs_stopped_empty=True,metadata_only_prior_accepted_projection_sha256='118762fe67af83932d91508ec6e826afc6e35dbc49b523d50d77ea0067d3c347',unchanged=['typed owner','wire/schema/fingerprints','durable receipts','golden fixtures','snapshot transaction/recovery','providers','original delivered packages','real Factorio'],limits=['Windows source-cache execution only','Linux-only ordinary publication method explicitly skipped','No current-head hosted CI or current-package acceptance','No new endurance claim','No real Play, human, complete F11 or release claim'],git_mutations=False,provider_edits=False,game_edits=False,new_roots_or_caches=False)
out=E/'tui-edited-confirmation-author-packet-01.json';assert not out.exists();owned.write_json(out,packet);print(json.dumps(dict(status=packet['status'],packet=str(out),sha256=sha(out),diff_sha256=sha(diffpath),custody_sha256=sha(custody),raw_files=len(files),jobs=len(receipts),source_files=len(source)),indent=2),flush=True)
