import hashlib,json,subprocess
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_bytes())
packet=E/'tui-edited-confirmation-author-packet-01.json';assert sha(packet)=='53bab3e7fb12bfbb5d1947baf7e8e990c4e6eea2bd6861276087e8876e8fdc44'
p=load(packet);assert p['status']=='PASS_PRODUCT_AND_REQUIRED_LOCAL_CHECKS_WITH_RETAINED_CONTROLLER_FAILURES'
git=lambda *a:subprocess.check_output(['git','-c','core.safecrlf=false',*a],cwd=R,text=True).strip()
assert git('rev-parse','HEAD')==p['source_base']=='c51726567dd3bc4becd9afb80546b5a3ef2250bd'
assert git('branch','--show-current')==p['branch']=='task/facman-tui-edited-confirmation-01'
dirty=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
assert dirty<=set(p['source_files'])|{'.aide/memory/project-state.md','.aide/memory/project-state.v2.json','README.md'}
for n in dirty-set(p['source_files']):assert git('hash-object','--path',n,str(R/n))==git('rev-parse','HEAD:'+n)
assert len(p['source_files'])==10
for n,row in p['source_files'].items():assert sha(R/n)==row['sha256'] and (R/n).stat().st_size==row['bytes']
for n,digest in p['compiled_source_hashes'].items():assert sha(R/n)==digest
assert sha(p['diff']['path'])==p['diff']['sha256']
assert sha(p['raw_custody']['path'])==p['raw_custody']['sha256']
custody={}
for line in Path(p['raw_custody']['path']).read_text(encoding='utf-8').splitlines():
 digest,name=line.split('  ',1);path=(E/name).resolve(strict=True);assert path.is_relative_to(W.resolve()) and not path.is_symlink() and sha(path)==digest
 custody[name]=path
assert len(custody)==p['raw_custody']['files']==219 and sum(path.stat().st_size for path in custody.values())==p['raw_custody']['bytes']==838606
def receipt(path):
 path=Path(path)
 if not path.is_absolute():path=E/path
 assert path.relative_to(E).as_posix() in custody
 r=load(path);assert r['termination']=='completed' and r['primary_stopped'] and r['job_empty_observed'] and not r['job_terminated']
 for stream in ('stdout','stderr'):assert sha(path.parent/r[stream]['file'])==r[stream]['sha256']
 return r
for row in p['process_receipts']:receipt(row['path'])
assert len(p['process_receipts'])==p['process_receipt_count']==50
commands={row['name']:row for row in p['qualification_commands']}
for row in p['qualification_commands']:
 path=Path(row['directory'])/'receipt.json';assert sha(path)==row['receipt_sha256'];r=receipt(path)
 assert r['exit_code']==row['exit_code']==(1 if row['name'] in ('doctor','doctor-after','final-doctor') else 0),row['name']
build=receipt(Path(commands['build']['directory'])/'receipt.json');assert '--clean-first' in build['command'] and '/p:TrackFileAccess=false' in build['command']
raw=Path(commands['native']['directory']).joinpath('stdout.raw').read_text(encoding='utf-8');assert '100% tests passed, 0 tests failed out of 2' in raw
raw=Path(commands['ordinary']['directory']).joinpath('stderr.raw').read_text(encoding='utf-8');assert 'Ran 11 tests' in raw and 'OK (skipped=1)' in raw
for name in ('test_ordinary_edited_snapshot_name_requires_fresh_confirmation_before_cancel','test_ordinary_edited_snapshot_name_completes_only_after_renewed_confirmation'):
 lines=[line for line in raw.splitlines() if line.startswith(name+' (')];assert len(lines)==1 and lines[0].endswith(' ... ok')
q=p['qualification'];assert q['ordinary_discovered']==11 and q['ordinary_passed']==10 and len(q['ordinary_skips'])==1
assert q['native_passed']==2 and q['new_ordinary_methods_passed']==2 and q['legacy_twenty_field_request_and_replay_passed']==1 and q['new_endurance_runs']==0
for row in q['final_static_checks']:
 path=Path(row['directory'])/'receipt.json';assert sha(path)==row['receipt_sha256'] and receipt(path)['exit_code']==row['exit_code']==0
for name,row in p['compiled_binaries'].items():assert sha(row['path'])==row['sha256']
assert p['compiled_binaries']['facman.exe']['sha256']=='acb5dc1c890151d67ca969687c975f272fbe0724d82ec5c5b7c6f655aafa2b4b'
assert sha(p['compiled_identity']['path'])==p['compiled_identity']['sha256'] and p['source_base'] in p['compiled_identity']['text']
assert 'source_dirty = true' in p['compiled_identity']['text']
assert sha(p['cache']['path'])==p['cache']['sha256']
res=p['resources'];assert res['roots']==8 and res['after_measured_bytes']<res['cap_bytes']==20*1024**3
assert res['after_free_bytes']>=res['reserve_bytes']==12*1024**3
assert sha(W/'.facman-development-root.v1.json')==res['marker_sha256'] and res['marker_task_id']=='task/facman-world-restore-retention-01'
assert len(p['retained_failures'])==2 and p['source_and_fixtures_unchanged_during_qualification']
assert not p['git_mutations'] and not p['provider_edits'] and not p['game_edits'] and not p['new_roots_or_caches']
model=(R/'apps/tui/tui_product_model.cpp').read_text(encoding='utf-8')
baseline=subprocess.check_output(['git','show','HEAD:apps/tui/tui_product_model.cpp'],cwd=R,text=True)
line='        if (next.form.values[event.name] != event.value) next.pending_action.clear();\n'
assert model.replace(line,'',1)==baseline and model.count(line)==1
out=E/'tui-edited-confirmation-independent-review-01.json';assert not out.exists()
v=dict(schema='facman.independent_tui_edited_confirmation_source_review.v1',verdict='PASS_SCOPED_SOURCE_FOR_REQUIRED_CURRENT_CI',
 source_base=p['source_base'],branch=p['branch'],author='/root/managed_update_acceptance',reviewer='/root',non_authoring=True,
 packet_sha256=sha(packet),reviewer_script_sha256=sha(__file__),source_files=p['source_files'],raw_artifacts_verified=219,closed_owned_jobs=50,
 one_product_line=True,changed_values_require_new_confirmation=True,effective_empty_and_same_values_retain_confirmation=True,
 ordinary_passed=10,ordinary_platform_skips=1,native_passed=2,legacy_twenty_field_regression=1,new_endurance_runs=0,
 original_broken_delivered_behavior_reproduced=True,prior_accepted_PR425_metadata_only=True,retained_controller_failures=2,
 typed_owner_wire_receipts_and_providers_unchanged=True,source_checkout_not_delivered=True,
 current_CI_pending=True,current_delivered_proof_pending=True,workunit_closed=False,real_game=False,human=False,beta=False,rc=False)
out.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in v.items() if k!='source_files'},indent=2))
