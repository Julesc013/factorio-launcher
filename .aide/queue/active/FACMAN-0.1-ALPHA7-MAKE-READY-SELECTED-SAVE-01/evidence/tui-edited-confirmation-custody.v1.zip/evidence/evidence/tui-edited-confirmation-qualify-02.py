import datetime,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e');E=W/'evidence';B=W/'native-developer';sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools import provider_canary_process as owned,native_build
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git','-c','core.safecrlf=false',*a],cwd=R)
env=dict(os.environ,FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',FACMAN_MIN_FREE_GIB='12',CMAKE_BUILD_PARALLEL_LEVEL='2',MSBUILDDISABLENODEREUSE='1',PYTHONPATH=str(R/'tests')+os.pathsep+str(R))
out=E/'tui-edited-confirmation-qualification-result-02.json';assert not out.exists()
frozen=json.loads((E/'tui-edited-confirmation-prebuild-result-01.json').read_bytes())
record=dict(schema='facman.tui_edited_confirmation_qualification.v1',status='ADMISSION',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),commands=[],source_base=git('rev-parse','HEAD').decode().strip(),source_freeze_sha256=sha(E/'tui-edited-confirmation-prebuild-result-01.json'),source_files=frozen['files'],source_fixture_before={p.relative_to(R).as_posix():sha(p) for p in (R/'tests/fixtures').rglob('*') if p.is_file()},builds=0,linux_builds=0,provider_prepare=False,real_game=False)
save=lambda:owned.write_json(out,record)
def check_source():
 assert git('branch','--show-current').decode().strip()=='task/facman-tui-edited-confirmation-01'
 assert git('rev-parse','HEAD').decode().strip()=='c51726567dd3bc4becd9afb80546b5a3ef2250bd'
 assert all(sha(R/n)==v['sha256'] for n,v in frozen['files'].items())
 assert json.loads((W/'.facman-development-root.v1.json').read_bytes())['task_id']=='task/facman-world-restore-retention-01'
def run(name,args,timeout=900,allow_failure=False):
 cap=owned.command(args,cwd=R,environment=env,timeout=timeout,directory=E/('tui-edited-confirmation-'+name+'-02'),output_limit=32*1024**2,wait_for_job_empty_after_primary=True)
 item=dict(name=name,argv=args,exit_code=cap.returncode,termination=cap.receipt['termination'],job_empty=cap.receipt['job_empty_observed'],primary_stopped=cap.receipt['primary_stopped'],job_terminated=cap.receipt['job_terminated'],directory=str(cap.directory),receipt_sha256=sha(cap.directory/'receipt.json'),stdout_sha256=sha(cap.directory/'stdout.raw'),stderr_sha256=sha(cap.directory/'stderr.raw'));record['commands'].append(item);save();print(name,cap.returncode,flush=True)
 if not item['job_empty'] or not item['primary_stopped'] or item['job_terminated'] or (not cap.ok and not allow_failure):
  record.update(status='FAIL_RETAINED',failed_command=name);save();print((cap.stdout+cap.stderr).decode(errors='replace')[-12000:],flush=True);raise SystemExit(cap.returncode or 1)
 return cap
check_source();save()
# Reuse previously reviewed foreign heavy-job observation and unbounded healthy admission wait.
previous=(E/'snapshot-producer-qualify-10.py').read_text();exec(previous[previous.index('probe="""'):previous.index("record['foreign_admission_wait_cycles']")].replace("snapshot-producer-heavy-admission-10.json","tui-edited-confirmation-heavy-admission-02.json"))
record['foreign_admission_wait_cycles']=wait_cycles;check_source()
run('paths',['py','-3','-B','tools/workspace_hygiene.py','paths'])
doctor=run('doctor',['py','-3','-B','tools/workspace_hygiene.py','doctor','--measure'],allow_failure=True)
d=json.loads(doctor.stdout);assert set(d['violations'])<= {'unmanaged_secondary_worktrees_present'};assert len(d['task_roots'])==8
peak=2*1024**3;free=shutil.disk_usage(W).free;assert d['task_root_bytes']+peak<20*1024**3 and free-peak>=12*1024**3
cache=(B/'CMakeCache.txt').read_text();settings={line.split('=',1)[0]:line.split('=',1)[1] for line in cache.splitlines() if '=' in line and not line.startswith('//')}
assert settings['CMAKE_HOME_DIRECTORY:INTERNAL'].lower()==R.as_posix().lower();assert settings['CMAKE_GENERATOR:INTERNAL']=='Visual Studio 18 2026'
provider_roots={k:Path(settings[k]) for k in ['FLAUNCH_UNIVERSAL_LAUNCHER_ROOT:PATH','FLAUNCH_UNIVERSAL_SETUP_ROOT:PATH']}
pins=['5479939ca5cbc9ee0f901608a92012778b4752ae','2749a15b835a6c1c9968598a2b434d85809691ad']
for p,pin in zip(provider_roots.values(),pins):assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=p).decode().strip()==pin
record['resource']=dict(task_root_count=8,measured_bytes=d['task_root_bytes'],conservative_additional_peak_bytes=peak,total_peak_bytes=d['task_root_bytes']+peak,free_bytes=free,reserve_bytes=12*1024**3,known_advisory=d['violations'],cache_before_sha256=sha(B/'CMakeCache.txt'),cache_settings=settings,provider_roots={k:str(v) for k,v in provider_roots.items()},provider_pins=pins,configuration='Release',workers=2,heavy_jobs=1);record['status']='BUILDING';save()
# Necessary same-cache identity regeneration only; no prepare or configuration override.
assert record['source_base'] in (B/'generated/include/facman/build_identity.hpp').read_text()
newcache=(B/'CMakeCache.txt').read_text()
for k in provider_roots:assert k+'='+settings[k] in newcache
native_build.require_disk_reserve(B)
args=native_build.command(B,'Release',['facman_cli','facman_tui_smoke','facman_tui_product_model_smoke'],{})
assert '--clean-first' in args and '/p:TrackFileAccess=false' in args and args[args.index('--parallel')+1]=='2'
record['builds']=1;record['build_command']=args;record['compiled_source_before']={n:sha(R/n) for n in ['apps/tui/tui_product_model.cpp','tests/native/facman_tui_product_model_smoke.cpp','apps/tui/tui_product_shell.cpp']};save()
run('build',args,7200)
check_source()
identity=B/'generated/include/facman/build_identity.hpp';text=identity.read_text();assert record['source_base'] in text and 'source_dirty = true' in text
record['compiled_identity']=dict(path=str(identity),sha256=sha(identity),text=text)
exe=B/'Release/facman.exe';assert exe.is_file();env.update(FACMAN_CLI_EXE=str(exe),FACMAN_TUI_EXE=str(exe))
run('native',['ctest','--test-dir',str(B),'-C','Release','-R','^(facman_tui_smoke|facman_tui_product_model_smoke)$','--output-on-failure'],300)
run('ordinary',['py','-3','-B','-m','unittest','test_tui_product','-v'],1800)
run('legacy-receipt',['py','-3','-B','-m','unittest','test_presentation_snapshot_create.PresentationSnapshotCreateTests.test_legacy_twenty_field_backup_request_bytes_and_replay_stay_exact','-v'],600)
for name,args in [('engineering',['py','-3','-B','tools/engineering_quality_check.py']),('source-format',['py','-3','-B','tools/source_format_check.py']),('metadata',['py','-3','-B','tools/codegen/generate_metadata.py','--check']),('contracts',['py','-3','-B','tools/codegen/generate_contracts.py','--check']),('truth',['py','-3','-B','tools/project_state.py','--validate']),('diff',['git','-c','core.safecrlf=false','diff','--check']),('strict',['py','-3','-B','tools/strict_check.py']),('portable-aide',['py','-3','-B','.aide/scripts/aide_lite.py','test'])]:run('final-'+name,args)
finaldoctor=run('final-doctor',['py','-3','-B','tools/workspace_hygiene.py','doctor','--measure'],allow_failure=True);fd=json.loads(finaldoctor.stdout);assert set(fd['violations'])<= {'unmanaged_secondary_worktrees_present'} and fd['task_root_bytes']<20*1024**3 and shutil.disk_usage(W).free>=12*1024**3
check_source();assert record['source_fixture_before']=={p.relative_to(R).as_posix():sha(p) for p in (R/'tests/fixtures').rglob('*') if p.is_file()}
record.update(status='PASS_FOCUSED_WINDOWS_QUALIFICATION',finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_unchanged=True,source_fixture_inputs_unchanged=True,final_measured_bytes=fd['task_root_bytes'],final_free_bytes=shutil.disk_usage(W).free,cache_after_sha256=sha(B/'CMakeCache.txt'),cli=dict(path=str(exe),sha256=sha(exe)),native_binaries={n:sha(B/'tests/native/Release'/ (n+'.exe')) for n in ['facman_tui_smoke','facman_tui_product_model_smoke']});save();print(json.dumps(dict(status=record['status'],path=str(out),sha256=sha(out))),flush=True)

