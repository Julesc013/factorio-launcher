import ast,datetime,difflib,hashlib,json,os,subprocess,sys
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e');E=W/'evidence';sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git','-c','core.safecrlf=false',*args],cwd=R)
assert git('branch','--show-current').decode().strip()=='task/facman-tui-edited-confirmation-01'
assert git('rev-parse','HEAD').decode().strip()=='c51726567dd3bc4becd9afb80546b5a3ef2250bd'
assert json.loads((W/'.facman-development-root.v1.json').read_bytes())['task_id']=='task/facman-world-restore-retention-01'
env=dict(os.environ,FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',FACMAN_MIN_FREE_GIB='12')
tracked=git('diff','--name-only','HEAD').decode().splitlines();untracked=git('ls-files','--others','--exclude-standard').decode().splitlines();names=sorted(tracked+untracked)
before={n:sha(R/n) for n in names};out=E/'tui-edited-confirmation-prebuild-result-01.json';assert not out.exists()
record=dict(schema='facman.tui_edited_confirmation_prebuild.v1',status='CHECKING_SOURCE_PENDING_ROOT_PREBUILD_REVIEW',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_base=git('rev-parse','HEAD').decode().strip(),branch=git('branch','--show-current').decode().strip(),source_before=before,commands=[],builds=0,product_tests_run=False,source_owner_wire_provider_changes=False)
save=lambda:owned.write_json(out,record)
save()
commands=[('engineering',['py','-3','-B','tools/engineering_quality_check.py']),('source-format',['py','-3','-B','tools/source_format_check.py']),('metadata',['py','-3','-B','tools/codegen/generate_metadata.py','--check']),('contracts',['py','-3','-B','tools/codegen/generate_contracts.py','--check']),('truth',['py','-3','-B','tools/project_state.py','--validate']),('diff',['git','-c','core.safecrlf=false','diff','--check']),('strict',['py','-3','-B','tools/strict_check.py']),('portable-aide',['py','-3','-B','.aide/scripts/aide_lite.py','test'])]
for name,args in commands:
 cap=owned.command(args,cwd=R,environment=env,timeout=900,directory=E/('tui-edited-confirmation-prebuild-'+name+'-01'),output_limit=8*1024**2,wait_for_job_empty_after_primary=True)
 record['commands'].append(dict(name=name,argv=args,exit_code=cap.returncode,termination=cap.receipt['termination'],job_empty=cap.receipt['job_empty_observed'],primary_stopped=cap.receipt['primary_stopped'],receipt_sha256=sha(cap.directory/'receipt.json'),stdout_sha256=sha(cap.directory/'stdout.raw'),stderr_sha256=sha(cap.directory/'stderr.raw')));save();print(name,cap.returncode,flush=True)
 if not cap.ok or not cap.receipt['job_empty_observed'] or not cap.receipt['primary_stopped'] or cap.receipt['job_terminated']:
  record.update(status='FAIL_RETAINED',failed_command=name);save();print((cap.stdout+cap.stderr).decode(errors='replace')[-12000:]);raise SystemExit(cap.returncode or 1)
assert before=={n:sha(R/n) for n in names}
module=ast.parse((R/'tests/test_tui_product.py').read_text());methods=[n.name for c in module.body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_ordinary_edited_snapshot_name_')];assert len(methods)==2
assert not git('diff','--name-only','HEAD','--','tests/golden','contracts','runtime','apps/tui/tui_product_shell.cpp','.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01/evidence/snapshot-producer.v1.json').decode().strip()
manifest=R/'.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01/evidence/snapshot-producer-accepted-projection-hashes-01.json';assert sha(manifest)=='118762fe67af83932d91508ec6e826afc6e35dbc49b523d50d77ea0067d3c347'
for n,v in json.loads(manifest.read_bytes())['files'].items():assert sha(manifest.parent/n)==v['sha256'] and (manifest.parent/n).read_bytes()==(E/n).read_bytes()
diff=git('diff','--binary','HEAD').decode('utf-8')
for n in untracked:diff+=''.join(difflib.unified_diff([], (R/n).read_text(encoding='utf-8').splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+n))
path=E/'tui-edited-confirmation-prebuild-source-01.diff';assert not path.exists();path.write_text(diff,encoding='utf-8',newline='\n')
record.update(status='FROZEN_SOURCE_STATIC_PASS_PENDING_ROOT_BUILD_ADMISSION',files={n:dict(sha256=sha(R/n),bytes=(R/n).stat().st_size,tracked=n in tracked) for n in names},diff=dict(path=str(path),sha256=sha(path),bytes=path.stat().st_size),new_ordinary_methods=methods,native_controls='7changed/empty/optional/no-op rows plus invalid-to-correct/re-arm/no-op sequence',metadata_only_projection=dict(records=3,bytes=21903,custody_bytes=606,custody_sha256=sha(manifest)),historical_pending_and_goldens_unchanged=True,source_unchanged_during_static_checks=True);save();print(json.dumps(dict(status=record['status'],packet=str(out),sha256=sha(out),diff=record['diff'],files=len(names),methods=methods),indent=2))
