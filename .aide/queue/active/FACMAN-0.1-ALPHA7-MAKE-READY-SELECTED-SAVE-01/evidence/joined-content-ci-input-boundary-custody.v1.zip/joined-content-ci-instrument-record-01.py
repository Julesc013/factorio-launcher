from pathlib import Path
import hashlib,json,os,subprocess,sys,zipfile
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent
Q=R/'.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
parent='87a2e4a1d6e15799a1df4d2da61f29bf068539dd';test='tests/test_windows_delivered_joined_gui.py'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==parent
assert sha(R/test)=='9bea8994d037d67dab9b0d6514aa8ed2c45862a400566034d957a7d8ae0ba4ba'
review=E/'joined-content-ci-gui-instrumentation-source-review-01.json'
assert sha(review)=='5e99624fe33e4783e65244dc5d4f5c787b43dfe72397b6a8b6106d10ad4bcfae'
assert not json.loads(review.read_bytes())['findings']
names=[p.name for p in [review,E/'joined-content-ci-gui-diagnosis-review-01.json',E/'joined-content-ci-gui-custody-binding-01.json',E/'joined-content-ci-descriptor-diag-actual-review-01.json',E/'joined-content-ci-descriptor-diag-preexecution-review-02.json',E/'joined-content-ci-descriptor-diag-01.json',E/'joined-content-ci-descriptor-diag-02.py',E/'joined-content-ci-descriptor-diag-plan-02.json',E/'joined-content-source-draft-13.json',E/'joined-content-ci-instrument-checks-01.py',E/'joined-content-ci-instrument-checks-01.json',Path(__file__)]]
# Exact selected evidence only; never walk fixture, package, build or unrelated roots.
dirs=['joined-content-ci-gui-custody-01','joined-content-ci-descriptor-diag-raw-01','joined-content-ci-descriptor-diag-owned-01','joined-content-ci-diag-doctor-owned-01','joined-content-ci-failure-job-01','joined-content-ci-failure-logs-01']
dirs += ['joined-content-ci-instrument-'+n+'-owned-01' for n in ('paths','inspect','noop','recover','policy','detect','plan','aide-lite')]
for d in dirs:
 root=E/d;assert root.is_dir() and not root.is_symlink()
 for p in root.rglob('*'):
  assert not p.is_symlink() and not getattr(p.lstat(),'st_file_attributes',0)&0x400
  if p.is_file():names.append(p.relative_to(E).as_posix())
names=sorted(set(names));assert len(names)<256
data={};size=0
for name in names:
 p=E/name;assert p.is_file() and not p.is_symlink()
 value=p.read_bytes();size+=len(value);assert len(value)<4*1024**2 and size<16*1024**2
 data[name]=value
inventory={n:dict(size_bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for n,v in data.items()}
canonical=(json.dumps(inventory,sort_keys=True,separators=(',',':'))+'\n').encode()
archive=Q/'evidence/joined-content-ci-input-boundary-custody.v1.zip';record=Q/'evidence/joined-content-ci-input-boundary.v1.json'
assert not archive.exists() and not record.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,value in data.items():z.writestr(name,value)
 z.writestr('inventory.v1.json',canonical)
assert archive.stat().st_size<4*1024**2
receipt=dict(schema='facman.joined_content_ci_input_boundary.v1',status='INSTRUMENTED_CANDIDATE_PENDING_FRESH_CI_AND_DELIVERED_PROOF',parent_source=parent,
 test=dict(path=test,sha256=sha(R/test)),runtime_source_packet_sha256=sha(E/'joined-content-source-draft-13.json'),
 failed_ci=dict(run=39094153111,job=117576954816,result='failure',unit_tests=2176,failures=1,errors=0,classified_skips=100,
  sole_failure='Existing ordinary WinForms first Make Ready input dialog absent after one native notification;35s assertion unchanged',
  log_sha256=sha(E/'joined-content-ci-failure-logs-01/stdout.raw'),result_sha256=sha(E/'joined-content-ci-gui-custody-01/result.json'),
  cause='Undetermined: native notification did not reach managed Click, or unchanged handler saw unavailable/empty descriptor. No action receipt or effect observed.'),
 local_diagnostic=dict(result_sha256=sha(E/'joined-content-ci-descriptor-diag-01.json'),actual_review_sha256=sha(E/'joined-content-ci-descriptor-diag-actual-review-01.json'),
  observation='Both exact-fixture scopes expose available joined v1 and four typed inputs;8 owned commands normal, all read-only inventories unchanged',
  scope='Existing developer build08 exact23 source-bound files;compiled base/dirty stamp differs. No GUI execution or original delivered qualification.'),
 instrumentation=dict(source_review_sha256=sha(review),checks_sha256=sha(E/'joined-content-ci-instrument-checks-01.json'),
  observations=['Exact packaged instances and launch_deck before first click and on first dialog failure','Displayed revision bound to launch_deck first7hex, preserving full caption','Owned HWND/thread/native-notification parameters,GetGUIThreadInfo and bounded WM_NULL parent/root responsiveness'],
  unchanged=['Single click','35s input-dialog assertion','Cancellation,stale-refusal,owner effects and preservation assertions','All production runtime and frontend bytes']),
 limitations=['Diagnostic queries and WM_NULL can alter timing;future pass is instrumented-candidate evidence,not proof of original race or managed Click acknowledgment','Original failed CI remains failed','Prior local native qualification retains its original split-image/forced-lifetime/skip limits','Fresh exact-head required CI and original newly produced package CLI,TUI and ordinary WinForms proof with independent actual review remain mandatory before merge','Historical local-joined-locked-content.v1.json delivery-pending field remains unresolved until later source-bound PR receipt','Whole WorkUnit and programme remain active'],
 custody=dict(path=archive.relative_to(R).as_posix(),sha256=sha(archive),entries=len(data)+1,inventory_sha256=hashlib.sha256(canonical).hexdigest(),expanded_bytes=size,scope='Exact selected negative CI/local diagnostic/static evidence; full original raw remains managed E. This ZIP is committed.'))
record.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
plan=Q/'ExecPlan.md';before=plan.read_bytes()
append=('\n\n### Joined locked-content CI input-boundary evidence\n\n'
 'The first source87 required Windows campaign failed before the existing healthy-content Make Ready input dialog; no content action was dispatched. Retained custody leaves managed Click delivery versus descriptor availability unresolved. The bounded exact-fixture developer-backend diagnostic exposes both joined-v1 descriptors and preserves all observed files; it does not exercise the GUI or qualify an original package.\n\n'
 'The next test-only candidate retains packaged scoped observations, launch-deck display revision and owned native thread responsiveness around the same single click and unchanged dialog/effect assertions. Diagnostic timing can change; a later pass cannot retrospectively establish a control race. Production bytes remain unchanged. Fresh exact-head CI and independently reviewed original-package CLI, ordinary TUI and ordinary WinForms proof remain required; the historical delivery-pending record is not resolved here.\n\n'
 'Evidence: `evidence/joined-content-ci-input-boundary.v1.json` and its exact compact custody. WorkUnit remains active.\n').encode()
plan.write_bytes(before+append)
out=E/'joined-content-ci-instrument-record-result-01.json';assert not out.exists()
out.write_text(json.dumps(dict(status='CONCRETE_RECORD_PENDING_REVIEW',record_sha256=sha(record),archive_sha256=sha(archive),entries=len(data)+1,execplan_before_sha256=hashlib.sha256(before).hexdigest(),execplan_append_bytes=len(append),execplan_sha256=sha(plan)),indent=2)+'\n',encoding='utf-8')
print(out.read_text(encoding='utf-8'))
