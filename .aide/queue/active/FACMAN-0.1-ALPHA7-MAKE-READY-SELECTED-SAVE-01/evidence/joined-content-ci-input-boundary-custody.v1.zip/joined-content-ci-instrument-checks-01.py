from pathlib import Path
import ast, hashlib, json, os, sys
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent
sys.path.insert(0,str(R));from tools import provider_canary_process as owned
env=dict(os.environ,FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
task='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
base=[sys.executable,'-B','.aide/scripts/aide_lite.py'];rows=[]
ast.parse((R/'tests/test_windows_delivered_joined_gui.py').read_text(encoding='utf-8'))
for name,args,limit in [
 ('paths',[sys.executable,'-B','tools/workspace_hygiene.py','paths'],120),
 ('inspect',base+['task','inspect','--task-id',task],120),
 ('noop',base+['task','noop-check','--task-id',task],120),
 ('recover',base+['task','recover','--task-id',task],120),
 ('policy',base+['git','policy'],120),('detect',base+['git','detect'],120),
 ('plan',base+['git','plan'],120),('aide-lite',base+['test'],900)]:
 c=owned.command(args,cwd=R,environment=env,timeout=limit,directory=E/('joined-content-ci-instrument-'+name+'-owned-01'),output_limit=4*1024**2,wait_for_job_empty_after_primary=True)
 row=dict(name=name,exit_code=c.returncode,receipt=str(c.directory/'receipt.json'),receipt_sha256=hashlib.sha256((c.directory/'receipt.json').read_bytes()).hexdigest());rows.append(row)
 assert c.returncode==0 and c.receipt['termination']=='completed' and c.receipt['primary_stopped'] and c.receipt['job_empty_observed'] and not c.receipt['job_terminated'],row
out=E/'joined-content-ci-instrument-checks-01.json';assert not out.exists()
out.write_text(json.dumps(dict(status='PASS_STATIC_PREFLIGHT_AND_AIDE',test_sha256=hashlib.sha256((R/'tests/test_windows_delivered_joined_gui.py').read_bytes()).hexdigest(),checks=rows),indent=2)+'\n',encoding='utf-8')
print(json.dumps(rows,indent=2))
