from pathlib import Path
import hashlib,json,os,sys,shutil,time,subprocess
from unittest.mock import patch
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent;F=W/'t/j3/jc-ci-descriptor-diag-01';RAW=E/'joined-content-ci-descriptor-diag-raw-01';B=W/'native-developer/Release/facman.exe';sys.path[:0]=[str(R/'tests'),str(R)]
from tools import provider_canary_process as owned,development_layout
import native_cli,test_configuration_reconciliation as existing,test_readiness_builtin_content as builtin,test_configuration_preparation as missing,test_selected_save_preparation as selected,test_make_ready_joined as joined,test_local_modset_solver as solver,unittest
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();source=json.loads((E/'joined-content-source-draft-13.json').read_bytes());assert all(sha(R/n)==h for n,h in source['files'].items())
assert sha(B)=='820187ed31f82874cc62a242d4d5e288e834a2ac708df45f1c61e3a17c05065e' and sha(W/development_layout.MARKER_NAME)=='30d72706c486ff20eed8b1947a920caa0a4e2d43820abbaf0ff78d12ab9f697c';development_layout.read_marker(W,R)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='87a2e4a1d6e15799a1df4d2da61f29bf068539dd' and not subprocess.check_output(['git','status','--porcelain'],cwd=R)
assert not F.exists() and not RAW.exists() and all(a.is_dir() and not a.is_symlink() and not getattr(a.lstat(),'st_file_attributes',0)&0x400 for a in (F.parent,*F.parent.parents))
F.mkdir();RAW.mkdir();(RAW/'cas').mkdir();C=F/'cwd';C.mkdir();I=F/'fixture-install-source';shutil.copytree(R/'tests/fixtures/fake_factorio_install',I);install_before={p.relative_to(I).as_posix():sha(p) for p in I.rglob('*') if p.is_file()}
marker=F/'.facman-diagnostic-fixture.v1.json';marker.write_text(json.dumps(dict(owner='joined-content-ci-descriptor-diag01',image_sha256=sha(B))),encoding='utf-8');marker_sha=sha(marker)
out=E/'joined-content-ci-descriptor-diag-01.json';assert not out.exists();result=dict(status='RUNNING_SOURCE_BOUND_LOCAL_DIAGNOSTIC',source='87a2e4a1d6e15799a1df4d2da61f29bf068539dd',runtime_source_packet_sha256=sha(E/'joined-content-source-draft-13.json'),image_sha256=sha(B),image_scope='Existing developer build08; compiled base/dirty stamp differs from committed candidate; same23 exact source files. Not delivered qualification.',calls=[],new_builds=0,new_candidates=0,gui_executed=False);start=time.monotonic()
def save():
 data=(json.dumps(result,indent=2)+'\n').encode();assert len(data)<4*1024**2 and sum(p.stat().st_size for p in RAW.rglob('*') if p.is_file())+len(data)<32*1024**2;out.write_bytes(data)
def inventory():
 rows={};size=0
 for p in F.rglob('*'):
  st=p.lstat();assert not p.is_symlink() and not getattr(st,'st_file_attributes',0)&0x400
  if not p.is_file():continue
  size+=st.st_size;assert size<16*1024**2 and st.st_size<4*1024**2 and len(rows)<512
  data=p.read_bytes();h=hashlib.sha256(data).hexdigest();target=RAW/'cas'/h
  if not target.exists():
   assert sum(q.stat().st_size for q in RAW.rglob('*') if q.is_file())+len(data)+9*1024**2<32*1024**2;target.write_bytes(data)
  rows[p.relative_to(F).as_posix()]=dict(sha256=h,bytes=len(data),native_file_identity=joined.file_identity(p))
 return rows
def machine(args,env=None):
 assert not env and len(result['calls'])<16 and time.monotonic()-start<300 and sha(B)==result['image_sha256']
 before=inventory();index=len(result['calls']);directory=RAW/f'call-{index:03d}'
 environment={k:v for k,v in os.environ.items() if not k.startswith(('FACMAN_','FLAUNCH_','ULK_','USK_','LD_','DYLD_'))};environment.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',PATH='',PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',TEMP=str(F),TMP=str(F))
 remaining=300-(time.monotonic()-start);assert remaining>0
 assert sum(p.stat().st_size for p in RAW.rglob('*') if p.is_file())+9*1024**2<32*1024**2,'Reserve actual combined streams, result and receipt before dispatch'
 captured=owned.command([str(B),*args],cwd=C,environment=environment,timeout=min(45,remaining),directory=directory,output_limit=2*1024**2,wait_for_job_empty_after_primary=True)
 assert len(captured.stdout)+len(captured.stderr)<4*1024**2
 result['calls'].append(dict(argv=list(args),receipt=str(directory/'receipt.json'),receipt_sha256=sha(directory/'receipt.json'),exit_code=captured.returncode,before=before,after=inventory()));save()
 assert captured.receipt['termination']=='completed' and captured.receipt['primary_stopped'] and captured.receipt['job_empty_observed'] and not captured.receipt['job_terminated']
 return captured.returncode,captured.stdout.decode('utf-8'),captured.stderr.decode('utf-8')
try:
 save()
 with patch.object(native_cli,'invoke_machine',machine),patch.object(builtin,'invoke_machine',machine),patch.object(missing,'invoke_machine',machine),patch.object(selected,'invoke_machine',machine),patch.object(joined,'invoke_machine',machine),patch.object(builtin,'FIXTURE_INSTALL',I),patch.object(solver,'FIXTURE_INSTALL',I):
  test=unittest.TestCase();test.query=lambda *a:missing.ConfigurationPreparationTests.query(test,*a)
  workspace=F/'workspace';instance,original,expected=existing.ExistingConfigurationTests.prepare(test,workspace,'load_save',raw=True,crlf=True)
  frozen=inventory();snapshots={}
  for scope in ('instances','launch_deck'):
   value=builtin.ReadinessBuiltinContentTests.query(test,workspace,scope,'load_save');snapshots[scope]=value
   assert frozen==inventory(),'Read-only observation changed fixture'
  result['snapshots']=snapshots
  result['eligibility']={scope:dict(revision=value['revision'],selected_context=value['selected_context'],descriptor=next((a for a in value['available_semantic_actions'] if a['action_id']=='readiness.prepare_joined'),None),joined_preparation=value['dependency_identities']['joined_preparation']) for scope,value in snapshots.items()}
  assert install_before=={p.relative_to(I).as_posix():sha(p) for p in I.rglob('*') if p.is_file()} and sha(marker)==marker_sha
  assert time.monotonic()-start<300
  result.update(status='LOCAL_DESCRIPTOR_BOUNDARY_OBSERVED_CI_CAUSE_UNDETERMINED',fixture_inventory=inventory(),fixture_install_unchanged=True,elapsed_seconds=time.monotonic()-start)
except BaseException as error:
 import traceback
 result.update(status='FAIL_RETAINED_LOCAL_DESCRIPTOR_DIAGNOSTIC',error=repr(error),traceback=traceback.format_exc())
finally:
 if result['status']=='LOCAL_DESCRIPTOR_BOUNDARY_OBSERVED_CI_CAUSE_UNDETERMINED' and time.monotonic()-start>=300:result.update(status='FAIL_RETAINED_LOCAL_DESCRIPTOR_DIAGNOSTIC',error='Final product deadline exceeded')
 save();print(json.dumps(dict(status=result['status'],eligibility={k:dict(revision=v['revision'],descriptor=v['descriptor'],refusal=v['joined_preparation']['refusal']) for k,v in result.get('eligibility',{}).items()},error=result.get('error')),indent=2))
sys.exit(0 if result['status']=='LOCAL_DESCRIPTOR_BOUNDARY_OBSERVED_CI_CAUSE_UNDETERMINED' else 1)
