import hashlib,json,os,subprocess,sys,traceback,zipfile
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent;BASE='674703a506751915ca8b286db094d10acce00f56';BRANCH='task/facman-macos-delivered-tui-ready-01';Q='.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.safecrlf',GIT_CONFIG_VALUE_0='false')
sys.dont_write_bytecode=True;sys.path.insert(0,str(R));from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
out=E/'macos-delivered-tui-candidate-commit-result-01.json';assert not out.exists();record=dict(status='SEALING_REVIEWED_DELIVERED_TUI_CANDIDATE',commands=[],goal_status_mutated=False,new_roots=0,new_native_builds=0,new_optional_campaigns=0)
def save():out.write_text(json.dumps(record,indent=2)+'\n')
def run(label,args,timeout=180):
 r=owned.command(args,cwd=R,environment=dict(os.environ),timeout=timeout,directory=E/('macos-delivered-tui-commit01-'+label),output_limit=4*1024*1024)
 record['commands'].append(dict(label=label,exit=r.returncode,receipt_sha256=sha(r.directory/'receipt.json')));save()
 assert r.ok and r.receipt['primary_stopped'] and r.receipt['job_empty_observed'],(label,r.stderr[-1800:].decode(errors='replace'),r.stdout[-1800:].decode(errors='replace'));return r
try:
 assert git('rev-parse','HEAD')==BASE and git('branch','--show-current')==BRANCH and not git('diff','--cached','--name-only')
 frozen=E/'macos-delivered-tui-frozen-02.json';f=json.loads(frozen.read_bytes());review=E/'macos-delivered-tui-independent-review-01.json';a=json.loads(review.read_bytes())
 assert a['verdict']=='PASS_FOR_REQUIRED_ACTUAL_DARWIN_CANDIDATE' and a['frozen_packet_sha256']==sha(frozen) and a['base_head']==BASE and a['non_authoring']
 paths=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines());assert paths==set(a['files_sha256']) and len(paths)==3
 for n,h in a['files_sha256'].items():assert sha(R/n)==h,n
 evidence=R/Q/'evidence/macos-delivered-tui-candidate.v1.json';archive=R/Q/'evidence/macos-delivered-tui-candidate-custody.v1.zip';assert not evidence.exists() and not archive.exists()
 names=['macos-delivered-tui-frozen-01.json','macos-delivered-tui-frozen-01.patch','macos-delivered-tui-frozen-02.json','macos-delivered-tui-frozen-02.patch',review.name,'macos-delivered-tui-root-review-01.py',Path(__file__).name]
 manifest={n:sha(E/n) for n in names}
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
  z.writestr('custody-manifest.json',json.dumps(manifest,indent=2,sort_keys=True)+'\n')
  for n in sorted(manifest):z.write(E/n,'evidence/'+n)
 with zipfile.ZipFile(archive) as z:
  for n,h in manifest.items():assert hashlib.sha256(z.read('evidence/'+n)).hexdigest()==h
 evidence.write_text(json.dumps(dict(schema='facman.macos_delivered_tui_reviewed_candidate.v1',base_head=BASE,files_sha256=a['files_sha256'],independent_review_sha256=sha(review),frozen_packet_sha256=sha(frozen),original_linux_campaign_ast_unchanged=True,standalone_darwin_methods_required=a['actual_darwin_required'],local_darwin_skips_counted_as_acceptance=0,produced_profile='macos_portable_tui_x64',normal_clean_canonical_package_factory=True,custody=archive.name,custody_sha256=sha(archive),actual_mac_package_pending=True,required_checks_pending=True,authority_delta='none',minimum_mac13_physical_host_qualified=False,named_physical_host=False,game=False,human=False,canonical_installed_desktop=False,full_make_ready=False,beta=False,rc=False),indent=2)+'\n')
 with (R/Q/'ExecPlan.md').open('a',encoding='utf-8',newline='\n') as stream:stream.write('\n### Delivered macOS Terminal/TUI candidate\n\nContinue from checked dev674703a5. Two standalone mandatory Darwin tests stage one genuine macOS TUI package with the normal clean canonical factory from the current explicit native build. Compiled source/provider/build/package identities and full hash closure bind the consumer bytes; the existing CLI observation corroborates the same build without granting TUI composition custody. A relocated read-only package runs with an empty PATH, cleared source/backend overrides and external consumer cwd. Ordinary linear and real PTY fullscreen scenarios cancel stale confirmation, prepare missing routing, refresh the revision and prepare exact selected-save context, preserve all other inputs and restore terminal state. The existing Linux campaign AST and test ID are unchanged apart from optional evidence capture. Exact terminal/effect bytes are exported in bounded compressed job-log custody before cleanup, with independent decode/hash verification required. Local Darwin skips grant zero acceptance. Both actual Mac package methods, all required checks and the full Mac native suite must pass before checked integration. Full MakeReady, minimum/named hosts, real game, human experience, canonical installed Desktop and Beta/RC remain open.\n\nEvidence: `evidence/macos-delivered-tui-candidate.v1.json` and hash-closed custody.\n')
 paths|={Q+'/ExecPlan.md',Q+'/evidence/'+evidence.name,Q+'/evidence/'+archive.name}
 assert set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())==paths
 for label in ('policy','detect','plan'):run(label,['py','-3','-B','.aide/scripts/aide_lite.py','git',label])
 run('strict',['py','-3','-B','tools/strict_check.py'],1800)
 message='test(tui): qualify delivered macOS selected-save preparation\n\nBind linear and fullscreen effects to genuine package bytes and retain\nexact bounded evidence through the required job log.\n\nWork-Item: FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01\nEvidence-Ref: '+Q+'/evidence/'+evidence.name+'\n'
 msg=E/'macos-delivered-tui-candidate-commit-message-01.txt';msg.write_text(message,encoding='utf-8',newline='\n');run('message',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--message',message])
 changes=[dict(path=n,state='content',sha256=sha(R/n),git_blob_oid=git('hash-object','--path',n,str(R/n)),ownership='task_owned') for n in sorted(paths)]
 snapshot=hashlib.sha256((json.dumps(changes,indent=2,sort_keys=True,separators=(',',': '))+'\n').encode()).hexdigest()
 commit_review=E/'macos-delivered-tui-candidate-commit-review-01.json';commit_review.write_text(json.dumps(dict(schema_version='aide.git-commit-review.v1',verdict='PASS',reviewer='/root',author='/root/macos_delivered_tui_implementation',non_authoring=True,branch=BRANCH,base_commit=BASE,snapshot_sha256=snapshot,message_sha256=sha(msg),independent_source_review_sha256=sha(review),review='Package-byte identity and immutable closure, cleared consumer overrides and external cwd, preserved Linux scenario assertions, mandatory actual Darwin linear/fullscreen effects and terminal restoration, bounded exact-byte durable job-log custody. Required actual Mac acceptance and normal CI remain mandatory.'),indent=2)+'\n')
 classification=E/'macos-delivered-tui-candidate-commit-classification-01.json';classification.write_text(json.dumps(dict(schema_version='aide.git-commit-classification.v1',branch=BRANCH,base_commit=BASE,work_item='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01',snapshot_sha256=snapshot,message_sha256=sha(msg),changed_paths=changes,reviews=[dict(path=str(commit_review),sha256=sha(commit_review),verdict='PASS')]),indent=2)+'\n')
 helper=['py','-3','-B','.aide/scripts/aide_lite.py','git','commit-plan','--classification',str(classification),'--message-file',str(msg)]
 run('plan-stage',helper);run('stage',['git','add','--',*sorted(paths)]);run('diff',['git','diff','--cached','--check']);run('plan-commit',helper)
 assert git('rev-parse','HEAD')==BASE;run('commit',['git','commit','-F',str(msg)]);run('range',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--range',BASE+'..HEAD']);assert not git('status','--porcelain')
 record.update(status='COMMITTED_REVIEWED_DELIVERED_TUI_CANDIDATE',source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),review_sha256=sha(commit_review),evidence_sha256=sha(evidence),actual_mac_package_pending=True,remote_not_pushed=True)
except BaseException as exc:record.update(status='ACTIONABLE_DELIVERED_TUI_COMMIT_FAILURE',error=str(exc),traceback=traceback.format_exc())
finally:save();print(json.dumps({k:v for k,v in record.items() if k!='commands'},indent=2))
raise SystemExit(0 if record['status']=='COMMITTED_REVIEWED_DELIVERED_TUI_CANDIDATE' else 1)
