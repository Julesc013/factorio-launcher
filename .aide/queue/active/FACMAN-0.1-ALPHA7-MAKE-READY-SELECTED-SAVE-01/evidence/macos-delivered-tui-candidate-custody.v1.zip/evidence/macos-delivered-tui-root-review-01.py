import ast,base64,hashlib,json,os,subprocess,sys,unittest,zlib
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1')
sys.dont_write_bytecode=True;sys.path[:0]=[str(R),str(R/'tests')]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
F=E/'macos-delivered-tui-frozen-02.json';f=json.loads(F.read_bytes());BASE=f['base_source_commit']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==BASE
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).strip()
for name,v in f['source_paths'].items():assert sha(R/name)==v['sha256'],name
assert sha(E/'macos-delivered-tui-frozen-02.patch')==f['patch_sha256']
old=ast.parse(subprocess.check_output(['git','show',BASE+':tests/test_tui_product.py'],cwd=R,text=True))
new=ast.parse((R/'tests/test_tui_product.py').read_text())
old_class=next(n for n in old.body if isinstance(n,ast.ClassDef) and n.name=='TuiProductTests')
new_class=next(n for n in new.body if isinstance(n,ast.ClassDef) and n.name=='TuiProductTests')
old_method=next(n for n in old_class.body if isinstance(n,ast.FunctionDef) and n.name=='test_ordinary_selected_save_missing_configuration_then_context_linux')
helper=next(n for n in new_class.body if isinstance(n,ast.FunctionDef) and n.name=='exercise_ordinary_selected_save_missing_configuration_then_context')
class RemoveCapture(ast.NodeTransformer):
 def visit_If(self,node):
  if ast.unparse(node.test)=='evidence is not None':return None
  return self.generic_visit(node)
body=RemoveCapture().visit(ast.Module(body=helper.body,type_ignores=[])).body
assert ast.dump(ast.Module(body=old_method.body,type_ignores=[]),include_attributes=False)==ast.dump(ast.Module(body=body,type_ignores=[]),include_attributes=False)
current=next(n for n in new_class.body if isinstance(n,ast.FunctionDef) and n.name==old_method.name)
assert ast.dump(current.decorator_list[0])==ast.dump(old_method.decorator_list[0])
current.body=body;new_class.body.remove(helper)
assert ast.dump(new,include_attributes=False)==ast.dump(old,include_attributes=False),'other original TUI campaign changed'
import test_macos_delivered_tui as candidate
suite=unittest.defaultTestLoader.loadTestsFromModule(candidate)
assert suite.countTestCases()==2
result=unittest.TestResult();suite.run(result)
assert result.testsRun==2 and len(result.skipped)==2 and not result.failures and not result.errors
assert all(reason=='not_applicable: delivered macOS TUI requires Darwin' for _,reason in result.skipped)
env=candidate.consumer_environment(dict(FACMAN_CLI_EXE='foreign',FLAUNCH_SOURCE='foreign',ULK_ROOT='foreign',USK_ROOT='foreign',DYLD_LIBRARY_PATH='foreign',PATH='foreign',NO_COLOR='1',KEEP='preserved'))
assert env==dict(PATH='',TERM='xterm-256color',LANG='C.UTF-8',KEEP='preserved')
for state in ('pass','fail'):
 record=candidate.custody_record(dict(mode='linear',test_id='independent.roundtrip',result=state),{'linear.terminal.log':bytes(range(256))*4,'linear.effects.json':b'[]\n'})
 compressed=base64.b64decode(record['payload_base64'],validate=True)
 assert len(record['payload_base64'])==record['encoded_size_bytes'] and hashlib.sha256(compressed).hexdigest()==record['compressed_sha256']
 decoder=zlib.decompressobj();raw=decoder.decompress(compressed,6*1024*1024+1)
 assert decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail and len(raw)==record['canonical_json_size_bytes']
 assert hashlib.sha256(raw).hexdigest()==record['canonical_json_sha256']
 content=json.loads(raw);assert content['result']==state
 for name,v in content['files'].items():
  payload=base64.b64decode(v['bytes_base64'],validate=True)
  assert len(payload)==v['size_bytes']==record['files'][name]['size_bytes'] and hashlib.sha256(payload).hexdigest()==v['sha256']==record['files'][name]['sha256']
review=dict(schema='facman.macos_delivered_tui_independent_review.v1',verdict='PASS_FOR_REQUIRED_ACTUAL_DARWIN_CANDIDATE',reviewer='/root',author='/root/macos_delivered_tui_implementation',non_authoring=True,base_head=BASE,frozen_packet_sha256=sha(F),files_sha256={n:v['sha256'] for n,v in f['source_paths'].items()},original_linux_campaign_ast_unchanged=True,standalone_darwin_discovered=2,local_darwin_skips_counted_as_acceptance=0,independent_custody_arbitrary_bytes_pass_fail_roundtrip=True,consumer_environment_isolation_checked=True,no_native_build=True,review='Normal clean canonical package factory and compiled package/source/build/provider closure, explicit produced executable for fixture setup and consumers, external cwd and cleared overrides, read-only relocation, preserved ordinary scenario assertions, real PTY complete-frame acknowledgement and terminal restoration, bounded exact-byte log custody exported before cleanup. Actual Darwin methods and full required CI must pass before integration.',actual_darwin_required=f['actual_test_selection'],actual_darwin_pending=True,full_make_ready=False,beta=False,rc=False)
out=E/'macos-delivered-tui-independent-review-01.json';assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(dict(verdict=review['verdict'],review_sha256=sha(out),linux_ast_unchanged=True,darwin_tests=2,actual_darwin_pending=True)))
