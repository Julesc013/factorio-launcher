import hashlib,json,os,tempfile,unittest
from pathlib import Path
assert os.getuid()==os.getgid()==65534 and not os.getgroups()
names=['test_tui_product.TuiProductTests.test_ordinary_selected_save_missing_configuration_then_context_linux','test_tui_product.TuiProductTests.test_ordinary_shell_pages_launch_deck_and_advanced_handoff','test_tui_product.TuiProductTests.test_ordinary_observation_choice_preserves_empty_workspace','test_tui_pty']
with tempfile.TemporaryDirectory(prefix='tui-private-home-') as temporary:
 home=Path(temporary)
 os.environ.update(HOME=str(home),XDG_CONFIG_HOME=str(home/'config'),XDG_CACHE_HOME=str(home/'cache'),XDG_DATA_HOME=str(home/'data'))
 suite=unittest.defaultTestLoader.loadTestsFromNames(names)
 result=unittest.TextTestRunner(verbosity=2).run(suite)
 record=dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skips=[(str(t),reason) for t,reason in result.skipped],uid=os.getuid(),gid=os.getgid(),groups=os.getgroups(),cli_sha256=hashlib.sha256(Path(os.environ['FACMAN_CLI_EXE']).read_bytes()).hexdigest(),test_names=names,private_home=True)
print('FACMAN_FIXTURE_RESULT='+json.dumps(record))
raise SystemExit(0 if result.wasSuccessful() and not result.skipped else 1)
