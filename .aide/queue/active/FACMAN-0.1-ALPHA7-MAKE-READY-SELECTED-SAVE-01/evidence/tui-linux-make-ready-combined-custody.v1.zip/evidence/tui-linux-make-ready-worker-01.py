import hashlib,json,os,sys,unittest
from pathlib import Path
E=Path(__file__).resolve().parent
assert os.getuid()==os.getgid()==65534 and not os.getgroups()
names=['test_tui_product.TuiProductTests.test_ordinary_selected_save_missing_configuration_then_context_linux','test_tui_product.TuiProductTests.test_ordinary_shell_pages_launch_deck_and_advanced_handoff','test_tui_product.TuiProductTests.test_ordinary_observation_choice_preserves_empty_workspace','test_tui_pty']
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(name) for name in names)
result=unittest.TextTestRunner(verbosity=2).run(suite)
record=dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skips=[(str(t),reason) for t,reason in result.skipped],uid=os.getuid(),gid=os.getgid(),groups=os.getgroups(),cli_sha256=hashlib.sha256(Path(os.environ['FACMAN_CLI_EXE']).read_bytes()).hexdigest(),test_names=names)
# The unprivileged worker cannot write receipts outside the private fixture root.
print('FACMAN_FIXTURE_RESULT='+json.dumps(record))
raise SystemExit(0 if result.wasSuccessful() and not result.skipped else 1)
