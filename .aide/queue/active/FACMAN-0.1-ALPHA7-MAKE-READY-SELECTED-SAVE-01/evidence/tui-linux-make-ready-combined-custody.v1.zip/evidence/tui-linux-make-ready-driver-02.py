import hashlib,json,os,signal,subprocess,traceback
from pathlib import Path
R=Path('/mnt/d/Projects/Factorio/factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent;L=W/'native-save-context-linux';M=E/'posix-publication-private-fixtures-01'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads((E/'tui-linux-make-ready-source-assurance-02.json').read_bytes())
assert os.getpid()==1 and os.getuid()==0
assert os.readlink('/proc/self/ns/mnt')!=os.environ['FACMAN_PARENT_MOUNT_NAMESPACE']
os.environ.update(GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.autocrlf',GIT_CONFIG_VALUE_0='true',PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='0',TMPDIR=str(W/'t'),TMP=str(W/'t'),TEMP=str(W/'t'),FACMAN_DEV_ROOT='/mnt/d/Projects/Factorio/.task-builds',CMAKE_BUILD_PARALLEL_LEVEL='2')
out=E/'tui-linux-make-ready-result-02.json';assert not out.exists()
record=dict(status='CONFIGURING_COMBINED_LINUX_TUI_SOURCE',base=a['base'],branch=a['branch'],source_assurance_sha256=sha(E/'tui-linux-make-ready-source-assurance-02.json'),commands=[],parallel=2,new_roots=0,new_clones=0,new_worktrees=0,new_candidates=0,beta=False,game=False,existing_ini_owner_admitted=False,physical_ext4=False,mount_namespace=os.readlink('/proc/self/ns/mnt'),pid_namespace=os.readlink('/proc/self/ns/pid'))
def save():out.write_text(json.dumps(record,indent=2)+'\n')
def bound():
 for n,h in a['source_files_sha256'].items():assert sha(R/n)==h,n
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==a['base']
def run(label,args,timeout=600,env=None):
 bound();stdout=E/('tui-linux-make-ready02-'+label+'.stdout');stderr=E/('tui-linux-make-ready02-'+label+'.stderr')
 with stdout.open('xb') as o,stderr.open('xb') as er:
  p=subprocess.Popen([str(x) for x in args],cwd=R,env=env,stdout=o,stderr=er,start_new_session=True);timed=False
  try:code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:timed=True;os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=30)
 record['commands'].append(dict(label=label,argv=[str(x) for x in args],exit=code,execution_limit_exceeded=timed,stdout_sha256=sha(stdout),stderr_sha256=sha(stderr)));save()
 assert code==0 and not timed,(label,code,str(stderr));bound()
mounted=False
try:
 ulk=W/'providers/universal-launcher-5479939ca5cb';usk=W.parent/'task-facman-u-507ecf4b41/providers/universal-setup-2749a15b835a'
 for root,pin in ((ulk,'5479939ca5cb'),(usk,'2749a15b835a')):
  head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head.startswith(pin)
  assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=root,text=True).strip()
 prior=json.loads((E/'tui-linux-make-ready-result-01.json').read_bytes())
 old=json.loads((E/'tui-linux-make-ready-source-assurance-01.json').read_bytes())
 for name,value in old['source_files_sha256'].items():
  if name!='tests/test_tui_product.py':assert a['source_files_sha256'][name]==value,name
 assert sha(L/'facman')==prior['cli_sha256']
 assert all(item['exit']==0 and not item['execution_limit_exceeded'] for item in prior['commands'] if item['label'] in ('configure','build','native'))
 assert '100% tests passed, 0 tests failed out of 3' in (E/'tui-linux-make-ready01-native.stdout').read_text()
 record['native_reuse']=dict(binary_sha256=prior['cli_sha256'],prior_result_sha256=sha(E/'tui-linux-make-ready-result-01.json'),native_log_sha256=sha(E/'tui-linux-make-ready01-native.stdout'),source_delta=['tests/test_tui_product.py'],native_tests=3,configure_build_native_rerun=False)
 record['cli_sha256']=sha(L/'facman');record['status']='RUNNING_ORDINARY_TUI_AND_PTY_ACCEPTANCE';save()
 assert M.is_dir() and not list(M.iterdir()) and not os.path.ismount(M)
 subprocess.run(['mount','-t','tmpfs','-o','size=128m,nosuid,nodev,mode=1777','facman-tui-make-ready',M],check=True,timeout=30);mounted=True
 record['private_mount']=next(line for line in Path('/proc/self/mountinfo').read_text().splitlines() if str(M) in line)
 assert os.statvfs(M).f_blocks*os.statvfs(M).f_frsize==134217728
 env=dict(os.environ,TMPDIR=str(M),TMP=str(M),TEMP=str(M),FACMAN_CLI_EXE=str(L/'facman'),FACMAN_TUI_EXE=str(L/'facman'),PYTHONPATH=str(W/'validators-linux')+':'+str(R)+':'+str(R/'tests'))
 privilege=['setpriv','--reuid=65534','--regid=65534','--clear-groups']
 run('fixtures',[*privilege,'python3','-B',E/'tui-linux-make-ready-worker-02.py'],900,env)
 line=next(line for line in (E/'tui-linux-make-ready02-fixtures.stdout').read_text().splitlines() if line.startswith('FACMAN_FIXTURE_RESULT='));record['fixtures']=json.loads(line.split('=',1)[1])
 assert record['fixtures']['cli_sha256']==record['cli_sha256'] and not record['fixtures']['skips']
 assert not list(M.iterdir()),'unresolved fixture state remains'
 record['status']='PASS_COMBINED_LINUX_ORDINARY_SELECTED_SAVE_MAKE_READY_AND_PTY'
except BaseException as exc:record.update(status='ACTIONABLE_LINUX_TUI_QUALIFICATION_FAILURE',error=str(exc),traceback=traceback.format_exc())
finally:
 if mounted:
  if list(M.iterdir()):
   archive=E/'tui-linux-make-ready-unresolved-fixtures-01.tar';subprocess.run(['tar','-cf',archive,'-C',M,'.'],check=True,timeout=60);record['unresolved_fixture_archive_sha256']=sha(archive)
  subprocess.run(['umount',M],check=True,timeout=30)
 record['private_mount_absent']=not os.path.ismount(M);record['remaining_namespace_processes']=[]
 for path in Path('/proc').iterdir():
  if path.name.isdigit() and path.name!='1':
   try:record['remaining_namespace_processes'].append(dict(pid=int(path.name),command=(path/'cmdline').read_bytes().decode(errors='replace').replace('\0',' ')))
   except FileNotFoundError:pass
 bound();save();print(json.dumps({k:v for k,v in record.items() if k!='commands'},indent=2));raise SystemExit(0 if record['status'].startswith('PASS_') else 1)
