import hashlib, json, os, subprocess, sys, traceback, zipfile
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
BASE='cb97d8cff22b400dbfdf8a24b9659fbb7adb9605'
BRANCH='task/facman-delivered-environment-reconstruction-01'
Q='.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.safecrlf',GIT_CONFIG_VALUE_0='false')
sys.path.insert(0,str(R))
from tools import provider_canary_process as owned
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True,encoding='utf-8').strip()
def dirty():return set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
out=E/'environment-reconstruction-candidate-commit-result-02.json';assert not out.exists()
record=dict(status='SEALING_REVIEWED_ENVIRONMENT_RECONSTRUCTION',commands=[],new_roots=0,new_clones=0,new_worktrees=0,native_rebuild=False,goal_status_mutated=False)
def save():out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
def run(label,args,timeout=180,expected_codes=(0,)):
 result=owned.command(args,cwd=R,environment=dict(os.environ),timeout=timeout,directory=E/('environment-reconstruction-commit02-'+label),output_limit=8*1024**2,wait_for_job_empty_after_primary=True)
 record['commands'].append(dict(label=label,exit_code=result.returncode,receipt_sha256=sha(result.directory/'receipt.json')));save()
 assert result.returncode in expected_codes and result.receipt['termination']=='completed' and result.receipt['primary_stopped'] and result.receipt['job_empty_observed'] and not result.receipt['job_terminated'],(label,(result.stdout[-1200:]+result.stderr[-1800:]).decode('utf-8','replace'))
 return result
try:
 assert git('rev-parse','HEAD')==BASE and git('branch','--show-current')==BRANCH and not git('diff','--cached','--name-only')
 packet=E/'environment-reconstruction-author-packet-01.json';p=json.loads(packet.read_bytes())
 review=E/'environment-reconstruction-independent-review-02.json';v=json.loads(review.read_bytes())
 assert v['verdict']=='PASS_ENVIRONMENT_RECONSTRUCTION_SOURCE_FOR_REQUIRED_CURRENT_CI' and v['non_authoring'] and v['author_packet_sha256']==sha(packet)
 initial=dirty();expected={row['path'] for row in p['author_files']}|{row['path'] for row in p['root_owned_preserved']}
 assert initial==expected,(initial,expected)
 for row in p['author_files']+p['root_owned_preserved']:assert sha(R/row['path'])==row['sha256']
 for label in ('policy','detect','plan'):run(label,['py','-3','-B','.aide/scripts/aide_lite.py','git',label])
 run('paths',['py','-3','-B','tools/workspace_hygiene.py','paths'])
 doctor=run('doctor',['py','-3','-B','tools/workspace_hygiene.py','doctor','--measure'],600,expected_codes=(0,1))
 hygiene=json.loads(doctor.stdout)
 assert hygiene['violations']==['unmanaged_secondary_worktrees_present']
 assert len(hygiene['task_roots'])==8 and all(root['owned'] for root in hygiene['task_roots'])
 assert sum(root['bytes'] for root in hygiene['task_roots'])<20*1024**3
 foreign=[tree for tree in hygiene['worktrees'] if not tree['owned']]
 assert len(foreign)==1 and foreign[0]['branch']=='task/facman-provider-canary-01'
 record.update(preserved_external_canary_violation=True,owned_task_roots=8,owned_task_root_bytes=sum(root['bytes'] for root in hygiene['task_roots']))
 evidence=R/Q/'evidence/environment-reconstruction-source.v1.json'
 archive=R/Q/'evidence/environment-reconstruction-source-custody.v1.zip'
 assert not evidence.exists() and not archive.exists()
 names={row['path'] for row in p['evidence_files']}
 names.update({packet.name,review.name,'environment-reconstruction-independent-review-01.json','environment-reconstruction-custody-review-02.json','environment-reconstruction-log-custody-01.py','environment-reconstruction-log-custody-02.py','environment-reconstruction-decoder-failure-01.json',Path(__file__).name})
 manifest={}
 for name in sorted(names):
  path=(E/name).resolve();assert path.is_relative_to(E.resolve()) and path.is_file() and path.suffix.lower() not in ('.exe','.dll','.zip')
  manifest['evidence/'+path.relative_to(E).as_posix()]=sha(path)
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as custody:
  custody.writestr('custody-manifest.json',json.dumps(manifest,indent=2,sort_keys=True)+'\n')
  for name in sorted(manifest):custody.write(E/name.removeprefix('evidence/'),name)
 with zipfile.ZipFile(archive) as custody:
  assert set(custody.namelist())==set(manifest)|{'custody-manifest.json'}
  for name,digest in manifest.items():assert hashlib.sha256(custody.read(name)).hexdigest()==digest
 evidence.write_text(json.dumps(dict(schema='facman.environment_reconstruction_source_qualification.v1',base_head=BASE,author_packet_sha256=sha(packet),review_sha256=sha(review),independent_custody_review_sha256=sha(E/'environment-reconstruction-custody-review-02.json'),authored_files_sha256=v['authored_files_sha256'],source_owner_methods=3,local_package_adapter_scenarios=3,local_package_adapter_calls=107,produced_package_source=p['package']['produced_source'],source_regression_only=True,current_head_package_pending=True,required_checks_pending=True,package=p['package'],declared_inputs=['selected_content_pack','inspected_portable_profile_settings','selected_snapshot_WorldBundle'],snapshot_install_alias_prerequisite=True,original_semantic_unknown_preserved=True,exact_source_target_bytes_and_provenance_verified=True,foreign_and_corrupt_inputs_preserved=True,custody=archive.name,custody_sha256=sha(archive),custody_files=len(manifest),native_rebuild=False,new_roots=0,new_clones=0,new_worktrees=0,protected_workflow_changes=False,full_make_ready=False,whole_workunit=False,canonical_installed_desktop=False,minimum_named_physical_host=False,real_game=False,human=False,beta=False,rc=False),indent=2)+'\n',encoding='utf-8')
 with (R/Q/'ExecPlan.md').open('a',encoding='utf-8',newline='\n') as stream:
  stream.write('\n### Clean-workspace declared environment reconstruction candidate\n\nThree ordinary owner journeys compose selected modpack export/import, explicitly inspected portable profile settings, existing snapshot/WorldBundle restoration into a carrier, destination-owned backup/clone, public verification and joined selected-save context. Snapshot restoration requires its source-declared compatible installation alias; pack import retains its independently selected local binding. Exact selected mod/settings/world bytes, original and rebound locks, profile settings and source provenance are independently verified. Missing alias, six foreign/corrupt/missing input boundaries and original unknown semantic replay preserve data. Actual selected-context owner74 interruption recovers its published effect; a fresh request observes the already prepared context without reimport, reclone or redispatch.\n\nThree source methods and107calls through the package adapter pass on the retained produced002824byte closure. Runtime/contracts/apps are unchanged to integrated devcb97; this is explicitly source regression with no fresh-head delivered claim. Source fixture mistakes and the first independent deadline finding remain preserved. The corrected adapter enforces300seconds through dispatch, finish, CAS, cleanup and acceptance; exact Windows retained process/thread membership before resume and natural empty-job exits are verified. Complete scenario roots and unchanged registered installation bytes survive cleanup in hash-closed custody. No new factory, GUI session, local native build, root, clone or worktree occurred.\n\nFresh required Windows execution reuses its existing factory-produced GUI package after the unchanged GUI oracle; three mandatory Mac methods reuse the existing single package factory and retain every prior method body. Independent decoding of both actual new-head package results and all required checks is mandatory before normal integration. Full Make Ready/Play, canonical installed Desktop/PR404 owner gate, real game/human/minimum/named physical hosts, whole workunit and Beta/RC remain open.\n\nEvidence: evidence/environment-reconstruction-source.v1.json and hash-closed custody; consumed PR418 result at evidence/produced-windows-live-joined-gui.v1.json.\n')
 paths=initial|{Q+'/evidence/'+evidence.name,Q+'/evidence/'+archive.name}
 run('project-state',['py','-3','-B','tools/project_state.py','--write'],600)
 run('metadata',['py','-3','-B','tools/codegen/generate_metadata.py','--write'])
 changed=dirty();assert paths<=changed<=paths|{'.aide/memory/project-state.md','.aide/memory/project-state.v2.json','README.md'}
 for row in p['author_files']:assert sha(R/row['path'])==row['sha256']
 run('strict',['py','-3','-B','tools/strict_check.py'],1800)
 run('portable-aide',['py','-3','-B','.aide/scripts/aide_lite.py','test'],1800)
 message='test(environment): qualify clean-workspace reconstruction\n\nJoin declared content, profile and world owners with exact provenance,\ninterruption recovery and preservation in reused delivered packages.\n\nWork-Item: FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01\nEvidence-Ref: '+Q+'/evidence/'+evidence.name+'\n'
 msg=E/'environment-reconstruction-candidate-commit-message-02.txt';msg.write_text(message,encoding='utf-8',newline='\n')
 run('message',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--message',message])
 changes=[dict(path=name,state='content',sha256=sha(R/name),git_blob_oid=git('hash-object','--path',name,str(R/name)),ownership='task_owned') for name in sorted(changed)]
 snapshot=hashlib.sha256((json.dumps(changes,indent=2,sort_keys=True,separators=(',',': '))+'\n').encode()).hexdigest()
 commit_review=E/'environment-reconstruction-candidate-commit-review-02.json'
 commit_review.write_text(json.dumps(dict(schema_version='aide.git-commit-review.v1',verdict='PASS',reviewer='/root',author=p['schema']+'; /root/delivered_environment_reconstruction_implementation',non_authoring=True,branch=BRANCH,base_commit=BASE,snapshot_sha256=snapshot,message_sha256=sha(msg),independent_source_review_sha256=sha(review),review='Declared clean-workspace content/profile/world composition, original/rebound provenance, real owner interruption and immutable unknown replay; exact input and job lifetime custody independently verified. Fresh current factory Windows/Mac results and all required checks remain mandatory.'),indent=2)+'\n',encoding='utf-8')
 classification=E/'environment-reconstruction-candidate-commit-classification-02.json'
 classification.write_text(json.dumps(dict(schema_version='aide.git-commit-classification.v1',branch=BRANCH,base_commit=BASE,work_item='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01',snapshot_sha256=snapshot,message_sha256=sha(msg),changed_paths=changes,reviews=[dict(path=str(commit_review),sha256=sha(commit_review),verdict='PASS')]),indent=2)+'\n',encoding='utf-8')
 helper=['py','-3','-B','.aide/scripts/aide_lite.py','git','commit-plan','--classification',str(classification),'--message-file',str(msg)]
 run('plan-stage',helper);run('stage',['git','add','--',*sorted(changed)]);run('staged-diff',['git','diff','--cached','--check']);run('plan-commit',helper)
 assert git('rev-parse','HEAD')==BASE
 run('commit',['git','commit','-F',str(msg)])
 run('range',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--range',BASE+'..HEAD'])
 remaining=git('diff','--name-only').splitlines()
 if remaining:
  assert set(remaining)<={'.aide/memory/project-state.md','.aide/memory/project-state.v2.json','README.md'} and not git('diff','--cached','--name-only')
  for name in remaining:assert git('hash-object','--path',name,str(R/name))==git('rev-parse','HEAD:'+name)
  run('refresh-generated-index',['git','add','--',*remaining])
 assert not git('status','--porcelain') and not git('diff','--cached','--name-only')
 record.update(status='COMMITTED_REVIEWED_ENVIRONMENT_RECONSTRUCTION_CANDIDATE',source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),review_sha256=sha(commit_review),evidence_sha256=sha(evidence),actual_windows_mac_factory_proof_pending=True,required_checks_pending=True,remote_not_pushed=True)
except BaseException as error:
 record.update(status='ACTIONABLE_ENVIRONMENT_COMMIT_FAILURE',error=str(error),traceback=traceback.format_exc())
finally:
 save();print(json.dumps({key:value for key,value in record.items() if key not in ('commands','traceback')},indent=2),flush=True)
raise SystemExit(0 if record['status']=='COMMITTED_REVIEWED_ENVIRONMENT_RECONSTRUCTION_CANDIDATE' else 1)
