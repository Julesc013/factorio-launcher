"""Freeze the narrow author handoff; no git, package or queue mutation."""
import ast, hashlib, json, subprocess
from collections import Counter
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher')
E=Path(__file__).resolve().parent
G=E.parent/'t/j3/g'
OUT=E/'environment-reconstruction-author-packet-01.json'
assert not OUT.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=R,text=True).strip()
author=['docs/product/modpack_import.md','tests/test_environment_reconstruction.py',
    'tests/delivered_environment_reconstruction.py','tests/test_macos_delivered_tui.py',
    'tests/test_windows_delivered_joined_gui.py']
Q='.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
root_owned=[Q+'/ExecPlan.md',Q+'/evidence/produced-windows-live-joined-gui.v1.json',
    Q+'/evidence/produced-windows-live-joined-gui-custody.v1.zip']
assert git('branch','--show-current')=='task/facman-delivered-environment-reconstruction-01'
assert git('rev-parse','HEAD')=='cb97d8cff22b400dbfdf8a24b9659fbb7adb9605'
assert not git('diff','--cached','--name-only')
changed=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
assert changed==set(author+root_owned)
assert not git('diff','002824ea9f2ac4d3844ec5141b455d5733a8008b','HEAD','--','runtime','contracts','apps')
assert sha(E/'environment-reconstruction-independent-review-01.json')=='8683ba2fd93e08d82fc47953534c907ff9f1d55cdbc3dd5cee65365e93808b71'
current=(R/'tests/test_environment_reconstruction.py').read_text()
old=current.replace('write_save(foreign_save, b"foreign world bytes")','foreign_save.write_bytes(b"foreign world bytes")').replace('"unknown_profile"),','"profile_not_found"),')
run03=json.loads((E/'environment-reconstruction-run-03.json').read_bytes())
assert hashlib.sha256(old.encode()).hexdigest()==run03['source_test_sha256']
prior_tree,final_tree=ast.parse(old),ast.parse(current)
methods=lambda tree:{n.name:ast.dump(n,include_attributes=False) for c in tree.body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,ast.FunctionDef)}
prior,final=methods(prior_tree),methods(final_tree)
assert all(prior[name]==final[name] for name in final if name!='test_reconstruction_owners_preserve_foreign_destinations_and_refuse_invalid_inputs')
assert json.loads((E/'environment-reconstruction-run-04.json').read_bytes())['status']=='pass'
terminal=json.loads((E/'environment-reconstruction-delivered-adapter-07.json').read_bytes())
assert terminal['status']=='pass' and len(terminal['scenarios'])==3 and terminal['factory_calls']==terminal['GUI_sessions']==0
delivery=E/'environment-reconstruction-delivered-adapter-07'
rows=[]
for result in sorted(delivery.glob('*/result.json')):
    receipt=json.loads(result.read_bytes())
    effects=json.loads((result.parent/'calls.json').read_bytes())
    assert receipt['result']=='pass' and receipt['source_regression_only'] and not receipt['current_head_package']
    assert effects['adapter_sha256']==sha(R/'tests/delivered_environment_reconstruction.py')
    assert effects['source_test_sha256']==sha(R/'tests/test_environment_reconstruction.py')
    assert len(effects['calls'])<=64 and effects['elapsed_seconds']<300 and len(effects['scenario_roots'])==1
    assert effects['registered_installation']['before']==effects['registered_installation']['after']
    assert effects['package_file_count']==598
    for call in effects['calls']:
        native=call['owned_command_receipt'];launch=call['launch']
        assert native['termination']=='completed' and native['primary_stopped'] and native['job_empty_observed'] and not native['job_terminated']
        assert launch['exact_job_membership_before_resume'] and launch['resume_previous_suspend_count']==1
        if call['exit_code']==74:
            assert call['environment_inputs']['FACMAN_TEST_SELECTED_CONTEXT_EXIT']=='after_publication'
            assert call['argv'][3:6]==['presentation','action','readiness.prepare_joined']
    rows.append(dict(scenario=effects['scenario'],calls=len(effects['calls']),exit_codes=dict(Counter(c['exit_code'] for c in effects['calls'])),
        elapsed_seconds=effects['elapsed_seconds'],result_path=str(result.relative_to(E)),result_sha256=sha(result),
        calls_sha256=sha(result.parent/'calls.json'),complete_scenario_roots=1,package_files=598,
        installation_bytes_unchanged=True,all_native_jobs_empty_without_termination=True))
files=[]
selected=['environment-reconstruction-run-01.json','environment-reconstruction-run-01-tests.log',
    'environment-reconstruction-run-02.json','environment-reconstruction-run-03.json','environment-reconstruction-run-03-tests.log',
    'environment-reconstruction-run-04.json','environment-reconstruction-delivered-adapter-05.json',
    'environment-reconstruction-delivered-adapter-06.json','environment-reconstruction-delivered-adapter-07.json',
    'environment-reconstruction-delivered-adapter-07.py','environment-reconstruction-delivered-adapter-07.log',
    'environment-reconstruction-independent-review-01.json','environment-reconstruction-author-freeze-01.py']
for path in [*(E/name for name in selected),*(p for p in delivery.rglob('*') if p.is_file())]:
    files.append(dict(path=str(path.relative_to(E)),sha256=sha(path),size_bytes=path.stat().st_size))
record=dict(schema='facman.environment_reconstruction_author_packet.v1',status='author_frozen_for_independent_review',
    base=git('rev-parse','HEAD'),branch=git('branch','--show-current'),base_tree=git('rev-parse','HEAD^{tree}'),
    author_files=[dict(path=p,sha256=sha(R/p),size_bytes=(R/p).stat().st_size) for p in author],
    root_owned_preserved=[dict(path=p,sha256=sha(R/p),size_bytes=(R/p).stat().st_size) for p in root_owned],
    source_owner_journeys=dict(methods=3,skips=0,happy_recovery_receipt='environment-reconstruction-run-03.json',
        corrected_refusal_receipt='environment-reconstruction-run-04.json',successful_method_bodies_unchanged=True,
        actual_refusals_retained=['snapshot_install_incompatible','unknown_profile','instance_save_invalid'],
        production_owner_bug=False),
    adapter_regression=dict(receipt='environment-reconstruction-delivered-adapter-07.json',scenarios=rows,
        native_calls=sum(r['calls'] for r in rows),factory_calls=0,GUI_sessions=0),
    package=dict(path=str(G),produced_source='002824ea9f2ac4d3844ec5141b455d5733a8008b',
        build_info=json.loads((G/'manifest/build_info.v1.json').read_bytes()),
        cli_sha256=sha(G/'bin/facman.exe'),gui_sha256=sha(G/'bin/FacMan.WinForms.exe'),
        closure_sha256=sha(G/'manifest/hashes.sha256'),runtime_contracts_apps_unchanged_to_base=True),
    scope=dict(source_regression_only=True,current_head_package=False,current_head_CI_pending=True,
        Mac_executed_local=False,real_play=False,real_game=False,human=False,whole_workunit=False,
        current_delivery_design='Same Windows factory after unchanged GUI custody; three added Mac methods share existing one class factory'),
    evidence_files=files,committed=False,pushed=False,CI_requested=False)
with OUT.open('x',encoding='utf-8') as stream:json.dump(record,stream,indent=2)
print(json.dumps(dict(status=record['status'],author_files=len(author),root_owned_preserved=len(root_owned),
    native_calls=record['adapter_regression']['native_calls'],scenarios=len(rows),receipt_sha256=sha(OUT))))
