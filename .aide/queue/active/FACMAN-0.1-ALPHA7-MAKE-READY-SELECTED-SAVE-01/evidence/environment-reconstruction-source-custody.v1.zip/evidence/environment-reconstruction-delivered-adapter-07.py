"""Exercise the approved package adapter on retained produced bytes; no factory."""
import contextlib, hashlib, json, os, shutil, sys, tempfile, traceback, unittest
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher')
E=Path(__file__).resolve().parent
W=E.parent
G=W/'t/j3/g'
OUT=E/'environment-reconstruction-delivered-adapter-07.json'
assert not OUT.exists()
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='0',
    TEMP=r'D:\Projects\Factorio\TASK-B~1\REPOSI~1\FACTOR~1\tasks\TASK-F~2\t\j3',
    TMP=r'D:\Projects\Factorio\TASK-B~1\REPOSI~1\FACTOR~1\tasks\TASK-F~2\t\j3')
sys.path[:0]=[str(R/'tests'),str(R)]
import delivered_environment_reconstruction as delivered
consumer=W/'t/j3/environment-consumer-07'
assert not consumer.exists()
consumer.mkdir()
fixture=consumer/'fixture-install'
shutil.copytree(R/'tests/fixtures/fake_factorio_install',fixture)
evidence=E/'environment-reconstruction-delivered-adapter-07'
evidence.mkdir()
temporary=tempfile.TemporaryDirectory
class RetainedTemporary(temporary):
    def cleanup(self):
        self._finalizer.detach()
tempfile.TemporaryDirectory=RetainedTemporary
class Owner(unittest.TestCase):
    def runTest(self): pass
owner=Owner()
record=dict(status='running',factory_calls=0,GUI_sessions=0,current_head_package=False,
    produced_source='002824ea9f2ac4d3844ec5141b455d5733a8008b',source_regression_only=True,scenarios=[])
try:
    with (E/'environment-reconstruction-delivered-adapter-07.log').open('x',encoding='utf-8') as log,contextlib.redirect_stdout(log):
        for scenario in delivered.SCENARIOS:
            delivered.exercise(owner,scenario,package=G,consumer=consumer,fixture=fixture,evidence_root=evidence,
                binding=dict(schema='facman.windows_delivered_environment_result.v1',
                    qualification='source_regression_on_retained_produced_portable_file_closure',
                    produced_source=record['produced_source'],current_head_package=False,source_regression_only=True,build_info=json.loads((G/'manifest/build_info.v1.json').read_bytes()),backend_sha256=hashlib.sha256((G/'bin/facman.exe').read_bytes()).hexdigest(),closure_sha256=hashlib.sha256((G/'manifest/hashes.sha256').read_bytes()).hexdigest()))
            record['scenarios'].append(dict(name=scenario,status='pass'))
    record['status']='pass'
except Exception:
    record.update(status='actual_adapter_failure',error=traceback.format_exc())
finally:
    with OUT.open('x',encoding='utf-8') as output: json.dump(record,output,indent=2)
print(json.dumps(dict(status=record['status'],scenarios=len(record['scenarios']),factory_calls=0,GUI_sessions=0)))
if record['status']!='pass':
    print(record['error'][-6000:])
    sys.exit(1)
