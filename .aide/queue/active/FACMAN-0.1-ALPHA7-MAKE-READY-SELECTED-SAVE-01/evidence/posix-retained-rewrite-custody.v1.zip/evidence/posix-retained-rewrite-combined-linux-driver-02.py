import hashlib
import json
import os
from pathlib import Path
import signal
import re
import subprocess
import traceback

R = Path('/mnt/d/Projects/Factorio/factorio-launcher')
E = Path(__file__).resolve().parent
W = E.parent
L = W / 'native-save-context-linux'
M = E / 'posix-publication-private-fixtures-01'
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
assurance = json.loads((E / 'posix-retained-rewrite-combined-source-assurance-02.json').read_text())
assert os.getpid() == 1 and os.getuid() == 0
assert os.readlink('/proc/self/ns/mnt') != os.environ['FACMAN_PARENT_MOUNT_NAMESPACE']
record = dict(schema='facman.posix_retained_combined_linux_qualification.v1', status='CONFIGURING_ACTUAL_COMBINED_SOURCE',
              source_assurance_sha256=sha(E / 'posix-retained-rewrite-combined-source-assurance-02.json'),
              base=assurance['base'], branch=assurance['branch'], commands=[], parallel=2,
              new_roots=0, new_clones=0, new_worktrees=0, new_candidates=0, existing_ini_owner_admitted=False,
              actual_process_death=False, physical_ext4=False, macos=False, game=False, power_loss=False,
              mount_namespace=os.readlink('/proc/self/ns/mnt'), pid_namespace=os.readlink('/proc/self/ns/pid'))
out = E / 'posix-retained-rewrite-combined-linux-result-02.json'
assert not out.exists()
def save(): out.write_text(json.dumps(record, indent=2) + '\n')
def bound():
    for group in ('task_source_files_sha256', 'context_source_files_sha256'):
        for path, expected in assurance[group].items(): assert sha(R / path) == expected, path
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == assurance['base']
    assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=R, text=True).strip() == assurance['branch']
def provider_bound():
    for provider in assurance['providers'].values():
        root = Path('/mnt/d/' + provider['root'][3:].replace('\\', '/'))
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == provider['pin']
        assert not subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=root, text=True).strip()
def run(label, argv, timeout=600, environment=None):
    bound(); provider_bound()
    stdout, stderr = E / ('posix-retained-combined-linux02-' + label + '.stdout'), E / ('posix-retained-combined-linux02-' + label + '.stderr')
    with stdout.open('xb') as output, stderr.open('xb') as errors:
        process = subprocess.Popen([str(arg) for arg in argv], cwd=R, env=environment,
                                   stdout=output, stderr=errors, start_new_session=True)
        exceeded = False
        try: code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            exceeded = True; os.killpg(process.pid, signal.SIGKILL); code = process.wait(timeout=30)
    item = dict(label=label, argv=[str(arg) for arg in argv], exit=code, execution_limit_exceeded=exceeded,
                stdout_sha256=sha(stdout), stderr_sha256=sha(stderr))
    record['commands'].append(item); save()
    assert code == 0 and not exceeded, (label, code)
    bound(); provider_bound()
os.environ.update(GIT_CONFIG_COUNT='1', GIT_CONFIG_KEY_0='core.autocrlf', GIT_CONFIG_VALUE_0='true', PYTHONDONTWRITEBYTECODE='1', PYTHONOPTIMIZE='0', TMPDIR=str(W / 't'), TEMP=str(W / 't'), TMP=str(W / 't'),
                  FACMAN_DEV_ROOT='/mnt/d/Projects/Factorio/.task-builds', CMAKE_BUILD_PARALLEL_LEVEL='2')
mounted = False
try:
    bound(); provider_bound(); save()
    # Real Linux preprocessing proves the authorized Windows-only correction
    # leaves every Linux runtime token unchanged. Whitespace is not a token.
    pp_flags = ['c++', '-E', '-P', '-std=c++17', '-I' + str(R / 'runtime/platform'), '-I' + str(R / 'runtime/core')]
    run('linux-pp-before', [*pp_flags, E / 'posix-retained-rewrite-opener-before-01.cpp'])
    run('linux-pp-after', [*pp_flags, E / 'posix-retained-rewrite-opener-after-01.cpp'])
    token = r'"(?:\\.|[^"\\])*"|\x27(?:\\.|[^\x27\\])*\x27|[^\s]'
    before_tokens = re.findall(token, (E / 'posix-retained-combined-linux02-linux-pp-before.stdout').read_text())
    after_tokens = re.findall(token, (E / 'posix-retained-combined-linux02-linux-pp-after.stdout').read_text())
    assert before_tokens == after_tokens, 'authorized correction changed Linux-preprocessed runtime tokens'
    record['opener_correction_linux_tokens_unchanged'] = True
    record['linux_preprocessed_token_sha256'] = hashlib.sha256(json.dumps(after_tokens, separators=(',', ':')).encode()).hexdigest()
    ulk = Path('/mnt/d/' + assurance['providers']['ulk']['root'][3:].replace('\\', '/'))
    usk = Path('/mnt/d/' + assurance['providers']['usk']['root'][3:].replace('\\', '/'))
    run('configure', ['cmake', '-S', R, '-B', L, '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Debug', '-DFACMAN_BUILD_TESTS=ON',
                      '-DFACMAN_BUILD_TUI=ON', '-DFACMAN_WARNINGS_AS_ERRORS=ON', '-DFACMAN_PROVIDER_MODE=source',
                      '-DFACMAN_PROVIDER_LOCK_FILE=' + str(R / 'release/index/workspace_lock.v1.toml'),
                      '-DFLAUNCH_UNIVERSAL_LAUNCHER_ROOT=' + str(ulk), '-DFLAUNCH_UNIVERSAL_SETUP_ROOT=' + str(usk)])
    record['status'] = 'BUILDING_ACTUAL_COMBINED_RUNTIME_AND_ABI'; save()
    run('build', ['cmake', '--build', L, '--parallel', '2', '--target', 'facman_cli', 'fl_platform_io_smoke',
                  'fl_retained_rewrite_smoke', 'facman_abi_layout_smoke', 'flb_factorio_shared'], timeout=2400)
    record['cli_sha256'] = sha(L / 'facman')
    record['native_primitive_sha256'] = sha(L / 'fl_retained_rewrite_smoke')
    assert M.is_dir() and not list(M.iterdir()) and not os.path.ismount(M)
    subprocess.run(['mount', '-t', 'tmpfs', '-o', 'size=128m,nosuid,nodev,mode=1777', 'facman-retained-combined', M], check=True, timeout=30)
    mounted = True
    record['private_mount'] = next(line for line in Path('/proc/self/mountinfo').read_text().splitlines() if str(M) in line)
    assert os.statvfs(M).f_blocks * os.statvfs(M).f_frsize == 134217728
    environment = dict(os.environ, TMPDIR=str(M), TEMP=str(M), TMP=str(M), FACMAN_CLI_EXE=str(L / 'facman'),
                       PYTHONPATH=str(W / 'validators-linux') + ':' + str(R) + ':' + str(R / 'tests'))
    privilege = ['setpriv', '--reuid=65534', '--regid=65534', '--clear-groups']
    record['status'] = 'RUNNING_UNPRIVILEGED_COMBINED_NATIVE_AND_OWNER_GATES'; save()
    run('native', [*privilege, 'ctest', '--test-dir', L, '-R', '^(fl_platform_io_smoke|fl_retained_rewrite_smoke|facman_abi_layout_smoke|facman_abi_symbol_smoke)$', '-V'], environment=environment)
    native_log = (E / 'posix-retained-combined-linux02-native.stdout').read_text()
    for phase in ('after_prefix', 'after_write', 'after_truncate'):
        assert 'real-process-death: ' + phase + ' SIGKILL observed;' in native_log
    assert '100% tests passed, 0 tests failed out of 4' in native_log
    record['actual_process_death'] = True
    run('fixtures', [*privilege, 'python3', '-B', E / 'posix-retained-rewrite-combined-linux-fixtures-01.py'], timeout=1200, environment=environment)
    fixtures = json.loads((E / 'posix-retained-rewrite-combined-linux-fixtures-result-01.json').read_text())
    assert fixtures['status'].startswith('PASS_') and fixtures['cli_sha256'] == record['cli_sha256']
    assert not list(M.iterdir()), 'unresolved fixture state remains'
    record.update(status='PASS_ACTUAL_COMBINED_LINUX_PRIMITIVE_PUBLICATION_AND_CLOSED_ADMISSION',
                  fixtures_result_sha256=sha(E / 'posix-retained-rewrite-combined-linux-fixtures-result-01.json'),
                  task_source_files_sha256=assurance['task_source_files_sha256'])
except BaseException as error:
    record.update(status='ACTIONABLE_COMBINED_LINUX_FAILURE', error=str(error), traceback=traceback.format_exc())
finally:
    if mounted:
        if list(M.iterdir()):
            archive = E / 'posix-retained-combined-unresolved-fixtures-02.tar'
            subprocess.run(['tar', '-cf', archive, '-C', M, '.'], check=True, timeout=60)
            record['unresolved_fixture_archive_sha256'] = sha(archive)
        subprocess.run(['umount', M], check=True, timeout=30)
    record['private_mount_absent'] = not os.path.ismount(M)
    record['remaining_namespace_processes'] = []
    for path in Path('/proc').iterdir():
        if path.name.isdigit() and path.name != '1':
            try: record['remaining_namespace_processes'].append(dict(pid=int(path.name), command=(path / 'cmdline').read_bytes().decode(errors='replace').replace('\0', ' ')))
            except FileNotFoundError: pass
    bound(); provider_bound(); save()
    print(json.dumps({key:value for key,value in record.items() if key not in ('commands', 'task_source_files_sha256')}, indent=2))
    raise SystemExit(0 if record['status'].startswith('PASS_') else 1)
