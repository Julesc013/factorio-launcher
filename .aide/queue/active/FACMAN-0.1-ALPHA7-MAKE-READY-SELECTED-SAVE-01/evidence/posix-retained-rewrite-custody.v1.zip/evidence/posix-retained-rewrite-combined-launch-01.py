import ast
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import traceback

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
W = E.parent
B = W / 'native-developer'
sys.path.insert(0, str(R))
from tools import native_build, provider_canary_process as owned
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
assurance = json.loads((E / 'posix-retained-rewrite-combined-source-assurance-02.json').read_text())
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds', TEMP=str(W / 't'), TMP=str(W / 't'),
                  PYTHONDONTWRITEBYTECODE='1', CMAKE_BUILD_PARALLEL_LEVEL='2', FACMAN_MIN_FREE_GIB='12', MSBUILDDISABLENODEREUSE='1')
out = E / 'posix-retained-rewrite-combined-launch-result-01.json'
assert not out.exists()
record = dict(schema='facman.posix_retained_combined_qualification_launch.v1', status='PREPARING',
              source_assurance_sha256=sha(E / 'posix-retained-rewrite-combined-source-assurance-02.json'),
              base=assurance['base'], branch=assurance['branch'], commands=[], foreign_wait_observations=[],
              reserve_bytes=12 * 1024 ** 3, planned_peak_bytes=2 * 1024 ** 3,
              new_roots=0, new_candidates=0, new_clones=0, new_worktrees=0,
              optional_windows_rebuild=False, windows_cli07_moved=False)
def save(): out.write_text(json.dumps(record, indent=2) + '\n')
def bound():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == assurance['base']
    assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=R, text=True).strip() == assurance['branch']
    for group in ('task_source_files_sha256', 'context_source_files_sha256'):
        for path, expected in assurance[group].items(): assert sha(R / path) == expected, path
    for path, expected in assurance['preserved_earlier_qualified_images'].items(): assert sha(path) == expected
    assert sha(assurance['cli07_preservation']['source']) == assurance['cli07_preservation']['sha256']
    for name, expected in assurance['windows_provider_sha256'].items(): assert sha(B / 'Release' / name) == expected
query = r"$all=@(Get-CimInstance Win32_Process); $active=@($all | Where-Object { $_.Name -match '^(cl|clang|link|ninja|ctest)\.exe$' -or ($_.Name -eq 'cmake.exe' -and $_.CommandLine -like '*--build*') -or ($_.Name -eq 'MSBuild.exe' -and $_.CommandLine -notlike '*/nodemode:*') } | Select-Object Name,ProcessId,ParentProcessId,CommandLine); $active | ConvertTo-Json -Depth 4 -Compress -AsArray"
probe = '''import os,json,shutil
names={"cmake","ninja","g++","c++","cc1plus","clang","clang++","ctest","facman"}; found=[]
for p in os.listdir("/proc"):
 if p.isdigit():
  try:
   comm=open("/proc/"+p+"/comm").read().strip()
   if comm in names or comm.startswith("fl_retained"):
    found.append(dict(pid=int(p),command=open("/proc/"+p+"/cmdline","rb").read().decode(errors="replace").replace(chr(0)," ")))
  except FileNotFoundError: pass
print(json.dumps(dict(uid=os.getuid(),mount_namespace=os.readlink("/proc/self/ns/mnt"),foreign_native=found,tools={n:shutil.which(n) for n in ["cmake","ninja","c++","timeout","unshare","mount","umount","setpriv","python3"]})))'''
def observe():
    windows = json.loads(subprocess.check_output(['pwsh', '-NoProfile', '-Command', query], text=True, timeout=45) or '[]')
    linux = json.loads(subprocess.check_output(['wsl', '-d', 'Ubuntu-24.04', '-u', 'root', '--', 'python3', '-B', '-c', probe], text=True, timeout=45))
    return windows, linux
def admit():
    delay = (60, 120, 300, 600)
    while True:
        windows, linux = observe()
        if not windows and not linux['foreign_native']: return linux
        record['status'] = 'WAITING_FOREIGN_NATIVE_UNTOUCHED'
        record['foreign_wait_observations'].append(dict(at=time.time(), windows=windows, linux=linux['foreign_native']))
        save(); time.sleep(delay[min(len(record['foreign_wait_observations']) - 1, 3)])
budget = None
def run(label, argv, timeout, environment=None):
    bound()
    result = owned.command([str(arg) for arg in argv], cwd=R,
                           environment=dict(os.environ) if environment is None else environment,
                           timeout=timeout, budget=budget, output_limit=16 * 1024 * 1024,
                           directory=E / ('posix-retained-combined-' + label + '-execution-01'),
                           wait_for_job_empty_after_primary=False)
    item = dict(label=label, exit=result.returncode, termination=result.receipt['termination'],
                primary_stopped=result.receipt['primary_stopped'], job_empty=result.receipt['job_empty_observed'],
                receipt=str(result.directory / 'receipt.json'), receipt_sha256=sha(result.directory / 'receipt.json'))
    record['commands'].append(item); save()
    assert result.ok and item['primary_stopped'] and item['job_empty'], label
    bound()
    return result
try:
    bound(); save()
    linux = admit()
    native_build.require_disk_reserve(W)
    record['free_bytes_before'] = shutil.disk_usage(W).free
    assert record['free_bytes_before'] >= record['reserve_bytes'] + record['planned_peak_bytes']
    record['resource_hygiene_receipt'] = assurance['source_prepare_sha256']
    budget = owned.Budget(7200, 5600)
    record['status'] = 'QUALIFYING_ACTUAL_COMBINED_LINUX_SOURCE'; save()
    linux_e = '/mnt/d/' + str(E)[3:].replace('\\', '/')
    run('linux', ['wsl', '-d', 'Ubuntu-24.04', '-u', 'root', '--', 'env', 'FACMAN_PARENT_MOUNT_NAMESPACE=' + linux['mount_namespace'],
                  'timeout', '--signal=TERM', '--kill-after=10s', '5400s', 'unshare', '--mount', '--pid', '--fork',
                  '--kill-child=SIGKILL', '--mount-proc', '--propagation', 'private', 'python3', '-B',
                  linux_e + '/posix-retained-rewrite-combined-linux-driver-01.py'], 5500)
    linux_result = json.loads((E / 'posix-retained-rewrite-combined-linux-result-01.json').read_text())
    assert linux_result['status'].startswith('PASS_') and linux_result['remaining_namespace_processes'] == []
    # No Windows binary rebuild. Actual MSVC preprocessing establishes the
    # corrected Win32 runtime token equivalence to the integrated dev source.
    admit()
    record['status'] = 'PROVING_WINDOWS_PREPROCESSED_RUNTIME_REUSE'; save()
    compiler_metadata = next((B / 'CMakeFiles').glob('*/CMakeCXXCompiler.cmake')).read_text()
    compiler = Path(re.search(r'set\(CMAKE_CXX_COMPILER "([^"]+)"\)', compiler_metadata)[1])
    vc_root = next(parent for parent in compiler.parents if parent.name.upper() == 'VC')
    vcvars = vc_root / 'Auxiliary/Build/vcvarsall.bat'
    assert compiler.is_file() and vcvars.is_file() and '"' not in str(vcvars)
    setup = subprocess.check_output(['cmd', '/d', '/s', '/c', 'call "' + str(vcvars) + '" x64 >nul && set'], env=dict(os.environ), timeout=60)
    selected = {}
    wanted = {'path', 'include', 'lib', 'libpath', 'vctoolsinstalldir', 'windowssdkdir', 'windowssdkversion'}
    for line in setup.decode(errors='replace').splitlines():
        if '=' in line:
            name, value = line.split('=', 1)
            if name.casefold() in wanted: selected[name] = value
    assert any(name.casefold() == 'include' for name in selected)
    environment = dict(os.environ, **selected)
    token = r'"(?:\\.|[^"\\])*"|\x27(?:\\.|[^\x27\\])*\x27|[^\s]'
    proofs = []
    for relative in ('runtime/platform/fl_file_io.cpp', 'runtime/base/fl_local_operation_lock.cpp'):
        name = Path(relative).stem
        baseline = E / ('posix-retained-windows-9bb-' + name + '-01.cpp')
        assert not baseline.exists()
        baseline.write_bytes(subprocess.check_output(['git', 'show', assurance['base'] + ':' + relative], cwd=R))
        flags = [compiler, '/nologo', '/EP', '/TP', '/std:c++17', '/I' + str(R / 'runtime/platform'),
                 '/I' + str(R / 'runtime/core'), '/I' + str(R / 'runtime/base')]
        old = run('windows-pp-' + name + '-base', [*flags, baseline], 180, environment)
        new = run('windows-pp-' + name + '-current', [*flags, R / relative], 180, environment)
        old_tokens = re.findall(token, old.stdout.decode(errors='strict'))
        new_tokens = re.findall(token, new.stdout.decode(errors='strict'))
        assert old_tokens == new_tokens, ('Windows-preprocessed runtime token drift', relative)
        proofs.append(dict(path=relative, compiler=str(compiler), baseline_raw_sha256=sha(baseline),
                           current_raw_sha256=sha(R / relative), tokens_unchanged=True,
                           token_sha256=hashlib.sha256(json.dumps(new_tokens, separators=(',', ':')).encode()).hexdigest(),
                           base_preprocess_receipt_sha256=old.receipt['stdout']['sha256'],
                           current_preprocess_receipt_sha256=new.receipt['stdout']['sha256']))
    # 805 is the exact merged PR410 source. Its Windows runtime preimages are
    # identical to 9bb; qualification image02 was sealed before the merge.
    source805 = '8058694049b992118cc41e0a9b34dc5ef46664b1'
    same805 = {}
    for relative in ('runtime/platform/fl_file_io.cpp', 'runtime/base/fl_local_operation_lock.cpp',
                     'runtime/factorio/instance/flb_factorio_configuration_preparation.cpp',
                     'runtime/factorio/instance/flb_factorio_instance_model.cpp', 'runtime/factorio/saves/flb_factorio_selected_context.cpp'):
        base = subprocess.check_output(['git', 'show', assurance['base'] + ':' + relative], cwd=R)
        previous = subprocess.check_output(['git', 'show', source805 + ':' + relative], cwd=R)
        assert base == previous, relative
        same805[relative] = hashlib.sha256(base).hexdigest()
    previous = json.loads((E / 'posix-preparation-publication-windows-result-02.json').read_text())
    image = E / 'posix-publication-qualified-combined-windows-cli-02.exe'
    assert previous['status'] == 'PASS_WINDOWS_NATIVE_AND_EXISTING_OWNER_REGRESSIONS' and sha(image) == previous['cli_sha256']
    reuse = dict(status='PASS_SCOPED_WINDOWS_RUNTIME_REUSE_NEW_SOURCE_CI_REQUIRED',
                 base=assurance['base'], merged_source805=source805, source805_runtime_bytes_identical=same805,
                 corrected_runtime_preprocessed_proofs=proofs,
                 reused_result_sha256=sha(E / 'posix-preparation-publication-windows-result-02.json'),
                 reused_image=str(image), reused_image_sha256=sha(image), new_windows_binary_qualified=False,
                 existing_owner_platform_abi_regression_reused=True, mandatory_new_source_windows_ci=True)
    (E / 'posix-retained-rewrite-windows-scoped-reuse-01.json').write_text(json.dumps(reuse, indent=2) + '\n')
    record['windows_reuse_sha256'] = sha(E / 'posix-retained-rewrite-windows-scoped-reuse-01.json')
    run('strict', ['py', '-3', '-B', 'tools/strict_check.py'], 1800)
    run('aide', ['py', '-3', '-B', '.aide/scripts/aide_lite.py', 'test'], 600)
    record.update(status='PASS_COMBINED_LINUX_AND_SCOPED_WINDOWS_REUSE',
                  linux_result_sha256=sha(E / 'posix-retained-rewrite-combined-linux-result-01.json'),
                  task_source_files_sha256=assurance['task_source_files_sha256'], full_windows_ci_required=True)
except BaseException as error:
    record.update(status='ACTIONABLE_COMBINED_QUALIFICATION_FAILURE', error=str(error), traceback=traceback.format_exc())
finally:
    bound()
    record['free_bytes_after'] = shutil.disk_usage(W).free
    windows, linux_after = observe()
    record['native_processes_after'] = dict(windows=windows, linux=linux_after['foreign_native'])
    mount = linux_e + '/posix-publication-private-fixtures-01'
    check = 'import os,json;print(json.dumps(dict(mounted=os.path.ismount(' + repr(mount) + '),empty=not os.listdir(' + repr(mount) + '))))'
    record['parent_mount_after'] = json.loads(subprocess.check_output(['wsl', '-d', 'Ubuntu-24.04', '-u', 'root', '--', 'python3', '-B', '-c', check], text=True))
    save()
    print(json.dumps({key:value for key,value in record.items() if key not in ('commands', 'task_source_files_sha256', 'foreign_wait_observations')}, indent=2))
    raise SystemExit(0 if record['status'].startswith('PASS_') else 1)
