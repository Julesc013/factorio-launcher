import difflib
import hashlib
import json
from pathlib import Path
import subprocess

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
path = 'runtime/platform/fl_file_io.cpp'
source = R / path
before = source.read_bytes()
sha = lambda data: hashlib.sha256(data).hexdigest()
prepare = json.loads((E / 'posix-retained-rewrite-prepare-result-01.json').read_text())
assert sha(before) == prepare['source_files_sha256'][path]
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == prepare['base']
newline = '\r\n' if before.count(b'\r\n') == before.count(b'\n') else '\n'
old = '''        !impl_ || impl_->handle == kInvalidHandle)
        return IoStatus::failure("retained_rewrite_admission_invalid", "Bound original/intended stream inputs are invalid");
#ifdef _WIN32
    if (!impl_->identity.fixed_local_volume || impl_->identity.filesystem_name != "NTFS")
        return IoStatus::failure("retained_rewrite_admission_invalid", "Bound original/intended stream inputs are invalid");
#endif'''.replace('\n', newline).encode()
new = '''        !impl_
#ifdef _WIN32
        || !impl_->identity.fixed_local_volume || impl_->identity.filesystem_name != "NTFS"
#else
        || impl_->handle == kInvalidHandle
#endif
        )
        return IoStatus::failure("retained_rewrite_admission_invalid", "Bound original/intended stream inputs are invalid");'''.replace('\n', newline).encode()
assert before.count(old) == 1
after = before.replace(old, new)
assert before != after
before_path = E / 'posix-retained-rewrite-opener-before-01.cpp'
after_path = E / 'posix-retained-rewrite-opener-after-01.cpp'
patch_path = E / 'posix-retained-rewrite-opener-correction-01.patch'
for candidate in (before_path, after_path, patch_path): assert not candidate.exists()
before_path.write_bytes(before); after_path.write_bytes(after)
patch = 'diff --git a/' + path + ' b/' + path + '\n' + ''.join(difflib.unified_diff(
    before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), fromfile='a/' + path, tofile='b/' + path))
patch_path.write_bytes(patch.encode())
source.write_bytes(after)
record = dict(schema='facman.posix_retained_windows_admission_restoration.v1',
              status='NARROW_AUTHORIZED_PREDICATE_CORRECTION_PREPROCESSING_PROOF_PENDING',
              base=prepare['base'], branch=prepare['branch'], path=path,
              before_sha256=sha(before), after_sha256=sha(after), delta_patch_sha256=sha(patch.encode()),
              changed_scope='one admission predicate only; original Windows NTFS predicate and refusal order restored; closed-parent check remains POSIX only',
              linux_preprocessed_tokens_expected_unchanged=True,
              windows_original_token_restoration_required=True,
              source_authorization='root directed narrow correction before qualification; no native job had started',
              application_owner_admitted=False, branch_commit_push_mutated=False)
(E / 'posix-retained-rewrite-opener-correction-01.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
