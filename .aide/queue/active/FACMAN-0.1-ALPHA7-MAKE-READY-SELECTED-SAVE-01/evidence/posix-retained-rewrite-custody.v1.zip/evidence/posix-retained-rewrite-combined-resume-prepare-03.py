import ast
import hashlib
import json
from pathlib import Path

E = Path(__file__).resolve().parent
linux = json.loads((E / 'posix-retained-rewrite-combined-linux-result-02.json').read_text())
assert linux['status'] == 'PASS_ACTUAL_COMBINED_LINUX_PRIMITIVE_PUBLICATION_AND_CLOSED_ADMISSION'
assert linux['remaining_namespace_processes'] == [] and linux['private_mount_absent']
source = (E / 'posix-retained-rewrite-combined-launch-02.py').read_text()
source = source.replace('posix-retained-rewrite-combined-launch-result-02.json', 'posix-retained-rewrite-combined-launch-result-03.json')
source = source.replace("'-execution-02'", "'-execution-03'")
start = source.index("    record['status'] = 'QUALIFYING_ACTUAL_COMBINED_LINUX_SOURCE'")
end = source.index('    # No Windows binary rebuild.', start)
source = source[:start] + """    linux_e = '/mnt/d/' + str(E)[3:].replace('\\\\', '/')
    linux_result = json.loads((E / 'posix-retained-rewrite-combined-linux-result-02.json').read_text())
    assert linux_result['status'].startswith('PASS_') and linux_result['remaining_namespace_processes'] == []
    record['reused_actual_combined_linux_result_sha256'] = sha(E / 'posix-retained-rewrite-combined-linux-result-02.json')
""" + source[end:]
old = """    setup = subprocess.check_output(['cmd', '/d', '/s', '/c', 'call "' + str(vcvars) + '" x64 >nul && set'], env=dict(os.environ), timeout=60)"""
new = """    setup_script = E / 'posix-retained-msvc-environment-03.cmd'
    assert not setup_script.exists() and '%' not in str(vcvars)
    setup_script.write_bytes(('@echo off\\r\\ncall "' + str(vcvars) + '" x64 >nul\\r\\nif errorlevel 1 exit /b %errorlevel%\\r\\nset\\r\\n').encode())
    # The fixed batch path has no shell metacharacters or spaces. Quoting of
    # the SDK path belongs inside the batch, not Python argv serialization.
    assert not any(character in str(setup_script) for character in ' &|<>^%"')
    setup = subprocess.check_output(['cmd', '/d', '/c', str(setup_script)], env=dict(os.environ), timeout=60)"""
assert source.count(old) == 1
source = source.replace(old, new)
ast.parse(source)
out = E / 'posix-retained-rewrite-combined-launch-03.py'
assert not out.exists(); out.write_text(source, encoding='utf-8')
print(json.dumps(dict(status='RESUME_ONLY_WINDOWS_PREPROCESS_REUSE_AND_REPOSITORY_GATES',
                     launcher_sha256=hashlib.sha256(out.read_bytes()).hexdigest(), linux_rerun=False)))
