import ast
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import traceback

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
W = E.parent
B = W / 'native-developer'
sys.path.insert(0, str(R))
from tools import native_build, provider_canary_process as owned
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
assurance = json.loads((E / 'posix-retained-rewrite-combined-source-assurance-02.json').read_text())
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds', TEMP=str(W / 't'), TMP=str(W / 't'),
                  PYTHONDONTWRITEBYTECODE='1', CMAKE_BUILD_PARALLEL_LEVEL='2', FACMAN_MIN_FREE_GIB='12', MSBUILDDISABLENODEREUSE='1')
out = E / 'posix-retained-rewrite-combined-launch-result-05.json'
assert not out.exists()
record = dict(schema='facman.posix_retained_combined_qualification_launch.v1', status='PREPARING',
              source_assurance_sha256=sha(E / 'posix-retained-rewrite-combined-source-assurance-02.json'),
              base=assurance['base'], branch=assurance['branch'], commands=[], foreign_wait_observations=[],
              reserve_bytes=12 * 1024 ** 3, planned_peak_bytes=2 * 1024 ** 3,
              new_roots=0, new_candidates=0, new_clones=0, new_worktrees=0,
              optional_windows_rebuild=False, windows_cli07_moved=False)
def save(): out.write_text(json.dumps(record, indent=2) + '\n')
def bound():
    assert sha(R / 'tools/local_lock_check.py') == '780e2541a32d3e972e4ea6ed12f0958ed998ad237a9501787932720544dce9ec'
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == assurance['base']
    assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=R, text=True).strip() == assurance['branch']
    for group in ('task_source_files_sha256', 'context_source_files_sha256'):
        for path, expected in assurance[group].items(): assert sha(R / path) == expected, path
    for path, expected in assurance['preserved_earlier_qualified_images'].items(): assert sha(path) == expected
    assert sha(assurance['cli07_preservation']['source']) == assurance['cli07_preservation']['sha256']
    for name, expected in assurance['windows_provider_sha256'].items(): assert sha(B / 'Release' / name) == expected
query = r"$all=@(Get-CimInstance Win32_Process); $active=@($all | Where-Object { $_.Name -match '^(cl|clang|link|ninja|ctest)\.exe$' -or ($_.Name -eq 'cmake.exe' -and $_.CommandLine -like '*--build*') -or ($_.Name -eq 'MSBuild.exe' -and $_.CommandLine -notlike '*/nodemode:*') } | Select-Object Name,ProcessId,ParentProcessId,CommandLine); $active | ConvertTo-Json -Depth 4 -Compress -AsArray"
probe = '''import os,json,shutil
names={"cmake","ninja","g++","c++","cc1plus","clang","clang++","ctest","facman"}; found=[]
for p in os.listdir("/proc"):
 if p.isdigit():
  try:
   comm=open("/proc/"+p+"/comm").read().strip()
   if comm in names or comm.startswith("fl_retained"):
    found.append(dict(pid=int(p),command=open("/proc/"+p+"/cmdline","rb").read().decode(errors="replace").replace(chr(0)," ")))
  except FileNotFoundError: pass
print(json.dumps(dict(uid=os.getuid(),mount_namespace=os.readlink("/proc/self/ns/mnt"),foreign_native=found,tools={n:shutil.which(n) for n in ["cmake","ninja","c++","timeout","unshare","mount","umount","setpriv","python3"]})))'''
def observe():
    windows = json.loads(subprocess.check_output(['pwsh', '-NoProfile', '-Command', query], text=True, timeout=45) or '[]')
    linux = json.loads(subprocess.check_output(['wsl', '-d', 'Ubuntu-24.04', '-u', 'root', '--', 'python3', '-B', '-c', probe], text=True, timeout=45))
    return windows, linux
def admit():
    delay = (60, 120, 300, 600)
    while True:
        windows, linux = observe()
        if not windows and not linux['foreign_native']: return linux
        record['status'] = 'WAITING_FOREIGN_NATIVE_UNTOUCHED'
        record['foreign_wait_observations'].append(dict(at=time.time(), windows=windows, linux=linux['foreign_native']))
        save(); time.sleep(delay[min(len(record['foreign_wait_observations']) - 1, 3)])
budget = None
def run(label, argv, timeout, environment=None):
    bound()
    result = owned.command([str(arg) for arg in argv], cwd=R,
                           environment=dict(os.environ) if environment is None else environment,
                           timeout=timeout, budget=budget, output_limit=16 * 1024 * 1024,
                           directory=E / ('posix-retained-combined-' + label + '-execution-05'),
                           wait_for_job_empty_after_primary=False)
    item = dict(label=label, exit=result.returncode, termination=result.receipt['termination'],
                primary_stopped=result.receipt['primary_stopped'], job_empty=result.receipt['job_empty_observed'],
                receipt=str(result.directory / 'receipt.json'), receipt_sha256=sha(result.directory / 'receipt.json'))
    record['commands'].append(item); save()
    assert result.ok and item['primary_stopped'] and item['job_empty'], label
    bound()
    return result
try:
    bound(); save()
    linux = admit()
    native_build.require_disk_reserve(W)
    record['free_bytes_before'] = shutil.disk_usage(W).free
    assert record['free_bytes_before'] >= record['reserve_bytes'] + record['planned_peak_bytes']
    record['resource_hygiene_receipt'] = assurance['source_prepare_sha256']
    budget = owned.Budget(7200, 5600)
    linux_e = '/mnt/d/' + str(E)[3:].replace('\\', '/')
    linux_result = json.loads((E / 'posix-retained-rewrite-combined-linux-result-02.json').read_text())
    assert linux_result['status'].startswith('PASS_') and linux_result['remaining_namespace_processes'] == []
    record['reused_actual_combined_linux_result_sha256'] = sha(E / 'posix-retained-rewrite-combined-linux-result-02.json')
    reuse_path = E / 'posix-retained-rewrite-windows-scoped-reuse-01.json'
    assert sha(reuse_path) == '1983dde85f9134eee359a3d80c36c16cff7e96a2cbcc452afd91a494eea6e35b'
    reuse = json.loads(reuse_path.read_text())
    assert reuse['base'] == assurance['base'] and all(p['tokens_unchanged'] for p in reuse['corrected_runtime_preprocessed_proofs'])
    record['windows_reuse_sha256'] = sha(reuse_path)
    record['local_lock_checker_correction_sha256'] = sha(E / 'posix-retained-rewrite-local-lock-check-correction-01.json')
    record['additional_check_source'] = {'tools/local_lock_check.py': sha(R / 'tools/local_lock_check.py')}
    run('local-lock', ['py', '-3', '-B', 'tools/local_lock_check.py'], 180)
    run('strict', ['py', '-3', '-B', 'tools/strict_check.py'], 1800)
    run('aide', ['py', '-3', '-B', '.aide/scripts/aide_lite.py', 'test'], 600)
    record.update(status='PASS_COMBINED_LINUX_AND_SCOPED_WINDOWS_REUSE',
                  linux_result_sha256=sha(E / 'posix-retained-rewrite-combined-linux-result-02.json'),
                  task_source_files_sha256=assurance['task_source_files_sha256'], full_windows_ci_required=True)
except BaseException as error:
    record.update(status='ACTIONABLE_COMBINED_QUALIFICATION_FAILURE', error=str(error), traceback=traceback.format_exc())
finally:
    bound()
    record['free_bytes_after'] = shutil.disk_usage(W).free
    windows, linux_after = observe()
    record['native_processes_after'] = dict(windows=windows, linux=linux_after['foreign_native'])
    mount = linux_e + '/posix-publication-private-fixtures-01'
    check = 'import os,json;print(json.dumps(dict(mounted=os.path.ismount(' + repr(mount) + '),empty=not os.listdir(' + repr(mount) + '))))'
    record['parent_mount_after'] = json.loads(subprocess.check_output(['wsl', '-d', 'Ubuntu-24.04', '-u', 'root', '--', 'python3', '-B', '-c', check], text=True))
    save()
    print(json.dumps({key:value for key,value in record.items() if key not in ('commands', 'task_source_files_sha256', 'foreign_wait_observations')}, indent=2))
    raise SystemExit(0 if record['status'].startswith('PASS_') else 1)
