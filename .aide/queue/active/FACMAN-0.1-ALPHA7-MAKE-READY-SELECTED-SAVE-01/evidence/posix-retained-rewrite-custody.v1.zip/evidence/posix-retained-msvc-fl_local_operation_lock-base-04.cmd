@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Auxiliary\Build\vcvarsall.bat" x64 >nul
if errorlevel 1 exit /b %errorlevel%
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.51.36231\bin\Hostx64\x64\cl.exe" "/nologo" "/EP" "/TP" "/std:c++17" "/ID:\Projects\Factorio\factorio-launcher\runtime\platform" "/ID:\Projects\Factorio\factorio-launcher\runtime\core" "/ID:\Projects\Factorio\factorio-launcher\runtime\base" "D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e\evidence\posix-retained-windows-9bb-fl_local_operation_lock-01.cpp"
exit /b %errorlevel%
