import ast
import hashlib
import json
import re
import subprocess
from pathlib import Path

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
W = E.parent
A = E / 'posix-retained-rewrite-author-01'
sha = lambda data: hashlib.sha256(data).hexdigest()
prepare = json.loads((E / 'posix-retained-rewrite-prepare-result-01.json').read_text())
def git(*args, cwd=R):
    return subprocess.check_output(['git', *args], cwd=cwd).decode().rstrip('\r\n')
assert git('rev-parse', 'HEAD') == prepare['base'] == '9bb5eef08b3ebf633dd32667e31ab701fed2a122'
assert git('branch', '--show-current') == prepare['branch']
assert set(line[3:] for line in git('status', '--porcelain=v1', '--untracked-files=all').splitlines()) == set(prepare['source_files_sha256'])
# Reconstruct reviewed patches on exact current dev bytes. Offset changes from
# PR410 are admitted only through exact hunk text; no obsolete 0b8 hash rule.
def apply_patch(files, patch):
    lines = patch.splitlines(keepends=True)
    path = None; index = 0
    while index < len(lines):
        line = lines[index]
        if line.startswith('+++ b/'):
            path = line[6:].strip()
            if path not in files:
                try:
                    files[path] = subprocess.check_output(['git', 'show', prepare['base'] + ':' + path], cwd=R, stderr=subprocess.DEVNULL).decode()
                except subprocess.CalledProcessError:
                    files[path] = ''
        elif line.startswith('@@ '):
            header = re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', line)
            assert header and path
            old, new = [], []
            index += 1
            while index < len(lines) and not lines[index].startswith(('@@ ', 'diff --git ')):
                entry = lines[index]
                if entry.startswith(' '): old.append(entry[1:]); new.append(entry[1:])
                elif entry.startswith('-'): old.append(entry[1:])
                elif entry.startswith('+'): new.append(entry[1:])
                elif entry.startswith('\\ No newline'): pass
                else: raise AssertionError(entry)
                index += 1
            assert len(old) == int(header[2] or 1) and len(new) == int(header[4] or 1)
            current = files[path].splitlines(keepends=True)
            if old:
                positions = [position for position in range(len(current) - len(old) + 1) if current[position:position + len(old)] == old]
                assert positions, (path, line)
                position = min(positions, key=lambda candidate: abs(candidate - (int(header[3]) - 1)))
            else:
                position = int(header[3]) - 1
            current[position:position + len(old)] = new
            files[path] = ''.join(current)
            continue
        index += 1
    return files
files = apply_patch({}, (A / 'source.patch').read_text())
files = apply_patch(files, (A / 'source-process-death-delta-02.patch').read_text())
for path, expected in prepare['source_files_sha256'].items():
    actual = (R / path).read_bytes()
    assert sha(actual) == expected, path
    assert actual.decode().replace('\r\n', '\n') == files[path].replace('\r\n', '\n'), ('current-base canonical patch reconstruction', path)
    if path.endswith('.py'): ast.parse(actual.decode(), filename=path)
baseline_lock = subprocess.check_output(['git', 'show', prepare['base'] + ':runtime/base/fl_local_operation_lock.cpp'], cwd=R).decode()
shared = (R / 'runtime/platform/fl_local_filesystem.h').read_text()
assert re.findall(r'case (0x[0-9A-Fa-f]+UL):', baseline_lock) == re.findall(r'case (0x[0-9A-Fa-f]+UL):', shared)
def windows_branch(text):
    begin = text.index('#ifdef _WIN32') + len('#ifdef _WIN32')
    return text[begin:text.index('\n#else', begin)]
base_io = subprocess.check_output(['git', 'show', prepare['base'] + ':runtime/platform/fl_file_io.cpp'], cwd=R).decode()
actual_io = (R / 'runtime/platform/fl_file_io.cpp').read_text()
for signature in ('IoStatus RetainedStreamRewriteFile::observe(', 'IoStatus RetainedStreamRewriteFile::readable_metadata_identity('):
    assert windows_branch(base_io[base_io.index(signature):]) == windows_branch(actual_io[actual_io.index(signature):])
owners = ['runtime/factorio/instance/flb_factorio_configuration_preparation.cpp',
          'runtime/factorio/instance/flb_factorio_instance_model.cpp', 'runtime/factorio/saves/flb_factorio_selected_context.cpp']
assert not git('diff', '--', *owners)
owner = (R / owners[0]).read_text(); model = (R / owners[1]).read_text()
for signature in ('Result reconcile_existing_configuration(', 'Result recover_existing_configuration('):
    assert re.search(r'\{\s*#ifndef _WIN32\s*return refused\("configuration_publication_unavailable"', owner[owner.index(signature):])
planner = model[model.index('facman::core::Result<std::string> existing_configuration_plan('):]
assert planner.index('if (delta.bytes == p.config->text)') < planner.index('#ifndef _WIN32')
context = owners + ['release/index/workspace_lock.v1.toml', 'tools/requirements-dev.lock',
                    'tests/native/fl_platform_io_smoke.cpp', 'tests/native/facman_abi_layout_smoke.cpp',
                    'tests/test_configuration_preparation.py', 'tests/test_selected_save_preparation.py',
                    'tests/test_configuration_reconciliation.py', 'tests/test_posix_preparation_publication.py',
                    'runtime/platform/fl_retained_rewrite_state.h', 'tools/abi_symbol_check.py']
providers = {
    'ulk': dict(root=str(W / 'providers/universal-launcher-5479939ca5cb'), pin='5479939ca5cbc9ee0f901608a92012778b4752ae', tree='7728e4d415539a0f24e6f17aa7d22be00cc99d80'),
    'usk': dict(root=str(W.parent / 'task-facman-u-507ecf4b41/providers/universal-setup-2749a15b835a'), pin='2749a15b835a6c1c9968598a2b434d85809691ad', tree='5cfd42acea5242a5a04fc79140fcfdf7accf6ee4')}
for provider in providers.values():
    root = Path(provider['root'])
    assert git('rev-parse', 'HEAD', cwd=root) == provider['pin']
    assert git('rev-parse', 'HEAD^{tree}', cwd=root) == provider['tree']
    assert not git('status', '--porcelain=v1', cwd=root)
prior = json.loads((E / 'tui-selected-save-native-result-07.json').read_text())
source_cli = W / 'native-developer/Release/facman.exe'
assert sha(source_cli.read_bytes()) == prior['cli_sha256'] == 'c0a41c31da11b96ffca19d149c6749ce1dd1af229f3c2b776e2737cb3255749f'
for name, expected in prior['provider_sha256'].items():
    assert sha((source_cli.parent / name).read_bytes()) == expected
earlier = {str(path): sha(path.read_bytes()) for path in E.glob('*qualified*') if path.is_file() and path.suffix in ('.exe', '.bin')}
record = dict(schema='facman.posix_retained_combined_source_assurance.v1',
              status='PASS_AUTHOR_CURRENT_BASE_SOURCE_BINDING_NATIVE_QUALIFICATION_REQUIRED',
              independent=False, base=prepare['base'], branch=prepare['branch'],
              task_source_files_sha256=prepare['source_files_sha256'],
              context_source_files_sha256={path: sha((R / path).read_bytes()) for path in context},
              source_prepare_sha256=sha((E / 'posix-retained-rewrite-prepare-result-01.json').read_bytes()),
              reviewed_patch_sha256=sha((A / 'source.patch').read_bytes()),
              reviewed_sigkill_delta_sha256=sha((A / 'source-process-death-delta-02.patch').read_bytes()),
              exact_current_base_canonical_patch_reconstruction=True,
              checkout_newline_conversion='canonical Git text reconstructed; separate physical SHA256 binds actual CRLF/LF checkout bytes',
              windows_observe_metadata_branch_unchanged=True,
              filesystem_allowlist_unchanged=True, owner_files_unchanged=True,
              independent_existing_ini_owner_gates_closed=True, already_current_ordering_preserved=True,
              providers=providers, preserved_earlier_qualified_images=earlier,
              cli07_preservation=dict(source=str(source_cli), sha256=prior['cli_sha256'], action='retain unchanged; Windows rebuild cancelled by root'),
              windows_regression_reuse=dict(result='posix-preparation-publication-windows-result-02.json', image='posix-publication-qualified-combined-windows-cli-02.exe', full_new_source_ci_required=True, complete_preprocessed_equivalence_pending=True),
              windows_provider_sha256=prior['provider_sha256'],
              new_roots=0, new_worktrees=0, new_clones=0, new_candidates=0)
out = E / 'posix-retained-rewrite-combined-source-assurance-01.json'
assert not out.exists()
out.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(dict(status=record['status'], assurance_sha256=sha(out.read_bytes()), task_paths=len(prepare['source_files_sha256']), providers={key: value['pin'] for key,value in providers.items()})))
