import hashlib
import json
from pathlib import Path
import subprocess

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
driver = (E / 'posix-retained-rewrite-combined-linux-driver-01.py').read_text()
driver = driver.replace("out = E / 'posix-retained-rewrite-combined-linux-result-01.json'", "out = E / 'posix-retained-rewrite-combined-linux-result-02.json'")
driver = driver.replace('posix-retained-combined-linux01-', 'posix-retained-combined-linux02-')
driver = driver.replace('posix-retained-combined-unresolved-fixtures-01.tar', 'posix-retained-combined-unresolved-fixtures-02.tar')
driver = driver.replace("os.environ.update(PYTHONDONTWRITEBYTECODE='1'", "os.environ.update(GIT_CONFIG_COUNT='1', GIT_CONFIG_KEY_0='core.autocrlf', GIT_CONFIG_VALUE_0='true', PYTHONDONTWRITEBYTECODE='1'")
target = E / 'posix-retained-rewrite-combined-linux-driver-02.py'
assert not target.exists(); target.write_text(driver, encoding='utf-8')
launcher = (E / 'posix-retained-rewrite-combined-launch-01.py').read_text()
launcher = launcher.replace('posix-retained-rewrite-combined-launch-result-01.json', 'posix-retained-rewrite-combined-launch-result-02.json')
launcher = launcher.replace("'-execution-01'", "'-execution-02'")
launcher = launcher.replace('posix-retained-rewrite-combined-linux-driver-01.py', 'posix-retained-rewrite-combined-linux-driver-02.py')
launcher = launcher.replace('posix-retained-rewrite-combined-linux-result-01.json', 'posix-retained-rewrite-combined-linux-result-02.json')
target2 = E / 'posix-retained-rewrite-combined-launch-02.py'
assert not target2.exists(); target2.write_text(launcher, encoding='utf-8')
assurance = json.loads((E / 'posix-retained-rewrite-combined-source-assurance-02.json').read_text())
observations = []
for provider in assurance['providers'].values():
    root = Path(provider['root'])
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == provider['pin']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=root, text=True).strip() == provider['tree']
    assert not subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=root, text=True).strip()
    original = subprocess.check_output(['git', 'show', 'HEAD:.gitignore'], cwd=root)
    physical = (root / '.gitignore').read_bytes()
    assert original.replace(b'\r\n', b'\n') == physical.replace(b'\r\n', b'\n')
    observations.append(dict(root=str(root), pin=provider['pin'], tree=provider['tree'], windows_clean=True,
                             gitignore_physical_sha256=hashlib.sha256(physical).hexdigest(),
                             gitignore_git_blob_sha256=hashlib.sha256(original).hexdigest(),
                             canonical_gitignore_bytes_equal=True))
record = dict(status='CONFIRMED_PROCESS_ONLY_HOST_NORMALIZATION_RETRY', failed_native_job=sha(E / 'posix-retained-combined-linux-execution-01/receipt.json'),
              failed_outer_result=sha(E / 'posix-retained-rewrite-combined-launch-result-01.json'),
              failed_driver_sha256=sha(E / 'posix-retained-rewrite-combined-linux-driver-01.py'),
              corrected_driver_sha256=sha(target), providers=observations,
              process_environment=dict(GIT_CONFIG_COUNT='1', GIT_CONFIG_KEY_0='core.autocrlf', GIT_CONFIG_VALUE_0='true'),
              provider_bytes_changed=False, repository_or_global_git_config_changed=False,
              failed_cell_compiler_or_product_test_ran=False, cleanup_verified=True)
(E / 'posix-retained-rewrite-provider-host-normalization-02.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(dict(status=record['status'], retry_driver_sha256=sha(target), source_correction_changed=False)))
