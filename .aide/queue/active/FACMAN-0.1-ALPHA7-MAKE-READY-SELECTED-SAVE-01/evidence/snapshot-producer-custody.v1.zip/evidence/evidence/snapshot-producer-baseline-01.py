import hashlib,json,os,subprocess,sys
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e');E=W/'evidence';G=W/'t/j3/gdf';Q=W/'t/j3/qdf';C=W/'t/j3/cdf3'
sys.path.insert(0,str(R));from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def inv(root):
 return {p.relative_to(root).as_posix():dict(kind='directory') if p.is_dir() else dict(kind='file',sha256=sha(p),bytes=p.stat().st_size,object=p.stat().st_ino,device=p.stat().st_dev) for p in sorted(root.rglob('*'))}
assert not (E/'snapshot-producer-baseline-result-01.json').exists()
assert G.is_dir() and Q.is_dir() and C.is_dir()
assert sha(G/'bin/facman.exe')=='fe661038c7d7861a03894461da8f7b3f17b665fedd5267baa1e614753046c295'
assert subprocess.check_output(['git','status','--porcelain'],cwd=R)==b''
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='45387703b4d84a7d9a90c8ef07729777cb4ffe93'
before=dict(package=inv(G),fixture=inv(Q))
env={k:v for k,v in os.environ.items() if not k.upper().startswith(('FACMAN','FLAUNCH','ULK','USK','PYTHONPATH'))}
env.update(PATH=os.environ['SystemRoot']+'\\System32',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1')
calls=[]
for name,args in [
 ('identity',['product','inspect']),
 ('instances',['instances','list']),
 ('saves-default',['presentation','query','saves']),
 ('saves-selected',['presentation','query','saves','--instance','main']),
 ('content-selected',['presentation','query','content','--instance','main']),
 ('snapshot-inspect',['snapshots','inspect','main','world']),
]:
 cap=owned.command([str(G/'bin/facman.exe'),'--workspace',str(Q/'source'),*args,'--json'],cwd=C,environment=env,timeout=25,directory=E/('snapshot-producer-baseline-'+name+'-01'),output_limit=1024**2,wait_for_job_empty_after_primary=True)
 assert cap.ok and cap.receipt['primary_stopped'] and cap.receipt['job_empty_observed'] and not cap.receipt['job_terminated']
 value=json.loads(cap.stdout)
 calls.append(dict(name=name,args=args,payload=value['payload'],receipt_sha256=sha(cap.directory/'receipt.json'),stdout_sha256=sha(cap.directory/'stdout.raw')))
after=dict(package=inv(G),fixture=inv(Q));assert before==after
byname={c['name']:c['payload'] for c in calls}
actions={name:[dict(action_id=a['action_id'],availability=a['availability'],input_fields=a['input_fields']) for a in byname[name]['available_semantic_actions']] for name in ['saves-default','saves-selected','content-selected']}
assert all(a['action_id']!='snapshots.create' for rows in actions.values() for a in rows)
assert any(a['action_id']=='snapshots.restore' for a in actions['saves-selected'])
report=byname['snapshot-inspect'];assert report['world_bundle_state']=='available'
result=dict(schema='facman.snapshot-producer-ordinary-baseline.v1',status='MISSING_ORDINARY_SNAPSHOT_PRODUCER_CONFIRMED',source='45387703b4d84a7d9a90c8ef07729777cb4ffe93',package=str(G),backend_sha256=sha(G/'bin/facman.exe'),fixture_root=str(Q),commands=calls,actions=actions,world_bundle_state=report['world_bundle_state'],before=before,after=after,workspace_and_package_unchanged=True,owned_jobs_empty=True,product_write_calls=0,source_edits=0,builds=0,git_mutations=0,real_game=False)
(E/'snapshot-producer-baseline-result-01.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=result['status'],calls=len(calls),selected_saves_actions=[a['action_id'] for a in actions['saves-selected']],content_actions=[a['action_id'] for a in actions['content-selected']],world_bundle_state=report['world_bundle_state'],preserved=True,result_sha256=sha(E/'snapshot-producer-baseline-result-01.json')),indent=2))
