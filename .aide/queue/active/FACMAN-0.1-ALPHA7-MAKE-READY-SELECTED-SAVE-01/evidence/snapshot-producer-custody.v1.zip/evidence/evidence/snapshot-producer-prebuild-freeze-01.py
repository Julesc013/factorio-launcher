import ast,datetime,difflib,hashlib,json,os,subprocess,sys
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e');E=W/'evidence'
sys.path.insert(0,str(R));from tools import provider_canary_process as owned
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',FACMAN_MIN_FREE_GIB='12')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git','-c','core.safecrlf=false',*args],cwd=R)
assert git('branch','--show-current').decode().strip()=='task/facman-snapshot-producer-01'
assert git('rev-parse','HEAD').decode().strip()=='45387703b4d84a7d9a90c8ef07729777cb4ffe93'
marker=json.loads((W/'.facman-development-root.v1.json').read_bytes());assert marker['task_id']=='task/facman-world-restore-retention-01'
result=dict(status='FROZEN_SOURCE_PENDING_INDEPENDENT_PREBUILD_REVIEW',source_base=git('rev-parse','HEAD').decode().strip(),branch=git('branch','--show-current').decode().strip(),created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),builds=0,product_qualification_run=False,provider_changes=0,game_effects=0,commits=0,ci_runs=0,commands=[])
for name,args in [('metadata',[sys.executable,'-B','tools/codegen/generate_metadata.py','--check']),('contracts',[sys.executable,'-B','tools/codegen/generate_contracts.py','--check']),('truth',[sys.executable,'-B','tools/project_state.py','--validate']),('diff',['git','-c','core.safecrlf=false','diff','--check'])]:
 cap=owned.command(args,cwd=R,environment=dict(os.environ),timeout=180,directory=E/('snapshot-producer-prebuild-'+name+'-01'),output_limit=1024**2,wait_for_job_empty_after_primary=True)
 result['commands'].append(dict(name=name,exit_code=cap.returncode,receipt_sha256=sha(cap.directory/'receipt.json'),stdout_sha256=sha(cap.directory/'stdout.raw'),stderr_sha256=sha(cap.directory/'stderr.raw')))
 assert cap.ok and cap.receipt['primary_stopped'] and cap.receipt['job_empty_observed'] and not cap.receipt['job_terminated'],name
tracked=git('diff','--name-only','HEAD').decode().splitlines();untracked=git('ls-files','--others','--exclude-standard').decode().splitlines()
assert all(not p.startswith(('D:','../')) for p in tracked+untracked)
result['files']={p:dict(sha256=sha(R/p),bytes=(R/p).stat().st_size,tracked=p in tracked) for p in sorted(tracked+untracked)}
diff=git('diff','--binary','HEAD').decode('utf-8')
for name in untracked:
 text=(R/name).read_text(encoding='utf-8')
 diff+=''.join(difflib.unified_diff([],text.splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+name))
path=E/'snapshot-producer-prebuild-source-01.diff';path.write_text(diff,encoding='utf-8',newline='\n');result['diff']=dict(path=str(path),sha256=sha(path),bytes=path.stat().st_size)
module=ast.parse((R/'tests/test_presentation_snapshot_create.py').read_text())
result['new_semantic_test_methods']=[n.name for node in module.body if isinstance(node,ast.ClassDef) for n in node.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
ast.parse((R/'tests/test_tui_product.py').read_text())
result['ordinary_tui_method']='test_ordinary_snapshot_producer_cancels_then_roundtrips_through_restore'
result['compiled_winforms']='Existing PackImportHarness producer mode; production controls/optional fields/cancel/pending-copy and selected-context projection. Five-second finite modal observation; no physical input/backend-through-UI claim.'
result['compatibility']='Nonempty-only appended snapshot_id; absent field leaves exact prior20-field, source_path and launch_intent encodings. Public request/recorded identifier vocabulary <=128; unchanged snapshot owner path-safe <=64 admission beforeclaim.'
result['recovery']='Existing create/publication pause only. Intentionally kill retained owned child at observed publication marker, ordinary Activity generic rollback, original accepted_outcome_unknown receipt/replay preserved. Existing missing-save failure with retained incomplete transaction reports recovery_required. No create/recovery owner or new guarantees.'
result['prior_authoring_observations']=['Atomic initial apply_patch rejected unmatched WinForms context without applying any source edits; corrected context then applied.','First generate_metadata invocation omitted --write and reported expected stale outputs; existing --write regenerated them. No product/build failure or qualification campaign.']
result['metadata_only_receipts']=dict(count=3,total_json_bytes=19561,custody_sha256='eb435e8a8fdfe0303c8df1bdb379ec32b09c7c61dab87e12372e187aacd426e7',historical_pending_changed=False)
out=E/'snapshot-producer-prebuild-result-01.json';out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=result['status'],packet_sha256=sha(out),diff=result['diff'],files=len(result['files']),methods=result['new_semantic_test_methods'],checks=result['commands']),indent=2))
