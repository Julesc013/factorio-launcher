import hashlib,json,os,subprocess,traceback,zipfile,sys
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
BASE='45387703b4d84a7d9a90c8ef07729777cb4ffe93';BRANCH='task/facman-snapshot-producer-01'
ITEM='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01';Q='.aide/queue/active/'+ITEM
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),
 PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.safecrlf',GIT_CONFIG_VALUE_0='false')
sys.path.insert(0,str(R));from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
dirty=lambda:set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
out=E/'snapshot-producer-candidate-commit-result-01.json';assert not out.exists()
record=dict(status='QUALIFYING_REVIEWED_SNAPSHOT_PRODUCER',commands=[],new_roots=0,new_clones=0,new_worktrees=0)
def save():out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
def run(label,args,timeout=180,codes=(0,)):
 r=owned.command(args,cwd=R,environment=dict(os.environ),timeout=timeout,directory=E/('snapshot-producer-commit01-'+label),
  output_limit=8*1024**2,wait_for_job_empty_after_primary=True)
 record['commands'].append(dict(label=label,exit=r.returncode,receipt_sha256=sha(r.directory/'receipt.json')));save()
 assert r.returncode in codes and r.receipt['termination']=='completed' and r.receipt['primary_stopped'] and r.receipt['job_empty_observed'],(label,(r.stdout[-1500:]+r.stderr[-1500:]).decode('utf-8','replace'))
 return r
try:
 assert git('rev-parse','HEAD')==BASE and git('branch','--show-current')==BRANCH and not git('diff','--cached','--name-only')
 packet=E/'snapshot-producer-author-packet-01.json';p=json.loads(packet.read_bytes())
 review=E/'snapshot-producer-independent-review-01.json';v=json.loads(review.read_bytes())
 assert v['verdict']=='PASS_SCOPED_SOURCE_FOR_REQUIRED_CURRENT_CI' and v['packet_sha256']==sha(packet)
 expected=dirty();assert expected<=set(p['source_files'])
 for name in set(p['source_files'])-expected:
  assert name in {'.aide/memory/project-state.md','.aide/memory/project-state.v2.json','README.md'}
  assert git('hash-object','--path',name,str(R/name))==git('rev-parse','HEAD:'+name)
 for name,row in p['source_files'].items():assert sha(R/name)==row['sha256']
 for label in ('policy','detect','plan'):run(label,['py','-3','-B','.aide/scripts/aide_lite.py','git',label])
 run('paths',['py','-3','-B','tools/workspace_hygiene.py','paths'])
 h=json.loads(run('doctor',['py','-3','-B','tools/workspace_hygiene.py','doctor','--measure'],600,(0,1)).stdout)
 assert set(h['violations'])<={'unmanaged_secondary_worktrees_present'} and len(h['task_roots'])==8 and h['task_root_bytes']<20*1024**3
 custody=json.loads(Path(p['raw_custody']['path']).read_bytes());assert sha(p['raw_custody']['path'])==p['raw_custody']['sha256']
 artifacts=[E/name for name in custody['files']]+[Path(p['raw_custody']['path']),packet,review,E/'snapshot-producer-independent-review-01.py',Path(__file__)]
 manifest={}
 for path in artifacts:
  path=path.resolve(strict=True);assert path.is_relative_to(W.resolve()) and not path.is_symlink() and path.suffix.lower() not in ('.exe','.dll','.zip')
  manifest['evidence/'+path.relative_to(W).as_posix()]=sha(path)
 archive=R/Q/'evidence/snapshot-producer-custody.v1.zip';evidence=R/Q/'evidence/snapshot-producer.v1.json'
 assert not archive.exists() and not evidence.exists()
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
  z.writestr('custody-manifest.json',json.dumps(manifest,indent=2,sort_keys=True)+'\n')
  for name in sorted(manifest):z.write(W/name.removeprefix('evidence/'),name)
 with zipfile.ZipFile(archive) as z:
  assert set(z.namelist())==set(manifest)|{'custody-manifest.json'}
  for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
 assert archive.stat().st_size<8*1024**2
 evidence.write_text(json.dumps(dict(schema='facman.snapshot_producer.qualified_source.v1',base_head=BASE,
  base_tree=git('rev-parse',BASE+'^{tree}'),author_packet_sha256=sha(packet),independent_review_sha256=sha(review),
  authored_files=p['source_files'],focused_unique_methods=40,all_methods_run_on_final_binary=False,
  retained_unchanged_owner_results=True,final_native_tui_tests=2,prior_native_tests=3,
  bounded_endurance_operations=64,bounded_endurance_seconds=4.188,
  existing_snapshot_owner=True,required_name_without_default=True,blank_save_includes_none=True,
  legacy_canonical_bytes_preserved=True,ordinary_TUI_displayed_path_consumed_by_restore=True,
  source_package_mode='source_checkout',all_failures_retained=True,closed_owned_jobs=68,
  custody=archive.name,custody_sha256=sha(archive),custody_files=len(manifest),
  required_checks_pending=True,produced_package_qualified=False,workunit_closed=False,
  real_game_qualified=False,human_qualified=False,beta=False,rc=False,new_roots=0,new_clones=0,new_worktrees=0),indent=2)+'\n',encoding='utf-8')
 plan=R/Q/'ExecPlan.md';prefix=plan.read_bytes();assert hashlib.sha256(prefix).hexdigest()==p['source_files'][Q+'/ExecPlan.md']['sha256']
 suffix=('\nIndependent source review passes ordinary snapshot creation using the existing\n'
  'archive owner, required user-entered name, exact legacy receipt compatibility\n'
  'and displayed terminal archive-path handoff to ordinary restoration. Qualified\n'
  'source evidence and preserved failed attempts are hash-closed in\n'
  'evidence/snapshot-producer.v1.json and its custody. Required current-head CI\n'
  'and delivered CLI/TUI/Windows GUI acceptance remain open; no WorkUnit, game,\n'
  'provider, human, Beta or release gate is closed.\n').encode()
 plan.write_bytes(prefix+suffix)
 allowed=expected|{Q+'/ExecPlan.md',Q+'/evidence/'+archive.name,Q+'/evidence/'+evidence.name}
 run('project-state',['py','-3','-B','tools/project_state.py','--write'],600)
 run('metadata',['py','-3','-B','tools/codegen/generate_metadata.py','--write'])
 changed=dirty();assert changed<=allowed|{'.aide/memory/project-state.md','.aide/memory/project-state.v2.json','README.md'}
 assert {Q+'/evidence/'+archive.name,Q+'/evidence/'+evidence.name}<=changed
 for name,row in p['source_files'].items():
  if name==Q+'/ExecPlan.md':assert (R/name).read_bytes()==prefix+suffix
  elif name not in {'.aide/memory/project-state.md','.aide/memory/project-state.v2.json','README.md'}:assert sha(R/name)==row['sha256']
 run('strict',['py','-3','-B','tools/strict_check.py'],1800)
 run('portable-aide',['py','-3','-B','.aide/scripts/aide_lite.py','test'],1800)
 message=('feat(worlds): create snapshots through ordinary Saves workflows\n\n'
  'Require a snapshot name and explicit confirmation; show the archive path\n'
  'for ordinary restoration while preserving owner and legacy receipt bytes.\n\n'
  'Work-Item: '+ITEM+'\nEvidence-Ref: '+Q+'/evidence/'+evidence.name+'\n')
 msg=E/'snapshot-producer-candidate-commit-message-01.txt';msg.write_text(message,encoding='utf-8',newline='\n')
 run('message',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--message',message])
 changes=[dict(path=name,state='content',sha256=sha(R/name),git_blob_oid=git('hash-object','--path',name,str(R/name)),ownership='task_owned') for name in sorted(changed)]
 digest=hashlib.sha256((json.dumps(changes,indent=2,sort_keys=True,separators=(',',': '))+'\n').encode()).hexdigest()
 cr=E/'snapshot-producer-candidate-commit-review-01.json'
 cr.write_text(json.dumps(dict(schema_version='aide.git-commit-review.v1',verdict='PASS',reviewer='/root',
  author='/root/managed_update_acceptance',non_authoring=True,branch=BRANCH,base_commit=BASE,snapshot_sha256=digest,message_sha256=sha(msg),
  independent_source_review_sha256=sha(review),review='Reviewed existing snapshot dispatch, optional wire extension, immutable legacy bytes, required naming, visible TUI archive handoff,40 unique methods and344 retained raw artifacts. Hosted CI and delivered proof remain required.'),indent=2)+'\n',encoding='utf-8')
 classification=E/'snapshot-producer-candidate-commit-classification-01.json'
 classification.write_text(json.dumps(dict(schema_version='aide.git-commit-classification.v1',branch=BRANCH,base_commit=BASE,
  work_item=ITEM,snapshot_sha256=digest,message_sha256=sha(msg),changed_paths=changes,
  reviews=[dict(path=str(cr),sha256=sha(cr),verdict='PASS')]),indent=2)+'\n',encoding='utf-8')
 helper=['py','-3','-B','.aide/scripts/aide_lite.py','git','commit-plan','--classification',str(classification),'--message-file',str(msg)]
 run('plan-stage',helper);run('stage',['git','add','--',*sorted(changed)]);run('staged-diff',['git','diff','--cached','--check']);run('plan-commit',helper)
 assert git('rev-parse','HEAD')==BASE;run('commit',['git','commit','-F',str(msg)],600)
 run('range',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--range',BASE+'..HEAD'])
 # Preserve leading porcelain spaces when finding stat-only generated paths.
 raw=subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)
 if raw:
  remaining=[line[3:] for line in raw.splitlines()];assert set(remaining)<={'.aide/memory/project-state.md','.aide/memory/project-state.v2.json','README.md'}
  for name in remaining:assert git('hash-object','--path',name,str(R/name))==git('rev-parse','HEAD:'+name)
  run('refresh-generated-index',['git','add','--',*remaining])
 assert not git('status','--porcelain') and not git('diff','--cached','--name-only')
 record.update(status='COMMITTED_REVIEWED_SNAPSHOT_PRODUCER_CANDIDATE',source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),
  review_sha256=sha(cr),evidence_sha256=sha(evidence),required_checks_pending=True,remote_not_pushed=True,workunit_closed=False)
except BaseException as error:record.update(status='ACTIONABLE_SNAPSHOT_PRODUCER_COMMIT_FAILURE',error=str(error),traceback=traceback.format_exc())
finally:save();print(json.dumps({k:v for k,v in record.items() if k not in ('commands','traceback')},indent=2))
raise SystemExit(0 if record['status']=='COMMITTED_REVIEWED_SNAPSHOT_PRODUCER_CANDIDATE' else 1)
