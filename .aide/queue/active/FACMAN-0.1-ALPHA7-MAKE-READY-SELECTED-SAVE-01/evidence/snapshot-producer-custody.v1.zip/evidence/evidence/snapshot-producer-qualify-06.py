import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e');E=W/'evidence';B=W/'native-developer';sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools import provider_canary_process as owned, native_build
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();env=dict(os.environ,FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',FACMAN_MIN_FREE_GIB='12',CMAKE_BUILD_PARALLEL_LEVEL='2',MSBUILDDISABLENODEREUSE='1',PYTHONPATH=str(R/'tests')+os.pathsep+str(R))
resource=json.loads((E/'snapshot-producer-resource-02.json').read_text());assert resource['peak_within_20GiB'];assert json.loads((W/'.facman-development-root.v1.json').read_text())['task_id']=='task/facman-world-restore-retention-01';assert subprocess.check_output(['git','branch','--show-current'],cwd=R).decode().strip()=='task/facman-snapshot-producer-01'
record=dict(compiled_build_receipt='snapshot-producer-windows-build-03/receipt.json',prior_campaign='snapshot-producer-windows-result-03.json',schema='facman.snapshot_presentation_qualification.v1',status='started',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),commands=[],real_game=False,provider_edits=False,linux_builds=0)
out=E/'snapshot-producer-windows-result-06.json';assert not out.exists()
def save():owned.write_json(out,record)
save()
# Existing read-only foreign-job census; healthy waiting has no elapsed cutoff.
probe="""import json,os
active=[]
for name in os.listdir('/proc'):
 if name.isdigit():
  try:
   comm=open('/proc/'+name+'/comm').read().strip()
   if comm in {'facman','cmake','ninja','cc1plus','ctest','g++','c++','clang','clang++'}:active.append(dict(pid=int(name),command=open('/proc/'+name+'/cmdline','rb').read().decode(errors='replace').replace(chr(0),' ')))
  except FileNotFoundError:pass
print(json.dumps(dict(mount_namespace=os.readlink('/proc/self/ns/mnt'),active=active)))"""
query="$all=@(Get-CimInstance Win32_Process); @($all | Where-Object { $_.Name -match '^(cl|clang|link|ninja|ctest)\\.exe$' -or ($_.Name -eq 'cmake.exe' -and $_.CommandLine -like '*--build*') -or ($_.Name -eq 'MSBuild.exe' -and $_.CommandLine -notlike '*/nodemode:*') } | Select-Object Name,ProcessId,ParentProcessId,CommandLine) | ConvertTo-Json -Depth 4 -Compress -AsArray"
def census():return dict(windows=json.loads(subprocess.check_output(['pwsh','-NoProfile','-Command',query],text=True,timeout=45) or '[]'),linux=json.loads(subprocess.check_output(['wsl.exe','-d','Ubuntu-24.04','-u','root','--exec','/usr/bin/python3','-B','-c',probe],text=True,timeout=45)))
observations=[];last=None;wait_cycles=0
while True:
 observation=census();observation['windows'].sort(key=lambda p:p['ProcessId']);observation['linux']['active'].sort(key=lambda p:p['pid'])
 if observation!=last:
  observations.append(observation);owned.write_json(E/'snapshot-producer-heavy-admission-06.json',observations);last=observation
 if not observation['windows'] and not observation['linux']['active']:break
 time.sleep((30,45,60)[min(wait_cycles,2)]);wait_cycles+=1
record['foreign_admission_wait_cycles']=wait_cycles
frozen=json.loads((E/'snapshot-producer-prebuild-result-02.json').read_bytes())
correction=json.loads((E/'snapshot-producer-cli-compile-correction-01.json').read_bytes());assert frozen['files'][correction['path']]['sha256']==correction['before_sha256'];frozen['files'][correction['path']]['sha256']=correction['after_sha256']
test_correction=json.loads((E/'snapshot-producer-rpc-envelope-test-correction-02.json').read_bytes());frozen['files'][test_correction['path']]['sha256']=test_correction['after_sha256']
assert all(sha(R/n)==v['sha256'] for n,v in frozen['files'].items()),'Source changed before continuation'

def run(name,args,timeout=600):
 cap=owned.command(args,cwd=R,environment=env,timeout=timeout,directory=E/f'snapshot-producer-{name}-06',output_limit=32*1024*1024,wait_for_job_empty_after_primary=True)
 item=dict(name=name,argv=args,exit_code=cap.returncode,termination=cap.receipt['termination'],job_empty=cap.receipt['job_empty_observed'],primary_stopped=cap.receipt['primary_stopped'],receipt=str(cap.directory/'receipt.json'),receipt_sha256=sha(cap.directory/'receipt.json'),stdout_sha256=sha(cap.directory/'stdout.raw'),stderr_sha256=sha(cap.directory/'stderr.raw'));record['commands'].append(item);save();print(name,cap.returncode,cap.receipt['termination'],flush=True)
 if not cap.ok or not item['job_empty'] or not item['primary_stopped']:
  record.update(status='FAIL_RETAINED',failed_command=name);save();print(cap.stdout.decode(errors='replace')[-7000:]+cap.stderr.decode(errors='replace')[-7000:],flush=True);raise SystemExit(cap.returncode or 1)
exe=B/'Release/facman.exe';assert exe.is_file();env.update(FACMAN_CLI_EXE=str(exe),FACMAN_TUI_EXE=str(exe))
for name,tests in [
 ('existing-pack-import',['test_presentation_pack_import']),
 ('existing-presentation',['test_presentation_service']),
 ('immutable-legacy-receipt',['test_presentation_intent']),
 ('old-snapshots',['test_instance_snapshots']),
 ('winforms-scoped-guard',['test_facman_winforms_c1_shell.FacManWinFormsC1ShellTests.test_content_and_saves_are_ordinary_descriptor_driven_pages'])]:
 run('windows-'+name,['py','-3','-B','-m','unittest',*tests,'-v'],900)

assert all(sha(R/n)==v['sha256'] for n,v in frozen['files'].items()),'Frozen source changed during tests'
assert resource['fixture_before']=={p.relative_to(R).as_posix():sha(p) for p in (R/'tests/fixtures').rglob('*') if p.is_file()},'Fixture inputs changed'
identity=B/'generated/include/facman/build_identity.hpp';assert '45387703b4d84a7d9a90c8ef07729777cb4ffe93' in identity.read_text()
record['compiled_identity_header']=dict(path=str(identity),sha256=sha(identity),text=identity.read_text())
record.update(status='PASS_FOCUSED_WINDOWS_QUALIFICATION',source_unchanged=True,source_fixture_inputs_unchanged=True,cli=str(exe),cli_sha256=sha(exe),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save();print(json.dumps(dict(status=record['status'],commands=len(record['commands']),result=str(out))),flush=True)
