import datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e');E=W/'evidence';B=W/'native-developer'
sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
env=dict(os.environ,FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',FACMAN_MIN_FREE_GIB='12')
def git(*args):return subprocess.check_output(['git','-c','core.safecrlf=false',*args],cwd=R)
names=sorted(git('diff','--name-only','HEAD').decode().splitlines()+git('ls-files','--others','--exclude-standard').decode().splitlines())
before={n:sha(R/n) for n in names};exe=B/'Release/facman.exe';exe_before=sha(exe)
assert json.loads((E/'snapshot-producer-windows-result-10.json').read_text())['status']=='PASS_FOCUSED_WINDOWS_QUALIFICATION'
out=E/'snapshot-producer-final-checks-result-01.json';assert not out.exists()
record=dict(schema='facman.snapshot_producer_final_checks.v1',status='started',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_before=before,cli_sha256_before=exe_before,commands=[])
def save():owned.write_json(out,record)
save()
commands=[('strict',['py','-3','-B','tools/strict_check.py']),('portable-aide',['py','-3','-B','.aide/scripts/aide_lite.py','test']),('metadata',['py','-3','-B','tools/codegen/generate_metadata.py','--check']),('contracts',['py','-3','-B','tools/codegen/generate_contracts.py','--check']),('truth',['py','-3','-B','tools/project_state.py','--validate']),('engineering',['py','-3','-B','tools/engineering_quality_check.py']),('source-format',['py','-3','-B','tools/source_format_check.py']),('diff',['git','-c','core.safecrlf=false','diff','--check']),('doctor',['py','-3','-B','tools/workspace_hygiene.py','doctor','--measure']),('runtime-identity',[str(exe),'--workspace',str(W/'t/j3/snapshot-producer-inspect-absent'),'product','inspect','--json'])]
for name,args in commands:
 childenv=dict(env)
 if name=='runtime-identity':
  for key in list(childenv):
   if key.startswith(('FACMAN_PROVIDER_','ULK_','USK_')):childenv.pop(key)
 cap=owned.command(args,cwd=W/'t/j3' if name=='runtime-identity' else R,environment=childenv,timeout=900,directory=E/('snapshot-producer-final-'+name+'-01'),output_limit=32*1024*1024,wait_for_job_empty_after_primary=True)
 item=dict(name=name,argv=args,exit_code=cap.returncode,termination=cap.receipt['termination'],job_empty=cap.receipt['job_empty_observed'],primary_stopped=cap.receipt['primary_stopped'],receipt=str(cap.directory/'receipt.json'),receipt_sha256=sha(cap.directory/'receipt.json'),stdout_sha256=sha(cap.directory/'stdout.raw'),stderr_sha256=sha(cap.directory/'stderr.raw'));record['commands'].append(item);save();print(name,cap.returncode,flush=True)
 accepted=cap.ok
 if name=='doctor':
  doctor=json.loads(cap.stdout);record['doctor_summary']=doctor
  # Existing checkout advisory is preserved, never masked as a clean doctor.
  accepted=cap.returncode in (0,1)
 if not accepted or not item['job_empty'] or not item['primary_stopped'] or cap.receipt['job_terminated']:
  record['status']='FAIL_RETAINED';save();print((cap.stdout+cap.stderr).decode(errors='replace')[-12000:]);raise SystemExit(cap.returncode or 1)
 if name=='runtime-identity':
  record['runtime_identity']=json.loads(cap.stdout)
  assert not (W/'t/j3/snapshot-producer-inspect-absent').exists(),'inspect created workspace'
assert before=={n:sha(R/n) for n in names},'Source changed during checks'
assert sha(exe)==exe_before,'Compiled binary changed during checks'
record.update(status='PASS_FINAL_CHECKS',source_unchanged=True,binary_unchanged=True,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
