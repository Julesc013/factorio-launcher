import datetime,difflib,hashlib,json,os,re,shutil,subprocess,sys
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e');E=W/'evidence';B=W/'native-developer'
sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(n):return json.loads((E/n).read_bytes())
def git(*args):return subprocess.check_output(['git','-c','core.safecrlf=false',*args],cwd=R)
def ref(n):return dict(path=str(E/n),sha256=sha(E/n),bytes=(E/n).stat().st_size)
def filemap(root):return {p.relative_to(root).as_posix():sha(p) for p in sorted(root.rglob('*')) if p.is_file()}
assert git('branch','--show-current').decode().strip()=='task/facman-snapshot-producer-01'
assert git('rev-parse','HEAD').decode().strip()=='45387703b4d84a7d9a90c8ef07729777cb4ffe93'
checks=load('snapshot-producer-final-checks-result-01.json');assert checks['status']=='PASS_FINAL_CHECKS'
doctor=checks['doctor_summary'];assert doctor['violations']==['unmanaged_secondary_worktrees_present'];assert len(doctor['task_roots'])==8
assert doctor['task_root_bytes']<20*1024**3
free=shutil.disk_usage(W).free;assert free>12*1024**3
resource=load('snapshot-producer-resource-04.json')
assert resource['fixture_before']=={p.relative_to(R).as_posix():sha(p) for p in sorted((R/'tests/fixtures').rglob('*')) if p.is_file()}
assert sha(B/'CMakeCache.txt')==resource['cache_sha256']
assert json.loads((W/'.facman-development-root.v1.json').read_bytes())==resource['task_marker']
tracked=git('diff','--name-only','HEAD').decode().splitlines();untracked=git('ls-files','--others','--exclude-standard').decode().splitlines();names=sorted(tracked+untracked)
files={n:dict(sha256=sha(R/n),bytes=(R/n).stat().st_size,tracked=n in tracked) for n in names};assert {n:v['sha256'] for n,v in files.items()}==checks['source_before']
compiled_inputs={n:h for n,h in resource['source_before'].items() if n.startswith(('apps/','runtime/','contracts/','tests/native/'))}
assert all(sha(R/n)==h for n,h in compiled_inputs.items())
assert not git('diff','--name-only','HEAD','--','tests/golden','runtime/factorio/application/handlers/snapshots.cpp','runtime/factorio/workspace/transaction.cpp').decode().strip()
diff=git('diff','--binary','HEAD').decode('utf-8')
for n in untracked:diff+=''.join(difflib.unified_diff([], (R/n).read_text(encoding='utf-8').splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+n))
diffpath=E/'snapshot-producer-author-source-01.diff'
if diffpath.exists():assert diffpath.read_text(encoding='utf-8')==diff
else:diffpath.write_text(diff,encoding='utf-8',newline='\n')
runtime=checks['runtime_identity']['payload']['backend_identity'];build=runtime['build'];assert build['source_revision']=='45387703b4d84a7d9a90c8ef07729777cb4ffe93' and build['source_dirty']
assert build['universal_launcher_revision']==resource['pins']['ULK'] and build['universal_setup_revision']==resource['pins']['USK']
assert runtime['package']['mode']=='source_checkout' and runtime['package']['integrity']=='not_packaged'
run07=load('snapshot-producer-windows-result-07.json');run10=load('snapshot-producer-windows-result-10.json');assert run07['status']==run10['status']=='PASS_FOCUSED_WINDOWS_QUALIFICATION'
endurance=load('snapshot-producer-endurance-result-07.json');assert (endurance['durable_operations'],endurance['idempotent_replays'],endurance['conflict_controls'],endurance['restart_cycles'],endurance['receipt_files'],endurance['failures'])==(64,4,4,4,64,0)
campaigns={f'{i:02}':load(f'snapshot-producer-windows-result-{i:02}.json') for i in range(1,11)}
receipts=[]
for p in sorted(E.glob('snapshot-producer-*/receipt.json')):
 r=json.loads(p.read_bytes());receipts.append(dict(path=str(p),sha256=sha(p),termination=r.get('termination'),job_empty=r.get('job_empty_observed'),primary_stopped=r.get('primary_stopped'),job_terminated=r.get('job_terminated'),active_processes_at_primary_exit=r.get('active_processes_at_primary_exit'),exit_code=r.get('exit_code'),process_identity=r.get('process_identity')))
assert all(v['job_empty'] and v['primary_stopped'] and v['termination']=='completed' for v in receipts),'Owned command cleanup failure'
assert all(not v['job_terminated'] or v['active_processes_at_primary_exit']==0 for v in receipts),'Nonempty owned job terminated'
# Reuse the existing read-only admission census, without effects or new controllers.
probe="""import json,os
active=[]
for name in os.listdir('/proc'):
 if name.isdigit():
  try:
   comm=open('/proc/'+name+'/comm').read().strip()
   if comm in {'facman','cmake','ninja','cc1plus','ctest','g++','c++','clang','clang++'}:active.append(dict(pid=int(name),command=open('/proc/'+name+'/cmdline','rb').read().decode(errors='replace').replace(chr(0),' ')))
  except FileNotFoundError:pass
print(json.dumps(dict(mount_namespace=os.readlink('/proc/self/ns/mnt'),active=active)))"""
query="$all=@(Get-CimInstance Win32_Process); @($all | Where-Object { $_.Name -match '^(cl|clang|link|ninja|ctest|facman)\\.exe$' -or ($_.Name -eq 'cmake.exe' -and $_.CommandLine -like '*--build*') -or ($_.Name -eq 'MSBuild.exe' -and $_.CommandLine -notlike '*/nodemode:*') } | Select-Object Name,ProcessId,ParentProcessId,CommandLine) | ConvertTo-Json -Depth 4 -Compress -AsArray"
census=dict(windows=json.loads(subprocess.check_output(['pwsh','-NoProfile','-Command',query],text=True,timeout=45) or '[]'),linux=json.loads(subprocess.check_output(['wsl.exe','-d','Ubuntu-24.04','-u','root','--exec','/usr/bin/python3','-B','-c',probe],text=True,timeout=45)))
owned.write_json(E/'snapshot-producer-final-process-census-01.json',census)
retained=[dict(suite='new producer semantic/control + compiled Windows form',methods=10,receipt='snapshot-producer-windows-producer-07/receipt.json',campaign='07'),dict(suite='ordinary TUI producer + restore; displayed archive input',methods=2,receipt='snapshot-producer-windows-ordinary-tui-10/receipt.json',campaign='10'),dict(suite='shared presentation/backup/restore',methods=7,receipt='snapshot-producer-windows-existing-presentation-07/receipt.json',campaign='07'),dict(suite='immutable intent controls',methods=1,receipt='snapshot-producer-windows-immutable-legacy-receipt-07/receipt.json',campaign='07'),dict(suite='snapshot restore presentation',methods=8,receipt='snapshot-producer-windows-restore-05/receipt.json',campaign='05'),dict(suite='pack import',methods=6,receipt='snapshot-producer-windows-existing-pack-import-06/receipt.json',campaign='06'),dict(suite='old snapshot owner',methods=5,receipt='snapshot-producer-windows-old-snapshots-06/receipt.json',campaign='06'),dict(suite='scoped Windows form source guard',methods=1,receipt='snapshot-producer-windows-winforms-scoped-guard-06/receipt.json',campaign='06')]
for s in retained:
 p=E/s['receipt'];assert p.is_file(),s
 r=json.loads(p.read_bytes());assert r['exit_code']==0 and r['job_empty_observed'] and not r['job_terminated'];s['receipt_sha256']=sha(p)
 # Count actual unittest terminal report; no count inferred from test source alone.
 raw=(p.parent/'stderr.raw').read_text(errors='replace');m=re.search(r'Ran (\d+) tests? in',raw);assert m and int(m[1])==s['methods'],s
assert sum(s['methods'] for s in retained)==40
artifact_exclusions={'snapshot-producer-author-packet-01.json','snapshot-producer-author-raw-custody-01.json'}
rawfiles=[p for p in sorted(E.glob('snapshot-producer-*')) if p.is_file() and p.name not in artifact_exclusions]
for d in sorted(E.glob('snapshot-producer-*')):
 if d.is_dir():rawfiles.extend(p for p in sorted(d.rglob('*')) if p.is_file())
custody={p.relative_to(E).as_posix():dict(sha256=sha(p),bytes=p.stat().st_size) for p in rawfiles}
custodypath=E/'snapshot-producer-author-raw-custody-01.json';assert not custodypath.exists();owned.write_json(custodypath,dict(schema='facman.snapshot_producer_raw_custody.v1',files=custody,total_files=len(custody),total_bytes=sum(v['bytes'] for v in custody.values())))
packet=dict(schema='facman.snapshot_producer_author_packet.v1',status='FROZEN_FOR_INDEPENDENT_SOURCE_REVIEW',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),branch='task/facman-snapshot-producer-01',source_base=build['source_revision'],source_files=files,diff=ref(diffpath.name),raw_custody=ref(custodypath.name),compiled=dict(executable=str(B/'Release/facman.exe'),sha256=sha(B/'Release/facman.exe'),identity_header_sha256=sha(B/'generated/include/facman/build_identity.hpp'),runtime=runtime,build_receipt=ref('snapshot-producer-windows-build-08/receipt.json'),compiled_input_hashes=compiled_inputs,prior_binary_custody=ref('snapshot-producer-pre-tui-rebuild-binary-custody-01.json')),checks=ref('snapshot-producer-final-checks-result-01.json'),method_evidence=retained,unique_methods=40,native=dict(final_two_tui=ref('snapshot-producer-windows-native-08/receipt.json'),unchanged_presentation_native_plus_two_prior_tui=ref('snapshot-producer-windows-native-07/receipt.json')),endurance=endurance,retained_evidence_limits=['40 unique methods were not all rerun on final binary. Final08 changes only scoped TUI feedback/native controls; final10 ordinary tests consume the displayed Unicode/space archive path. Unchanged application owners/wire/WinForms inputs retain07 evidence; older unchanged snapshot/restore/pack owners retain05/06 evidence.','Compiled Windows modal harness is a finite5-second structural control test; no physical UI or backend-through-UI producer claim.','Endurance64/4/4/4 is bounded and does not establish the90-minute gate.','This is Windows source qualification. New producer hosted3-platform CI and delivered-package qualification remain outstanding.'],failures_preserved=dict(campaign_statuses={n:v['status'] for n,v in campaigns.items()},details=['Static engineering ratchet failures before narrow extraction; budgets unchanged.','01 zero-effect branch-guard typo; no build/product command.','02 CLI compile failure for removed operation/attempt locals; restored exact prior locals.','03 missing public RPC transport envelope schema fixture.','04 invalid canonical empty identifiers sent as public request fixture.','05 real TUI default-name cancellation interaction, fixed required-name defaultnull without generic state change.','08/09 exact visible-path test asserted wrong Status label and then omitted Operation indentation; product path was already correct, corrected tests only in10.'],whole_failed_campaigns_relabelled=False),preservation=dict(source_fixture_hashes_unchanged=True,fixture_files=len(resource['fixture_before']),fixture_digest=hashlib.sha256(json.dumps(resource['fixture_before'],sort_keys=True).encode()).hexdigest(),legacy_golden_diff=[],archived_owner_transaction_unchanged=True,compiled_inputs_unchanged_since08=True,source_and_binary_unchanged_during_final_checks=True,marker_unchanged=True,cache_unchanged=True,cache_sha256=sha(B/'CMakeCache.txt'),provider_authored_edits=False,global_provider_inventory_claim=False,real_game_effects=False),resources=dict(task_roots=8,measured_bytes=doctor['task_root_bytes'],cap_bytes=20*1024**3,conservative_admitted_peak_bytes=resource['measured_bytes']+resource['conservative_additional_peak_bytes'],free_final=free,reserve_bytes=12*1024**3,workers_configured=2,observed_compiler_max_claim=False,heavy_jobs=1,build_root=str(B),profile='Visual Studio 18 2026 / Release / static runtime / existing tracked shared sources',doctor_exit=1,doctor_violations=doctor['violations'],no_new_roots_caches_worktrees_clones=True),processes=dict(owned_command_receipts=len(receipts),all_owned_jobs_empty=True,no_safety_termination=True,already_empty_jobs_closed_with_termination_flag=sum(bool(v["job_terminated"]) for v in receipts),empty_job_cleanup_note="Resource paths/doctor default cleanup calls TerminateJobObject after active count is already zero; these8 flags are retained, not relabelled as false.",receipts=receipts,final_census=ref('snapshot-producer-final-process-census-01.json'),intentional_product_death='New semantic publication-death test intentionally terminates its retained owned child after the existing pause marker; generic Activity rollback preserves unknown semantic receipt.',inner_cli_identity_limit='Outer owned Jobs contain descendant source-test processes; no invented per-inner-CLI PID census.'),git_effects=dict(commits=0,pushes=0,ci_runs=0,provider_prepares=0,local_linux_builds=0),prior_pr424_metadata_only=ref('snapshot-producer-prebuild-result-02.json'))
out=E/'snapshot-producer-author-packet-01.json';assert not out.exists();owned.write_json(out,packet)
assert all(sha(R/n)==v['sha256'] for n,v in files.items())
print(json.dumps(dict(packet=ref(out.name),diff=packet['diff'],raw_custody=packet['raw_custody'],source_files=len(files),owned_receipts=len(receipts),unique_methods=40,final_cli_sha256=packet['compiled']['sha256']),indent=2))
