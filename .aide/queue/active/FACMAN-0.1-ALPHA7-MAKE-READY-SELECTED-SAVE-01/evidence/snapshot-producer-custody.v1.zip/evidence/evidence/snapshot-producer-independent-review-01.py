import hashlib,json,subprocess
from pathlib import Path
E=Path(__file__).resolve().parent;W=E.parent;R=Path(r'D:\Projects\Factorio\factorio-launcher')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_bytes())
packet=E/'snapshot-producer-author-packet-01.json'
assert sha(packet)=='7978083a83cab8090b73559176a090cafce59fdae9b959313f93615a86166987'
p=load(packet);assert p['status']=='FROZEN_FOR_INDEPENDENT_SOURCE_REVIEW'
git=lambda *a:subprocess.check_output(['git','-c','core.safecrlf=false',*a],cwd=R,text=True).strip()
assert git('rev-parse','HEAD')==p['source_base']=='45387703b4d84a7d9a90c8ef07729777cb4ffe93'
assert git('branch','--show-current')==p['branch']=='task/facman-snapshot-producer-01'
dirty=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
assert dirty<=set(p['source_files']) and len(p['source_files'])==49
for name in set(p['source_files'])-dirty:
 assert name in {'.aide/memory/project-state.md','.aide/memory/project-state.v2.json','README.md'}
 assert git('hash-object','--path',name,str(R/name))==git('rev-parse','HEAD:'+name)
for name,row in p['source_files'].items():assert sha(R/name)==row['sha256'] and (R/name).stat().st_size==row['bytes'],name
for name,digest in p['compiled']['compiled_input_hashes'].items():assert sha(R/name)==digest,name
for key in ('diff','raw_custody','checks','prior_pr424_metadata_only'):
 assert sha(p[key]['path'])==p[key]['sha256'],key
custody=load(p['raw_custody']['path']);assert custody['total_files']==len(custody['files'])==344
assert custody['total_bytes']==sum(row['bytes'] for row in custody['files'].values())==2048431
for name,row in custody['files'].items():
 path=(E/name).resolve(strict=True);assert path.is_relative_to(W.resolve()) and not path.is_symlink()
 assert sha(path)==row['sha256'] and path.stat().st_size==row['bytes'],name
def receipt(path,digest=None):
 path=Path(path)
 if not path.is_absolute():path=E/path
 if digest:assert sha(path)==digest
 r=load(path);assert r['termination']=='completed' and r['primary_stopped'] and r['job_empty_observed'],str(path)
 for stream in ('stdout','stderr'):assert sha(path.parent/r[stream]['file'])==r[stream]['sha256']
 return r
terminated=[]
for row in p['processes']['receipts']:
 r=receipt(row['path'],row['sha256'])
 if r['job_terminated']:
  assert r['active_processes_at_primary_exit']==0
  assert any(x in str(row['path']) for x in ('paths','doctor'))
  terminated.append(row['path'])
assert len(p['processes']['receipts'])==p['processes']['owned_command_receipts']==68
assert len(terminated)==p['processes']['already_empty_jobs_closed_with_termination_flag']==8
for row in p['method_evidence']:
 r=receipt(row['receipt'],row['receipt_sha256']);assert r['exit_code']==0
 raw=(E/row['receipt']).parent.joinpath('stderr.raw').read_text(encoding='utf-8')
 assert f"Ran {row['methods']} test" in raw and '\nOK' in raw and 'FAILED' not in raw and 'skipped' not in raw
assert sum(x['methods'] for x in p['method_evidence'])==p['unique_methods']==40
for key,count in (('final_two_tui',2),('unchanged_presentation_native_plus_two_prior_tui',3)):
 row=p['native'][key];assert receipt(row['path'],row['sha256'])['exit_code']==0
 assert f'100% tests passed, 0 tests failed out of {count}' in Path(row['path']).parent.joinpath('stdout.raw').read_text()
build=p['compiled']['build_receipt'];r=receipt(build['path'],build['sha256']);assert r['exit_code']==0
assert '--clean-first' in r['command'] and '/p:TrackFileAccess=false' in r['command']
assert sha(p['compiled']['executable'])==p['compiled']['sha256']=='9b82b2b0e70d9ba4bed1eb7836d3a55ea1b9f70dc7187b224fd227b73ff5baa8'
prior=load(p['compiled']['prior_binary_custody']['path']);assert sha(p['compiled']['prior_binary_custody']['path'])==p['compiled']['prior_binary_custody']['sha256']
assert prior['facman.exe']['sha256']==load(E/'snapshot-producer-windows-result-07.json')['cli_sha256']
runtime=p['compiled']['runtime'];assert runtime['build']['source_revision']==p['source_base'] and runtime['build']['source_dirty']
assert runtime['package']['mode']=='source_checkout' and not runtime['package']['verified']
checks=load(p['checks']['path']);assert checks['status']=='PASS_FINAL_CHECKS' and checks['source_unchanged'] and checks['binary_unchanged']
for row in checks['commands']:
 r=receipt(row['receipt']);assert r['exit_code']==row['exit_code']==(1 if row['name']=='doctor' else 0)
end=p['endurance'];assert end['status']=='pass' and end['durable_operations']==end['receipt_files']==64
assert end['idempotent_replays']==end['conflict_controls']==end['restart_cycles']==4 and end['failures']==0 and end['elapsed_seconds']==4.188
res=p['resources'];assert res['task_roots']==8 and res['doctor_violations']==['unmanaged_secondary_worktrees_present']
assert res['measured_bytes']<res['conservative_admitted_peak_bytes']<res['cap_bytes']==20*1024**3
assert res['free_final']>=res['reserve_bytes']==12*1024**3 and res['workers_configured']==2
assert sha(Path(res['build_root'])/'CMakeCache.txt')==p['preservation']['cache_sha256']
census=load(p['processes']['final_census']['path']);assert census['windows']==[] and census['linux']['active']==[]
assert not p['preservation']['legacy_golden_diff'] and p['preservation']['archived_owner_transaction_unchanged']
assert not p['preservation']['provider_authored_edits'] and not p['preservation']['real_game_effects']
assert all(value==0 for value in p['git_effects'].values())
assert not p['failures_preserved']['whole_failed_campaigns_relabelled']
support=(R/'runtime/factorio/application/presentation_action_support.cpp').read_text()
service=(R/'runtime/factorio/application/presentation_service.cpp').read_text()
tui=(R/'apps/tui/tui_product_shell.cpp').read_text()
test=(R/'tests/test_tui_product.py').read_text()
assert 'if (!request.snapshot_id.empty()) input.add_string("snapshot_id", request.snapshot_id);' in support
assert 'CreateSnapshotRequest create {request.selected_instance_id, request.snapshot_id, {}};' in support
assert 'if (!request.save.empty()) create.saves.push_back(request.save);' in support
assert '{"snapshot_id", "New snapshot ID", "identifier", true, {}, {}}' in service
assert 'output = owner_result(dispatch_snapshot_create(context_, request));' in service
assert 'semantic_action && response.ok() && outcome == "completed"' in tui and 'return "Snapshot created: " + text("path")' in tui
assert 'prefix = "  Operation: Snapshot created: "' in test and 'archive = Path(paths[-1])' in test
out=E/'snapshot-producer-independent-review-01.json';assert not out.exists()
v=dict(schema='facman.independent_snapshot_producer_review.v1',verdict='PASS_SCOPED_SOURCE_FOR_REQUIRED_CURRENT_CI',
 source_base=p['source_base'],branch=p['branch'],author='/root/managed_update_acceptance',reviewer='/root',non_authoring=True,
 packet_sha256=sha(packet),reviewer_script_sha256=sha(__file__),source_files_sha256=p['source_files'],
 raw_artifacts_verified=344,raw_bytes_verified=2048431,closed_owned_receipts=68,already_empty_cleanup_flags_retained=8,
 unique_methods=40,all_methods_run_on_final_binary=False,retained_unchanged_owner_results=True,
 final_native_tui_tests=2,prior_native_tests=3,endurance_seconds=4.188,endurance_operations=64,
 legacy_canonical_request_and_golden_compatibility=True,typed_existing_snapshot_owner=True,
 required_name_no_default=True,blank_save_includes_none=True,raw_owner_bytes_preserved=True,
 visible_TUI_path_consumed_by_ordinary_restore=True,scope_preserved=True,all_failures_retained=True,
 source_checkout_not_delivered=True,current_hosted_CI_pending=True,current_delivered_CLI_TUI_GUI_pending=True,
 real_game=False,human_acceptance=False,workunit_closed=False,beta=False,rc=False,
 no_new_roots_caches_worktrees_clones=True,provider_edits=False)
out.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in v.items() if k!='source_files_sha256'},indent=2))
