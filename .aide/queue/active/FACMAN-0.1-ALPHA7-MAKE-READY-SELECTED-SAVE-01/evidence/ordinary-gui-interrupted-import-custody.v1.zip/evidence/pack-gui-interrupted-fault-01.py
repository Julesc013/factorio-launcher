"""Prepared external adapter only; import/instantiation requires exact root review.

No process is launched by this module. Existing GUI/job lifetime checks remain.
Only one independently bound, live import backend may receive the deliberate loss.
"""
import ast
import ctypes
from ctypes import wintypes as wt
import hashlib
from pathlib import Path

FAULT_EXIT = 0xFA430001


def reviewed_job_class(gui_module, persist, verify_binding):
    """verify_binding rechecks the frozen typed request, journal and pause bytes.

    It returns one immutable binding dict, including original journal/request
    hashes. persist must durably retain the attempted action before termination.
    Both callbacks belong to the reviewed one-scenario controller.
    """
    base = gui_module.OwnedProcessJob

    class InterruptedImportJob(base):
        intentional = None

        def identity(self, handle):
            creation, ended, kernel, user = (wt.FILETIME() for _ in range(4))
            member = wt.BOOL()
            assert self.api.IsProcessInJob(handle, self.job, ctypes.byref(member)) and member.value
            assert self.api.GetProcessTimes(handle, ctypes.byref(creation), ctypes.byref(ended),
                ctypes.byref(kernel), ctypes.byref(user))
            image, length = ctypes.create_unicode_buffer(32768), wt.DWORD(32768)
            assert self.api.QueryFullProcessImageNameW(handle, 0, image, ctypes.byref(length))
            pid = self.api.GetProcessId(handle)
            assert pid and self.api.WaitForSingleObject(handle, 0) == 0x102
            return dict(pid=pid, process_identity=str(pid) + ':' + str(
                (creation.dwHighDateTime << 32) | creation.dwLowDateTime),
                image=str(Path(image.value).resolve()), exact_job_membership=True)

        def interrupt_verified_import(self):
            assert self.intentional is None
            binding = verify_binding()
            pids = self.observe()
            known = {r['pid'] for r in self.records} | {self.pid}
            assert set(pids) <= known, 'Uncustodied live descendant; preserve/refuse'
            live = [r for r in self.records if r['role'] == 'packaged_backend' and
                self.api.WaitForSingleObject(self.handles[r['process_identity']], 0) == 0x102]
            assert len(live) == 1, 'Import backend is not uniquely live; preserve/refuse'
            record = live[0]
            held = self.handles[record['process_identity']]
            before = self.identity(held)
            expected = {k: record[k] for k in before}
            expected['image'] = str(Path(expected['image']).resolve())
            assert before == expected and Path(before['image']) == self.backend
            assert hashlib.sha256(self.backend.read_bytes()).hexdigest() == record['image_sha256']
            # Existing observed handles have query/synchronize rights only.
            # Reopen with TERMINATE, then match every capability to the held one.
            terminate = self.api.OpenProcess(0x1 | 0x1000 | 0x100000, False, record['pid'])
            assert terminate
            try:
                assert self.identity(terminate) == before == self.identity(held)
                assert verify_binding() == binding
                latest = self.observe()
                assert set(latest) <= ({r['pid'] for r in self.records} | {self.pid})
                assert len([r for r in self.records if r['role'] == 'packaged_backend' and
                    self.api.WaitForSingleObject(self.handles[r['process_identity']], 0) == 0x102]) == 1
                event = dict(binding=binding, identity=before, image_sha256=record['image_sha256'],
                    requested_exit_code=FAULT_EXIT, intentional_loss=True, termination_succeeded=False)
                persist(event)  # Failure here prevents the deliberate effect.
                self.api.TerminateProcess.argtypes = [wt.HANDLE, wt.UINT]
                self.api.TerminateProcess.restype = wt.BOOL
                assert self.identity(terminate) == before == self.identity(held)
                assert self.api.TerminateProcess(terminate, FAULT_EXIT)
                assert self.api.WaitForSingleObject(held, 5000) == 0
                actual = wt.DWORD()
                assert self.api.GetExitCodeProcess(held, ctypes.byref(actual)) and actual.value == FAULT_EXIT
                event.update(termination_succeeded=True, observed_exit_code=actual.value)
                persist(event)
                self.intentional = event
            finally:
                self.api.CloseHandle(terminate)

        def accept_exit(self, record, code):
            if code in (0, 1):
                return True
            event = self.intentional
            return bool(event and event['termination_succeeded'] and code == FAULT_EXIT and
                record['process_identity'] == event['identity']['process_identity'] and
                record['pid'] == event['identity']['pid'] and
                Path(record['image']).resolve() == Path(event['identity']['image']) and
                record['image_sha256'] == event['image_sha256'])

    # Reuse the exact source finish body. Change its sole exit-code admission
    # predicate, preserving empty-job proof, safety-failure and handle cleanup.
    tree = ast.parse(Path(gui_module.__file__).read_text(encoding='utf-8'))
    owner = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'OwnedProcessJob')
    finish = next(n for n in owner.body if isinstance(n, ast.FunctionDef) and n.name == 'finish')
    replacements = 0
    for node in ast.walk(finish):
        if isinstance(node, ast.If) and ast.unparse(node.test) == 'code.value not in (0, 1)':
            node.test = ast.parse('not self.accept_exit(record, code.value)', mode='eval').body
            replacements += 1
    assert replacements == 1
    code = compile(ast.fix_missing_locations(ast.Module(body=[finish], type_ignores=[])),
        '<reviewed one-predicate external finish adaptation>', 'exec')
    namespace = {}
    exec(code, gui_module.__dict__, namespace)
    InterruptedImportJob.finish = namespace['finish']
    return InterruptedImportJob
