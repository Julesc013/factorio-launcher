"""One reviewed actual packaged GUI loss/recovery scenario; no build/download."""
import contextlib
import ctypes
from ctypes import wintypes as wt
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time
import traceback
import unittest
from unittest.mock import patch
import zipfile

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
W = E.parent
G = W / 't/j3/g3b'
F = W / 't/j3/pg1'
C, P, I = F / 'c', F / 'producer', F / 'i'
WS = F / 'consumer'
RAW = E / 'pack-gui-interrupted-raw-04'
sys.dont_write_bytecode = True
sys.path[:0] = [str(E), str(R / 'tests'), str(R)]
STATUS_STREAM = None
STATUS = dict(schema='facman.pack_gui_import_worker_status.v1', status='STARTED', phase='entry')


def status_update(**values):
    STATUS.update(values)
    encoded = (json.dumps(STATUS, indent=2) + '\n').encode()
    assert len(encoded) <= 1024**2
    STATUS_STREAM.seek(0); STATUS_STREAM.write(encoded); STATUS_STREAM.truncate()
    STATUS_STREAM.flush(); os.fsync(STATUS_STREAM.fileno())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def execute(plan_hash):
    status_update(phase='plan_source_and_launcher_guards')
    import importlib
    probe = importlib.import_module('pack-gui-interrupted-probe-04')
    probe.PLAN = E / 'pack-gui-interrupted-plan-04.json'
    assert sha(probe.PLAN) == plan_hash
    plan = json.loads(probe.PLAN.read_bytes())
    probe.guard(plan)
    launch_path = E / 'pack-gui-interrupted-launch-result-04.json'
    launch_raw = launch_path.read_bytes()
    launch = json.loads(launch_raw)
    assert launch['plan_sha256'] == plan_hash and launch['execution_head'] == plan['execution_head']
    assert launch['artifact_source'] == plan['artifact_source'] and launch['worker_dispatch_count'] == 1
    assert launch['status'] == 'RUNNING_SINGLE_FINITE_GUI_SCENARIO'
    assert launch['resource_sample']['quiet'] and launch['pre_worker_resource_sample']['quiet']
    assert launch['doctor_admission']['task_roots'] <= 8
    assert launch['doctor_admission']['bytes'] + plan['limits']['new_total_bytes'] < 20*1024**3
    assert launch['doctor_admission']['foreign_worktrees_touched'] is False
    assert not F.exists() and not RAW.exists()
    admission = json.loads((E / 'tui-feedback-delivered-extract-02.json').read_bytes())
    assert admission['source'] == plan['artifact_source'] and admission['artifact'] == plan['artifact']
    expected_package = admission['file_inventory']
    assert len(expected_package) == 599
    import native_cli
    import test_local_modset_solver as solver
    import test_presentation_pack_import as presentation
    import test_portable_modpack_import as portable
    import test_make_ready_joined as joined
    import test_windows_delivered_joined_gui as gui
    from tools import provider_canary_process as owned
    from tools.package.runtime_identity import require_backend_identity
    fault = importlib.import_module('pack-gui-interrupted-fault-01')
    started, deadline = time.monotonic(), time.monotonic() + 300
    result = dict(status='STARTED', plan_sha256=plan_hash, execution_head=plan['execution_head'],
        artifact_source=plan['artifact_source'], artifact=plan['artifact'], calls=[], sessions=[],
        snapshots=[], intentional_loss=None, real_game=False, human=False, beta=False,
        canonical_installed_desktop=False, resource_changes=[], new_builds=0, new_downloads=0)
    result['launcher_admission_sha256'] = digest(launch_raw)
    active, pins, fixed_pins = None, [], []

    def guard_time():
        assert time.monotonic() < deadline, 'Actual scenario deadline exceeded'

    def output_guard():
        guard_time()
        assert sum(p.stat().st_size for p in RAW.rglob('*') if p.is_file()) <= 80 * 1024**2
        total = 0
        for item in E.glob('pack-gui-interrupted-*'):
            total += item.stat().st_size if item.is_file() else sum(p.stat().st_size for p in item.rglob('*') if p.is_file())
        assert total <= 128 * 1024**2
        assert sum(p.stat().st_size for p in F.rglob('*') if p.is_file()) <= 16 * 1024**2

    # No-follow, no-delete native pins protect the exact directory namespace.
    api = ctypes.WinDLL('kernel32', use_last_error=True)
    api.CreateFileW.argtypes = [wt.LPCWSTR, wt.DWORD, wt.DWORD, ctypes.c_void_p, wt.DWORD, wt.DWORD, wt.HANDLE]
    api.CreateFileW.restype = wt.HANDLE
    api.CloseHandle.argtypes, api.CloseHandle.restype = [wt.HANDLE], wt.BOOL

    class Info(ctypes.Structure):
        _fields_ = [('attributes', wt.DWORD), ('creation', wt.FILETIME), ('access', wt.FILETIME),
            ('write', wt.FILETIME), ('volume', wt.DWORD), ('size_high', wt.DWORD),
            ('size_low', wt.DWORD), ('links', wt.DWORD), ('index_high', wt.DWORD), ('index_low', wt.DWORD)]

    api.GetFileInformationByHandle.argtypes = [wt.HANDLE, ctypes.POINTER(Info)]
    api.GetFileInformationByHandle.restype = wt.BOOL

    def object_identity(path):
        # The reused joined.file_identity helper opens with flags=0 and is a
        # regular-file observer. Directory observations require BACKUP_SEMANTICS.
        # OPEN_REPARSE_POINT keeps this local observer explicitly no-follow.
        handle = api.CreateFileW(str(path), 0x80, 7, None, 3, 0x02200000, None)
        if handle == ctypes.c_void_p(-1).value:
            raise ctypes.WinError(ctypes.get_last_error())
        try:
            info = Info()
            if not api.GetFileInformationByHandle(handle, ctypes.byref(info)):
                raise ctypes.WinError(ctypes.get_last_error())
            assert not info.attributes & 0x400, 'Identity observation refuses reparse point: ' + str(path)
            assert info.attributes & 0x10 or info.links == 1
            return f'{info.volume}:{(info.index_high << 32) | info.index_low}'
        finally:
            assert api.CloseHandle(handle)

    def pin(path, directory, group):
        path = Path(path)
        status_update(phase='no_follow_pin', path=str(path), directory=directory)
        assert path.is_absolute()
        handle = api.CreateFileW(str(path), 0x80, 3 if directory else 1, None, 3, 0x02200000, None)
        assert handle != ctypes.c_void_p(-1).value, str(path)
        try:
            info = Info()
            assert api.GetFileInformationByHandle(handle, ctypes.byref(info))
            assert not info.attributes & 0x400 and bool(info.attributes & 0x10) == directory
            assert directory or info.links == 1
            identity = f'{info.volume}:{(info.index_high << 32) | info.index_low}'
            assert object_identity(path) == identity
            group.append(handle)
            return identity
        except BaseException:
            api.CloseHandle(handle)
            raise

    def unpin(group):
        while group:
            assert api.CloseHandle(group.pop())

    def plain(root):
        rows = {}
        for path in sorted(Path(root).rglob('*')):
            st = path.lstat()
            assert not path.is_symlink() and not getattr(st, 'st_file_attributes', 0) & 0x400
            if path.is_file():
                rows[path.relative_to(root).as_posix()] = sha(path)
        return rows

    def snapshot(root, label):
        guard_time()
        rows = {}
        for path in sorted(Path(root).rglob('*')):
            st = path.lstat()
            assert not path.is_symlink() and not getattr(st, 'st_file_attributes', 0) & 0x400
            key = path.relative_to(root).as_posix()
            row = dict(identity=object_identity(path), directory=path.is_dir())
            if path.is_file():
                data = path.read_bytes()
                row.update(size=len(data), sha256=digest(data))
                blob = RAW / 'cas' / row['sha256']
                if not blob.exists():
                    assert len(data) <= 16 * 1024**2
                    with blob.open('xb') as stream:
                        stream.write(data)
            rows[key] = row
        result['snapshots'].append(dict(label=label, root=str(root), inventory=rows))
        output_guard()
        return rows

    def save():
        owned.write_json(RAW / 'result.json', result)
        status_update(status=result['status'], phase='scenario', raw_result_exists=True,
            error=result.get('error'), traceback=result.get('traceback'),
            cleanup_errors=result.get('cleanup_errors'), final_guard_errors=result.get('final_guard_errors'))

    def run_machine(args, env=None):
        guard_time()
        assert len(result['calls']) < 32
        # All fixture and oracle commands use the produced executable. Source
        # test imports never choose or rebuild another consumer.
        environment = {k: v for k, v in os.environ.items() if not k.startswith('FACMAN_')}
        environment.update(PATH='', PYTHONDONTWRITEBYTECODE='1', TEMP=str(F), TMP=str(F))
        if env:
            assert not any(k.startswith('FACMAN_TEST_') for k in env), 'CLI fault override forbidden'
        directory = RAW / f'command-{len(result["calls"]):03}'
        cap = owned.command([str(G / 'bin/facman.exe'), *args], cwd=C, environment=environment,
            directory=directory, timeout=min(30, deadline-time.monotonic()), output_limit=1024**2,
            wait_for_job_empty_after_primary=True)
        result['calls'].append(dict(argv=args, receipt=str(directory / 'receipt.json'),
            receipt_sha256=sha(directory / 'receipt.json'), exit_code=cap.returncode))
        save()
        assert cap.receipt['termination'] == 'completed' and cap.receipt['primary_stopped']
        assert cap.receipt['job_empty_observed'] and not cap.receipt['job_terminated']
        output_guard()
        return cap.returncode, cap.stdout.decode('utf-8').replace('\r\n', '\n'), cap.stderr.decode('utf-8').replace('\r\n', '\n')

    def machine(args):
        code, out, err = run_machine(args)
        assert code == 0 and not err, out + err
        return json.loads(out)['payload']

    def frame(active, window, name):
        active.frame(window, name)
        save()

    def tab(active, main, index, caption):
        tabs = [h for h in active.enumerate(main) if active.text(h, True).casefold() == 'systabcontrol32']
        assert len(tabs) == 1 and active.send(tabs[0], 0x1304) == 7
        # TCM_SETCURSEL alone does not deliver the selection notification
        # needed by WinForms to show its managed page. Send ordinary navigation
        # keys to this exact owned control; no global keyboard/focus/activation.
        for key in [0x24] + [0x27] * index:  # VK_HOME, then VK_RIGHT.
            active.send(tabs[0], 0x100, key, 1)
            active.send(tabs[0], 0x101, key, 0xC0000001)
        assert active.send(tabs[0], 0x130B) == index
        active.events.append(dict(stage='owned tab keyboard navigation', hwnd=tabs[0],
            pid=active.process.pid, index=index, caption=caption, global_input=False))
        active.wait(lambda: any(active.text(h) == caption and active.api.IsWindowVisible(h)
            for h in active.enumerate(main)), 'visible owned page ' + caption)

    def fill(active, dialog, label, value):
        controls = active.enumerate(dialog)
        labels = [h for h in controls if active.text(h) in (label, label + ' *')]
        assert len(labels) == 1
        rect = wt.RECT()
        assert active.api.GetWindowRect(labels[0], ctypes.byref(rect))
        candidates = []
        for h in controls:
            if 'EDIT' not in active.text(h, True).upper():
                continue
            observed = wt.RECT()
            assert active.api.GetWindowRect(h, ctypes.byref(observed))
            if observed.left >= rect.right and abs((observed.top+observed.bottom)-(rect.top+rect.bottom)) <= 32:
                candidates.append(h)
        assert len(candidates) == 1, label
        buffer = ctypes.create_unicode_buffer(value)
        assert active.send(candidates[0], 0xC, 0, ctypes.addressof(buffer))
        assert active.text(candidates[0]) == value

    frozen_binding = None
    original_receipt_path, original_receipt_bytes, original_stage = None, None, None
    journal_path, transaction_id = None, None
    pack = P / 'pack.zip'
    stage, target = WS / '.facman-pack-import-reconstructed', WS / 'instances/reconstructed'
    signal = WS / '.facman-modpack-import-verified-paused'
    release = WS / '.facman-modpack-import-verified-release'

    def binding():
        nonlocal frozen_binding, original_receipt_path, original_receipt_bytes, original_stage
        nonlocal journal_path, transaction_id
        guard_time()
        assert signal.read_bytes() == b'paused\n' and not release.exists() and not target.exists()
        receipts = []
        for path in (WS / '.facman/action-receipts-v2').glob('*.v2.json'):
            raw = path.read_bytes(); doc = json.loads(raw)
            if doc['action_id'] == 'modsets.import':
                receipts.append((path, raw, doc))
        assert len(receipts) == 1
        rp, raw, receipt = receipts[0]
        request = json.loads(receipt['request_json'])
        assert receipt['schema'] == 'facman.presentation_action_receipt.v2'
        assert receipt['state'] == 'accepted_outcome_unknown'
        expected = dict(action_id='modsets.import', scope='content', confirmation='explicit',
            source_path=str(pack), new_instance_id='reconstructed', installation_id='fixture', display_name='Restored pack')
        assert all(request.get(k) == v for k, v in expected.items())
        assert set(request) == {'action_id', 'scope', 'expected_snapshot_revision', 'request_id',
            'selected_instance_id', 'durable_operation_id', 'attempt_id', 'confirmation',
            'installation_id', 'installation_path', 'new_instance_id', 'display_name', 'template_id',
            'profile_id', 'mod_identity', 'save', 'output_path', 'source_data_root', 'transaction_id',
            'roots', 'source_path'}
        for name in ('selected_instance_id', 'installation_path', 'template_id', 'profile_id',
            'mod_identity', 'save', 'output_path', 'source_data_root', 'transaction_id'):
            assert request[name] == ''
        assert request['roots'] == []
        assert request['expected_snapshot_revision'] == result['content_revision']
        for outer, inner in [('request_id', 'request_id'), ('operation_id', 'durable_operation_id'), ('attempt_id', 'attempt_id')]:
            assert receipt[outer] == request[inner] and request[inner]
        assert receipt['idempotency_key'] == 'winforms-' + request['request_id']
        assert receipt['key_digest'] == digest(receipt['idempotency_key'].encode())
        assert receipt['request_fingerprint'] == digest(receipt['request_json'].encode())
        assert receipt['result_digest'] == digest(receipt['result_json'].encode())
        assert receipt['result_length'] == len(receipt['result_json'].encode())
        assert receipt['target_instance_id'] == 'reconstructed' and receipt['target_installation_id'] == 'fixture'
        assert json.loads(receipt['result_json'])['outcome'] == 'outcome_unknown'
        journals = [(p, json.loads(p.read_bytes())) for p in (WS / 'transactions').glob('*.transaction.v1.json')]
        journals = [(p, j) for p, j in journals if j['command_id'] == 'modsets.import']
        assert len(journals) == 1
        jp, journal = journals[0]
        assert journal['schema'] == 'facman.transaction.v2' and journal['state'] == 'verified'
        assert journal['commit_strategy'] == 'modpack_instance_no_replace_v1'
        assert Path(journal['target']) == target
        assert list(map(Path, journal['source_identities'])) == [pack, I]
        assert list(map(Path, journal['owned_staging_roots'])) == [stage]
        assert journal['workspace_id'] == json.loads((WS / 'workspace.v1.json').read_bytes())['workspace_id']
        assert set(plan['actual_fault_path']['required_steps']) <= set(journal['completed_steps'])
        context = json.loads(journal['operation_context'])
        assert set(context) == {'schema', 'install_id', 'root_identity', 'files', 'source_binding'}
        assert context['schema'] == 'facman.modpack_import_install.v1' and context['install_id'] == 'fixture'
        assert context['root_identity'] == object_identity(I)
        with zipfile.ZipFile(pack) as archive:
            expected_source = dict(schema='facman.modpack_import_source.v1', archive_sha256=sha(pack),
                archive_size=pack.stat().st_size, manifest_sha256=digest(archive.read('modpack-manifest.v1.json')),
                lock_sha256=digest(archive.read('modset-lock.v1.json')), instance_id='reconstructed',
                install_id='fixture', display_name='Restored pack')
            assert context['source_binding'] == expected_source
            expected_raw = {name: dict(size=len(archive.read(name)), sha256=digest(archive.read(name))) for name in archive.namelist()}
        assert journal['effect_file_identity'] == object_identity(stage)
        assert journal['effect_parent_identity'] == object_identity(target.parent)
        marker = stage / '.facman-transaction-staging.v2.json'
        md = json.loads(marker.read_bytes())
        assert md == dict(schema='facman.transaction_staging.v2', transaction_id=journal['transaction_id'],
            command_id='modsets.import', target_sha256=digest(str(target).encode()), nonce=journal['marker_nonce'])
        assert (stage / '.facman-archive-staging.v1').read_bytes() == b'schema=facman.archive_staging.v1\n'
        expected_files = {row['path']: dict(size=row['size'], sha256=row['sha256']) for row in journal['expected_files']}
        assert len(expected_files) == len(journal['expected_files']) == len(expected_raw) + 4
        assert all(expected_files[name] == row for name, row in expected_raw.items())
        assert set(expected_files) - set(expected_raw) == {'mods/modset-lock.v1.json', 'instance.v1.json', 'config/config.ini', 'modpack-import.v1.json'}
        for name, row in expected_files.items():
            path = stage / name
            assert path.is_relative_to(stage) and '..' not in Path(name).parts
            assert path.stat().st_size == row['size'] and sha(path) == row['sha256']
        for row in context['files']:
            path = Path(row['path'])
            assert path.is_relative_to(F) and path.stat().st_size == row['size'] and sha(path) == row['sha256']
        metadata = {row['path']: dict(sha256=sha(row['path']), size=Path(row['path']).stat().st_size,
            identity=object_identity(Path(row['path']))) for row in context['files']}
        workspace_manifest = WS / 'workspace.v1.json'
        state = dict(request_sha256=digest(raw), journal_sha256=sha(jp), transaction_id=journal['transaction_id'],
            source_sha256=sha(pack), request=request, stage_identity=journal['effect_file_identity'],
            parent_identity=journal['effect_parent_identity'], expected_files=expected_files,
            source_identity=object_identity(pack), installation_metadata=metadata,
            workspace_manifest=dict(sha256=sha(workspace_manifest), identity=object_identity(workspace_manifest)),
            markers={str(marker): sha(marker), str(signal): sha(signal)})
        if frozen_binding is None:
            original_receipt_path, original_receipt_bytes = rp, raw
            journal_path, transaction_id = jp, journal['transaction_id']
            original_stage = snapshot(stage, 'verified stage before intentional loss')
            assert set(k for k, row in original_stage.items() if not row['directory']) == set(expected_files) | {
                '.facman-transaction-staging.v2.json', '.facman-archive-staging.v1'}
            for directory in [WS, stage, target.parent, I] + [stage / name for name, row in original_stage.items() if row['directory']]:
                pin(directory, True, pins)
            for path in [rp, jp, marker, stage / '.facman-archive-staging.v1', signal, pack, workspace_manifest] + [stage / n for n in expected_files] + [Path(r['path']) for r in context['files']]:
                pin(path, False, pins)
            frozen_binding = state
            result['bound_request'] = state
            save()
        assert state == frozen_binding
        assert all(object_identity(stage / name) == row['identity'] for name, row in original_stage.items())
        return state

    def persist_fault(event):
        result['intentional_loss'] = event
        with (RAW / 'intentional-loss.json').open('wb') as stream:
            stream.write((json.dumps(event, indent=2) + '\n').encode()); stream.flush(); os.fsync(stream.fileno())
        save()

    try:
        status_update(phase='package_inventory')
        assert plain(G) == expected_package
        status_update(phase='source_fixture_inventory')
        assert plain(R / 'tests/fixtures/fake_factorio_install') == plan['source_fixture_inventory']
        # Hold every existing ancestor, preventing namespace redirection while
        # exclusively creating the single absent diagnostic fixture root.
        for directory in reversed([F.parent, *F.parent.parents]):
            pin(directory, True, fixed_pins)
        for directory in [E, G, R]:
            pin(directory, True, fixed_pins)
        F.mkdir()
        status_update(phase='fixture_created', fixture_created=True)
        with (F / '.facman-diagnostic-fixture.v1.json').open('x', encoding='utf-8') as stream:
            json.dump(dict(owner='pack-gui-interrupted-import-04', plan_sha256=plan_hash, task_marker_sha256=plan['task_marker_sha256']), stream)
            stream.flush(); os.fsync(stream.fileno())
        pin(F, True, fixed_pins)
        RAW.mkdir(); (RAW / 'cas').mkdir(); C.mkdir()
        with (RAW / 'launcher-admission.raw.json').open('xb') as stream:
            stream.write(launch_raw)
        shutil.copytree(R / 'tests/fixtures/fake_factorio_install', I)
        fixture_before = plain(I)
        with contextlib.ExitStack() as stack:
            stack.enter_context(patch.object(native_cli, 'invoke_machine', run_machine))
            stack.enter_context(patch.object(native_cli, 'ROOT', C))
            stack.enter_context(patch.object(solver, 'FIXTURE_INSTALL', I))
            stack.enter_context(patch.object(presentation, 'FIXTURE_INSTALL', I))
            # Fixture/oracle aliases use native_cli.invoke, which resolves the
            # patched machine boundary at call time. No source module changes.
            source, consumer, actual_pack = presentation.PresentationPackImportTests().prepare(F, b'\x00declared binary settings\xff')
            assert source == P and consumer == WS
            assert actual_pack == pack
            sentinel = WS / 'user-owned/sentinel.bin'
            sentinel.parent.mkdir(); sentinel.write_bytes(b'foreign player bytes\x00\xff')
            sentinel_before = (sentinel.read_bytes(), object_identity(sentinel))
            producer_before = snapshot(P, 'source producer before GUI')
            install_before = snapshot(I, 'registered fixture installation before GUI')
            package_product = machine(['product', 'inspect', '--json'])
            result['backend_identity'] = require_backend_identity(G, G / 'bin/facman.exe', package_product)
            backend = package_product['backend_identity']
            assert backend['build']['source_revision'] == plan['artifact_source']
            assert backend['build']['source_dirty'] is False
            assert backend['contract_set_sha256'] == plan['contract_set_sha256']
            assert backend['package']['files_verified'] == 598
            assert backend['build']['universal_launcher_revision'] == plan['provider_pins']['ULK']
            assert backend['build']['universal_setup_revision'] == plan['provider_pins']['USK']
            content = machine(['--workspace', str(WS), 'presentation', 'query', 'content', '--json'])
            descriptor = next(a for a in content['available_semantic_actions'] if a['action_id'] == 'modsets.import')
            assert descriptor['availability'] == 'available' and descriptor['confirmation'] == 'explicit'
            fields = {row['field_id']: row for row in descriptor['input_fields']}
            assert set(fields) == {'source_path', 'new_instance_id', 'installation_id', 'display_name'}
            assert fields['installation_id']['choices'] == ['fixture']
            result['content_revision'] = content['revision']
            result['content_descriptor'] = descriptor
            snapshot(WS, 'consumer before GUI dispatch')
            assert not signal.exists() and not release.exists() and not stage.exists() and not target.exists()
            environment = {k: v for k, v in os.environ.items() if not k.startswith('FACMAN_')}
            environment.update(PATH='', PYTHONDONTWRITEBYTECODE='1', TEMP=str(F), TMP=str(F))
            fault_environment = dict(environment, FACMAN_TEST_MODPACK_IMPORT_PAUSE='verified')
            job_class = fault.reviewed_job_class(gui, persist_fault, binding)
            stack.enter_context(patch.object(gui, 'OwnedProcessJob', job_class))
            active = gui.OwnedControls(G / 'bin/FacMan.WinForms.exe', C, WS, fault_environment, deadline)
            session = dict(events=active.events)
            result['sessions'].append(session)
            main = active.window('FacMan'); active.show_main_offscreen(main)
            active.wait(lambda: 'revision 0' not in active.revision(main) and bool(active.revision(main)), 'initial production observation')
            tab(active, main, 2, 'Content')
            active.click(active.control(main, 'Import offline pack'))
            dialog = active.window(descriptor['label'], 'Continue')
            fill(active, dialog, fields['source_path']['label'], str(pack))
            fill(active, dialog, fields['new_instance_id']['label'], 'reconstructed')
            fill(active, dialog, fields['display_name']['label'], 'Restored pack')
            combos = [h for h in active.enumerate(dialog) if 'COMBOBOX' in active.text(h, True).upper()]
            assert len(combos) == 1 and active.text(combos[0]) == 'fixture'
            active.select(combos[0], 0, 'fixture')
            frame(active, dialog, 'actual typed Content import values')
            active.click(active.control(dialog, 'Continue'))
            confirmation = active.window(descriptor['label'], 'Apply ' + descriptor['label'])
            frame(active, confirmation, 'separate explicit import confirmation')
            dispatch_at = time.monotonic()
            active.click(active.control(confirmation, 'OK'))
            active.wait(lambda: signal.exists(), 'original verified import pause', seconds=20)
            assert time.monotonic() - dispatch_at < 20
            binding()
            active.job.interrupt_verified_import()
            assert active.job.intentional and active.job.intentional['termination_succeeded']
            # Release the source/staging/journal no-delete capabilities before
            # ordinary recovery needs native rename and journal replacement.
            unpin(pins)
            refusal = active.window(descriptor['label'] + ' refused')
            frame(active, refusal, 'actual transport uncertainty after exact backend loss')
            visible = '\n'.join(active.text(h) for h in active.enumerate(refusal)).casefold()
            assert 'frontend_' in visible and any(s in visible for s in ('unknown', 'after dispatch', 'recovery'))
            assert original_receipt_path.read_bytes() == original_receipt_bytes
            assert json.loads(original_receipt_bytes)['state'] == 'accepted_outcome_unknown'
            assert snapshot(stage, 'retained stage after intentional loss') == original_stage
            active.click(active.control(refusal, 'OK'))
            # Fresh session is the ordinary cross-process route around the
            # old session's deliberate uncertain-action effect interlock.
            active.finish(); session['terminal'] = active.terminal; active = None
            assert (sentinel.read_bytes(), object_identity(sentinel)) == sentinel_before
            active = gui.OwnedControls(G / 'bin/FacMan.WinForms.exe', C, WS, environment, deadline)
            session = dict(events=active.events); result['sessions'].append(session)
            main = active.window('FacMan'); active.show_main_offscreen(main)
            active.wait(lambda: 'revision 0' not in active.revision(main) and bool(active.revision(main)), 'fresh recovery observation')
            tab(active, main, 4, 'Activity')
            frame(active, main, 'ordinary Activity recovery controls')
            active.click(active.control(main, 'Apply supported recovery'))
            confirmation = active.window('Recover operation', transaction_id)
            frame(active, confirmation, 'exact domain transaction recovery confirmation')
            assert any(transaction_id in active.text(h) for h in active.enumerate(confirmation))
            assert original_receipt_path.read_bytes() == original_receipt_bytes
            active.click(active.control(confirmation, 'OK'))
            active.wait(lambda: journal_path.exists() and json.loads(journal_path.read_bytes())['state'] == 'complete',
                'ordinary GUI recovery completes original domain journal')
            active.wait(lambda: any(active.text(h).replace('\r\n', '\n') == 'Instance\nRestored pack'
                for h in active.enumerate(main)), 'ordinary refreshed selected imported instance')
            frame(active, main, 'recovery completion and selected new instance')
            active.finish(); session['terminal'] = active.terminal; active = None
            portable.PortableModpackImportTests().assert_reconstruction(WS, pack)
            assert original_receipt_path.read_bytes() == original_receipt_bytes
            recovered = json.loads(journal_path.read_bytes())
            assert recovered['state'] == 'complete' and recovered['transaction_id'] == transaction_id
            assert object_identity(target) == frozen_binding['stage_identity']
            target_after = snapshot(target, 'recovered exact published instance')
            for name, row in original_stage.items():
                if name not in ('.facman-archive-staging.v1', '.facman-transaction-staging.v2.json'):
                    assert target_after[name] == row, name
            assert snapshot(P, 'source producer unchanged') == producer_before
            assert snapshot(I, 'registered installation unchanged') == install_before
            assert (sentinel.read_bytes(), object_identity(sentinel)) == sentinel_before
            assert plain(I) == fixture_before
            # Terminal inspect and plan are read-only; do not replay the original
            # semantic request or apply recovery to the terminal journal.
            terminal_before = snapshot(WS, 'before terminal read-only inspection')
            machine(['--workspace', str(WS), 'workspace', 'recovery', 'inspect', '--json'])
            machine(['--workspace', str(WS), 'workspace', 'recovery', 'plan', transaction_id, '--json'])
            assert snapshot(WS, 'after terminal read-only inspection') == terminal_before
            receipts = [json.loads(p.read_bytes()) for p in (WS / '.facman/action-receipts-v2').glob('*.v2.json')]
            recoveries = [r for r in receipts if r['action_id'] == 'recovery.apply_supported']
            assert len(recoveries) == 1
            rr = recoveries[0]; rq = json.loads(rr['request_json']); outcome = json.loads(rr['result_json'])
            assert rq['transaction_id'] == transaction_id and rq['confirmation'] == 'explicit'
            assert outcome['outcome'] == 'completed'
            result.update(status='PASS_EXACT_PACKAGED_GUI_INTERRUPTED_IMPORT_ORDINARY_RECOVERY',
                transaction_id=transaction_id, original_uncertain_receipt_sha256=digest(original_receipt_bytes),
                recovered_journal_sha256=sha(journal_path), recovery_semantic_receipt=rr,
                original_request_replayed=False, terminal_apply_dispatched=False,
                intentional_fault_count=1, naturally_drained_gui_jobs=2)
            save()
    except BaseException as error:
        result.update(status='FAIL_RETAINED', error=str(error), traceback=traceback.format_exc())
        status_update(status=result['status'], error=result['error'], traceback=result['traceback'])
    finally:
        unpin(pins)
        if active is not None:
            try:
                active.finish()
            except BaseException as error:
                result.setdefault('cleanup_errors', []).append(repr(error))
                result['status'] = 'FAIL_RETAINED_CLEANUP'
            if result['sessions']:
                result['sessions'][-1]['terminal'] = active.terminal
        result.update(elapsed_seconds=time.monotonic()-started)
        if RAW.exists():
            try:
                result['final_fixture_inventory'] = snapshot(F, 'retained complete owned fixture')
                probe.guard(plan)
                assert plain(G) == expected_package
                assert plain(R / 'tests/fixtures/fake_factorio_install') == plan['source_fixture_inventory']
                output_guard()
                result['final_guards'] = dict(package_599_unchanged=True, source_clean_and_frozen=True,
                    source_fixture_unchanged=True, no_cleanup_deletion=True)
            except BaseException as error:
                result.setdefault('final_guard_errors', []).append(repr(error))
                result['status'] = 'FAIL_RETAINED_FINAL_GUARD'
            save()
        unpin(fixed_pins)
    return 0 if result['status'].startswith('PASS_') else 1


if __name__ == '__main__':
    # This record lives directly in existing E and is durable before guards,
    # imports, inventories, pins or fixture creation can fail. Existing records
    # are never overwritten by a retry.
    with (E / 'pack-gui-interrupted-worker-status-04.json').open('x+b') as STATUS_STREAM:
        status_update()
        try:
            assert len(sys.argv) == 3 and sys.argv[1] == '--reviewed-plan-sha256'
            code = execute(sys.argv[2])
            status_update(exit_code=code)
        except BaseException as error:
            status_update(status='FAIL_RETAINED', wrapper_error=str(error),
                wrapper_traceback=traceback.format_exc(), exit_code=1)
            code = 1
        print(json.dumps({k:STATUS.get(k) for k in ('status','phase','exit_code','error','wrapper_error')}), flush=True)
    raise SystemExit(code)
