import hashlib,json,os,subprocess,sys,traceback,zipfile
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.safecrlf',GIT_CONFIG_VALUE_0='false')
sys.dont_write_bytecode=True;sys.path.insert(0,str(R));from tools import provider_canary_process as owned
BASE='46f2af9e4c25257628303c057f1db86ad80aa78d';BRANCH='task/facman-linux-existing-ini-01';Q='.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
out=E/'linux-existing-ini-commit-result-01.json';assert not out.exists()
record=dict(status='SEALING_QUALIFIED_LINUX_OWNER',commands=[],goal_status_mutated=False,new_optional_campaigns=0)
def save():out.write_text(json.dumps(record,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
def run(label,args,timeout=180):
    r=owned.command(args,cwd=R,environment=dict(os.environ),timeout=timeout,directory=E/('linux-existing-ini-commit01-'+label),output_limit=2*1024*1024)
    record['commands'].append(dict(label=label,exit=r.returncode,receipt_sha256=sha(r.directory/'receipt.json')));save()
    assert r.ok and r.receipt['primary_stopped'] and r.receipt['job_empty_observed'],(label,r.stderr[-1600:].decode(errors='replace'));return r
try:
    assert git('rev-parse','HEAD')==BASE and git('branch','--show-current')==BRANCH and not git('diff','--cached','--name-only')
    summary_path=E/'linux-existing-ini-qualification-summary-02.json';assert sha(summary_path)=='1320d857c7fe88b3f47173ecbf0051c9059c92151408b9c03323a8a673493de6'
    a=json.loads(summary_path.read_bytes());assert a['status']=='PASS_LINUX_EXISTING_INI_OWNER_QUALIFICATION' and a['base_head']==BASE
    for n,h in a['candidate_files_sha256'].items():assert sha(R/n)==h,n
    assurance_path=E/'linux-existing-ini-source-assurance-03.json';assert sha(assurance_path)==a['source_assurance_sha256']
    assurance=json.loads(assurance_path.read_bytes())
    for n,h in assurance['source_files_sha256'].items():assert sha(R/n)==h,n
    assert len(assurance['source_files_sha256'])==1946
    assert hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=R)).hexdigest()==a['index_semantic_sha256']
    assert git('write-tree')==a['staged_tree'] and sha(W/'native-save-context-linux/facman')==a['cli_sha256']
    for n,h in a['native_images_sha256'].items():assert sha(W/'native-save-context-linux'/n)==h,n
    assert a['combined_accepted_counts']['total_passed']==57 and a['combined_accepted_counts']['linux_owner_new_methods_passed']==11
    assert a['fresh_proof']['total_passed']==50 and a['accepted_reuse']['total_reused_passed']==7 and a['fresh_proof']['new_linux_skip_count']==0
    assert all(a['drain'][k] for k in ('owned_primary_stopped','owned_windows_job_empty','linux_namespace_empty','private_fixture_unmounted','private_native_bind_unmounted','parent_fixture_empty'))
    assert all(c['exit']==0 and not c['execution_limit_exceeded'] for c in a['commands'])
    assert sha(E/'linux-existing-ini-independent-source-review-04.json')==a['reuse_boundaries']['independent_review04_sha256']
    assert sha(E/'linux-existing-ini-qualification-summary-01.json')==a['accepted_reuse']['prior_summary_sha256']
    task_paths=set(a['candidate_files_sha256']);assert set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())==task_paths
    archive=R/Q/'evidence/linux-existing-ini-custody.v1.zip';evidence=R/Q/'evidence/linux-existing-ini.v1.json';assert not archive.exists() and not evidence.exists()
    manifest={}
    for item in a['custody']:
        p=Path(item['path']);assert p.is_relative_to(E) and sha(p)==item['sha256'];manifest[p.relative_to(E).as_posix()]=item['sha256']
    for name in (summary_path.name,'linux-existing-ini-independent-source-review-02.json','linux-existing-ini-independent-source-review-03.json','linux-existing-ini-obligation-review-02.json','linux-existing-ini-commit-01.py'):
        manifest[name]=sha(E/name)
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr('custody-manifest.json',json.dumps(manifest,indent=2,sort_keys=True)+'\n')
        for n in sorted(manifest):z.write(E/n,'evidence/'+n)
    with zipfile.ZipFile(archive) as z:
        for n,h in manifest.items():assert hashlib.sha256(z.read('evidence/'+n)).hexdigest()==h,n
    proof=dict(schema='facman.linux_existing_ini_owner_qualification.v1',base_head=BASE,files_sha256=a['candidate_files_sha256'],qualification_summary_sha256=sha(summary_path),independent_review_sha256=a['reuse_boundaries']['independent_review04_sha256'],source_assurance_sha256=a['source_assurance_sha256'],linux_cli_sha256=a['cli_sha256'],combined_accepted_counts=a['combined_accepted_counts'],fresh_passes=50,explicitly_reused_passes=7,actual_owner_sigkill_combinations=9,repeated_actual_prefix_recovery_losses=3,all_eleven_durable_boundaries=True,checkpoint_parent_permission_denial_proven=True,metadata_xattrs_acl_inode_preserved=True,terminal_states_readonly=True,uid=65534,gid=65534,groups=[],private_tmpfs_bytes=134217728,drained=True,first_fixture_failure_preserved=True,custody=archive.name,custody_sha256=sha(archive),custody_members=len(manifest)+1,required_cross_platform_ci_pending=True,authority_delta='Linux ordinary confirmed existing-INI reconciliation and journal recovery admitted through existing guards',darwin_owner_admitted=False,readiness_complete=False,play=False,permit=False,physical_ext4=False,apfs=False,power_loss=False,game=False,beta=False,rc=False)
    evidence.write_text(json.dumps(proof,indent=2)+'\n')
    with (R/Q/'ExecPlan.md').open('a',encoding='utf-8',newline='\n') as f:
        f.write('\n### Linux ordinary existing-INI reconciliation and recovery\n\nThe checked POSIX primitive integration is consumed at dev46f2af9e. The ordinary planner, confirmed action and recovery owner now admit Linux explicitly, retaining the same original inode, parent, readable metadata, current input guard, locks and durable journal. Windows hook semantics and metadata suite are preserved; Darwin owner admission remains closed. Scoped Linux qualification accepts 57 passes (50 fresh plus seven explicitly reused), four Windows-only skips and no new Linux skips. All eleven new owner methods pass: ordinary scopes and intents, exact custom bytes and metadata/xattr/ACL/inode preservation, all eleven interruption boundaries, nine actual CLI SIGKILL combinations with three repeated recovery losses, current input and unsafe-object refusal, terminal verification-only behavior and demonstrated unprivileged atomic-checkpoint parent denial followed by recovery. The first profile-fixture error and its correction remain in custody; no build or successful proof was duplicated. Owned execution and private mounts drain. Fresh required source CI, physical host/filesystem, actual game, canonical Desktop and broader Make Ready/Beta/RC acceptance remain open.\n\nEvidence: `evidence/linux-existing-ini.v1.json` and its hash-closed custody archive.\n')
    paths=task_paths|{Q+'/ExecPlan.md',Q+'/evidence/'+evidence.name,Q+'/evidence/'+archive.name}
    assert set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())==paths
    for label in ('policy','detect','plan'):run(label,['py','-3','-B','.aide/scripts/aide_lite.py','git',label])
    run('strict',['py','-3','-B','tools/strict_check.py'],1800)
    message='feat(readiness): reconcile existing Linux INI in place\n\nPreserve the original inode, custom bytes and readable metadata through\nconfirmed routing repair and durable interruption recovery.\n\nWork-Item: FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01\nEvidence-Ref: '+Q+'/evidence/'+evidence.name+'\n'
    msg=E/'linux-existing-ini-commit-message-01.txt';msg.write_text(message,encoding='utf-8',newline='\n');run('message',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--message',message])
    changes=[dict(path=n,state='content',sha256=sha(R/n),git_blob_oid=git('hash-object','--path',n,str(R/n)),ownership='task_owned') for n in sorted(paths)]
    snapshot=hashlib.sha256((json.dumps(changes,indent=2,sort_keys=True,separators=(',',': '))+'\n').encode()).hexdigest()
    review=E/'linux-existing-ini-commit-review-01.json';review.write_text(json.dumps(dict(schema_version='aide.git-commit-review.v1',verdict='PASS',reviewer='/root',runtime_author='/root/linux_existing_ini_implementation',non_authoring=True,branch=BRANCH,base_commit=BASE,snapshot_sha256=snapshot,message_sha256=sha(msg),independent_source_review_sha256=proof['independent_review_sha256'],qualification_summary_sha256=sha(summary_path),custody_sha256=sha(archive),review='Existing retained owner reuse and Linux-only hook extension independently reviewed; actual57 accepted passes and classified skips/custody/drain verified; failed fixture and exact scoped reuse preserved; fresh required CI and broader product gates remain open'),indent=2)+'\n')
    classification=E/'linux-existing-ini-commit-classification-01.json';classification.write_text(json.dumps(dict(schema_version='aide.git-commit-classification.v1',branch=BRANCH,base_commit=BASE,work_item='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01',snapshot_sha256=snapshot,message_sha256=sha(msg),changed_paths=changes,reviews=[dict(path=str(review),sha256=sha(review),verdict='PASS')]),indent=2)+'\n')
    helper=['py','-3','-B','.aide/scripts/aide_lite.py','git','commit-plan','--classification',str(classification),'--message-file',str(msg)]
    run('plan-stage',helper);run('stage',['git','add','--',*sorted(paths)]);run('diff',['git','diff','--cached','--check']);run('plan-commit',helper)
    assert git('rev-parse','HEAD')==BASE;run('commit',['git','commit','-F',str(msg)])
    run('range',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--range',BASE+'..HEAD']);assert not git('status','--porcelain')
    record.update(status='COMMITTED_QUALIFIED_LINUX_EXISTING_INI_OWNER',source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),review_sha256=sha(review),evidence_sha256=sha(evidence),remote_not_pushed=True)
except BaseException as exc:record.update(status='ACTIONABLE_LINUX_OWNER_COMMIT_FAILURE',error=str(exc),traceback=traceback.format_exc())
finally:save();print(json.dumps({k:v for k,v in record.items() if k!='commands'},indent=2))
raise SystemExit(0 if record['status']=='COMMITTED_QUALIFIED_LINUX_EXISTING_INI_OWNER' else 1)
