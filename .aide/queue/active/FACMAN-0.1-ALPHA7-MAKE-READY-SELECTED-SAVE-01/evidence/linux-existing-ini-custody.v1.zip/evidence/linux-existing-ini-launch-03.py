import hashlib,json,os,shutil,subprocess,sys,time,traceback
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
sys.path.insert(0,str(R))
from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',CMAKE_BUILD_PARALLEL_LEVEL='2')
out=E/'linux-existing-ini-launch-result-03.json';assert not out.exists()
linux_e='/mnt/d/'+str(E)[3:].replace('\\','/')
record=dict(status='PREFLIGHT',commands=[],reserve_bytes=12*1024**3,planned_peak_bytes=2*1024**3,new_roots=0,new_clones=0,new_worktrees=0)
def save():out.write_text(json.dumps(record,indent=2)+'\n')
probe='''import os,json
names={'cmake','ninja','g++','c++','cc1plus','clang','clang++','ctest','facman'};active=[]
for name in os.listdir('/proc'):
 if name.isdigit():
  try:
   if open('/proc/'+name+'/comm').read().strip() in names:active.append(dict(pid=int(name),command=open('/proc/'+name+'/cmdline','rb').read().decode(errors='replace').replace(chr(0),' ')))
  except FileNotFoundError:pass
print(json.dumps(dict(mount_namespace=os.readlink('/proc/self/ns/mnt'),active=active)))'''
query="$all=@(Get-CimInstance Win32_Process); @($all | Where-Object { $_.Name -match '^(cl|clang|link|ninja|ctest)\\.exe$' -or ($_.Name -eq 'cmake.exe' -and $_.CommandLine -like '*--build*') -or ($_.Name -eq 'MSBuild.exe' -and $_.CommandLine -notlike '*/nodemode:*') } | Select-Object Name,ProcessId,ParentProcessId,CommandLine) | ConvertTo-Json -Depth 4 -Compress -AsArray"
def census():
 windows=json.loads(subprocess.check_output(['pwsh','-NoProfile','-Command',query],text=True,timeout=45) or '[]')
 linux=json.loads(subprocess.check_output(['wsl','-d','Ubuntu-24.04','-u','root','--','python3','-B','-c',probe],text=True,timeout=45))
 return dict(windows=windows,linux=linux)
try:
 record['admission_wait_observations']=[];admission_deadline=time.monotonic()+7200
 while True:
  record['before']=census()
  if not record['before']['windows'] and not record['before']['linux']['active']:break
  record['status']='WAITING_FOREIGN_NATIVE_UNTOUCHED';record['admission_wait_observations'].append(dict(at=time.time(),census=record['before']));save()
  assert time.monotonic()<admission_deadline,'finite admission deadline exceeded; foreign processes untouched'
  time.sleep(min((30,45,60)[min(len(record['admission_wait_observations'])-1,2)],max(1,admission_deadline-time.monotonic())))
 record['free_bytes_before']=shutil.disk_usage(W).free;assert record['free_bytes_before']>=record['reserve_bytes']+record['planned_peak_bytes']
 linux_e='/mnt/d/'+str(E)[3:].replace('\\','/')
 argv=['wsl','-d','Ubuntu-24.04','-u','root','--','env','FACMAN_PARENT_MOUNT_NAMESPACE='+record['before']['linux']['mount_namespace'],'timeout','--signal=TERM','--kill-after=15s','6000s','unshare','--mount','--pid','--fork','--mount-proc','--kill-child=SIGKILL','python3','-B',linux_e+'/linux-existing-ini-linux-driver-03.py']
 record['status']='RUNNING_FINITE_OWNED_LINUX_JOB';save()
 result=owned.command(argv,cwd=R,environment=dict(os.environ),timeout=6060,budget=owned.Budget(6120,6060),directory=E/'linux-existing-ini-owned-execution-03',output_limit=16*1024*1024)
 record['commands'].append(dict(exit=result.returncode,termination=result.receipt['termination'],primary_stopped=result.receipt['primary_stopped'],job_empty=result.receipt['job_empty_observed'],receipt_sha256=sha(result.directory/'receipt.json')))
 assert result.ok and result.receipt['primary_stopped'] and result.receipt['job_empty_observed']
 record['linux_result_sha256']=sha(E/'linux-existing-ini-linux-result-03.json');record['status']='PASS_OWNED_LINUX_EXISTING_INI_QUALIFICATION'
except BaseException as exc:record.update(status='ACTIONABLE_LINUX_TUI_LAUNCH_FAILURE',error=str(exc),traceback=traceback.format_exc())
finally:
 record['after']=census();record['free_bytes_after']=shutil.disk_usage(W).free
 mount=linux_e+'/posix-publication-private-fixtures-01'
 check='import os,json;print(json.dumps(dict(mounted=os.path.ismount('+repr(mount)+'),empty=not os.listdir('+repr(mount)+'))))'
 record['parent_mount_after']=json.loads(subprocess.check_output(['wsl','-d','Ubuntu-24.04','-u','root','--','python3','-B','-c',check],text=True,timeout=45))
 save();print(json.dumps(record,indent=2));raise SystemExit(0 if record['status'].startswith('PASS_') else 1)
