import base64
from contextlib import redirect_stdout
import ctypes
from ctypes import wintypes as wt
import hashlib
import json
import os
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
import zlib

R = Path(r'D:\Projects\Factorio\factorio-launcher')
W = Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e')
G = W / 't/j3/g'
consumer = W / 't/j3/cvis08'
consumer.mkdir(exist_ok=False)
sys.path[:0] = [str(R / 'tests'), str(R)]
import test_windows_delivered_joined_gui as tested
import delivered_environment_reconstruction as reconstruction

probes = []
class VisibleControls(tested.OwnedControls):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.api.GetForegroundWindow.argtypes = []
        self.api.GetForegroundWindow.restype = wt.HWND
        self.api.GetWindowRect.argtypes = [wt.HWND, ctypes.POINTER(wt.RECT)]
        self.api.GetWindowRect.restype = wt.BOOL
        self.probe = dict(pid=self.process.pid, main=None, passive_show=None, clicks=[])
        probes.append(self.probe)

    def ancestors(self, hwnd):
        root = self.api.GetAncestor(hwnd, 2)
        self.require_owned(root)
        result = []
        current = hwnd
        for unused in range(16):
            self.require_owned(current)
            result.append(dict(hwnd=current, class_name=self.text(current, True),
                **self.control_state(current)))
            if current == root:
                return result
            current = self.api.GetParent(current)
            if not current:
                break
        raise AssertionError('Owned control ancestors did not terminate at exact root')

    def selected_observation(self, main):
        self.require_owned(main)
        class_name = self.text(main, True)
        assert self.text(main) == 'FacMan' and class_name.startswith('WindowsForms10.Window.')
        assert self.api.GetAncestor(main, 2) == main
        self.probe['main'] = dict(hwnd=main, class_name=class_name, pid=self.process.pid)
        button = self.control(main, 'Make Ready with current settings')
        before = self.ancestors(button)
        assert self.api.SetWindowPos(main, None, -20000, -20000, 0, 0, 0x15)
        rectangle = wt.RECT()
        assert self.api.GetWindowRect(main, ctypes.byref(rectangle))
        assert rectangle.right < -10000 and rectangle.bottom < -10000
        foreground = self.api.GetForegroundWindow()
        # Only this exact owned FacMan main form. NOSIZE | NOZORDER |
        # NOACTIVATE | SHOWWINDOW keeps the ordinary controls offscreen.
        if not self.api.SetWindowPos(main, None, -20000, -20000, 0, 0, 0x55):
            raise ctypes.WinError(ctypes.get_last_error())
        unchanged = foreground == self.api.GetForegroundWindow()
        after = self.ancestors(button)
        assert self.api.IsWindowVisible(main) and all(item['visible'] for item in after)
        assert unchanged, 'Passive owned show changed foreground'
        self.probe['passive_show'] = dict(flags=0x55, foreground_unchanged=unchanged,
            before=before, after=after, offscreen_rectangle=dict(left=rectangle.left,
                top=rectangle.top, right=rectangle.right, bottom=rectangle.bottom))
        super().selected_observation(main)
        frame = self.events[-1]
        self.probe['selection_readiness'] = [dict(hwnd=item['hwnd'], text=item['text'])
            for item in frame['controls'] if item.get('text', '').startswith(('Readiness:', 'Readiness\r\n'))]
        edits = []
        for hwnd in self.enumerate(main):
            if 'EDIT' in self.text(hwnd, True).upper():
                value = ctypes.create_unicode_buffer(16384)
                self.send(hwnd, 0xD, len(value), ctypes.addressof(value))
                edits.append(dict(hwnd=hwnd, caption=self.text(hwnd), wm_gettext=value.value))
        self.probe['owned_edit_reads'] = edits

    def click(self, hwnd):
        state = dict(hwnd=hwnd, text=self.text(hwnd), ancestors=self.ancestors(hwnd))
        self.probe['clicks'].append(state)
        assert self.api.IsWindowVisible(hwnd) and self.api.IsWindowEnabled(hwnd)
        return super().click(hwnd)

log_path = W / 'evidence/windows-delivered-gui-visible-probe-01.log'
assert not log_path.exists()
test_result = unittest.TestResult()
# Focused GUI regression: the prior GUI oracle remains unmodified. The three
# unchanged portable-environment scenarios are outside this diagnostic change's
# local regression scope; required CI still executes all of them from source.
with log_path.open('w', encoding='utf-8') as stream, redirect_stdout(stream), \
     patch.dict(os.environ, FACMAN_DELIVERED_GUI_PACKAGE=str(G),
         FACMAN_DELIVERED_GUI_CONSUMER=str(consumer)), \
     patch.object(reconstruction, 'SCENARIOS', ()), \
     patch.object(tested, 'OwnedControls', VisibleControls):
    tested.WindowsDeliveredJoinedGuiTests(
        'test_actual_joined_controls_dispatch_production_packaged_backend').run(test_result)

terminal_path = W / 'evidence/windows-delivered-gui-visible-probe-terminal-01.json'
assert not terminal_path.exists()
terminal_path.write_text(json.dumps(dict(tests_run=test_result.testsRun,
    failures=[item[1] for item in test_result.failures], errors=[item[1] for item in test_result.errors],
    probes=probes), indent=2))
assert test_result.testsRun == 1 and not test_result.failures and not test_result.errors, \
    repr(test_result.failures + test_result.errors)
lines = log_path.read_text().splitlines()
prefix = 'delivered-windows-gui-custody '
custody, = [json.loads(line[len(prefix):]) for line in lines if line.startswith(prefix)]
compressed = base64.b64decode(custody['payload_base64'], validate=True)
assert hashlib.sha256(compressed).hexdigest() == custody['compressed_sha256']
canonical = zlib.decompress(compressed)
assert hashlib.sha256(canonical).hexdigest() == custody['canonical_sha256']
manifest = json.loads(canonical)
assert len(manifest) == custody['file_count']
raw = {}
for name, item in manifest.items():
    data = base64.b64decode(item['bytes_base64'], validate=True)
    assert len(data) == item['size_bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
    assert data == (consumer / 'evidence' / name).read_bytes()
    raw[name] = data
record = json.loads(raw['result.json'])
assert record['result'] == 'PASS' and 'exception' not in record and 'cleanup_exception' not in record
assert record['package_closure_unchanged'] and len(record['sessions']) == 2
for session in record['sessions']:
    terminal = session['terminal']
    assert terminal['exit_code'] == 0 and not terminal['safety_termination']
    assert terminal['owned_job_active_processes'] == 0
    assert terminal['launch']['exact_job_membership_before_resume']
    assert all(event['post_succeeded'] for event in session['events'] if event['stage'] == 'BM_CLICK')
for snapshot in record['snapshots']:
    for name, item in snapshot['inventory'].items():
        assert raw['objects/' + item['sha256']]
prefix = 'delivered-windows-gui-result '
summary, = [json.loads(line[len(prefix):]) for line in lines if line.startswith(prefix)]
assert summary['result'] == 'PASS'
assert summary['result_sha256'] == hashlib.sha256(raw['result.json']).hexdigest()
processes = [process for session in record['sessions'] for process in session['terminal']['backend_processes']]
receipt = dict(schema='facman.windows_delivered_gui_offscreen_visibility_probe.v1', result='PASS_GUI_ORACLE_OWNED_OFFSCREEN',
    qualification='external owned offscreen visibility comparison; reused source002 package, GUI oracle only; not fresh factory or established CI causality',
    probes=probes,
    omitted_only_in_external_driver=['three unchanged portable-environment scenarios'],
    source_sha256=hashlib.sha256((R / 'tests/test_windows_delivered_joined_gui.py').read_bytes()).hexdigest(),
    consumer=str(consumer), log=str(log_path), log_sha256=hashlib.sha256(log_path.read_bytes()).hexdigest(),
    result_sha256=summary['result_sha256'], custody_sha256=custody['canonical_sha256'],
    file_count=len(raw), log_bytes=log_path.stat().st_size,
    gui_pids=[session['terminal']['pid'] for session in record['sessions']],
    total_observed_owned_descendants=len(processes),
    observed_packaged_backends=sum(p['role'] == 'packaged_backend' for p in processes),
    observed_console_hosts=sum(p['role'] == 'windows_console_host' for p in processes),
    fixture_cli_calls=len(record['calls']),
    normal_exits=True, owned_job_active_processes=0, package_closure_unchanged=True,
    completed_owner_commands=[item['owner_command'] for item in record['outcome']['action_payload']['completed_components']])
receipt_path = W / 'evidence/windows-delivered-gui-visible-probe-result-01.json'
assert not receipt_path.exists()
receipt_path.write_text(json.dumps(receipt, indent=2))
print(json.dumps({key: value for key, value in receipt.items() if key != 'probes'}, indent=2))
