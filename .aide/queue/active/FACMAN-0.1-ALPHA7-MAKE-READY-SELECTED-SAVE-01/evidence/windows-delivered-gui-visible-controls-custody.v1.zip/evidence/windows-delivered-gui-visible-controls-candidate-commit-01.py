import hashlib, json, os, subprocess, sys, traceback, zipfile
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher'); E=Path(__file__).resolve().parent; W=E.parent
BASE='a176d21c399078aa453597a10bc4941898ebc7c2'; BRANCH='task/facman-linux-delivered-environment-01'
Q='.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds', TEMP=str(W/'t'), TMP=str(W/'t'), PYTHONDONTWRITEBYTECODE='1', GIT_CONFIG_COUNT='1', GIT_CONFIG_KEY_0='core.safecrlf', GIT_CONFIG_VALUE_0='false')
sys.path.insert(0,str(R)); from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True,encoding='utf-8').strip()
dirty=lambda:set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
out=E/'windows-delivered-gui-visible-controls-candidate-commit-result-01.json'; assert not out.exists()
record=dict(status='QUALIFYING_OWNED_VISIBLE_GUI_CONTROLS',commands=[],new_roots=0,new_clones=0,new_worktrees=0,native_rebuild=False,goal_status_mutated=False)
def save():out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
def run(label,args,timeout=180,codes=(0,)):
 r=owned.command(args,cwd=R,environment=dict(os.environ),timeout=timeout,directory=E/('gui-visible-controls-commit01-'+label),output_limit=8*1024**2,wait_for_job_empty_after_primary=True)
 record['commands'].append(dict(label=label,exit=r.returncode,receipt_sha256=sha(r.directory/'receipt.json')));save()
 assert r.returncode in codes and r.receipt['termination']=='completed' and r.receipt['primary_stopped'] and r.receipt['job_empty_observed'] and not r.receipt['job_terminated'],(label,(r.stdout[-1000:]+r.stderr[-1500:]).decode('utf-8','replace'))
 return r
try:
 assert git('rev-parse','HEAD')==BASE and git('branch','--show-current')==BRANCH and not git('diff','--cached','--name-only')
 packet=E/'windows-delivered-gui-visible-controls-author-packet-01.json'; p=json.loads(packet.read_bytes())
 review=E/'windows-delivered-gui-visible-controls-independent-review-01.json'; v=json.loads(review.read_bytes())
 assert v['verdict']=='PASS_OWNED_VISIBLE_CONTROLS_FOR_REQUIRED_CURRENT_CI' and v['non_authoring'] and v['author_packet_sha256']==sha(packet)
 expected={Path(row['path']).resolve().relative_to(R.resolve()).as_posix() for row in p['author_files']}; assert expected=={'tests/test_windows_delivered_joined_gui.py','docs/development/make-ready-preparation.md'} and dirty()==expected
 for row in p['author_files']:assert sha(R/row['path'])==row['sha256']
 for label in ('policy','detect','plan'):run(label,['py','-3','-B','.aide/scripts/aide_lite.py','git',label])
 run('paths',['py','-3','-B','tools/workspace_hygiene.py','paths'])
 h=json.loads(run('doctor',['py','-3','-B','tools/workspace_hygiene.py','doctor','--measure'],600,(0,1)).stdout)
 assert set(h['violations'])<={'unmanaged_secondary_worktrees_present'} and len(h['task_roots'])==8 and h['task_root_bytes']<20*1024**3
 names=set()
 for row in p['preserved_artifacts']:
  artifact=Path(row['path']).resolve();assert artifact.is_relative_to(E.resolve()) and sha(artifact)==row['sha256'];names.add(artifact.relative_to(E.resolve()).as_posix())
 names.update({'windows-delivered-gui-diagnostic-candidate-commit-01.py','windows-delivered-gui-diagnostic-candidate-commit-result-01.json'})
 names.update({packet.name,review.name,'windows-delivered-gui-visible-controls-independent-review-01.py',Path(__file__).name,'linux-delivered-failed-windows-job-result-01.json','linux-delivered-acceptance-failed-windows-job-115705425989.log'})
 archive=R/Q/'evidence/windows-delivered-gui-visible-controls-custody.v1.zip'; assert not archive.exists()
 manifest={}
 for name in sorted(names):
  path=(E/name).resolve(); assert path.is_relative_to(E.resolve()) and path.is_file() and path.suffix.lower() not in ('.exe','.dll','.zip')
  manifest['evidence/'+path.relative_to(E).as_posix()]=sha(path)
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
  z.writestr('custody-manifest.json',json.dumps(manifest,indent=2,sort_keys=True)+'\n')
  for name in sorted(manifest):z.write(E/name.removeprefix('evidence/'),name)
 with zipfile.ZipFile(archive) as z:
  assert set(z.namelist())==set(manifest)|{'custody-manifest.json'}
  for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
 assert archive.stat().st_size<4*1024**2
 evidence=R/Q/'evidence/windows-delivered-gui-visible-controls.v1.json'; assert not evidence.exists()
 evidence.write_text(json.dumps(dict(schema='facman.windows_delivered_visible_gui_controls.v1',base_head=BASE,failed_source=BASE,failed_run_id=38533170540,failed_job_id=115749632980,failed_log_sha256=sha(E/'windows-delivered-gui-diagnostic-failed-windows-job-115749632980.log'),actual_failure='second GUI session Make Ready input dialog missing; original35-second timeout',historical_managed_click_rejection_observed=False,author_packet_sha256=sha(packet),independent_review_sha256=sha(review),authored_files_sha256=v['authored_files_sha256'],only_owned_main_shown_offscreen=True,NOACTIVATE_flags=0x55,foreground_readings_observational=True,visible_enabled_owned_ancestors_required=True,bounded_actual_EDIT_contents=True,normal_disposal_partial_frames=True,truthful_failure_custody=True,unchanged_dialog_deadlines_and_queued_dispatch=True,unchanged_success_oracle=True,reused_package_source='002824ea9f2ac4d3844ec5141b455d5733a8008b',reused_GUI_sessions=2,reused_GUI_backend_processes=68,fixture_CLI_calls=8,focused_negative_checks=12,source_regression_only=True,current_head_factory_proof_pending=True,required_checks_pending=True,custody=archive.name,custody_sha256=sha(archive),custody_files=len(manifest),runtime_or_provider_change=False,new_roots=0,new_clones=0,new_worktrees=0,native_rebuild=False,beta=False,rc=False),indent=2)+'\n',encoding='utf-8')
 with (R/Q/'ExecPlan.md').open('a',encoding='utf-8',newline='\n') as stream:
  stream.write('\n### Restore ordinary selectable GUI-control preconditions\n\nThe diagnostic candidate a176d21c retained25 exact files from required Windows job115749632980. Its first session completed both cancellation paths and stale refusal; the second session failed before its first input dialog and exited normally. The retained target and its ancestors were hidden. Its initial EDIT caption suggested projection failure, but actual owned WM_GETTEXT reads prove that caption stale; final presentation contained no structured refusal. Historical managed CanSelect rejection was not observed and is not claimed.\n\nThe minimal test correction shows only the exact verified FacMan main form, already offscreen, with size/Z preservation and SWP_NOACTIVATE. Helpers retain their show states; foreground readings remain observations, so parallel user focus changes cannot manufacture product failure. Ordinary button lookup/dispatch requires visible and enabled owned ancestors. Actual bounded EDIT reads and post-read ownership checks replace stale cross-process captions; partial read-error frames preserve the original timeout while ordinary control errors remain failures. No WinEvent machinery, activation API, click retry, readiness-predicate/deadline change or runtime/provider edit occurs.\n\nThe exact final source independently passes the original two-session GUI owner oracle through the retained produced002824 package:68 actual backends,8fixture CLI calls, both owner effects, cancellations/stale refusal, original inputs, readonly closure and normal zero-job exits. A controlled real timeout still fails and exports24 independently decoded files with normal shutdown. Twelve focused regressions reject hidden/disabled controls and cover bounded reads, disposal/reuse and original-timeout preservation. Both hosted failures and prior hook/input/partial-render comparisons remain durable. Fresh exact-head factory and all required checks remain pending; this structural proof grants no canonical installed Desktop, real game/human, full Make Ready, Beta or RC acceptance.\n\nEvidence: evidence/windows-delivered-gui-visible-controls.v1.json and its hash-closed custody.\n')
 paths=expected|{Q+'/ExecPlan.md',Q+'/evidence/'+archive.name,Q+'/evidence/'+evidence.name}
 run('project-state',['py','-3','-B','tools/project_state.py','--write'],600)
 run('metadata',['py','-3','-B','tools/codegen/generate_metadata.py','--write'])
 changed=dirty();assert paths<=changed<=paths|{'.aide/memory/project-state.md','.aide/memory/project-state.v2.json','README.md'}
 for row in p['author_files']:assert sha(R/row['path'])==row['sha256']
 run('strict',['py','-3','-B','tools/strict_check.py'],1800)
 run('portable-aide',['py','-3','-B','.aide/scripts/aide_lite.py','test'],1800)
 message='fix(winforms): exercise visible owned GUI controls\n\nShow only the verified offscreen main form without activation and read\nactual bounded edit contents while preserving the original GUI oracle.\n\nWork-Item: FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01\nEvidence-Ref: '+Q+'/evidence/'+evidence.name+'\n'
 msg=E/'windows-delivered-gui-visible-controls-candidate-commit-message-01.txt';msg.write_text(message,encoding='utf-8',newline='\n')
 run('message',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--message',message])
 changes=[dict(path=name,state='content',sha256=sha(R/name),git_blob_oid=git('hash-object','--path',name,str(R/name)),ownership='task_owned') for name in sorted(changed)]
 snapshot=hashlib.sha256((json.dumps(changes,indent=2,sort_keys=True,separators=(',',': '))+'\n').encode()).hexdigest()
 commit_review=E/'windows-delivered-gui-visible-controls-candidate-commit-review-01.json'
 commit_review.write_text(json.dumps(dict(schema_version='aide.git-commit-review.v1',verdict='PASS',reviewer='/root',author='/root/windows_delivered_gui_failure_implementation',non_authoring=True,branch=BRANCH,base_commit=BASE,snapshot_sha256=snapshot,message_sha256=sha(msg),independent_source_review_sha256=sha(review),review=v['review']),indent=2)+'\n',encoding='utf-8')
 classification=E/'windows-delivered-gui-visible-controls-candidate-commit-classification-01.json'
 classification.write_text(json.dumps(dict(schema_version='aide.git-commit-classification.v1',branch=BRANCH,base_commit=BASE,work_item='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01',snapshot_sha256=snapshot,message_sha256=sha(msg),changed_paths=changes,reviews=[dict(path=str(commit_review),sha256=sha(commit_review),verdict='PASS')]),indent=2)+'\n',encoding='utf-8')
 helper=['py','-3','-B','.aide/scripts/aide_lite.py','git','commit-plan','--classification',str(classification),'--message-file',str(msg)]
 run('plan-stage',helper);run('stage',['git','add','--',*sorted(changed)]);run('staged-diff',['git','diff','--cached','--check']);run('plan-commit',helper)
 assert git('rev-parse','HEAD')==BASE
 run('commit',['git','commit','-F',str(msg)])
 run('range',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--range',BASE+'..HEAD'])
 remaining=git('diff','--name-only').splitlines()
 if remaining:
  assert set(remaining)<={'.aide/memory/project-state.md','.aide/memory/project-state.v2.json','README.md'}
  for name in remaining:assert git('hash-object','--path',name,str(R/name))==git('rev-parse','HEAD:'+name)
  run('refresh-generated-index',['git','add','--',*remaining])
 assert not git('status','--porcelain') and not git('diff','--cached','--name-only')
 record.update(status='COMMITTED_REVIEWED_VISIBLE_GUI_CONTROLS_CANDIDATE',source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),review_sha256=sha(commit_review),evidence_sha256=sha(evidence),actual_CI_cause_resolved=False,current_head_factory_proof_pending=True,required_checks_pending=True,remote_not_pushed=True)
except BaseException as error:record.update(status='ACTIONABLE_VISIBLE_GUI_CONTROLS_COMMIT_FAILURE',error=str(error),traceback=traceback.format_exc())
finally:save();print(json.dumps({k:v for k,v in record.items() if k not in ('commands','traceback')},indent=2))
raise SystemExit(0 if record['status']=='COMMITTED_REVIEWED_VISIBLE_GUI_CONTROLS_CANDIDATE' else 1)
