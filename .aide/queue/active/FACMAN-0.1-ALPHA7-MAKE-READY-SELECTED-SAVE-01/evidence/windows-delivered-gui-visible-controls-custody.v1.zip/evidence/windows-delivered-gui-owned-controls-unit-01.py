"""Diagnostic/selection regressions only; no simulated backend acceptance."""
import ast
import ctypes
import hashlib
import json
from pathlib import Path
import sys
from types import SimpleNamespace

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e\evidence')
sys.path[:0] = [str(R / 'tests'), str(R)]
import test_windows_delivered_joined_gui as tested

source = R / 'tests/test_windows_delivered_joined_gui.py'
ast.parse(source.read_text())
owned = tested.OwnedControls.__new__(tested.OwnedControls)
owned.require_owned = lambda hwnd: None
owned.enumerate = lambda window: [101, 102, 103]
owned.text = lambda hwnd, class_name=False: 'WindowsForms10.BUTTON' if class_name else 'Make Ready with current settings'
states = {
    101: [dict(hwnd=101, visible=False, enabled=True)],
    102: [dict(hwnd=102, visible=True, enabled=True), dict(hwnd=10, visible=True, enabled=False)],
    103: [dict(hwnd=103, visible=True, enabled=True), dict(hwnd=10, visible=True, enabled=True)],
}
owned.ancestors = lambda hwnd: states[hwnd]
owned.wait = lambda predicate, description: predicate()
assert owned.control(10, 'Make Ready with current settings') == 103
posted = []
owned.api = SimpleNamespace(PostMessageW=lambda *args: posted.append(args) or 1)
owned.process = SimpleNamespace(pid=12)
owned.events = []
owned.control_state = lambda hwnd: dict(visible=True, enabled=True)
for hwnd in [101, 102]:
    try:
        owned.click(hwnd)
    except AssertionError as failure:
        assert str(failure) == 'BM_CLICK requires visible and enabled owned control ancestors'
    else:
        raise AssertionError('Unsupported control was dispatched')
assert not posted and not owned.events
owned.click(103)
assert len(posted) == 1 and posted[0][1] == 0xF5 and owned.events[0]['post_succeeded']

editor = tested.OwnedControls.__new__(tested.OwnedControls)
editor.require_owned = lambda hwnd: None
caption_reads = []
def native_class(hwnd, buffer, length):
    buffer.value = 'WindowsForms10.EDIT.app'
    return len(buffer.value)
def stale_caption(hwnd, buffer, length):
    caption_reads.append(hwnd)
    buffer.value = 'frontend_backend_projection_failed: initial not queried caption'
    return len(buffer.value)
editor.api = SimpleNamespace(GetClassNameW=native_class, GetWindowTextW=stale_caption)
reads = []
def cleared_edit(hwnd, message, count, address):
    assert hwnd == 201 and message == 0xD and count == 16384
    reads.append(dict(hwnd=hwnd, message=message, bound=count))
    empty = ctypes.create_unicode_buffer('')
    ctypes.memmove(address, ctypes.addressof(empty), ctypes.sizeof(empty))
    return 0
editor.send = cleared_edit
assert editor.text(201) == '' and reads and not caption_reads
editor.send = lambda *args: 16383
try:
    editor.text(201)
except AssertionError as failure:
    assert str(failure) == 'Owned edit text exceeds the evidence bound'
else:
    raise AssertionError('Edit evidence bound was lost')

receipt = dict(schema='facman.windows_delivered_owned_control_regressions.v1', result='PASS',
    qualification='synthetic selection/refusal-diagnostic regressions; no backend or product acceptance claim',
    source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    checks=['Python AST', 'selection rejects hidden target',
        'selection rejects disabled ancestor', 'click guards reject before any PostMessage',
        'supported visible/enabled control queues one BM_CLICK',
        'cleared actual EDIT does not report stale constructor refusal caption',
        'owned EDIT read keeps 16K evidence bound'])
path = E / 'windows-delivered-gui-owned-controls-unit-result-01.json'
assert not path.exists()
path.write_text(json.dumps(receipt, indent=2))
print(json.dumps(receipt, indent=2))
