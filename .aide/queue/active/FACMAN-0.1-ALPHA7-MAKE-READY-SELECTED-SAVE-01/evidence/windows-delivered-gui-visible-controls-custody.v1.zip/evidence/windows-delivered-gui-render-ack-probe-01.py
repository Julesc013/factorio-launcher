import base64
from contextlib import redirect_stdout
import ctypes
from ctypes import wintypes as wt
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time
import unittest
from unittest.mock import patch
import zlib

R = Path(r'D:\Projects\Factorio\factorio-launcher')
W = Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e')
E = W / 'evidence'
consumer = W / 't/j3/cack06'
consumer.mkdir(exist_ok=False)
sys.path[:0] = [str(R / 'tests'), str(R)]
import test_windows_delivered_joined_gui as tested
import delivered_environment_reconstruction as reconstruction

def revisions_ready(main_text, deck_text):
    main = re.search(r'\(revision ([1-9][0-9]*)\)', main_text)
    deck = re.search(r'· revision ([1-9][0-9]*)', deck_text)
    return bool(main and deck and main.group(1) == deck.group(1))

actual = json.loads((E / 'windows-delivered-gui-diagnostic-failed-actual-job-115749632980/result.json').read_bytes())
partial_regressions = []
for session in actual['sessions']:
    frame, = [item for item in session['events'] if item['stage'] == 'selected-save observation completed']
    main, = [item['text'] for item in frame['controls'] if item.get('text', '').startswith('Readiness:')]
    deck, = [item['text'] for item in frame['controls'] if item.get('text', '').startswith('Readiness\r\n')]
    assert not revisions_ready(main, deck)
    partial_regressions.append(dict(gui_pid=frame['pid'], rejected=True, main=main, deck=deck))

original_controls = tested.OwnedControls
probes = []
class ProbeControls(original_controls):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._hook = None
        self._main = None
        self._selection = None
        self._announcements = []
        self._probe = dict(gui_pid=self.process.pid, announcements=self._announcements,
            selection=None, gate=None, edit_reads=[], hook_cleanup=False)
        probes.append(self._probe)
        self._winevent_type = ctypes.WINFUNCTYPE(None, wt.HANDLE, wt.DWORD, wt.HWND,
            wt.LONG, wt.LONG, wt.DWORD, wt.DWORD)
        self.api.SetWinEventHook.argtypes = [wt.DWORD, wt.DWORD, wt.HMODULE,
            self._winevent_type, wt.DWORD, wt.DWORD, wt.DWORD]
        self.api.SetWinEventHook.restype = wt.HANDLE
        self.api.UnhookWinEvent.argtypes = [wt.HANDLE]
        self.api.UnhookWinEvent.restype = wt.BOOL
        self.api.PeekMessageW.argtypes = [ctypes.POINTER(wt.MSG), wt.HWND, wt.UINT, wt.UINT, wt.UINT]
        self.api.PeekMessageW.restype = wt.BOOL
        self.api.TranslateMessage.argtypes = [ctypes.POINTER(wt.MSG)]
        self.api.DispatchMessageW.argtypes = [ctypes.POINTER(wt.MSG)]
        self.api.DispatchMessageW.restype = wt.LPARAM
        self.job.api.GetTickCount64.argtypes = []
        self.job.api.GetTickCount64.restype = ctypes.c_uint64
        @self._winevent_type
        def announced(hook, event, hwnd, object_id, child_id, thread_id, tick):
            if (event != 0x800C or hwnd != self._main or object_id != -4 or child_id != 0
                    or thread_id != self.job.launch['primary_thread_id']
                    or self.process.poll() is not None):
                return
            pid = wt.DWORD()
            if (self.api.GetWindowThreadProcessId(hwnd, ctypes.byref(pid)) != thread_id
                    or pid.value != self.process.pid):
                return
            if len(self._announcements) >= 128:
                self._probe['event_bound_exceeded'] = True
                return
            self._announcements.append(dict(sequence=len(self._announcements) + 1,
                pid=pid.value, hwnd=int(hwnd), event=event, object_id=object_id,
                child_id=child_id, thread_id=thread_id, source_tick=tick,
                delivered_at=time.monotonic()))
        self._announced = announced
        # Exact retained suspended-launch process and initial UI thread; out of
        # context, no DLL injection and no foreign/global process subscription.
        self._hook = self.api.SetWinEventHook(0x800C, 0x800C, None, announced,
            self.process.pid, self.job.launch['primary_thread_id'], 0)
        if not self._hook:
            self.finish()
            raise ctypes.WinError(ctypes.get_last_error())

    def pump(self):
        message = wt.MSG()
        for unused in range(128):
            if not self.api.PeekMessageW(ctypes.byref(message), None, 0, 0, 1):
                break
            self.api.TranslateMessage(ctypes.byref(message))
            self.api.DispatchMessageW(ctypes.byref(message))
        if self._probe.get('event_bound_exceeded'):
            raise AssertionError('Owned announcement evidence exceeded its bound')

    def select(self, hwnd, index, value):
        if value == 'Selected Save':
            self.pump()
            self._selection = dict(hwnd=hwnd, after_sequence=len(self._announcements),
                queued_after_tick=self.job.api.GetTickCount64() & 0xFFFFFFFF,
                queued_after_monotonic=time.monotonic())
            self._probe['selection'] = self._selection
        return super().select(hwnd, index, value)

    def message_text(self, hwnd):
        value = ctypes.create_unicode_buffer(16384)
        length = self.send(hwnd, 0xD, len(value), ctypes.addressof(value))  # WM_GETTEXT
        if length >= len(value) - 1:
            raise AssertionError('Owned WM_GETTEXT evidence exceeds its bound')
        return value.value

    def selected_observation(self, main):
        self._main = main
        super().selected_observation(main)
        def settled():
            self.pump()
            selection = self._selection
            announcements = [event for event in self._announcements
                if event['sequence'] > selection['after_sequence']
                and 0 < ((event['source_tick'] - selection['queued_after_tick']) & 0xFFFFFFFF) < 300000
                and event['delivered_at'] >= selection['queued_after_monotonic']]
            if not announcements:
                return None
            controls = self.enumerate(main)
            main_label = next((hwnd for hwnd in controls if self.text(hwnd).startswith('Readiness:')), None)
            deck_label = next((hwnd for hwnd in controls if self.text(hwnd).startswith('Readiness\r\n')), None)
            if not main_label or not deck_label:
                return None
            main_text, deck_text = self.message_text(main_label), self.message_text(deck_label)
            if not (revisions_ready(main_text, deck_text)
                    and self.api.IsWindowEnabled(selection['hwnd'])
                    and self.text(selection['hwnd']) == 'Selected Save'):
                return None
            return dict(announcement=announcements[-1], main=main_text, deck=deck_text,
                selected_save=True, enabled=True, acknowledged_at=time.monotonic())
        gate = self.wait(settled, 'post-selection owned final-render announcement and matching revisions')
        self._probe['gate'] = gate
        self.events.append(dict(stage='owned final-render acknowledgement', pid=self.process.pid, **gate))
        for hwnd in self.enumerate(main):
            if 'EDIT' in self.text(hwnd, True).upper():
                caption, value = self.text(hwnd), self.message_text(hwnd)
                self._probe['edit_reads'].append(dict(hwnd=hwnd, caption=caption,
                    wm_gettext=value, differ=caption != value))

    def finish(self):
        try:
            return super().finish()
        finally:
            if self._hook is not None:
                if not self.api.UnhookWinEvent(self._hook):
                    raise ctypes.WinError(ctypes.get_last_error())
                self._hook = None
                self._probe['hook_cleanup'] = True

log = E / 'windows-delivered-gui-render-ack-probe-01.log'
assert not log.exists()
result = unittest.TestResult()
with log.open('w', encoding='utf-8') as stream, redirect_stdout(stream), \
     patch.dict(os.environ, FACMAN_DELIVERED_GUI_PACKAGE=str(W / 't/j3/g'),
         FACMAN_DELIVERED_GUI_CONSUMER=str(consumer)), \
     patch.object(tested, 'OwnedControls', ProbeControls), \
     patch.object(reconstruction, 'SCENARIOS', ()):
    tested.WindowsDeliveredJoinedGuiTests(
        'test_actual_joined_controls_dispatch_production_packaged_backend').run(result)

outcome = dict(schema='facman.windows_delivered_render_ack_probe.v1',
    qualification='external bounded probe, reused original package source002; not fresh factory or full acceptance',
    source_sha256=hashlib.sha256((R / 'tests/test_windows_delivered_joined_gui.py').read_bytes()).hexdigest(),
    consumer=str(consumer), log=str(log), log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),
    tests_run=result.testsRun, failures=[item[1] for item in result.failures], errors=[item[1] for item in result.errors],
    rejected_actual_partial_frames=partial_regressions, probes=probes,
    result='PASS_GUI_ORACLE_WITH_FINAL_ACK' if result.wasSuccessful() else 'FAIL_PROBE')
path = E / 'windows-delivered-gui-render-ack-probe-result-01.json'
assert not path.exists()
path.write_text(json.dumps(outcome, indent=2))
if result.wasSuccessful():
    prefix = 'delivered-windows-gui-custody '
    custody, = [json.loads(line[len(prefix):]) for line in log.read_text().splitlines() if line.startswith(prefix)]
    compressed = base64.b64decode(custody['payload_base64'], validate=True)
    assert hashlib.sha256(compressed).hexdigest() == custody['compressed_sha256']
    canonical = zlib.decompress(compressed)
    assert hashlib.sha256(canonical).hexdigest() == custody['canonical_sha256']
    manifest = json.loads(canonical)
    for name, value in manifest.items():
        data = base64.b64decode(value['bytes_base64'], validate=True)
        assert len(data) == value['size_bytes'] and hashlib.sha256(data).hexdigest() == value['sha256']
        assert data == (consumer / 'evidence' / name).read_bytes()
    assert all(probe['gate'] and probe['hook_cleanup'] for probe in probes)
print(json.dumps(dict(result=outcome['result'], result_path=str(path),
    log_sha256=outcome['log_sha256'], failures=outcome['failures'], errors=outcome['errors'],
    gate_count=sum(probe['gate'] is not None for probe in probes),
    all_hooks_cleaned=all(probe['hook_cleanup'] for probe in probes)), indent=2))
