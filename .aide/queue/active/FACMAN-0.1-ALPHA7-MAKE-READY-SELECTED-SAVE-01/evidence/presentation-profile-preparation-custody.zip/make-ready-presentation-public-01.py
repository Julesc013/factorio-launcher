"""Run affected public cases once; retain real command envelopes off model."""
import hashlib
import json
import os
from pathlib import Path
import sys
import threading
import unittest

R=Path(r'D:\Projects\Factorio\factorio-launcher')
E=Path(__file__).resolve().parent
sys.path[:0]=[str(R/'tests'),str(R)]
import native_cli
original=native_cli.invoke_machine
commands=E/'make-ready-presentation-public-01-commands.jsonl'
lock=threading.Lock()
count=0

def observed(args,env=None):
    global count
    result=original(args,env)
    with lock:
        count+=1
        with commands.open('a',encoding='utf-8') as f:
            f.write(json.dumps(dict(sequence=count,argv=args,exit_code=result[0],stdout=result[1],stderr=result[2]))+'\n')
    return result

assert not commands.exists()
native_cli.invoke_machine=observed
suite=unittest.defaultTestLoader.loadTestsFromNames([
    'test_presentation_profile_preparation','test_presentation_service','test_profiles_templates'])
result=unittest.TextTestRunner(verbosity=2).run(suite)
receipt=dict(status='PASS_AFFECTED_PUBLIC_SUITE' if result.wasSuccessful() and not result.skipped else 'stopped_for_actionable_failure',
    tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skips=len(result.skipped),
    observed_public_commands=count,commands_sha256=hashlib.sha256(commands.read_bytes()).hexdigest(),
    cli_sha256=hashlib.sha256(Path(os.environ['FACMAN_CLI_EXE']).read_bytes()).hexdigest(),whole_workunit_closed=False)
with (E/'make-ready-presentation-public-01.json').open('x',encoding='utf-8') as f: json.dump(receipt,f,indent=2)
print(json.dumps(receipt))
sys.exit(0 if receipt['status']=='PASS_AFFECTED_PUBLIC_SUITE' else 1)
