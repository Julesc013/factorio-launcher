"""One reviewed owned native build, independent/public observation, no candidates."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

R=Path(r'D:\Projects\Factorio\factorio-launcher')
E=Path(__file__).resolve().parent
BUILD=E.parent/'native-developer'
CLI=BUILD/'Debug/facman.exe'
PREFIX='make-ready-presentation-source-proof-01'
RECEIPT=E/(PREFIX+'.json')
sys.path.insert(0,str(R))
from tools import development_layout

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8') as f: json.dump(v,f,indent=2)
def update():
    p=RECEIPT.with_suffix('.writing')
    write(p,record)
    p.replace(RECEIPT)
def out(*args):
    p=subprocess.run(args,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
    assert p.returncode==0,(args,p.returncode,p.stderr[:500])
    return p.stdout.strip()
def check(name,args,timeout=600):
    log=E/(PREFIX+'-'+name+'.log')
    with log.open('x',encoding='utf-8') as f:
        p=subprocess.run(args,cwd=R,env=os.environ.copy(),stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
    record['checks'].append(dict(check=name,argv=args,exit_code=p.returncode,log=str(log),sha256=sha(log)))
    update()
    assert p.returncode==0,(name,p.returncode,str(log))
    return log.read_text(encoding='utf-8',errors='replace')

assert __debug__ and os.environ.get('PYTHONOPTIMIZE')=='0' and not RECEIPT.exists()
assert out('git','branch','--show-current')=='task/facman-world-restore-retention-01'
assert out('git','rev-parse','HEAD')=='1c8638bb0d7cc484963c4324fe6e564a0748b468'
marker=development_layout.read_marker(E.parent,R)
assert marker['task_id']=='task/facman-world-restore-retention-01'
preflight_path=E/'make-ready-presentation-preflight-02.json'
preflight=json.loads(preflight_path.read_text(encoding='utf-8'))
assert preflight['status']=='PASS_SOURCE_PREFLIGHT' and len(preflight['checks'])==8
for item in preflight['checks']: assert item['exit_code']==0 and sha(Path(item['log']))==item['sha256']
source_hashes=preflight['source_hashes']
for path,digest in source_hashes.items(): assert sha(R/path)==digest,path
review_path=E/'make-ready-presentation-source-review-01.json'
assert sha(review_path)=='8816a95f0aa0bf2970778152b10e2069a913a0bcca6e4862bc82a5b4ae6dbf76'
review=json.loads(review_path.read_text(encoding='utf-8'))
assert review['verdict']=='PASS_STATIC_SOURCE' and review['independent'] and review['non_authoring']
for path,digest in review['source_hashes'].items(): assert sha(R/path)==digest,path
write(E/(PREFIX+'.claim.json'),dict(pid=os.getpid(),source_hashes=source_hashes,no_automatic_replay=True,script_sha256=sha(Path(__file__))))
record=dict(status='running_scoped_presentation_preparation_proof',base=out('git','rev-parse','HEAD'),
    source_hashes=source_hashes,source_review_sha256=sha(review_path),source_preflight_sha256=sha(preflight_path),
    native_builds=0,new_roots=0,new_worktrees=0,candidate_dispatches=0,CI_reruns=0,model_wait_calls=0,checks=[])
update()
os.environ.update(CMAKE_BUILD_PARALLEL_LEVEL='2',MSBUILDDISABLENODEREUSE='1',PYTHONDONTWRITEBYTECODE='1',
    PYTHONOPTIMIZE='0',PYTHONUTF8='1',FACMAN_CLI_EXE=str(CLI),PYTHONPATH=os.pathsep.join([str(R/'tests'),str(R)]))
temp=E/'make-ready-presentation-01-temp'
try:
    assert temp.is_dir() and not list(temp.iterdir())
    heavy=out('powershell','-NoProfile','-Command',"@(Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('MSBuild.exe','cl.exe','ninja.exe','cmake.exe') } | Select-Object ProcessId,Name) | ConvertTo-Json -Compress")
    assert heavy in {'','[]'},'Existing heavy local job must finish first'
    memory=int(out('powershell','-NoProfile','-Command','(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory'))*1024
    assert memory>=4*1024**3
    for name,extra in [('paths',[]),('doctor',['--measure'])]:
        p=subprocess.run([sys.executable,'-B','tools/workspace_hygiene.py',name,*extra],cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
        d=json.loads(p.stdout); write(E/(PREFIX+'-'+name+'.json'),d)
        if name=='doctor':
            assert p.returncode in {0,1} and set(d['violations']) <= {'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
            assert len(d['task_roots'])<=8 and d['task_root_bytes']+2*1024**3+64*1024**2<=20*1024**3
        else: assert p.returncode==0
    assert shutil.disk_usage(E).free>=8*1024**3+2*1024**3+64*1024**2
    assert sha(CLI)=='cf91509fa9a649cd717eba2b2449907b45450f80664131b04ce52d4f3bd3bebc'
    archive=E/'native-profile-preparation-qualified-images.zip'
    images=sorted(p for p in (BUILD/'Debug').iterdir() if p.is_file() and p.suffix.lower() in {'.exe','.dll'})
    assert CLI in images and sum(p.stat().st_size for p in images)<=64*1024**2
    members={p.name:sha(p) for p in images}
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for p in images: z.write(p,p.name)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and set(z.namelist())==set(members)
        for name,digest in members.items(): assert hashlib.sha256(z.read(name)).hexdigest()==digest
    record['preserved_qualified_images']=dict(path=str(archive),sha256=sha(archive),members=members,producer_commit='7f290d6236c40cbb147f52f7c7dafcf73115ab71')
    record['resource_peak_bytes']=2*1024**3+64*1024**2
    os.environ['TMP']=os.environ['TEMP']=str(temp)
    record['native_builds']=1; update()
    check('build',[sys.executable,'-B','tools/dev.py','build','developer','--task-root',str(E.parent),
        '--build-root',str(BUILD),'--configuration','Debug','--target','facman_cli','--target','facman_presentation_service_smoke'],1800)
    record['CLI_sha256']=sha(CLI)
    check('native-presentation',['ctest','--test-dir',str(BUILD),'-C','Debug','-R','^facman_presentation_service_smoke$',
        '--output-on-failure','--no-tests=error'],180)
    check('public-presentation-and-profiles',[sys.executable,'-B',str(E/'make-ready-presentation-public-01.py')],600)
    public=json.loads((E/'make-ready-presentation-public-01.json').read_text(encoding='utf-8'))
    assert public['status']=='PASS_AFFECTED_PUBLIC_SUITE' and public['cli_sha256']==sha(CLI)
    assert not list(temp.iterdir())
    for path,digest in source_hashes.items(): assert sha(R/path)==digest,path
    renewed=development_layout.read_marker(E.parent,R)
    assert all(renewed[k]==marker[k] for k in marker if k!='last_used_at')
    record.update(status='PASS_SCOPED_WINDOWS_PRESENTATION_PREPARATION',public_suite=public,native_presentation_tests=1,
        stale_revision_scopes=['instances','content'],observed_plan_to_owner_boundary_refused=True,
        failed_profile_preserves_usable_siblings=True,late_owner_recovery_and_replay=True,temp_parent_empty=True,
        actual_Factorio=False,produced_package=False,whole_workunit_closed=False,full_programme_complete=False)
except BaseException as exc:
    record.update(status='stopped_for_actionable_failure',error=repr(exc),whole_workunit_closed=False)
finally:
    record['finished_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat(); update()
print(json.dumps({k:v for k,v in record.items() if k not in {'source_hashes','checks','preserved_qualified_images'}}))
if record['status']=='stopped_for_actionable_failure':
    if record['checks'] and record['checks'][-1]['exit_code']:
        print(Path(record['checks'][-1]['log']).read_text(encoding='utf-8',errors='replace')[-3500:])
    sys.exit(1)
