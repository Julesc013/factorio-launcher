"""Source checks once, retaining full off-model logs and actionable failures."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

R=Path(r'D:\Projects\Factorio\factorio-launcher')
E=Path(__file__).resolve().parent
PREFIX='make-ready-presentation-preflight-02'
checks=[]
commands=[('format',['tools/source_format_check.py']),
          ('metadata',['-m','tools.codegen.generate_metadata','--check']),
          ('contracts',['tools/command_contract_check.py']),
          ('strict',['tools/strict_check.py']),
          ('state-check',['tools/project_state.py','--validate']),
          ('plan-check',['tools/generate_plan_views.py','--check']),
          ('portable',['.aide/scripts/aide_lite.py','test'])]
for name,args in commands+[('diff',None)]:
    log=E/(PREFIX+'-'+name+'.log')
    argv=[sys.executable,'-B',*args] if args else ['git','diff','--check']
    with log.open('x',encoding='utf-8') as f:
        p=subprocess.run(argv,cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=600)
    checks.append(dict(check=name,argv=argv,exit_code=p.returncode,log=str(log),sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
    if p.returncode: break
paths=set(subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines())
paths.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R,text=True).splitlines())
result=dict(status='PASS_SOURCE_PREFLIGHT' if all(c['exit_code']==0 for c in checks) and len(checks)==8 else 'stopped_for_actionable_failure',checks=checks,
    source_hashes={p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in sorted(paths)},native_builds=0,candidate_dispatches=0,whole_workunit_closed=False)
with (E/(PREFIX+'.json')).open('x',encoding='utf-8') as f: json.dump(result,f,indent=2)
print(json.dumps(dict(status=result['status'],checks=len(checks),failure=next((c for c in checks if c['exit_code']),None))))
if result['status']!='PASS_SOURCE_PREFLIGHT':
    print(Path(checks[-1]['log']).read_text(encoding='utf-8',errors='replace')[-2500:])
    sys.exit(1)
