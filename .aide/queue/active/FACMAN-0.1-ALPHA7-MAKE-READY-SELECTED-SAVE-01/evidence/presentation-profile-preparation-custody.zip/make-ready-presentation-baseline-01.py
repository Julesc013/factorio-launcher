"""One real baseline regression against the retained qualified CLI, no build."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
exe = E.parent/'native-developer/Debug/facman.exe'
assert hashlib.sha256(exe.read_bytes()).hexdigest() == 'cf91509fa9a649cd717eba2b2449907b45450f80664131b04ce52d4f3bd3bebc'
temp = E/'make-ready-presentation-01-temp'
temp.mkdir(exist_ok=False)
env = os.environ.copy()
env.update(FACMAN_CLI_EXE=str(exe), PYTHONPATH=str(R/'tests')+';'+str(R),
           TMP=str(temp), TEMP=str(temp), PYTHONOPTIMIZE='0', PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1')
test = 'test_presentation_profile_preparation.PresentationProfilePreparationTests.test_replaced_unselected_profile_invalidates_both_ordinary_scopes'
log = E/'make-ready-presentation-baseline-01.log'
with log.open('x',encoding='utf-8') as f:
    p = subprocess.run([sys.executable,'-B','-m','unittest',test],cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=90)
text = log.read_text(encoding='utf-8')
assert p.returncode == 1 and text.count('AssertionError:') == 2 and 'unexpectedly equal' in text
assert not list(temp.iterdir())
receipt = dict(status='baseline_gap_demonstrated', test=test, failures=2, scopes=['instances','content'],
               retained_cli_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(), producer_commit='7f290d6236c40cbb147f52f7c7dafcf73115ab71',
               exact_current_native_build=False, log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),
               builds=0,candidate_dispatches=0,whole_workunit_closed=False)
with (E/'make-ready-presentation-baseline-01.json').open('x',encoding='utf-8') as f: json.dump(receipt,f,indent=2)
print(json.dumps(receipt))
