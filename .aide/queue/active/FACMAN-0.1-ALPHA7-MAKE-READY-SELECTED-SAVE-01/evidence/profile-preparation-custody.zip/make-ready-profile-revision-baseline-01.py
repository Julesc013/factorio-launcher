import datetime,hashlib,json,os,subprocess,sys,tempfile
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher')
E=Path(__file__).resolve().parent
CLI=E.parent/'native-developer/Debug/facman.exe'
OUT=E/'make-ready-profile-revision-baseline-01.json'
LOG=E/'make-ready-profile-revision-baseline-01-commands.jsonl'
sys.path.insert(0,str(R/'tests'));sys.path.insert(0,str(R))
from native_cli import invoke
assert __debug__ and not OUT.exists() and not LOG.exists()
assert hashlib.sha256(CLI.read_bytes()).hexdigest()=='737c32d9f9008748583f50cd752a1305e8f72a89baf5fb9a42fd18e95f578488'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()=='e01a0d2bbf372dc030c8c2fe9565342cdb6f4891'
blob=subprocess.check_output(['git','rev-parse','HEAD:runtime/factorio/profiles'],cwd=R).decode().strip()
assert subprocess.check_output(['git','rev-parse','46bb38f895d6a72f410c5948faa84718e6f3baf5:runtime/factorio/profiles'],cwd=R).decode().strip()==blob
os.environ.update(FACMAN_CLI_EXE=str(CLI),PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='0')
temp=E/'make-ready-profile-revision-baseline-01-temp';temp.mkdir();os.environ['TEMP']=os.environ['TMP']=str(temp)
count=0
with LOG.open('x',encoding='utf-8',newline='\n') as log:
    def cmd(w,*args):
        global count
        argv=['--workspace',str(w),*args,'--json'];code,text,error=invoke(argv)
        value=json.loads(text or error)
        log.write(json.dumps(dict(argv=argv,exit_code=code,stdout=value,stderr=error))+'\n');log.flush()
        count+=1
        assert code==0,(args,code,value)
        return value
    findings=[]
    for changed in ('profile_definition','existing_instance_overrides'):
        with tempfile.TemporaryDirectory(prefix='profile owner baseline ',dir=temp) as td:
            w=Path(td)
            cmd(w,'installs','import',str(R/'tests/fixtures/fake_factorio_install'),'--id','fixture')
            cmd(w,'instances','create','Main','--id','main','--install','fixture')
            cmd(w,'profiles','create','quiet','--audio','disabled')
            if changed=='existing_instance_overrides':cmd(w,'profiles','apply','main','gui','--audio','disabled')
            planned=cmd(w,'profiles','plan','main','quiet')
            if changed=='profile_definition':
                cmd(w,'profiles','archive','quiet')
                cmd(w,'profiles','create','quiet','--selection-mode','load-save','--selection','selected.zip')
            else:cmd(w,'profiles','apply','main','gui','--audio','enabled')
            manifest=(w/'instances/main/instance.v1.json').read_bytes()
            assert hashlib.sha256(manifest).hexdigest()==planned['source_manifest_sha256']
            before={p.relative_to(w).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in w.rglob('*') if p.is_file()}
            applied=cmd(w,'profiles','apply','main','quiet','--expected-revision',planned['source_manifest_sha256'])
            after={p.relative_to(w).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in w.rglob('*') if p.is_file()}
            assert applied['mutation_executed'] and before!=after
            if changed=='profile_definition':assert planned['settings']['selection_mode']=='none' and applied['settings']['selection_mode']=='load-save'
            findings.append(dict(changed_owner_input=changed,instance_manifest_revision_unchanged=True,legacy_expected_revision_check_accepted=True,mutation_executed=True,planned_settings=planned['settings'],applied_settings=applied['settings'],reviewed_owner_plan_cannot_be_bound=True))
assert not any(temp.iterdir())
record=dict(status='DEMONSTRATED_REVIEWED_PROFILE_PREPARATION_INPUT_GAP',base='e01a0d2bbf372dc030c8c2fe9565342cdb6f4891',native_producer_source='46bb38f895d6a72f410c5948faa84718e6f3baf5',profile_source_tree_oid=blob,CLI_sha256=hashlib.sha256(CLI.read_bytes()).hexdigest(),cases=findings,commands=count,command_log=str(LOG),command_log_sha256=hashlib.sha256(LOG.read_bytes()).hexdigest(),legacy_flag_semantics='--expected-revision checks only the instance manifest; preserve that documented compatibility meaning',next_missing_behavior='Add an explicit owner preparation-plan identity and expected-plan refusal for changed profile, existing overrides and desired settings; reuse original domain transaction and recovery',temp_parent_empty=True,new_roots=0,native_builds=0,candidate_dispatches=0,whole_workunit_closed=False,finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
with OUT.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(status=record['status'],cases=len(findings),commands=count,temp_parent_empty=True)))
