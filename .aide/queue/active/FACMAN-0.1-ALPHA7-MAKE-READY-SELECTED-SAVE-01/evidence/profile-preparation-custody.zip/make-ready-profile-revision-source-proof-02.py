"""One owned build, exact source binding and public profile preparation proof."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
BUILD = E.parent/'native-developer'
CLI = BUILD/'Debug/facman.exe'
PREFIX = 'make-ready-profile-revision-source-proof-02'
RECEIPT = E/(PREFIX+'.json')
CLAIM = E/(PREFIX+'.claim.json')
BRANCH = 'task/facman-world-restore-retention-01'
BASE = 'e01a0d2bbf372dc030c8c2fe9565342cdb6f4891'
sys.path.insert(0,str(R))
from tools import development_layout


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def out(*args):
    c = subprocess.run(args,cwd=R,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=120)
    assert c.returncode == 0,(args[:4],c.returncode,c.stderr[:600])
    return c.stdout.strip()


def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f: f.write(json.dumps(v,indent=2)+'\n')


def update():
    temporary = RECEIPT.with_suffix('.json.writing')
    write(temporary,record)
    temporary.replace(RECEIPT)


def check(name,args,timeout=600):
    p = E/(PREFIX+'-'+name+'.log')
    with p.open('x',encoding='utf-8') as f:
        c = subprocess.run(args,cwd=R,env=os.environ.copy(),stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
    item = dict(check=name,exit_code=c.returncode,log=str(p),sha256=sha(p))
    record['checks'].append(item)
    update()
    assert c.returncode == 0,(name,c.returncode,str(p))
    return p.read_text(encoding='utf-8',errors='replace')


assert __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0'
assert not RECEIPT.exists() and not CLAIM.exists()
assert out('git','branch','--show-current') == BRANCH and out('git','rev-parse','HEAD') == BASE
marker = development_layout.read_marker(E.parent,R)
assert marker['task_id'] == BRANCH
baseline = json.loads((E/'make-ready-profile-revision-baseline-01.json').read_text(encoding='utf-8'))
assert baseline['status'] == 'DEMONSTRATED_REVIEWED_PROFILE_PREPARATION_INPUT_GAP'
assert baseline['base'] == BASE and sha(CLI) == baseline['CLI_sha256']
paths = out('git','diff','--name-only').splitlines()
assert paths and all((R/p).is_file() for p in paths)
source_hashes = {p:sha(R/p) for p in paths}
write(CLAIM,dict(PID=os.getpid(),script_sha256=sha(Path(__file__)),source_hashes=source_hashes,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),no_automatic_replay=True))
record = dict(status='RUNNING_SCOPED_PROFILE_PREPARATION_PROOF',base=BASE,branch=BRANCH,
    source_hashes=source_hashes,baseline_receipt_sha256=sha(E/'make-ready-profile-revision-baseline-01.json'),
    previous_preflight_failure_sha256=sha(E/'make-ready-profile-revision-preflight-01.json'),
    native_builds=0,new_roots=0,new_worktrees=0,candidate_dispatches=0,CI_reruns=0,model_wait_calls=0,checks=[])
update()
os.environ.update(CMAKE_BUILD_PARALLEL_LEVEL='2',MSBUILDDISABLENODEREUSE='1',PYTHONDONTWRITEBYTECODE='1',
    PYTHONOPTIMIZE='0',PYTHONUTF8='1',FACMAN_CLI_EXE=str(CLI),PYTHONPATH=os.pathsep.join([str(R/'tests'),str(R)]))
temp = E/'make-ready-profile-revision-01-temp'
try:
    previous = json.loads((E/'make-ready-profile-revision-source-proof-01.json').read_text(encoding='utf-8'))
    assert previous['status'] == 'stopped_for_actionable_failure' and previous['native_builds'] == 0
    assert previous['error'] == "KeyError('status')"
    assert previous['source_hashes'] == source_hashes
    assert [c['check'] for c in previous['checks']] == ['format','metadata','contracts','strict','state-check','plan-check','portable','diff']
    assert all(c['exit_code'] == 0 and sha(Path(c['log'])) == c['sha256'] for c in previous['checks'])
    record['reused_exact_source_preflight'] = previous['checks']
    record['prior_runner_failure_sha256'] = sha(E/'make-ready-profile-revision-source-proof-01.json')
    for p,digest in source_hashes.items(): assert sha(R/p) == digest,p
    late_review = json.loads((E/'make-ready-profile-revision-late-source-review-01.json').read_text(encoding='utf-8'))
    assert late_review['verdict'].startswith('PASS'),late_review['verdict']
    record['late_source_review_sha256'] = sha(E/'make-ready-profile-revision-late-source-review-01.json')
    heavy = out('powershell','-NoProfile','-Command',"@(Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('MSBuild.exe','cl.exe','ninja.exe','cmake.exe') } | Select-Object ProcessId,Name) | ConvertTo-Json -Compress")
    assert heavy in {'','[]'},'An existing heavy job must finish first'
    memory = int(out('powershell','-NoProfile','-Command','(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory'))*1024
    assert memory >= 4*1024**3
    for name,extra in [('paths',[]),('doctor',['--measure'])]:
        c = subprocess.run([sys.executable,'-B','tools/workspace_hygiene.py',name,*extra],cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
        d = json.loads(c.stdout); write(E/(PREFIX+'-'+name+'.json'),d)
        if name == 'doctor':
            assert c.returncode in {0,1} and set(d['violations']) <= {'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
            assert len(d['task_roots']) <= 8 and d['task_root_bytes']+2*1024**3+64*1024**2 <= 20*1024**3
        else: assert c.returncode == 0
    assert shutil.disk_usage(E).free >= 8*1024**3+2*1024**3+64*1024**2
    archive = E/'native-menu-intent-qualified-images.zip'
    images = sorted(p for p in (BUILD/'Debug').iterdir() if p.is_file() and p.suffix.lower() in {'.exe','.dll'})
    assert sum(p.stat().st_size for p in images) <= 64*1024**2 and CLI in images
    digests = {p.name:sha(p) for p in images}
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for p in images: z.write(p,p.name)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and set(z.namelist()) == set(digests)
        for name,digest in digests.items(): assert hashlib.sha256(z.read(name)).hexdigest() == digest
    record['old_qualified_native_images'] = dict(path=str(archive),sha256=sha(archive),members=digests)
    record['resource_peak_bytes'] = 2*1024**3+64*1024**2
    record['available_memory_bytes'] = memory
    temp.mkdir()
    os.environ['TMP'] = os.environ['TEMP'] = str(temp)
    record['native_builds'] = 1; update()
    check('build',[sys.executable,'-B','tools/dev.py','build','developer','--task-root',str(E.parent),
        '--build-root',str(BUILD),'--configuration','Debug','--target','facman_cli','--target','flb_factorio_instance_model_smoke'],1800)
    for p,digest in source_hashes.items(): assert sha(R/p) == digest,p
    record['CLI_sha256'] = sha(CLI)
    native = check('native-model',['ctest','--test-dir',str(BUILD),'-C','Debug','-R','^flb_factorio_instance_model_smoke$',
        '--output-on-failure','--no-tests=error'],180)
    assert '0 tests failed out of 1' in native
    public = check('profiles-and-query',[sys.executable,'-B','-m','unittest','-v','tests.test_profiles_templates',
        'tests.test_cli.CliTests.test_instance_projection_is_deterministic_intent_specific_and_read_only'],600)
    assert '\nOK\n' in public and 'skipped=' not in public
    record['public_suite_tests'] = int(re.search(r'Ran (\d+) tests?',public).group(1))
    assert record['public_suite_tests'] == 15
    assert not any(temp.iterdir())
    for p,digest in source_hashes.items(): assert sha(R/p) == digest,p
    renewed = development_layout.read_marker(E.parent,R)
    assert all(renewed[k] == marker[k] for k in marker if k != 'last_used_at')
    record.update(status='PASS_SCOPED_WINDOWS_PROFILE_PREPARATION',early_stale_input_cases=3,
        override_absence_distinct=True,late_profile_change_refused=True,explicit_recovery_preserves_changed_profile=True,
        temp_parent_empty=True,actual_Factorio=False,produced_package=False,whole_workunit_closed=False,full_programme_complete=False)
except BaseException as exc:
    record.update(status='stopped_for_actionable_failure',error=repr(exc),
        next_action='Inspect retained failure; do not replay successful build or completed proof')
record['finished_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
update()
print(json.dumps({k:record.get(k) for k in ['status','native_builds','public_suite_tests','CLI_sha256','error','finished_at_utc']}))
