"""Run the corrected component first; retain failing synthetic workspaces."""
from pathlib import Path
import hashlib, importlib, json, os, sys, tempfile, unittest
E=Path(__file__).resolve().parent;R=Path(r'D:\Projects\Factorio\factorio-launcher');W=E.parent
group=sys.argv[1];assert __debug__ and group in {'new','regression'}
freeze=json.loads((E/'existing-configuration-source-freeze-04.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(Path(__file__).resolve())==freeze['focused_runner_sha256']
assert {p:sha(R/p) for p in freeze['changed_paths_raw_sha256']}==freeze['changed_paths_raw_sha256']
sys.path[:0]=[str(R/'tests'),str(R)]
tempfile.tempdir=str(W/'t')
OUT=E/('existing-configuration-q04-focused-'+group+'-receipt.json');assert not OUT.exists()
record=dict(group=group,status='RUNNING',failed_workspaces=[],source_freeze_sha256=sha(E/'existing-configuration-source-freeze-04.json'))
original=tempfile.TemporaryDirectory
class OwnedTemporaryDirectory(original):
    def __init__(self,*args,**kwargs):
        kwargs['delete']=False;super().__init__(*args,**kwargs)
        assert Path(self.name).resolve().is_relative_to((W/'t').resolve())
    def __exit__(self,kind,error,traceback):
        if kind is None:self.cleanup()
        else:record['failed_workspaces'].append(dict(path=self.name,error=repr(error)))
        return False
tempfile.TemporaryDirectory=OwnedTemporaryDirectory
names=['test_configuration_reconciliation'] if group=='new' else [
    'test_configuration_preparation','test_selected_save_preparation','test_readiness_builtin_content',
    'test_save_index_retention','test_presentation_service','test_presentation_profile_preparation','test_presentation_intent',
    'test_local_modset_solver.LocalModsetSolverTests.test_applied_selection_exports_exact_lock_and_only_selected_archives']
expected=10 if group=='new' else 59
suite=unittest.defaultTestLoader.loadTestsFromNames(names)
assert suite.countTestCases()==expected
result=unittest.TextTestRunner(verbosity=2).run(suite)
record.update(status='PASS' if result.wasSuccessful() and not result.skipped else 'FAIL',
    tests_run=result.testsRun,skipped=len(result.skipped),failures=len(result.failures),errors=len(result.errors))
with OUT.open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
assert result.testsRun==expected
raise SystemExit(0 if record['status']=='PASS' else 1)
