"""Prepare one test-only corrective campaign retaining the exact q03 build."""
from pathlib import Path
import ast, datetime, hashlib, json, os, subprocess
E=Path(__file__).resolve().parent; R=Path(r'D:\Projects\Factorio\factorio-launcher')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=dict(os.environ,FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',FACMAN_TASK_ROOT=str(E.parent),
    TEMP=str(E.parent/'t'),TMP=str(E.parent/'t'),PYTHONOPTIMIZE='0')
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(name,value):
    with (E/name).open('x',encoding='utf-8',newline='\n') as f:
        if isinstance(value,str):f.write(value)
        else:json.dump(value,f,indent=2);f.write('\n')
def git(*a):return subprocess.check_output(['git','-c','core.quotePath=false',*a],cwd=R,env=env,text=True).rstrip('\r\n')
def replace_once(s,old,new):
    assert s.count(old)==1,(old,s.count(old));return s.replace(old,new)
prior=read(E/'existing-configuration-source-freeze-03.json')
failure=read(E/'existing-configuration-qualification-03.json')
assert failure['status']=='ACTIONABLE_FAILURE'
assert failure['active_step']=='focused-new'
assert read(E/'existing-configuration-controller-05.json')['steps']==[]
assert read(E/'produced-existing-configuration-controller-02.json')['steps']==[]
assert git('rev-parse','HEAD')==prior['base'] and git('branch','--show-current')==prior['branch']
assert not git('diff','--cached','--name-only')
inventory={s[3:]:sha(R/s[3:]) for s in git('status','--porcelain','--untracked-files=all').splitlines()}
assert set(inventory)==set(prior['changed_paths_raw_sha256'])
changed=[p for p in inventory if inventory[p]!=prior['changed_paths_raw_sha256'][p]]
assert set(changed)=={'tests/test_configuration_reconciliation.py',
    '.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01/ExecPlan.md'}
for name in ('configure','build','native'):
    item=next(i for i in failure['steps'] if i['name']==name)
    assert item['exit_code']==0 and sha(Path(item['log']))==item['log_sha256']
for item in failure['binaries'].values():assert sha(Path(item['path']))==item['sha256']
record=dict(status='running',steps=[],base=prior['base'],branch=prior['branch'],
    failed_qualification_sha256=sha(E/'existing-configuration-qualification-03.json'),
    unchanged_native_source=True,new_builds=0,new_roots=0,new_candidates=0)
for name,args in [('metadata',['py','-3','tools/codegen/generate_metadata.py','--check']),
    ('contracts',['py','-3','tools/codegen/generate_contracts.py','--check']),
    ('project-state',['py','-3','tools/project_state.py','--validate']),
    ('strict',['py','-3','tools/strict_check.py']),('diff',['git','diff','--check'])]:
    log=E/('existing-configuration-preflight05-'+name+'.log')
    print('START '+name,flush=True)
    with log.open('xb') as stream:
        result=subprocess.run(args,cwd=R,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=900)
    record['steps'].append(dict(name=name,exit_code=result.returncode,log=str(log),log_sha256=sha(log)))
    assert result.returncode==0,(name,result.returncode,str(log))
ast.parse((R/'tests/test_configuration_reconciliation.py').read_text())
record.update(status='existing_configuration_source_preflight_pass_requires_frozen_review_and_native_qualification',
    changed_paths_raw_sha256=inventory,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
write('existing-configuration-source-preflight-05.json',record)
focused=(E/'run-existing-configuration-focused-03.py').read_text().replace('source-freeze-03.json','source-freeze-04.json').replace('q03-focused','q04-focused')
write('run-existing-configuration-focused-04.py',focused)
runner=(E/'qualify-existing-configuration-03.py').read_text().replace('source-freeze-03.json','source-freeze-04.json').replace('frozen-source-review-03.json','frozen-source-review-04.json').replace('qualification-03','qualification-04').replace('q03-','q04-').replace('source-preflight-04.json','source-preflight-05.json').replace('focused-03.py','focused-04.py')
start=runner.index("    step('configure',")
end=runner.index("    focused_runner =",start)
replacement="""    retained_path=E/'existing-configuration-qualification-03.json'
    assert sha(retained_path)==freeze['retained_native_qualification_sha256']
    retained=json.loads(retained_path.read_text()); assert retained['status']=='ACTIONABLE_FAILURE'
    prior_freeze=E/'existing-configuration-source-freeze-03.json'
    assert sha(prior_freeze)==freeze['prior_freeze_sha256']
    previous=json.loads(prior_freeze.read_text())
    for path,digest in previous['changed_paths_raw_sha256'].items():
        if path not in freeze['changes_from_prior_freeze']:assert sha(R/path)==digest,path
    assert set(freeze['changes_from_prior_freeze'])=={'tests/test_configuration_reconciliation.py',
        '.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01/ExecPlan.md'}
    record['retained_native_steps']=[]
    for name in ('configure','build','native'):
        item=next(i for i in retained['steps'] if i['name']==name)
        assert item['exit_code']==0 and sha(Path(item['log']))==item['log_sha256']
        record['retained_native_steps'].append(item)
    native=Path(record['retained_native_steps'][-1]['log']).read_text()
    assert '100% tests passed, 0 tests failed out of 4' in native and 'Skipped' not in native
    for item in retained['binaries'].values():assert sha(Path(item['path']))==item['sha256']
    record.update(binaries=retained['binaries'],retained_native_qualification_sha256=sha(retained_path),
        new_builds=0,native_evidence_reused=True);save()
    exe=Path(retained['binaries']['facman.exe']['path'])
    env.update(FACMAN_CLI_EXE=str(exe),FACMAN_NATIVE_CLI=str(exe))
"""
runner=runner[:start]+replacement+runner[end:]
write('qualify-existing-configuration-04.py',runner)
freeze=dict(prior,created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    changed_paths_raw_sha256=inventory,source_preflight_sha256=sha(E/'existing-configuration-source-preflight-05.json'),
    qualification_runner_sha256=sha(E/'qualify-existing-configuration-04.py'),
    focused_runner_sha256=sha(E/'run-existing-configuration-focused-04.py'),
    prior_freeze_sha256=sha(E/'existing-configuration-source-freeze-03.json'),
    retained_native_qualification_sha256=sha(E/'existing-configuration-qualification-03.json'),
    changes_from_prior_freeze=changed,
    source_correction='Test/documentation only: actual source_identities fixture and exact strategy refusal contract; strengthened preservation oracles',
    runner_only_correction='Reuse hash-bound unchanged native q03 build and four smoke results; run corrected focused10 then59 and historical3; no build or candidate')
write('existing-configuration-source-freeze-04.json',freeze)
observer=(E/'run-existing-configuration-qualification-once-03.py').read_text()
observer=observer.replace('source-freeze-03.json','source-freeze-04.json').replace('frozen-source-review-03.json','frozen-source-review-04.json').replace('qualify-existing-configuration-03.py','qualify-existing-configuration-04.py').replace('qualification-controller-03','qualification-controller-04').replace('qualification-03.json','qualification-04.json')
observer=replace_once(observer,"assert sha(F) == '72d5c378bf0828027f091f0b5def436313a9a431f248f10eac67f4dc802f2eef'",'assert sha(F) == '+repr(sha(E/'existing-configuration-source-freeze-04.json')))
observer=replace_once(observer,"assert sha(RUNNER) == '7596c3ba65692695caf62bbf0fc89f1fa115378c0664a3f9b105e89c54857d3a'",'assert sha(RUNNER) == '+repr(sha(E/'qualify-existing-configuration-04.py')))
write('run-existing-configuration-qualification-once-04.py',observer)
for name in ('qualify-existing-configuration-04.py','run-existing-configuration-focused-04.py','run-existing-configuration-qualification-once-04.py'):ast.parse((E/name).read_text())
print(json.dumps(dict(status='prepared_requires_independent_review',changed=changed,
    freeze_sha256=sha(E/'existing-configuration-source-freeze-04.json'),runner_sha256=sha(E/'qualify-existing-configuration-04.py'),
    focused_runner_sha256=sha(E/'run-existing-configuration-focused-04.py'))),flush=True)
