"""One frozen existing-INI owner campaign in the already owned native cache."""
from pathlib import Path
import hashlib, json, os, re, shutil, subprocess, sys, time, traceback
R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
W, B = E.parent, E.parent / 'native-developer'
F = E / 'existing-configuration-source-freeze-04.json'
V = E / 'existing-configuration-frozen-source-review-04.json'
OUT = E / 'existing-configuration-qualification-04.json'
env = dict(os.environ, FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds', FACMAN_TASK_ROOT=str(W),
    TEMP=str(W / 't'), TMP=str(W / 't'), CMAKE_BUILD_PARALLEL_LEVEL='2', FACMAN_MIN_FREE_GIB='10',
    PYTHONOPTIMIZE='0', PYTHONPATH=os.pathsep.join([str(R / 'tests'), str(R)]))
os.environ.update(env)
sys.path.insert(0, str(R))
from tools import native_build, provider_workspace
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
freeze = json.loads(F.read_text())
record = dict(status='running', source_parent=freeze['base'], steps=[], native_workers=2, new_roots=0, new_worktrees=0,
    new_clones=0, new_candidates=0, whole_workunit_closed=False, beta_qualified=False,
    opaque_sacl_compared=False, power_loss_qualified=False, real_game_effects=False, visible_UI_acceptance=False,
    full_make_ready_execution_available=False, play_authority=False, prior_q03_timeout_resolved=False)
def save():
    pending = OUT.with_suffix('.pending.json'); pending.write_text(json.dumps(record, indent=2) + '\n'); os.replace(pending, OUT)
def git(*args): return subprocess.check_output(['git', '-c', 'core.quotePath=false', *args], cwd=R, env=env, text=True).rstrip('\r\n')
def frozen():
    assert git('rev-parse', 'HEAD') == freeze['base'] and git('branch', '--show-current') == freeze['branch']
    assert not git('diff', '--cached', '--name-only')
    assert {row[3:] for row in git('status', '--porcelain', '--untracked-files=all').splitlines()} == set(freeze['changed_paths_raw_sha256'])
    assert {p: sha(R / p) for p in freeze['changed_paths_raw_sha256']} == freeze['changed_paths_raw_sha256']
def census(owner_pid, known_owned=None):
    probe = subprocess.run(['powershell', '-NoProfile', '-Command',
        '@(Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,Name,CreationDate) | ConvertTo-Json -Compress'],
        capture_output=True, text=True, timeout=30)
    assert probe.returncode == 0, 'Owned process census unavailable; stop before another heavy job'
    processes = json.loads(probe.stdout) if probe.stdout.strip() else []
    if isinstance(processes, dict): processes = [processes]
    owned = set(known_owned or []) | {owner_pid}
    while True:
        expanded = owned | {p['ProcessId'] for p in processes if p['ParentProcessId'] in owned}
        if expanded == owned: break
        owned = expanded
    return dict(owned_ids=sorted(owned), live_owned=[p for p in processes if p['ProcessId'] in owned],
        native_owners=[p for p in processes if p['Name'].lower() in {'msbuild.exe', 'cl.exe', 'link.exe', 'cmake.exe', 'ctest.exe'}])
def step(name, command, timeout=300, accepted=(0,), child_env=None):
    frozen(); log = E / ('existing-configuration-q04-' + name + '.log')
    started = time.monotonic(); print('START ' + name, flush=True)
    with log.open('xb') as stream:
        child = subprocess.Popen(command, cwd=R, env=child_env or env, stdout=stream, stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW)
        record['active_step'] = name; record['active_pid'] = child.pid; save()
        try: child.wait(timeout=timeout)
        except BaseException as error:
            before, after = None, None
            try: before = census(child.pid)
            except BaseException as probe_error: record['before_timeout_census_error'] = repr(probe_error)
            if child.poll() is None: child.kill()
            try: child.wait(timeout=10)
            except BaseException as drain_error: record['timeout_drain_error'] = repr(drain_error)
            try: after = census(child.pid, (before or {}).get('owned_ids'))
            except BaseException as probe_error: record['after_timeout_census_error'] = repr(probe_error)
            record['steps'].append(dict(name=name, pid=child.pid, status='STOP_PRESERVE_DESCENDANTS', error=repr(error),
                census_before=before, census_after=after, log=str(log), log_sha256=sha(log)))
            record['later_heavy_job_requires_residual_owner_audit'] = True; save(); raise
    record['steps'].append(dict(name=name, command=command, owned_pid=child.pid, exit_code=child.returncode,
        seconds=round(time.monotonic() - started, 3), log=str(log), log_sha256=sha(log)))
    save(); print('DONE ' + name + ': ' + str(child.returncode), flush=True)
    if child.returncode not in accepted:
        print('\n'.join(log.read_text(errors='replace').splitlines()[-60:]), flush=True)
        raise RuntimeError(name + ' failed; retain exact source, cache and evidence')
    return log

assert __debug__ and not OUT.exists()
with (E / 'existing-configuration-qualification-04.claim.json').open('x') as stream:
    json.dump(dict(pid=os.getpid(), freeze_sha256=sha(F)), stream)
save()
try:
    assert sha(Path(__file__).resolve()) == freeze['qualification_runner_sha256']; frozen()
    review = json.loads(V.read_text())
    assert review['verdict'] == 'PASS' and review['independent'] and review['non_authoring']
    assert review['freeze_sha256'] == sha(F) and review['qualification_runner_sha256'] == sha(Path(__file__).resolve())
    assert review['changed_paths_raw_sha256'] == freeze['changed_paths_raw_sha256']
    record.update(source_freeze_sha256=sha(F), frozen_source_review_sha256=sha(V))
    preflight_path = E / 'existing-configuration-source-preflight-05.json'
    assert sha(preflight_path) == freeze['source_preflight_sha256']
    preflight = json.loads(preflight_path.read_text())
    assert preflight['status'] == 'existing_configuration_source_preflight_pass_requires_frozen_review_and_native_qualification'
    assert preflight['changed_paths_raw_sha256'] == freeze['changed_paths_raw_sha256']
    for item in preflight['steps']: assert item['exit_code'] == 0 and sha(Path(item['log'])) == item['log_sha256']
    failure_path=E/'existing-configuration-qualification-02.json'
    assert sha(failure_path)==freeze['failed_qualification_sha256'] and json.loads(failure_path.read_text())['status']=='ACTIONABLE_FAILURE'
    custody_path=E/'existing-configuration-failed-q02-binary-custody.json'
    assert sha(custody_path)==freeze['failed_binary_custody_sha256']
    assert sha(E/'existing-configuration-failed-q02-binaries.zip')==json.loads(custody_path.read_text())['zip_sha256']
    marker = json.loads((W / '.facman-development-root.v1.json').read_text(encoding='utf-8-sig'))
    assert marker['kind'] == 'task-root' and Path(marker['canonical_path']).resolve() == W.resolve()
    assert Path(marker['source_root']).resolve() == R.resolve() and marker['task_id'] == freeze['branch']
    step('paths', ['py', '-3', 'tools/workspace_hygiene.py', 'paths'])
    doctor = json.loads(step('doctor', ['py', '-3', 'tools/workspace_hygiene.py', 'doctor', '--measure'], accepted=(0, 1)).read_text())
    assert set(doctor['violations']) <= {'unmanaged_secondary_worktrees_present', 'merged_local_task_branches_present'}
    assert len(doctor['task_roots']) <= 8 and doctor['task_root_bytes'] + 2147483648 <= 21474836480
    assert shutil.disk_usage(W).free >= 10737418240
    record['resources'] = dict(task_root_bytes=doctor['task_root_bytes'], reserved_peak_bytes=2147483648,
        free_before_bytes=shutil.disk_usage(W).free, retained_findings=doctor['violations']); save()
    query = "Get-CimInstance Win32_Process | Where-Object { ($_.Name -match '^(cmake|MSBuild|cl|link|ninja|ctest)\\.exe$' -and $_.CommandLine -notmatch '[-/]nodemode:') -or ($_.Name -eq 'dotnet.exe' -and $_.CommandLine -match ' (build|msbuild) ') } | Select-Object ProcessId,Name,CreationDate | ConvertTo-Json -Compress"
    deadline, previous = time.monotonic() + 1200, None
    while True:
        probe = subprocess.run(['powershell', '-NoProfile', '-Command', query], text=True, capture_output=True, timeout=30)
        assert probe.returncode == 0, 'Heavy-owner census failed; preserve parallel jobs'
        active = probe.stdout.strip()
        if not active: break
        if active != previous:
            record.setdefault('preserved_foreign_heavy_jobs', []).append(active); save()
            print('Existing heavy job owns machine: ' + active, flush=True); previous = active
        assert time.monotonic() < deadline, 'Heavy-owner deadline; no duplicate campaign started'
        time.sleep(10)
    providers = freeze['provider_roots_reused_readonly']; components = provider_workspace.locked_components(R)
    for key, alias in [('universal_launcher', 'ULK'), ('universal_setup', 'USK')]:
        provider_workspace.verify_checkout(Path(providers[alias]), components[key])
    targets = ['facman_cli', 'flb_factorio_instance_model_smoke', 'facman_presentation_service_smoke',
        'fl_transaction_session_smoke', 'fl_platform_io_smoke']
    step('generated-before-build', ['py', '-3', 'tools/codegen/generate_contracts.py', '--check'])
    retained_path=E/'existing-configuration-qualification-03.json'
    assert sha(retained_path)==freeze['retained_native_qualification_sha256']
    retained=json.loads(retained_path.read_text()); assert retained['status']=='ACTIONABLE_FAILURE'
    prior_freeze=E/'existing-configuration-source-freeze-03.json'
    assert sha(prior_freeze)==freeze['prior_freeze_sha256']
    previous=json.loads(prior_freeze.read_text())
    for path,digest in previous['changed_paths_raw_sha256'].items():
        if path not in freeze['changes_from_prior_freeze']:assert sha(R/path)==digest,path
    assert set(freeze['changes_from_prior_freeze'])=={'tests/test_configuration_reconciliation.py',
        '.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01/ExecPlan.md'}
    record['retained_native_steps']=[]
    for name in ('configure','build','native'):
        item=next(i for i in retained['steps'] if i['name']==name)
        assert item['exit_code']==0 and sha(Path(item['log']))==item['log_sha256']
        record['retained_native_steps'].append(item)
    native=Path(record['retained_native_steps'][-1]['log']).read_text()
    assert '100% tests passed, 0 tests failed out of 4' in native and 'Skipped' not in native
    for item in retained['binaries'].values():assert sha(Path(item['path']))==item['sha256']
    record.update(binaries=retained['binaries'],retained_native_qualification_sha256=sha(retained_path),
        new_builds=0,native_evidence_reused=True);save()
    exe=Path(retained['binaries']['facman.exe']['path'])
    env.update(FACMAN_CLI_EXE=str(exe),FACMAN_NATIVE_CLI=str(exe))
    focused_runner = E / 'run-existing-configuration-focused-04.py'
    assert sha(focused_runner) == freeze['focused_runner_sha256']
    assert review['focused_runner_sha256'] == freeze['focused_runner_sha256']
    for group, expected_count in [('new',10),('regression',59)]:
        focused = step('focused-'+group, [sys.executable, '-B', str(focused_runner), group], timeout=1200).read_text()
        match = re.search(r'Ran (\d+) tests in ', focused)
        assert match and int(match.group(1)) == expected_count and '\nOK\n' in focused and 'skipped=' not in focused and 'FAILED' not in focused
        group_receipt = E / ('existing-configuration-q04-focused-'+group+'-receipt.json')
        value = json.loads(group_receipt.read_text())
        assert value['status']=='PASS' and value['tests_run']==expected_count and value['skipped']==0
        record.setdefault('focused_groups',[]).append(dict(group=group,passed=expected_count,receipt_sha256=sha(group_receipt)));save()
    record['tests'] = dict(native_passed=4,focused_passed=69,skipped=0,new_methods=10);save()
    legacy = json.loads((E / 'presentation-intent-legacy-frozen.json').read_text(encoding='utf-8-sig'))
    workspace, receipt = Path(legacy['workspace']), Path(legacy['receipt_path'])
    def inventory(): return {p.relative_to(workspace).as_posix(): sha(p) for p in workspace.rglob('*') if p.is_file()}
    assert sha(receipt) == legacy['receipt_sha256'] and inventory() == legacy['workspace_inventory_sha256']
    record['historical_replays'] = []
    for index, (label, intent) in enumerate([('absent-default', None), ('explicit-menu', 'menu'), ('different-intent-conflict', 'load_save')], 1):
        frozen(); args = [str(exe), *legacy['replay_argv'][1:]]
        if intent is not None: args += ['--intent', intent]
        entry = dict(label=label, argv=args, status='STARTING', lifetime_deadline_seconds=45)
        record['historical_replays'].append(entry); save()
        child = subprocess.Popen(args, cwd=R, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=subprocess.CREATE_NO_WINDOW)
        entry.update(owned_pid=child.pid, status='RUNNING'); save()
        failure, out, err = None, b'', b''
        try: out, err = child.communicate(timeout=45)
        except BaseException as error:
            failure = error; entry.update(status='STOP_PRESERVE_PROCESS_EVIDENCE', error=repr(error)); save()
            try: entry['census_before'] = census(child.pid)
            except BaseException as probe_error: entry['census_before_error'] = repr(probe_error)
            try:
                if child.poll() is None: child.kill()
            except BaseException as kill_error: entry['owned_child_kill_error'] = repr(kill_error)
            try: out, err = child.communicate(timeout=10)
            except BaseException as drain_error:
                out, err = getattr(drain_error, 'stdout', None) or getattr(error, 'stdout', None) or b'', getattr(drain_error, 'stderr', None) or getattr(error, 'stderr', None) or b''
                entry['bounded_drain_error'] = repr(drain_error)
            try: entry['census_after'] = census(child.pid, entry.get('census_before', {}).get('owned_ids'))
            except BaseException as probe_error: entry['census_after_error'] = repr(probe_error)
            record['later_heavy_job_requires_residual_owner_audit'] = True
        finally:
            streams = {}
            for name, data in [('stdout', out), ('stderr', err)]:
                path = E / ('existing-configuration-q04-legacy-' + str(index) + '.' + name)
                with path.open('xb') as stream: stream.write(data)
                streams[name] = dict(path=str(path), sha256=sha(path))
            entry.update(exit_code=child.poll(), streams=streams,
                status='ACTIONABLE_PROCESS_FAILURE' if failure else 'TERMINAL'); save()
        if failure is not None: raise failure
        value = json.loads(out); assert not err
        if intent != 'load_save': assert child.returncode == 0 and value['payload'] == json.loads(legacy['result_json'])
        else: assert child.returncode != 0 and value['error']['code'] == 'idempotency_key_conflict'
        assert sha(receipt) == legacy['receipt_sha256'] and inventory() == legacy['workspace_inventory_sha256']
        entry.update(status='PASS', workspace_unchanged=True); save()
    step('generated-after', ['py', '-3', 'tools/codegen/generate_contracts.py', '--check'])
    step('diff', ['git', 'diff', '--check']); frozen()
    record.update(status='PASS', resources={**record['resources'], 'free_after_bytes': shutil.disk_usage(W).free})
    save(); print(json.dumps(dict(status='PASS', tests=record['tests'], historical_replays=3)), flush=True)
except Exception as error:
    record.update(status='ACTIONABLE_FAILURE', error=str(error), traceback=traceback.format_exc()); save()
    print(traceback.format_exc(), flush=True); raise
