"""One frozen existing-INI owner campaign in the already owned native cache."""
from pathlib import Path
import hashlib, json, os, re, shutil, subprocess, sys, time, traceback
R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
W, B = E.parent, E.parent / 'native-developer'
F = E / 'existing-configuration-source-freeze-01.json'
V = E / 'existing-configuration-frozen-source-review-01.json'
OUT = E / 'existing-configuration-qualification-01.json'
env = dict(os.environ, FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds', FACMAN_TASK_ROOT=str(W),
    TEMP=str(W / 't'), TMP=str(W / 't'), CMAKE_BUILD_PARALLEL_LEVEL='2', FACMAN_MIN_FREE_GIB='10',
    PYTHONOPTIMIZE='0', PYTHONPATH=os.pathsep.join([str(R / 'tests'), str(R)]))
os.environ.update(env)
sys.path.insert(0, str(R))
from tools import native_build, provider_workspace
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
freeze = json.loads(F.read_text())
record = dict(status='running', steps=[], native_workers=2, new_roots=0, new_worktrees=0,
    new_clones=0, new_candidates=0, whole_workunit_closed=False, beta_qualified=False,
    opaque_sacl_compared=False, power_loss_qualified=False, real_game_effects=False, visible_UI_acceptance=False,
    full_make_ready_execution_available=False, play_authority=False, prior_q02_timeout_resolved=False)
def save():
    pending = OUT.with_suffix('.pending.json'); pending.write_text(json.dumps(record, indent=2) + '\n'); os.replace(pending, OUT)
def git(*args): return subprocess.check_output(['git', '-c', 'core.quotePath=false', *args], cwd=R, env=env, text=True).rstrip('\r\n')
def frozen():
    assert git('rev-parse', 'HEAD') == freeze['base'] and git('branch', '--show-current') == freeze['branch']
    assert not git('diff', '--cached', '--name-only')
    assert {row[3:] for row in git('status', '--porcelain', '--untracked-files=all').splitlines()} == set(freeze['changed_paths_raw_sha256'])
    assert {p: sha(R / p) for p in freeze['changed_paths_raw_sha256']} == freeze['changed_paths_raw_sha256']
def census(owner_pid, known_owned=None):
    probe = subprocess.run(['powershell', '-NoProfile', '-Command',
        '@(Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,Name,CreationDate) | ConvertTo-Json -Compress'],
        capture_output=True, text=True, timeout=30)
    assert probe.returncode == 0, 'Owned process census unavailable; stop before another heavy job'
    processes = json.loads(probe.stdout) if probe.stdout.strip() else []
    if isinstance(processes, dict): processes = [processes]
    owned = set(known_owned or []) | {owner_pid}
    while True:
        expanded = owned | {p['ProcessId'] for p in processes if p['ParentProcessId'] in owned}
        if expanded == owned: break
        owned = expanded
    return dict(owned_ids=sorted(owned), live_owned=[p for p in processes if p['ProcessId'] in owned],
        native_owners=[p for p in processes if p['Name'].lower() in {'msbuild.exe', 'cl.exe', 'link.exe', 'cmake.exe', 'ctest.exe'}])
def step(name, command, timeout=300, accepted=(0,), child_env=None):
    frozen(); log = E / ('existing-configuration-q01-' + name + '.log')
    started = time.monotonic(); print('START ' + name, flush=True)
    with log.open('xb') as stream:
        child = subprocess.Popen(command, cwd=R, env=child_env or env, stdout=stream, stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW)
        record['active_step'] = name; record['active_pid'] = child.pid; save()
        try: child.wait(timeout=timeout)
        except BaseException as error:
            before, after = None, None
            try: before = census(child.pid)
            except BaseException as probe_error: record['before_timeout_census_error'] = repr(probe_error)
            if child.poll() is None: child.kill()
            try: child.wait(timeout=10)
            except BaseException as drain_error: record['timeout_drain_error'] = repr(drain_error)
            try: after = census(child.pid, (before or {}).get('owned_ids'))
            except BaseException as probe_error: record['after_timeout_census_error'] = repr(probe_error)
            record['steps'].append(dict(name=name, pid=child.pid, status='STOP_PRESERVE_DESCENDANTS', error=repr(error),
                census_before=before, census_after=after, log=str(log), log_sha256=sha(log)))
            record['later_heavy_job_requires_residual_owner_audit'] = True; save(); raise
    record['steps'].append(dict(name=name, command=command, owned_pid=child.pid, exit_code=child.returncode,
        seconds=round(time.monotonic() - started, 3), log=str(log), log_sha256=sha(log)))
    save(); print('DONE ' + name + ': ' + str(child.returncode), flush=True)
    if child.returncode not in accepted:
        print('\n'.join(log.read_text(errors='replace').splitlines()[-60:]), flush=True)
        raise RuntimeError(name + ' failed; retain exact source, cache and evidence')
    return log

assert __debug__ and not OUT.exists()
with (E / 'existing-configuration-qualification-01.claim.json').open('x') as stream:
    json.dump(dict(pid=os.getpid(), freeze_sha256=sha(F)), stream)
save()
try:
    assert sha(Path(__file__).resolve()) == freeze['qualification_runner_sha256']; frozen()
    review = json.loads(V.read_text())
    assert review['verdict'] == 'PASS' and review['independent'] and review['non_authoring']
    assert review['freeze_sha256'] == sha(F) and review['qualification_runner_sha256'] == sha(Path(__file__).resolve())
    assert review['changed_paths_raw_sha256'] == freeze['changed_paths_raw_sha256']
    record.update(source_freeze_sha256=sha(F), frozen_source_review_sha256=sha(V))
    preflight_path = E / 'existing-configuration-source-preflight-03.json'
    assert sha(preflight_path) == freeze['source_preflight_sha256']
    preflight = json.loads(preflight_path.read_text())
    assert preflight['status'] == 'existing_configuration_source_preflight_pass_requires_frozen_review_and_native_qualification'
    assert preflight['changed_paths_raw_sha256'] == freeze['changed_paths_raw_sha256']
    for item in preflight['steps']: assert item['exit_code'] == 0 and sha(Path(item['log'])) == item['log_sha256']
    marker = json.loads((W / '.facman-development-root.v1.json').read_text(encoding='utf-8-sig'))
    assert marker['kind'] == 'task-root' and Path(marker['canonical_path']).resolve() == W.resolve()
    assert Path(marker['source_root']).resolve() == R.resolve() and marker['task_id'] == freeze['branch']
    step('paths', ['py', '-3', 'tools/workspace_hygiene.py', 'paths'])
    doctor = json.loads(step('doctor', ['py', '-3', 'tools/workspace_hygiene.py', 'doctor', '--measure'], accepted=(0, 1)).read_text())
    assert set(doctor['violations']) <= {'unmanaged_secondary_worktrees_present', 'merged_local_task_branches_present'}
    assert len(doctor['task_roots']) <= 8 and doctor['task_root_bytes'] + 2147483648 <= 21474836480
    assert shutil.disk_usage(W).free >= 10737418240
    record['resources'] = dict(task_root_bytes=doctor['task_root_bytes'], reserved_peak_bytes=2147483648,
        free_before_bytes=shutil.disk_usage(W).free, retained_findings=doctor['violations']); save()
    query = "Get-CimInstance Win32_Process | Where-Object { ($_.Name -match '^(cmake|MSBuild|cl|link|ninja|ctest)\\.exe$' -and $_.CommandLine -notmatch '[-/]nodemode:') -or ($_.Name -eq 'dotnet.exe' -and $_.CommandLine -match ' (build|msbuild) ') } | Select-Object ProcessId,Name,CreationDate | ConvertTo-Json -Compress"
    deadline, previous = time.monotonic() + 1200, None
    while True:
        probe = subprocess.run(['powershell', '-NoProfile', '-Command', query], text=True, capture_output=True, timeout=30)
        assert probe.returncode == 0, 'Heavy-owner census failed; preserve parallel jobs'
        active = probe.stdout.strip()
        if not active: break
        if active != previous:
            record.setdefault('preserved_foreign_heavy_jobs', []).append(active); save()
            print('Existing heavy job owns machine: ' + active, flush=True); previous = active
        assert time.monotonic() < deadline, 'Heavy-owner deadline; no duplicate campaign started'
        time.sleep(10)
    providers = freeze['provider_roots_reused_readonly']; components = provider_workspace.locked_components(R)
    for key, alias in [('universal_launcher', 'ULK'), ('universal_setup', 'USK')]:
        provider_workspace.verify_checkout(Path(providers[alias]), components[key])
    targets = ['facman_cli', 'flb_factorio_instance_model_smoke', 'facman_presentation_service_smoke',
        'fl_transaction_session_smoke', 'fl_platform_io_smoke']
    step('generated-before-build', ['py', '-3', 'tools/codegen/generate_contracts.py', '--check'])
    step('configure', ['cmake', '-S', str(R), '-B', str(B), '-DFACMAN_PROVIDER_SOURCE_LINKAGE=shared',
        '-DFACMAN_WARNINGS_AS_ERRORS=ON', '-DFLAUNCH_UNIVERSAL_LAUNCHER_ROOT=' + providers['ULK'],
        '-DFLAUNCH_UNIVERSAL_SETUP_ROOT=' + providers['USK']])
    step('build', native_build.command(B, 'Release', targets, {}), timeout=2400)
    exe = B / 'Release/facman.exe'; env.update(FACMAN_CLI_EXE=str(exe), FACMAN_NATIVE_CLI=str(exe))
    record['binaries'] = {p.name: dict(path=str(p), sha256=sha(p), bytes=p.stat().st_size)
        for p in sorted((B / 'Release').glob('*')) if p.suffix.lower() in {'.exe', '.dll'}}; save()
    native_temp = W / 't/existing-configuration-q01-native'
    assert not native_temp.exists(); native_temp.mkdir()
    native_env = dict(env, TEMP=str(native_temp), TMP=str(native_temp))
    native = step('native', ['ctest', '--test-dir', str(B), '-C', 'Release', '--output-on-failure',
        '-R', '^(' + '|'.join(targets[1:]) + ')$'], timeout=300, child_env=native_env).read_text()
    assert '100% tests passed, 0 tests failed out of 4' in native and 'Skipped' not in native
    modules = ['test_configuration_reconciliation', 'test_configuration_preparation', 'test_selected_save_preparation',
        'test_readiness_builtin_content', 'test_save_index_retention', 'test_presentation_service',
        'test_presentation_profile_preparation', 'test_presentation_intent',
        'test_local_modset_solver.LocalModsetSolverTests.test_applied_selection_exports_exact_lock_and_only_selected_archives']
    focused = step('focused', ['py', '-3', '-B', '-m', 'unittest', '-v', *modules], timeout=1200).read_text()
    match = re.search(r'Ran (\d+) tests in ', focused)
    assert match and int(match.group(1)) == 68 and '\nOK\n' in focused and 'skipped=' not in focused and 'FAILED' not in focused
    record['tests'] = dict(native_passed=4, focused_passed=int(match.group(1)), skipped=0, new_methods=9); save()
    legacy = json.loads((E / 'presentation-intent-legacy-frozen.json').read_text(encoding='utf-8-sig'))
    workspace, receipt = Path(legacy['workspace']), Path(legacy['receipt_path'])
    def inventory(): return {p.relative_to(workspace).as_posix(): sha(p) for p in workspace.rglob('*') if p.is_file()}
    assert sha(receipt) == legacy['receipt_sha256'] and inventory() == legacy['workspace_inventory_sha256']
    record['historical_replays'] = []
    for index, (label, intent) in enumerate([('absent-default', None), ('explicit-menu', 'menu'), ('different-intent-conflict', 'load_save')], 1):
        frozen(); args = [str(exe), *legacy['replay_argv'][1:]]
        if intent is not None: args += ['--intent', intent]
        child = subprocess.Popen(args, cwd=R, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=subprocess.CREATE_NO_WINDOW)
        failure = None
        try: out, err = child.communicate(timeout=45)
        except BaseException as error:
            failure = error
            before = census(child.pid)
            if child.poll() is None: child.kill()
            out, err = child.communicate(timeout=10)
            record['historical_replay_failure'] = dict(label=label, owned_pid=child.pid,
                error=repr(error), census_before=before, census_after=census(child.pid, before['owned_ids']))
        streams = {}
        for name, data in [('stdout', out), ('stderr', err)]:
            path = E / ('existing-configuration-q01-legacy-' + str(index) + '.' + name)
            with path.open('xb') as stream: stream.write(data)
            streams[name] = dict(path=str(path), sha256=sha(path))
        if failure is not None:
            record['historical_replay_failure']['streams'] = streams; save(); raise failure
        value = json.loads(out); assert not err
        if intent != 'load_save': assert child.returncode == 0 and value['payload'] == json.loads(legacy['result_json'])
        else: assert child.returncode != 0 and value['error']['code'] == 'idempotency_key_conflict'
        assert sha(receipt) == legacy['receipt_sha256'] and inventory() == legacy['workspace_inventory_sha256']
        record['historical_replays'].append(dict(label=label, owned_pid=child.pid, exit_code=child.returncode,
            streams=streams, workspace_unchanged=True)); save()
    step('generated-after', ['py', '-3', 'tools/codegen/generate_contracts.py', '--check'])
    step('diff', ['git', 'diff', '--check']); frozen()
    record.update(status='PASS', resources={**record['resources'], 'free_after_bytes': shutil.disk_usage(W).free})
    save(); print(json.dumps(dict(status='PASS', tests=record['tests'], historical_replays=3)), flush=True)
except Exception as error:
    record.update(status='ACTIONABLE_FAILURE', error=str(error), traceback=traceback.format_exc()); save()
    print(traceback.format_exc(), flush=True); raise
