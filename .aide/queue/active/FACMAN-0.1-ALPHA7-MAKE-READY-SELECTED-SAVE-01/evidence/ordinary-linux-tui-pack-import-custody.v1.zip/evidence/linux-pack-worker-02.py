import contextlib,hashlib,io,json,os,select,signal,stat,subprocess,sys,tempfile,threading,time,traceback,unittest,zipfile
from pathlib import Path
from unittest.mock import patch
E=Path(__file__).resolve().parent;W=E.parent;R=Path('/mnt/d/Projects/Factorio/factorio-launcher');M=E/'linux-delivered-private-01';C=M/'consumer';O=E/'linux-pack-raw-02';I=C/'fixture-install'
V=W/'validators-linux';sys.path[:0]=[str(V),str(R/'tests'),str(R)]
cached=json.loads((E/'joined-final-input-linux-existing-validators-review-01.json').read_bytes())
assert not os.access(V,os.W_OK)
for name,row in cached['verified_files'].items():assert hashlib.sha256((V/name).read_bytes()).hexdigest()==row['sha256']
assert hashlib.sha256((R/'tools/requirements-dev.lock').read_bytes()).hexdigest()==cached['requirements_sha256']
a=json.loads((E/'linux-pack-admission-01.json').read_bytes());packages={k:M/('relocated FacMan '+k+' Ω') for k in ('cli','tui')};CLI=packages['cli']/'bin/facman';TUI=packages['tui']/'bin/facman'
os.environ.update(FACMAN_CLI_EXE=str(CLI),FACMAN_TUI_EXE=str(TUI))
import native_cli,test_presentation_pack_import as presentation,test_local_modset_solver as solver,test_portable_modpack_import as portable,test_make_ready_joined as joined,test_tui_product as tui
from tools.package.runtime_identity import require_backend_identity
from tools import package_hash_manifest
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();digest=lambda b:hashlib.sha256(b).hexdigest()
assert os.getuid()==os.getgid()==65534 and os.getgroups()==[] and not os.access(R,os.W_OK)
environment={k:v for k,v in os.environ.items() if not k.startswith(('FACMAN_','FLAUNCH_','ULK_','USK_','LD_','DYLD_')) and k not in ('DISPLAY','WAYLAND_DISPLAY','PYTHONPATH')}
environment.update(PATH='',HOME=str(C/'home'),XDG_CONFIG_HOME=str(C/'home/config'),XDG_CACHE_HOME=str(C/'home/cache'),XDG_DATA_HOME=str(C/'home/data'),TMPDIR=str(C),TEMP=str(C),TMP=str(C),LANG='C.UTF-8',TERM='dumb',PYTHONDONTWRITEBYTECODE='1')
result=dict(status='STARTED',admission_sha256=sha(E/'linux-pack-admission-01.json'),bindings={},calls=[],sessions=[],intentional_loss=None,physical_ext4=False,fullscreen=False,human=False,real_game=False)
out=E/'linux-pack-worker-result-02.json';assert not out.exists();deadline=time.monotonic()+600
def budget(extra=0):
 assert sum(p.stat().st_size for p in C.rglob('*') if p.is_file())<32*1024**2 and sum(p.stat().st_size for p in O.rglob('*') if p.is_file())+extra<64*1024**2,'Declared fixture/raw budget exceeded'
def save():
 data=(json.dumps(result,indent=2)+'\n').encode();assert len(data)<4*1024**2;out.write_bytes(data)
def inventory(root):
 rows={}
 for p in root.rglob('*'):
  assert not p.is_symlink()
  if p.is_file():rows[p.relative_to(root).as_posix()]=dict(bytes=p.stat().st_size,sha256=sha(p),identity=joined.file_identity(p))
  elif p.is_dir():rows[p.relative_to(root).as_posix()]=dict(directory=True,identity=joined.file_identity(p))
  else:raise AssertionError('Unexpected fixture object: '+str(p))
 return rows
def retain(p):
 assert p.stat().st_size<16*1024**2;raw=p.read_bytes();h=digest(raw);cas=O/'objects'/h
 if not cas.exists():budget(len(raw));cas.write_bytes(raw)
 return dict(bytes=len(raw),sha256=h,identity=joined.file_identity(p))
def identity(pid):
 p=Path('/proc',str(pid));s=(p/'stat').read_text().rsplit(')',1)[1].split();status={x.split(':',1)[0]:x.split(':',1)[1].split() for x in (p/'status').read_text().splitlines() if ':' in x}
 try:image=os.readlink(p/'exe')
 except FileNotFoundError:
  s=(p/'stat').read_text().rsplit(')',1)[1].split();assert s[0]=='Z';image=None
 return dict(pid=pid,start_ticks=int(s[19]),ppid=int(s[1]),pgrp=int(s[2]),state=s[0],uid=list(map(int,status['Uid'])),gid=list(map(int,status['Gid'])),groups=list(map(int,status['Groups'])),image=image,argv=(p/'cmdline').read_bytes().decode().rstrip('\0').split('\0'))
def run(args,stdin=None,interrupt=False):
 assert time.monotonic()<deadline
 number=len(result['calls']);d=O/('call-%03d'%number);d.mkdir();budget(len((stdin or '').encode()));(d/'stdin.raw').write_bytes((stdin or '').encode())
 env=dict(environment)
 if interrupt:env['FACMAN_TEST_MODPACK_IMPORT_PAUSE']='verified'
 p=subprocess.Popen(args,cwd=C,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 row=dict(args=list(args),descendants=[],intentional=False,safety_termination=False);result['calls'].append(row);captured=[];errors=[];handles={};done=False;primary_fd=None;thread=None
 def communicate():
  try:captured.append(p.communicate((stdin or '').encode(),timeout=min(90,deadline-time.monotonic())))
  except BaseException as e:errors.append(repr(e))
 def store_streams():
  stdout,stderr=captured[0];oversized=max(len(stdout),len(stderr))>4*1024**2
  if oversized:row['output_limit_exceeded']=True
  values=[('stdout',stdout[:65536] if oversized else stdout),('stderr',stderr[:65536] if oversized else stderr)]
  budget(sum(max(0,len(data)-((d/(name+'.raw')).stat().st_size if (d/(name+'.raw')).exists() else 0)) for name,data in values))
  for name,data in values:(d/(name+'.raw')).write_bytes(data)
  return not oversized
 try:
  primary_fd=os.pidfd_open(p.pid);initial=identity(p.pid);assert initial['pgrp']==p.pid and initial['uid']==initial['gid']==[65534]*4 and initial['groups']==[]
  assert initial['image']==args[0] or (initial['state']=='Z' and select.select([primary_fd],[],[],0)[0]==[primary_fd])
  row.update(primary=initial,primary_pidfd_held=True,executable_sha256=sha(args[0]));save()
  thread=threading.Thread(target=communicate,daemon=True);thread.start()
  while thread.is_alive():
   assert time.monotonic()<deadline and not errors
   for proc in Path('/proc').iterdir():
    if not proc.name.isdigit() or int(proc.name)==p.pid:continue
    try:
     # Filter public stat before privileged image/status observation; namespace
     # PID1 and unrelated groups are outside this owned primary's custody.
     summary=(proc/'stat').read_text().rsplit(')',1)[1].split()
     if int(summary[2])!=p.pid:continue
     ident=identity(int(proc.name))
     if ident['pgrp']!=p.pid:continue
     # fork() briefly exposes the frontend image before exec(); custody begins
     # only after this descendant becomes the exact packaged backend.
     if ident['image']!=str(CLI):continue
     key=(ident['pid'],ident['start_ticks'])
     if key not in handles:
      fd=os.pidfd_open(ident['pid']);again=identity(ident['pid']);assert again['start_ticks']==ident['start_ticks'] and again['pgrp']==p.pid
      assert ident['uid']==ident['gid']==[65534]*4 and ident['groups']==[] and ident['image']==str(CLI)
      item=dict(ident,image_sha256=sha(CLI),pidfd_held=True);row['descendants'].append(item);handles[key]=(fd,item)
    except (FileNotFoundError,ProcessLookupError):pass
   if interrupt and not done and signal_path.is_file():
    assert signal_path.read_bytes()==b'paused\n';frozen_binding=binding()
    live=[(fd,item) for fd,item in handles.values() if not select.select([fd],[],[],0)[0]]
    if not live:thread.join(.001);continue
    assert len(live)==1,live
    fd,item=live[0];current=identity(item['pid']);assert current['start_ticks']==item['start_ticks'] and current['ppid']==p.pid and current['pgrp']==p.pid and current['image']==str(CLI)
    assert sha(CLI)==item['image_sha256'] and binding()==frozen_binding
    event=dict(identity=item,binding=frozen_binding,signal='SIGKILL',held_pidfd=True,termination_succeeded=False);result['intentional_loss']=event;save()
    with (O/'intentional-loss.json').open('xb') as f:f.write((json.dumps(event,indent=2)+'\n').encode());f.flush();os.fsync(f.fileno())
    signal.pidfd_send_signal(fd,signal.SIGKILL);assert select.select([fd],[],[],5)[0]==[fd]
    event['termination_succeeded']=True;row['intentional']=True;done=True;save()
   thread.join(.001)
  assert not errors and len(captured)==1 and done is interrupt
  stdout,stderr=captured[0];assert store_streams(),'Captured output exceeds declared per-stream limit'
  assert all(select.select([fd],[],[],5)[0]==[fd] for fd,item in handles.values())
  for fd,item in handles.values():item['stopped_pidfd_ready']=True
  remaining=[]
  for proc in Path('/proc').iterdir():
   if not proc.name.isdigit():continue
   try:
    s=(proc/'stat').read_text().rsplit(')',1)[1].split()
    if int(s[2])==p.pid:remaining.append(int(proc.name))
   except FileNotFoundError:pass
  row.update(exit_code=p.returncode,normal_wait=True,group_empty=not remaining,remaining=remaining,primary_absent=not Path('/proc',str(p.pid)).exists(),stdout_sha256=sha(d/'stdout.raw'),stderr_sha256=sha(d/'stderr.raw'))
  assert row['group_empty'] and row['primary_absent'];save()
  return p.returncode,stdout.decode('utf-8'),stderr.decode('utf-8')
 finally:
  if p.poll() is None:row['safety_termination']=True;os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=10)
  row['final_observed_primary_exit']=p.returncode
  if thread is not None:thread.join(10)
  if captured:store_streams()
  for fd,item in handles.values():os.close(fd)
  if primary_fd is not None:os.close(primary_fd)
  budget();save()
def machine(args,env=None):
 assert not env
 return run([str(CLI),*args])
def query(scope):
 code,text,err=machine(['--workspace',str(WS),'presentation','query',scope,'--json']);assert code==0 and not err
 return json.loads(text)['payload']
def session(text,interrupt=False):
 code,out,err=run([str(TUI),'tui','--workspace',str(WS),'--ordinary','--plain','--transport','process','--cli-path',str(CLI)],text,interrupt)
 assert code==0 and not err,(code,err,out);result['sessions'].append(len(result['calls'])-1);return out
try:
 for kind,root in packages.items():
  assert not os.access(root,os.W_OK) and not os.access(root/'bin/facman',os.W_OK) and not package_hash_manifest.verify_manifest(root)
  code,text,err=run([str(root/'bin/facman'),'product','inspect','--json']);assert code==0 and not err
  backend=require_backend_identity(root,root/'bin/facman',json.loads(text)['payload']);assert backend['compiled_source_revision']==a['compiled_source'] and backend['compiled_source_dirty'] is False
  build=json.loads((root/'manifest/build_info.v1.json').read_bytes());assert build['source_revisions']==dict(factorio_launcher=a['compiled_source'],universal_launcher='5479939ca5cbc9ee0f901608a92012778b4752ae',universal_setup='2749a15b835a6c1c9968598a2b434d85809691ad')
  result['bindings'][kind]=dict(backend=backend,build_info=build,closure_sha256=sha(root/'manifest/hashes.sha256'))
 with contextlib.ExitStack() as stack:
  for module,name,value in [(native_cli,'invoke_machine',machine),(presentation,'invoke_machine',machine),(presentation,'FIXTURE_INSTALL',I),(solver,'FIXTURE_INSTALL',I)]:stack.enter_context(patch.object(module,name,value))
  normal=C/'normal Ω';normal.mkdir();producer,WS,pack=presentation.PresentationPackImportTests().prepare(normal,b'\x00binary settings\xff')
  sentinel=WS/'user-owned/sentinel.bin';sentinel.parent.mkdir();sentinel.write_bytes(b'foreign player bytes\x00\xff');protected=inventory(producer),inventory(I),retain(sentinel)
  projected=query('content');assert projected['selected_context']['instance_id'] is None
  index=next(i for i,x in enumerate(projected['available_semantic_actions']) if x['action_id']=='modsets.import')
  form='4\n'+'tab\n'*index+'space\nsource_path='+str(pack)+'\nnew_instance_id=reconstructed\ninstallation_id=fixture\ndisplay_name=Restored pack\n'
  before=inventory(WS)
  for suffix,marker in [('6\nq\n','Action input: Import offline pack'),('space\n6\nq\n','Confirm Import offline pack')]:
   text=session(form+suffix);assert marker in text and inventory(WS)==before
  text=session(form+'space\nspace\nq\n');assert 'Instance: Restored pack' in text
  portable.PortableModpackImportTests().assert_reconstruction(WS,pack);assert protected==(inventory(producer),inventory(I),retain(sentinel))
  receipts=list((WS/'.facman/action-receipts-v2').glob('*.v2.json'));assert len(receipts)==1
  rec=json.loads(receipts[0].read_bytes());assert json.loads(rec['result_json'])['outcome']=='completed'
  result['normal']=dict(protected_preserved=True,receipt=rec,consumer=inventory(WS))
  interrupted=C/'interrupted Ω';interrupted.mkdir();producer,WS,pack=presentation.PresentationPackImportTests().prepare(interrupted,b'\x00preserved TUI settings\xff')
  sentinel=WS/'user-owned/sentinel.bin';sentinel.parent.mkdir();sentinel.write_bytes(b'foreign player data\x00\xff');protected=inventory(producer),inventory(I),retain(sentinel)
  content=query('content');assert content['selected_context']['instance_id'] is None
  index=next(i for i,x in enumerate(content['available_semantic_actions']) if x['action_id']=='modsets.import')
  form='4\n'+'tab\n'*index+'space\nsource_path='+str(pack)+'\nnew_instance_id=reconstructed\ninstallation_id=fixture\ndisplay_name=Restored pack\nspace\nspace\nq\n'
  signal_path=WS/'.facman-modpack-import-verified-paused';release=WS/'.facman-modpack-import-verified-release';stage=WS/'.facman-pack-import-reconstructed';target=WS/'instances/reconstructed'
  frozen=None;original_receipt=None;journal_path=None;stage_before=None
  # Frozen request/journal/source validation follows the independently reviewed
  # Windows delivered proof; Linux identities use the existing portable oracle.
  def binding():
   global frozen,original_receipt,journal_path,stage_before
   assert signal_path.read_bytes()==b'paused\n' and not release.exists() and not target.exists()
   receipts=[(p,json.loads(p.read_bytes())) for p in (WS/'.facman/action-receipts-v2').glob('*.v2.json') if json.loads(p.read_bytes())['action_id']=='modsets.import'];assert len(receipts)==1
   rp,receipt=receipts[0];request=json.loads(receipt['request_json']);assert receipt['state']=='accepted_outcome_unknown' and json.loads(receipt['result_json'])['outcome']=='outcome_unknown'
   expected=dict(action_id='modsets.import',scope='content',confirmation='explicit',source_path=str(pack),new_instance_id='reconstructed',installation_id='fixture',display_name='Restored pack',selected_instance_id='',template_id='vanilla')
   assert all(request.get(k)==v for k,v in expected.items()) and request['expected_snapshot_revision']==content['revision']
   assert receipt['request_id']==request['request_id']==receipt['idempotency_key'] and request['request_id'].startswith('tui-modsets-import-')
   assert receipt['request_fingerprint']==digest(receipt['request_json'].encode()) and receipt['result_digest']==digest(receipt['result_json'].encode())
   journals=[(p,json.loads(p.read_bytes())) for p in (WS/'transactions').glob('*.transaction.v1.json') if json.loads(p.read_bytes())['command_id']=='modsets.import'];assert len(journals)==1
   jp,journal=journals[0];assert journal['state']=='verified' and journal['commit_strategy']=='modpack_instance_no_replace_v1' and Path(journal['target'])==target
   assert list(map(Path,journal['source_identities']))==[pack,I] and list(map(Path,journal['owned_staging_roots']))==[stage]
   assert journal['effect_file_identity']==joined.file_identity(stage) and journal['effect_parent_identity']==joined.file_identity(target.parent)
   context=json.loads(journal['operation_context']);assert context['install_id']=='fixture' and context['root_identity']==joined.file_identity(I)
   source=context['source_binding'];assert source['archive_sha256']==sha(pack) and source['archive_size']==pack.stat().st_size and source['instance_id']=='reconstructed' and source['install_id']=='fixture' and source['display_name']=='Restored pack'
   with zipfile.ZipFile(pack) as archive:assert source['manifest_sha256']==digest(archive.read('modpack-manifest.v1.json')) and source['lock_sha256']==digest(archive.read('modset-lock.v1.json'))
   expected_files={x['path']:dict(bytes=x['size'],sha256=x['sha256']) for x in journal['expected_files']};assert len(expected_files)==len(journal['expected_files'])==9
   for name,row in expected_files.items():
    p=stage/name;assert stage in p.parents and p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
   for p in stage.rglob('*'):
    if p.is_file():retain(p)
   value=dict(request=retain(rp),journal=retain(jp),transaction_id=journal['transaction_id'],stage_identity=joined.file_identity(stage),parent_identity=joined.file_identity(target.parent),stage=inventory(stage),expected_files=expected_files,source=retain(pack),installation=inventory(I),signal=retain(signal_path))
   if frozen is None:frozen=value;original_receipt=rp;journal_path=jp;stage_before=value['stage'];result['pre_fault_binding']=value;save()
   assert value==frozen
   return value
  lost=session(form,interrupt=True);assert 'unknown' in lost.lower()
  assert result['intentional_loss']['termination_succeeded'] and not target.exists() and json.loads(journal_path.read_bytes())['state']=='verified'
  uncertainty=original_receipt.read_bytes();assert digest(uncertainty)==frozen['request']['sha256'] and protected==(inventory(producer),inventory(I),retain(sentinel))
  activity=query('activity_recovery');aindex=next(i for i,x in enumerate(activity['available_semantic_actions']) if x['action_id']=='recovery.apply_supported')
  opening='6\n'+'tab\n'*aindex+'space\ntransaction_id='+frozen['transaction_id']+'\nspace\n'
  preserved=inventory(WS);cancelled=session(opening+'7\nq\n');assert 'Confirm Apply supported recovery' in cancelled and inventory(WS)==preserved
  recovered=session(opening+'space\n1\nq\n');assert 'Apply supported recovery completed' in recovered and 'Instance: Restored pack' in recovered
  portable.PortableModpackImportTests().assert_reconstruction(WS,pack)
  assert original_receipt.read_bytes()==uncertainty and json.loads(journal_path.read_bytes())['state']=='complete' and joined.file_identity(target)==frozen['stage_identity']
  now=inventory(target)
  for name,row in stage_before.items():
   if name not in ('.facman-transaction-staging.v2.json','.facman-archive-staging.v1'):assert now[name]==row,name
  assert protected==(inventory(producer),inventory(I),retain(sentinel))
  receipts=[json.loads(p.read_bytes()) for p in (WS/'.facman/action-receipts-v2').glob('*.v2.json')];recoveries=[r for r in receipts if r['action_id']=='recovery.apply_supported'];assert len(recoveries)==1
  r=recoveries[0];assert json.loads(r['request_json'])['transaction_id']==frozen['transaction_id'] and json.loads(r['result_json'])['outcome']=='completed'
  before=inventory(WS)
  for args in [['workspace','recovery','inspect'],['workspace','recovery','plan',frozen['transaction_id']]]:
   code,text,err=machine(['--workspace',str(WS),*args,'--json']);assert code==0 and not err
  assert inventory(WS)==before
  result['recovered']=dict(transaction_id=frozen['transaction_id'],original_uncertainty_sha256=digest(uncertainty),recovery_receipt=r,original_import_not_replayed=True,all_protected_preserved=True)
 for kind,root in packages.items():assert {p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file()}==a['packages'][kind]['file_inventory']
 assert all(c['normal_wait'] and c['group_empty'] and c['primary_absent'] and not c['safety_termination'] for c in result['calls'])
 result['status']='PASS_DELIVERED_LINUX_PACK_IMPORT_AND_ORDINARY_RECOVERY'
except BaseException as e:result.update(status='FAIL_RETAINED',error=repr(e),traceback=traceback.format_exc())
finally:
 try:
  for p in C.rglob('*'):
   if p.is_file():retain(p)
  result['final_consumer']=inventory(C);budget();save();budget()
 except BaseException as e:result.update(status='FAIL_RETAINED_FINAL_GUARD',final_guard_error=repr(e),final_guard_traceback=traceback.format_exc())
 save();print(json.dumps({k:result.get(k) for k in ('status','error','final_guard_error')}),flush=True)
raise SystemExit(0 if result['status'].startswith('PASS_') else 1)
