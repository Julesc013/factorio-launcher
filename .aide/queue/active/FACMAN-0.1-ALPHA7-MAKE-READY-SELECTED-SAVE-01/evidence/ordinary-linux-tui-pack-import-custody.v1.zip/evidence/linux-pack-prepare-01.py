from pathlib import Path
import ast,hashlib,json
E=Path(__file__).resolve().parent
text=(E/'snapshot-producer-linux-delivered-namespace-01.py').read_text()
text=text.replace('snapshot-producer-linux-delivered-evidence-01','linux-pack-raw-01').replace('snapshot-producer-linux-delivered-review-01.json','linux-pack-preexecution-review-01.json')
text=text.replace("a=json.loads((E/'snapshot-producer-linux-delivered-package-admission-01.json').read_bytes());peak=json.loads((E/'snapshot-producer-linux-delivered-source-and-peak-admission-01.json').read_bytes())\nassert peak['calculated_peak']<512*1024**2 and sha(E/'snapshot-producer-linux-delivered-package-admission-01.json')==peak['package_admission_sha256']", "a=json.loads((E/'linux-pack-admission-01.json').read_bytes());assert a['calculated_peak']<512*1024**2\nV=W/'validators-linux';cached=json.loads((E/'joined-final-input-linux-existing-validators-review-01.json').read_bytes())\nfor name,row in cached['verified_files'].items():assert sha(V/name)==row['sha256']")
text=text.replace("source_names=['tools/package/runtime_identity.py','tests/test_presentation_snapshot_create.py','tests/test_presentation_snapshot_restore.py','tests/test_tui_product.py','runtime/factorio/snapshots/flb_factorio_snapshots.cpp']", "source_names=['tools/package/runtime_identity.py','tests/test_presentation_pack_import.py','tests/test_portable_modpack_import.py','tests/test_make_ready_joined.py','tests/test_local_modset_solver.py','tests/test_tui_product.py','tools/requirements-dev.lock']")
text=text.replace('snapshot-producer-linux-delivered-namespace-result-01.json','linux-pack-namespace-result-01.json').replace('snapshot-producer-linux-delivered-'+"'+kind+'-01.tar.gz",'linux-pack-'+"'+kind+'-01.tar.gz")
needle="record['private_mountinfo']="
pos=text.index(needle)
text=text[:pos]+"subprocess.run(['/usr/bin/mount','--bind',str(V),str(V)],check=True,timeout=30);mounted.append(V)\n subprocess.run(['/usr/bin/mount','-o','remount,bind,ro',str(V)],check=True,timeout=30)\n "+text[pos:]
text=text.replace("(O/'objects').chmod(0o777)","(O/'objects').chmod(0o777)\n assert [line.split(':',1)[0].strip() for line in Path('/proc/net/dev').read_text().splitlines()[2:]]==['lo']")
text=text.replace('snapshot-producer-linux-delivered-worker-01.py','linux-pack-worker-01.py').replace('snapshot-producer-linux-delivered-worker-01.stdout','linux-pack-worker-01.stdout').replace('snapshot-producer-linux-delivered-worker-01.stderr','linux-pack-worker-01.stderr')
text=text.replace("(O/'worker-result.json')","(E/'linux-pack-worker-result-01.json')").replace('PASS_BOUNDED_DELIVERED_LINUX_SNAPSHOT_CLI_AND_ORDINARY_TUI','PASS_DELIVERED_LINUX_PACK_IMPORT_AND_ORDINARY_RECOVERY').replace('PASS_BOUNDED_PRIVATE_TMPFS_LINUX_DELIVERED_SNAPSHOT','PASS_PRIVATE_TMPFS_LINUX_PACK_IMPORT_AND_RECOVERY').replace('snapshot-producer-linux-delivered-synthetic-fixture-state-01.tar','linux-pack-synthetic-fixture-state-01.tar')
text=text.replace("assert sum(p.stat().st_size for p in O.rglob('*') if p.is_file())<128*1024**2","assert sum(p.stat().st_size for p in O.rglob('*') if p.is_file())<64*1024**2")
text=text.replace("source_bind_absent=not os.path.ismount(R)","source_bind_absent=not os.path.ismount(R),validators_bind_absent=not os.path.ismount(V)")
ast.parse(text);p=E/'linux-pack-namespace-01.py';assert not p.exists();p.write_text(text)
print('Prepared namespace',hashlib.sha256(p.read_bytes()).hexdigest())
