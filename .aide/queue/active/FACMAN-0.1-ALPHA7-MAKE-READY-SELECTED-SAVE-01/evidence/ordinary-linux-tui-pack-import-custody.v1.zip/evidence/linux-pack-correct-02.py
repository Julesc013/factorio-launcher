from pathlib import Path
import ast,hashlib,json
E=Path(__file__).resolve().parent
for kind in ('worker','namespace','launch'):
 text=(E/f'linux-pack-{kind}-01.py').read_text()
 for old,new in [('linux-pack-worker-01','linux-pack-worker-02'),('linux-pack-namespace-01','linux-pack-namespace-02'),('linux-pack-launch-result-01','linux-pack-launch-result-02'),('linux-pack-preexecution-review-01','linux-pack-preexecution-review-02'),('linux-pack-raw-01','linux-pack-raw-02'),('linux-pack-synthetic-fixture-state-01','linux-pack-synthetic-fixture-state-02'),('linux-pack-owned-execution-01','linux-pack-owned-execution-02'),('linux-pack-preexec-doctor-01','linux-pack-preexec-doctor-02')]:text=text.replace(old,new)
 if kind=='worker':
  text=text.replace("    try:\n     ident=identity(int(proc.name))", "    try:\n     # Filter public stat before privileged image/status observation; namespace\n     # PID1 and unrelated groups are outside this owned primary's custody.\n     summary=(proc/'stat').read_text().rsplit(')',1)[1].split()\n     if int(summary[2])!=p.pid:continue\n     ident=identity(int(proc.name))")
  text=text.replace("  if p.poll() is None:row['safety_termination']=True;os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=10)","  if p.poll() is None:row['safety_termination']=True;os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=10)\n  row['final_observed_primary_exit']=p.returncode")
 ast.parse(text);p=E/f'linux-pack-{kind}-02.py';assert not p.exists();p.write_text(text);print(p.name,hashlib.sha256(p.read_bytes()).hexdigest())
