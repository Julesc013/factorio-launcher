import hashlib,io,json,os,shutil,subprocess,tarfile,zipfile
from pathlib import Path,PurePosixPath
E=Path(__file__).resolve().parent;W=E.parent;R=Path(r'D:\Projects\Factorio\factorio-launcher')
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1')
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha((W/'.facman-development-root.v1.json').read_bytes())=='30d72706c486ff20eed8b1947a920caa0a4e2d43820abbaf0ff78d12ab9f697c'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='8bae82fbed257224164711eb2c57e693e4bf63d6'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R)
assert shutil.disk_usage(W).free-512*1024**2>12*1024**3
out=E/'linux-pack-admission-01.json';archive=E/'linux-pack-original-artifact-01.zip';assert not out.exists() and not archive.exists()
with archive.open('xb') as stream:subprocess.run(['gh','api','repos/Julesc013/factorio-launcher/actions/artifacts/12109725963/zip'],stdout=stream,check=True,timeout=180)
record=dict(artifact_id=12109725963,run=39053131459,head='c30d9f72cc94d5daa9c774f59341b307fa138f39',compiled_source='08d91a32fd41cddfaafa87c8bbd1c943f247526d',source_tree='ed24123d835b43b8758de71475261e7c2a333940',parents=['2b1e20e916162157145cbd40228f08a43b7e33f8','c30d9f72cc94d5daa9c774f59341b307fa138f39'],artifact_sha256=sha(archive.read_bytes()),artifact_bytes=archive.stat().st_size,packages={})
with zipfile.ZipFile(archive) as z:
 record['artifact_members']={n:dict(bytes=z.getinfo(n).file_size) for n in z.namelist()}
 for kind in ('cli','tui'):
  names=[n for n in z.namelist() if n.endswith('.tar.gz') and ('-'+kind+'-' in n or '/'+kind+'/' in n)]
  assert len(names)==1,names
  data=z.read(names[0]);p=E/('linux-pack-'+kind+'-01.tar.gz');assert not p.exists();p.write_bytes(data)
  with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:
   members=t.getmembers();files={}
   for m in members:
    path=PurePosixPath(m.name);assert not path.is_absolute() and '..' not in path.parts and (m.isfile() or m.isdir())
    if m.isfile():files[m.name]=sha(t.extractfile(m).read())
   record['packages'][kind]=dict(member=names[0],tar_sha256=sha(data),expanded_bytes=sum(m.size for m in members),file_inventory=files)
record['calculated_peak']=archive.stat().st_size+sum((E/('linux-pack-'+k+'-01.tar.gz')).stat().st_size+p['expanded_bytes'] for k,p in record['packages'].items())+128*1024**2
assert record['calculated_peak']<512*1024**2
out.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ('packages','artifact_members')}));print([(k,p['member'],p['expanded_bytes'],len(p['file_inventory'])) for k,p in record['packages'].items()])
