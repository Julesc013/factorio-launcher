import hashlib,json,os,shutil,signal,subprocess,tarfile,time,traceback
from pathlib import Path,PurePosixPath
E=Path(__file__).resolve().parent;W=E.parent;R=Path('/mnt/d/Projects/Factorio/factorio-launcher');M=E/'linux-delivered-private-01';O=E/'linux-pack-raw-03'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert os.getpid()==1 and os.getuid()==0 and os.readlink('/proc/self/ns/mnt')!=os.environ['FACMAN_PARENT_MOUNT_NAMESPACE']
marker=json.loads((W/'.facman-development-root.v1.json').read_bytes());assert marker['owner']=='facman-development' and marker['task_id']=='task/facman-world-restore-retention-01'
review=json.loads((E/'linux-pack-preexecution-review-03.json').read_bytes());assert review['verdict']=='PASS_BOUNDED_LINUX_PACK_DRIVER' and all(sha(E/n)==h for n,h in review['controller_hashes'].items())
assert sha(E/'linux-pack-admission-01.json')==review['admission_sha256']
a=json.loads((E/'linux-pack-admission-01.json').read_bytes());assert a['calculated_peak']<512*1024**2
V=W/'validators-linux';cached=json.loads((E/'joined-final-input-linux-existing-validators-review-01.json').read_bytes())
for name,row in cached['verified_files'].items():assert sha(V/name)==row['sha256']
source_names=['tools/package/runtime_identity.py','tests/test_presentation_pack_import.py','tests/test_portable_modpack_import.py','tests/test_make_ready_joined.py','tests/test_local_modset_solver.py','tests/test_tui_product.py','tools/requirements-dev.lock']
source_names+=[p.relative_to(R).as_posix() for p in (R/'tests/fixtures/fake_factorio_install').rglob('*') if p.is_file()]
source_names+=['tests/fixtures/factorio_saves/valid_simple_save/starter.zip']
source_before={n:sha(R/n) for n in source_names};out=E/'linux-pack-namespace-result-03.json';assert not out.exists()
record=dict(status='PREPARING_PRIVATE_LINUX_SNAPSHOT_PROOF',mount_namespace=os.readlink('/proc/self/ns/mnt'),pid_namespace=os.readlink('/proc/self/ns/pid'),tmpfs_bytes=512*1024**2,physical_ext4=False,source_hashes=source_before,new_roots=0,new_caches=0,builds=0,packages={})
mounted=[];worker=None
save=lambda:out.write_text(json.dumps(record,indent=2)+'\n')
def reap():
 while True:
  try:pid,_=os.waitpid(-1,os.WNOHANG)
  except ChildProcessError:break
  if pid==0:break
def census():
 values=[]
 for path in Path('/proc').iterdir():
  if path.name.isdigit() and path.name!='1':
   try:values.append(dict(pid=int(path.name),command=(path/'cmdline').read_bytes().decode(errors='replace').replace('\0',' ')))
   except FileNotFoundError:pass
 return values
try:
 assert M.is_dir() and not list(M.iterdir()) and not os.path.ismount(M) and not O.exists()
 assert os.statvfs(W).f_bavail*os.statvfs(W).f_frsize>12*1024**3
 memory=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024;assert memory>1024**3;record['memory_available_before']=memory
 subprocess.run(['/usr/bin/mount','--make-rprivate','/'],check=True,timeout=30)
 subprocess.run(['/usr/bin/mount','--bind',str(R),str(R)],check=True,timeout=30);mounted.append(R)
 subprocess.run(['/usr/bin/mount','-o','remount,bind,ro',str(R)],check=True,timeout=30)
 subprocess.run(['/usr/bin/mount','-t','tmpfs','-o','size=512m,nosuid,nodev,mode=1777','facman-snapshot-delivered',str(M)],check=True,timeout=30);mounted.append(M)
 assert os.statvfs(M).f_blocks*os.statvfs(M).f_frsize==512*1024**2
 subprocess.run(['/usr/bin/mount','--bind',str(V),str(V)],check=True,timeout=30);mounted.append(V)
 subprocess.run(['/usr/bin/mount','-o','remount,bind,ro',str(V)],check=True,timeout=30)
 record['private_mountinfo']=[x for x in Path('/proc/self/mountinfo').read_text().splitlines() if str(M) in x or (' '+str(R)+' ') in x]
 for kind in ('cli','tui'):
  entry=a['packages'][kind];archive=E/('linux-pack-'+kind+'-01.tar.gz');assert sha(archive)==entry['tar_sha256'];target=M/('relocated FacMan '+kind+' \u03a9');target.mkdir()
  with tarfile.open(archive,'r:gz') as tar:
   members=tar.getmembers();assert sum(m.size for m in members)==entry['expanded_bytes']
   for member in members:
    path=PurePosixPath(member.name);assert not path.is_absolute() and '..' not in path.parts and (member.isfile() or member.isdir())
   tar.extractall(target,filter='data')
  assert {p.relative_to(target).as_posix():sha(p) for p in target.rglob('*') if p.is_file()}==entry['file_inventory']
  for path in (target,*target.rglob('*')):path.chmod((path.stat().st_mode&0o777)&~0o222)
  record['packages'][kind]=dict(path=str(target),tar_sha256=entry['tar_sha256'],files=len(entry['file_inventory']),binary_sha256=sha(target/'bin/facman'))
 consumer=M/'consumer';consumer.mkdir();consumer.chmod(0o777);home=consumer/'home';home.mkdir();home.chmod(0o777)
 fixture=consumer/'fixture-install';shutil.copytree(R/'tests/fixtures/fake_factorio_install',fixture)
 for path in (fixture,*fixture.rglob('*')):path.chmod((path.stat().st_mode&0o777)&~0o222)
 O.mkdir();O.chmod(0o777);(O/'objects').mkdir();(O/'objects').chmod(0o777)
 assert [line.split(':',1)[0].strip() for line in Path('/proc/net/dev').read_text().splitlines()[2:]]==['lo']
 env=dict(os.environ,TMPDIR=str(consumer),TEMP=str(consumer),TMP=str(consumer),PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='0')
 args=['/usr/bin/setpriv','--reuid=65534','--regid=65534','--clear-groups','/usr/bin/python3','-B',str(E/'linux-pack-worker-03.py')]
 with (E/'linux-pack-worker-03.stdout').open('xb') as stdout,(E/'linux-pack-worker-03.stderr').open('xb') as stderr:
  worker=subprocess.Popen(args,cwd=consumer,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  ticks=int(Path('/proc',str(worker.pid),'stat').read_text().rsplit(')',1)[1].split()[19]);record['worker']=dict(pid=worker.pid,start_ticks=ticks,pgid=os.getpgid(worker.pid),retained_before_wait=True);assert ticks>0 and record['worker']['pgid']==worker.pid;save()
  try:code=worker.wait(timeout=750)
  except subprocess.TimeoutExpired:
   record['worker_safety_cleanup']=True;os.killpg(worker.pid,signal.SIGKILL);code=worker.wait(timeout=15)
 record['worker_exit']=code;record['worker_proc_entry_after']=Path('/proc',str(worker.pid)).exists();assert not record['worker_proc_entry_after'] and not record.get('worker_safety_cleanup')
 result=json.loads((E/'linux-pack-worker-result-03.json').read_bytes());assert code==0 and result['status']=='PASS_DELIVERED_LINUX_PACK_IMPORT_AND_ORDINARY_RECOVERY'
 assert source_before=={n:sha(R/n) for n in source_before};record.update(status='PASS_PRIVATE_TMPFS_LINUX_PACK_IMPORT_AND_RECOVERY',source_inputs_unchanged=True,worker_result_sha256=sha(E/'linux-pack-worker-result-03.json'))
except BaseException as error:record.update(status='FAIL_RETAINED',error=str(error),traceback=traceback.format_exc())
finally:
 end=time.monotonic()+5
 while True:
  reap();remaining=census()
  if not remaining or time.monotonic()>=end:break
  time.sleep(.025)
 record['remaining_namespace_processes']=remaining
 if remaining:record['status']='FAIL_RETAINED_OWNED_NAMESPACE_PROCESSES_REMAIN'
 if M in mounted:
  record['tmpfs_used_bytes']=(os.statvfs(M).f_blocks-os.statvfs(M).f_bfree)*os.statvfs(M).f_frsize
  consumer=M/'consumer'
  if consumer.exists():
   assert sum(p.stat().st_size for p in consumer.rglob('*') if p.is_file())<32*1024**2
   archive=E/'linux-pack-synthetic-fixture-state-03.tar';assert not archive.exists()
   with tarfile.open(archive,'w') as tar:tar.add(consumer,arcname='consumer')
   assert archive.stat().st_size<32*1024**2;record['fixture_export']=dict(path=str(archive),sha256=sha(archive),bytes=archive.stat().st_size)
 if O.exists():
  assert sum(p.stat().st_size for p in O.rglob('*') if p.is_file())<64*1024**2
  record['evidence_before_unmount']={p.relative_to(O).as_posix():dict(sha256=sha(p),bytes=p.stat().st_size) for p in O.rglob('*') if p.is_file()}
 record['source_inputs_final']={n:sha(R/n) for n in source_before};save()
 if not remaining:
  for path in reversed(mounted):subprocess.run(['/usr/bin/umount',str(path)],check=True,timeout=30)
 else:record['teardown']='Private namespace lifecycle owns remaining failure processes; no PASS'
 record.update(private_mount_absent=not os.path.ismount(M),source_bind_absent=not os.path.ismount(R),validators_bind_absent=not os.path.ismount(V),private_parent_empty=not list(M.iterdir()))
 if record['status'].startswith('PASS_'):assert record['private_mount_absent'] and record['source_bind_absent'] and record['private_parent_empty'] and source_before==record['source_inputs_final']
 save();print(json.dumps({k:v for k,v in record.items() if k not in ('source_hashes','source_inputs_final','evidence_before_unmount')},indent=2),flush=True)
raise SystemExit(0 if record['status'].startswith('PASS_') else 1)
