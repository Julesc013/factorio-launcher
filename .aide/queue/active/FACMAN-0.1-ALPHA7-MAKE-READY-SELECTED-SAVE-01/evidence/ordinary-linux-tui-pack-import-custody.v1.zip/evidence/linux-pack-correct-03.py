from pathlib import Path
import ast,hashlib
E=Path(__file__).resolve().parent
for kind in ('worker','namespace','launch'):
 text=(E/f'linux-pack-{kind}-02.py').read_text()
 for name in ('worker','worker-result','namespace','namespace-result','launch-result','preexecution-review','raw','synthetic-fixture-state','owned-execution','preexec-doctor'):
  text=text.replace('linux-pack-'+name+'-02','linux-pack-'+name+'-03')
 if kind=='worker':
  start=text.index('   for proc in Path(\'/proc\').iterdir():');end=text.index('   if interrupt and not done',start)
  text=text[:start]+'''   # The POSIX supervisor gives each backend its own group. Establish
   # ancestry from public stat data before reading privileged image fields.
   public={}
   for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():continue
    try:
     fields=(proc/'stat').read_text().rsplit(')',1)[1].split()
     public[int(proc.name)]=dict(ppid=int(fields[1]),pgrp=int(fields[2]),start_ticks=int(fields[19]))
    except FileNotFoundError:pass
   related={p.pid};related.update(item['pid'] for fd,item in handles.values())
   while True:
    before=len(related);related.update(pid for pid,s in public.items() if s['ppid'] in related)
    if len(related)==before:break
   for pid in related-{p.pid}:
    try:
     ident=identity(pid)
     if ident['image']!=str(CLI):continue
     key=(ident['pid'],ident['start_ticks'])
     if key not in handles:
      fd=os.pidfd_open(pid)
      try:
       again=identity(pid)
       assert again['start_ticks']==ident['start_ticks']==public[pid]['start_ticks'] and again['ppid']==p.pid
       assert again['pgrp']==pid and again['image']==str(CLI) and again['uid']==again['gid']==[65534]*4 and again['groups']==[]
       item=dict(again,image_sha256=sha(CLI),pidfd_held=True);row['descendants'].append(item);handles[key]=(fd,item)
      except BaseException:os.close(fd);raise
    except (FileNotFoundError,ProcessLookupError):pass
''' +text[end:]
  text=text.replace("current['pgrp']==p.pid", "current['pgrp']==item['pgrp']==item['pid']")
  text=text.replace("  remaining=[]\n  for proc", "  remaining=[];owned_groups={p.pid}|{item['pgrp'] for fd,item in handles.values()}\n  row['owned_groups']=sorted(owned_groups)\n  for proc")
  text=text.replace("if int(s[2])==p.pid:remaining.append(int(proc.name))", "if int(s[2]) in owned_groups:remaining.append(int(proc.name))")
  text=text.replace("  if p.poll() is None:row['safety_termination']=True;os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=10)","  for fd,item in handles.values():\n   if not select.select([fd],[],[],0)[0]:\n    row['safety_termination']=True;item['safety_cleanup_signal']='SIGKILL via exact held pidfd';signal.pidfd_send_signal(fd,signal.SIGKILL)\n  if p.poll() is None:row['safety_termination']=True;os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=10)")
  # Keep the already observed natural normal journey; only the concretely
  # failed interruption observer is rerun in a fresh owned consumer.
  start=text.index("  normal=C/'normal Ω'");end=text.index("  interrupted=C/'interrupted Ω'",start)
  text=text[:start]+'''  previous=json.loads((E/'linux-pack-worker-result-02.json').read_bytes());assert previous['status']=='FAIL_RETAINED' and previous['normal']['protected_preserved'] and previous['intentional_loss'] is None
  normal_calls=[]
  for c in previous['calls']:
   if any('interrupted Ω' in arg for arg in c['args']):break
   assert c['normal_wait'] and c['exit_code']==0 and c['group_empty'] and not c['safety_termination'];normal_calls.append(c)
  assert len([c for c in normal_calls if 'tui' in c['args']])==3
  result['normal_reused']=dict(source='linux-pack-worker-result-02.json',sha256=sha(E/'linux-pack-worker-result-02.json'),normal=previous['normal'],calls=normal_calls,descendant_custody_not_observed=True)
''' +text[end:]
 ast.parse(text);p=E/f'linux-pack-{kind}-03.py';assert not p.exists();p.write_text(text);print(p.name,hashlib.sha256(p.read_bytes()).hexdigest())
