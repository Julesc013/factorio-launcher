import ast,hashlib,json,os,shutil,subprocess,sys,time,traceback
from pathlib import Path
E=Path(__file__).resolve().parent;W=E.parent;R=Path(r'D:\Projects\Factorio\factorio-launcher');sys.path.insert(0,str(R))
from tools import provider_canary_process as owned
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',TEMP=str(W/'t'),TMP=str(W/'t'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
module=ast.parse((E/'snapshot-producer-linux-delivered-launch-01.py').read_text());nodes=[n for n in module.body if (isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('probe','query')) or (isinstance(n,ast.FunctionDef) and n.name=='census')];assert len(nodes)==3
exec(compile(ast.Module(body=nodes,type_ignores=[]),'retained-readonly-census','exec'))
out=E/'linux-pack-launch-result-01.json';assert not out.exists();record=dict(status='ADMISSION',observations=[],new_roots=0,new_clones=0,new_worktrees=0,native_builds=0,peak_bytes=512*1024**2)
def save():out.write_text(json.dumps(record,indent=2)+'\n')
def guard():
 assert sha(W/'.facman-development-root.v1.json')=='30d72706c486ff20eed8b1947a920caa0a4e2d43820abbaf0ff78d12ab9f697c'
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='8bae82fbed257224164711eb2c57e693e4bf63d6' and not subprocess.check_output(['git','status','--porcelain'],cwd=R)
 review=json.loads((E/'linux-pack-preexecution-review-01.json').read_bytes());assert review['verdict']=='PASS_BOUNDED_LINUX_PACK_DRIVER' and all(sha(E/n)==h for n,h in review['controller_hashes'].items())
 assert sha(E/'linux-pack-admission-01.json')==review['admission_sha256']
try:
 guard();previous=None;cycles=0
 while True:
  observation=census();observation['windows'].sort(key=lambda x:x['ProcessId']);observation['linux']['active'].sort(key=lambda x:x['pid'])
  if observation!=previous:record['observations'].append(observation);save();previous=observation
  if not observation['windows'] and not observation['linux']['active']:break
  record['status']='WAITING_FOREIGN_WORK_UNTOUCHED';save();time.sleep((30,45,60)[min(cycles,2)]);cycles+=1
 guard();record['admission_wait_cycles']=cycles
 measured=owned.command([sys.executable,'-B','tools/workspace_hygiene.py','doctor','--measure'],cwd=R,environment=dict(os.environ),timeout=240,directory=E/'linux-pack-preexec-doctor-01',output_limit=2*1024**2,wait_for_job_empty_after_primary=True)
 assert measured.receipt['job_empty_observed'] and measured.receipt['primary_stopped'];doctor=json.loads(measured.stdout)
 assert len(doctor['task_roots'])==8 and set(doctor['violations'])<={'unmanaged_secondary_worktrees_present'} and doctor['task_root_bytes']+512*1024**2<20*1024**3 and shutil.disk_usage(W).free-512*1024**2>12*1024**3
 record['resource_revalidation']=dict(bytes=doctor['task_root_bytes'],free=shutil.disk_usage(W).free,doctor_receipt_sha256=sha(measured.directory/'receipt.json'))
 guard();linux_e='/mnt/d/'+str(E)[3:].replace('\\','/')
 argv=['wsl.exe','-d','Ubuntu-24.04','-u','root','--exec','/usr/bin/env','FACMAN_PARENT_MOUNT_NAMESPACE='+observation['linux']['mount_namespace'],'FACMAN_DEV_ROOT=/mnt/d/Projects/Factorio/.task-builds','PYTHONDONTWRITEBYTECODE=1','PYTHONUTF8=1','/usr/bin/timeout','--signal=TERM','--kill-after=15s','900s','/usr/bin/unshare','--mount','--pid','--net','--fork','--mount-proc','--kill-child=SIGKILL','/usr/bin/python3','-B',linux_e+'/linux-pack-namespace-01.py']
 record.update(status='RUNNING_FINITE_OWNED_LINUX_PACKAGE_JOB',argv=argv);save()
 cap=owned.command(argv,cwd=R,environment=dict(os.environ),timeout=930,directory=E/'linux-pack-owned-execution-01',output_limit=2*1024**2,wait_for_job_empty_after_primary=True)
 record.update(exit_code=cap.returncode,owned_receipt_sha256=sha(cap.directory/'receipt.json'))
 assert cap.ok and cap.receipt['primary_stopped'] and cap.receipt['job_empty_observed'] and not cap.receipt['job_terminated'],(cap.stdout+cap.stderr).decode(errors='replace')[-4000:]
 assert json.loads((E/'linux-pack-namespace-result-01.json').read_bytes())['status']=='PASS_PRIVATE_TMPFS_LINUX_PACK_IMPORT_AND_RECOVERY'
 record['status']='PASS_OWNED_DELIVERED_LINUX_PACK_IMPORT_AND_RECOVERY';guard()
except BaseException as e:record.update(status='FAIL_RETAINED',error=repr(e),traceback=traceback.format_exc())
finally:
 record['after']=census();save();print(json.dumps({k:v for k,v in record.items() if k not in ('argv','observations')}),flush=True)
raise SystemExit(0 if record['status'].startswith('PASS_') else 1)
