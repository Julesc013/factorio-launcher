import base64,hashlib,json,re,runpy,zlib
from pathlib import Path,PurePosixPath
digest=lambda data:hashlib.sha256(data).hexdigest()
SELECTION=[
 ('routing_and_exact_selected_context','one_ordinary_request_prepares_routing_and_exact_world_with_independent_receipts',2),
 ('ordinary_linear_tui','ordinary_tui_dispatches_one_confirmed_request_for_both_components',1)]
def extract(text,source,evidence_root,job_id):
    E=Path(evidence_root)
    records={};custodies={};retained=[]
    for line in text.splitlines():
        keep=True
        for prefix,target in [('delivered-tui-evidence: ',records),('delivered-tui-custody: ',custodies)]:
            if prefix in line:
                value=json.loads(line.split(prefix,1)[1]);mode=value['mode']
                assert mode not in target
                target[mode]=value
                if mode.startswith('joined-'):keep=False
        if keep:retained.append(line)
    assert len(records)==len(custodies)==11 and set(records)==set(custodies)
    original=runpy.run_path(str(E/'macos-delivered-pack-log-custody-01.py'))['extract']('\n'.join(retained),source,E,job_id)
    candidate=json.loads((Path(r'D:\Projects\Factorio\factorio-launcher')/'.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01/evidence/joined-make-ready-fixture-correction.v1.json').read_bytes())
    output=E/('make-ready-joined-mac-job-'+str(job_id));assert not output.exists();output.mkdir()
    accepted=[]
    for index,(method,scenario,expected_requests) in enumerate(SELECTION):
        mode='joined-'+scenario
        record=records[mode];custody=custodies[mode]
        test_id='tests.test_macos_delivered_tui.MacosDeliveredTuiTests.test_delivered_joined_make_ready_'+method
        assert record['test_id']==custody['test_id']==test_id and record['result']==custody['result']=='pass'
        assert record['backend_identity']==records['linear']['backend_identity'] and record['backend_identity']['compiled_source_revision']==source
        for key in ('build_identity','manifest_sha256','closure_sha256','profile_id'):assert record[key]==records['linear'][key]
        assert all(record[k] is True for k in ('consumer_cwd_outside_source','consumer_overrides_removed','pathless','package_readonly'))
        assert record['source_test_id']=='test_make_ready_joined.JoinedMakeReadyTests.test_'+scenario
        assert record['source_test_sha256']==candidate['source_scenario_git_blob_sha256']['joined']
        assert record['fault_controls']=={} and record['evidence_scope']=='produced_package_joined_preparation_source_fixture; no_real_game_or_human_claim'
        assert custody['schema']=='facman.macos_delivered_tui_custody.v1' and custody['encoding']=='zlib_base64'
        encoded=custody['payload_base64'];assert len(encoded)==custody['encoded_size_bytes']<=512*1024
        compressed=base64.b64decode(encoded,validate=True)
        assert len(compressed)==custody['compressed_size_bytes'] and digest(compressed)==custody['compressed_sha256']==record['custody_compressed_sha256']
        decoder=zlib.decompressobj();raw=decoder.decompress(compressed,6*1024**2+1)
        assert decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail
        assert len(raw)==custody['canonical_json_size_bytes']<=6*1024**2 and digest(raw)==custody['canonical_json_sha256']==record['custody_canonical_json_sha256']
        content=json.loads(raw)
        assert content['schema']=='facman.macos_delivered_tui_custody_content.v1' and content['mode']==mode and content['result']=='pass' and content['test_id']==test_id
        assert content['receipt']=={k:v for k,v in record.items() if k not in ('custody_compressed_sha256','custody_canonical_json_sha256')}
        files={}
        for name,value in content['files'].items():
            assert name=='calls.json' or re.fullmatch(r'objects/[0-9a-f]{64}',name)
            data=base64.b64decode(value['bytes_base64'],validate=True)
            assert len(data)==value['size_bytes']==custody['files'][name]['size_bytes'] and digest(data)==value['sha256']==custody['files'][name]['sha256']
            if name!='calls.json':assert name=='objects/'+digest(data)
            files[name]=data
        assert set(files)==set(custody['files']) and sum(map(len,files.values()))<=4*1024**2
        calls=json.loads(files['calls.json'])
        assert calls['schema']=='facman.macos_delivered_joined_calls.v1' and calls['source_test_id']==record['source_test_id']
        assert digest(files['calls.json'])==record['calls_sha256'] and calls['tests_run']==1
        assert not calls['errors'] and not calls['failures'] and not calls['skips']
        assert not calls['live_child_pids_before_safety_drain'] and not calls['safety_cleanup_terminations'] and calls['all_owned_children_drained'] is True
        assert 0<len(calls['calls'])==calls['call_count']<=512 and calls['scenario_elapsed_seconds']<=600 and calls['raw_stream_size_bytes']<=4*1024**2
        completed=set();tui_requests=0
        for call in calls['calls']:
            assert call['argv'][0]==call['executable'] and '/relocated FacMan Ω/bin/facman' in call['executable']
            assert call['cwd'] not in ('','.') and not call['source_backend_provider_overrides'] and call['environment_inputs']['PATH']==''
            assert not any(key.startswith('FACMAN_TEST_') for key in call['environment_inputs'])
            assert all(key in call for key in ('exit_code','stdout','stderr','before','after'))
            for inventory in (call['before'],call['after']):
                for name,item in inventory.items():
                    if 'sha256' in item:
                        data=files['objects/'+item['sha256']]
                        assert len(data)==item['size_bytes'] and digest(data)==item['sha256']
            is_tui=call['argv'][1]=='tui'
            direct='readiness.prepare_joined' in call['argv'] and 'action' in call['argv']
            if not (is_tui or direct):continue
            assert call['exit_code']==0 and call['stderr']==''
            if is_tui:
                assert 'Confirm Make Ready with current settings' in call['stdout'] and 'review remaining readiness checks' in call['stdout']
                assert 'space\nspace\nq\n' in call['stdin'];tui_requests+=1
            allowed={'.facman/action-receipts-v2/','transactions/','instances/main/config/config.ini','instances/main/metadata/save-refs/selected.zip.save-ref.v1.json'}
            for name,item in call['before'].items():
                if not any(name==p or (p.endswith('/') and name.startswith(p)) for p in allowed):assert call['after'].get(name)==item,(test_id,name)
            inventory=call['after']
            for name,item in inventory.items():
                if not name.startswith('.facman/action-receipts-v2/') or 'sha256' not in item:continue
                receipt=json.loads(files['objects/'+item['sha256']])
                if name=='.facman/action-receipts-v2/workspace-admission.v1.json':
                    assert receipt['schema']=='facman.presentation_workspace_admission.v1'
                    continue
                assert re.fullmatch(r'\.facman/action-receipts-v2/[0-9a-f]{64}\.v2\.json',name),name
                assert receipt['schema']=='facman.presentation_action_receipt.v2'
                if receipt['action_id']!='readiness.prepare_joined' or receipt['state']!='terminal':continue
                result=json.loads(receipt['result_json']);payload=result['action_payload']
                assert result['outcome']=='completed' and payload['schema']=='factorio.make_ready_joined_result.v1'
                assert payload['continuation']=='observe_readiness' and payload['completed_effects_verified'] is True
                assert payload['preparation_complete'] is False and payload['readiness_complete'] is False and payload['execution_started'] is False and payload['permit_issued'] is False
                assert [c['owner_command'] for c in payload['completed_components']]==['readiness.prepare_configuration','readiness.prepare_selected_save']
                for component in payload['completed_components']:
                    journal_name='transactions/'+component['transaction_id']+'.transaction.v1.json'
                    journal=json.loads(files['objects/'+inventory[journal_name]['sha256']])
                    context=json.loads(journal['operation_context'])
                    assert journal['state']=='complete' and journal['command_id']==component['owner_command']
                    assert context['operation_id']==receipt['operation_id'] and context['attempt_id']==receipt['attempt_id']
                    target=PurePosixPath(journal['target']).relative_to(PurePosixPath(call['workspace'])).as_posix()
                    assert int(journal['effect_file_identity'].split(':')[1])==inventory[target]['inode']
                    intended=context['config_text'] if journal['command_id']=='readiness.prepare_configuration' else context['sidecar_text']
                    assert files['objects/'+inventory[target]['sha256']]==intended.encode('utf-8')
                completed.add((call['workspace'],receipt['idempotency_key']))
        assert len(completed)==expected_requests
        assert tui_requests==(1 if index==1 else 0)
        case=output/f'case-{index+1:02d}';case.mkdir();(case/'objects').mkdir()
        for name,data in files.items():
            with (case/name).open('xb') as stream:stream.write(data)
        (case/'receipt.v1.json').write_text(json.dumps(record,indent=2)+'\n')
        accepted.append(dict(test_id=test_id,calls=len(calls['calls']),completed_two_owner_requests=len(completed),ordinary_tui_requests=tui_requests,
            calls_sha256=record['calls_sha256'],custody_canonical_json_sha256=record['custody_canonical_json_sha256'],decoded_bytes=sum(map(len,files.values()))))
    return dict(method_count=11,method_skips=0,retained_nine=original,new_joined_methods=accepted,completed_two_owner_requests=sum(c['completed_two_owner_requests'] for c in accepted),
        decoded_joined_evidence_directory=str(output),full_make_ready=False,canonical_installed_desktop=False,minimum_mac13=False,real_game=False,human=False,beta=False,rc=False)
