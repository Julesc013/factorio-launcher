import hashlib,json,os,re,sys,zipfile
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
sys.path.insert(0,str(R))
from tools import provider_canary_process as owned
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1')
Q=R/'.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
obs_path=E/'make-ready-joined-checked-integration-result-02.json';obs=json.loads(obs_path.read_bytes())
assert obs['status']=='merged_exact_source' and obs['required_checks_all_pass']
assert obs['source']=='002824ea9f2ac4d3844ec5141b455d5733a8008b'
assert obs['pr_state']['mergeCommit']['oid']=='3b12f8e36786ef8cdb5c3bb897440d1566b91c51'
rows=obs['observations'][-1]['checks'];assert all(r['state']=='SUCCESS' and r['bucket']=='pass' for r in rows)
row=next(r for r in rows if r['name']=='windows-native-package')
run_id,job_id=re.search(r'/actions/runs/(\d+)/job/(\d+)',row['link']).groups()
def cmd(label,args):
 r=owned.command(['gh',*args],cwd=R,environment=dict(os.environ),timeout=120,directory=E/('make-ready-joined-actual-seal01-'+label),output_limit=16*1024**2)
 assert r.ok and r.receipt['primary_stopped'] and r.receipt['job_empty_observed']
 return r.stdout
j=json.loads(cmd('windows-job',['api','repos/Julesc013/factorio-launcher/actions/jobs/'+job_id]))
assert str(j['run_id'])==run_id and j['status']=='completed' and j['conclusion']=='success'
run=json.loads(cmd('windows-run',['api','repos/Julesc013/factorio-launcher/actions/runs/'+run_id]))
assert run['head_sha']==obs['source'] and run['event']=='pull_request'
raw=cmd('windows-log',['api','repos/Julesc013/factorio-launcher/actions/jobs/'+job_id+'/logs'])
log=E/('make-ready-joined-windows-actual-job-'+job_id+'.log')
with log.open('xb') as f:f.write(raw)
text=raw.decode('utf-8','replace')
assert text.count('100% tests passed, 0 tests failed out of 55')==4
match=re.search(r'Ran (\d+) tests in [^\n]+\n[^\n]*\n[^\n]*OK(?: \(skipped=(\d+)\))?',text)
assert match
proof=obs['actual_mac_delivered_package_qualification'];assert proof['method_count']==11 and proof['method_skips']==0 and proof['completed_two_owner_requests']==3
archive=Q/'evidence/produced-joined-make-ready-custody.v1.zip'
names={Path(__file__).name,obs_path.name,log.name,'make-ready-joined-log-custody-04.py','make-ready-joined-checked-observer-02.py',
 'macos-delivered-pack-checked-observer-01.py','macos-delivered-pack-log-custody-01.py','macos-delivered-tui-log-custody-02.py',
 'macos-delivered-pack-independent-review-01.json','make-ready-joined-candidate-commit-result-02.json',
 'make-ready-joined-candidate-commit-review-02.json',Path(proof['log_path']).name,
 'make-ready-joined-postmerge-dev-sync-result-01.json','make-ready-joined-retirement-result-01.json'}
for root in (proof['decoded_joined_evidence_directory'],proof['retained_nine']['decoded_pack_evidence_directory'],proof['retained_nine']['retained_tui']['decoded_evidence_directory']):
 names.update(p.relative_to(E).as_posix() for p in Path(root).rglob('*') if p.is_file())
for label in ('windows-job','windows-run','windows-log'):
 names.update('make-ready-joined-actual-seal01-'+label+'/'+n for n in ('receipt.json','stdout.raw','stderr.raw'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest={n:sha(E/n) for n in sorted(names)}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 z.writestr('custody-manifest.json',json.dumps(manifest,indent=2,sort_keys=True)+'\n')
 for n in sorted(manifest):z.write(E/n,'evidence/'+n)
with zipfile.ZipFile(archive) as z:
 for n,d in manifest.items():assert hashlib.sha256(z.read('evidence/'+n)).hexdigest()==d
record=dict(schema='facman.joined_make_ready_accepted_slice.v1',reviewed_source=obs['source'],
 integration=obs['pr_state']['mergeCommit']['oid'],pr=417,compiled_mac_source=proof['compiled_checkout_source'],
 compiled_mac_tree=proof['compiled_checkout_tree'],compiled_mac_parents=proof['compiled_checkout_parents'],
 mac_run=proof['run_id'],mac_job=proof['job_id'],actual_mac_package_methods_passed=11,actual_mac_method_skips=0,
 actual_mac_native_tests=57,retained_mac_owner_methods=41,actual_mac_joined_source_methods=12,
 completed_joined_two_owner_requests=3,joined_package_results=proof['new_joined_methods'],
 retained_package_results=proof['retained_nine'],windows_run=int(run_id),windows_job=int(job_id),
 actual_windows_native_builds_passed=4,actual_windows_native_tests_per_build=55,windows_python_tests=int(match[1]),
 windows_expected_skips=int(match[2] or 0),windows_job_conclusion='success',windows_log_sha256=sha(log),
 required_checks=rows,required_checks_all_pass=True,observer_sha256=sha(obs_path),
 custody=archive.name,custody_sha256=sha(archive),custody_files=len(manifest),
 single_mac_package_factory=True,original_partial_v1_preserved=True,accepted_receipt_v2_preserved=True,
 runtime_fix_for_windows_test=False,torn_file_refusal_not_repair=True,
 live_windows_button_to_packaged_backend_pending=True,canonical_installed_desktop=False,
 minimum_mac13_physical_host=False,named_physical_host=False,real_game=False,human=False,whole_workunit=False,full_make_ready=False,beta=False,rc=False)
out=Q/'evidence/produced-joined-make-ready.v1.json'
with out.open('x',encoding='utf-8') as f:json.dump(record,f,indent=2);f.write('\n')
with (Q/'ExecPlan.md').open('a',encoding='utf-8',newline='\n') as f:f.write('\n### Accepted joined current-settings preparation slice\n\nPR417 integrated reviewed002824ea as dev3b12f8e3 after all required checks passed. The single script waited about89minutes without model polling, independently decoded all11actual Mac package methods and merged only the exact qualified source. The synthetic Mac checkout1a1928eb has the exact reviewed tree7644850b and expected base/source parents. Three ordinary joined requests (including TUI confirmation) retained two completed owner effects and preserved other inputs; readiness, process and permit authority remain false. All57Mac native tests,41retained owner methods and12joined source methods passed. The current Windows job passed all55native tests in each of four builds and its full Python qualification. The test-only startup synchronization correction retains exact changed-effect refusal; no runtime pause or policy limit changed. Task refs were retired and dev synchronized. This closes the admitted existing-instance joined preparation slice. Installation/profile/content reconstruction, live Windows packaged-button dispatch, full readiness/Play, canonical installed Desktop, physical/minimum/named hosts, real game, human and Beta/RC remain open. Continue the missing live Windows GUI-to-packaged-backend result using the existing passed Windows artifact.\n\nEvidence: evidence/produced-joined-make-ready.v1.json and hash-closed custody.\n')
print(json.dumps(dict(status='SEALED_ACTUAL_JOINED_SLICE',receipt=str(out),receipt_sha256=sha(out),archive_bytes=archive.stat().st_size,mac_methods=11,windows_native_builds=4,windows_native_tests=55,windows_python_tests=record['windows_python_tests'],remaining_live_GUI=True)))
