import base64,hashlib,json,re,zlib
from pathlib import Path
digest=lambda value:hashlib.sha256(value).hexdigest()
def extract(text,source,evidence_root,job_id):
 records={};custodies={}
 for line in text.splitlines():
  for prefix,target in [('delivered-tui-evidence: ',records),('delivered-tui-custody: ',custodies)]:
   if prefix in line:
    value=json.loads(line.split(prefix,1)[1]);mode=value['mode']
    assert mode in ('linear','fullscreen') and mode not in target,'duplicate or foreign delivered record'
    target[mode]=value
 assert set(records)==set(custodies)=={'linear','fullscreen'},'actual package proof or durable custody missing'
 output=Path(evidence_root)/('macos-delivered-tui-actual-job-'+str(job_id));assert not output.exists();output.mkdir()
 methods={'linear':'test_delivered_linear_selected_save_make_ready','fullscreen':'test_delivered_fullscreen_selected_save_make_ready_restores_terminal'}
 results=[]
 for mode in ('linear','fullscreen'):
  record,custody=records[mode],custodies[mode]
  assert record['schema']=='facman.macos_delivered_tui_result.v1' and record['profile_id']=='macos_portable_tui_x64'
  test_id='tests.test_macos_delivered_tui.MacosDeliveredTuiTests.'+methods[mode]
  assert record['test_id']==custody['test_id']==test_id and record['result']==custody['result']=='pass'
  assert record['backend_identity']['compiled_source_revision']==source and record['backend_identity']['compiled_source_dirty'] is False and record['backend_identity']['package_verified'] is True
  assert record['authenticity']=='not_proven_unsigned' and record['corroborating_observation_scope']=='same_source_providers_build; macos_portable_cli_x64; no_TUI_composition_claim'
  assert all(record[k] is True for k in ('consumer_cwd_outside_source','consumer_overrides_removed','pathless','package_readonly'))
  assert custody['schema']=='facman.macos_delivered_tui_custody.v1' and custody['encoding']=='zlib_base64'
  encoded=custody['payload_base64'];assert len(encoded)==custody['encoded_size_bytes']<=512*1024
  compressed=base64.b64decode(encoded,validate=True)
  assert len(compressed)==custody['compressed_size_bytes'] and digest(compressed)==custody['compressed_sha256']==record['custody_compressed_sha256']
  decoder=zlib.decompressobj();raw=decoder.decompress(compressed,6*1024*1024+1)
  assert decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail and len(raw)==custody['canonical_json_size_bytes']<=6*1024*1024
  assert digest(raw)==custody['canonical_json_sha256']==record['custody_canonical_json_sha256']
  content=json.loads(raw);assert content['schema']=='facman.macos_delivered_tui_custody_content.v1' and content['mode']==mode and content['result']=='pass' and content['test_id']==test_id
  original={k:v for k,v in record.items() if k not in ('custody_compressed_sha256','custody_canonical_json_sha256')};assert content['receipt']==original
  names={mode+'.terminal.log',mode+'.effects.json',mode+'.terminal-state.json'};assert set(content['files'])==set(custody['files'])==names
  files={}
  for name,value in content['files'].items():
   payload=base64.b64decode(value['bytes_base64'],validate=True)
   assert len(payload)==value['size_bytes']==custody['files'][name]['size_bytes'] and digest(payload)==value['sha256']==custody['files'][name]['sha256']
   files[name]=payload
  assert sum(map(len,files.values()))<=4*1024*1024
  assert digest(files[mode+'.terminal.log'])==record['terminal_log_sha256'] and digest(files[mode+'.effects.json'])==record['effects_sha256']
  assert digest(files[mode+'.terminal-state.json'])==record['terminal_state_sha256'] and record['terminal_control_result']=='pass'
  state=json.loads(files[mode+'.terminal-state.json']);assert state['schema']=='facman.macos_delivered_tui_terminal_state.v1'
  control=state['control'];assert control['schema']=='facman.darwin_terminal_control.v1' and control['result']=='pass'
  assert control['symbols']['PENDIN']==0x20000000 and len(control['observations'])==2
  for observation in control['observations']:
   assert observation['original']==observation['after_fionread']
   pending=base64.b64decode(observation['pending_input_base64'],validate=True)
   assert pending==base64.b64decode(observation['recovered_input_base64'],validate=True) and observation['fionread_count']==len(pending)
   expected=list(observation['original']);expected[3]|=control['symbols']['PENDIN'];assert expected==observation['immediate_after_restore']
  sessions=state['candidate_sessions'];assert len(sessions)==(3 if mode=='fullscreen' else 0)
  for index,session in enumerate(sessions):
   assert session['session_index']==index and session['fionread_count']==0 and session['original']==session['after_fionread']
   allowed=list(session['original']);allowed[3]|=control['symbols']['PENDIN']
   assert session['immediate_after_exit'] in (session['original'],allowed)
  effects=json.loads(files[mode+'.effects.json']);assert len(effects)==2 and [v['component'] for v in effects]==['routing_configuration','selected_save_declared_context']
  for effect in effects:
   receipt=effect['receipt'];request=json.loads(receipt['request_json']);result=json.loads(receipt['result_json']);journal=effect['owner_journal'];plan=effect['reviewed_plan']
   assert request['action_id']=='readiness.prepare' and request['launch_intent']=='load_save' and request['confirmation']=='explicit'
   assert digest(receipt['request_json'].encode())==receipt['request_fingerprint'] and digest(receipt['result_json'].encode())==receipt['result_digest']
   assert result['outcome']=='completed' and result['action_payload']['composition']=='partial'
   assert all(result['action_payload'][k] is False for k in ('readiness_complete','execution_started','permit_issued'))
   assert journal['state']=='complete' and plan['plan_sha256']==result['action_payload']['completed_components'][0]['plan_sha256']
   assert journal['effect_file_identity']==effect['published_file_identity'] and journal['expected_files'][0]['sha256']==effect['published_sha256']
   assert effect['install_preservation_verified'] is True
  if mode=='fullscreen':
   terminal=files[mode+'.terminal.log'];assert b'\x1b[?1049h' in terminal and b'\x1b[?25h\x1b[?1049l' in terminal
  for name,payload in files.items():
   with (output/name).open('xb') as stream:stream.write(payload)
  (output/(mode+'.v1.json')).write_text(json.dumps(record,indent=2)+'\n')
  results.append(dict(mode=mode,test_id=test_id,result='pass',package_source=source,backend_sha256=record['backend_identity']['backend_sha256'],build_identity=record['build_identity'],manifest_sha256=record['manifest_sha256'],closure_sha256=record['closure_sha256'],effects=2,terminal_log_sha256=record['terminal_log_sha256'],effects_sha256=record['effects_sha256'],terminal_state_sha256=record['terminal_state_sha256'],terminal_sessions=len(sessions),control_pending_bytes_preserved=True,custody_canonical_json_sha256=record['custody_canonical_json_sha256'],decoded_bytes=sum(map(len,files.values()))))
 assert records['linear']['backend_identity']==records['fullscreen']['backend_identity']
 assert records['linear']['manifest_sha256']==records['fullscreen']['manifest_sha256'] and records['linear']['closure_sha256']==records['fullscreen']['closure_sha256']
 return dict(method_count=2,method_skips=0,results=results,decoded_evidence_directory=str(output),full_make_ready=False,beta=False,rc=False)
