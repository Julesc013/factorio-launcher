import base64,hashlib,io,json,re,runpy,zipfile,zlib
from pathlib import Path
digest=lambda value:hashlib.sha256(value).hexdigest()
SELECTION=[
 ('exact_offline_reconstruction','exported_pack_reconstructs_offline_exact_bytes_and_rebound_local_lock',3),
 ('process_loss_before_staging','process_loss_before_staging_reconstructs_from_the_original_durable_source_binding',1),
 ('process_loss_partial_raw_and_generated','process_loss_adopts_original_lock_and_recovers_partial_raw_and_generated_states',2),
 ('recovery_itself_interrupted','recovery_before_staging_can_itself_be_interrupted_after_a_complete_entry',1),
 ('changed_and_torn_objects_preserved','partial_recovery_refuses_changed_source_context_inventory_and_markers_without_effects',0),
 ('foreign_partial_objects_preserved','incomplete_extraction_is_retained_and_recovery_does_not_delete_it',0),
 ('ordinary_semantic_recovery','process_loss_recovers_through_ordinary_recovery_action',3),
]
def extract(text,source,evidence_root,job_id):
 E=Path(evidence_root);records={};custodies={};tui_lines=[]
 for line in text.splitlines():
  keep=True
  for prefix,target in [('delivered-tui-evidence: ',records),('delivered-tui-custody: ',custodies)]:
   if prefix in line:
    value=json.loads(line.split(prefix,1)[1]);mode=value['mode'];assert mode not in target
    target[mode]=value
    if mode.startswith('pack-'):keep=False
  if keep:tui_lines.append(line)
 expected={'linear','fullscreen'}|{'pack-'+scenario for _,scenario,_ in SELECTION};assert set(records)==set(custodies)==expected
 retained=runpy.run_path(str(E/'macos-delivered-tui-log-custody-02.py'))['extract']('\n'.join(tui_lines),source,E,job_id)
 candidate=json.loads((E/'macos-delivered-pack-independent-review-01.json').read_bytes())
 output=E/('macos-delivered-pack-job-'+str(job_id));assert not output.exists();output.mkdir()
 accepted=[];total_calls=0;total_reconstructions=0;total_killed=0
 for index,(method,scenario,min_reconstructions) in enumerate(SELECTION):
  mode='pack-'+scenario;record=records[mode];custody=custodies[mode]
  test_id='tests.test_macos_delivered_tui.MacosDeliveredTuiTests.test_delivered_pack_'+method
  assert record['test_id']==custody['test_id']==test_id and record['result']==custody['result']=='pass'
  assert record['backend_identity']==records['linear']['backend_identity'] and record['backend_identity']['compiled_source_revision']==source
  for key in ('build_identity','manifest_sha256','closure_sha256','profile_id'):assert record[key]==records['linear'][key]
  assert all(record[k] is True for k in ('consumer_cwd_outside_source','consumer_overrides_removed','pathless','package_readonly'))
  role='presentation' if index==6 else 'portable';source_module='test_presentation_pack_import' if index==6 else 'test_portable_modpack_import';source_class='PresentationPackImportTests' if index==6 else 'PortableModpackImportTests'
  assert record['source_test_id']==source_module+'.'+source_class+'.test_'+scenario and record['source_test_sha256']==candidate['source_scenario_git_blob_sha256'][role]
  assert record['evidence_scope']=='produced_package_offline_source_fixture; no_real_game_or_human_claim'
  assert custody['schema']=='facman.macos_delivered_tui_custody.v1' and custody['encoding']=='zlib_base64'
  encoded=custody['payload_base64'];assert len(encoded)==custody['encoded_size_bytes']<=512*1024
  compressed=base64.b64decode(encoded,validate=True);assert len(compressed)==custody['compressed_size_bytes'] and digest(compressed)==custody['compressed_sha256']==record['custody_compressed_sha256']
  decoder=zlib.decompressobj();raw=decoder.decompress(compressed,6*1024*1024+1)
  assert decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail and len(raw)==custody['canonical_json_size_bytes']<=6*1024*1024 and digest(raw)==custody['canonical_json_sha256']==record['custody_canonical_json_sha256']
  content=json.loads(raw);assert content['schema']=='facman.macos_delivered_tui_custody_content.v1' and content['mode']==mode and content['result']=='pass' and content['test_id']==test_id
  assert content['receipt']=={k:v for k,v in record.items() if k not in ('custody_compressed_sha256','custody_canonical_json_sha256')}
  files={}
  for name,value in content['files'].items():
   assert name=='calls.json' or re.fullmatch(r'objects/[0-9a-f]{64}',name)
   payload=base64.b64decode(value['bytes_base64'],validate=True);assert len(payload)==value['size_bytes']==custody['files'][name]['size_bytes'] and digest(payload)==value['sha256']==custody['files'][name]['sha256']
   if name!='calls.json':assert name=='objects/'+digest(payload)
   files[name]=payload
  assert set(files)==set(custody['files']) and sum(map(len,files.values()))<=4*1024*1024
  calls=json.loads(files['calls.json']);assert digest(files['calls.json'])==record['calls_sha256'] and calls['schema']=='facman.macos_delivered_pack_calls.v1' and calls['source_test_id']==record['source_test_id']
  assert calls['tests_run']==1 and not calls['errors'] and not calls['failures'] and not calls['skips']
  assert not calls['live_child_pids_before_safety_drain'] and not calls['safety_cleanup_terminations'] and calls['all_owned_children_drained'] is True
  assert 0<len(calls['calls'])==calls['call_count']<=512 and calls['scenario_elapsed_seconds']<=600 and calls['raw_stream_size_bytes']<=4*1024*1024
  reconstructions=set();killed=0;refusals=0
  for call in calls['calls']:
   assert call['argv'][0]==call['executable'] and '/relocated FacMan Ω/bin/facman' in call['executable'] and call['cwd'] not in ('','.')
   assert not call['source_backend_provider_overrides'] and call['environment_inputs']['PATH']==''
   assert all(key in call for key in ('exit_code','stdout','stderr','before','after')) and isinstance(call['stdout'],str) and isinstance(call['stderr'],str)
   for key,value in call['environment_inputs'].items():
    if key.startswith('FACMAN_TEST_'):
     suffix=key.removeprefix('FACMAN_TEST_MODPACK_IMPORT_');assert key.startswith('FACMAN_TEST_MODPACK_IMPORT_') and value in record['fault_controls'][suffix]
   for inventory in (call['before'],call['after']):
    for name,item in inventory.items():
     if 'sha256' in item:
      data=files['objects/'+item['sha256']];assert len(data)==item['size_bytes'] and digest(data)==item['sha256']
   if 'child_pid' in call:
    assert call['termination']=='test_owned_kill' and call['exit_code']==-9;killed+=1
   if call['stdout'].strip():
    envelope=json.loads(call['stdout']);assert envelope['schema']=='facman.transport_response.v2'
    payload=envelope.get('payload') or {};error=envelope.get('error') or {};refusals+=int(payload.get('refusal',{}).get('code',error.get('code'))=='recovery_modpack_import_unsafe')
   inventory=call['after'];prefix='instances/reconstructed/';receipt_name=prefix+'modpack-import.v1.json'
   if receipt_name in inventory:
    receipt=json.loads(files['objects/'+inventory[receipt_name]['sha256']]);archive_bytes=files['objects/'+receipt['archive_sha256']]
    assert digest(archive_bytes)==receipt['archive_sha256'] and len(archive_bytes)==receipt['archive_size']
    with zipfile.ZipFile(io.BytesIO(archive_bytes)) as archive:
     for name in ('modset-lock.v1.json','modpack-manifest.v1.json','mods/simple_1.0.0.zip','mods/mod-list.json','mods/mod-settings.dat'):
      if name in archive.namelist():assert archive.read(name)==files['objects/'+inventory[prefix+name]['sha256']]
      else:assert prefix+name not in inventory
     assert digest(archive.read('modset-lock.v1.json'))==receipt['source_lock_sha256'] and digest(archive.read('modpack-manifest.v1.json'))==receipt['source_manifest_sha256']
    lock_bytes=files['objects/'+inventory[prefix+'mods/modset-lock.v1.json']['sha256']];lock=json.loads(lock_bytes)
    assert digest(lock_bytes)==receipt['target_lock_sha256'] and lock['instance_id']=='reconstructed' and next(mod['source'] for mod in lock['mods'] if mod['name']=='base')=='install-data:'+receipt['install_ref']
    assert prefix+'mods/unselected_1.0.0.zip' not in inventory
    reconstructions.add((call['workspace'],receipt['archive_sha256']))
  assert len(reconstructions)>=min_reconstructions
  if index in (1,2,3,6):assert killed>0
  if index in (4,5):assert refusals>0 and not reconstructions
  case=output/f'case-{index+1:02d}';case.mkdir();(case/'objects').mkdir()
  for name,value in files.items():
   with (case/name).open('xb') as stream:stream.write(value)
  (case/'receipt.v1.json').write_text(json.dumps(record,indent=2)+'\n')
  accepted.append(dict(test_id=test_id,source_test_id=record['source_test_id'],mode=mode,calls=len(calls['calls']),reconstructions=len(reconstructions),sigkill_cases=killed,preserved_unsafe_refusals=refusals,calls_sha256=record['calls_sha256'],custody_canonical_json_sha256=record['custody_canonical_json_sha256'],decoded_bytes=sum(map(len,files.values()))))
  total_calls+=len(calls['calls']);total_reconstructions+=len(reconstructions);total_killed+=killed
 return dict(method_count=9,method_skips=0,retained_tui=retained,new_pack_methods=accepted,actual_cli_calls=total_calls,independently_verified_reconstructions=total_reconstructions,actual_sigkill_cases=total_killed,decoded_pack_evidence_directory=str(output),torn_refusal_not_repair=True,full_make_ready=False,beta=False,rc=False)
