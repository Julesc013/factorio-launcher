from pathlib import Path
E=Path(__file__).resolve().parent
origin=E/'macos-delivered-pack-checked-observer-01.py'
code=origin.read_text(encoding='utf-8')
changes={
 'e0809f002865906dcaee56455a88761ccad0e56e':'002824ea9f2ac4d3844ec5141b455d5733a8008b',
 'e504c5ed6d7366f0cf43df5105ae8ce415a8ffdc':'dff35d6bbc38a1b3f05e1bc1d79b6a5c6b5b91bc',
 'macos-delivered-pack-':'make-ready-joined-',
 'COMMITTED_REVIEWED_DELIVERED_TUI_CANDIDATE':'COMMITTED_QUALIFIED_JOINED_SOURCE_CANDIDATE',
 'pr=416':'pr=417',"'416'":"'417'",'assert len(actual_records)==9':'assert len(actual_records)==11',
 "make-ready-joined-candidate-commit-result-01.json":"make-ready-joined-candidate-commit-result-02.json",
 "make-ready-joined-candidate-commit-review-01.json":"make-ready-joined-candidate-commit-review-02.json",
 "make-ready-joined-checked-integration-result-01.json":"make-ready-joined-checked-integration-result-02.json",
 "make-ready-joined-candidate-commit-message-01.txt":"make-ready-joined-candidate-commit-message-02.txt",
 "make-ready-joined-merge-body-01.txt":"make-ready-joined-merge-body-02.txt",
 "make-ready-joined-log-custody-01.py":"make-ready-joined-log-custody-04.py",
 "make-ready-joined-observer01-":"make-ready-joined-observer02-"}
for old,new in changes.items():
 assert old in code,old
 code=code.replace(old,new)
marker='    import runpy\n'
extra="""    joined_source=[]
    frozen=json.loads((E/'make-ready-joined-frozen-06.json').read_bytes())
    for name in frozen['test_selection']['methods']:
        if name=='test_compiled_ordinary_gui_control_preserves_actual_preparation_receipt':continue
        test_id='tests.test_make_ready_joined.JoinedMakeReadyTests.'+name
        lines=[line for line in text.splitlines() if f'{name} ({test_id})' in line]
        assert len(lines)==1 and re.search(r'\\.\\.\\. ok\\s*$',lines[0]),('joined Mac source method',test_id)
        joined_source.append(test_id)
    assert len(joined_source)==12
    record['actual_mac_joined_source_methods_passed']=joined_source
"""
assert code.count(marker)==1
code=code.replace(marker,extra+marker,1)
exec(compile(code,str(origin)+'#joined417-correction02','exec'))
