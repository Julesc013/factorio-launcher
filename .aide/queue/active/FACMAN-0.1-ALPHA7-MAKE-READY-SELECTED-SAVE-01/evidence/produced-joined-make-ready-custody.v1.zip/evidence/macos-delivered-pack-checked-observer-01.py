
import ast,re,datetime,hashlib,json,os,subprocess,sys,time,traceback
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher')
W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e')
E=W/'evidence';sys.dont_write_bytecode=True;sys.path.insert(0,str(R))
from tools import provider_canary_process as owned
S='e0809f002865906dcaee56455a88761ccad0e56e';REPO='Julesc013/factorio-launcher'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
qualified=json.loads((E/'macos-delivered-pack-candidate-commit-result-01.json').read_bytes())
assert qualified['status']=='COMMITTED_REVIEWED_DELIVERED_TUI_CANDIDATE' and qualified['source']==S
assert json.loads((E/'macos-delivered-pack-candidate-commit-review-01.json').read_bytes())['verdict']=='PASS'
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1')
out=E/'macos-delivered-pack-checked-integration-result-01.json'
assert not out.exists()
record=dict(schema='facman.checked_acceptance_integration_observation.v1',source=S,pr=416,
    qualification_submission_sha256=sha(E/'macos-delivered-pack-candidate-commit-result-01.json'),
    status='observing_single_existing_required_campaign',new_ci_jobs=0,new_candidates=0,goal_status_mutated=False,
    local_checkout_mutated=False,observations=[],transient_network_failures=[],commands=[])
counter=0
def save():out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
def call(label,args,timeout=45):
    global counter
    counter+=1
    r=owned.command(['gh',*args],cwd=R,environment=dict(os.environ),timeout=timeout,output_limit=16*1024*1024,
        directory=E/f'macos-delivered-pack-observer01-{counter:03d}-{label}',wait_for_job_empty_after_primary=True)
    record['commands'].append(dict(label=label,receipt=str(r.directory/'receipt.json'),sha256=sha(r.directory/'receipt.json'),
        exit=r.returncode,termination=r.receipt['termination'],primary_stopped=r.receipt['primary_stopped'],job_empty=r.receipt['job_empty_observed']))
    save()
    assert r.receipt['primary_stopped'] and r.receipt['job_empty_observed'],label
    return r
def transient(r):
    raw=(r.stdout+r.stderr).decode('utf-8','replace')
    return r.receipt['termination']=='completed' and any(s in raw for s in (
        'HTTP 502','HTTP 503','HTTP 504','TLS handshake timeout','connection reset','unexpected EOF','i/o timeout'))

def verify_mac(rows):
    mac=[x for x in rows if x['name']=='macos-native-cli']
    assert len(mac)==1 and mac[0]['state']=='SUCCESS' and mac[0]['bucket']=='pass'
    match=re.search(r'/actions/runs/(\d+)/job/(\d+)',mac[0]['link']);assert match
    run_id,job_id=match.groups()
    job=call('mac-job',['api',f'repos/{REPO}/actions/jobs/{job_id}']);assert job.ok
    j=json.loads(job.stdout);assert str(j['run_id'])==run_id and j['status']=='completed' and j['conclusion']=='success' and j['name']=='macos-native-cli'
    workflow=call('mac-run',['api',f'repos/{REPO}/actions/runs/{run_id}']);assert workflow.ok
    w=json.loads(workflow.stdout);assert w['head_sha']==S and w['event']=='pull_request'
    logs=call('mac-actual-tests',['api',f'repos/{REPO}/actions/jobs/{job_id}/logs'],120);assert logs.ok
    log_path=E/f'macos-delivered-pack-mac-job-{job_id}.log'
    with log_path.open('xb') as stream:stream.write(logs.stdout)
    text=logs.stdout.decode('utf-8','replace')
    assert '100% tests passed out of 57' in text and re.search(r'Test #\d+: fl_platform_io_smoke\s+\.\.\.+\s+Passed',text)
    previous=json.loads((R/'.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01/evidence/darwin-preparation-publication-candidate.v1.json').read_bytes())
    accepted=[]
    for path,methods in previous['actual_mac_methods_required'].items():
        for member in methods:
            name=member.rsplit('.',1)[1];test_id='tests.'+Path(path).stem+'.'+member
            lines=[line for line in text.splitlines() if f'{name} ({test_id})' in line]
            assert len(lines)==1 and re.search(r'\.\.\. ok\s*$',lines[0]),('retained Mac owner regression',test_id)
            accepted.append(test_id)
    assert len(accepted)==41
    import runpy
    actual_records=[json.loads(line.split('delivered-tui-evidence: ',1)[1]) for line in text.splitlines() if 'delivered-tui-evidence: ' in line]
    assert len(actual_records)==9
    compiled={v['backend_identity']['compiled_source_revision'] for v in actual_records};assert len(compiled)==1
    compiled_source=compiled.pop()
    compiled_commit=call('compiled-checkout',['api',f'repos/{REPO}/git/commits/{compiled_source}']);assert compiled_commit.ok
    commit=json.loads(compiled_commit.stdout)
    reviewed_commit=json.loads((E/'macos-delivered-pack-candidate-commit-result-01.json').read_bytes())
    assert commit['tree']['sha']==reviewed_commit['tree'],'compiled CI checkout differs from independently reviewed task tree'
    parents=[v['sha'] for v in commit['parents']]
    assert compiled_source==S or (len(parents)==2 and parents[1]==S and parents[0]=='e504c5ed6d7366f0cf43df5105ae8ce415a8ffdc'),'unexpected synthetic CI checkout ancestry'
    qualification=runpy.run_path(str(E/'macos-delivered-pack-log-custody-01.py'))['extract'](text,compiled_source,E,job_id)
    qualification.update(compiled_checkout_source=compiled_source,compiled_checkout_tree=commit['tree']['sha'],compiled_checkout_parents=parents,reviewed_task_source=S)
    qualification.update(source=S,run_id=int(run_id),job_id=int(job_id),runner_name=j.get('runner_name'),job_conclusion=j['conclusion'],log_sha256=sha(log_path),log_path=str(log_path),native_tests_passed=57,retained_owner_methods_passed=41)
    record['actual_mac_delivered_package_qualification']=qualification
    save()

try:
    ident=owned.command(['powershell','-NoProfile','-Command','[Security.Principal.WindowsIdentity]::GetCurrent().Name'],
        cwd=R,environment=dict(os.environ),timeout=30,output_limit=16384,directory=E/'macos-delivered-pack-observer01-identity',
        wait_for_job_empty_after_primary=True)
    assert ident.ok and ident.stdout.decode().strip().casefold()==r'BLACKGLASS-WIN1\Jules'.casefold()
    last=None;delays=[60,120,300,600];step=0
    for poll in range(1500):
        pr=call('pr',['pr','view','416','--repo',REPO,'--json','headRefOid,baseRefName,state,mergeCommit,mergedAt'])
        if not pr.ok:
            if transient(pr):
                record['transient_network_failures'].append(dict(command=counter,category='github_or_network_transient'))
                save();time.sleep(delays[min(step,3)]);step+=1;continue
            raise RuntimeError('PR read failed: '+pr.stderr.decode('utf-8','replace')[:1000])
        view=json.loads(pr.stdout)
        assert view['headRefOid']==S and view['baseRefName']=='dev','exact source/base changed'
        if view['state']=='MERGED':
            c=call('merged-checks',['pr','checks','416','--repo',REPO,'--required','--json','name,state,bucket,link']);assert c.ok
            rows=json.loads(c.stdout);assert len(rows)>=12 and all(x['bucket']=='pass' and x['state']=='SUCCESS' for x in rows)
            verify_mac(rows)
            record.update(status='merged_exact_source',pr_state=view,required_checks_all_pass=True);break
        assert view['state']=='OPEN','PR no longer open'
        checks=call('checks',['pr','checks','416','--repo',REPO,'--required','--json','name,state,bucket,link'])
        if checks.receipt['termination']!='completed' or checks.returncode not in (0,1,8):
            if transient(checks):
                record['transient_network_failures'].append(dict(command=counter,category='github_or_network_transient'))
                save();time.sleep(delays[min(step,3)]);step+=1;continue
            raise RuntimeError('Required-check observation lost: '+checks.stderr.decode('utf-8','replace')[:1000])
        try:rows=json.loads(checks.stdout)
        except Exception:
            if transient(checks):
                record['transient_network_failures'].append(dict(command=counter,category='github_http_5xx'))
                save();time.sleep(delays[min(step,3)]);step+=1;continue
            raise
        if not rows or len(rows)<12:
            record['awaiting_required_check_registration']=len(rows)
            save();time.sleep(delays[min(step,3)]);step+=1;continue
        changed=sorted((x['name'],x['state'],x['bucket']) for x in rows)
        if changed!=last:
            record['observations'].append(dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),checks=rows))
            save();last=changed
        failed=[x for x in rows if x['bucket'] in ('fail','cancel')]
        if failed:
            record.update(status='ACTIONABLE_CHECK_FAILURE',failed=failed);break
        if all(x['bucket']=='pass' and x['state']=='SUCCESS' for x in rows):
            verify_mac(rows)
            message=(E/'macos-delivered-pack-candidate-commit-message-01.txt').read_text()
            subject,body=message.split('\n',1)
            body_path=E/'macos-delivered-pack-merge-body-01.txt'
            with body_path.open('x',encoding='utf-8',newline='\n') as f:f.write(body.lstrip('\n'))
            merged=call('merge',['pr','merge','416','--repo',REPO,'--merge','--match-head-commit',S,'--subject',subject,'--body-file',str(body_path)],120)
            if not merged.ok:raise RuntimeError('Checked normal merge failed: '+merged.stderr.decode('utf-8','replace')[:1600])
            final=call('merged-pr',['pr','view','416','--repo',REPO,'--json','headRefOid,baseRefName,state,mergeCommit,mergedAt'])
            assert final.ok
            view=json.loads(final.stdout);assert view['state']=='MERGED' and view['headRefOid']==S and view['baseRefName']=='dev'
            record.update(status='merged_exact_source',pr_state=view,required_checks_all_pass=True);break
        time.sleep(delays[min(step,3)]);step+=1
    else:record.update(status='durable_observation_boundary',action='reconnect_same_attempt_without_goal_blocking_or_duplicate_ci')
except BaseException as exc:record.update(status='ACTIONABLE_OBSERVER_FAILURE',error=str(exc),traceback=traceback.format_exc())
finally:save();print(json.dumps({k:v for k,v in record.items() if k not in ('commands','observations')},indent=2))

