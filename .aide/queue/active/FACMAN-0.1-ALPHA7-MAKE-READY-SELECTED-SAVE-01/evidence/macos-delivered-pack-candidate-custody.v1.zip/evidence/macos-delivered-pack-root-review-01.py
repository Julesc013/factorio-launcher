import ast,hashlib,json,os,subprocess,sys,unittest
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1')
sys.dont_write_bytecode=True;sys.path[:0]=[str(R),str(R/'tests')]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
F=E/'macos-delivered-pack-frozen-02.json';f=json.loads(F.read_bytes());BASE=f['base_commit']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==BASE
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).strip()
for n,h in f['path_sha256'].items():assert sha(R/n)==h,n
assert sha(E/'macos-delivered-pack-frozen-02.patch')==f['patch_sha256']
old=ast.parse(subprocess.check_output(['git','show',BASE+':tests/test_macos_delivered_tui.py'],cwd=R,text=True));new=ast.parse((R/'tests/test_macos_delivered_tui.py').read_text())
classes=[]
for tree in (old,new):classes.append(next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='MacosDeliveredTuiTests'))
old_methods={n.name:n for n in classes[0].body if isinstance(n,ast.FunctionDef)};new_methods={n.name:n for n in classes[1].body if isinstance(n,ast.FunctionDef)}
for name,node in old_methods.items():assert ast.dump(node,include_attributes=False)==ast.dump(new_methods[name],include_attributes=False),name
factory=[n for n in ast.walk(new) if isinstance(n,ast.Call) and ast.unparse(n.func)=='package_build.build_profile'];assert len(factory)==1
import test_macos_delivered_tui as candidate
suite=unittest.defaultTestLoader.loadTestsFromModule(candidate);assert suite.countTestCases()==9
result=unittest.TestResult();suite.run(result);assert result.testsRun==9 and len(result.skipped)==9 and not result.failures and not result.errors
assert len(candidate.PACK_SCENARIOS)==7 and len(candidate.PACK_FAULTS)==7
source_files={'portable':'tests/test_portable_modpack_import.py','presentation':'tests/test_presentation_pack_import.py'}
git_sources={role:hashlib.sha256(subprocess.check_output(['git','show',BASE+':'+name],cwd=R)).hexdigest() for role,name in source_files.items()}
review=dict(schema='facman.macos_delivered_pack_independent_review.v1',verdict='PASS_FOR_REQUIRED_ACTUAL_DARWIN_PACKAGE_CANDIDATE',reviewer='/root',author='/root/macos_delivered_pack_implementation',non_authoring=True,base_head=BASE,frozen_packet_sha256=sha(F),files_sha256=f['path_sha256'],changed_paths=f['changed_paths'],existing_tui_method_asts_unchanged=True,original_source_scenarios_unchanged=True,package_factory_count=1,standalone_methods=9,new_package_methods=7,local_mac_skips_counted_as_acceptance=0,source_scenario_git_blob_sha256=git_sources,source_scenario_file_paths=source_files,review='Explicit produced executable for every synchronous and loss-case child; external owned workspace/cwd, empty PATH, cleared source/provider overrides with scenario-specific reviewed fault allowlist. Raw argv/streams/before-after inventories and deduplicated exact bytes captured before source fixture cleanup. Source assertions remain unchanged. All children and call evidence must finish before success; safety cleanup is recorded separately and cannot manufacture lifecycle acceptance. Per-scenario call/time/stream bounds and unchanged custody caps refuse loss/truncation. Original two delivered TUI methods and single package factory remain unchanged. Actual nine Darwin methods and independent custody decoding plus normal required checks remain mandatory.',actual_mac_pending=True,torn_file_refusal_is_not_repair=True,authority_delta='none',full_make_ready=False,beta=False,rc=False)
out=E/'macos-delivered-pack-independent-review-01.json';assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(dict(verdict=review['verdict'],review_sha256=sha(out),retained_method_asts=len(old_methods),methods=9,one_package_factory=True,actual_mac_pending=True)))
