import datetime,hashlib,json,os,sys
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R))
from tools import native_build,provider_canary_process as owned,development_layout
E=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e\evidence');W=E.parent;B=W/'native-developer'
resources=json.loads((E/'content-activation-resources-02.json').read_text(encoding='utf-8-sig'))
assert not resources['Toolchains'];assert resources['AvailablePhysicalBytes']>=3*1024**3;assert resources['FreeDiskBytes']>=12*1024**3
assert (datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(resources['ObservedAtUtc'])).total_seconds()<180
hygiene=json.loads((E/'content-activation-hygiene-01.json').read_text(encoding='utf-8-sig'));assert len(hygiene['task_roots'])<=8
assert hygiene['task_root_bytes']+4*1024**3<=20*1024**3
assert hygiene['violations']==['unmanaged_secondary_worktrees_present']
marker=W/development_layout.MARKER_NAME;marker_sha=hashlib.sha256(marker.read_bytes()).hexdigest();assert marker_sha=='30d72706c486ff20eed8b1947a920caa0a4e2d43820abbaf0ff78d12ab9f697c'
development_layout.read_marker(W,R)
os.environ.update(CMAKE_BUILD_PARALLEL_LEVEL='2',TEMP=str(W/'t'),TMP=str(W/'t'),MSBUILDDISABLENODEREUSE='1',FACMAN_MIN_FREE_GIB='12')
native_build.require_disk_reserve(B)
command=native_build.command(B,'Release',['facman_cli','flb_factorio_instance_model_smoke'],{})
result=owned.command(command,cwd=R,environment=dict(os.environ),timeout=900,directory=E/'content-activation-build-owned-02',output_limit=8*1024**2,wait_for_job_empty_after_primary=False)
row=dict(command=command,ok=result.ok,receipt=str(result.directory/'receipt.json'),exit_code=result.returncode,termination=result.receipt['termination'],primary_stopped=result.receipt['primary_stopped'],job_empty=result.receipt['job_empty_observed'],marker_unchanged=hashlib.sha256(marker.read_bytes()).hexdigest()==marker_sha,cli_sha256=hashlib.sha256((B/'Release/facman.exe').read_bytes()).hexdigest())
(E/'content-activation-build-02.json').write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8');print(json.dumps(row))
if not result.ok:print(result.stdout.decode(errors='replace')[-5000:]);print(result.stderr.decode(errors='replace')[-2000:])
sys.exit(0 if result.ok else 1)
