import hashlib,json,os,sys,unittest
from pathlib import Path
R=Path.cwd();sys.path[:0]=[str(R/'tests'),str(R)]
E=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e\evidence')
from tools import provider_canary_process as owned
if '--worker' not in sys.argv:
 env=dict(os.environ,FACMAN_CLI_EXE=str(E.parent/'t/j3/g6/bin/facman.exe'),TEMP=str(E.parent/'t'),TMP=str(E.parent/'t'))
 result=owned.command([sys.executable,__file__,'--worker'],cwd=R,environment=env,timeout=120,directory=E/'joined-content-baseline-owned-01',wait_for_job_empty_after_primary=True)
 print(json.dumps(dict(ok=result.ok,receipt=str(result.directory/'receipt.json'),termination=result.receipt['termination'],job_empty=result.receipt['job_empty_observed'])))
 print(result.stdout.decode('utf-8'));print(result.stderr.decode('utf-8'));sys.exit(0 if result.ok else 1)
import test_make_ready_joined as joined
from native_cli import invoke_machine
from test_local_modset_solver import snapshot
case=joined.JoinedMakeReadyTests();rows=[]
for kind in ('missing','disabled'):
 workspace=E/('joined-content-baseline-fixture-01-'+kind)
 workspace.mkdir()
 instance,_=joined.missing.ConfigurationPreparationTests.prepare(case,workspace,'load_save',True)
 modlist=instance/'mods/mod-list.json'
 original=modlist.read_bytes()
 if kind=='missing':modlist.unlink()
 else:
  data=json.loads(original)
  for mod in data['mods']:
   if mod['name']=='simple':mod['enabled']=False
  modlist.write_text(json.dumps(data)+'\n',encoding='utf-8')
 before=snapshot(workspace)
 observation=case.query(workspace,'instances','load_save')
 descriptor=next(a for a in observation['available_semantic_actions'] if a['action_id']=='readiness.prepare_joined')
 assert before==snapshot(workspace)
 action=case.result(invoke_machine(case.arguments(workspace,observation,'baseline-'+kind)))
 row=dict(case=kind,workspace=str(workspace),image=str(os.environ['FACMAN_CLI_EXE']),image_sha256=hashlib.sha256(Path(os.environ['FACMAN_CLI_EXE']).read_bytes()).hexdigest(),modset_status=observation['readiness']['preparation_preview']['modset']['status'],availability=descriptor['availability'],outcome=action['outcome'],components=[c['owner_command'] for c in action['action_payload']['completed_components']],mod_list_repaired=modlist.exists() and modlist.read_bytes()==original,final_modset_status=action['action_payload']['readiness_observation']['preparation_preview']['modset']['status'])
 rows.append(row)
 assert row['modset_status']=='locked_verified' and row['outcome']=='completed' and not row['mod_list_repaired']
(E/'joined-content-baseline-01.json').write_text(json.dumps(dict(schema='facman.joined_content_baseline.v1',rows=rows),indent=2)+'\n',encoding='utf-8')
print(json.dumps(rows))
