import json,os,sys
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R))
from tools import provider_canary_process as owned
E=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e\evidence');W=E.parent
os.environ.update(FACMAN_CLI_EXE=str(W/'native-developer/Release/facman.exe'),TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONPATH=str(R/'tests')+os.pathsep+str(R))
command=[sys.executable,'-m','unittest','test_presentation_profile_preparation.PresentationProfilePreparationTests.test_preparation_preview_modset_and_association_are_observations','-v']
r=owned.command(command,cwd=R,environment=dict(os.environ),timeout=180,directory=E/'content-activation-profile-control-owned-02',wait_for_job_empty_after_primary=True)
(E/'content-activation-profile-control-02.json').write_text(json.dumps(dict(command=command,ok=r.ok,exit_code=r.returncode,receipt=str(r.directory/'receipt.json')),indent=2)+'\n',encoding='utf-8')
print(r.stdout.decode('utf-8'));print(r.stderr.decode('utf-8'));sys.exit(0 if r.ok else 1)
