import json,os,sys
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R))
from tools import provider_canary_process as owned
E=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e\evidence');W=E.parent
os.environ.update(FACMAN_CLI_EXE=str(W/'native-developer/Release/facman.exe'),TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONPATH=str(R/'tests')+os.pathsep+str(R))
commands=[('regression',[sys.executable,'-m','unittest','test_make_ready_joined','test_make_ready_preparation','test_readiness_builtin_content','test_local_modset_solver','test_presentation_service','-v']),('instance-model-smoke',[str(W/'native-developer/Release/flb_factorio_instance_model_smoke.exe')]),('strict',[sys.executable,'-B','tools/strict_check.py']),('aide-lite',[sys.executable,'-B','.aide/scripts/aide_lite.py','test'])]
rows=[]
for label,command in commands:
 result=owned.command(command,cwd=R,environment=dict(os.environ),timeout=900,directory=E/('content-activation-'+label+'-owned-01'),output_limit=8*1024**2,wait_for_job_empty_after_primary=True)
 row=dict(label=label,command=command,ok=result.ok,receipt=str(result.directory/'receipt.json'),exit_code=result.returncode,termination=result.receipt['termination'],primary_stopped=result.receipt['primary_stopped'],job_empty=result.receipt['job_empty_observed']);rows.append(row)
 (E/'content-activation-regression-01.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print(json.dumps(row),flush=True)
 if not result.ok:
  print(result.stdout.decode('utf-8')[-4000:]);print(result.stderr.decode('utf-8')[-14000:]);sys.exit(1)
print('All appropriate regression/static checks completed normally')
