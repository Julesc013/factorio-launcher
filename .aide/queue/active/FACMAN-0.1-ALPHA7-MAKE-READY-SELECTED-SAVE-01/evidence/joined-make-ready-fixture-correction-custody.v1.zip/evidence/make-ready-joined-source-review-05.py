import ast,hashlib,json,re,subprocess
from pathlib import Path
E=Path(__file__).resolve().parent
R=Path(r'D:\Projects\Factorio\factorio-launcher')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
packet=E/'make-ready-joined-frozen-06.json'
f=json.loads(packet.read_bytes())
assert git('rev-parse','HEAD')==f['base']=='7198b84ea9d73aa78333db3d0dfe46123615ee09'
assert git('rev-parse','HEAD^{tree}')==f['base_tree']=='a99f9acd4dcadce32b80676347c3f3d4bb7595a1'
path='tests/test_make_ready_joined.py'
assert [row['path'] for row in f['files']]==[path] and not f['root_owned_preserved']
assert git('diff','--name-only')==path and not git('diff','--cached','--name-only')
assert not git('ls-files','--others','--exclude-standard')
assert sha(R/path)==f['files'][0]['sha256'] and sha(f['patch']['path'])==f['patch']['sha256']
for row in f['logs']+f['retained_failed_qualification']:
    assert sha(row['path'])==row['sha256'],row['path']
for row in f['previous_freezes']:
    assert sha(row['path'])==row['sha256']
    prior=json.loads(Path(row['path']).read_bytes())
    assert sha(prior['patch']['path'])==row['patch_sha256']
    for log in prior['logs']:assert sha(log['path'])==log['sha256']
before=subprocess.check_output(['git','show','HEAD:'+path],cwd=R).decode('utf-8')
after=(R/path).read_text(encoding='utf-8')
def methods(source):
    cls=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=='JoinedMakeReadyTests')
    return {n.name:ast.dump(n,include_attributes=False) for n in cls.body if isinstance(n,ast.FunctionDef)}
old,new=methods(before),methods(after)
assert set(new)-set(old)=={'owned_pause','wait_marker'} and not set(old)-set(new)
changed={name for name in old if old[name]!=new[name]}
assert changed=={'paused','test_concurrent_exact_request_reads_checkpoint_without_redispatch',
    'test_failed_final_receipt_persistence_preserves_foreign_target_and_exposes_no_clearing_directive',
    'test_changed_effect_after_final_observation_cannot_manufacture_success'}
assert sum(name.startswith('test_') for name in new)==13
log=(E/'make-ready-joined-marker-06-ordinary-regressions-final.log').read_text(encoding='utf-8')
assert len(re.findall(r'\.\.\. ok\s*$',log,re.M))==5 and 'Ran 5 tests' in log and log.rstrip().endswith('OK')
p=json.loads((E/'make-ready-joined-marker-06-final-calls-custody.json').read_bytes())
assert p['result']=='PASS' and p['tests_run']==2 and not p['runtime_build']
assert p['all_owned_children_finished'] and p['stale_completed_marker_rejected'] and p['communication_failure_cannot_pass']
assert len(p['calls'])==4
objects={name:bytes.fromhex(value) for name,value in p['CAS'].items()}
assert sum(map(len,objects.values()))<4*1024**2
assert all(hashlib.sha256(data).hexdigest()==name for name,data in objects.items())
for call in p['calls']:
    assert call['pid']>0 and call['actual_start']<=call['finished'] and 'exit_code' in call
    for inventory in (call['before'],call['after']):
        for item in inventory.values():assert len(objects[item['sha256']])==item['bytes']
for call in p['calls'][:2]:
    assert call['exit_code']==3 and not call['stderr']
    result=json.loads(call['stdout'])['payload']
    assert result['outcome']=='recovery_required' and result['problems'][0]['code']=='make_ready_completed_effect_unknown'
    payload=result['action_payload']
    assert payload['continuation']=='inspect_domain_recovery' and not payload['completed_effects_verified']
    assert len(payload['completed_components'])==2 and payload['readiness_observation'] is None
    assert payload['permit_issued'] is False and payload['execution_started'] is False
assert p['calls'][1]['actual_start']-p['calls'][1]['started']>=9 and p['delayed']['wait_seconds']>9
assert p['delayed']['live'] and p['delayed']['release_absent'] and p['ordinary']['live']
assert p['calls'][2]['exit_code']==0 and p['early_completion']['wait_seconds']<5
assert 'exit_code' in p['early_completion']['error'] and len(p['early_completion']['error'])<4096
assert p['calls'][3]['exit_code']==1
assert sha(f['existing_runtime']['path'])==f['existing_runtime']['sha256']
mac=json.loads((E/'make-ready-joined-mac-actual-custody-result-03.json').read_bytes())
assert mac['status']=='PASS_ACTUAL_ELEVEN_MAC_PACKAGE_METHODS_CUSTODY'
assert mac['source']==f['base'] and mac['actual_package']['method_count']==11 and mac['actual_package']['method_skips']==0
record=dict(verdict='PASS_FIXTURE_CORRECTION_FOR_REQUIRED_CURRENT_CI',reviewer='/root',
    author='/root/make_ready_joined_implementation',non_authoring=True,
    frozen_packet_sha256=sha(packet),base=f['base'],authored_files=[path],
    changed_existing_methods=sorted(changed),runtime_contract_provider_policy_unchanged=True,
    owned_child_review='Real Popen retained; monotonic startup bound; ready/live/unreleased marker; early terminal diagnostics; release and finite cleanup; safety termination or communication error refuses success.',
    substantive_oracle_review='Original byte/identity/journal/replay/foreign-target assertions retained; exact completed-effect-unknown problem excludes pause-timeout false success.',
    affected_ordinary_methods_passed=5,delayed_start_seconds=p['calls'][1]['actual_start']-p['calls'][1]['started'],
    delayed_marker_wait_seconds=p['delayed']['wait_seconds'],early_completion_seconds=p['early_completion']['wait_seconds'],
    retained_CXX_pause_seconds=20,native_rebuild=False,required_current_checks_pending=True,
    historical_mac_proof_sha256=sha(E/'make-ready-joined-mac-actual-custody-result-03.json'),
    canonical_installed_desktop=False,full_make_ready=False,beta=False,rc=False)
out=E/'make-ready-joined-independent-review-05.json'
with out.open('x',encoding='utf-8') as stream:json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record,indent=2))
