import ast
import collections
import hashlib
import json
import subprocess
from pathlib import Path

R=Path(r'D:\Projects\Factorio\factorio-launcher')
E=Path(__file__).resolve().parent
BASE='7198b84ea9d73aa78333db3d0dfe46123615ee09'
sha=lambda data:hashlib.sha256(data).hexdigest()
def git(*args):
    return subprocess.run(['git',*args],cwd=R,capture_output=True,check=True).stdout
assert git('rev-parse','HEAD').decode().strip()==BASE
assert git('diff','--name-only','HEAD').decode().splitlines()==['tests/test_make_ready_joined.py']
old=ast.parse(git('show','HEAD:tests/test_make_ready_joined.py').decode('utf-8'))
current=(R/'tests/test_make_ready_joined.py').read_text(encoding='utf-8')
new=ast.parse(current)
def methods(module):
    cls=next(node for node in module.body if isinstance(node,ast.ClassDef) and node.name=='JoinedMakeReadyTests')
    return {node.name:node for node in cls.body if isinstance(node,ast.FunctionDef)}
before,after=methods(old),methods(new)
modified={'paused','test_concurrent_exact_request_reads_checkpoint_without_redispatch',
    'test_failed_final_receipt_persistence_preserves_foreign_target_and_exposes_no_clearing_directive',
    'test_changed_effect_after_final_observation_cannot_manufacture_success'}
for name,node in before.items():
    if name not in modified:
        assert ast.dump(node)==ast.dump(after[name]),name
def assertion_oracles(node):
    values=[]
    for call in ast.walk(node):
        if not isinstance(call,ast.Call) or not isinstance(call.func,ast.Attribute) or not call.func.attr.startswith('assert'):
            continue
        dump=ast.dump(call)
        if call.func.attr in ('assertTrue','assertFalse') and ("attr='is_alive'" in dump or "attr='is_file'" in dump):
            continue
        values.append(dump)
    return collections.Counter(values)
for name in modified.difference({'paused'}):
    assert not (assertion_oracles(before[name])-assertion_oracles(after[name])), 'Lost substantive assertion: '+name
assert 'make_ready_completed_effect_unknown' in ast.dump(after['test_changed_effect_after_final_observation_cannot_manufacture_success'])
assert 'range(' not in current
assert len([name for name in after if name.startswith('test_')])==13
for number in ('01','02','03','04','05'):
    packet=json.loads((E/('make-ready-joined-frozen-'+number+'.json')).read_text(encoding='utf-8'))
    assert sha(Path(packet['patch']['path']).read_bytes())==packet['patch']['sha256']
    for record in packet['logs']:
        assert sha(Path(record['path']).read_bytes())==record['sha256'],record['path']
failure=json.loads((E/'make-ready-joined-windows-CI-failure-01.json').read_text(encoding='utf-8'))
assert sha(Path(failure['log']).read_bytes())==failure['log_sha256']=='21445d1ba836cc477147fcd17379e086ff4d80917be37f02a98e7a68e09d32f9'
validation=json.loads((E/'make-ready-joined-marker-06-final-calls-custody.json').read_text(encoding='utf-8'))
assert validation['result']=='PASS' and validation['all_owned_children_finished']
assert validation['stale_completed_marker_rejected'] and validation['communication_failure_cannot_pass']
assert validation['delayed']['wait_seconds']>7.5
print(json.dumps(dict(result='PASS',base=BASE,fixture_owned_files=1,runtime_unchanged=True,
    substantive_loss_substitution_oracles_preserved=True,source_methods=13,
    all_new_marker_waits_use_owned_monotonic_helper=True,final_problem_assertion_required=True,
    prior_freezes_and_bound_logs_immutable=True,CI_failure_retained=True,
    delayed_real_CLI_and_early_completion_cleanup_checks='PASS'),sort_keys=True))
