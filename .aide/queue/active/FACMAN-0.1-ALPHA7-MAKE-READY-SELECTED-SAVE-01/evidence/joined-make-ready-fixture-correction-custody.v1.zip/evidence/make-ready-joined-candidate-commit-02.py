import hashlib,json,os,subprocess,sys,traceback,zipfile
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
BASE='7198b84ea9d73aa78333db3d0dfe46123615ee09';DEV='dff35d6bbc38a1b3f05e1bc1d79b6a5c6b5b91bc';BRANCH='task/facman-make-ready-joined-01'
Q='.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.safecrlf',GIT_CONFIG_VALUE_0='false')
sys.path.insert(0,str(R))
from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
out=E/'make-ready-joined-candidate-commit-result-02.json';assert not out.exists()
record=dict(status='SEALING_REVIEWED_FIXTURE_CORRECTION',commands=[],new_roots=0,new_clones=0,new_worktrees=0,new_optional_campaigns=0,goal_status_mutated=False)
def save():out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
def run(label,args,timeout=180):
 r=owned.command(args,cwd=R,environment=dict(os.environ),timeout=timeout,directory=E/('make-ready-joined-commit02-'+label),output_limit=8*1024**2)
 record['commands'].append(dict(label=label,exit_code=r.returncode,receipt_sha256=sha(r.directory/'receipt.json')));save()
 assert r.ok and r.receipt['primary_stopped'] and r.receipt['job_empty_observed'],(label,(r.stdout[-1000:]+r.stderr[-1500:]).decode('utf-8','replace'))
 return r
try:
 assert git('rev-parse','HEAD')==BASE and git('branch','--show-current')==BRANCH
 assert git('diff','--name-only')=='tests/test_make_ready_joined.py' and not git('diff','--cached','--name-only') and not git('ls-files','--others','--exclude-standard')
 frozen=E/'make-ready-joined-frozen-06.json';f=json.loads(frozen.read_bytes())
 review=E/'make-ready-joined-independent-review-05.json';v=json.loads(review.read_bytes())
 assert v['verdict']=='PASS_FIXTURE_CORRECTION_FOR_REQUIRED_CURRENT_CI' and v['non_authoring'] and v['frozen_packet_sha256']==sha(frozen) and v['base']==BASE
 assert sha(R/f['files'][0]['path'])==f['files'][0]['sha256']
 for label in ('policy','detect','plan'):run(label,['py','-3','-B','.aide/scripts/aide_lite.py','git',label])
 evidence=R/Q/'evidence/joined-make-ready-fixture-correction.v1.json';archive=R/Q/'evidence/joined-make-ready-fixture-correction-custody.v1.zip'
 assert not evidence.exists() and not archive.exists()
 names={Path(__file__).name,frozen.name,Path(f['patch']['path']).name,review.name,'make-ready-joined-source-review-05.py','make-ready-joined-mac-actual-job-115514828080.log','macos-delivered-pack-log-custody-01.py','macos-delivered-tui-log-custody-02.py','macos-delivered-pack-independent-review-01.json'}
 names.update('make-ready-joined-mac-actual-custody-result-'+str(i).zfill(2)+'.json' for i in range(1,4))
 names.update('make-ready-joined-log-custody-'+str(i).zfill(2)+'.py' for i in range(1,4))
 for row in f['logs']+f['retained_failed_qualification']:
  assert sha(row['path'])==row['sha256'];names.add(Path(row['path']).relative_to(E).as_posix())
 for label in ('job','run','compiled'):
  names.update('make-ready-joined-mac-custody01-'+label+'/'+n for n in ('stdout.raw','stderr.raw','receipt.json'))
 for prefix in ('macos-delivered-pack-job-','macos-delivered-tui-actual-job-','make-ready-joined-mac-job-'):
  directory=E/(prefix+'115514828080-custody03');assert directory.is_dir()
  names.update(p.relative_to(E).as_posix() for p in directory.rglob('*') if p.is_file())
 manifest={n:sha(E/n) for n in sorted(names)}
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
  z.writestr('custody-manifest.json',json.dumps(manifest,indent=2,sort_keys=True)+'\n')
  for n in sorted(manifest):z.write(E/n,'evidence/'+n)
 with zipfile.ZipFile(archive) as z:
  for n,d in manifest.items():assert hashlib.sha256(z.read('evidence/'+n)).hexdigest()==d
 source=R/Q/'evidence/joined-make-ready-source.v1.json'
 blob_hash=hashlib.sha256((R/'tests/test_make_ready_joined.py').read_text(encoding='utf-8').replace('\r\n','\n').encode('utf-8')).hexdigest()
 mac_path=E/'make-ready-joined-mac-actual-custody-result-03.json';mac=json.loads(mac_path.read_bytes())
 assert mac['status']=='PASS_ACTUAL_ELEVEN_MAC_PACKAGE_METHODS_CUSTODY' and mac['source']==BASE
 winlog=E/'make-ready-joined-windows-CI-job-115514828046.log';assert winlog.read_text(encoding='utf-8').count('100% tests passed, 0 tests failed out of 55')==4
 evidence.write_text(json.dumps(dict(schema='facman.joined_make_ready_fixture_correction.v1',previous_published_head=BASE,integration_base=DEV,frozen_packet_sha256=sha(frozen),review_sha256=sha(review),previous_source_qualification_sha256=sha(source),changed_source_files_sha256={r['path']:r['sha256'] for r in f['files']},source_scenario_git_blob_sha256=dict(joined=blob_hash),fixture_correction=f['correction'],affected_ordinary_methods_passed=5,source_method_count=13,delayed_start_seconds=v['delayed_start_seconds'],delayed_marker_wait_seconds=v['delayed_marker_wait_seconds'],early_completion_seconds=v['early_completion_seconds'],runtime_changed=False,native_rebuild=False,historical_windows_job=115514828046,historical_windows_native_tests_per_build=55,historical_windows_native_builds_passed=4,historical_windows_job_overall='failure: one startup-marker fixture deadline',historical_windows_log_sha256=sha(winlog),historical_mac_proof_sha256=sha(mac_path),historical_mac_source=BASE,historical_mac_job=115514828080,historical_mac_package_methods_passed=11,historical_mac_method_skips=0,custody=archive.name,custody_sha256=sha(archive),custody_files=len(manifest),original_partial_v1_preserved=True,accepted_receipt_v2_preserved=True,required_current_checks_pending=True,current_mac_package_proof_pending=True,canonical_installed_desktop=False,minimum_mac13_physical_host=False,named_physical_host=False,real_game=False,human=False,whole_workunit=False,full_make_ready=False,beta=False,rc=False),indent=2)+'\n',encoding='utf-8')
 with (R/Q/'ExecPlan.md').open('a',encoding='utf-8',newline='\n') as stream:
  stream.write('\n### Joined preparation fixture synchronization correction\n\nThe first PR417 campaign passed all55 native Windows tests in each of four builds. Its overall Windows job remains failed: one joined fixture exceeded its7.5second startup observation. All11actual Mac package methods passed without method skips; independent exact-byte custody verifies three joined two-owner requests plus the retained nine scenarios. These are historical7198b84results, not qualification of a corrected head.\n\nA test-only correction retains the actual CLI child and observes a ready/live/unreleased pause with a monotonic30second startup bound or early terminal result. Finite release/join/cleanup refuses safety termination or communication failure. The native20second pause and runtime/provider/policy/host limits remain unchanged. Five affected cases pass. An actual launch delayed9seconds reaches its marker after15.7seconds and still proves exact completed-effect-unknown refusal after file substitution. Early completion, stale markers and cleanup errors cannot manufacture success. Original byte/identity/journal/foreign-target/replay assertions remain. All required current checks and independently decoded11method Mac package proof precede integration. No root, clone, worktree or optional campaign was added. Full Make Ready, canonical installed Desktop, human/game/minimum/named-host acceptance and Beta/RC remain open.\n\nEvidence: evidence/joined-make-ready-fixture-correction.v1.json and hash-closed custody. Earlier source qualification remains immutable.\n')
 paths={'tests/test_make_ready_joined.py',Q+'/ExecPlan.md',Q+'/evidence/'+evidence.name,Q+'/evidence/'+archive.name}
 run('project-state',['py','-3','-B','tools/project_state.py','--write'],600);run('metadata',['py','-3','-B','tools/codegen/generate_metadata.py','--write'])
 dirty=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
 assert paths<=dirty<=paths|{'.aide/memory/project-state.md','.aide/memory/project-state.v2.json','README.md'}
 assert sha(R/'tests/test_make_ready_joined.py')==f['files'][0]['sha256']
 run('strict',['py','-3','-B','tools/strict_check.py'],1800);run('portable-aide',['py','-3','-B','.aide/scripts/aide_lite.py','test'],1800)
 message='test(readiness): observe owned preparation pauses until ready\n\nKeep delayed startup and early completion distinct while preserving\nexact changed-file refusal and finite child cleanup.\n\nWork-Item: FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01\nEvidence-Ref: '+Q+'/evidence/'+evidence.name+'\n'
 msg=E/'make-ready-joined-candidate-commit-message-02.txt';msg.write_text(message,encoding='utf-8',newline='\n')
 run('message',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--message',message])
 changes=[dict(path=n,state='content',sha256=sha(R/n),git_blob_oid=git('hash-object','--path',n,str(R/n)),ownership='task_owned') for n in sorted(dirty)]
 snapshot=hashlib.sha256((json.dumps(changes,indent=2,sort_keys=True,separators=(',',': '))+'\n').encode()).hexdigest()
 commit_review=E/'make-ready-joined-candidate-commit-review-02.json'
 commit_review.write_text(json.dumps(dict(schema_version='aide.git-commit-review.v1',verdict='PASS',reviewer='/root',author='/root/make_ready_joined_implementation',non_authoring=True,branch=BRANCH,base_commit=BASE,snapshot_sha256=snapshot,message_sha256=sha(msg),independent_source_review_sha256=sha(review),review='Fixture-only actual child ownership and monotonic synchronization; immutable historical failure/package results; unchanged runtime; all current mandatory checks and package custody remain required.'),indent=2)+'\n',encoding='utf-8')
 classification=E/'make-ready-joined-candidate-commit-classification-02.json'
 classification.write_text(json.dumps(dict(schema_version='aide.git-commit-classification.v1',branch=BRANCH,base_commit=BASE,work_item='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01',snapshot_sha256=snapshot,message_sha256=sha(msg),changed_paths=changes,reviews=[dict(path=str(commit_review),sha256=sha(commit_review),verdict='PASS')]),indent=2)+'\n',encoding='utf-8')
 helper=['py','-3','-B','.aide/scripts/aide_lite.py','git','commit-plan','--classification',str(classification),'--message-file',str(msg)]
 run('plan-stage',helper);run('stage',['git','add','--',*sorted(dirty)]);run('staged-diff',['git','diff','--cached','--check']);run('plan-commit',helper)
 assert git('rev-parse','HEAD')==BASE
 run('commit',['git','commit','-F',str(msg)]);run('range',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--range',BASE+'..HEAD'])
 assert not git('status','--porcelain')
 record.update(status='COMMITTED_QUALIFIED_JOINED_SOURCE_CANDIDATE',source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),review_sha256=sha(commit_review),evidence_sha256=sha(evidence),actual_mac_package_pending=True,required_checks_pending=True,remote_not_pushed=True)
except BaseException as error:record.update(status='ACTIONABLE_JOINED_COMMIT_FAILURE',error=str(error),traceback=traceback.format_exc())
finally:save();print(json.dumps({k:v for k,v in record.items() if k not in ('commands','traceback')},indent=2),flush=True)
raise SystemExit(0 if record['status']=='COMMITTED_QUALIFIED_JOINED_SOURCE_CANDIDATE' else 1)
