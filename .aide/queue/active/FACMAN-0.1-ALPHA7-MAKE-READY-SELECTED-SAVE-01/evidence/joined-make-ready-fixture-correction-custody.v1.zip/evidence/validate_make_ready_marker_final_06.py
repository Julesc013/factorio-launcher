import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time
import types
import unittest
from pathlib import Path
from unittest.mock import patch

R=Path(r'D:\Projects\Factorio\factorio-launcher')
E=Path(__file__).resolve().parent
sys.path[:0]=[str(R),str(R/'tests')]
import test_make_ready_joined as joined

real_popen=subprocess.Popen
real_wait=joined.wait_for_owned_marker
calls=[]
observations=[]
objects={}
delay=False

def snapshot(workspace):
    inventory={}
    for path in workspace.rglob('*'):
        if path.is_file():
            data=path.read_bytes()
            digest=hashlib.sha256(data).hexdigest()
            objects.setdefault(digest,data)
            assert sum(len(data) for data in objects.values())<4*1024*1024
            inventory[path.relative_to(workspace).as_posix()]=dict(sha256=digest,bytes=len(data),
                identity=joined.file_identity(path))
    return inventory

def popen(args,**kwargs):
    workspace=Path(args[args.index('--workspace')+1])
    record=dict(argv=list(args),cwd=str(kwargs['cwd']),started=time.monotonic(),
        before=snapshot(workspace),delay_seconds=9 if delay else 0)
    calls.append(record)
    if delay:
        time.sleep(9)
    child=real_popen(args,**kwargs)
    record.update(actual_start=time.monotonic(),pid=child.pid)
    communicate=child.communicate
    def capture(**options):
        out,err=communicate(**options)
        record.update(exit_code=child.returncode,stdout=out,stderr=err,
            after=snapshot(workspace),finished=time.monotonic())
        assert len(out.encode())+len(err.encode())<2*1024*1024
        return out,err
    child.communicate=capture
    return child

def wait(worker,marker,release):
    start=time.monotonic()
    try:
        real_wait(worker,marker,release)
        observations.append(dict(marker=marker.name,wait_seconds=time.monotonic()-start,
            live=worker.running(),release_absent=not release.exists(),pid=worker.process.pid))
    except AssertionError as error:
        observations.append(dict(marker=marker.name,wait_seconds=time.monotonic()-start,error=str(error)))
        raise

proxy=types.SimpleNamespace(Popen=popen,PIPE=subprocess.PIPE,TimeoutExpired=subprocess.TimeoutExpired,
                            run=subprocess.run)
method='test_changed_effect_after_final_observation_cannot_manufacture_success'
with patch.object(joined,'subprocess',proxy),patch.object(joined,'wait_for_owned_marker',wait):
    result=unittest.TestResult()
    joined.JoinedMakeReadyTests(method).run(result)
    assert result.wasSuccessful(),repr(result.errors+result.failures)
    ordinary_wait=observations[-1]
    delay=True
    joined.JoinedMakeReadyTests(method).run(result)
    delay=False
    assert result.wasSuccessful(),repr(result.errors+result.failures)
    delayed_wait=observations[-1]
    assert delayed_wait['wait_seconds']>8.9 and delayed_wait['live'] and delayed_wait['release_absent']
    delayed_call=calls[-1]
    assert delayed_call['actual_start']-delayed_call['started']>=9
    payload=json.loads(delayed_call['stdout'])['payload']
    assert payload['problems'][0]['code']=='make_ready_completed_effect_unknown'
    assert not payload['action_payload']['completed_effects_verified']
    assert len(payload['action_payload']['completed_components'])==2
    case=joined.JoinedMakeReadyTests(method)
    with tempfile.TemporaryDirectory(prefix='joined-early-',dir=os.environ['TEMP']) as value:
        workspace=Path(value)
        joined.existing.ExistingConfigurationTests.prepare(case,workspace,'load_save')
        args=['--workspace',str(workspace),'presentation','query','instances','--instance','main','--json']
        with case.assertRaisesRegex(AssertionError,'Owned marker .* absent after'):
            with case.owned_pause(workspace,args,context=True) as worker:
                case.wait_marker(workspace,worker)
        assert worker.response[0]==0 and not worker.running()
        early_wait=observations[-1]
        assert early_wait['wait_seconds']<5 and 'exit_code' in early_wait['error']
        assert len(early_wait['error'])<4096
        marker=workspace/'instances/main/.facman-test-make-ready-before-context'
        release=workspace/'instances/main/.facman-test-make-ready-context-release'
        release.unlink()
        marker.write_bytes(b'ready\n')
        with case.assertRaisesRegex(AssertionError,'live unreleased owned pause'):
            joined.wait_for_owned_marker(worker,marker,release)
        marker.unlink()
        def broken_popen(argv,**options):
            child=popen(argv,**options)
            capture=child.communicate
            def fail_once(**communication):
                child.communicate=capture
                raise OSError('Test-owned communication failure')
            child.communicate=fail_once
            return child
        with patch.object(proxy,'Popen',broken_popen):
            failed_worker=joined.PausedAction(args,dict(os.environ))
            with case.assertRaisesRegex(AssertionError,'failed to finish normally'):
                failed_worker.finish()
        assert not failed_worker.thread.is_alive()
        assert failed_worker.process is not None and failed_worker.process.poll() is not None
        assert 'Test-owned communication failure' in failed_worker.error
        if 'exit_code' not in calls[-1]:
            failed_worker.process.communicate(timeout=10)
    record=dict(result='PASS',ordinary=ordinary_wait,delayed=delayed_wait,early_completion=early_wait,
        tests_run=result.testsRun,source_method=method,expected_problem=payload['problems'][0]['code'],
        runtime_build=False,stale_completed_marker_rejected=True,communication_failure_cannot_pass=True,all_owned_children_finished=all('exit_code' in call for call in calls),
        calls=calls,CAS={key:data.hex() for key,data in objects.items()})
    target=E/'make-ready-joined-marker-06-final-calls-custody.json'
    assert not target.exists()
    target.write_text(json.dumps(record,indent=2),encoding='utf-8')
    print(json.dumps(dict(result='PASS',ordinary_wait_seconds=ordinary_wait['wait_seconds'],
        delayed_real_CLI_start_seconds=delayed_call['actual_start']-delayed_call['started'],
        delayed_marker_wait_seconds=delayed_wait['wait_seconds'],early_completion_wait_seconds=early_wait['wait_seconds'],
        expected_problem=payload['problems'][0]['code'],calls=len(calls),CAS_bytes=sum(map(len,objects.values())),
        all_owned_children_finished=record['all_owned_children_finished']),sort_keys=True))
