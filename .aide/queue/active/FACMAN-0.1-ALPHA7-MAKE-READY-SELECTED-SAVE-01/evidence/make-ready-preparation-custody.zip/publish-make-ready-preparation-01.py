"""Push qualified reviewed source and create its normal dev pull request once."""
from pathlib import Path
import hashlib,json,os,subprocess
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent
P='make-ready-preparation';REPO='Julesc013/factorio-launcher'
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',PYTHONOPTIMIZE='0',PYTHONDONTWRITEBYTECODE='1')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(*args):
 p=subprocess.run(args,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=180)
 assert p.returncode==0,(args[:4],p.returncode,p.stderr[-1800:])
 return p.stdout.rstrip('\r\n')
def write(path,value):
 with path.open('x',encoding='utf-8') as stream:json.dump(value,stream,indent=2);stream.write('\n')
assert __debug__
V=E/(P+'-commit-review-01.json');review_bytes=V.read_bytes();v=json.loads(review_bytes)
review_sha=hashlib.sha256(review_bytes).hexdigest()
assert v['verdict']=='PASS' and v['independent'] and v['non_authoring'] and v['approve_normal_checked_integration']
assert v['publication_driver_sha256']==sha(Path(__file__))
committed_path=E/(P+'-committed-01.json');committed_bytes=committed_path.read_bytes();c=json.loads(committed_bytes)
HEAD=c['head'];BASE=c['integration_base'];BRANCH=c['branch']
def bound():
 assert V.read_bytes()==review_bytes and committed_path.read_bytes()==committed_bytes,'Approval/commit identity changed'
 assert run('git','rev-parse','HEAD')==HEAD and run('git','branch','--show-current')==BRANCH
 assert not run('git','status','--porcelain')
assert c['review_sha256']==review_sha and c['base']==BASE==v['base_commit']
assert c['snapshot_sha256']==v['snapshot_sha256'] and c['message_sha256']==v['message_sha256']
assert run('git','rev-parse','HEAD')==HEAD and run('git','branch','--show-current')==BRANCH and not run('git','status','--porcelain')
assert run('git','show','-s','--format=%P',HEAD)==BASE
identity=run('powershell','-NoProfile','-Command','[System.Security.Principal.WindowsIdentity]::GetCurrent().Name')
assert identity.casefold()==r'BLACKGLASS-WIN1\Jules'.casefold()
run('gh','auth','status');assert run('gh','api','user','--jq','.login')=='Julesc013'
assert json.loads(run('gh','api','repos/'+REPO+'/git/ref/heads/dev'))['object']['sha']==BASE
assert not run('git','ls-remote','--heads','origin','refs/heads/'+BRANCH),'Existing remote task branch requires inspection'
prs=json.loads(run('gh','api','repos/'+REPO+'/pulls?state=open&base=dev&head=Julesc013:'+BRANCH))
assert not prs,'Existing PR must be continued, not duplicated'
OUT=E/(P+'-published-01.json');assert not OUT.exists()
body=E/(P+'-pr-body-01.md')
with body.open('x',encoding='utf-8') as stream:
 stream.write('Make Ready now prepares routing configuration or selected-save declared context through the maintained presentation action. Each click admits one existing owner against a fresh revision, returns that owner’s actual partial receipt, and requires another revision before continuing. Interrupted dispatch retains its journal and immutable unknown receipt; existing domain recovery preserves custom inputs.\n\n'
 'Validation: five native smoke results from the unchanged shared Release build; all73 focused methods, including five new backend methods and the three-mode compiled Windows control; three historical receipt replays. Failure receipts remain in the custody archive. The prior delivered retained-extraction proof is preserved alongside this source evidence.\n\n'
 'Evidence: `.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01/evidence/make-ready-preparation.v1.json` and its verified custody archive. Required Checks own platform qualification. Genuine produced-package continuation follows normal checked integration.\n\n'
 'Authority: component preparation only. Full Make Ready, Play, game execution, live click-to-backend, human acceptance, F09/F11 and Beta gates remain open.\n\n'
 'Review focus: revision admission, single-owner dispatch, interruption recovery and raw-input preservation. Merge commit preserves this continuing provider/release train’s qualified source checkpoint.\n')
write(E/(P+'-publication-01.claim.json'),dict(pid=os.getpid(),source=HEAD,review_sha256=review_sha,no_automatic_replay=True))
bound()
log=E/(P+'-normal-push-01.log')
with log.open('xb') as stream:result=subprocess.run(['git','push','-u','origin',BRANCH],cwd=R,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
assert result.returncode==0,(result.returncode,str(log))
assert run('git','ls-remote','--heads','origin','refs/heads/'+BRANCH).split()[0]==HEAD
bound()
url=run('gh','pr','create','--repo',REPO,'--base','dev','--head',BRANCH,
 '--title','feat(readiness): prepare instance components through Make Ready','--body-file',str(body))
number=int(url.rsplit('/',1)[1]);pr=json.loads(run('gh','api','repos/'+REPO+'/pulls/'+str(number)))
bound()
assert pr['state']=='open' and not pr['draft'] and not pr['merged']
assert pr['head']['sha']==HEAD and pr['head']['ref']==BRANCH and pr['base']['ref']=='dev' and pr['base']['sha']==BASE
assert pr['head']['repo']['full_name']==pr['base']['repo']['full_name']==REPO
write(OUT,dict(source=HEAD,base=BASE,commit_parent=BASE,branch=BRANCH,
 pr=dict(number=number,url=pr['html_url'],state='OPEN',isDraft=False,headRefOid=HEAD,baseRefName='dev'),
 execution_identity=identity,github_account='Julesc013',normal_pushes=1,new_pull_requests=1,
 new_candidates=0,job_reruns=0,review_sha256=review_sha,push_log_sha256=sha(log)))
print(json.dumps(dict(status='reviewed_source_published',source=HEAD,pull_request=number,new_candidates=0)),flush=True)
