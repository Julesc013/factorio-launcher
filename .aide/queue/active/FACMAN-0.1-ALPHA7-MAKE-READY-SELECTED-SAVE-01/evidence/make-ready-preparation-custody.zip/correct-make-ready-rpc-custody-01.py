from pathlib import Path
import ast,json,hashlib,difflib
E=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def version(old,new,replacements):
 before=(E/old).read_text(encoding='utf-8');after=before
 for a,b in replacements.items():
  assert a in after,(old,a);after=after.replace(a,b)
 ast.parse(after)
 with (E/new).open('x',encoding='utf-8',newline='\n') as stream:stream.write(after)
 with (E/(new+'.diff')).open('x',encoding='utf-8',newline='\n') as stream:
  stream.write(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=old,tofile=new)))
version('owned-source-native-text-child-custody-05.py','owned-source-native-text-child-custody-06.py',{
 "                    workspace=Path(request['workspace']).resolve()":
 "                    assert Path(request['workspace']).is_absolute(), 'RPC workspace must be absolute before sending stdin'\n                    workspace=Path(request['workspace']).resolve()"})
version('run-make-ready-focused-07.py','run-make-ready-focused-08.py',{
 'make-ready-source-freeze-05':'make-ready-source-freeze-06',
 'make-ready-frozen-source-review-05':'make-ready-frozen-source-review-06',
 'owned-source-native-text-child-custody-05.py':'owned-source-native-text-child-custody-06.py'})
version('qualify-make-ready-10.py','qualify-make-ready-11.py',{
 'make-ready-source-freeze-05':'make-ready-source-freeze-06',
 'make-ready-frozen-source-review-05':'make-ready-frozen-source-review-06',
 'run-make-ready-focused-07.py':'run-make-ready-focused-08.py',
 'def frozen():':'reused_bytes={}\ndef frozen():\n    for path,data in reused_bytes.items():assert path.read_bytes()==data, "Reused evidence changed"',
 "    assert sha(previous_freeze)==review['reused_groups_source_freeze_sha256']\n    assert json.loads(previous_freeze.read_bytes())['changed_paths_raw_sha256']==freeze['changed_paths_raw_sha256']":
 "    previous_freeze_bytes=previous_freeze.read_bytes();reused_bytes[previous_freeze]=previous_freeze_bytes\n    previous_freeze_sha=hashlib.sha256(previous_freeze_bytes).hexdigest()\n    assert previous_freeze_sha==review['reused_groups_source_freeze_sha256']\n    assert json.loads(previous_freeze_bytes)['changed_paths_raw_sha256']==freeze['changed_paths_raw_sha256']",
 "        path=E/('make-ready-focused-'+group+'-03.json');value=json.loads(path.read_bytes())\n        assert sha(path)==review['reused_focused_groups_sha256'][group]":
 "        path=E/('make-ready-focused-'+group+'-03.json');data=path.read_bytes();reused_bytes[path]=data\n        value=json.loads(data);digest=hashlib.sha256(data).hexdigest()\n        assert digest==review['reused_focused_groups_sha256'][group]",
 "value['source_freeze_sha256']==sha(previous_freeze)":"value['source_freeze_sha256']==previous_freeze_sha",
 "dict(group=group,passed=count,receipt_sha256=sha(path))":"dict(group=group,passed=count,receipt_sha256=digest)",
 "    assert sha(prior_regression)==review['prior_failed_regression_receipt_sha256']\n    value=json.loads(prior_regression.read_bytes())":
 "    prior_regression_bytes=prior_regression.read_bytes();reused_bytes[prior_regression]=prior_regression_bytes\n    prior_regression_sha=hashlib.sha256(prior_regression_bytes).hexdigest()\n    assert prior_regression_sha==review['prior_failed_regression_receipt_sha256']\n    value=json.loads(prior_regression_bytes)",
 "failed_receipt_sha256=sha(prior_regression)":"failed_receipt_sha256=prior_regression_sha"})
parent=E/'make-ready-source-freeze-05.json';f=json.loads(parent.read_bytes())
f.update(parent_source_freeze_sha256=sha(parent),
 qualification_runner_sha256=sha(E/'qualify-make-ready-11.py'),focused_runner_sha256=sha(E/'run-make-ready-focused-08.py'),
 text_child_helper_sha256=sha(E/'owned-source-native-text-child-custody-06.py'),
 review_correction='Require absolute RPC stdin workspace; capture all reused receipt bytes once and check unchanged through suffix/history/final gates')
target=E/'make-ready-source-freeze-06.json'
with target.open('x',encoding='utf-8') as stream:json.dump(f,stream,indent=2);stream.write('\n')
print(json.dumps({name:sha(E/name) for name in ['make-ready-source-freeze-06.json','owned-source-native-text-child-custody-06.py','run-make-ready-focused-08.py','qualify-make-ready-11.py']}))
