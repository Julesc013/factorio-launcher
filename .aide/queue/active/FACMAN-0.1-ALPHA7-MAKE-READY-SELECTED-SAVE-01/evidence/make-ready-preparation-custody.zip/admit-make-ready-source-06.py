"""Admit seven reviewed Make Ready files only after actual integrated-package acceptance."""
import datetime,hashlib,json,os,shutil,subprocess,traceback
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
UNIT='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01';BRANCH='task/facman-world-restore-retention-01'
OUT=E/'make-ready-source-admission-02.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def captured(name):
    data=(E/name).read_bytes();return json.loads(data),hashlib.sha256(data).hexdigest()
env=dict(os.environ,FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',FACMAN_TASK_ROOT=str(W),
    TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONOPTIMIZE='0',PYTHONDONTWRITEBYTECODE='1')
def git(*args):return subprocess.check_output(['git',*args],cwd=R,env=env,text=True,encoding='utf-8').rstrip('\r\n')
record=dict(status='VALIDATING_REVIEWED_SOURCE_ADMISSION',steps=[],source_applied=False,source_qualified=False,
    new_roots=0,new_clones=0,new_worktrees=0,new_builds=0,new_candidates=0,github_queries=0,
    foreign_Universal_work_mutated=False,whole_F11_closed=False,beta_qualified=False)
def save():
    pending=OUT.with_suffix('.writing');pending.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');pending.replace(OUT)
def step(name,args,accepted=(0,),timeout=300):
    log=E/('make-ready-admission02-'+name+'.log')
    with log.open('xb') as stream:
        child=subprocess.Popen(args,cwd=R,env=env,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        try:child.wait(timeout=timeout)
        except BaseException:
            cleanup=[]
            try:
                if child.poll() is None:child.kill()
            except BaseException as cleanup_error:cleanup.append(dict(step='owned_child_kill',error=repr(cleanup_error)))
            try:child.wait(timeout=10)
            except BaseException as cleanup_error:cleanup.append(dict(step='bounded_wait',error=repr(cleanup_error)))
            record['possible_failed_step']=dict(name=name,pid=child.pid,log=str(log),log_sha256=sha(log),cleanup_errors=cleanup,possible_live_owned_pid=child.pid if child.poll() is None else None)
            save();raise
    record['steps'].append(dict(name=name,exit_code=child.returncode,pid=child.pid,log=str(log),log_sha256=sha(log)));save()
    assert child.returncode in accepted,(name,child.returncode,str(log))
    return log
assert __debug__ and not OUT.exists()
driver_review,driver_review_sha=captured('make-ready-admission-driver-review-06.json')
assert driver_review['verdict']=='PASS' and driver_review['independent'] and driver_review['non_authoring']
assert driver_review['admission_driver_sha256']==sha(Path(__file__))
proposal,proposal_sha=captured('make-ready-source-proposal-06.json')
assert proposal_sha=='4bdc59650d1d8db4b27fc9b75ab4708239a1c358865135da4665ec9925c03bc4'
source_review,source_review_sha=captured('make-ready-source-final-review-05.json')
control_review,control_review_sha=captured('make-ready-control-oracle-review-06.json')
assert source_review['status']=='CONDITIONALLY_SUITABLE_FOR_SOURCE_ADMISSION_AND_BOUNDED_EXECUTION'
assert control_review['status']=='CONDITIONALLY_SUITABLE_TO_EXECUTE_AFTER_SOURCE_ADMISSION'
assert source_review_sha=='b50e2ea956470c4a01161159541b6b634dcc0501c156940a773aee0943fda0ba'
assert control_review_sha=='da2ff8517c0b19910c46570eb44844a52d91019760ff42e414ac565f22db5b2f'
assert control_review['proposal_manifest_sha256']==proposal_sha
assert control_review['proposed_file_sha256']=={p:v['proposed_sha256'] for p,v in proposal['files'].items()}
assert all(source_review['proposed_file_sha256'][p]==v['proposed_sha256'] for p,v in proposal['files'].items() if p!='tests/test_make_ready_preparation.py')
patch=Path(proposal['patch']);patch_bytes=patch.read_bytes()
assert hashlib.sha256(patch_bytes).hexdigest()==proposal['patch_sha256']==control_review['proposal_patch_sha256']
assert len(proposal['files'])==7
for p,v in proposal['files'].items():assert sha(Path(v['proposed_path']))==v['proposed_sha256']
completion,completion_sha=captured('retained-extraction-coverage-policy-postintegration-completion-01.json')
assert completion['status']=='reviewed_retained_extraction_integrated_and_clean_primaries_synchronized' and completion['task_refs_retired']
assert completion['source']=='1f517c39f91810d693e0f2c5c08ae3f97b9045e1' and completion['pull_request']==402
integration,integration_sha=captured('retained-extraction-coverage-policy-integration-1f517c39.json')
assert integration['status']=='required_source_and_merge_CI_pass'
base=completion['facman_dev'];assert integration['merge']==base
proof,proof_sha=captured('produced-retained-extraction-proof-01.json')
admission,admission_sha=captured('produced-retained-extraction-admission-01.json')
acceptance,acceptance_sha=captured('produced-retained-extraction-acceptance-review-01.json')
assert proof['status']=='PASS_EXACT_PRODUCED_WINDOWS_RETAINED_EXTRACTION_PUBLIC_OWNERS'
assert acceptance['verdict']=='PASS' and acceptance['independent'] and acceptance['non_authoring'] and acceptance['approve_proof']
assert acceptance['proof_sha256']==proof_sha and acceptance['admission_sha256']==admission_sha
assert acceptance['integration_completion_sha256']==completion_sha and acceptance['integration_sha256']==integration_sha
assert proof['tests_run']==17 and proof['skipped']==0 and proof['full_methods']==16
assert not proof['original_all17_zero_skip_qualification'] and len(proof['retained_host_gaps'])==2
assert git('rev-parse','HEAD')==git('rev-parse','origin/dev')==base and git('branch','--show-current')=='dev'
assert not git('status','--porcelain')
marker_path=W/'.facman-development-root.v1.json';marker=json.loads(marker_path.read_text(encoding='utf-8-sig'))
assert marker['kind']=='task-root' and Path(marker['canonical_path']).resolve()==W.resolve()
assert Path(marker['source_root']).resolve()==R.resolve() and marker['task_id']==BRANCH
for p,v in proposal['files'].items():
    assert (sha(R/p)==v['original_sha256']) if v['original_sha256'] else not (R/p).exists(),p
# This numbered recovery preserves the real failure and requires actual completed audit evidence.
prior_failure,prior_failure_sha=captured('make-ready-source-admission-01.json')
diagnostic,diagnostic_sha=captured('make-ready-resource-scan-diagnostic-01.json')
assert prior_failure_sha=='98ae7b7c8b4cf926d106b14f0401ee9e7b054f93a96ba617b4c5a7db7afc6ec4'
assert diagnostic_sha=='0a4aabd937a086ee0239128649745de32afbf30ae5c48d3f73a4f3fd1c926080'
assert prior_failure['status']=='ACTIONABLE_FAILURE_PRESERVE_TASK_SOURCE' and not prior_failure['source_applied']
assert prior_failure['possible_failed_step']['name']=='doctor' and '300' in prior_failure['error']
assert diagnostic['previous_failure_sha256']==prior_failure_sha and diagnostic['source_head']==base
assert not diagnostic['source_changed'] and diagnostic['native_builds']==0 and diagnostic['new_roots']==0
assert sha(R/'tools/workspace_hygiene.py')==diagnostic['hygiene_source_sha256']
assert sha(E/'make-ready-resource-scan-doctor-01.json')==diagnostic['doctor_sha256']
assert sha(E/'make-ready-resource-scan-trace-01.jsonl')==diagnostic['trace_sha256']
assert set(diagnostic['violations'])<={'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
assert diagnostic['task_root_bytes']+2147483648<=21474836480
# Refuse if any recorded owner from the interrupted, read-only admission remains alive.
residual=subprocess.run(['powershell','-NoProfile','-Command',
    '@(Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -in @(60332,32156,30676,44072) } | Select-Object ProcessId,Name,CreationDate) | ConvertTo-Json -Compress'],
    cwd=R,env=env,capture_output=True,text=True,timeout=30)
assert residual.returncode==0 and (not residual.stdout.strip() or json.loads(residual.stdout)==[]),'Prior owned PID remains; stop for actual owner audit'
record['resource_inspection_recovery']=dict(previous_failure_sha256=prior_failure_sha,diagnostic_sha256=diagnostic_sha,
    inspection_deadline_seconds=900,ordinary_step_deadline_seconds=300,quota_checks_unchanged=True,
    prior_owned_pids_absent=[60332,32156,30676,44072],cause_unproven=True)
with (E/'make-ready-source-admission-02.claim.json').open('x',encoding='utf-8') as stream:
    json.dump(dict(pid=os.getpid(),driver_sha256=sha(Path(__file__)),base=base,no_automatic_replay=True),stream)
record.update(base=base,branch=BRANCH,driver_review_sha256=driver_review_sha,proposal_sha256=proposal_sha,
    source_review_sha256=source_review_sha,control_review_sha256=control_review_sha,
    retained_integration_sha256=integration_sha,retained_completion_sha256=completion_sha,
    retained_produced_proof_sha256=proof_sha,retained_produced_acceptance_sha256=acceptance_sha)
save()
try:
    step('paths',['py','-3','tools/workspace_hygiene.py','paths'])
    doctor=json.loads(step('doctor',['py','-3','tools/workspace_hygiene.py','doctor','--measure'],accepted=(0,1),timeout=900).read_bytes())
    assert set(doctor['violations']) <= {'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
    assert len(doctor['task_roots'])<=8 and doctor['task_root_bytes']+2147483648<=21474836480
    assert shutil.disk_usage(W).free>=10737418240
    for action in ['inspect','noop-check','recover']:step('task-'+action,['py','-3','.aide/scripts/aide_lite.py','task',action,'--task-id',UNIT])
    for action in ['policy','detect','plan']:step('git-'+action,['py','-3','.aide/scripts/aide_lite.py','git',action])
    record['explicit_branch_plan']=dict(operation='create_task_branch_after_prior_exact_refs_retired',branch=BRANCH,target='dev',base=base,
        operator_authorization='Existing explicit go/continue authorization for normal task integration; no extra root or worktree')
    save()
    identity=subprocess.check_output(['powershell','-NoProfile','-Command','[System.Security.Principal.WindowsIdentity]::GetCurrent().Name'],cwd=R,env=env,text=True).strip()
    assert identity.casefold()==r'BLACKGLASS-WIN1\Jules'.casefold()
    credential=subprocess.run(['gh','auth','status'],cwd=R,env=env,capture_output=True,text=True,timeout=30)
    assert credential.returncode==0,'User-context credential check failed; no branch effect'
    assert subprocess.check_output(['gh','api','user','--jq','.login'],cwd=R,env=env,text=True).strip()=='Julesc013'
    step('fetch-dev',['git','fetch','--no-tags','origin','dev'])
    assert git('rev-parse','HEAD')==git('rev-parse','origin/dev')==base and git('branch','--show-current')=='dev' and not git('status','--porcelain')
    assert subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/'+BRANCH],cwd=R,env=env).returncode==1
    assert sha(patch)==hashlib.sha256(patch_bytes).hexdigest()
    step('apply-check',['git','apply','--check',str(patch)])
    assert git('rev-parse','HEAD')==git('rev-parse','origin/dev')==base and git('branch','--show-current')=='dev'
    assert not git('status','--porcelain') and not git('diff','--cached','--name-only')
    assert sha(patch)==hashlib.sha256(patch_bytes).hexdigest()
    for p,v in proposal['files'].items():
        assert (sha(R/p)==v['original_sha256']) if v['original_sha256'] else not (R/p).exists(),p
    step('switch',['git','switch','-c',BRANCH,base])
    assert git('rev-parse','HEAD')==git('rev-parse','origin/dev')==base and git('branch','--show-current')==BRANCH
    assert not git('status','--porcelain') and not git('diff','--cached','--name-only')
    assert sha(patch)==hashlib.sha256(patch_bytes).hexdigest()
    for p,v in proposal['files'].items():
        assert (sha(R/p)==v['original_sha256']) if v['original_sha256'] else not (R/p).exists(),p
    step('apply',['git','apply',str(patch)])
    assert git('rev-parse','HEAD')==git('rev-parse','origin/dev')==base and git('branch','--show-current')==BRANCH
    assert not git('diff','--cached','--name-only')
    assert {row[3:] for row in git('-c','core.quotePath=false','status','--porcelain','--untracked-files=all').splitlines()}==set(proposal['files'])
    for p,v in proposal['files'].items():assert sha(R/p)==v['proposed_sha256'],p
    record.update(status='REVIEWED_SOURCE_APPLIED_REQUIRES_PREFLIGHT_FREEZE_AND_QUALIFICATION',source_applied=True,
        changed_paths_raw_sha256={p:sha(R/p) for p in proposal['files']},patch_sha256=hashlib.sha256(patch_bytes).hexdigest(),
        resources=dict(task_root_bytes=doctor['task_root_bytes'],peak_reserve_bytes=2147483648,free_bytes=shutil.disk_usage(W).free),
        finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    marker['last_used_at']=record['finished_at']
    if 'last_used_at_utc' in marker:marker['last_used_at_utc']=record['finished_at']
    marker_path.write_text(json.dumps(marker,indent=2)+'\n',encoding='utf-8');save()
    print(json.dumps(dict(status=record['status'],base=base,files=7)),flush=True)
except Exception as error:
    record.update(status='ACTIONABLE_FAILURE_PRESERVE_TASK_SOURCE',error=repr(error),traceback=traceback.format_exc());save();raise
