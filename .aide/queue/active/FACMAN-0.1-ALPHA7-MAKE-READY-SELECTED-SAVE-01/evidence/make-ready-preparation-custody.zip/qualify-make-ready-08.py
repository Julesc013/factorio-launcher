"""One frozen existing-INI owner campaign in the already owned native cache."""
from pathlib import Path
import hashlib, json, os, re, shutil, subprocess, sys, time, traceback
R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
W, B = E.parent, E.parent / 'native-developer'
F = E / 'make-ready-source-freeze-03.json'
V = E / 'make-ready-frozen-source-review-03.json'
OUT = E / 'make-ready-qualification-02.json'
env = dict(os.environ, FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds', FACMAN_TASK_ROOT=str(W),
    TEMP=str(W / 't'), TMP=str(W / 't'), CMAKE_BUILD_PARALLEL_LEVEL='2', FACMAN_MIN_FREE_GIB='10',
    PYTHONOPTIMIZE='0', PYTHONPATH=os.pathsep.join([str(R / 'tests'), str(R)]))
os.environ.update(env)
sys.path.insert(0, str(R))
from tools import native_build, provider_workspace
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
freeze_bytes=F.read_bytes(); freeze=json.loads(freeze_bytes)
review_bytes=V.read_bytes(); review=json.loads(review_bytes)
preflight_path=E/'make-ready-source-preflight-03.json'
preflight_bytes=preflight_path.read_bytes(); preflight=json.loads(preflight_bytes)
record = dict(status='running', source_parent=freeze['base'], steps=[], native_workers=2, new_roots=0, new_worktrees=0,
    new_clones=0, new_candidates=0, whole_workunit_closed=False, beta_qualified=False,
    opaque_sacl_compared=False, power_loss_qualified=False, real_game_effects=False, visible_UI_acceptance=False,
    full_make_ready_execution_available=False, play_authority=False, prior_q03_timeout_resolved=False)
def save():
    pending = OUT.with_suffix('.pending.json'); pending.write_text(json.dumps(record, indent=2) + '\n',encoding='utf-8'); os.replace(pending, OUT)
def git(*args): return subprocess.check_output(['git', '-c', 'core.quotePath=false', *args], cwd=R, env=env, text=True).rstrip('\r\n')
def frozen():
    assert F.read_bytes()==freeze_bytes and V.read_bytes()==review_bytes,'Frozen source/approval was changed or revoked; stop before another effect'
    assert preflight_path.read_bytes()==preflight_bytes,'Source preflight approval was changed; stop before another effect'
    assert git('rev-parse', 'HEAD') == freeze['base'] and git('branch', '--show-current') == freeze['branch']
    assert not git('diff', '--cached', '--name-only')
    assert {row[3:] for row in git('status', '--porcelain', '--untracked-files=all').splitlines()} == set(freeze['changed_paths_raw_sha256'])
    assert {p: sha(R / p) for p in freeze['changed_paths_raw_sha256']} == freeze['changed_paths_raw_sha256']
def census(owner_pid, known_owned=None):
    probe = subprocess.run(['powershell', '-NoProfile', '-Command',
        '@(Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,Name,CreationDate) | ConvertTo-Json -Compress'],
        capture_output=True, text=True, timeout=30)
    assert probe.returncode == 0, 'Owned process census unavailable; stop before another heavy job'
    processes = json.loads(probe.stdout) if probe.stdout.strip() else []
    if isinstance(processes, dict): processes = [processes]
    owned = set(known_owned or []) | {owner_pid}
    while True:
        expanded = owned | {p['ProcessId'] for p in processes if p['ParentProcessId'] in owned}
        if expanded == owned: break
        owned = expanded
    return dict(owned_ids=sorted(owned), live_owned=[p for p in processes if p['ProcessId'] in owned],
        native_owners=[p for p in processes if p['Name'].lower() in {'msbuild.exe', 'cl.exe', 'link.exe', 'cmake.exe', 'ctest.exe'}])
def step(name, command, timeout=300, accepted=(0,), child_env=None):
    frozen(); log = E / ('make-ready-q02-' + name + '.log')
    started = time.monotonic(); print('START ' + name, flush=True)
    with log.open('xb') as stream:
        child = subprocess.Popen(command, cwd=R, env=child_env or env, stdout=stream, stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW)
        try:
            record['active_step'] = name; record['active_pid'] = child.pid; save()
            child.wait(timeout=timeout)
        except BaseException as error:
            before, after = None, None
            try: before = census(child.pid)
            except BaseException as probe_error: record['before_timeout_census_error'] = repr(probe_error)
            try:
                if child.poll() is None:child.kill()
            except BaseException as kill_error:record['owned_child_kill_error']=repr(kill_error)
            try: child.wait(timeout=10)
            except BaseException as drain_error: record['timeout_drain_error'] = repr(drain_error)
            try: after = census(child.pid, (before or {}).get('owned_ids'))
            except BaseException as probe_error: record['after_timeout_census_error'] = repr(probe_error)
            record['steps'].append(dict(name=name, pid=child.pid, status='STOP_PRESERVE_DESCENDANTS', error=repr(error),
                census_before=before, census_after=after, log=str(log), log_sha256=sha(log)))
            record['later_heavy_job_requires_residual_owner_audit'] = True; save(); raise
    record['steps'].append(dict(name=name, command=command, owned_pid=child.pid, exit_code=child.returncode,
        seconds=round(time.monotonic() - started, 3), log=str(log), log_sha256=sha(log)))
    save(); print('DONE ' + name + ': ' + str(child.returncode), flush=True)
    if child.returncode not in accepted:
        print('\n'.join(log.read_text(errors='replace').splitlines()[-60:]), flush=True)
        raise RuntimeError(name + ' failed; retain exact source, cache and evidence')
    return log

assert __debug__ and not OUT.exists()
with (E / 'make-ready-qualification-02.claim.json').open('x',encoding='utf-8') as stream:
    json.dump(dict(pid=os.getpid(), freeze_sha256=hashlib.sha256(freeze_bytes).hexdigest()), stream)
save()
try:
    assert sha(Path(__file__).resolve()) == freeze['qualification_runner_sha256']; frozen()
    assert review['verdict'] == 'PASS' and review['independent'] and review['non_authoring']
    assert review['freeze_sha256'] == hashlib.sha256(freeze_bytes).hexdigest() and review['qualification_runner_sha256'] == sha(Path(__file__).resolve())
    assert review['changed_paths_raw_sha256'] == freeze['changed_paths_raw_sha256']
    record.update(source_freeze_sha256=hashlib.sha256(freeze_bytes).hexdigest(), frozen_source_review_sha256=hashlib.sha256(review_bytes).hexdigest())
    assert hashlib.sha256(preflight_bytes).hexdigest() == freeze['source_preflight_sha256']
    assert preflight['status'] == 'PASS_SOURCE_PREFLIGHT_REQUIRES_FROZEN_REVIEW_AND_NATIVE'
    assert preflight['changed_paths_raw_sha256'] == freeze['changed_paths_raw_sha256']
    for item in preflight['steps']: assert item['exit_code'] == 0 and sha(Path(item['log'])) == item['log_sha256']
    marker = json.loads((W / '.facman-development-root.v1.json').read_text(encoding='utf-8-sig'))
    assert marker['kind'] == 'task-root' and Path(marker['canonical_path']).resolve() == W.resolve()
    assert Path(marker['source_root']).resolve() == R.resolve() and marker['task_id'] == freeze['branch']
    step('paths', ['py', '-3', 'tools/workspace_hygiene.py', 'paths'])
    doctor = json.loads(step('doctor', ['py', '-3', 'tools/workspace_hygiene.py', 'doctor', '--measure'], accepted=(0, 1), timeout=900).read_text())
    assert set(doctor['violations']) <= {'unmanaged_secondary_worktrees_present', 'merged_local_task_branches_present'}
    assert len(doctor['task_roots']) <= 8 and doctor['task_root_bytes'] + 2147483648 <= 21474836480
    assert shutil.disk_usage(W).free >= 10737418240
    record['resources'] = dict(task_root_bytes=doctor['task_root_bytes'], reserved_peak_bytes=2147483648,
        free_before_bytes=shutil.disk_usage(W).free, retained_findings=doctor['violations']); save()
    query = "Get-CimInstance Win32_Process | Where-Object { ($_.Name -match '^(cmake|MSBuild|cl|link|ninja|ctest)\\.exe$' -and $_.CommandLine -notmatch '[-/]nodemode:') -or ($_.Name -eq 'dotnet.exe' -and $_.CommandLine -match ' (build|msbuild) ') } | Select-Object ProcessId,Name,CreationDate | ConvertTo-Json -Compress"
    deadline, previous = time.monotonic() + 1200, None
    while True:
        probe = subprocess.run(['powershell', '-NoProfile', '-Command', query], text=True, capture_output=True, timeout=30)
        assert probe.returncode == 0, 'Heavy-owner census failed; preserve parallel jobs'
        active = probe.stdout.strip()
        if not active: break
        if active != previous:
            record.setdefault('preserved_foreign_heavy_jobs', []).append(active); save()
            print('Existing heavy job owns machine: ' + active, flush=True); previous = active
        assert time.monotonic() < deadline, 'Heavy-owner deadline; no duplicate campaign started'
        time.sleep(10)
    providers = freeze['provider_roots_reused_readonly']; components = provider_workspace.locked_components(R)
    for key, alias in [('universal_launcher', 'ULK'), ('universal_setup', 'USK')]:
        provider_workspace.verify_checkout(Path(providers[alias]), components[key])
    targets = ['facman_cli', 'flb_factorio_instance_model_smoke', 'facman_presentation_service_smoke',
        'fl_transaction_session_smoke', 'fl_platform_io_smoke', 'fl_archive_core_smoke']
    step('generated-before-build', ['py', '-3', 'tools/codegen/generate_contracts.py', '--check'])
    prior_path=E/'make-ready-native-qualification-01.json'
    prior_bytes=prior_path.read_bytes();prior=json.loads(prior_bytes)
    old_freeze_path=E/'make-ready-source-freeze-01.json';old_freeze_bytes=old_freeze_path.read_bytes();old_freeze=json.loads(old_freeze_bytes)
    assert review['approve_native_reuse'] and review['prior_native_qualification_sha256']==hashlib.sha256(prior_bytes).hexdigest()
    assert review['prior_source_freeze_sha256']==hashlib.sha256(old_freeze_bytes).hexdigest()
    assert prior['status']=='PASS_NATIVE_REQUIRES_FOCUSED_QUALIFICATION' and prior['native_tests']==5
    assert prior['source_freeze_sha256']==hashlib.sha256(old_freeze_bytes).hexdigest()
    assert set(old_freeze['changed_paths_raw_sha256'])==set(freeze['changed_paths_raw_sha256'])
    allowed={'tests/test_make_ready_preparation.py','.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01/ExecPlan.md'}
    assert {p for p,digest in old_freeze['changed_paths_raw_sha256'].items() if freeze['changed_paths_raw_sha256'][p]!=digest}<=allowed
    for item in prior['binaries'].values():assert sha(Path(item['path']))==item['sha256']
    for item in prior['build_and_native_steps']:assert item['exit_code']==0 and sha(Path(item['log']))==item['log_sha256']
    exe=Path(prior['executable']);assert exe.resolve()==(B/'Release/facman.exe').resolve()
    env.update(FACMAN_CLI_EXE=str(exe),FACMAN_NATIVE_CLI=str(exe))
    record['binaries']=prior['binaries']
    record['native_reuse']=dict(prior_native_qualification_sha256=hashlib.sha256(prior_bytes).hexdigest(),
        prior_source_freeze_sha256=hashlib.sha256(old_freeze_bytes).hexdigest(),native_passed=5,
        repeated_builds=0,compiled_source_unchanged=True)
    save()
    focused_runner = E / 'run-make-ready-focused-05.py'
    assert sha(focused_runner) == freeze['focused_runner_sha256']
    assert review['focused_runner_sha256'] == freeze['focused_runner_sha256']
    native_receipt_path=E/'make-ready-native-qualification-02.json'
    assert not native_receipt_path.exists()
    native_receipt=dict(status='PASS_NATIVE_REQUIRES_FOCUSED_QUALIFICATION',
        source_freeze_sha256=hashlib.sha256(freeze_bytes).hexdigest(),
        frozen_review_sha256=hashlib.sha256(review_bytes).hexdigest(),
        executable=str(exe),executable_sha256=sha(exe),native_tests=5,
        build_and_native_steps=prior['build_and_native_steps'],native_reused=True,native_reuse=record['native_reuse'],
        binaries=record['binaries'],new_roots=0,new_clones=0,new_candidates=0,
        source_focused_qualified=False,produced_package_qualified=False,whole_F11_closed=False)
    native_receipt_path.write_text(json.dumps(native_receipt,indent=2)+'\n',encoding='utf-8')
    record['native_qualification_sha256']=sha(native_receipt_path);save()
    for group,expected_count in [('new',5),('control',1),('regression',67)]:
        if group=='control':
            doctor=json.loads(step('control-doctor',['py','-3','tools/workspace_hygiene.py','doctor','--measure'],accepted=(0,1),timeout=900).read_text(encoding='utf-8'))
            assert set(doctor['violations']) <= {'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
            assert len(doctor['task_roots'])<=8 and doctor['task_root_bytes']+2147483648<=21474836480
            assert shutil.disk_usage(W).free>=10737418240
            control_deadline,previous=time.monotonic()+1200,None
            while True:
                probe=subprocess.run(['powershell','-NoProfile','-Command',query],text=True,capture_output=True,timeout=30)
                assert probe.returncode==0,'Control heavy-owner census failed; preserve parallel jobs'
                active=probe.stdout.strip()
                if not active:break
                if active!=previous:
                    record.setdefault('preserved_foreign_heavy_jobs_before_control',[]).append(active);save()
                    print('Existing heavy job owns machine before controls: '+active,flush=True);previous=active
                assert time.monotonic()<control_deadline,'Control heavy-owner deadline; no overlapping control build admitted'
                time.sleep(10)
        step('focused-'+group,[sys.executable,'-B',str(focused_runner),group],timeout=1800)
        group_receipt=E/('make-ready-focused-'+group+'-02.json')
        value=json.loads(group_receipt.read_bytes())
        assert value['status']=='PASS_SOURCE_FOCUSED_QUALIFICATION' and value['tests_run']==expected_count and value['skipped']==0
        assert value['source_freeze_sha256']==hashlib.sha256(freeze_bytes).hexdigest() and value['executable_sha256']==sha(exe)
        record.setdefault('focused_groups',[]).append(dict(group=group,passed=expected_count,receipt_sha256=sha(group_receipt)));save()
    record['tests']=dict(native_passed=5,focused_passed=73,skipped=0,new_methods=6,compiled_control_modes=3);save()
    legacy = json.loads((E / 'presentation-intent-legacy-frozen.json').read_text(encoding='utf-8-sig'))
    workspace, receipt = Path(legacy['workspace']), Path(legacy['receipt_path'])
    def inventory(): return {p.relative_to(workspace).as_posix(): sha(p) for p in workspace.rglob('*') if p.is_file()}
    assert sha(receipt) == legacy['receipt_sha256'] and inventory() == legacy['workspace_inventory_sha256']
    record['historical_replays'] = []
    for index, (label, intent) in enumerate([('absent-default', None), ('explicit-menu', 'menu'), ('different-intent-conflict', 'load_save')], 1):
        frozen(); args = [str(exe), *legacy['replay_argv'][1:]]
        if intent is not None: args += ['--intent', intent]
        entry = dict(label=label, argv=args, status='STARTING', lifetime_deadline_seconds=45)
        record['historical_replays'].append(entry); save()
        child = subprocess.Popen(args, cwd=R, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=subprocess.CREATE_NO_WINDOW)
        failure, out, err = None, b'', b''
        try:
            entry.update(owned_pid=child.pid, status='RUNNING'); save()
            out, err = child.communicate(timeout=45)
        except BaseException as error:
            failure=error;entry.update(status='STOP_PRESERVE_PROCESS_EVIDENCE',error=repr(error))
            # Drain the owned child before any fallible failure-receipt write.
            try: entry['census_before'] = census(child.pid)
            except BaseException as probe_error: entry['census_before_error'] = repr(probe_error)
            try:
                if child.poll() is None: child.kill()
            except BaseException as kill_error: entry['owned_child_kill_error'] = repr(kill_error)
            try: out, err = child.communicate(timeout=10)
            except BaseException as drain_error:
                out, err = getattr(drain_error, 'stdout', None) or getattr(error, 'stdout', None) or b'', getattr(drain_error, 'stderr', None) or getattr(error, 'stderr', None) or b''
                entry['bounded_drain_error'] = repr(drain_error)
            try: entry['census_after'] = census(child.pid, entry.get('census_before', {}).get('owned_ids'))
            except BaseException as probe_error: entry['census_after_error'] = repr(probe_error)
            record['later_heavy_job_requires_residual_owner_audit'] = True
        finally:
            streams = {}
            for name, data in [('stdout', out), ('stderr', err)]:
                path = E / ('make-ready-q02-legacy-' + str(index) + '.' + name)
                with path.open('xb') as stream: stream.write(data)
                streams[name] = dict(path=str(path), sha256=sha(path))
            entry.update(exit_code=child.poll(), streams=streams,
                status='ACTIONABLE_PROCESS_FAILURE' if failure else 'TERMINAL'); save()
        if failure is not None: raise failure
        value = json.loads(out); assert not err
        if intent != 'load_save': assert child.returncode == 0 and value['payload'] == json.loads(legacy['result_json'])
        else: assert child.returncode != 0 and value['error']['code'] == 'idempotency_key_conflict'
        assert sha(receipt) == legacy['receipt_sha256'] and inventory() == legacy['workspace_inventory_sha256']
        entry.update(status='PASS', workspace_unchanged=True); save()
    step('generated-after', ['py', '-3', 'tools/codegen/generate_contracts.py', '--check'])
    step('strict-after', ['py', '-3', 'tools/strict_check.py'],timeout=900)
    step('diff', ['git', 'diff', '--check']); frozen()
    record.update(status='PASS_SOURCE_QUALIFICATION_REQUIRES_ACCEPTANCE_REVIEW', ordinary_make_ready_component_qualified=True, live_click_to_backend_qualified=False, produced_package_qualified=False, resources={**record['resources'], 'free_after_bytes': shutil.disk_usage(W).free})
    save(); print(json.dumps(dict(status='PASS', tests=record['tests'], historical_replays=3)), flush=True)
except Exception as error:
    record.update(status='ACTIONABLE_FAILURE', error=str(error), traceback=traceback.format_exc()); save()
    print(traceback.format_exc(), flush=True); raise
