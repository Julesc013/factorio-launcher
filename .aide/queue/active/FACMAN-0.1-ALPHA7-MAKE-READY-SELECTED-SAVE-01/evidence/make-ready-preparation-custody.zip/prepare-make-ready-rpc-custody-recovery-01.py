from pathlib import Path
import ast,json,hashlib,subprocess,difflib,datetime
E=Path(__file__).resolve().parent;R=Path(r'D:\Projects\Factorio\factorio-launcher')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
freeze_path=E/'make-ready-source-freeze-04.json';freeze=json.loads(freeze_path.read_bytes())
assert {p:sha(R/p) for p in freeze['changed_paths_raw_sha256']}==freeze['changed_paths_raw_sha256']
failed=E/'make-ready-focused-regression-03.json';d=json.loads(failed.read_bytes())
assert d['status']=='ACTIONABLE_FAILURE' and d['tests_run']==52 and d['skipped']==0
assert sha(Path(d['test_log']))==d['test_log_sha256']
def version(old,new,replacements):
 before=(E/old).read_text(encoding='utf-8');after=before
 for a,b in replacements.items():
  assert a in after,(old,a);after=after.replace(a,b)
 ast.parse(after)
 with (E/new).open('x',encoding='utf-8',newline='\n') as stream:stream.write(after)
 with (E/(new+'.diff')).open('x',encoding='utf-8',newline='\n') as stream:
  stream.write(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=old,tofile=new)))
version('owned-source-native-text-child-custody-04.py','owned-source-native-text-child-custody-05.py',{
 'import hashlib,subprocess,threading,time':'import hashlib,json,subprocess,threading,time',
 "            assert not positional and '--workspace' in args\n            workspace=Path(str(args[args.index('--workspace')+1])).resolve()\n            assert workspace.is_relative_to(temporary)":
 "            assert not positional\n            self._rpc_stdin_owned='--workspace' not in args\n            if self._rpc_stdin_owned:\n                assert list(map(str,args[1:]))==['rpc','--stdio'] and kwargs.get('stdin')==subprocess.PIPE\n            else:\n                workspace=Path(str(args[args.index('--workspace')+1])).resolve()\n                assert workspace.is_relative_to(temporary)",
 "            try:out,err=original.communicate(self,input,min(remaining,timeout) if timeout is not None else remaining)":
 "            try:\n                if self._rpc_stdin_owned:\n                    assert isinstance(input,bytes) and len(input)<=8*1024*1024\n                    request=json.loads(input.decode(self._encoding,self._errors))\n                    assert isinstance(request,dict) and isinstance(request.get('workspace'),str)\n                    workspace=Path(request['workspace']).resolve()\n                    assert workspace.is_relative_to(temporary)\n                    self._entry['stdin_workspace']=str(workspace)\n                    self._entry['stdin_sha256']=hashlib.sha256(input).hexdigest()\n                    save()\n                out,err=original.communicate(self,input,min(remaining,timeout) if timeout is not None else remaining)"})
version('run-make-ready-focused-06.py','run-make-ready-focused-07.py',{
 'make-ready-source-freeze-04':'make-ready-source-freeze-05',
 'make-ready-frozen-source-review-04':'make-ready-frozen-source-review-05',
 'make-ready-native-qualification-03':'make-ready-native-qualification-04',
 "group+'-03":"group+'-04", "group+'-commands-03":"group+'-commands-04",
 'owned-source-native-text-child-custody-04.py':'owned-source-native-text-child-custody-05.py',
 '        suite=unittest.TestSuite(c for c in all_cases if c._testMethodName not in exclude);expected=67':
 "        admitted=[c for c in all_cases if c._testMethodName not in exclude]\n        assert review['approve_regression_prefix_reuse'] and [c.id() for c in admitted[:51]]==review['reused_regression_prefix_ids']\n        record['reused_regression_prefix_ids']=review['reused_regression_prefix_ids']\n        record['prior_failed_regression_receipt_sha256']=review['prior_failed_regression_receipt_sha256']\n        suite=unittest.TestSuite(admitted[51:]);expected=16"})
reuse_block="""    assert review['approve_regression_prefix_reuse']
    previous_freeze=E/'make-ready-source-freeze-04.json'
    assert sha(previous_freeze)==review['reused_groups_source_freeze_sha256']
    assert json.loads(previous_freeze.read_bytes())['changed_paths_raw_sha256']==freeze['changed_paths_raw_sha256']
    record['reused_focused_groups']=[]
    for group,count in [('new',5),('control',1)]:
        path=E/('make-ready-focused-'+group+'-03.json');value=json.loads(path.read_bytes())
        assert sha(path)==review['reused_focused_groups_sha256'][group]
        assert value['status']=='PASS_SOURCE_FOCUSED_QUALIFICATION' and value['tests_run']==count and value['skipped']==0
        assert value['source_freeze_sha256']==sha(previous_freeze) and value['executable_sha256']==sha(exe)
        assert sha(Path(value['test_log']))==value['test_log_sha256']
        for child in value['commands']+value['legacy_direct_children']+value['control_children']:
            assert child['status']=='TERMINAL' and child['raw_streams_complete']
            for stream in list(child['streams'].values())+list(child.get('audit_streams',{}).values()):assert sha(Path(stream['path']))==stream['sha256']
        record['reused_focused_groups'].append(dict(group=group,passed=count,receipt_sha256=sha(path)))
    prior_regression=E/'make-ready-focused-regression-03.json'
    assert sha(prior_regression)==review['prior_failed_regression_receipt_sha256']
    value=json.loads(prior_regression.read_bytes())
    assert value['status']=='ACTIONABLE_FAILURE' and value['tests_run']==52 and value['skipped']==0
    assert value['selected_test_ids'][:51]==review['reused_regression_prefix_ids']
    assert sha(Path(value['test_log']))==review['prior_failed_regression_test_log_sha256']==value['test_log_sha256']
    for child in value['commands']+value['legacy_direct_children']+value['control_children']:
        assert child['status']=='TERMINAL' and child['raw_streams_complete']
        for stream in list(child['streams'].values())+list(child.get('audit_streams',{}).values()):assert sha(Path(stream['path']))==stream['sha256']
    record['reused_regression_prefix']=dict(passed=51,ids=review['reused_regression_prefix_ids'],failed_aggregate_status_preserved=True,
        failed_receipt_sha256=sha(prior_regression),test_log_sha256=value['test_log_sha256'])
    save()
    for group,expected_count in [('regression',16)]:"""
version('qualify-make-ready-09.py','qualify-make-ready-10.py',{
 'make-ready-source-freeze-04':'make-ready-source-freeze-05',
 'make-ready-frozen-source-review-04':'make-ready-frozen-source-review-05',
 'make-ready-qualification-03':'make-ready-qualification-04',
 'make-ready-native-qualification-03':'make-ready-native-qualification-04',
 'make-ready-q03-':'make-ready-q04-', 'run-make-ready-focused-06.py':'run-make-ready-focused-07.py',
 "group+'-03":"group+'-04",
 "    for group,expected_count in [('new',5),('control',1),('regression',67)]:":reuse_block})
freeze.update(parent_source_freeze_sha256=sha(freeze_path),
 qualification_runner_sha256=sha(E/'qualify-make-ready-10.py'),focused_runner_sha256=sha(E/'run-make-ready-focused-07.py'),
 text_child_helper_sha256=sha(E/'owned-source-native-text-child-custody-05.py'),
 continuation_proposal=dict(reason='Validate actual existing RPC stdin workspace before sending input; preserve52method failedaggregate; reuse51 actuallypassed prefix and new/control only under independent exact decision',
  prior_failed_qualification_sha256=sha(E/'make-ready-qualification-03.json'),prior_failed_regression_receipt_sha256=sha(failed),
  prior_failed_regression_test_log_sha256=d['test_log_sha256'],proposed_prefix_ids=d['selected_test_ids'][:51],
  reused_focused_groups_sha256={g:sha(E/('make-ready-focused-'+g+'-03.json')) for g in ('new','control')},
  source_changed=False,repeated_native_builds=0,repeated_completed_methods=0),created_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
target=E/'make-ready-source-freeze-05.json'
with target.open('x',encoding='utf-8') as stream:json.dump(freeze,stream,indent=2);stream.write('\n')
print(json.dumps({name:sha(E/name) for name in ['make-ready-source-freeze-05.json','owned-source-native-text-child-custody-05.py','run-make-ready-focused-07.py','qualify-make-ready-10.py']}))
