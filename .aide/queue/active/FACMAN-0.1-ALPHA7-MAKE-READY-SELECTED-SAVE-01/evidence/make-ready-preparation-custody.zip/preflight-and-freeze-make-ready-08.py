"""Validate and freeze admitted Make Ready source without product execution."""
import ast,datetime,hashlib,json,os,subprocess,traceback
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
OUT=E/'make-ready-source-preflight-02.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=dict(os.environ,FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',FACMAN_TASK_ROOT=str(W),
    TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONOPTIMIZE='0',PYTHONDONTWRITEBYTECODE='1')
def git(*args):return subprocess.check_output(['git','-c','core.quotePath=false',*args],cwd=R,env=env,text=True,encoding='utf-8').rstrip('\r\n')
def paths():return {s[3:]:sha(R/s[3:]) for s in git('status','--porcelain','--untracked-files=all').splitlines()}
admission_path=E/'make-ready-source-admission-02.json';admission_bytes=admission_path.read_bytes();admission=json.loads(admission_bytes)
driver_bytes=(E/'make-ready-admission-driver-review-06.json').read_bytes();driver_review=json.loads(driver_bytes)
assert driver_review['verdict']=='PASS' and driver_review['independent'] and driver_review['non_authoring']
assert driver_review['preflight_driver_sha256']==sha(E/'preflight-and-freeze-make-ready-07.py')
# The previous accepted driver actually failed strict; this reversible recovery requires a new actual frozen-source review before native execution.
runner_path=E/'run-make-ready-focused-03.py';runner_bytes=runner_path.read_bytes()
helper_path=E/'owned-source-native-text-child-custody-04.py';helper_bytes=helper_path.read_bytes()
runner_review_path=E/'make-ready-focused-runner-review-03.json';runner_review_bytes=runner_review_path.read_bytes();runner_review=json.loads(runner_review_bytes)
assert runner_review['status']=='CONDITIONALLY_SUITABLE_FOR_FOCUSED_EXECUTION' and runner_review['independent'] and runner_review['non_authoring']
assert runner_review['runner_sha256']==hashlib.sha256(runner_bytes).hexdigest()
assert runner_review['text_child_helper_sha256']==hashlib.sha256(helper_bytes).hexdigest()

assert __debug__ and not OUT.exists()
assert admission['status']=='REVIEWED_SOURCE_APPLIED_REQUIRES_PREFLIGHT_FREEZE_AND_QUALIFICATION'
assert git('rev-parse','HEAD')==admission['base'] and git('branch','--show-current')==admission['branch']
recovery_path=E/'make-ready-complexity-recovery-proposal-01.json'
recovery_bytes=recovery_path.read_bytes();recovery=json.loads(recovery_bytes)
assert hashlib.sha256(recovery_bytes).hexdigest()=='1f9dc2c4da935d972f1c08e3b4054d0980f2c4345d07620181cb50cd930251bb'
assert sha(E/'make-ready-source-preflight-01.json')==recovery['previous_preflight_sha256']
assert recovery['status']=='SOURCE_CORRECTION_REQUIRES_STRICT_FREEZE_AND_INDEPENDENT_REVIEW'
assert not git('diff','--cached','--name-only') and paths()==recovery['changed_paths_raw_sha256']
record=dict(status='RUNNING_SOURCE_PREFLIGHT',base=admission['base'],branch=admission['branch'],steps=[],
    source_admission_sha256=hashlib.sha256(admission_bytes).hexdigest(),source_recovery_sha256=hashlib.sha256(recovery_bytes).hexdigest(),previous_failed_preflight_sha256=recovery['previous_preflight_sha256'],product_calls=0,new_builds=0,new_candidates=0,
    new_roots=0,new_worktrees=0,whole_F11_closed=False,beta_qualified=False)
def save():
    pending=OUT.with_suffix('.writing');pending.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');pending.replace(OUT)
with (E/'make-ready-source-preflight-02.claim.json').open('x',encoding='utf-8') as stream:json.dump(dict(pid=os.getpid(),no_automatic_replay=True),stream)
save()
try:
    plan=R/'.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01/ExecPlan.md'
    assert (R/'docs/development/make-ready-preparation.md').exists()
    plan.write_text(plan.read_text(encoding='utf-8')+'\n\nMake Ready preflight01 failed the unchanged presentation-service complexity\nratchet (497 points against494); no configure or native build ran. Preserve\nits exact source and strict evidence. Move the read-only four-action plan\nselector into existing action support, retaining the same refusal before\ndurable claim and exactly one owner dispatch after claim. The corrected\nservice has493 points; the budget and every behavioral oracle remain\nunchanged. Strict/generation, actual frozen-source assurance and first native\nqualification remain required; no failed preflight is qualified.\n',encoding='utf-8')
    ast.parse((R/'tests/test_make_ready_preparation.py').read_text(encoding='utf-8'))
    commands=[('metadata',['py','-3','tools/codegen/generate_metadata.py','--write']),
        ('contracts',['py','-3','tools/codegen/generate_contracts.py']),
        ('project-state',['py','-3','tools/project_state.py','--write']),
        ('strict',['py','-3','tools/strict_check.py']),('generated',['py','-3','tools/codegen/generate_contracts.py','--check']),
        ('diff',['git','diff','--check'])]
    for name,args in commands:
        log=E/('make-ready-preflight02-'+name+'.log');print('START '+name,flush=True)
        with log.open('xb') as stream:
            child=subprocess.Popen(args,cwd=R,env=env,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
            try:child.wait(timeout=900)
            except BaseException:
                cleanup=[]
                try:
                    if child.poll() is None:child.kill()
                except BaseException as cleanup_error:cleanup.append(dict(step='owned_child_kill',error=repr(cleanup_error)))
                try:child.wait(timeout=10)
                except BaseException as cleanup_error:cleanup.append(dict(step='bounded_wait',error=repr(cleanup_error)))
                record['failed_step']=dict(name=name,pid=child.pid,log=str(log),log_sha256=sha(log),cleanup_errors=cleanup,possible_live_owned_pid=child.pid if child.poll() is None else None)
                save();raise
        record['steps'].append(dict(name=name,exit_code=child.returncode,log=str(log),log_sha256=sha(log)));save()
        assert child.returncode==0,(name,child.returncode,str(log));print('DONE '+name,flush=True)
    assert git('rev-parse','HEAD')==admission['base'] and git('branch','--show-current')==admission['branch']
    assert not git('diff','--cached','--name-only')
    record.update(status='PASS_SOURCE_PREFLIGHT_REQUIRES_FROZEN_REVIEW_AND_NATIVE',changed_paths_raw_sha256=paths(),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
    assert admission_path.read_bytes()==admission_bytes and runner_path.read_bytes()==runner_bytes and helper_path.read_bytes()==helper_bytes and runner_review_path.read_bytes()==runner_review_bytes,'Admission or accepted runner/helper/review changed'
    freeze_path=E/'make-ready-source-freeze-01.json';assert not freeze_path.exists()
    previous=json.loads((E/'existing-configuration-source-freeze-04.json').read_bytes())
    freeze=dict(schema='facman.make_ready_source_freeze.v1',base=record['base'],branch=record['branch'],
        changed_paths_raw_sha256=record['changed_paths_raw_sha256'],provider_roots_reused_readonly=previous['provider_roots_reused_readonly'],
        source_preflight_sha256=sha(OUT),source_admission_sha256=record['source_admission_sha256'],
        source_preflight_path=str(OUT),source_recovery_sha256=record['source_recovery_sha256'],previous_failed_preflight_sha256=record['previous_failed_preflight_sha256'],
        qualification_runner_sha256=sha(E/'qualify-make-ready-06.py'),focused_runner_sha256=hashlib.sha256(runner_bytes).hexdigest(),
        text_child_helper_sha256=hashlib.sha256(helper_bytes).hexdigest(),
        source_proposal_sha256=sha(E/'make-ready-source-proposal-06.json'),
        source_proposal_review_sha256=sha(E/'make-ready-source-final-review-05.json'),
        control_oracle_review_sha256=sha(E/'make-ready-control-oracle-review-06.json'),
        focused_runner_review_sha256=hashlib.sha256(runner_review_bytes).hexdigest(),
        expected_native_tests=5,expected_focused_tests=73,expected_new_methods=6,expected_control_modes=3,
        expected_historical_replays=3,new_roots=0,new_clones=0,new_worktrees=0,new_candidates=0,
        source_qualified=False,produced_package_qualified=False,live_click_to_backend_qualified=False,
        full_F11_closed=False,beta_qualified=False,created_at=record['finished_at'])
    freeze_path.write_text(json.dumps(freeze,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(status=record['status'],freeze_sha256=sha(freeze_path),files=len(record['changed_paths_raw_sha256']))),flush=True)
except Exception as error:
    record.update(status='ACTIONABLE_FAILURE_PRESERVE_TASK_SOURCE',error=repr(error),traceback=traceback.format_exc(),changed_paths_raw_sha256=paths());save();raise
