from pathlib import Path
import hashlib,json,subprocess,ast,difflib
E=Path(__file__).resolve().parent;R=Path(r'D:\Projects\Factorio\factorio-launcher')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git','-c','core.quotePath=false',*args],cwd=R,text=True).rstrip('\r\n')
old=json.loads((E/'make-ready-source-freeze-03.json').read_bytes())
assert json.loads((E/'make-ready-qualification-02.json').read_bytes())['status']=='ACTIONABLE_FAILURE'
paths={line[3:]:sha(R/line[3:]) for line in git('status','--porcelain','--untracked-files=all').splitlines()}
assert set(paths)==set(old['changed_paths_raw_sha256'])
assert {p for p in paths if paths[p]!=old['changed_paths_raw_sha256'][p]}=={'tests/test_make_ready_preparation.py'}
assert not git('diff','--cached','--name-only') and git('rev-parse','HEAD')==old['base']
previous=json.loads((E/'make-ready-dry-run-recovery-proposal-01.json').read_bytes())
previous.update(changed_paths_raw_sha256=paths,prior_qualification_sha256=sha(E/'make-ready-qualification-02.json'),
 corrected_oracle_sha256=paths['tests/test_make_ready_preparation.py'],
 oracle_diff_sha256=None,reason='Align transport and semantic request/operation/attempt identities; retain exact dry-run refusal and no-effect assertions')
proposal=E/'make-ready-dry-run-recovery-proposal-02.json'
with proposal.open('x',encoding='utf-8') as stream:json.dump(previous,stream,indent=2);stream.write('\n')
def version(old_name,new_name,replacements):
 before=(E/old_name).read_text(encoding='utf-8');after=before
 for a,b in replacements.items():
  assert a in after,(old_name,a)
  after=after.replace(a,b)
 ast.parse(after)
 with (E/new_name).open('x',encoding='utf-8',newline='\n') as stream:stream.write(after)
 with (E/(new_name+'.diff')).open('x',encoding='utf-8',newline='\n') as stream:
  stream.write(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=old_name,tofile=new_name)))
version('run-make-ready-focused-05.py','run-make-ready-focused-06.py',{
 'make-ready-source-freeze-03.json':'make-ready-source-freeze-04.json',
 'make-ready-frozen-source-review-03.json':'make-ready-frozen-source-review-04.json',
 'make-ready-native-qualification-02.json':'make-ready-native-qualification-03.json',
 "group+'-02":"group+'-03", "group+'-commands-02":"group+'-commands-03",
 'make-ready-selected-qualified-02':'make-ready-selected-qualified-03',
 'make-ready-menu-qualified-02':'make-ready-menu-qualified-03'})
version('qualify-make-ready-08.py','qualify-make-ready-09.py',{
 'make-ready-source-freeze-03.json':'make-ready-source-freeze-04.json',
 'make-ready-frozen-source-review-03.json':'make-ready-frozen-source-review-04.json',
 'make-ready-source-preflight-03.json':'make-ready-source-preflight-04.json',
 'make-ready-qualification-02':'make-ready-qualification-03',
 'make-ready-native-qualification-02':'make-ready-native-qualification-03',
 'make-ready-q02-':'make-ready-q03-', 'run-make-ready-focused-05.py':'run-make-ready-focused-06.py',
 "group+'-02":"group+'-03"})
version('preflight-and-freeze-make-ready-09.py','preflight-and-freeze-make-ready-10.py',{
 'make-ready-source-preflight-03':'make-ready-source-preflight-04',
 'run-make-ready-focused-04.py':'run-make-ready-focused-06.py',
 'make-ready-dry-run-recovery-proposal-01':'make-ready-dry-run-recovery-proposal-02',
 '8da8ea9b8ab2e3862082ca367d9e59fdbc771c3bf218c63de0f4b6136341aeb5':sha(proposal),
 'make-ready-preflight03-':'make-ready-preflight04-',
 'make-ready-source-freeze-02':'make-ready-source-freeze-04',
 'qualify-make-ready-07.py':'qualify-make-ready-09.py',
 "plan.write_text(plan.read_text(encoding='utf-8')+'\\n\\nMake Ready campaign01 passed the actual shared Release build and five native\\nsmokes, then its first new method failed because --dry-run is not a CLI\\noption. Preserve the complete failed campaign and original oracle. Exercise\\nreal dry_run=true through the existing v2 rpc --stdio transport, requiring\\nthe matching presentation.action response, explicit-confirmation refusal\\nand unchanged workspace. Product/compiled source and every native binary\\nremain unchanged; native reuse requires separate exact frozen review02.\\nAll five new methods, three-mode control,67 regressions and historical\\nreplays remain outstanding. No new build, root, clone or candidate.\\n',encoding='utf-8')":
 "plan.write_text(plan.read_text(encoding='utf-8')+'\\n\\nCampaign02 reached the genuine RPC dry-run route and correctly rejected\\nthe oracle mismatching transport and semantic identities. Preserve that\\nfailed campaign and streams. Align request/operation/attempt identities\\nand additionally assert the semantic refusal and returned identities.\\nUnchanged compiled source/build/five smokes remain reusable only under\\nnew exact frozen review04. Focused/control/historical acceptance remains\\noutstanding; no new build, root, clone or candidate.\\n',encoding='utf-8')"})
print(json.dumps({name:sha(E/name) for name in ['make-ready-dry-run-recovery-proposal-02.json','run-make-ready-focused-06.py','qualify-make-ready-09.py','preflight-and-freeze-make-ready-10.py']}))
