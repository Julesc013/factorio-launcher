"""Execute the admitted produced runtime outside checkout, using synthetic inputs."""
import ast,datetime,hashlib,importlib,types,json,os,subprocess,sys,tempfile,threading,time,unittest
from pathlib import Path
E=Path(__file__).resolve().parent;W=E.parent;R=Path(r'D:\Projects\Factorio\factorio-launcher')

assert __debug__, 'Assertions must remain enabled'
group=sys.argv[1];assert group in {'new','regression','control'}
freeze_path=E/'make-ready-source-freeze-05.json';freeze_bytes=freeze_path.read_bytes();freeze=json.loads(freeze_bytes)
review_path=E/'make-ready-frozen-source-review-05.json';review_bytes=review_path.read_bytes();review=json.loads(review_bytes)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert review['verdict']=='PASS' and review['independent'] and review['non_authoring']
assert review['freeze_sha256']==hashlib.sha256(freeze_bytes).hexdigest()
assert review['focused_runner_sha256']==sha(Path(__file__))==freeze['focused_runner_sha256']
native_path=E/'make-ready-native-qualification-04.json';native_bytes=native_path.read_bytes();native=json.loads(native_bytes)
assert native['status']=='PASS_NATIVE_REQUIRES_FOCUSED_QUALIFICATION'
assert native['source_freeze_sha256']==hashlib.sha256(freeze_bytes).hexdigest()
CLI=Path(native['executable']);DELIVERY=CLI.parent
assert CLI.resolve()==(W/'native-developer/Release/facman.exe').resolve() and sha(CLI)==native['executable_sha256']
git=lambda *args:subprocess.check_output(['git',*args],cwd=R,text=True).rstrip('\r\n')
assert git('rev-parse','HEAD')==freeze['base'] and git('branch','--show-current')==freeze['branch']
assert not git('diff','--cached','--name-only')
assert {row[3:] for row in git('-c','core.quotePath=false','status','--porcelain','--untracked-files=all').splitlines()}==set(freeze['changed_paths_raw_sha256'])
assert {p:sha(R/p) for p in freeze['changed_paths_raw_sha256']}==freeze['changed_paths_raw_sha256']
OUT=E/('make-ready-focused-'+group+'-04.json');assert not OUT.exists()
os.environ.update(FACMAN_CLI_EXE=str(CLI),FACMAN_NATIVE_CLI=str(CLI),FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',
    FACMAN_TASK_ROOT=str(W),TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONOPTIMIZE='0',PYTHONDONTWRITEBYTECODE='1')
for key in list(os.environ):
    if key.startswith('FACMAN_TEST_'):os.environ.pop(key)
os.environ.update(FACMAN_MAKE_READY_FIXTURE_ROOT=str(W/'t'/'make-ready-selected-qualified-03'),
    FACMAN_MAKE_READY_ABSENT_FIXTURE_ROOT=str(W/'t'/'make-ready-menu-qualified-03'))
tempfile.tempdir=str(W/'t');sys.path[:0]=[str(R/'tests'),str(R)]
fixture=R/'tests/fixtures/fake_factorio_install'
inventory=lambda root:{p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file()}
before_fixture=inventory(fixture)
before_delivery={p.name:sha(p) for p in DELIVERY.glob('*.dll')}
cmake_sources={name:sha(R/name) for name in ('apps/cli/CMakeLists.txt','runtime/factorio/CMakeLists.txt','runtime/client/CMakeLists.txt')}
record=dict(status='RUNNING_SOURCE_FOCUSED_QUALIFICATION',pid=os.getpid(),group=group,commands=[],
    source_freeze_sha256=hashlib.sha256(freeze_bytes).hexdigest(),frozen_review_sha256=hashlib.sha256(review_bytes).hexdigest(),
    native_qualification_sha256=hashlib.sha256(native_bytes).hexdigest(),executable_sha256=sha(CLI),
    produced_package_qualified=False,real_factorio_execution=False,human_UI_acceptance=False,whole_workunit_closed=False,beta_qualified=False)
command_dir=E/('make-ready-focused-'+group+'-commands-04');assert not command_dir.exists();command_dir.mkdir()
with (E/('make-ready-focused-'+group+'-04.claim.json')).open('x',encoding='utf-8') as f:
    json.dump(dict(pid=os.getpid(),runner_sha256=sha(Path(__file__)),source_freeze_sha256=record['source_freeze_sha256'],no_automatic_replay=True),f,indent=2)

guard=threading.Lock()
def save_locked():
    temporary=OUT.with_suffix('.writing');temporary.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');temporary.replace(OUT)
def save():
    with guard:save_locked()
def invoke(args,env=None):
    assert '--workspace' in args
    workspace_path=Path(args[args.index('--workspace')+1]).resolve()
    assert workspace_path.is_relative_to((W/'t').resolve()),'Only owned synthetic workspaces may be mutated'
    environment=dict(os.environ if env is None else env)
    with guard:
        index=len(record['commands'])+1
        entry=dict(index=index,argv=[str(CLI),*args],cwd=str(DELIVERY),status='RUNNING',
            seams={k:v for k,v in environment.items() if k in {'FACMAN_TEST_CONFIGURATION_EXIT','FACMAN_TEST_CONFIGURATION_PAUSE','FACMAN_TEST_SELECTED_CONTEXT_EXIT','FACMAN_TEST_SELECTED_CONTEXT_PAUSE','FACMAN_TEST_RETENTION_RECOVERY_PAUSE','FACMAN_TEST_RETENTION_APPLY_PAUSE','FACMAN_TEST_PROFILE_BEFORE_PUBLICATION_PAUSE','FACMAN_TEST_PROFILE_APPLY_EXIT_AFTER_JOURNAL'}})
        record['commands'].append(entry);save_locked()
    started=time.monotonic();deadline=started+45
    def remaining(limit=None):
        available=deadline-time.monotonic()
        if available<=0:raise subprocess.TimeoutExpired(entry['argv'],45)
        return min(available,limit) if limit is not None else available
    release=None;failure=None;out=b'';err=b'';raw_streams_complete=False
    lifetime=dict(deadline_exceeded=False,kill_errors=[])
    timer=None
    def deadline_kill():
        if process.poll() is None:
            lifetime['deadline_exceeded']=True
            try:process.kill()
            except BaseException as error:lifetime['kill_errors'].append(repr(error))
    process=subprocess.Popen(entry['argv'],cwd=DELIVERY,env=environment,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
        creationflags=subprocess.CREATE_NO_WINDOW)
    try:
        entry.update(pid=process.pid,lifetime_deadline_seconds=45)
        # Arm before fallible postspawn custody; cleanup also covers timer setup.
        timer=threading.Timer(max(0.001,deadline-time.monotonic()),deadline_kill)
        timer.daemon=True;timer.start()
        with guard:save_locked()
        if environment.get('FACMAN_TEST_CONFIGURATION_PAUSE')=='rewrite_after_write':
            workspace=Path(args[args.index('--workspace')+1]);root=workspace/'instances/main'
            marker=root/'.facman-test-configuration-rewrite_after_write';release=root/'.facman-test-configuration-release'
            marker_deadline=min(deadline,time.monotonic()+15)
            while not marker.exists() and process.poll() is None and time.monotonic()<marker_deadline:time.sleep(0.01)
            assert marker.exists(),'Produced owner did not reach final held-file observation'
            script="Get-Process -Id "+str(process.pid)+" | Select-Object -ExpandProperty Modules | Where-Object { $_.ModuleName -in @('flb_factorio.dll','ulk.dll','usk.dll') } | Select-Object ModuleName,FileName | ConvertTo-Json -Compress"
            audit_out,audit_err=b'',b''
            try:
                audit=subprocess.run(['powershell','-NoProfile','-Command',script],capture_output=True,timeout=remaining(10))
                audit_out,audit_err=audit.stdout,audit.stderr
            except subprocess.TimeoutExpired as error:
                audit_out,audit_err=error.stdout or b'',error.stderr or b''
                raise
            finally:
                audit_streams={}
                for name,data in [('stdout',audit_out),('stderr',audit_err)]:
                    path=command_dir/(f'{index:04d}.audit.'+name)
                    with path.open('xb') as f:f.write(data)
                    audit_streams[name]=dict(path=str(path),sha256=sha(path))
                with guard:entry['audit_streams']=audit_streams;save_locked()
            assert process.poll() is None,'Owned paused consumer exited during module audit'
            assert audit.returncode==0,audit.stderr.decode(errors='replace')
            modules=json.loads(audit.stdout);assert {m['ModuleName'].lower() for m in modules}=={'ulk.dll','usk.dll'}
            for item in modules:
                path=Path(item['FileName']);assert path.resolve()==(DELIVERY/item['ModuleName']).resolve()
                assert sha(path)==before_delivery[item['ModuleName']]
            record['actual_loaded_shared_modules']=modules
            record['factorio_application_linkage']='static_in_source_cli'
            record['Factorio_shared_DLL_execution_qualified']=False
            record['primary_cmake_source_sha256']=cmake_sources
            release.write_bytes(b'release')
        out,err=process.communicate(timeout=remaining())
        raw_streams_complete=True
        assert not lifetime['deadline_exceeded'] and not lifetime['kill_errors'],'Owned child exceeded lifetime guard'
    except BaseException as error:
        failure=error;entry['cleanup_errors']=[]
        out=getattr(error,'stdout',None) or out;err=getattr(error,'stderr',None) or err
        try:
            if process.poll() is None:process.kill()
        except BaseException as kill_error:entry['cleanup_errors'].append(dict(step='owned_child_kill',error=repr(kill_error)))
        try:
            out,err=process.communicate(timeout=10)
            raw_streams_complete=True
        except BaseException as drain_error:
            if not raw_streams_complete:
                out=getattr(drain_error,'stdout',None) or out;err=getattr(drain_error,'stderr',None) or err
            entry['cleanup_errors'].append(dict(step='bounded_drain',error=repr(drain_error)))
            entry['possible_live_owned_pid']=process.pid if process.poll() is None else None
    finally:
        if timer is not None and process.poll() is not None:timer.cancel()
        entry['lifetime_guard']=lifetime
        entry['raw_streams_complete']=raw_streams_complete
        try:
            if release is not None and not release.exists():release.write_bytes(b'release')
        except BaseException as release_error:
            entry.setdefault('cleanup_errors',[]).append(dict(step='synthetic_pause_release',error=repr(release_error)))
            if failure is None:failure=release_error
        paths={}
        for name,data in [('stdout',out),('stderr',err)]:
            path=command_dir/(f'{index:04d}.'+name)
            try:
                with path.open('xb') as f:f.write(data)
                paths[name]=dict(path=str(path),sha256=sha(path),bytes=len(data))
            except BaseException as custody_error:
                paths[name]=dict(path=str(path),expected_bytes=len(data),custody_error=repr(custody_error))
                if failure is None:failure=custody_error
        with guard:
            entry.update(status='ACTIONABLE_PROCESS_FAILURE' if failure else 'TERMINAL',exit_code=process.poll(),
                streams=paths,seconds=round(time.monotonic()-started,3),error=repr(failure) if failure else None)
            save_locked()

    if failure is not None:raise failure
    return process.returncode,out.decode('utf-8'),err.decode('utf-8')

save()
try:
    original_temporary_directory=tempfile.TemporaryDirectory
    class OwnedTemporaryDirectory(original_temporary_directory):
        def __init__(self,*args,**kwargs):
            kwargs['delete']=False;super().__init__(*args,**kwargs)
            assert Path(self.name).resolve().is_relative_to((W/'t').resolve())
        def __exit__(self,exc_type,exc,tb):
            if exc_type is None:self.cleanup()
            else:
                record.setdefault('preserved_failed_workspaces',[]).append(dict(path=self.name,error=repr(exc)))
                save()
            return False
    tempfile.TemporaryDirectory=OwnedTemporaryDirectory
    import native_cli
    original=native_cli.invoke_machine
    modules=[importlib.import_module(name) for name in ('test_configuration_reconciliation','test_configuration_preparation','test_selected_save_preparation',
        'test_readiness_builtin_content','test_local_modset_solver','test_save_index_retention','test_presentation_profile_preparation',
        'test_portable_modpack_import','test_presentation_pack_import')]
    native_cli.ROOT=R
    for module in [native_cli,*modules]:
        for name,value in list(vars(module).items()):
            if value is original:setattr(module,name,invoke)
    # The text guard covers maintained direct text children as well as invoke.
    helper_path=E/'owned-source-native-text-child-custody-05.py';helper_bytes=helper_path.read_bytes()
    assert hashlib.sha256(helper_bytes).hexdigest()==freeze['text_child_helper_sha256']==review['text_child_helper_sha256']
    helper=types.ModuleType('source_text_child_custody');helper.__file__=str(helper_path)
    exec(compile(helper_bytes,str(helper_path),'exec'),helper.__dict__)
    helper.install(CLI,W/'t',command_dir,record,save,DELIVERY)
    # Preserve raw successful and failed MSBuild/harness output separately from native CLI custody.
    original_run=subprocess.run
    record['control_children']=[]
    def control_run(args,*positional,**kwargs):
        name=Path(str(args[0])).name.lower() if isinstance(args,(list,tuple)) and args else ''
        if name not in {'msbuild.exe','facman.selectedsave.harness.exe'}:
            return original_run(args,*positional,**kwargs)
        assert group=='control' and not positional and kwargs.get('capture_output')
        assert kwargs.get('text') and kwargs.get('encoding')=='utf-8' and kwargs.get('errors')=='replace'
        assert kwargs.get('timeout')==(180 if name=='msbuild.exe' else 60)
        if name=='msbuild.exe':assert '/m:2' in args and '/nr:false' in args
        else:assert Path(str(args[0])).resolve().is_relative_to((W/'t').resolve())
        index=len(record['control_children'])+1
        child=dict(index=index,argv=list(map(str,args)),cwd=str(kwargs.get('cwd')),status='RUNNING',
            timeout_seconds=kwargs['timeout'],native_CLI_child=False,streams={})
        record['control_children'].append(child);save()
        raw_kwargs=dict(kwargs)
        for key in ('text','encoding','errors'):raw_kwargs.pop(key)
        started=time.monotonic();output=b'';errors=b'';completed=None;failure=None
        try:
            completed=original_run(args,**raw_kwargs)
            output,errors=completed.stdout,completed.stderr
        except BaseException as error:
            failure=error
            if isinstance(error,subprocess.TimeoutExpired):output,error_stderr=error.stdout,error.stderr;output=output or b'';errors=error_stderr or b''
        finally:
            child.update(status='ACTIONABLE_PROCESS_FAILURE' if failure else 'TERMINAL',
                exit_code=completed.returncode if completed else None,raw_streams_complete=failure is None,
                seconds=round(time.monotonic()-started,3),error=repr(failure) if failure else None)
            for stream,data in [('stdout',output),('stderr',errors)]:
                path=command_dir/(f'control-{index:02d}.'+stream)
                with path.open('xb') as handle:handle.write(data)
                child['streams'][stream]=dict(path=str(path),sha256=sha(path),bytes=len(data))
            save()
        if failure is not None:raise failure
        return subprocess.CompletedProcess(args,completed.returncode,output.decode('utf-8',errors='replace'),errors.decode('utf-8',errors='replace'))
    subprocess.run=control_run

    import test_make_ready_preparation as candidate
    old_native=original
    for name,value in list(vars(candidate).items()):
        if value is old_native:setattr(candidate,name,invoke)
    control_method='test_compiled_preparation_controls_preserve_actual_receipts_in_all_modes'
    methods=sorted(n for n in vars(candidate.MakeReadyPreparationTests) if n.startswith('test_'))
    assert len(methods)==6 and control_method in methods
    if group in {'new','control'}:
        chosen=[control_method] if group=='control' else [n for n in methods if n!=control_method]
        expected=1 if group=='control' else 5
        suite=unittest.TestSuite(candidate.MakeReadyPreparationTests(n) for n in chosen)
    else:
        names=['test_configuration_reconciliation','test_configuration_preparation','test_selected_save_preparation',
            'test_readiness_builtin_content','test_save_index_retention','test_presentation_service',
            'test_presentation_profile_preparation','test_presentation_intent',
            'test_local_modset_solver.LocalModsetSolverTests.test_applied_selection_exports_exact_lock_and_only_selected_archives']
        original_suite=unittest.defaultTestLoader.loadTestsFromNames(names)
        def cases(items):
            for item in items:
                if isinstance(item,unittest.TestSuite):yield from cases(item)
                else:yield item
        exclude={'test_compiled_fixed_control_dispatches_ordinary_owner_and_keeps_captured_intent',
                 'test_compiled_fixed_control_preserves_selected_intent_and_uncertain_request'}
        all_cases=list(cases(original_suite));assert len(all_cases)==69
        skipped=[c.id() for c in all_cases if c._testMethodName in exclude];assert len(skipped)==2
        record['replaced_compiled_control_oracles']=skipped
        record['replacement_control_group']='One actual maintained control method builds once and checks all three actual preparation modes'
        admitted=[c for c in all_cases if c._testMethodName not in exclude]
        assert review['approve_regression_prefix_reuse'] and [c.id() for c in admitted[:51]]==review['reused_regression_prefix_ids']
        record['reused_regression_prefix_ids']=review['reused_regression_prefix_ids']
        record['prior_failed_regression_receipt_sha256']=review['prior_failed_regression_receipt_sha256']
        suite=unittest.TestSuite(admitted[51:]);expected=16
    record['selected_test_ids']=[c.id() for c in suite];save()
    testlog=E/('make-ready-focused-'+group+'-04-tests.log')
    with testlog.open('x',encoding='utf-8') as stream:
        result=unittest.TextTestRunner(stream=stream,verbosity=2,failfast=True).run(suite)
    record.update(test_log=str(testlog),test_log_sha256=sha(testlog),tests_run=result.testsRun,skipped=len(result.skipped));save()
    assert result.wasSuccessful() and result.testsRun==expected and not result.skipped
    assert all(c['status']=='TERMINAL' and c['raw_streams_complete'] and not c.get('cleanup_errors') and
        not c['lifetime_guard']['deadline_exceeded'] and not c['lifetime_guard']['kill_errors'] for c in record['commands'])
    assert all(c['status']=='TERMINAL' and c['raw_streams_complete'] and not c['deadline_exceeded'] and not c['kill_error']
        and 'drain_error' not in c and 'audit_error' not in c for c in record['legacy_direct_children'])
    assert len(record['control_children'])==(4 if group=='control' else 0)
    assert all(c['status']=='TERMINAL' and c['raw_streams_complete'] and c['exit_code']==0 for c in record['control_children'])
    for c in [*record['commands'],*record['legacy_direct_children'],*record['control_children']]:
        for stream in c['streams'].values():
            p=Path(stream['path']);assert sha(p)==stream['sha256'] and p.stat().st_size==stream['bytes']
    assert inventory(fixture)==before_fixture and sha(CLI)==native['executable_sha256']
    assert {p:sha(R/p) for p in freeze['changed_paths_raw_sha256']}==freeze['changed_paths_raw_sha256']
    record.update(status='PASS_SOURCE_FOCUSED_QUALIFICATION',commands_total=len(record['commands']),
        legacy_direct_children_total=len(record['legacy_direct_children']),
        completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        live_click_to_backend_qualified=False,compiled_control_qualified_by_this_group=group=='control');save()
    print(json.dumps(dict(status=record['status'],group=group,tests=expected,skipped=0)),flush=True)
except Exception as error:
    record.update(status='ACTIONABLE_FAILURE',error=repr(error));save();raise
