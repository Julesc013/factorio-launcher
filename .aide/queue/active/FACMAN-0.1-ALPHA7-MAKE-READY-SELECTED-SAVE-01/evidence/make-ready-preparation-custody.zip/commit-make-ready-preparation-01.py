"""Stage and commit only the exact accepted source and four compact receipts."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,traceback
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;P='make-ready-preparation'
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',PYTHONOPTIMIZE='0',PYTHONDONTWRITEBYTECODE='1')
sys.path.insert(0,str(R/'.aide/scripts'));import aide_lite as aide
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
def write(path,value):
 with path.open('x',encoding='utf-8',newline='\n') as stream:json.dump(value,stream,indent=2);stream.write('\n')
def run(*args):
 result=subprocess.run(args,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=900)
 assert result.returncode==0,(args[:4],result.returncode,result.stderr[-1800:])
 return result.stdout.rstrip('\r\n')
def logged(name,args):
 log=E/(P+'-'+name+'.log')
 with log.open('xb') as stream:result=subprocess.run(args,cwd=R,stdout=stream,stderr=subprocess.STDOUT,timeout=900)
 assert result.returncode==0,(name,result.returncode,str(log))
packet_path=E/(P+'-commit-snapshot-01.json');packet_bytes=packet_path.read_bytes();packet=json.loads(packet_bytes)
C=E/(P+'-commit-classification-01.json');M=Path(packet['message_path']);V=E/(P+'-commit-review-01.json')
classification_bytes=C.read_bytes();c=json.loads(classification_bytes)
review_bytes=V.read_bytes();v=json.loads(review_bytes);review_sha=hashlib.sha256(review_bytes).hexdigest()
message_bytes=M.read_bytes();BASE=c['base_commit'];BRANCH=c['branch']
def bound():
 assert packet_path.read_bytes()==packet_bytes and C.read_bytes()==classification_bytes
 assert V.read_bytes()==review_bytes and M.read_bytes()==message_bytes,'Approval or exact packet changed'
OUT=E/(P+'-committed-01.json');STAGED=E/(P+'-stage-classification-01.json')
assert __debug__ and not OUT.exists() and not STAGED.exists()
assert packet['status']=='ACTUAL_QUALIFIED_SOURCE_AND_RECEIPT_ONLY_COMMIT_PACKET_REQUIRES_INDEPENDENT_REVIEW'
assert packet['classification_sha256']==hashlib.sha256(classification_bytes).hexdigest()
assert packet['message_sha256']==hashlib.sha256(message_bytes).hexdigest()
assert v['schema_version']==aide.GIT_COMMIT_REVIEW_SCHEMA and v['verdict']=='PASS'
assert v['independent'] and v['non_authoring'] and v['approve_normal_checked_integration']
assert v['commit_driver_sha256']==sha(Path(__file__)) and v['source_packet_sha256']==hashlib.sha256(packet_bytes).hexdigest()
for key in ('branch','base_commit','snapshot_sha256','message_sha256'):assert v[key]==c[key],key
assert not c['reviews'] and c['snapshot_sha256']==aide.helper_commit_snapshot_sha256(c['changed_paths'])
assert run('git','rev-parse','HEAD')==BASE and run('git','branch','--show-current')==BRANCH
assert not run('git','diff','--cached','--name-only')
source=packet['frozen_source_paths'];additions=packet['receipt_only_additions']
assert len(source)==14 and len(additions)==4 and not (set(source)&set(additions))
assert {row[3:] for row in run('git','-c','core.quotePath=false','status','--porcelain','--untracked-files=all').splitlines()}==set(source)
assert {p:sha(R/p) for p in source}==source
for rel,item in additions.items():
 target=(R/rel).resolve();assert target.is_relative_to((R/'.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01/evidence').resolve())
 prepared=Path(item['prepared_path']).resolve();assert prepared.parent==E.resolve() and sha(prepared)==item['sha256']
 assert not target.exists() and not target.is_symlink()
write(E/(P+'-commit-01.claim.json'),dict(pid=os.getpid(),review_sha256=review_sha,no_automatic_replay=True))
try:
 logged('commit-template-01',['py','-3','.aide/scripts/aide_lite.py','commit','template'])
 logged('compact-message-01',['py','-3','.aide/scripts/aide_lite.py','commit','check','--message-file',str(M)])
 bound()
 for rel,item in additions.items():
  bound()
  target=R/rel;target.parent.mkdir(parents=True,exist_ok=True)
  prepared_bytes=Path(item['prepared_path']).read_bytes()
  assert hashlib.sha256(prepared_bytes).hexdigest()==item['sha256']
  with target.open('xb') as stream:stream.write(prepared_bytes)
 paths={item['path'] for item in c['changed_paths']};assert paths==set(source)|set(additions)
 assert {row[3:] for row in run('git','-c','core.quotePath=false','status','--porcelain','--untracked-files=all').splitlines()}==paths
 for item in c['changed_paths']:
  assert sha(R/item['path'])==item['sha256']
  assert run('git','hash-object','--path='+item['path'],'--',item['path'])==item['git_blob_oid']
 bound()
 logged('final18-strict-01',['py','-3','tools/strict_check.py'])
 logged('final18-diff-01',['git','diff','--check'])
 bound()
 assert run('git','rev-parse','HEAD')==BASE and run('git','branch','--show-current')==BRANCH
 assert not run('git','diff','--cached','--name-only')
 assert {row[3:] for row in run('git','-c','core.quotePath=false','status','--porcelain','--untracked-files=all').splitlines()}==paths
 for item in c['changed_paths']:
  assert sha(R/item['path'])==item['sha256']
  assert run('git','hash-object','--path='+item['path'],'--',item['path'])==item['git_blob_oid']
 c['reviews']=[dict(path=str(V),sha256=review_sha,verdict='PASS')];write(STAGED,c)
 plan=aide.make_git_commit_plan(R,STAGED,M);write(E/(P+'-stage-plan-01.json'),plan)
 assert plan['status']=='ready_to_stage' and not plan['blockers'],plan['blockers']
 for i,args in enumerate(plan['planned_argv']):logged('stage01-'+str(i),args)
 ready=aide.make_git_commit_plan(R,STAGED,M);write(E/(P+'-commit-plan-01.json'),ready)
 assert ready['status']=='ready_to_commit' and not ready['blockers'],ready['blockers']
 bound()
 assert run('git','rev-parse','HEAD')==BASE and run('git','branch','--show-current')==BRANCH
 assert set(run('git','diff','--cached','--name-only').splitlines())==paths and not run('git','diff','--name-only')
 assert {row[3:] for row in run('git','-c','core.quotePath=false','status','--porcelain','--untracked-files=all').splitlines()}==paths
 for item in c['changed_paths']:
  assert sha(R/item['path'])==item['sha256'] and run('git','rev-parse',':'+item['path'])==item['git_blob_oid']
 bound()
 logged('normal-commit-01',['git','commit','-F',str(M)])
 bound()
 head=run('git','rev-parse','HEAD');assert run('git','show','-s','--format=%P',head)==BASE
 assert run('git','show','-s','--format=%B',head)==message_bytes.decode('utf-8').rstrip('\r\n')
 assert not run('git','status','--porcelain') and run('git','branch','--show-current')==BRANCH
 assert set(run('git','diff','--no-renames','--name-only',BASE,head).splitlines())==paths
 for item in c['changed_paths']:
  assert sha(R/item['path'])==item['sha256'] and run('git','rev-parse',head+':'+item['path'])==item['git_blob_oid']
 logged('commit-range-01',['py','-3','.aide/scripts/aide_lite.py','commit','check','--range',BASE+'..'+head])
 changelog={p:(R/p).read_bytes() for p in run('git','ls-files','.aide/changelog').splitlines()}
 try:logged('changelog-preview-01',['py','-3','.aide/scripts/aide_lite.py','changelog','preview','--range',BASE+'..'+head])
 finally:
  for rel,original in changelog.items():
   target=R/rel;assert target.resolve().is_relative_to((R/'.aide/changelog').resolve())
   if target.read_bytes()!=original:
    with (E/(P+'-changelog01-'+target.name)).open('xb') as stream:stream.write(target.read_bytes())
    target.write_bytes(original)
 assert not run('git','status','--porcelain') and run('git','rev-parse','HEAD')==head
 bound()
 write(OUT,dict(status='normal_reviewed_commit',head=head,base=BASE,integration_base=BASE,branch=BRANCH,
  tree=run('git','rev-parse','HEAD^{tree}'),snapshot_sha256=c['snapshot_sha256'],message_sha256=sha(M),
  review_sha256=review_sha,classification_sha256=sha(STAGED),source_packet_sha256=sha(packet_path),
  normal_hooks_pass=True,full_history_range_pass=True,source_clean=True,
  final18_strict_sha256=sha(E/(P+'-final18-strict-01.log')),final18_diff_sha256=sha(E/(P+'-final18-diff-01.log')),
  new_builds=0,new_clones=0,new_worktrees=0,
  required_source_and_merge_CI_pending=True,produced_package_acceptance_pending=True,whole_workunit_closed=False))
 print(json.dumps(dict(status='normal_reviewed_commit',head=head,paths=len(paths))),flush=True)
except BaseException as error:
 write(E/(P+'-commit-01-failure.json'),dict(status='ACTIONABLE_STOP_PRESERVE_SOURCE_AND_INDEX',
  error=repr(error),traceback=traceback.format_exc(),source_or_index_reset=False));raise
