"""One observer: required current source checks, exact-head normal merge, dev sync and merge checks."""
import datetime
import json
import os
from pathlib import Path
import subprocess
import time
import traceback

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
P = 'make-ready-preparation'
REPO = 'Julesc013/factorio-launcher'
publication = json.loads((E / (P + '-published-01.json')).read_text())
HEAD, BASE, BRANCH = publication['source'], publication['base'], publication['branch']
PR = publication['pr']['number']
os.environ['FACMAN_DEV_ROOT'] = r'D:\Projects\Factorio\.task-builds'
RESULT = E / (P + '-integration-' + HEAD[:8] + '.json')
record = dict(status='observing_required_source_checks', source=HEAD, base=BASE, branch=BRANCH,
    pull_request=PR, merge_requests=0, job_reruns=0, new_candidates=0, new_roots=0,
    whole_workunit_closed=False, beta_qualified=False)

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

def run(*args):
    readonly = args[:2] == ('gh', 'api') and '--method' not in args and '--input' not in args
    transient = ('connectex', 'dial tcp', 'TLS handshake timeout', 'unexpected EOF',
                 'connection reset', 'HTTP 502', 'HTTP 503', 'HTTP 504', 'no such host')
    attempts = 5 if readonly else 1
    for attempt in range(attempts):
        p = subprocess.run(args, cwd=R, capture_output=True, text=True, encoding='utf-8', timeout=90)
        if p.returncode == 0:
            return p.stdout.rstrip('\r\n')
        error = p.stderr[-1800:]
        if readonly and (any(token in error for token in transient) or p.returncode in {3221225794, -1073741502}) and attempt + 1 < attempts:
            print(json.dumps(dict(phase='read_network_retry', attempt=attempt+1, error=error)), flush=True)
            time.sleep(min(60, 15 * (attempt + 1)))
            continue
        raise RuntimeError(dict(command=args[:4], exit=p.returncode, error=error))

def api(path, *args):
    return json.loads(run('gh', 'api', path, *args))

def source_clean():
    assert run('git', 'rev-parse', 'HEAD') == HEAD
    assert run('git', 'branch', '--show-current') == BRANCH
    assert not run('git', 'status', '--porcelain')

def required_rules():
    rules = api(f'repos/{REPO}/rules/branches/dev')
    required = set()
    for rule in rules:
        if rule['type'] == 'required_status_checks':
            assert rule['parameters']['strict_required_status_checks_policy']
            required.update((c['context'], c['integration_id'])
                            for c in rule['parameters']['required_status_checks'])
    assert len(required) == 12 and ('task-to-dev-promotion-check', 15368) in required
    return rules, required

def latest_checks(head):
    pages = json.loads(run('gh', 'api', '--paginate', '--slurp',
        f'repos/{REPO}/commits/{head}/check-runs?per_page=100'))
    latest = {}
    for check in sorted([c for page in pages for c in page['check_runs']], key=lambda c:c['id']):
        assert check['head_sha'] == head
        latest[(check['name'], check['app']['id'])] = check
    return latest

def push_census(head):
    pages = json.loads(run('gh', 'api', '--paginate', '--slurp',
        f'repos/{REPO}/actions/runs?head_sha={head}&event=push&per_page=100'))
    return [r for page in pages for r in page['workflow_runs']
            if r['head_sha'] == head and r['head_branch'] == 'dev']

def observe(head, required, phase):
    deadline, previous = time.monotonic() + 7200, None
    while time.monotonic() < deadline:
        checks = latest_checks(head)
        save(E / (P + '-' + phase + '-latest-checks.json'), list(checks.values()))
        failures = [c for c in checks.values() if c['status'] == 'completed' and
                    c['conclusion'] not in {'success', 'skipped', 'neutral', 'cancelled'}]
        cancelled = [c for key,c in checks.items() if key in required and
                     c['status'] == 'completed' and c['conclusion'] == 'cancelled']
        if failures or cancelled:
            save(E / (P + '-' + phase + '-failures.json'), failures + cancelled)
            raise RuntimeError(dict(phase=phase, failed_checks=[c['name'] for c in failures+cancelled],
                                    action='retain and diagnose; no automatic job retry'))
        pending = sorted(name for name, app in required if (name, app) not in checks or
            checks[(name, app)]['status'] != 'completed' or checks[(name, app)]['conclusion'] != 'success')
        runs = push_census(head) if phase == 'merge' else []
        if runs:
            save(E / (P + '-merge-push-census.json'), runs)
            bad_runs = [r for r in runs if r['status'] == 'completed' and r['conclusion'] != 'success']
            if bad_runs:
                raise RuntimeError(dict(phase=phase, failed_push_runs=[r['id'] for r in bad_runs],
                                        action='preserve every same-SHA automatic campaign'))
            pending += ['automatic-push-run:' + str(r['id']) for r in runs if r['status'] != 'completed']
        state = tuple(sorted(pending))
        if state != previous:
            print(json.dumps(dict(phase=phase, required_remaining=list(state), at=now())), flush=True)
            previous = state
        if not pending:
            return dict(checks=list(checks.values()), automatic_push_runs=runs)
        time.sleep(30)
    raise TimeoutError(dict(phase=phase, head=head, action='retain live jobs; never resubmit'))

# Require the actual independent exact-source decision before observing or mutating.
import hashlib
predecision_path=E/(P+'-commit-review-01.json')
predecision_bytes=predecision_path.read_bytes();predecision=json.loads(predecision_bytes)
predecision_sha=hashlib.sha256(predecision_bytes).hexdigest()
precommit=json.loads((E/(P+'-committed-01.json')).read_text())
assert predecision['verdict']=='PASS' and predecision['independent'] and predecision['non_authoring']
assert predecision['approve_normal_checked_integration'] is True
assert predecision['integration_driver_sha256']==hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
assert predecision_sha==precommit['review_sha256']
assert precommit['head']==HEAD and precommit['integration_base']==BASE and precommit['branch']==BRANCH
assert predecision['base_commit']==publication['commit_parent'] and predecision['branch']==BRANCH
assert predecision['snapshot_sha256']==precommit['snapshot_sha256'] and predecision['message_sha256']==precommit['message_sha256']
with (E / (P + '-integration-' + HEAD[:8] + '.claim.json')).open('x', encoding='utf-8') as stream:
    json.dump(dict(pid=os.getpid(), source=HEAD, pull_request=PR, started_at=now()), stream)
try:
    identity = run('powershell','-NoProfile','-Command','[System.Security.Principal.WindowsIdentity]::GetCurrent().Name')
    assert identity.casefold() == r'BLACKGLASS-WIN1\Jules'.casefold()
    run('gh','auth','status')
    assert run('gh','api','user','--jq','.login') == 'Julesc013'
    source_clean()
    rules, required = required_rules()
    record['source_checks'] = observe(HEAD, required, 'source')
    decision_path=E/(P+'-commit-review-01.json')
    decision_bytes=decision_path.read_bytes();decision=json.loads(decision_bytes)
    decision_sha=hashlib.sha256(decision_bytes).hexdigest()
    committed=json.loads((E/(P+'-committed-01.json')).read_text())
    import hashlib
    assert decision_sha==committed['review_sha256']==predecision_sha
    assert decision['verdict']=='PASS' and decision['independent'] and decision['non_authoring']
    assert decision['approve_normal_checked_integration'] is True
    assert decision['base_commit']==publication['commit_parent'] and decision['branch']==BRANCH
    assert committed['head']==HEAD and committed['base']==publication['commit_parent']
    assert decision['snapshot_sha256']==committed['snapshot_sha256'] and decision['message_sha256']==committed['message_sha256']
    record['independent_integration_decision']=decision
    record['source_checks_reobserved'] = observe(HEAD, required, 'source-reobserved')
    source_clean()
    pull = api(f'repos/{REPO}/pulls/{PR}')
    assert pull['state'] == 'open' and not pull['draft'] and pull['head']['sha'] == HEAD
    assert pull['head']['ref'] == BRANCH and pull['head']['repo']['full_name'] == REPO
    assert pull['base']['ref'] == 'dev' and pull['base']['repo']['full_name'] == REPO
    assert api(f'repos/{REPO}/git/ref/heads/dev')['object']['sha'] == BASE
    assert required_rules() == (rules, required)
    assert api(f'repos/{REPO}')['allow_merge_commit'] is True
    request_path = E / (P + '-normal-merge-' + HEAD[:8] + '.request.json')
    save(request_path, dict(sha=HEAD, merge_method='merge',
        commit_title='feat(presentation): integrate ordinary Make Ready preparation',
        commit_message='Work-Item: FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01\n'
        'Evidence-Ref: .aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01/evidence/make-ready-preparation.v1.json\n'))
    record['merge_method'] = 'merge'
    record['merge_method_reason'] = 'Preserve the exact qualified source checkpoint in the continuing F11 integration train; no published history rewriting'
    record['merge_requests'] = 1
    save(RESULT, record)
    assert hashlib.sha256(decision_path.read_bytes()).hexdigest()==decision_sha, 'Approval changed before merge'
    response = api(f'repos/{REPO}/pulls/{PR}/merge', '--method', 'PUT', '--input', str(request_path))
    assert response['merged'] is True
    merged = api(f'repos/{REPO}/pulls/{PR}')
    assert merged['merged'] and merged['head']['sha'] == HEAD
    merge = merged['merge_commit_sha']
    record.update(status='merged', merge=merge, merged_pr=merged,
                  merge_response=response, required_rules=rules)
    save(RESULT, record)
    run('git', 'fetch', '--no-tags', 'origin', 'dev')
    assert run('git', 'show', '-s', '--format=%P', merge).split() == [BASE, HEAD]
    assert run('git', 'rev-parse', merge+'^{tree}') == run('git', 'rev-parse', HEAD+'^{tree}')
    assert run('git', 'rev-parse', 'origin/dev') == merge
    source_clean()
    for command in ['policy', 'detect', 'plan']:
        run('py', '-3', '.aide/scripts/aide_lite.py', 'git', command)
    run('git', 'switch', 'dev')
    run('git', 'merge', '--ff-only', 'origin/dev')
    record['status'] = 'merged_and_local_dev_synchronized'
    save(RESULT, record)
    print(json.dumps(dict(phase='integrated', merge=merge, at=now())), flush=True)
    record['merge_checks'] = observe(merge, required-{('task-to-dev-promotion-check',15368)}, 'merge')
    record.update(status='required_source_and_merge_CI_pass', finished_at=now())
    save(RESULT, record)
    print(json.dumps(dict(status=record['status'], merge=merge)), flush=True)
except Exception as error:
    record.update(status='actionable_stop_preserve_execution', error=str(error),
                  traceback=traceback.format_exc(), stopped_at=now())
    save(RESULT, record)
    print(json.dumps(dict(status=record['status'], error=str(error))), flush=True)
    raise
