from pathlib import Path
import hashlib,json,subprocess,difflib,ast,datetime
E=Path(__file__).resolve().parent
R=Path(r'D:\Projects\Factorio\factorio-launcher')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
parent=E/'make-ready-source-freeze-02.json'
assert sha(parent)=='f97e2e496271de14ec28df268af9fd5aaeab1a325d73ca9da2b0ca01b0019a4e'
freeze=json.loads(parent.read_bytes())
preflight=Path(freeze['source_preflight_path'])
assert sha(preflight)==freeze['source_preflight_sha256']
receipt=json.loads(preflight.read_bytes())
assert receipt['status']=='PASS_SOURCE_PREFLIGHT_REQUIRES_FROZEN_REVIEW_AND_NATIVE'
assert receipt['changed_paths_raw_sha256']==freeze['changed_paths_raw_sha256']
for item in receipt['steps']:assert item['exit_code']==0 and sha(Path(item['log']))==item['log_sha256']
git=lambda *args:subprocess.check_output(['git','-c','core.quotePath=false',*args],cwd=R,text=True).rstrip('\r\n')
assert git('rev-parse','HEAD')==freeze['base'] and git('branch','--show-current')==freeze['branch']
assert not git('diff','--cached','--name-only')
assert {line[3:] for line in git('status','--porcelain','--untracked-files=all').splitlines()}==set(freeze['changed_paths_raw_sha256'])
assert {p:sha(R/p) for p in freeze['changed_paths_raw_sha256']}==freeze['changed_paths_raw_sha256']
changes={
 'run-make-ready-focused-04.py':('run-make-ready-focused-05.py',{
 'make-ready-source-freeze-02.json':'make-ready-source-freeze-03.json',
 'make-ready-frozen-source-review-02.json':'make-ready-frozen-source-review-03.json',
 "group+'-commands-01'":"group+'-commands-02'"}),
 'qualify-make-ready-07.py':('qualify-make-ready-08.py',{
 'make-ready-source-freeze-02.json':'make-ready-source-freeze-03.json',
 'make-ready-frozen-source-review-02.json':'make-ready-frozen-source-review-03.json',
 'run-make-ready-focused-04.py':'run-make-ready-focused-05.py'})}
diffs={}
for old,(new,replacements) in changes.items():
 original=(E/old).read_text(encoding='utf-8'); updated=original
 for before,after in replacements.items():
  assert updated.count(before)==1,(old,before,updated.count(before))
  updated=updated.replace(before,after)
 ast.parse(updated)
 with (E/new).open('x',encoding='utf-8',newline='\n') as stream:stream.write(updated)
 diff=E/(new+'.diff')
 with diff.open('x',encoding='utf-8',newline='\n') as stream:
  stream.write(''.join(difflib.unified_diff(original.splitlines(True),updated.splitlines(True),fromfile=old,tofile=new)))
 diffs[new]=dict(old_sha256=sha(E/old),new_sha256=sha(E/new),diff_sha256=sha(diff))
for group in ('new','control','regression'):
 for suffix in ('-commands-02','-02.json','-02.claim.json'):
  assert not (E/('make-ready-focused-'+group+suffix)).exists()
for name in ('make-ready-qualification-02.json','make-ready-qualification-02.claim.json','make-ready-native-qualification-02.json'):
 assert not (E/name).exists()
freeze.update(parent_source_freeze_sha256=sha(parent),driver_only_correction={
 'reason':'Fresh02 command custody; preserve failed01 directory and streams',
 'changes':diffs,'source_paths_changed':False,'new_preflight_runs':0,'new_native_builds':0},
 qualification_runner_sha256=sha(E/'qualify-make-ready-08.py'),
 focused_runner_sha256=sha(E/'run-make-ready-focused-05.py'),
 created_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
target=E/'make-ready-source-freeze-03.json'
with target.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(freeze,indent=2)+'\n')
print(json.dumps(dict(freeze_sha256=sha(target),changes=diffs)))
