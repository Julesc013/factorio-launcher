import hashlib
from pathlib import Path
E=Path(__file__).resolve().parent
source=(E/'linux-delivered-correct-02.py').read_text(encoding='utf-8')
source=source.replace('.read_text()',".read_text(encoding='utf-8')")
for name in ('worker','namespace','launch'):
 source=source.replace('linux-delivered-'+name+'-02.py','linux-delivered-'+name+'-03.py')
for old,new in (('linux-delivered-evidence-02','linux-delivered-evidence-03'),('linux-delivered-namespace-result-02','linux-delivered-namespace-result-03'),('linux-delivered-launch-result-02','linux-delivered-launch-result-03'),('linux-delivered-worker-02.stdout','linux-delivered-worker-03.stdout'),('linux-delivered-worker-02.stderr','linux-delivered-worker-03.stderr'),('linux-delivered-unresolved-fixtures-02','linux-delivered-unresolved-fixtures-03'),('linux-delivered-owned-execution-02','linux-delivered-owned-execution-03')):source=source.replace(old,new)
target=E/'linux-delivered-correct-03.py';assert not target.exists();target.write_text(source,encoding='utf-8')
exec(compile(source,str(target),'exec'),dict(__file__=str(target)))
for name in ('worker','namespace'):
 content=(E/('linux-delivered-'+name+'-03.py')).read_text(encoding='utf-8')
 assert '\u03a9' in content and '\u00ce\u00a9' not in content,name
print('Explicit UTF-8 reads/writes and original relocation Ω verified; draft02 preserved.')
