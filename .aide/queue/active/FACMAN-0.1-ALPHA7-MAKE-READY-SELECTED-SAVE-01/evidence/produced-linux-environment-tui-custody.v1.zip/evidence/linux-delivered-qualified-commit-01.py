import hashlib,json,os,subprocess,sys,traceback,zipfile
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
Q='.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
BASE='44dcf5b6cf22f20f89020534de72b6fa1e3a14f8';BRANCH='task/facman-linux-delivered-environment-01'
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.safecrlf',GIT_CONFIG_VALUE_0='false')
sys.path[:0]=[str(R)];from tools import provider_canary_process as owned
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=R,text=True,encoding='utf-8').strip()
def dirty():return set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
out=E/'linux-delivered-qualified-commit-result-01.json';assert not out.exists()
record=dict(status='SEALING_ACCEPTED_LINUX_PACKAGE_SLICE',commands=[],native_rebuild=False,new_roots=0,new_clones=0,new_worktrees=0,goal_status_mutated=False)
def save():out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
def run(label,args,timeout=180,expected_codes=(0,)):
 result=owned.command(args,cwd=R,environment=dict(os.environ),timeout=timeout,directory=E/('linux-delivered-commit01-'+label),output_limit=8*1024**2,wait_for_job_empty_after_primary=True)
 record['commands'].append(dict(label=label,exit=result.returncode,receipt_sha256=sha(result.directory/'receipt.json')));save()
 assert result.returncode in expected_codes and result.receipt['termination']=='completed' and result.receipt['primary_stopped'] and result.receipt['job_empty_observed'] and not result.receipt['job_terminated'],(label,(result.stdout[-1200:]+result.stderr[-1600:]).decode('utf-8','replace'))
 return result
try:
 assert git('rev-parse','HEAD')==BASE and git('branch','--show-current')==BRANCH and not git('diff','--cached','--name-only')
 expected={Q+'/ExecPlan.md',Q+'/evidence/produced-environment-reconstruction.v1.json',Q+'/evidence/produced-environment-reconstruction-custody.v1.zip'}
 assert dirty()==expected
 packet=E/'linux-delivered-frozen-packet-03.json';p=json.loads(packet.read_bytes())
 review=E/'linux-delivered-independent-custody-review-03.json';v=json.loads(review.read_bytes())
 assert v['verdict']=='PASS_INDEPENDENT_ACTUAL_LINUX_DELIVERED_CLI_TUI' and v['non_authoring'] and v['packet_sha256']==sha(packet)
 for label in ('policy','detect','plan'):run(label,['py','-3','-B','.aide/scripts/aide_lite.py','git',label])
 run('paths',['py','-3','-B','tools/workspace_hygiene.py','paths'])
 hygiene=json.loads(run('doctor',['py','-3','-B','tools/workspace_hygiene.py','doctor','--measure'],600,(0,1)).stdout)
 assert set(hygiene['violations'])<={'unmanaged_secondary_worktrees_present'} and len(hygiene['task_roots'])==8 and hygiene['task_root_bytes']<20*1024**3
 names={name for name in p['files'] if not name.lower().endswith(('.zip','.tar.gz'))}
 names.update({packet.name,review.name,'linux-delivered-environment-custody-review-03.json','linux-delivered-environment-log-custody-01.py',Path(__file__).name})
 names.update(path.relative_to(E).as_posix() for directory in (E/'linux-delivered-environment-independent-decoded-03',E/'linux-delivered-TUI-independent-decoded-03') for path in directory.rglob('*') if path.is_file())
 manifest={}
 for name in names:
  path=(E/name).resolve();assert path.is_relative_to(E.resolve()) and path.is_file()
  manifest['evidence/'+path.relative_to(E).as_posix()]=sha(path)
 archive=R/Q/'evidence/produced-linux-environment-tui-custody.v1.zip';assert not archive.exists()
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as custody:
  custody.writestr('custody-manifest.json',json.dumps(manifest,indent=2,sort_keys=True)+'\n')
  for name in sorted(manifest):custody.write(E/name.removeprefix('evidence/'),name)
 with zipfile.ZipFile(archive) as custody:
  for name,digest in manifest.items():assert hashlib.sha256(custody.read(name)).hexdigest()==digest
 evidence=R/Q/'evidence/produced-linux-environment-tui.v1.json'
 receipt=dict(schema='facman.linux_delivered_environment_tui_accepted_slice.v1',integrated_source=BASE,compiled_source=p['compiled_source'],compiled_tree=p['compiled_tree'],source_workflow_run=38502974985,artifact_id=p['artifact_id'],artifact_sha256=p['artifact_sha256'],
  CLI_environment_scenarios=3,CLI_environment_calls=107,TUI_linear_effect_components=2,TUI_fullscreen_sessions=3,TUI_fullscreen_effect_components=2,normal_owned_processes=133,
  exact_selected_content_settings_world_profile_and_provenance=True,unknown_semantic_replay_and_supported_recovery=True,foreign_and_corrupt_refusals_preserved=True,
  genuine_cli_and_tui_distributions=True,readonly_packages_and_registered_installation=True,pathless_external_consumer=True,display_and_source_overrides_absent=True,
  exact_terminal_restoration=True,uid=65534,gid=65534,groups=[],zero_owned_processes=True,private_mount_removed=True,tmpfs_peak_bytes=p['tmpfs_used_bytes'],
  independent_review_sha256=sha(review),frozen_packet_sha256=sha(packet),custody=archive.name,custody_sha256=sha(archive),custody_files=len(manifest),
  original_distribution_archives_retained_externally=True,distribution_archives_not_duplicated_in_custody=True,no_redownload=True,no_native_build=True,new_roots=0,new_clones=0,new_worktrees=0,
  source_or_product_changes=False,wsl=True,physical_ext4=False,minimum_named_physical_host=False,canonical_installed_desktop=False,real_game=False,human=False,whole_workunit=False,full_make_ready=False,beta=False,rc=False)
 with evidence.open('x',encoding='utf-8') as stream:json.dump(receipt,stream,indent=2);stream.write('\n')
 with (R/Q/'ExecPlan.md').open('a',encoding='utf-8',newline='\n') as stream:
  stream.write('\n### Accepted existing Linux CLI and TUI distributions\n\nThe existing successful PR419 campaign supplied authentic Linux CLI and TUI tar distributions in one verified GitHub artifact11867723625. Download occurred once; original archive/tar digests, manifests, build/backend/provider identities and complete closures match synthetic0a1310b4/tree5bc241a1, the exact reviewed/integrated source tree. No replacement package, native build or repository copy occurred. The packaged CLI passes all three combined environment journeys and107ordinary calls. The packaged TUI passes linear preparation and three real fullscreen sessions with stale cancellation, confirmed routing/context effects and byte-exact terminal restoration. Independent decode verifies the same provenance/bytes/refusal/unknown/recovery contracts, actual receipts/journals and original distribution closure.\n\nAll133owned processes run as UID/GID65534 without groups, retain actual pre-poll startticks, complete through normal wait and leave no process/proc entry. Readonly package and installation probes preserve inputs under emptyPATH, no display/source/backend/provider overrides and an external consumer directory. One private PID/mount namespace exports exact evidence before draining and unmounting; its512MiB tmpfs peaks at185032704bytes. The worker patiently preserves parallel Universal tests before dispatch. Original natural attempt01 and draft02 encoding error remain in custody; reviewed03 fixes healthy admission timeout, absent-leaf failure masking and fullscreen completion bookkeeping while retaining exact UTF8 paths. The parent Windows job also drains normally.\n\nThis closes the admitted structural Linux CLI reconstruction and ordinary delivered TUI preparation/terminal slice on Ubuntu24.04 WSL/tmpfs. It grants no physical ext4/named-host, real game/human, canonical installed Desktop, full Make Ready/Play, whole WorkUnit, Beta or RC acceptance. Source fixtures, package behavior and external gates remain distinct. Continue the next admitted maintained-application or playable-instance clause from synchronized dev.\n\nEvidence: evidence/produced-linux-environment-tui.v1.json and hash-closed custody; actual Windows/Mac reconstruction is retained at evidence/produced-environment-reconstruction.v1.json.\n')
 paths=expected|{Q+'/evidence/'+evidence.name,Q+'/evidence/'+archive.name}
 run('project-state',['py','-3','-B','tools/project_state.py','--write'],600)
 run('metadata',['py','-3','-B','tools/codegen/generate_metadata.py','--write'])
 changed=dirty();assert paths<=changed<=paths|{'.aide/memory/project-state.md','.aide/memory/project-state.v2.json','README.md'}
 run('strict',['py','-3','-B','tools/strict_check.py'],1800)
 run('portable-aide',['py','-3','-B','.aide/scripts/aide_lite.py','test'],1800)
 message='test(terminal): record delivered Linux reconstruction and TUI\n\nVerify the existing distributions with exact input preservation,\nrecovery, terminal restoration and naturally completed owned processes.\n\nWork-Item: FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01\nEvidence-Ref: '+Q+'/evidence/'+evidence.name+'\n'
 msg=E/'linux-delivered-qualified-commit-message-01.txt';msg.write_text(message,encoding='utf-8',newline='\n')
 run('message',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--message',message])
 changes=[dict(path=name,state='content',sha256=sha(R/name),git_blob_oid=git('hash-object','--path',name,str(R/name)),ownership='task_owned') for name in sorted(changed)]
 snapshot=hashlib.sha256((json.dumps(changes,indent=2,sort_keys=True,separators=(',',': '))+'\n').encode()).hexdigest()
 commit_review=E/'linux-delivered-qualified-commit-review-01.json'
 commit_review.write_text(json.dumps(dict(schema_version='aide.git-commit-review.v1',verdict='PASS',reviewer='/root',author='/root/linux_delivered_environment_implementation',non_authoring=True,branch=BRANCH,base_commit=BASE,snapshot_sha256=snapshot,message_sha256=sha(msg),independent_source_review_sha256=sha(review),review='Existing authentic distributions, exact source/tree/providers/closure and public reconstruction/TUI behavior independently verified; original owner unknown semantics and user-data refusal preserved. WSL/tmpfs and non-release scope remain explicit. Qualified task-owned receipts only; no source/product/policy changes.'),indent=2)+'\n',encoding='utf-8')
 classification=E/'linux-delivered-qualified-commit-classification-01.json'
 classification.write_text(json.dumps(dict(schema_version='aide.git-commit-classification.v1',branch=BRANCH,base_commit=BASE,work_item='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01',snapshot_sha256=snapshot,message_sha256=sha(msg),changed_paths=changes,reviews=[dict(path=str(commit_review),sha256=sha(commit_review),verdict='PASS')]),indent=2)+'\n',encoding='utf-8')
 helper=['py','-3','-B','.aide/scripts/aide_lite.py','git','commit-plan','--classification',str(classification),'--message-file',str(msg)]
 run('plan-stage',helper);run('stage',['git','add','--',*sorted(changed)]);run('staged-diff',['git','diff','--cached','--check']);run('plan-commit',helper)
 assert git('rev-parse','HEAD')==BASE
 run('commit',['git','commit','-F',str(msg)])
 run('range',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--range',BASE+'..HEAD'])
 remaining=git('diff','--name-only').splitlines()
 if remaining:
  assert set(remaining)<={'.aide/memory/project-state.md','.aide/memory/project-state.v2.json','README.md'}
  for name in remaining:assert git('hash-object','--path',name,str(R/name))==git('rev-parse','HEAD:'+name)
  run('refresh-generated-index',['git','add','--',*remaining])
 assert not git('status','--porcelain') and not git('diff','--cached','--name-only')
 record.update(status='COMMITTED_QUALIFIED_LINUX_DELIVERED_ACCEPTANCE',source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),review_sha256=sha(commit_review),evidence_sha256=sha(evidence),custody_archive_bytes=archive.stat().st_size,required_checks_pending=True,remote_not_pushed=True)
except BaseException as error:record.update(status='ACTIONABLE_LINUX_ACCEPTANCE_COMMIT_FAILURE',error=str(error),traceback=traceback.format_exc())
finally:save();print(json.dumps({key:value for key,value in record.items() if key not in ('commands','traceback')},indent=2))
raise SystemExit(0 if record['status']=='COMMITTED_QUALIFIED_LINUX_DELIVERED_ACCEPTANCE' else 1)
