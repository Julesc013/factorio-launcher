import ast,hashlib,json
from pathlib import Path
E=Path(__file__).resolve().parent
result=json.loads((E/'linux-delivered-launch-result-01.json').read_bytes());assert result['status']=='PASS_OWNED_LINUX_PACKAGED_ENVIRONMENT_AND_TUI'
def change(text,old,new):
 assert text.count(old)==1,old
 return text.replace(old,new)
worker=(E/'linux-delivered-worker-01.py').read_text(encoding='utf-8')
worker=worker.replace("O=E/'linux-delivered-evidence-01'","O=E/'linux-delivered-evidence-03'")
old=""" start=time.monotonic();p=subprocess.Popen(args,**kwargs)
 lifetimes.append(dict(process=p,argv=list(args),pid=p.pid,started=start,cwd=str(kwargs.get('cwd')),environment={k:v for k,v in kwargs.get('env',{}).items() if k in ('PATH','TERM','LANG','HOME','TMPDIR','TEMP','TMP','LD_PRELOAD','LD_LIBRARY_PATH','DISPLAY','WAYLAND_DISPLAY') or k.startswith(('FACMAN_','FLAUNCH_','ULK_','USK_','DYLD_'))}))
 return p"""
new=""" start=time.monotonic();p=subprocess.Popen(args,**kwargs)
 status={line.split(':',1)[0]:line.split(':',1)[1].split() for line in Path('/proc',str(p.pid),'status').read_text(encoding='utf-8').splitlines() if ':' in line}
 ticks=int(Path('/proc',str(p.pid),'stat').read_text(encoding='utf-8').rsplit(')',1)[1].split()[19])
 uid=list(map(int,status['Uid']));gid=list(map(int,status['Gid']));groups=list(map(int,status['Groups']))
 assert uid==gid==[65534]*4 and groups==[] and ticks>0
 row=dict(process=p,argv=list(args),pid=p.pid,start_ticks=ticks,uid=uid,gid=gid,groups=groups,started=start,cwd=str(kwargs.get('cwd')),termination='launched_outcome_unknown',environment={k:v for k,v in kwargs.get('env',{}).items() if k in ('PATH','TERM','LANG','HOME','TMPDIR','TEMP','TMP','LD_PRELOAD','LD_LIBRARY_PATH','DISPLAY','WAYLAND_DISPLAY') or k.startswith(('FACMAN_','FLAUNCH_','ULK_','USK_','DYLD_'))})
 lifetimes.append(row)
 class RetainedChild:
  def __getattr__(self,name):return getattr(p,name)
  def communicate(self,*arguments,**options):
   output=p.communicate(*arguments,**options)
   row.update(exit_code=p.returncode,normal_wait=True,elapsed_seconds=time.monotonic()-start)
   if row['termination']=='launched_outcome_unknown':row['termination']='completed'
   return output
  def wait(self,*arguments,**options):
   code=p.wait(*arguments,**options)
   row.update(exit_code=code,normal_wait=True,elapsed_seconds=time.monotonic()-start)
   if row['termination']=='launched_outcome_unknown':row['termination']='completed'
   return code
  def kill(self):
   row['termination']='safety_cleanup_kill'
   return p.kill()
 return RetainedChild()"""
worker=change(worker,old,new)
worker=change(worker,"assert not life['alive'] and not life['proc_entry_present'] and life['normal_wait']","assert not life['alive'] and not life['proc_entry_present'] and life['normal_wait'] and life['termination']=='completed'")
worker=worker.replace("assert all(not row['alive'] and not row['proc_entry_present'] for row in lifetime_rows()","assert all(not row['alive'] and not row['proc_entry_present'] and row['normal_wait'] and row['termination']=='completed' for row in lifetime_rows()")
worker=change(worker,"fixture=C/'fixture-install';fixture_before=closure(fixture)","fixture=C/'fixture-install';fixture_before=closure(fixture)\nassert all(stat.S_IMODE(p.stat().st_mode)&0o222==0 for p in (fixture,*fixture.rglob('*')))\nfixture_probe=next(p for p in fixture.rglob('*') if p.is_file())\ntry:stream=fixture_probe.open('ab')\nexcept PermissionError:pass\nelse:stream.close();raise AssertionError('registered installation is writable by consumer')")
worker=change(worker,"build=json.loads((package/'manifest/build_info.v1.json').read_bytes());backend=", "build=json.loads((package/'manifest/build_info.v1.json').read_bytes())\n assert build['profile_id']=='linux_portable_'+kind+'_x64'\n assert build['source_revisions']==dict(factorio_launcher='0a1310b4f6703d0ec3371966e8781958a8a0cb29',universal_launcher='5479939ca5cbc9ee0f901608a92012778b4752ae',universal_setup='2749a15b835a6c1c9968598a2b434d85809691ad')\n backend=")
worker=change(worker,"dict(status='PASS_LINUX_PACKAGED_ENVIRONMENT_AND_TUI',bindings=", "dict(status='PASS_LINUX_PACKAGED_ENVIRONMENT_AND_TUI',uid=os.getuid(),gid=os.getgid(),groups=os.getgroups(),bindings=")
namespace=(E/'linux-delivered-namespace-01.py').read_text(encoding='utf-8')
for old,new in (("O=E/'linux-delivered-evidence-01'","O=E/'linux-delivered-evidence-03'"),('linux-delivered-namespace-result-01.json','linux-delivered-namespace-result-03.json'),('linux-delivered-worker-01.py','linux-delivered-worker-03.py'),('linux-delivered-worker-01.stdout','linux-delivered-worker-03.stdout'),('linux-delivered-worker-01.stderr','linux-delivered-worker-03.stderr'),('linux-delivered-unresolved-fixtures-01.tar.gz','linux-delivered-unresolved-fixtures-03.tar.gz')):namespace=namespace.replace(old,new)
namespace=change(namespace,"  assert not record['remaining_namespace_processes'],'refusing PASS/teardown with unresolved owned consumers'\n  subprocess.run(['/usr/bin/umount',str(M)],check=True,timeout=30)","  save()\n  if not record['remaining_namespace_processes']:\n   subprocess.run(['/usr/bin/umount',str(M)],check=True,timeout=30)\n  else:record['teardown']='private namespace lifecycle owns outstanding failure processes; no PASS'")
launch=(E/'linux-delivered-launch-01.py').read_text(encoding='utf-8')
for old,new in (('linux-delivered-launch-result-01.json','linux-delivered-launch-result-03.json'),('linux-delivered-namespace-01.py','linux-delivered-namespace-03.py'),('linux-delivered-namespace-result-01.json','linux-delivered-namespace-result-03.json'),('linux-delivered-owned-execution-01','linux-delivered-owned-execution-03')):launch=launch.replace(old,new)
launch=change(launch,"record['admission_waits']=[];deadline=time.monotonic()+1800","record['admission_waits']=[]")
launch=change(launch,"  assert time.monotonic()<deadline,'foreign workload admission deadline exceeded';time.sleep(30)","  interval=(30,45,60)[min(len(record['admission_waits'])-1,2)]\n  record['next_admission_seconds']=interval;save();time.sleep(interval)")
launch=change(launch,"M=E/'linux-delivered-private-01';assert not M.exists();M.mkdir()","M=E/'linux-delivered-private-01'\n if not M.exists():M.mkdir()\n assert M.is_dir() and not list(M.iterdir())")
launch=change(launch,"empty=not os.listdir(","empty=(not os.path.exists(")
# Replace the full probe string to preserve absent-leaf semantics precisely.
start=launch.index(' check=');end=launch.index("\n record['parent_mount_after']",start)
launch=launch[:start]+" check=\"import os,json;p=\"+repr(linux_e+'/linux-delivered-private-01')+\";print(json.dumps(dict(exists=os.path.exists(p),mounted=os.path.ismount(p),empty=(not os.path.exists(p) or not os.listdir(p)))))\""+launch[end:]
launch=change(launch,"record['parent_mount_after']==dict(mounted=False,empty=True)","record['parent_mount_after']==dict(exists=True,mounted=False,empty=True)")
launch=change(launch,"print(json.dumps({k:v for k,v in record.items() if k not in ('source_commit','argv')},indent=2))","print(json.dumps({k:v for k,v in record.items() if k not in ('source_commit','argv','admission_waits')},indent=2))")
for name,content in (('linux-delivered-worker-03.py',worker),('linux-delivered-namespace-03.py',namespace),('linux-delivered-launch-03.py',launch)):
 ast.parse(content);path=E/name;assert not path.exists();path.write_text(content,encoding='utf-8')
 print(name+' sha256='+hashlib.sha256(path.read_bytes()).hexdigest())
