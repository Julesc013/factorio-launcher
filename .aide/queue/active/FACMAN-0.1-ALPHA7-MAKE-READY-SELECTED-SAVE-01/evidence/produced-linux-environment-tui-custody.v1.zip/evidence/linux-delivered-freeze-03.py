import hashlib,json
from pathlib import Path
E=Path(__file__).resolve().parent;O=E/'linux-delivered-evidence-03';R=Path(r'D:\Projects\Factorio\factorio-launcher')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
launch=json.loads((E/'linux-delivered-launch-result-03.json').read_bytes())
namespace=json.loads((E/'linux-delivered-namespace-result-03.json').read_bytes())
worker=json.loads((O/'worker-result.json').read_bytes())
assert launch['status']=='PASS_OWNED_LINUX_PACKAGED_ENVIRONMENT_AND_TUI'
assert namespace['status']==worker['status']=='PASS_LINUX_PACKAGED_ENVIRONMENT_AND_TUI'
assert not namespace['remaining_namespace_processes'] and namespace['private_mount_absent']
assert launch['parent_mount_after']==dict(exists=True,mounted=False,empty=True)
assert worker['uid']==worker['gid']==65534 and worker['groups']==[]
assert len(worker['processes'])==133
for row in worker['processes']:
 assert row['normal_wait'] and row['termination']=='completed' and not row['alive'] and not row['proc_entry_present']
 assert row['uid']==row['gid']==[65534]*4 and not row['groups'] and row['start_ticks']>0
 assert row['environment']['PATH']=='' and not any(key in row['environment'] for key in ('LD_PRELOAD','LD_LIBRARY_PATH','DISPLAY','WAYLAND_DISPLAY','FACMAN_CLI_EXE','FACMAN_TUI_EXE'))
download=json.loads((E/'linux-delivered-download-result-01.json').read_bytes())
archive=E/'linux-delivered-artifact-11867723625.zip';assert sha(archive)==download['archive_sha256']=='2ab87b50731c5308c8a417a21f997c15fc09cde9b84b31979e45d1071bd6c393'
for name,digest in namespace['source_hashes'].items():assert sha(R/name)==digest,name
scenarios=[]
for folder in sorted(O.glob('environment-*')):
 effects=json.loads((folder/'calls.json').read_bytes());receipt=json.loads((folder/'result.json').read_bytes())
 assert receipt['result']=='pass' and effects['tests_run']==1 and not effects['errors'] and not effects['failures'] and not effects['skips']
 scenarios.append(dict(scenario=effects['scenario'],calls=len(effects['calls']),custody_sha256=receipt['custody_canonical_json_sha256'],source_test_sha256=effects['source_test_sha256'],adapter_sha256=effects['adapter_sha256']))
assert sorted(row['calls'] for row in scenarios)==[32,37,38]
for mode in ('linear','fullscreen'):
 receipt=json.loads((O/(mode+'.result.json')).read_bytes());assert receipt['result']=='pass' and receipt['effect_components']==2
 states=json.loads((O/(mode+'.terminal-state.json')).read_bytes())['candidate_sessions']
 assert len(states)==(3 if mode=='fullscreen' else 0)
 for session in states:assert session['original']==session['immediate_after_exit']==session['after_fionread'] and session['fionread_count']==0
names=['linux-delivered-download-01.py','linux-delivered-download-result-01.json','linux-delivered-artifact-11867723625.zip','linux-delivered-original-evidence.v1.json','linux-delivered-original-facman-0.1.0-alpha.6-linux-cli-x64-portable.tar.gz.provenance.v1.json','linux-delivered-independent-script-review-03.json','linux-delivered-correct-02.py','linux-delivered-regenerate-03.py','linux-delivered-correct-03.py','linux-delivered-freeze-03.py']
for attempt in ('01','03'):
 for name in ('launch','namespace','worker'):names.append('linux-delivered-'+name+'-'+attempt+'.py')
 for name in ('launch','namespace'):names.append('linux-delivered-'+name+'-result-'+attempt+'.json')
 names.extend(['linux-delivered-worker-'+attempt+'.stdout','linux-delivered-worker-'+attempt+'.stderr'])
 names.extend(str(path.relative_to(E)) for path in (E/('linux-delivered-owned-execution-'+attempt)).rglob('*') if path.is_file())
 names.extend(str(path.relative_to(E)) for path in (E/('linux-delivered-evidence-'+attempt)).rglob('*') if path.is_file())
for name in ('launch','namespace','worker'):names.append('linux-delivered-'+name+'-02.py')
for name in download['tar_inventory']:names.append(Path(name).name)
files={name:dict(sha256=sha(E/name),bytes=(E/name).stat().st_size) for name in sorted(set(names))}
assert sum(item['bytes'] for name,item in files.items() if 'linux-delivered-evidence-' in name)<48*1024**2
record=dict(schema='facman.linux_delivered_environment_packet.v1',status='PASS_ACTUAL_LINUX_PACKAGED_ENVIRONMENT_AND_TUI_PENDING_ROOT_INDEPENDENT_CUSTODY_REVIEW',artifact_id=11867723625,artifact_sha256=download['archive_sha256'],compiled_source='0a1310b4f6703d0ec3371966e8781958a8a0cb29',compiled_tree='5bc241a1f96dd9faa04171f2fb6497a9afa14b2d',integrated_source='44dcf5b6cf22f20f89020534de72b6fa1e3a14f8',reviewed_source_hashes=namespace['source_hashes'],package_profiles=list(worker['bindings'].values()),scenarios=scenarios,environment_calls=107,processes=133,fullscreen_sessions=3,linear_effect_components=2,fullscreen_effect_components=2,uid=65534,gid=65534,groups=[],tmpfs_bytes=namespace['tmpfs_bytes'],tmpfs_used_bytes=namespace['tmpfs_used_bytes_before_unmount'],mount_absent=True,zero_owned_processes=True,source_changes=False,product_changes=False,native_build=False,new_roots=0,new_clones=0,new_worktrees=0,external_task_root_cleanup=False,ephemeral_fixture_cleanup=True,original_attempt01_preserved=True,unexecuted_draft02_preserved=True,real_play=False,real_game=False,human=False,full_make_ready=False,beta=False,rc=False,physical_ext4=False,wsl=True,files=files)
target=E/'linux-delivered-frozen-packet-03.json';assert not target.exists();target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=record['status'],packet_sha256=sha(target),packet_bytes=target.stat().st_size,files=len(files),environment_calls=107,processes=133,fullscreen_sessions=3,tmpfs_peak=record['tmpfs_used_bytes']),indent=2))
