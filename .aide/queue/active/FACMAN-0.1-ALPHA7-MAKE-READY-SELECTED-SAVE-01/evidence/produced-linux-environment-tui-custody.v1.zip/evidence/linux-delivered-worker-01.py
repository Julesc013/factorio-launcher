import base64,hashlib,json,os,shutil,stat,subprocess,sys,tempfile,time,types,unittest,zlib
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch
E=Path(__file__).resolve().parent;W=E.parent;R=Path('/mnt/d/Projects/Factorio/factorio-launcher')
M=E/'linux-delivered-private-01';C=M/'consumer';O=E/'linux-delivered-evidence-01'
sys.path[:0]=[str(R/'tests'),str(R),str(W/'validators-linux')]
import native_cli,test_local_modset_solver as solver,test_readiness_builtin_content as builtin
import test_macos_delivered_tui as reusable,delivered_environment_reconstruction as adapter,test_tui_product
from tools import package_hash_manifest
from tools.package.runtime_identity import require_backend_identity
from tools.package_runtime_smoke import machine_payload
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert os.getuid()==os.getgid()==65534 and not os.getgroups()
os.environ.update(HOME=str(C/'home'),XDG_CONFIG_HOME=str(C/'home/config'),XDG_CACHE_HOME=str(C/'home/cache'),XDG_DATA_HOME=str(C/'home/data'),TMPDIR=str(C),TMP=str(C),TEMP=str(C),PYTHONDONTWRITEBYTECODE='1')
tempfile.tempdir=str(C)
original_custody=reusable.custody_record
def linux_custody(receipt,files):
 row=original_custody(receipt,files)
 raw=zlib.decompress(base64.b64decode(row['payload_base64']));content=json.loads(raw)
 content['schema']='facman.linux_delivered_custody_content.v1'
 raw=json.dumps(content,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode('ascii');compressed=zlib.compress(raw,9);encoded=base64.b64encode(compressed).decode('ascii')
 assert len(raw)<=reusable.MAX_CUSTODY_JSON_BYTES and len(encoded)<=reusable.MAX_CUSTODY_ENCODED_BYTES
 row.update(schema='facman.linux_delivered_custody.v1',canonical_json_size_bytes=len(raw),canonical_json_sha256=hashlib.sha256(raw).hexdigest(),compressed_size_bytes=len(compressed),compressed_sha256=hashlib.sha256(compressed).hexdigest(),encoded_size_bytes=len(encoded),payload_base64=encoded)
 return row
reusable.custody_record=linux_custody
lifetimes=[]
def launch(args,**kwargs):
 start=time.monotonic();p=subprocess.Popen(args,**kwargs)
 lifetimes.append(dict(process=p,argv=list(args),pid=p.pid,started=start,cwd=str(kwargs.get('cwd')),environment={k:v for k,v in kwargs.get('env',{}).items() if k in ('PATH','TERM','LANG','HOME','TMPDIR','TEMP','TMP','LD_PRELOAD','LD_LIBRARY_PATH','DISPLAY','WAYLAND_DISPLAY') or k.startswith(('FACMAN_','FLAUNCH_','ULK_','USK_','DYLD_'))}))
 return p
def complete(args,**kwargs):
 timeout=kwargs.pop('timeout',30);kwargs.pop('check',False);capture=kwargs.pop('capture_output',False)
 if capture:kwargs.update(stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 supplied=kwargs.pop('input',None)
 if supplied is not None:kwargs['stdin']=subprocess.PIPE
 p=launch(args,**kwargs)
 stdout,stderr=p.communicate(input=supplied,timeout=timeout)
 item=lifetimes[-1];assert item['pid']==p.pid
 item.update(exit_code=p.returncode,elapsed_seconds=time.monotonic()-item['started'],normal_wait=True,stdin=supplied)
 directory=O/'commands'/f'{len(lifetimes):03}';directory.mkdir(parents=True)
 for name,data in (('stdout.raw',stdout),('stderr.raw',stderr)):
  raw=data.encode('utf-8') if isinstance(data,str) else (data or b'')
  (directory/name).write_bytes(raw);item[name]=dict(path=str((directory/name).relative_to(O)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
 return subprocess.CompletedProcess(args,p.returncode,stdout,stderr)
def lifetime_rows():
 rows=[]
 for value in lifetimes:
  row={k:v for k,v in value.items() if k!='process'};p=value['process']
  row.update(exit_code=p.poll(),alive=p.poll() is None,proc_entry_present=Path('/proc',str(p.pid)).exists())
  rows.append(row)
 return rows
class LinuxEnvironmentDriver(adapter.EnvironmentConsumerDriver):
 def run(self,args,**kwargs):
  record,workspace=self.prepare(args,kwargs)
  kwargs['timeout']=min(30,adapter.MAX_SECONDS-(time.monotonic()-self.started))
  before=len(lifetimes);done=complete(args,**kwargs);life=lifetime_rows()[before]
  assert not life['alive'] and not life['proc_entry_present'] and life['normal_wait']
  directory=f'commands/{len(self.calls):03}'
  for name,data in (('stdout.raw',done.stdout.encode('utf-8')),('stderr.raw',done.stderr.encode('utf-8')),('receipt.json',json.dumps(life,sort_keys=True).encode())):self.files[directory+'/'+name]=data
  record['process_lifetime']=life
  self.finish(record,workspace,done.returncode,done.stdout,done.stderr)
  return done
adapter.EnvironmentConsumerDriver=LinuxEnvironmentDriver
def closure(root):return {p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file()}
def readonly(root):
 assert all(stat.S_IMODE(p.stat().st_mode)&0o222==0 for p in (root,*root.rglob('*')))
 probe=root/'bin/facman'
 try:stream=probe.open('ab')
 except PermissionError:return
 stream.close();raise AssertionError('unprivileged consumer can write package executable')
bindings={};packages={};checks=[]
for kind in ('cli','tui'):
 package=M/('relocated FacMan '+kind+' Ω');packages[kind]=package;readonly(package)
 assert not package_hash_manifest.verify_manifest(package)
 exe=package/'bin/facman';env=reusable.consumer_environment(dict(os.environ))
 env.pop('LD_PRELOAD',None);env.pop('LD_LIBRARY_PATH',None);env.pop('DISPLAY',None);env.pop('WAYLAND_DISPLAY',None)
 product=complete([str(exe),'product','inspect','--json'],cwd=C,env=env,capture_output=True,text=True,timeout=30)
 assert product.returncode==0,(product.stdout,product.stderr)
 build=json.loads((package/'manifest/build_info.v1.json').read_bytes());backend=require_backend_identity(package,exe,machine_payload(product.stdout))
 assert backend['compiled_source_revision']=='0a1310b4f6703d0ec3371966e8781958a8a0cb29' and backend['compiled_source_dirty'] is False
 bindings[kind]=dict(schema='facman.linux_delivered_environment_result.v1',profile_id='linux_portable_'+kind+'_x64',backend_identity=backend,build_info=build,build_identity=build['build_identity'],build_info_sha256=sha(package/'manifest/build_info.v1.json'),manifest_sha256=sha(package/'manifest/package.v1.toml'),closure_sha256=sha(package/'manifest/hashes.sha256'),consumer_cwd_outside_source=True,consumer_overrides_removed=True,pathless=True,package_readonly=True,authenticity='not_proven_unsigned',artifact_id=11867723625,artifact_sha256='2ab87b50731c5308c8a417a21f997c15fc09cde9b84b31979e45d1071bd6c393',compiled_tree='5bc241a1f96dd9faa04171f2fb6497a9afa14b2d',integrated_source='44dcf5b6cf22f20f89020534de72b6fa1e3a14f8',physical_ext4=False,wsl=True)
 checks.append(dict(kind=kind,argv=product.args,stdout=product.stdout,stderr=product.stderr,exit_code=product.returncode,binding=bindings[kind],closure=closure(package)))
(O/'packages.json').write_text(json.dumps(checks,indent=2)+'\n')
fixture=C/'fixture-install';fixture_before=closure(fixture)
class Owner(unittest.TestCase):
 def runTest(self):pass
owner=Owner()
try:
 with patch.dict(os.environ,env,clear=True):
  for scenario in adapter.SCENARIOS:
   adapter.exercise(owner,scenario,package=packages['cli'],consumer=C,fixture=fixture,binding=bindings['cli'],evidence_root=O)
 class TuiOwner(unittest.TestCase):
  exercise_scenario=test_tui_product.TuiProductTests.exercise_ordinary_selected_save_missing_configuration_then_context
  invoke=reusable.MacosDeliveredTuiTests.invoke
  def invoke_pty(self,args,stdin):
   self.dispatches.append(dict(argv=[str(self.executable),'tui',*args],stdin_commands=stdin,key_bytes_hex=b''.join({'tab':b'\t','space':b' '}.get(command,command.encode()) for command in stdin.splitlines()).hex()))
   return reusable.MacosDeliveredTuiTests.invoke_pty(self,args,stdin)
  def runTest(self):pass
  def run_cli(self,args,**kwargs):
   self.assertEqual(str(self.executable),args[0]);kwargs.update(cwd=C,env=env,timeout=30)
   return complete(args,**kwargs)
 for mode in ('linear','fullscreen'):
  tui=TuiOwner();tui.mode=mode;tui.executable=packages['tui']/'bin/facman';tui.consumer=C;tui.environment=env;tui.outputs=[];tui.terminal_states=[];tui.dispatches=[];effects=[];passed=False
  driver=types.SimpleNamespace(run=tui.run_cli,PIPE=subprocess.PIPE)
  tui_proxy=types.SimpleNamespace(run=complete,Popen=launch,CompletedProcess=subprocess.CompletedProcess)
  start=len(lifetimes)
  try:
   with ExitStack() as stack:
    stack.enter_context(patch.dict(os.environ,dict(env,FACMAN_CLI_EXE=str(tui.executable)),clear=True))
    stack.enter_context(patch.object(native_cli,'ROOT',C));stack.enter_context(patch.object(native_cli,'subprocess',driver))
    stack.enter_context(patch.object(reusable,'subprocess',tui_proxy))
    stack.enter_context(patch.object(solver,'FIXTURE_INSTALL',fixture));stack.enter_context(patch.object(builtin,'FIXTURE_INSTALL',fixture))
    tui.exercise_scenario(evidence=effects)
   assert len(effects)==2 and len(tui.terminal_states)==(3 if mode=='fullscreen' else 0)
   assert all(not row['alive'] and not row['proc_entry_present'] for row in lifetime_rows()[start:])
   for session in tui.terminal_states:assert session['original']==session['immediate_after_exit']==session['after_fionread'] and session['fionread_count']==0
   readonly(packages['tui']);assert not package_hash_manifest.verify_manifest(packages['tui']);passed=True
  finally:
   files={mode+'.terminal.log':'\n'.join(tui.outputs).encode(),mode+'.effects.json':json.dumps(effects,sort_keys=True).encode(),mode+'.terminal-state.json':json.dumps(dict(schema='facman.linux_delivered_tui_terminal_state.v1',candidate_sessions=tui.terminal_states,dispatches=tui.dispatches),sort_keys=True).encode(),mode+'.processes.json':json.dumps(lifetime_rows()[start:],sort_keys=True).encode()}
   receipt=dict(bindings['tui'],mode=mode,result='pass' if passed else 'fail',test_id='linux_delivered.TuiOwner.'+mode,terminal_sessions=len(tui.terminal_states),effect_components=len(effects))
   custody=linux_custody(receipt,files);receipt['custody_canonical_json_sha256']=custody['canonical_json_sha256']
   for name,data in files.items():(O/name).write_bytes(data)
   (O/(mode+'.result.json')).write_text(json.dumps(receipt,indent=2)+'\n')
   print('delivered-tui-custody: '+json.dumps(custody,sort_keys=True,separators=(',',':')),flush=True)
   print('delivered-linux-tui-evidence: '+json.dumps(receipt,sort_keys=True),flush=True)
 assert fixture_before==closure(fixture)
 for item in checks:
  assert item['closure']==closure(packages[item['kind']]);readonly(packages[item['kind']]);assert not package_hash_manifest.verify_manifest(packages[item['kind']])
 assert all(not row['alive'] and not row['proc_entry_present'] for row in lifetime_rows())
 (O/'worker-result.json').write_text(json.dumps(dict(status='PASS_LINUX_PACKAGED_ENVIRONMENT_AND_TUI',bindings=bindings,processes=lifetime_rows(),fixture_readonly=True,fixture_preserved=True,real_play=False,real_game=False,human=False),indent=2)+'\n')
finally:
 (O/'process-lifetimes.json').write_text(json.dumps(lifetime_rows(),indent=2)+'\n')
