import hashlib,json,os,shutil,subprocess,tarfile,time,traceback
from pathlib import Path,PurePosixPath
E=Path(__file__).resolve().parent;W=E.parent;R=Path('/mnt/d/Projects/Factorio/factorio-launcher');M=E/'linux-delivered-private-01';O=E/'linux-delivered-evidence-03'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert os.getpid()==1 and os.getuid()==0
assert os.readlink('/proc/self/ns/mnt')!=os.environ['FACMAN_PARENT_MOUNT_NAMESPACE']
os.environ.update(FACMAN_DEV_ROOT='/mnt/d/Projects/Factorio/.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),TMPDIR=str(W/'t'),PYTHONDONTWRITEBYTECODE='1')
record=dict(status='PREPARING_GENUINE_LINUX_PACKAGES',pid=os.getpid(),uid=os.getuid(),gid=os.getgid(),mount_namespace=os.readlink('/proc/self/ns/mnt'),pid_namespace=os.readlink('/proc/self/ns/pid'),tmpfs_bytes=512*1024**2,physical_ext4=False,new_roots=0,new_clones=0,new_worktrees=0,no_native_build=True,source_hashes={name:sha(R/name) for name in ('tests/test_environment_reconstruction.py','tests/delivered_environment_reconstruction.py','tests/test_macos_delivered_tui.py','tests/test_tui_product.py','tests/native_cli.py','tools/package_hash_manifest.py','tools/package/runtime_identity.py','release/index/workspace_lock.v1.toml')})
out=E/'linux-delivered-namespace-result-03.json';assert not out.exists()
save=lambda:out.write_text(json.dumps(record,indent=2)+'\n')
mounted=False
try:
 assert M.is_dir() and not list(M.iterdir()) and not os.path.ismount(M)
 memory=int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')))*1024
 assert memory>1024**3;record['memory_available_before']=memory
 download=json.loads((E/'linux-delivered-download-result-01.json').read_bytes())
 assert sum(item['expanded_bytes'] for item in download['tar_inventory'].values())<192*1024**2
 subprocess.run(['/usr/bin/mount','-t','tmpfs','-o','size=512m,nosuid,nodev,mode=1777','facman-linux-delivered',str(M)],check=True,timeout=30);mounted=True
 record['private_mount']=next(line for line in Path('/proc/self/mountinfo').read_text().splitlines() if str(M) in line)
 assert os.statvfs(M).f_blocks*os.statvfs(M).f_frsize==512*1024**2
 record['packages']={}
 for kind in ('cli','tui'):
  name,info=next((name,info) for name,info in download['tar_inventory'].items() if '-linux-'+kind+'-' in name)
  archive=E/Path(name).name;assert sha(archive)==info['sha256']
  target=M/('relocated FacMan '+kind+' Ω');target.mkdir()
  with tarfile.open(archive,mode='r:gz') as tar:
   members=tar.getmembers();assert sum(m.size for m in members)==info['expanded_bytes']
   for member in members:
    p=PurePosixPath(member.name);assert not p.is_absolute() and '..' not in p.parts and not (member.issym() or member.islnk() or member.isdev())
   tar.extractall(target,filter='data')
  for path in (target,*target.rglob('*')):path.chmod((path.stat().st_mode&0o777)&~0o222)
  record['packages'][kind]=dict(archive=archive.name,archive_sha256=sha(archive),expanded_bytes=info['expanded_bytes'],path=str(target))
 consumer=M/'consumer';consumer.mkdir();consumer.chmod(0o777);(consumer/'home').mkdir();(consumer/'home').chmod(0o777)
 fixture=consumer/'fixture-install'
 import sys;sys.path[:0]=[str(R/'tests'),str(R),str(W/'validators-linux')]
 import test_local_modset_solver as solver
 shutil.copytree(solver.FIXTURE_INSTALL,fixture)
 for path in (fixture,*fixture.rglob('*')):path.chmod((path.stat().st_mode&0o777)&~0o222)
 record['registered_installation']=dict(path=str(fixture),sha256={p.relative_to(fixture).as_posix():sha(p) for p in fixture.rglob('*') if p.is_file()})
 O.mkdir();O.chmod(0o777)
 record['status']='RUNNING_GENUINE_PACKAGED_LINUX_CONSUMERS';save()
 args=['/usr/bin/setpriv','--reuid=65534','--regid=65534','--clear-groups','/usr/bin/python3','-B',str(E/'linux-delivered-worker-03.py')]
 with (E/'linux-delivered-worker-03.stdout').open('xb') as stdout,(E/'linux-delivered-worker-03.stderr').open('xb') as stderr:
  process=subprocess.Popen(args,cwd=consumer,env=dict(os.environ),stdout=stdout,stderr=stderr)
  record['worker_pid']=process.pid;code=process.wait(timeout=900)
 record.update(worker_exit=code,worker_proc_entry_after=Path('/proc',str(process.pid)).exists(),worker_stdout_sha256=sha(E/'linux-delivered-worker-03.stdout'),worker_stderr_sha256=sha(E/'linux-delivered-worker-03.stderr'))
 assert code==0 and not record['worker_proc_entry_after'],('worker_failed',code)
 assert json.loads((O/'worker-result.json').read_bytes())['status']=='PASS_LINUX_PACKAGED_ENVIRONMENT_AND_TUI'
 record['status']='PASS_LINUX_PACKAGED_ENVIRONMENT_AND_TUI'
except BaseException as error:record.update(status='ACTIONABLE_LINUX_DELIVERED_FAILURE',error=str(error),traceback=traceback.format_exc())
finally:
 record['remaining_namespace_processes']=[]
 for path in Path('/proc').iterdir():
  if path.name.isdigit() and path.name!='1':
   try:record['remaining_namespace_processes'].append(dict(pid=int(path.name),command=(path/'cmdline').read_bytes().decode(errors='replace').replace('\0',' ')))
   except FileNotFoundError:pass
 if record['remaining_namespace_processes']:record['status']='ACTIONABLE_OWNED_PROCESSES_REMAIN_FAILURE'
 record['evidence_before_unmount']={p.relative_to(O).as_posix():dict(sha256=sha(p),bytes=p.stat().st_size) for p in O.rglob('*') if p.is_file()} if O.exists() else {}
 if mounted:
  record['tmpfs_used_bytes_before_unmount']=(os.statvfs(M).f_blocks-os.statvfs(M).f_bfree)*os.statvfs(M).f_frsize
  if not record['status'].startswith('PASS_'):
   with tarfile.open(E/'linux-delivered-unresolved-fixtures-03.tar.gz','w:gz') as archive:archive.add(M/'consumer',arcname='consumer')
   record['unresolved_fixtures_sha256']=sha(E/'linux-delivered-unresolved-fixtures-03.tar.gz')
  # Exported CAS and genuine source archives are durable before private namespace teardown.
  save()
  if not record['remaining_namespace_processes']:
   subprocess.run(['/usr/bin/umount',str(M)],check=True,timeout=30)
  else:record['teardown']='private namespace lifecycle owns outstanding failure processes; no PASS'
 record['private_mount_absent']=not os.path.ismount(M)
 for name,digest in record['source_hashes'].items():assert sha(R/name)==digest,name
 save();print(json.dumps({k:v for k,v in record.items() if k not in ('evidence_before_unmount','source_hashes','registered_installation')},indent=2),flush=True)
 raise SystemExit(0 if record['status'].startswith('PASS_') else 1)
