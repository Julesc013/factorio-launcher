import hashlib,json,os,shutil,subprocess,sys,time,traceback
from pathlib import Path
E=Path(__file__).resolve().parent;W=E.parent;R=Path(r'D:\Projects\Factorio\factorio-launcher')
sys.path.insert(0,str(R));from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1')
linux_e='/mnt/d/'+str(E)[3:].replace('\\','/')
out=E/'linux-delivered-launch-result-01.json';assert not out.exists()
record=dict(status='ADMISSION',new_roots=0,new_clones=0,new_worktrees=0,no_native_build=True,planned_peak_disk_bytes=512*1024**2,private_tmpfs_bytes=512*1024**2)
probe="""import json,os
active=[]
for name in os.listdir('/proc'):
 if name.isdigit():
  try:
   comm=open('/proc/'+name+'/comm').read().strip()
   if comm in {'facman','cmake','ninja','cc1plus','ctest','g++','c++','clang','clang++'}:active.append(dict(pid=int(name),command=open('/proc/'+name+'/cmdline','rb').read().decode(errors='replace').replace(chr(0),' ')))
  except FileNotFoundError:pass
print(json.dumps(dict(mount_namespace=os.readlink('/proc/self/ns/mnt'),active=active)))"""
query="$all=@(Get-CimInstance Win32_Process); @($all | Where-Object { $_.Name -match '^(cl|clang|link|ninja|ctest)\\.exe$' -or ($_.Name -eq 'cmake.exe' -and $_.CommandLine -like '*--build*') -or ($_.Name -eq 'MSBuild.exe' -and $_.CommandLine -notlike '*/nodemode:*') } | Select-Object Name,ProcessId,ParentProcessId,CommandLine) | ConvertTo-Json -Depth 4 -Compress -AsArray"
def census():return dict(windows=json.loads(subprocess.check_output(['pwsh','-NoProfile','-Command',query],text=True,timeout=45) or '[]'),linux=json.loads(subprocess.check_output(['wsl.exe','-d','Ubuntu-24.04','-u','root','--exec','/usr/bin/python3','-B','-c',probe],text=True,timeout=45)))
save=lambda:out.write_text(json.dumps(record,indent=2)+'\n')
try:
 record['admission_waits']=[];deadline=time.monotonic()+1800
 while True:
  record['before']=census()
  if not record['before']['windows'] and not record['before']['linux']['active']:break
  record['status']='WAITING_FOREIGN_NATIVE_WORK_UNTOUCHED';record['admission_waits'].append(record['before']);save()
  assert time.monotonic()<deadline,'foreign workload admission deadline exceeded';time.sleep(30)
 record['free_bytes_before']=shutil.disk_usage(W).free;assert record['free_bytes_before']>20*1024**3
 M=E/'linux-delivered-private-01';assert not M.exists();M.mkdir()
 record['source_commit']=json.loads(subprocess.check_output(['gh','api','repos/Julesc013/factorio-launcher/git/commits/0a1310b4f6703d0ec3371966e8781958a8a0cb29']))
 assert record['source_commit']['tree']['sha']=='5bc241a1f96dd9faa04171f2fb6497a9afa14b2d'
 record['argv']=['wsl.exe','-d','Ubuntu-24.04','-u','root','--exec','/usr/bin/env','FACMAN_PARENT_MOUNT_NAMESPACE='+record['before']['linux']['mount_namespace'],'/usr/bin/timeout','--signal=TERM','--kill-after=15s','1050s','/usr/bin/unshare','--mount','--pid','--fork','--mount-proc','--kill-child=SIGKILL','/usr/bin/python3','-B',linux_e+'/linux-delivered-namespace-01.py']
 record['status']='RUNNING_FINITE_OWNED_LINUX_PACKAGE_JOB';save()
 result=owned.command(record['argv'],cwd=R,environment=dict(os.environ),timeout=1080,directory=E/'linux-delivered-owned-execution-01',output_limit=2*1024*1024,wait_for_job_empty_after_primary=True)
 record['command_receipt_sha256']=sha(result.directory/'receipt.json');record['exit_code']=result.returncode
 assert result.ok and result.receipt['primary_stopped'] and result.receipt['job_empty_observed'] and not result.receipt['job_terminated']
 record['namespace_result_sha256']=sha(E/'linux-delivered-namespace-result-01.json');record['status']='PASS_OWNED_LINUX_PACKAGED_ENVIRONMENT_AND_TUI'
except BaseException as error:record.update(status='ACTIONABLE_LINUX_DELIVERED_LAUNCH_FAILURE',error=str(error),traceback=traceback.format_exc())
finally:
 record['after']=census();record['free_bytes_after']=shutil.disk_usage(W).free
 check="import os,json;print(json.dumps(dict(mounted=os.path.ismount("+repr(linux_e+'/linux-delivered-private-01')+"),empty=not os.listdir("+repr(linux_e+'/linux-delivered-private-01')+"))))"
 record['parent_mount_after']=json.loads(subprocess.check_output(['wsl.exe','-d','Ubuntu-24.04','-u','root','--exec','/usr/bin/python3','-B','-c',check],text=True,timeout=45))
 if record['status'].startswith('PASS_'):assert record['parent_mount_after']==dict(mounted=False,empty=True) and not record['after']['linux']['active']
 save();print(json.dumps({k:v for k,v in record.items() if k not in ('source_commit','argv')},indent=2));raise SystemExit(0 if record['status'].startswith('PASS_') else 1)
