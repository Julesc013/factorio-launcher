import hashlib,json,os,subprocess,zipfile,tarfile,io,shutil
from pathlib import Path,PurePosixPath
E=Path(__file__).resolve().parent;W=E.parent
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1')
identity=subprocess.check_output(['whoami'],text=True).strip()
assert identity.lower()==r'blackglass-win1\jules'
assert subprocess.check_output(['gh','api','user','--jq','.login'],text=True).strip()=='Julesc013'
artifact=json.loads(subprocess.check_output(['gh','api','repos/Julesc013/factorio-launcher/actions/artifacts/11867723625']))
assert artifact['size_in_bytes']==56385686 and not artifact['expired']
assert artifact['digest']=='sha256:2ab87b50731c5308c8a417a21f997c15fc09cde9b84b31979e45d1071bd6c393'
archive=E/'linux-delivered-artifact-11867723625.zip'
assert not archive.exists()
assert shutil.disk_usage(W).free>20*1024**3
with archive.open('xb') as out:
 subprocess.run(['gh','api','repos/Julesc013/factorio-launcher/actions/artifacts/11867723625/zip'],stdout=out,check=True,timeout=180)
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
assert digest==artifact['digest'].split(':')[1]
with zipfile.ZipFile(archive) as z:
 inventory=[dict(name=n.filename,size=n.file_size,compressed=n.compress_size) for n in z.infolist()]
 assert sum(n.file_size for n in z.infolist())<256*1024**2
 for n in z.infolist():
  p=PurePosixPath(n.filename);assert not p.is_absolute() and '..' not in p.parts and '\\' not in n.filename
 selected=[n for n in z.infolist() if n.filename.endswith('.tar.gz') and ('linux-cli-x64-portable' in n.filename or 'linux-tui-x64-portable' in n.filename)]
 assert len(selected)==2,[n.filename for n in z.infolist()]
 tar_inventory={}
 for n in selected:
  data=z.read(n)
  with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:
   members=t.getmembers(); assert sum(m.size for m in members)<256*1024**2
   for m in members:
    p=PurePosixPath(m.name);assert not p.is_absolute() and '..' not in p.parts and not (m.issym() or m.islnk() or m.isdev())
   tar_inventory[n.filename]=dict(sha256=hashlib.sha256(data).hexdigest(),members=len(members),expanded_bytes=sum(m.size for m in members),roots=sorted({PurePosixPath(m.name).parts[0] for m in members}))
  (E/Path(n.filename).name).write_bytes(data)
 # Preserve small authentic provenance/evidence separately, without expanding the archive tree.
 small={}
 for n in z.infolist():
  if n.filename.endswith(('.json','.txt','.sha256','.toml')) and n.file_size<1024*1024:
   path=E/('linux-delivered-original-'+Path(n.filename).name)
   assert not path.exists();path.write_bytes(z.read(n));small[n.filename]=dict(file=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
record=dict(schema='facman.linux_delivered_download.v1',identity=identity,artifact=artifact,archive_sha256=digest,archive_bytes=archive.stat().st_size,zip_inventory=inventory,tar_inventory=tar_inventory,small_evidence=small,peak_increment_bytes=archive.stat().st_size+sum(n['expanded_bytes'] for n in tar_inventory.values())+sum(n['size'] for n in inventory),free_bytes=shutil.disk_usage(W).free)
(E/'linux-delivered-download-result-01.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(archive_sha256=digest,tar_inventory=tar_inventory,free_bytes=record['free_bytes']),indent=2))
