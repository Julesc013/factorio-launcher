"""Focused Python-version CI recovery using unchanged hash-bound native consumers."""
from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,sys
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent
W=E.parent;OUT=E/'existing-configuration-py311-qualification-01.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert HEAD=='d87d5343f53aa76ec79d53e7d6f2c032e521c477' and not OUT.exists()
native=json.loads((E/'existing-configuration-qualification-03.json').read_text())
exe=Path(native['binaries']['facman.exe']['path'])
assert sha(exe)==native['binaries']['facman.exe']['sha256']
record=dict(schema='facman.existing_configuration_py311_qualification.v1',status='STARTED',source_head=HEAD,
    CLI=str(exe),CLI_sha256=sha(exe),native_product_changed=False,new_builds=0,new_candidates=0,
    unchanged_native_qualification_sha256=sha(E/'existing-configuration-qualification-04.json'),
    failed_job='https://github.com/Julesc013/factorio-launcher/actions/runs/37807914298/job/113416950478',
    failed_job_log_sha256=sha(E/'pr401-windows-native-job-113416950478-failure.log'),
    fixed_test_sha256=sha(R/'tests/test_configuration_reconciliation.py'),steps=[],
    whole_workunit_closed=False,produced_package_qualified=False)
def save():
    pending=OUT.with_suffix('.pending.json');pending.write_text(json.dumps(record,indent=2)+'\n');os.replace(pending,OUT)
def run(version):
    temp=E/('existing-configuration-python-'+version+'-qualified-01')
    assert not temp.exists();temp.mkdir()
    child_env=dict(os.environ,FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',
        FACMAN_CLI_EXE=str(exe),FACMAN_NATIVE_BUILD_ROOT=str(W/'native-developer'),
        FACMAN_NATIVE_CONFIGURATION='Release',PYTHONPATH=str(R/'tests'),TEMP=str(temp),TMP=str(temp),
        PYTHONDONTWRITEBYTECODE='1')
    command=['py','-'+version,'-B','-m','unittest','-v','test_configuration_reconciliation']
    log=E/('existing-configuration-python-'+version+'-qualified-01.log')
    with log.open('xb') as stream:
        child=subprocess.Popen(command,cwd=R,env=child_env,stdout=stream,stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW)
        record['active_pid']=child.pid;record['active_python']=version;save()
        try:child.wait(timeout=420)
        except BaseException:
            if child.poll() is None:child.kill()
            child.wait(timeout=10)
            record['status']='STOP_REQUIRES_EXACT_DESCENDANT_CENSUS';save();raise
    text=log.read_text(errors='replace')
    step=dict(python=version,command=command,exit_code=child.returncode,log=str(log),log_sha256=sha(log))
    record['steps'].append(step);save()
    assert child.returncode==0,(version,text[-2500:])
    assert re.search(r'Ran 10 tests\b',text) and re.search(r'\nOK\s*$',text) and 'skipped=' not in text
    step['tests']=10;step['skipped']=0;save()
assert 'creation_time_field' in (R/'tests/test_configuration_reconciliation.py').read_text()
save()
try:
    for version in ('3.11','3.14'):run(version)
    assert sha(exe)==record['CLI_sha256']
    assert sha(R/'tests/test_configuration_reconciliation.py')==record['fixed_test_sha256']
    record.update(status='PASS',focused_tests=20,skipped=0,active_pid=None,active_python=None,
        finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
    print(json.dumps(dict(status=record['status'],focused_tests=record['focused_tests'],new_builds=0,
        receipt_sha256=sha(OUT))),flush=True)
except BaseException as error:
    if not record['status'].startswith('STOP_'):record['status']='ACTIONABLE_FAILURE'
    record['error']=repr(error);save();raise
