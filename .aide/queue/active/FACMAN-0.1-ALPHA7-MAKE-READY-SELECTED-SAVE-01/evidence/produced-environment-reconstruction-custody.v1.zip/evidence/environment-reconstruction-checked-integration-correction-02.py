import hashlib,json,os,sys,traceback
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1')
sys.path.insert(0,str(R))
from tools import provider_canary_process as owned
S='544c783ffa6ea0c2e507f866b97d5b3bdd9f0dd5';REPO='Julesc013/factorio-launcher'
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
out=E/'environment-reconstruction-checked-integration-result-02.json';assert not out.exists()
record=dict(status='CONSUMING_COMPLETED_QUALIFICATION',source=S,pr=419,commands=[],new_ci_jobs=0,new_candidates=0,goal_status_mutated=False)
def save():out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
def call(label,args,timeout=90):
 r=owned.command(args,cwd=R,environment=dict(os.environ),timeout=timeout,directory=E/('environment-reconstruction-integration02-'+label),output_limit=2*1024**2,wait_for_job_empty_after_primary=True)
 record['commands'].append(dict(label=label,receipt=str(r.directory/'receipt.json'),sha256=sha(r.directory/'receipt.json'),exit=r.returncode));save()
 assert r.ok and r.receipt['job_empty_observed'] and not r.receipt['job_terminated'],(label,r.stderr[-1600:].decode('utf-8','replace'))
 return r
try:
 original=E/'environment-reconstruction-checked-integration-result-01.json';p=json.loads(original.read_bytes())
 assert p['status']=='ACTIONABLE_OBSERVER_FAILURE' and 'candidate-commit-message-01.txt' in p['error']
 q=json.loads((E/'environment-reconstruction-candidate-commit-result-02.json').read_bytes())
 mac=p['actual_mac_delivered_package_qualification'];win=p['actual_windows_delivered_environment_qualification']
 assert q['source']==S and mac['source']==win['source']==S
 assert mac['compiled_checkout_tree']==q['tree'] and mac['compiled_checkout_parents']==['cb97d8cff22b400dbfdf8a24b9659fbb7adb9605',S]
 assert mac['method_count']==14 and mac['method_skips']==0 and mac['new_environment']['calls']==win['new_environment']['calls']==107
 assert mac['new_environment']['status']==win['new_environment']['status']=='PASS_INDEPENDENT_ENVIRONMENT_CUSTODY'
 assert win['retained_GUI']['status']=='PASS_INDEPENDENT_ACTUAL_GUI_CUSTODY' and win['native_builds_passed']==4 and win['native_tests_per_build']==55
 for proof in (mac,win):assert sha(proof['log_path'])==proof['log_sha256'] and proof['job_conclusion']=='success'
 assert call('identity',['powershell','-NoProfile','-Command','[Security.Principal.WindowsIdentity]::GetCurrent().Name']).stdout.decode().strip().casefold()==r'BLACKGLASS-WIN1\Jules'.casefold()
 view=json.loads(call('pr',['gh','pr','view','419','--repo',REPO,'--json','headRefOid,baseRefName,state,mergeCommit,mergedAt']).stdout)
 assert view['headRefOid']==S and view['baseRefName']=='dev' and view['state'] in ('OPEN','MERGED')
 rows=json.loads(call('checks',['gh','pr','checks','419','--repo',REPO,'--required','--json','name,state,bucket,link']).stdout)
 assert len(rows)>=12 and all(row['state']=='SUCCESS' and row['bucket']=='pass' for row in rows)
 for name,proof in [('windows-native-package',win),('macos-native-cli',mac)]:
  matches=[row for row in rows if row['name']==name]
  assert len(matches)==1 and matches[0]['link'].endswith('/job/'+str(proof['job_id']))
 if view['state']=='OPEN':
  subject,body=(E/'environment-reconstruction-candidate-commit-message-02.txt').read_text(encoding='utf-8').split('\n',1)
  bodyfile=E/'environment-reconstruction-merge-body-02.txt'
  with bodyfile.open('x',encoding='utf-8',newline='\n') as stream:stream.write(body.lstrip('\n'))
  call('merge',['gh','pr','merge','419','--repo',REPO,'--merge','--match-head-commit',S,'--subject',subject,'--body-file',str(bodyfile)],120)
  view=json.loads(call('merged-pr',['gh','pr','view','419','--repo',REPO,'--json','headRefOid,baseRefName,state,mergeCommit,mergedAt']).stdout)
 assert view['state']=='MERGED' and view['headRefOid']==S and view['baseRefName']=='dev'
 record.update(status='merged_exact_source',pr_state=view,required_checks_all_pass=True,consumed_observer_result_sha256=sha(original),actual_mac_delivered_package_qualification=mac,actual_windows_delivered_environment_qualification=win)
except BaseException as error:record.update(status='ACTIONABLE_INTEGRATION_FAILURE',error=str(error),traceback=traceback.format_exc())
finally:
 save();print(json.dumps({key:value for key,value in record.items() if key not in ('commands','traceback','actual_mac_delivered_package_qualification','actual_windows_delivered_environment_qualification')},indent=2))
raise SystemExit(0 if record['status']=='merged_exact_source' else 1)
