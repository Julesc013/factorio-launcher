import base64
import hashlib
import io
import json
import re
import zipfile
import zlib
from pathlib import Path, PurePosixPath

SCENARIOS = (
    'clean_workspace_reconstructs_declared_content_profile_world_and_joined_context',
    'reconstructed_world_context_interruption_recovers_without_reimporting_or_recloning',
    'reconstruction_owners_preserve_foreign_destinations_and_refuse_invalid_inputs',
)
sha = lambda data: hashlib.sha256(data).hexdigest()
norm = lambda value: str(value).replace('\\', '/')

def extract(log_path, expected_source, expected_hashes, platform, output=None, qualification=None, legacy_binding=None):
    text = Path(log_path).read_text(encoding='utf-8', errors='replace')
    records, custodies = {}, {}
    for line in text.splitlines():
        if 'delivered-environment-evidence: ' in line:
            row = json.loads(line.split('delivered-environment-evidence: ', 1)[1])
            assert row['mode'] not in records
            records[row['mode']] = row
        prefix = 'delivered-windows-environment-custody ' if platform == 'windows' else 'delivered-tui-custody: '
        if prefix in line:
            row = json.loads(line.split(prefix, 1)[1])
            if platform != 'windows' and not row['mode'].startswith('environment-'):
                continue
            compressed = base64.b64decode(row['payload_base64'], validate=True)
            assert len(row['payload_base64']) <= 512 * 1024 and sha(compressed) == row['compressed_sha256']
            decoder = zlib.decompressobj()
            canonical = decoder.decompress(compressed, 6 * 1024**2 + 1)
            assert decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail and len(canonical) <= 6 * 1024**2
            assert sha(canonical) == row['canonical_json_sha256']
            content = json.loads(canonical)
            mode = content['receipt']['mode']
            assert mode not in custodies
            custodies[mode] = (row, content)
    assert set(records) == set(custodies) == {'environment-' + value for value in SCENARIOS}
    accepted = []
    if output is not None:
        output = Path(output)
        output.mkdir()
    for index, scenario in enumerate(SCENARIOS):
        mode = 'environment-' + scenario
        record, (custody, content) = records[mode], custodies[mode]
        assert record['result'] == 'pass' and record['custody_canonical_json_sha256'] == custody['canonical_json_sha256']
        assert content['receipt'] == {key: value for key, value in record.items() if key != 'custody_canonical_json_sha256'}
        if platform == 'windows':
            assert custody['schema'] == 'facman.windows_delivered_environment_custody.v1'
            info = record['build_info']
            assert info['profile_id'] == 'windows_legacy_winforms_x64' and info['source_commit'] == expected_source and not info['source_dirty']
            assert info['source_revisions'] == dict(factorio_launcher=expected_source, universal_launcher='5479939ca5cbc9ee0f901608a92012778b4752ae', universal_setup='2749a15b835a6c1c9968598a2b434d85809691ad')
            if qualification is not None:
                assert record['qualification'] == qualification
        else:
            assert custody['schema'] == 'facman.macos_delivered_tui_custody.v1'
            assert record['profile_id'] == 'macos_portable_tui_x64'
            assert record['backend_identity']['compiled_source_revision'] == expected_source
            assert record['consumer_cwd_outside_source'] and record['consumer_overrides_removed'] and record['pathless'] and record['package_readonly']
            assert legacy_binding is not None
            for key in ('backend_identity', 'build_identity', 'build_info_sha256', 'manifest_sha256', 'closure_sha256', 'build_identity_sha256', 'native_candidate_sha256', 'corroborating_cli_observation_sha256'):
                assert record[key] == legacy_binding[key]
        files = {}
        for name, item in content['files'].items():
            assert name == 'calls.json' or re.fullmatch(r'objects/[0-9a-f]{64}|commands/[0-9]{3}/(?:receipt.json|stdout.raw|stderr.raw)', name)
            data = base64.b64decode(item['bytes_base64'], validate=True)
            assert len(data) == item['size_bytes'] and sha(data) == item['sha256']
            if name.startswith('objects/'):
                assert name == 'objects/' + sha(data)
            files[name] = data
        assert sum(map(len, files.values())) <= 4 * 1024**2 and sha(files['calls.json']) == record['calls_sha256']
        effects = json.loads(files['calls.json'])
        assert effects['schema'] == 'facman.delivered_environment_calls.v1' and effects['scenario'] == 'test_' + scenario
        assert effects['source_test_sha256'] in expected_hashes['source'] and effects['adapter_sha256'] in expected_hashes['adapter']
        assert effects['tests_run'] == 1 and not effects['errors'] and not effects['failures'] and not effects['skips']
        assert effects['limits'] == dict(calls=64, seconds=300, raw_cas_bytes=4 * 1024**2)
        assert effects['elapsed_seconds'] < 300 and effects['raw_stream_bytes'] <= 4 * 1024**2
        assert not any(effects[key] for key in ('real_play', 'real_game', 'human'))
        def verify_inventory(inventory):
            for name, item in inventory.items():
                assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
                assert 'sha256' in item, ('unexpected fixture object', name)
                assert len(files['objects/' + item['sha256']]) == item['size_bytes']
        installation = effects['registered_installation']
        assert installation['before'] == installation['after']
        verify_inventory(installation['before'])
        roots = effects['scenario_roots']
        assert len(roots) == 1
        final = roots[0]['inventory']
        verify_inventory(final)
        data = lambda name: files['objects/' + final[name]['sha256']]
        source_prefix, target_prefix = 'source/instances/solver/', 'clean/instances/main/'
        for leaf in ('mods/simple_1.0.0.zip', 'mods/mod-list.json', 'mods/mod-settings.dat', 'saves/world.zip'):
            assert data(source_prefix + leaf) == data(target_prefix + leaf), leaf
        assert target_prefix + 'mods/unselected_1.0.0.zip' not in final and target_prefix + 'saves/unselected.zip' not in final
        provenance = json.loads(data(target_prefix + 'modpack-import.v1.json'))
        assert provenance['offline'] and provenance['source_instance_id'] == 'solver' and provenance['instance_id'] == 'main' and provenance['install_ref'] == 'local'
        pack = data('source/content.zip')
        assert sha(pack) == provenance['archive_sha256'] and len(pack) == provenance['archive_size']
        with zipfile.ZipFile(io.BytesIO(pack)) as archive:
            for leaf, key in (('modset-lock.v1.json', 'source_lock_sha256'), ('modpack-manifest.v1.json', 'source_manifest_sha256')):
                assert archive.read(leaf) == data(target_prefix + leaf) and sha(archive.read(leaf)) == provenance[key]
        lock_bytes = data(target_prefix + 'mods/modset-lock.v1.json')
        lock = json.loads(lock_bytes)
        assert sha(lock_bytes) == provenance['target_lock_sha256'] and lock['instance_id'] == 'main'
        assert next(mod['source'] for mod in lock['mods'] if mod['name'] == 'base') == 'install-data:local'
        assert json.loads(data(target_prefix + 'instance.v1.json'))['profile'] == 'declared'
        sidecar = json.loads(data(target_prefix + 'metadata/save-refs/world.zip.save-ref.v1.json'))
        assert sidecar['save_sha256'] == sha(data(target_prefix + 'saves/world.zip')) and sidecar['modset_lock_sha256'] == sha(lock_bytes) and sidecar['profile_id'] == 'declared'
        carrier = json.loads(data('clean/instances/carrier/instance.v1.json'))
        assert carrier['restored_from_snapshot'] == 'world' and carrier['install_ref'] == 'fixture'
        assert data('clean/instances/carrier/saves/world.zip') == data(target_prefix + 'saves/world.zip')
        calls = effects['calls']
        assert len(calls) == (32, 38, 37)[index]
        refused, injected, unknown, complete = [], 0, 0, 0
        for number, call in enumerate(calls, 1):
            assert norm(call['argv'][0]).endswith('/bin/facman.exe' if platform == 'windows' else '/bin/facman')
            assert call['environment_inputs']['PATH'] == '' and not call['source_backend_provider_overrides'] and not call['stderr']
            for inventory in (call['before'], call['after']):
                verify_inventory(inventory)
            if platform == 'windows':
                raw_receipt = files[f'commands/{number:03}/receipt.json']
                receipt = json.loads(raw_receipt)
                assert receipt == call['owned_command_receipt'] and sha(raw_receipt) == call['owned_command_receipt_sha256']
                assert receipt['termination'] == 'completed' and receipt['primary_stopped'] and receipt['job_empty_observed'] and not receipt['job_terminated']
                assert receipt['command'] == call['argv'] and receipt['exit_code'] == call['exit_code']
                assert receipt['process_identity']['pid'] == call['launch']['pid'] and receipt['process_identity']['creation_ticks'] > 0
                assert call['launch']['created_suspended'] and call['launch']['exact_job_membership_before_resume'] and call['launch']['resume_previous_suspend_count'] == 1
                assert files[f'commands/{number:03}/stdout.raw'].decode('utf-8') == call['stdout'] and files[f'commands/{number:03}/stderr.raw'].decode('utf-8') == call['stderr']
            if call['exit_code'] == 74:
                assert index == 1 and not call['stdout'] and call['environment_inputs']['FACMAN_TEST_SELECTED_CONTEXT_EXIT'] == 'after_publication'
                assert call['argv'][3:6] == ['presentation', 'action', 'readiness.prepare_joined']
                injected += 1
                continue
            document = json.loads(call['stdout'])
            payload = document['payload']
            if call['exit_code'] == 1:
                assert call['before'] == call['after']
                refused.append(payload['refusal']['code'])
            elif call['exit_code'] == 4:
                assert index == 1 and payload['outcome'] == 'outcome_unknown' and call['before'] == call['after']
                unknown += 1
            else:
                assert call['exit_code'] == 0
                if call['argv'][3:6] == ['presentation', 'action', 'readiness.prepare_joined']:
                    assert payload['outcome'] == 'completed'
                    result = payload['action_payload']
                    assert result['continuation'] == 'observe_readiness'
                    if index == 1:
                        assert not result['completed_effects_verified'] and not result['completed_components']
                    else:
                        assert result['completed_effects_verified']
                    allowed = {'instances/main/metadata/save-refs/world.zip.save-ref.v1.json'}
                    allowed.update(name for name in call['after'] if name.startswith('.facman/action-receipts-v2/'))
                    allowed.update('transactions/' + component['transaction_id'] + '.transaction.v1.json' for component in result['completed_components'])
                    assert not set(call['before']) - set(call['after'])
                    for name, item in call['before'].items():
                        if name not in allowed:
                            assert call['after'][name] == item, ('preserved input', name)
                    assert set(call['after']) - set(call['before']) <= allowed
                    assert not any(result[key] for key in ('preparation_complete', 'readiness_complete', 'execution_started', 'permit_issued'))
                    for component in result['completed_components']:
                        name = 'transactions/' + component['transaction_id'] + '.transaction.v1.json'
                        journal = json.loads(files['objects/' + call['after'][name]['sha256']])
                        assert journal['state'] == 'complete' and journal['command_id'] == 'readiness.prepare_selected_save'
                        context = json.loads(journal['operation_context'])
                        assert context['sidecar_text'].encode('utf-8') == data(target_prefix + 'metadata/save-refs/world.zip.save-ref.v1.json')
                    complete += 1
        profiles = [json.loads(call['stdout'])['payload'] for call in calls if call['argv'][3:5] == ['profiles', 'inspect'] and call['exit_code'] == 0]
        assert len(profiles) == 2 and profiles[0]['settings'] == profiles[1]['settings'] and profiles[0]['template_id'] == profiles[1]['template_id']
        bundles = [json.loads(call['stdout'])['payload']['world_bundle'] for call in calls if call['argv'][3:5] == ['snapshots', 'inspect'] and call['exit_code'] == 0]
        assert len(bundles) == 1 and bundles[0]['selected_saves'] == ['world.zip']
        assert bundles[0]['world_files'][0]['sha256'] == sidecar['save_sha256']
        clones = [json.loads(call['stdout'])['payload'] for call in calls if call['argv'][3:5] == ['saves', 'clone'] and call['exit_code'] == 0]
        assert len(clones) == 1 and clones[0]['source_kind'] == 'owned_backup' and clones[0]['source_instance_id'] == 'carrier' and clones[0]['target_instance_id'] == 'main'
        assert clones[0]['sha256'] == sidecar['save_sha256'] and clones[0]['destination_save'] == 'world.zip'
        if index == 1:
            recovered = [call for call in calls if call['argv'][3:6] == ['workspace', 'recovery', 'apply']]
            assert len(recovered) == 2
            for call in recovered:
                payload = json.loads(call['stdout'])['payload']
                assert call['exit_code'] == 0 and payload['transactions'][0]['state'] == 'complete'
                journal_name = 'transactions/' + call['argv'][6] + '.transaction.v1.json'
                journal = json.loads(files['objects/' + call['after'][journal_name]['sha256']])
                assert journal['command_id'] == 'readiness.prepare_selected_save' and journal['state'] == 'complete'
                context = json.loads(journal['operation_context'])
                assert context['sidecar_text'].encode('utf-8') == data(target_prefix + 'metadata/save-refs/world.zip.save-ref.v1.json')
            assert recovered[-1]['before'] == recovered[-1]['after'], 'Repeated complete recovery must be read-only'
        assert (injected, unknown) == ((1, 1) if index == 1 else (0, 0))
        assert complete == (2, 1, 1)[index]
        assert refused[0] == 'snapshot_install_incompatible'
        if index == 2:
            assert refused[1:] == ['persistent_target_exists', 'snapshot_restore_target_exists', 'snapshot_hash_closure_mismatch', 'save_clone_target_exists', 'save_backup_not_found', 'unknown_profile']
            assert data('clean/instances/foreign/user.dat') == b'foreign instance content'
            assert 'clean/instances/main/saves/foreign.zip' in final and 'corrupt-world.zip' in final
        if output is not None:
            folder = output / f'case-{index+1:02}'
            folder.mkdir()
            for name, raw in files.items():
                destination = folder / name
                destination.parent.mkdir(parents=True, exist_ok=True)
                with destination.open('xb') as stream:
                    stream.write(raw)
            (folder / 'result.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
        accepted.append(dict(scenario=scenario, calls=len(calls), refusals=len(refused), injected_owner_exit74=injected, original_semantic_unknown4=unknown, complete_joined_requests=complete, custody_sha256=custody['canonical_json_sha256'], decoded_files=len(files), decoded_bytes=sum(map(len, files.values()))))
    return dict(status='PASS_INDEPENDENT_ENVIRONMENT_CUSTODY', platform=platform, source=expected_source, scenarios=accepted, calls=sum(row['calls'] for row in accepted), real_game=False, human=False, full_make_ready=False, canonical_installed_desktop=False, beta=False, rc=False)
