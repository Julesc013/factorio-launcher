from pathlib import Path
E=Path(__file__).resolve().parent
origin=E/'macos-delivered-pack-checked-observer-01.py'
code=origin.read_text(encoding='utf-8')
changes={
 'e0809f002865906dcaee56455a88761ccad0e56e':'544c783ffa6ea0c2e507f866b97d5b3bdd9f0dd5',
 'e504c5ed6d7366f0cf43df5105ae8ce415a8ffdc':'cb97d8cff22b400dbfdf8a24b9659fbb7adb9605',
 'macos-delivered-pack-log-custody-01.py':'environment-reconstruction-mac-log-custody-01.py',
 'macos-delivered-pack-':'environment-reconstruction-',
 'COMMITTED_REVIEWED_DELIVERED_TUI_CANDIDATE':'COMMITTED_REVIEWED_ENVIRONMENT_RECONSTRUCTION_CANDIDATE',
 'pr=416':'pr=419',"'416'":"'419'",'assert len(actual_records)==9':'assert len(actual_records)==11',
 'environment-reconstruction-candidate-commit-result-01.json':'environment-reconstruction-candidate-commit-result-02.json',
 'environment-reconstruction-candidate-commit-review-01.json':'environment-reconstruction-candidate-commit-review-02.json',
}
for old,new in changes.items():
 assert old in code,old;code=code.replace(old,new)
marker='    import runpy\n'
extra="""    for module,methods in [('test_environment_reconstruction',[
        'test_clean_workspace_reconstructs_declared_content_profile_world_and_joined_context',
        'test_reconstructed_world_context_interruption_recovers_without_reimporting_or_recloning',
        'test_reconstruction_owners_preserve_foreign_destinations_and_refuse_invalid_inputs']),
        ('test_macos_delivered_tui',['test_delivered_environment_clean_reconstruction',
        'test_delivered_environment_interrupted_context_recovery','test_delivered_environment_foreign_and_invalid_inputs'])]:
        cls='EnvironmentReconstructionTests' if module=='test_environment_reconstruction' else 'MacosDeliveredTuiTests'
        for name in methods:
            test_id='tests.'+module+'.'+cls+'.'+name
            lines=[line for line in text.splitlines() if f'{name} ({test_id})' in line]
            assert len(lines)==1 and 'skipped' not in lines[0] and 'ERROR' not in lines[0],('actual environment method',test_id)
    joined_source=[]
    frozen=json.loads((E/'make-ready-joined-frozen-06.json').read_bytes())
    for name in frozen['test_selection']['methods']:
        if name=='test_compiled_ordinary_gui_control_preserves_actual_preparation_receipt':continue
        test_id='tests.test_make_ready_joined.JoinedMakeReadyTests.'+name
        lines=[line for line in text.splitlines() if f'{name} ({test_id})' in line]
        assert len(lines)==1 and re.search(r'\\.\\.\\. ok\\s*$',lines[0]),('retained joined Mac method',test_id)
        joined_source.append(test_id)
    assert len(joined_source)==12
    record['actual_mac_joined_source_methods_passed']=joined_source
"""
assert code.count(marker)==1;code=code.replace(marker,extra+marker,1)
marker='\ntry:\n    ident='
extra="""
def verify_windows(rows):
    import runpy
    windows=[row for row in rows if row['name']=='windows-native-package']
    assert len(windows)==1 and windows[0]['state']=='SUCCESS' and windows[0]['bucket']=='pass'
    run_id,job_id=re.search(r'/actions/runs/(\\d+)/job/(\\d+)',windows[0]['link']).groups()
    job=call('windows-job',['api',f'repos/{REPO}/actions/jobs/{job_id}']);assert job.ok
    j=json.loads(job.stdout);assert str(j['run_id'])==run_id and j['status']=='completed' and j['conclusion']=='success'
    workflow=call('windows-run',['api',f'repos/{REPO}/actions/runs/{run_id}']);assert workflow.ok
    w=json.loads(workflow.stdout);assert w['head_sha']==S and w['event']=='pull_request'
    logs=call('windows-actual-tests',['api',f'repos/{REPO}/actions/jobs/{job_id}/logs'],120);assert logs.ok
    log=E/f'environment-reconstruction-windows-job-{job_id}.log'
    with log.open('xb') as stream:stream.write(logs.stdout)
    text=logs.stdout.decode('utf-8','replace')
    assert text.count('100% tests passed, 0 tests failed out of 55')==4
    method='test_actual_joined_controls_dispatch_production_packaged_backend'
    test_id='tests.test_windows_delivered_joined_gui.WindowsDeliveredJoinedGuiTests.'+method
    lines=[line for line in text.splitlines() if f'{method} ({test_id})' in line]
    assert len(lines)==1 and 'skipped' not in lines[0] and 'ERROR' not in lines[0]
    GUI=runpy.run_path(str(E/'windows-delivered-joined-log-custody-01.py'))['extract'](
        log,S,E/f'environment-reconstruction-windows-GUI-actual-job-{job_id}',
        expected_qualification='factory-produced Windows legacy WinForms portable file closure')
    hashes=runpy.run_path(str(E/'environment-reconstruction-mac-log-custody-01.py'))['source_hashes'](S)
    environment=runpy.run_path(str(E/'environment-reconstruction-log-custody-02.py'))['extract'](
        log,S,hashes,'windows',E/f'environment-reconstruction-windows-environment-actual-job-{job_id}',
        qualification='factory-produced Windows legacy WinForms portable file closure')
    proof=dict(source=S,run_id=int(run_id),job_id=int(job_id),job_conclusion=j['conclusion'],runner_name=j.get('runner_name'),
        log_path=str(log),log_sha256=sha(log),native_builds_passed=4,native_tests_per_build=55,actual_GUI_method=test_id,
        retained_GUI=GUI,new_environment=environment)
    record['actual_windows_delivered_environment_qualification']=proof
    save()
"""
assert code.count(marker)==1;code=code.replace(marker,extra+marker,1)
assert code.count('            verify_mac(rows)')==2
code=code.replace('            verify_mac(rows)','            verify_mac(rows)\n            verify_windows(rows)')
exec(compile(code,str(origin)+'#environment419','exec'))
