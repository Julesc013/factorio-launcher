import hashlib,json,runpy,subprocess
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher')
def source_hashes(source):
 result={}
 for key,name in [('source','tests/test_environment_reconstruction.py'),('adapter','tests/delivered_environment_reconstruction.py')]:
  raw=subprocess.check_output(['git','show',source+':'+name],cwd=R)
  result[key]={hashlib.sha256(raw).hexdigest(),hashlib.sha256(raw.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')).hexdigest()}
 return result
def extract(text,source,evidence_root,job_id):
 E=Path(evidence_root)
 retained=[];legacy=None
 for line in text.splitlines():
  if 'delivered-tui-custody: ' in line:
   row=json.loads(line.split('delivered-tui-custody: ',1)[1])
   if row['mode'].startswith('environment-'):continue
  if 'delivered-environment-evidence: ' in line:continue
  if 'delivered-tui-evidence: ' in line and legacy is None:legacy=json.loads(line.split('delivered-tui-evidence: ',1)[1])
  retained.append(line)
 previous=runpy.run_path(str(E/'make-ready-joined-log-custody-04.py'))['extract']('\n'.join(retained),source,E,job_id)
 reviewed=json.loads((E/'environment-reconstruction-candidate-commit-result-02.json').read_bytes())['source']
 environment=runpy.run_path(str(E/'environment-reconstruction-log-custody-02.py'))['extract'](
  E/f'environment-reconstruction-mac-job-{job_id}.log',source,source_hashes(reviewed),'macos',
  E/f'environment-reconstruction-mac-environment-actual-job-{job_id}',legacy_binding=legacy)
 return dict(method_count=14,method_skips=0,retained_eleven=previous,new_environment=environment,real_game=False,human=False,full_make_ready=False,canonical_installed_desktop=False,beta=False,rc=False)
