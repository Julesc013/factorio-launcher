import hashlib,json,zipfile
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent
Q=R/'.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
original_path=E/'environment-reconstruction-checked-integration-result-01.json'
original=json.loads(original_path.read_bytes())
obs_path=E/'environment-reconstruction-checked-integration-result-02.json';obs=json.loads(obs_path.read_bytes())
assert obs['status']=='merged_exact_source' and obs['required_checks_all_pass'] and obs['pr']==419
assert obs['source']=='544c783ffa6ea0c2e507f866b97d5b3bdd9f0dd5' and obs['pr_state']['mergeCommit']['oid']=='44dcf5b6cf22f20f89020534de72b6fa1e3a14f8'
assert obs['consumed_observer_result_sha256']==sha(original_path)
win=obs['actual_windows_delivered_environment_qualification'];mac=obs['actual_mac_delivered_package_qualification']
assert win['new_environment']['calls']==mac['new_environment']['calls']==107
assert mac['method_count']==14 and mac['method_skips']==0 and mac['compiled_checkout_tree']=='5bc241a1f96dd9faa04171f2fb6497a9afa14b2d'
assert mac['compiled_checkout_parents']==['cb97d8cff22b400dbfdf8a24b9659fbb7adb9605',obs['source']]
assert win['retained_GUI']['actual_GUI_sessions']==2 and win['retained_GUI']['all_owned_jobs_empty']
names={Path(__file__).name,original_path.name,obs_path.name,'environment-reconstruction-checked-integration-correction-02.py',
 'environment-reconstruction-checked-observer-01.py','environment-reconstruction-log-custody-02.py','environment-reconstruction-mac-log-custody-01.py',
 'windows-delivered-joined-log-custody-01.py','make-ready-joined-log-custody-04.py','macos-delivered-pack-log-custody-01.py',
 'macos-delivered-tui-log-custody-02.py','macos-delivered-pack-independent-review-01.json',
 'environment-reconstruction-independent-review-02.json','environment-reconstruction-candidate-commit-result-02.json',
 'environment-reconstruction-candidate-commit-review-02.json','environment-reconstruction-postmerge-dev-sync-result-01.json',
 'environment-reconstruction-retirement-result-01.json',Path(win['log_path']).name,Path(mac['log_path']).name}
legacy=mac['retained_eleven'];pack=legacy['retained_nine']
dirs=[E/f"environment-reconstruction-windows-GUI-actual-job-{win['job_id']}",
 E/f"environment-reconstruction-windows-environment-actual-job-{win['job_id']}",
 E/f"environment-reconstruction-mac-environment-actual-job-{mac['job_id']}",
 Path(legacy['decoded_joined_evidence_directory']),Path(pack['decoded_pack_evidence_directory']),Path(pack['retained_tui']['decoded_evidence_directory'])]
for directory in dirs:
 assert directory.is_dir() and directory.resolve().is_relative_to(E.resolve())
 names.update(path.relative_to(E).as_posix() for path in directory.rglob('*') if path.is_file())
for observation in (original,obs):
 for row in observation['commands']:
  if row['label'] in ('windows-job','windows-run','compiled-checkout','mac-job','mac-run','checks','merged-pr'):
   directory=Path(row['receipt']).parent
   names.update((directory/name).relative_to(E).as_posix() for name in ('receipt.json','stdout.raw','stderr.raw'))
manifest={name:sha(E/name) for name in sorted(names)}
archive=Q/'evidence/produced-environment-reconstruction-custody.v1.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as custody:
 custody.writestr('custody-manifest.json',json.dumps(manifest,indent=2,sort_keys=True)+'\n')
 for name in sorted(manifest):custody.write(E/name,'evidence/'+name)
with zipfile.ZipFile(archive) as custody:
 for name,digest in manifest.items():assert hashlib.sha256(custody.read('evidence/'+name)).hexdigest()==digest
checks_row=next(row for row in obs['commands'] if row['label']=='checks')
checks=json.loads(Path(checks_row['receipt']).with_name('stdout.raw').read_bytes())
assert len(checks)>=12 and all(row['state']=='SUCCESS' and row['bucket']=='pass' for row in checks)
record=dict(schema='facman.delivered_environment_reconstruction_accepted_slice.v1',reviewed_source=obs['source'],integration=obs['pr_state']['mergeCommit']['oid'],pr=419,
 windows_actual=win,mac_actual=mac,new_environment_package_scenarios=6,new_environment_CLI_calls=214,
 exact_content_settings_world_and_declared_profile=True,original_and_rebound_provenance=True,
 original_semantic_unknown_replay_preserved=True,foreign_and_corrupt_inputs_preserved=True,registered_installations_unchanged=True,
 required_checks=checks,required_checks_all_pass=True,observer_sha256=sha(original_path),integration_receipt_sha256=sha(obs_path),
 source_review_sha256=sha(E/'environment-reconstruction-independent-review-02.json'),
 source_only_local_proof_honestly_retained=True,actual_new_head_factory_package_proof=True,retained_Windows_GUI_sessions=2,retained_mac_package_methods=11,
 custody=archive.name,custody_sha256=sha(archive),custody_files=len(manifest),new_roots=0,new_clones=0,new_worktrees=0,native_local_rebuild=False,
 canonical_installed_desktop_owner_dependency='PR404 protected control owner authorization',minimum_or_named_physical_host=False,
 real_game=False,human=False,whole_workunit=False,full_make_ready=False,beta=False,rc=False)
out=Q/'evidence/produced-environment-reconstruction.v1.json'
with out.open('x',encoding='utf-8') as stream:json.dump(record,stream,indent=2);stream.write('\n')
with (Q/'ExecPlan.md').open('a',encoding='utf-8',newline='\n') as stream:
 stream.write('\n### Accepted delivered Windows and Mac declared environment reconstruction\n\nPR419 integrated reviewed544c783f as dev44dcf5b6 after all required checks passed. A single observer waited about98minutes without model polling and independently decoded the actual Windows and Mac package results. Each platform passes all three combined clean-workspace journeys and107ordinary CLI calls, preserving exact selected content/settings/world bytes, declared profile settings, original/rebound locks and source provenance. Compatible snapshot alias registration is explicit. Owner74 interruption recovers the published selected context; the original semantic request remains unknown4, and a fresh request observes the already prepared effect. Six foreign/corrupt/missing-input boundaries plus the missing alias preserve all destination inputs. Complete scenario and unchanged registered installation bytes are in byte/hash custody before cleanup.\n\nThe existing Windows factory is reused after its unchanged real GUI oracle; two sessions and68observed production backend identities still pass. Windows passes55native tests in each of four builds. The existing single Mac factory passes14package methods without skips,57native,41retained owners and12joined source methods. Its synthetic0a1310b4 tree5bc241a1 equals the reviewed source with expected base/source parents. The observer\'s commit-message filename error prevented the first merge action; the correction consumed the successful immutable proof and current exact checks without another candidate or CI run. Normal merge, dev synchronization and exact merged-task ref retirement completed.\n\nThis closes the declared-input structural reconstruction and supported recovery slice on those delivered packages. No runtime/provider/policy change, local native rebuild, root, clone or worktree occurred. Full Make Ready/Play, canonical installed Desktop/PR404 owner control, approved real game/human/minimum/named physical hosts, whole WorkUnit and Beta/RC remain open. Continue existing Linux delivered CLI/TUI distributions from the completed source campaign; do not create another package merely to obtain those bytes.\n\nEvidence: evidence/produced-environment-reconstruction.v1.json and hash-closed custody.\n')
print(json.dumps(dict(status='SEALED_ACCEPTED_WINDOWS_MAC_ENVIRONMENT',receipt_sha256=sha(out),archive_bytes=archive.stat().st_size,package_scenarios=6,CLI_calls=214,new_roots=0)))
