import ast,hashlib,json
from pathlib import Path
E=Path(__file__).resolve().parent
R=Path(r'D:\Projects\Factorio\factorio-launcher')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
before=json.loads((E/'make-ready-joined-frozen-03.json').read_bytes())
after=json.loads((E/'make-ready-joined-frozen-04.json').read_bytes())
old={row['path']:row['sha256'] for row in before['files']}
new={row['path']:row['sha256'] for row in after['files']}
path='tests/test_make_ready_joined.py'
assert old.keys()==new.keys() and {n for n in old if old[n]!=new[n]}=={path}
assert before['root_owned_preserved']==after['root_owned_preserved']
patch=(E/'make-ready-joined-frozen-03.patch').read_text()
segment=patch.split('diff --git a/'+path+' b/'+path+'\n',1)[1].split('\ndiff --git ',1)[0]
assert 'new file mode 100644' in segment
original='\n'.join(line[1:] for line in segment.splitlines() if line.startswith('+') and not line.startswith('+++'))+'\n'
original=original.replace("f'{target.stat().st_dev}:{target.stat().st_ino}'",'file_identity(target)').replace("f'{retained.stat().st_dev}:{retained.stat().st_ino}'",'file_identity(retained)')
def cls(text):
    return ast.dump(next(n for n in ast.parse(text).body if isinstance(n,ast.ClassDef) and n.name=='JoinedMakeReadyTests'),include_attributes=False)
assert cls(original)==cls((R/path).read_text())
origin=E/'make-ready-joined-source-review-01.py'
code=origin.read_text().replace('make-ready-joined-frozen-02.json','make-ready-joined-frozen-04.json').replace('make-ready-joined-independent-review-01.json','make-ready-joined-independent-review-03.json')
extra={'prior_review_sha256':sha(E/'make-ready-joined-independent-review-02.json'),
    'failed_windows_qualification_sha256':sha(E/'make-ready-joined-windows-qualification-04.json'),
    'fixture_oracle_repair':'Independent held-handle Win32 volume serial and file index; existing POSIX identity preserved; all method ASTs identical after only two oracle substitutions',
    'compiled_sources_unchanged_from_successful_freeze03_build':True,
    'changed_from_previous_review':[path]}
code=code.replace('OUT.write_text(', 'record.update('+repr(extra)+')\nOUT.write_text(',1)
exec(compile(code,str(origin)+'#freeze04-reviewed','exec'))
