import ast,hashlib,json
from pathlib import Path
E=Path(__file__).resolve().parent
R=Path(r'D:\Projects\Factorio\factorio-launcher')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
before=json.loads((E/'make-ready-joined-frozen-04.json').read_bytes())
after=json.loads((E/'make-ready-joined-frozen-05.json').read_bytes())
old={row['path']:row['sha256'] for row in before['files']}
new={row['path']:row['sha256'] for row in after['files']}
delta={'apps/gui/windows/winforms/PresentationModels.cs','tests/test_make_ready_joined.py','tests/winforms_control_gallery/SelectedSaveHarness.cs'}
assert old.keys()==new.keys() and {n for n in old if old[n]!=new[n]}==delta
assert before['root_owned_preserved']==after['root_owned_preserved']
path='tests/test_make_ready_joined.py'
patch=(E/'make-ready-joined-frozen-04.patch').read_text()
segment=patch.split('diff --git a/'+path+' b/'+path+'\n',1)[1].split('\ndiff --git ',1)[0]
assert 'new file mode 100644' in segment
original='\n'.join(line[1:] for line in segment.splitlines() if line.startswith('+') and not line.startswith('+++'))+'\n'
def methods(text):
    node=next(n for n in ast.parse(text).body if isinstance(n,ast.ClassDef) and n.name=='JoinedMakeReadyTests')
    return {n.name:ast.dump(n,include_attributes=False) for n in node.body if isinstance(n,ast.FunctionDef)}
prior_methods=methods(original)
current_methods=methods((R/path).read_text())
gui='test_compiled_ordinary_gui_control_preserves_actual_preparation_receipt'
assert prior_methods.keys()==current_methods.keys()
assert {n for n in prior_methods if prior_methods[n]!=current_methods[n]}=={gui}
log=(E/'make-ready-joined-win05-joined/stderr.raw').read_text()
passed=[name for name in after['test_selection']['methods'] if name!=gui]
assert len(passed)==12 and 'Ran 13 tests' in log and 'FAILED (failures=1)' in log
for name in passed: assert name+' (test_make_ready_joined.JoinedMakeReadyTests.'+name+') ... ok' in log
calls=json.loads((E/'make-ready-joined-gui05-corrected-calls.json').read_bytes())
assert len(calls)==3 and all(call['exit_code']==0 and not call['stderr'] for call in calls)
assert 'Build succeeded.' in calls[0]['stdout']
assert 'PASS fixed selected save control' in calls[1]['stdout']
assert 'PASS 21 terminal continuation and adversarial uncertainty cases' in calls[2]['stdout']
result=json.loads((E/'make-ready-joined-gui05-corrected-result.log').read_bytes())
assert result==dict(tests=1,errors=[],failures=[],calls=3)
bundle=json.loads((E/'make-ready-joined-gui05-corrected-corpus.json').read_bytes())
assert len(bundle['cases'])==21
assert [c['expected_clear'] for c in bundle['cases']]==[True]+[False]*20
ledger_map=json.loads((E/'make-ready-joined-gui05-corrected-corpus-ledgers.json').read_bytes())
assert len(ledger_map)==1
ledger=json.loads(next(iter(ledger_map.values())))
positive=bundle['cases'][0]
envelope=json.loads(positive['envelope'])
assert ledger['state']=='terminal' and envelope['payload']==json.loads(ledger['result_json'])
assert positive['input']==json.loads(ledger['request_json'])
assert ledger['request_id']==bundle['request_id']==envelope['request_id']
payload=envelope['payload']['action_payload']
assert payload['continuation']=='fresh_request_after_input_correction'
assert payload['completed_effects_verified'] and payload['remaining_effects_blocked_before_effects']
assert len(payload['completed_components'])==1 and not payload['permit_issued'] and not payload['execution_started']
origin=E/'make-ready-joined-source-review-01.py'
code=origin.read_text().replace('make-ready-joined-frozen-02.json','make-ready-joined-frozen-05.json').replace('make-ready-joined-independent-review-01.json','make-ready-joined-independent-review-04.json')
code=code.replace('The GUI corpus retains 17 adversarial cases.','The GUI corpus retains the original 17 cases and four additional foreign/device target cases, 21 total.')
extra=dict(prior_review_sha256=sha(E/'make-ready-joined-independent-review-03.json'),
    current_guard_delta='Ordinal Windows separator equivalence only; reject device namespaces including slash variants; preserve every other proof predicate',
    compiled_runtime_unchanged_from_successful_freeze03_build=True,
    retained_windows_runtime_methods_passed=passed,retained_windows_runtime_log_sha256=sha(E/'make-ready-joined-win05-joined/stderr.raw'),
    corrected_compiled_GUI_method_passed=True,GUI_continuation_cases=21,
    corrected_GUI_calls_sha256=sha(E/'make-ready-joined-gui05-corrected-calls.json'),
    actual_terminal_ledger_sha256=sha(E/'make-ready-joined-gui05-corrected-corpus-ledgers.json'),
    corrected_GUI_corpus_sha256=sha(E/'make-ready-joined-gui05-corrected-corpus.json'),
    changed_from_previous_review=sorted(delta),local_setup_fixture_path_refusals_retained=True,required_CI_unchanged=True)
code=code.replace('OUT.write_text(', 'record.update('+repr(extra)+')\nOUT.write_text(',1)
exec(compile(code,str(origin)+'#freeze05-reviewed','exec'))
