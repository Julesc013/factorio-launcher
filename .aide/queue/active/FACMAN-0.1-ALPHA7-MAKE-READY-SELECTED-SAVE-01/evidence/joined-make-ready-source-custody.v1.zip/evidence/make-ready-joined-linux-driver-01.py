import hashlib,json,os,signal,subprocess,traceback
from pathlib import Path
R=Path('/mnt/d/Projects/Factorio/factorio-launcher')
E=Path(__file__).resolve().parent
W=E.parent
L=W/'native-save-context-linux'
M=E/'posix-publication-private-fixtures-01'
F=E/'make-ready-joined-frozen-05.json'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert os.getpid()==1 and os.getuid()==0
assert os.readlink('/proc/self/ns/mnt')!=os.environ['FACMAN_PARENT_MOUNT_NAMESPACE']
os.environ.update(GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.autocrlf',GIT_CONFIG_VALUE_0='true',PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='0',
    TMPDIR=str(W/'t'),TMP=str(W/'t'),TEMP=str(W/'t'),FACMAN_DEV_ROOT='/mnt/d/Projects/Factorio/.task-builds',CMAKE_BUILD_PARALLEL_LEVEL='2')
f=json.loads(F.read_bytes())
out=E/'make-ready-joined-linux-result-01.json'
assert not out.exists()
record=dict(status='RUNNING_FRESH_LINUX_JOINED_BUILD',source_base=f['base'],source_tree=f['tree'],frozen_packet_sha256=sha(F),commands=[],parallel=2,
    new_roots=0,new_clones=0,new_worktrees=0,new_candidates=0,private_tmpfs=True,physical_ext4=False,macos=False,real_game=False,human=False,beta=False,rc=False)
def save(): out.write_text(json.dumps(record,indent=2)+'\n')
def guard():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==f['base']
    for item in f['files']+f['root_owned_preserved']: assert sha(R/item['path'])==item['sha256'],item['path']
def run(label,args,timeout=600,env=None):
    guard()
    stdout=E/('make-ready-joined-linux01-'+label+'.stdout')
    stderr=E/('make-ready-joined-linux01-'+label+'.stderr')
    with stdout.open('xb') as o,stderr.open('xb') as er:
        child=subprocess.Popen([str(x) for x in args],cwd=R,env=env,stdout=o,stderr=er,start_new_session=True)
        timed=False
        try: code=child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed=True;os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=30)
    record['commands'].append(dict(label=label,argv=[str(x) for x in args],exit_code=code,execution_limit_exceeded=timed,stdout_sha256=sha(stdout),stderr_sha256=sha(stderr)))
    save()
    assert code==0 and not timed,(label,code,str(stderr))
    guard()
    return stdout
mounted=False
shadow=False
try:
    guard()
    ulk=W/'providers/universal-launcher-5479939ca5cb'
    usk=W.parent/'task-facman-u-507ecf4b41/providers/universal-setup-2749a15b835a'
    for root,pin in ((ulk,'5479939ca5cbc9ee0f901608a92012778b4752ae'),(usk,'2749a15b835a6c1c9968598a2b434d85809691ad')):
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==pin
        assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=root,text=True).strip()
    run('configure',['cmake','-S',R,'-B',L,'-G','Ninja','-DCMAKE_BUILD_TYPE=Debug','-DFACMAN_BUILD_TESTS=ON','-DFACMAN_BUILD_TUI=ON',
        '-DFACMAN_PROVIDER_SOURCE_LINKAGE=static','-DFACMAN_WARNINGS_AS_ERRORS=ON','-DFACMAN_PROVIDER_MODE=source',
        '-DFACMAN_PROVIDER_LOCK_FILE='+str(R/'release/index/workspace_lock.v1.toml'),'-DFLAUNCH_UNIVERSAL_LAUNCHER_ROOT='+str(ulk),'-DFLAUNCH_UNIVERSAL_SETUP_ROOT='+str(usk)],600)
    targets=['facman_presentation_service_smoke','flb_factorio_instance_model_smoke','facman_tui_smoke','facman_terminal_capabilities_smoke',
        'facman_tui_product_model_smoke','facman_frontend_session_smoke','facman_client_smoke','fl_transaction_session_smoke',
        'fl_platform_io_smoke','fl_retained_rewrite_smoke','fl_archive_core_smoke']
    run('build',['cmake','--build',L,'--parallel','2','--target','facman_cli',*targets],3600)
    record['cli_sha256']=sha(L/'facman')
    assert M.is_dir() and not M.is_symlink() and not list(M.iterdir()) and not os.path.ismount(M)
    subprocess.run(['mount','-t','tmpfs','-o','size=128m,nosuid,nodev,mode=1777','facman-joined-ready',M],check=True,timeout=30)
    mounted=True
    assert os.statvfs(M).f_blocks*os.statvfs(M).f_frsize==128*1024**2
    parent=L/'tests/native'
    assert parent.is_dir() and not parent.is_symlink()
    config=(parent/'CTestTestfile.cmake').read_bytes()
    record['native_ctest_config_sha256']=hashlib.sha256(config).hexdigest()
    temporary=M/'native'
    temporary.mkdir(mode=0o777);temporary.chmod(0o777)
    (temporary/'CTestTestfile.cmake').write_bytes(config)
    subprocess.run(['mount','--bind',temporary,parent],check=True,timeout=30);shadow=True
    env=dict(os.environ,TMPDIR=str(M),TMP=str(M),TEMP=str(M),FACMAN_CLI_EXE=str(L/'facman'),FACMAN_TUI_EXE=str(L/'facman'),
        PYTHONPATH=str(W/'validators-linux')+':'+str(R)+':'+str(R/'tests'))
    privilege=['setpriv','--reuid=65534','--regid=65534','--clear-groups']
    native=run('native',[*privilege,'ctest','--test-dir',L,'-R','^('+'|'.join(targets)+')$','--output-on-failure'],1200,env)
    assert f'100% tests passed, 0 tests failed out of {len(targets)}' in native.read_text() and 'Skipped' not in native.read_text()
    record['native_tests']=len(targets)
    run('owners',[*privilege,'python3','-B',E/'make-ready-joined-linux-worker-01.py'],3600,env)
    owners_path=E/'make-ready-joined-linux-owner-result-01.json'
    owners=json.loads(owners_path.read_bytes())
    assert owners['status']=='PASS_UNPRIVILEGED_LINUX_JOINED_AND_LEGACY_SOURCE'
    assert owners['cli_sha256']==record['cli_sha256']
    record.update(status='PASS_FRESH_LINUX_JOINED_AND_LEGACY_SOURCE',owners=owners,owners_sha256=sha(owners_path))
except BaseException as error:
    record.update(status='ACTIONABLE_LINUX_JOINED_QUALIFICATION_FAILURE',error=str(error),traceback=traceback.format_exc())
finally:
    if mounted and list(M.iterdir()):
        archive=E/'make-ready-joined-linux-fixture-custody-01.tar'
        subprocess.run(['tar','-cf',archive,'-C',M,'.'],check=True,timeout=90)
        record['fixture_custody_sha256']=sha(archive)
    record['reaped_terminal_namespace_children']=[]
    for path in Path('/proc').iterdir():
        if path.name.isdigit() and path.name!='1':
            try:
                fields={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in (path/'status').read_text().splitlines() if ':' in line}
                if fields.get('PPid')=='1' and fields.get('State','').startswith('Z'):
                    waited,status=os.waitpid(int(path.name),os.WNOHANG)
                    assert waited==int(path.name)
                    record['reaped_terminal_namespace_children'].append(dict(pid=waited,status=status))
            except FileNotFoundError: pass
    if shadow: subprocess.run(['umount',L/'tests/native'],check=True,timeout=30)
    if mounted: subprocess.run(['umount',M],check=True,timeout=30)
    record['private_mount_absent']=not os.path.ismount(M)
    record['native_parent_unmounted']=not os.path.ismount(L/'tests/native')
    record['remaining_namespace_pids']=[int(p.name) for p in Path('/proc').iterdir() if p.name.isdigit() and p.name!='1']
    if record['remaining_namespace_pids']: record['status']='ACTIONABLE_LINUX_OWNED_DESCENDANT_REMAINS'
    guard();save()
    print(json.dumps({k:v for k,v in record.items() if k not in ('commands','traceback')},indent=2),flush=True)
raise SystemExit(0 if record['status'].startswith('PASS_') else 1)
