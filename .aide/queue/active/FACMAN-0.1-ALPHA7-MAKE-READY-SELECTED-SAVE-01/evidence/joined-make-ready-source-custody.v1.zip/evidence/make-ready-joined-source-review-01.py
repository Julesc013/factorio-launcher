import ast, hashlib, json, os, subprocess
from pathlib import Path

R=Path(r'D:\Projects\Factorio\factorio-launcher')
E=Path(__file__).resolve().parent
F=E/'make-ready-joined-frozen-02.json'
OUT=E/'make-ready-joined-independent-review-01.json'
os.environ.update(GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.safecrlf',GIT_CONFIG_VALUE_0='false')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
assert not OUT.exists()
f=json.loads(F.read_bytes())
assert git('rev-parse','HEAD')==f['base'] and git('branch','--show-current')==f['branch']
assert not git('diff','--cached','--name-only')
rows=f['files']+f['root_owned_preserved']
paths=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
assert paths=={item['path'] for item in rows}
for item in rows:
    assert sha(R/item['path'])==item['sha256'],item['path']
    assert git('hash-object','--path',item['path'],str(R/item['path']))==item['git_blob'],item['path']
assert sha(f['patch']['path'])==f['patch']['sha256']
for item in f['logs']: assert sha(item['path'])==item['sha256'],item['path']
protected=[
    'contracts/schema/factorio/factorio_make_ready_preparation_result.v1.schema.json',
    'contracts/schema/presentation/presentation_action_receipt.v2.schema.json',
    'contracts/schema/presentation/semantic_action_input.v1.schema.json',
    'release/index/workspace_lock.v1.toml',
    'tests/test_make_ready_preparation.py','tests/test_configuration_preparation.py',
    'tests/test_configuration_reconciliation.py','tests/test_selected_save_preparation.py',
    'tests/test_presentation_profile_preparation.py','tests/test_profiles_templates.py',
    'tests/test_tui_product.py','tests/test_portable_modpack_import.py','tests/test_presentation_pack_import.py']
for path in protected:
    assert git('hash-object','--path',path,str(R/path))==git('rev-parse',f['base']+':'+path),path
def old(path): return subprocess.check_output(['git','show',f['base']+':'+path],cwd=R,text=True)
service=(R/'runtime/factorio/application/presentation_service.cpp').read_text()
original=old('runtime/factorio/application/presentation_service.cpp')
begin='    } else if (request.action_id == "readiness.prepare") {'
end='    } else if (request.action_id == "configuration.explain_effective" &&'
assert original[original.index(begin):original.index(end)]==service[service.index(begin):service.index(end)]
begin='    facman::platform::PathIdentity identity;'
end='    return replace_action_receipt(path, receipt, detail);'
oldpos=original.index('bool PresentationActionLedger::remember(')
newpos=service.index('bool PresentationActionLedger::replace_accepted(')
assert original[original.index(begin,oldpos):original.index(end,oldpos)+len(end)]==service[service.index(begin,newpos):service.index(end,newpos)+len(end)]
def members(text):
    node=next(n for n in ast.parse(text).body if isinstance(n,ast.ClassDef) and n.name=='MacosDeliveredTuiTests')
    return {n.name:ast.dump(n,include_attributes=False) for n in node.body if isinstance(n,ast.FunctionDef)}
old_members=members(old('tests/test_macos_delivered_tui.py'))
new_source=(R/'tests/test_macos_delivered_tui.py').read_text()
new_members=members(new_source)
original_methods=[name for name in old_members if name.startswith('test_')]
assert len(original_methods)==9
for name in [*original_methods,'setUpClass','exercise_delivered','exercise_delivered_pack']:
    assert old_members[name]==new_members[name],name
assert new_source.count('package_build.build_profile(')==1
store=(R/'apps/gui/windows/winforms/C1LivePresentationStore.cs').read_text()
entry=store[store.index('private async Task<CommandResult> ExecuteActionAsync('):store.index('private async Task<CommandResult> DispatchActionAsync(')]
assert entry.index('LastActionSummary = String.Empty;') < entry.index('BackendPresentationSnapshot source')
record=dict(schema='facman.independent_joined_make_ready_source_review.v1',
    verdict='PASS_FOR_SCOPED_NATIVE_AND_REQUIRED_CANDIDATE',reviewer='/root',
    implementation_author='/root/make_ready_joined_implementation',non_authoring=True,
    base_head=f['base'],authored_tree=f['authored_tree'],source_tree=f['tree'],
    frozen_packet_sha256=sha(F),files_sha256={item['path']:item['sha256'] for item in rows},
    protected_git_blobs_unchanged=protected,legacy_owner_dispatch_body_unchanged=True,
    accepted_receipt_validation_body_unchanged=True,original_macos_package_methods_unchanged=original_methods,
    single_macos_package_factory=True,findings=[
        'Separate typed joined action preserves the partial v1 action and strict durable receipt v2; explicit current instance/install/profile/save and internally bound locked content avoid hash-entry product flows.',
        'Read-only planning verifies prerequisites and retained input identities; each owner retains its existing journal, while fresh observation rechecks unchanged inputs and exact completed operation/attempt/target/parent/inode/bytes.',
        'The accepted request is durable before effects; actual component receipts checkpoint unknown outer state. Exact replay observes rather than redispatches, and failed final persistence exposes no clearing directive.',
        'Partial completion never erases applied effects or invents rollback. Only independently verified completed effects and a refusal before further effects admit a fresh request; foreign same-byte objects, changed parents and unknown owner outcomes retain inspection.',
        'Production GUI clearing requires exact terminal transport and semantic identities, versioned shapes, actual completed component bindings and strict proof booleans. Root found stale per-action guidance; the corrected store clears it before local admission/replay and compiled regression covers joined and unrelated local refusals.',
        'Native focused tests cover positive routing/world preparation, missing prerequisites, stale/foreign input, concurrent replay, actual process loss, domain recovery, terminal receipt persistence failure and post-observation effect replacement. The GUI corpus retains 17 adversarial cases.',
        'Two delivered Mac scenarios reuse the relocated read-only package and existing bounded call/CAS custody; original nine methods and staging/PTY acceptance bodies remain AST-identical.',
        'Completion follows independent owner readiness states; no fixture, composed request or GUI feedback grants whole readiness, Play, real-host, human, Beta or RC authority.'
    ],authority_delta='none',native_qualification_pending=True,required_checks_pending=True,
    produced_new_joined_package_pending=True,real_game=False,human=False,minimum_mac13_host=False,
    canonical_installed_desktop=False,whole_workunit_closed=False,beta=False,rc=False)
OUT.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(verdict=record['verdict'],review_sha256=sha(OUT),paths=len(paths),
    native_pending=True,package_pending=True)))
