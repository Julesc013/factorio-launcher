import ast,hashlib,importlib.metadata,json,os,sys,unittest
from pathlib import Path
R=Path('/mnt/d/Projects/Factorio/factorio-launcher')
E=Path(__file__).resolve().parent
assert os.getuid()==65534 and os.getgid()==65534 and os.getgroups()==[]
assert os.environ['TMPDIR']==str(E/'posix-publication-private-fixtures-01')
sys.path[:0]=[str(R),str(R/'tests')]
expected={line.split('==')[0]:line.split('==')[1] for line in (R/'tools/requirements-dev.lock').read_text().splitlines() if '==' in line}
versions={name:importlib.metadata.version(name) for name in expected}
assert versions==expected
groups={
 'joined': [('test_make_ready_joined','JoinedMakeReadyTests',{'test_compiled_ordinary_gui_control_preserves_actual_preparation_receipt'})],
 'legacy': [
  ('test_configuration_preparation','ConfigurationPreparationTests',{'test_final_observation_holds_exact_published_target_against_replacement_and_write','test_compiled_fixed_control_dispatches_ordinary_owner_and_keeps_captured_intent'}),
  ('test_selected_save_preparation','SelectedSavePreparationTests',{'test_finalization_retains_pinned_target_against_same_byte_replacement_and_write','test_compiled_fixed_control_preserves_selected_intent_and_uncertain_request'}),
  ('test_posix_preparation_publication','PosixPreparationPublicationTests',{'test_darwin_actual_sigkill_and_recovery_loss_preserve_bound_effect_and_unknown_request','test_darwin_live_recovery_lock_contention_preserves_exact_published_pair'}),
  ('test_posix_retained_rewrite_admission','PosixRetainedRewriteAdmissionTests',set()),
  ('test_presentation_profile_preparation','PresentationProfilePreparationTests',set()),
  ('test_profiles_templates','ProfileTemplateTests',set()),
  ('test_tui_product','TuiProductTests',{'test_ordinary_selected_save_preparation_and_changed_observation_confirmation'})]
}
record=dict(status='RUNNING_UNPRIVILEGED_LINUX_JOINED_SOURCE',groups={},uid=os.getuid(),gid=os.getgid(),groups_privilege=os.getgroups(),locked_validators=versions,
    cli_sha256=hashlib.sha256(Path(os.environ['FACMAN_CLI_EXE']).read_bytes()).hexdigest(),
    physical_ext4=False,macos=False,real_game=False,human=False,produced_package=False,beta=False,rc=False)
out=E/'make-ready-joined-linux-owner-result-01.json'
assert not out.exists()
ok=True
for group,classes in groups.items():
    names=[]
    for module,cls,excluded in classes:
        node=next(n for n in ast.parse((R/'tests'/f'{module}.py').read_text()).body if isinstance(n,ast.ClassDef) and n.name==cls)
        names += [module+'.'+cls+'.'+n.name for n in node.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_') and n.name not in excluded]
    suite=unittest.defaultTestLoader.loadTestsFromNames(names)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    passed=result.wasSuccessful() and result.testsRun==len(names) and not result.skipped
    record['groups'][group]=dict(methods=result.testsRun,expected=len(names),failures=len(result.failures),errors=len(result.errors),skips=[(str(t),s) for t,s in result.skipped],passed=passed)
    ok &= passed
    out.write_text(json.dumps(record,indent=2)+'\n')
    if not passed: break
record['status']='PASS_UNPRIVILEGED_LINUX_JOINED_AND_LEGACY_SOURCE' if ok else 'ACTIONABLE_LINUX_JOINED_OWNER_FAILURE'
out.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
raise SystemExit(0 if ok else 1)
