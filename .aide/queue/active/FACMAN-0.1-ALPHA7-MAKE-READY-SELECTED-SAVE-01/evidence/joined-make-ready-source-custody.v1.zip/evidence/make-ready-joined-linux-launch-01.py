import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher')
E=Path(__file__).resolve().parent
W=E.parent
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',CMAKE_BUILD_PARALLEL_LEVEL='2')
sys.path.insert(0,str(R))
from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
out=E/'make-ready-joined-linux-launch-result-01.json'
assert not out.exists()
record=dict(status='RESOURCE_AND_FOREIGN_OWNER_PREFLIGHT',commands=[],new_roots=0,new_clones=0,new_worktrees=0,healthy_model_poll_calls=0)
def save(): out.write_text(json.dumps(record,indent=2)+'\n')
def command(label,args,timeout):
    result=owned.command(args,cwd=R,environment=dict(os.environ),timeout=timeout,directory=E/('make-ready-joined-linux-launch01-'+label),output_limit=16*1024*1024)
    record['commands'].append(dict(label=label,exit_code=result.returncode,receipt_sha256=sha(result.directory/'receipt.json'),primary_stopped=result.receipt['primary_stopped'],job_empty=result.receipt['job_empty_observed']))
    save()
    assert result.receipt['primary_stopped'] and result.receipt['job_empty_observed']
    return result
windows_query="@(Get-CimInstance Win32_Process | Where-Object { ($_.Name -match '^(cmake|MSBuild|cl|link|ninja|ctest)\\.exe$' -and $_.CommandLine -notmatch '[-/]nodemode:') -or ($_.Name -eq 'dotnet.exe' -and $_.CommandLine -match ' (build|msbuild) ') } | Select-Object ProcessId,Name,CreationDate) | ConvertTo-Json -Compress"
linux_probe="""import json,os
from pathlib import Path
names={'cmake','ninja','gcc','g++','c++','cc','cc1plus','clang','clang++','ld','ctest'}
active=[]
for path in Path('/proc').iterdir():
 if path.name.isdigit():
  try:
   name=(path/'comm').read_text().strip()
   if name in names: active.append(dict(pid=int(path.name),name=name))
  except FileNotFoundError: pass
print(json.dumps(dict(mount_namespace=os.readlink('/proc/self/ns/mnt'),active=active)))
"""
try:
    review=json.loads((E/'make-ready-joined-independent-review-04.json').read_bytes())
    assert review['verdict']=='PASS_FOR_SCOPED_NATIVE_AND_REQUIRED_CANDIDATE' and review['non_authoring']
    assert review['frozen_packet_sha256']==sha(E/'make-ready-joined-frozen-05.json')
    assert json.loads((E/'make-ready-joined-windows-qualification-06.json').read_bytes())['status'].startswith('PASS_')
    assert command('paths',['py','-3','-B','tools/workspace_hygiene.py','paths'],180).ok
    measured=command('doctor',['py','-3','-B','tools/workspace_hygiene.py','doctor','--measure'],600)
    assert measured.returncode in (0,1)
    doctor=json.loads(measured.stdout)
    assert set(doctor['violations'])<={'unmanaged_secondary_worktrees_present'}
    assert len(doctor['task_roots'])<=8 and not doctor['in_tree_output_roots']
    assert doctor['task_root_bytes']+2*1024**3<=20*1024**3
    record['resources']=dict(task_roots=len(doctor['task_roots']),bytes=doctor['task_root_bytes'],reserved_peak_bytes=2*1024**3,retained_findings=doctor['violations'])
    interval=10
    previous=None
    while True:
        win=json.loads(subprocess.check_output(['powershell','-NoProfile','-Command',windows_query],text=True,timeout=30).strip() or '[]')
        linux=json.loads(subprocess.check_output(['wsl','-d','Ubuntu-24.04','-u','root','--','python3','-B','-c',linux_probe],text=True,timeout=45))
        active=dict(windows=win,linux=linux['active'])
        assert shutil.disk_usage(W).free>=14*1024**3
        if not win and not linux['active']: break
        if active!=previous:
            record.setdefault('preserved_foreign_heavy_jobs',[]).append(active);save();previous=active
        time.sleep(interval);interval=min(120,interval*2)
    linux_e='/mnt/d/'+str(E)[3:].replace('\\','/')
    args=['wsl','-d','Ubuntu-24.04','-u','root','--','env','FACMAN_PARENT_MOUNT_NAMESPACE='+linux['mount_namespace'],
        'timeout','--signal=TERM','--kill-after=15s','7100s','unshare','--mount','--pid','--fork','--mount-proc','--kill-child=SIGKILL',
        'python3','-B',linux_e+'/make-ready-joined-linux-driver-01.py']
    record['status']='RUNNING_SINGLE_OWNED_PRIVATE_NAMESPACE_LINUX_CAMPAIGN';save()
    result=command('campaign',args,7200)
    proof=E/'make-ready-joined-linux-result-01.json'
    passed=result.ok and proof.exists() and json.loads(proof.read_bytes())['status']=='PASS_FRESH_LINUX_JOINED_AND_LEGACY_SOURCE'
    record.update(status='PASS_SINGLE_LINUX_JOINED_CAMPAIGN' if passed else 'ACTIONABLE_LINUX_JOINED_CAMPAIGN_FAILURE',
        result_sha256=sha(proof) if proof.exists() else None,
        failure_excerpt=None if passed else (result.stdout[-4000:]+result.stderr[-3000:]).decode(errors='replace'))
except BaseException as error:
    record.update(status='ACTIONABLE_LINUX_JOINED_LAUNCH_FAILURE',error=str(error))
finally:
    save();print(json.dumps({k:v for k,v in record.items() if k not in ('commands','preserved_foreign_heavy_jobs')},indent=2),flush=True)
raise SystemExit(0 if record['status'].startswith('PASS_') else 1)
