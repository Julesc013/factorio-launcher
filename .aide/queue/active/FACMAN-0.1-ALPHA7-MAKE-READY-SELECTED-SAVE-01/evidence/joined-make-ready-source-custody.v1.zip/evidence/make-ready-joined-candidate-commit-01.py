import ast,hashlib,json,os,subprocess,sys,traceback,zipfile
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher')
E=Path(__file__).resolve().parent
W=E.parent
BASE='dff35d6bbc38a1b3f05e1bc1d79b6a5c6b5b91bc'
BRANCH='task/facman-make-ready-joined-01'
Q='.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',
    GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.safecrlf',GIT_CONFIG_VALUE_0='false')
sys.path[:0]=[str(R),str(R/'.aide/scripts')]
from tools import provider_canary_process as owned
import aide_lite
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
out=E/'make-ready-joined-candidate-commit-result-01.json'
assert not out.exists()
record=dict(status='SEALING_QUALIFIED_JOINED_CANDIDATE',commands=[],new_roots=0,new_clones=0,new_worktrees=0,new_optional_campaigns=0,goal_status_mutated=False)
def save():out.write_text(json.dumps(record,indent=2)+'\n')
def run(label,args,timeout=180):
    result=owned.command(args,cwd=R,environment=dict(os.environ),timeout=timeout,directory=E/('make-ready-joined-commit01-'+label),output_limit=8*1024*1024)
    record['commands'].append(dict(label=label,exit_code=result.returncode,receipt_sha256=sha(result.directory/'receipt.json')));save()
    assert result.ok and result.receipt['primary_stopped'] and result.receipt['job_empty_observed'],(label,(result.stdout[-1500:]+result.stderr[-2000:]).decode(errors='replace'))
    return result
try:
    assert git('rev-parse','HEAD')==BASE and git('branch','--show-current')==BRANCH and not git('diff','--cached','--name-only')
    frozen=E/'make-ready-joined-frozen-05.json'
    f=json.loads(frozen.read_bytes())
    review=E/'make-ready-joined-independent-review-04.json'
    v=json.loads(review.read_bytes())
    assert v['verdict']=='PASS_FOR_SCOPED_NATIVE_AND_REQUIRED_CANDIDATE' and v['non_authoring'] and v['frozen_packet_sha256']==sha(frozen)
    initial=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
    assert initial=={row['path'] for row in f['files']+f['root_owned_preserved']}
    for row in f['files']+f['root_owned_preserved']:assert sha(R/row['path'])==row['sha256'],row['path']
    win=E/'make-ready-joined-windows-qualification-06.json'
    linux=E/'make-ready-joined-linux-result-01.json'
    w=json.loads(win.read_bytes());l=json.loads(linux.read_bytes())
    assert w['status'].startswith('PASS_') and w['frozen_packet_sha256']==sha(frozen) and w['independent_review_sha256']==sha(review)
    assert w['joined']['methods']==13 and w['legacy-regression']==dict(methods=72,skips=0) and w['GUI_continuation_cases']==21
    assert l['status']=='PASS_FRESH_LINUX_JOINED_AND_LEGACY_SOURCE' and l['frozen_packet_sha256']==sha(frozen)
    assert l['native_tests']==11 and l['private_mount_absent'] and l['native_parent_unmounted'] and not l['remaining_namespace_pids']
    assert l['owners']['groups']['joined']['methods']==12 and l['owners']['groups']['legacy']['methods']==58
    evidence=R/Q/'evidence/joined-make-ready-source.v1.json'
    archive=R/Q/'evidence/joined-make-ready-source-custody.v1.zip'
    assert not evidence.exists() and not archive.exists()
    names={Path(__file__).name,review.name,win.name,linux.name,'make-ready-joined-linux-owner-result-01.json','make-ready-joined-linux-launch-result-01.json','make-ready-joined-native-path-retry-01.json',
        'make-ready-joined-source-review-01.py','make-ready-joined-source-review-02.py','make-ready-joined-source-review-03.py','make-ready-joined-source-review-04.py',
        'make-ready-joined-linux-driver-01.py','make-ready-joined-linux-worker-01.py','make-ready-joined-linux-launch-01.py'}
    for number in range(1,6):
        packet=E/f'make-ready-joined-frozen-{number:02d}.json'
        prior=json.loads(packet.read_bytes())
        names.update({packet.name,Path(prior['patch']['path']).relative_to(E).as_posix()})
        for item in prior['logs']:
            assert sha(item['path'])==item['sha256']
            names.add(Path(item['path']).relative_to(E).as_posix())
    for item in w['steps']:
        directory=Path(item['receipt']).parent
        names.update((directory/name).relative_to(E).as_posix() for name in ('receipt.json','stdout.raw','stderr.raw'))
    for number in range(1,7):
        proof=E/f'make-ready-joined-windows-qualification-{number:02d}.json'
        names.add(proof.name)
        p=json.loads(proof.read_bytes())
        for item in p.get('steps',[]):
            directory=Path(item['receipt']).parent
            names.update((directory/name).relative_to(E).as_posix() for name in ('receipt.json','stdout.raw','stderr.raw'))
    for item in l['commands']:
        names.update('make-ready-joined-linux01-'+item['label']+'.'+suffix for suffix in ('stdout','stderr'))
    manifest={name:sha(E/name) for name in sorted(names)}
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr('custody-manifest.json',json.dumps(manifest,indent=2,sort_keys=True)+'\n')
        for name in sorted(manifest):z.write(E/name,'evidence/'+name)
    with zipfile.ZipFile(archive) as z:
        for name,digest in manifest.items():assert hashlib.sha256(z.read('evidence/'+name)).hexdigest()==digest
    node=next(n for n in ast.parse((R/'tests/test_macos_delivered_tui.py').read_text()).body if isinstance(n,ast.ClassDef) and n.name=='MacosDeliveredTuiTests')
    mac=['tests.test_macos_delivered_tui.MacosDeliveredTuiTests.'+n.name for n in node.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
    assert len(mac)==11
    source_paths={'portable':'tests/test_portable_modpack_import.py','presentation':'tests/test_presentation_pack_import.py','joined':'tests/test_make_ready_joined.py'}
    source_hashes={role:hashlib.sha256(subprocess.check_output(['git','hash-object','--path',path,str(R/path)],cwd=R)).hexdigest() for role,path in source_paths.items()}
    # Darwin reads normalized Git blob bytes, not physical Windows line endings.
    blob_sha256={role:hashlib.sha256((R/path).read_text().replace('\r\n','\n').encode('utf-8')).hexdigest() for role,path in source_paths.items()}
    evidence.write_text(json.dumps(dict(schema='facman.joined_make_ready_source_qualification.v1',base_head=BASE,
        frozen_packet_sha256=sha(frozen),review_sha256=sha(review),source_files_sha256={row['path']:row['sha256'] for row in f['files']},
        windows_qualification_sha256=sha(win),windows_joined_methods=13,windows_legacy_methods=72,GUI_continuation_cases=21,
        retained_windows_native_passes=53,full_local_windows_native_pass=False,local_windows_setup_path_refusals=w['local_native_path_blockers'],
        linux_qualification_sha256=sha(linux),linux_native_tests=11,linux_joined_methods=12,linux_legacy_methods=58,linux_skips=0,
        custody=archive.name,custody_sha256=sha(archive),original_partial_v1_preserved=True,accepted_receipt_v2_preserved=True,
        checkpoint_replay_never_redispatches=True,verified_partial_fresh_request_only=True,
        required_actual_mac_package_methods=mac,single_package_factory=True,source_scenario_file_paths=source_paths,source_scenario_git_blob_sha256=blob_sha256,
        actual_new_joined_mac_package_pending=True,required_checks_pending=True,required_exact_windows_native_CI_pending=True,
        authority_delta='none',canonical_installed_desktop=False,minimum_mac13_physical_host=False,named_physical_host=False,
        real_game=False,human=False,whole_workunit=False,full_make_ready=False,beta=False,rc=False),indent=2)+'\n')
    with (R/Q/'ExecPlan.md').open('a',encoding='utf-8',newline='\n') as stream:
        stream.write('\n### Joined current-settings preparation candidate\n\nContinue from checked dev dff35d6 and accepted produced-pack reconstruction/recovery. A separately versioned ordinary Make Ready with current settings binds the existing installation, profile, exact world and internally verified locked content, then invokes existing routing and selected-context owners in one confirmed request. Unchanged inputs and exact operation-bound journal target/parents/inode/bytes are reobserved between owners; completed receipts checkpoint unknown outer state and exact replay never redispatches. Known partial completion retains actual effects and permits a fresh request only after independently verified completion and refusal before further effects. Unknown/foreign/persistence failures retain inspection. The immutable partial v1 action/control and strict durable receipt v2 remain compatible.\n\nFresh Windows runtime build, thirteen joined methods, twenty-one compiled GUI continuation cases, and seventy-two legacy methods passed without skips; a fresh Linux cache campaign passed eleven native, twelve joined and fifty-eight legacy methods under UID/GID65534 and private128MiBtmpfs, with all mounts/children drained. Two broader local Windows Setup fixtures still refuse the deep owned path at pinned SDK path limits; they remain unqualified locally, and exact candidate native CI remains mandatory. No limit, provider pin or policy was changed. Eleven actual Mac package methods (original nine plus two new joined positives) must execute with the same single clean produced package and independently decoded bounded call/CAS custody before integration. No root, clone or worktree was added. Installation/profile/content reconstruction, canonical installed Desktop, real game, human/minimum/named hosts, whole readiness/Play and Beta/RC remain open.\n\nEvidence: `evidence/joined-make-ready-source.v1.json` and its hash-closed custody archive; accepted predecessor `evidence/produced-macos-pack-recovery.v1.json`.\n')
    paths=initial|{Q+'/evidence/'+evidence.name,Q+'/evidence/'+archive.name}
    for label in ('policy','detect','plan'):run(label,['py','-3','-B','.aide/scripts/aide_lite.py','git',label])
    run('project-state',['py','-3','-B','tools/project_state.py','--write'],600)
    run('metadata',['py','-3','-B','tools/codegen/generate_metadata.py','--write'],180)
    generated_only={'.aide/memory/project-state.md','.aide/memory/project-state.v2.json','README.md'}
    for row in f['files']:
        if row['path'] not in generated_only:assert sha(R/row['path'])==row['sha256'],row['path']
    assert set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())==paths
    run('strict',['py','-3','-B','tools/strict_check.py'],1800)
    run('portable-aide',['py','-3','-B','.aide/scripts/aide_lite.py','test'],1800)
    message='feat(readiness): join configuration and selected-world preparation\n\nRetain durable component receipts across one confirmed request and stop\non stale or uncertain inputs without replaying an applied owner.\n\nWork-Item: FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01\nEvidence-Ref: '+Q+'/evidence/'+evidence.name+'\nChangelog: Added: Prepare current routing and exact selected-save context together\n'
    msg=E/'make-ready-joined-candidate-commit-message-01.txt';msg.write_text(message,encoding='utf-8',newline='\n')
    run('message',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--message',message])
    changes=[dict(path=n,state='content',sha256=sha(R/n),git_blob_oid=git('hash-object','--path',n,str(R/n)),ownership='task_owned') for n in sorted(paths)]
    snapshot=hashlib.sha256((json.dumps(changes,indent=2,sort_keys=True,separators=(',',': '))+'\n').encode()).hexdigest()
    commit_review=E/'make-ready-joined-candidate-commit-review-01.json'
    commit_review.write_text(json.dumps(dict(schema_version='aide.git-commit-review.v1',verdict='PASS',reviewer='/root',author='/root/make_ready_joined_implementation',non_authoring=True,
        branch=BRANCH,base_commit=BASE,snapshot_sha256=snapshot,message_sha256=sha(msg),independent_source_review_sha256=sha(review),
        review='Typed desired-state binding, existing owner journals and exact identity/byte reobservation; unknown checkpoint replay prohibition; verified terminal-only GUI continuation; old v1/v2 and nine package methods preserved. Current required CI and actual eleven delivered Mac methods remain mandatory; two broad local deep-path Setup refusals remain explicit.'),indent=2)+'\n')
    classification=E/'make-ready-joined-candidate-commit-classification-01.json'
    classification.write_text(json.dumps(dict(schema_version='aide.git-commit-classification.v1',branch=BRANCH,base_commit=BASE,
        work_item='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01',snapshot_sha256=snapshot,message_sha256=sha(msg),changed_paths=changes,
        reviews=[dict(path=str(commit_review),sha256=sha(commit_review),verdict='PASS')]),indent=2)+'\n')
    helper=['py','-3','-B','.aide/scripts/aide_lite.py','git','commit-plan','--classification',str(classification),'--message-file',str(msg)]
    run('plan-stage',helper);run('stage',['git','add','--',*sorted(paths)]);run('staged-diff',['git','diff','--cached','--check']);run('plan-commit',helper)
    assert git('rev-parse','HEAD')==BASE
    run('commit',['git','commit','-F',str(msg)])
    run('range',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--range',BASE+'..HEAD'])
    assert not git('status','--porcelain')
    record.update(status='COMMITTED_QUALIFIED_JOINED_SOURCE_CANDIDATE',source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),
        review_sha256=sha(commit_review),evidence_sha256=sha(evidence),actual_mac_package_pending=True,required_checks_pending=True,remote_not_pushed=True)
except BaseException as error:record.update(status='ACTIONABLE_JOINED_COMMIT_FAILURE',error=str(error),traceback=traceback.format_exc())
finally:save();print(json.dumps({k:v for k,v in record.items() if k not in ('commands','traceback')},indent=2),flush=True)
raise SystemExit(0 if record['status']=='COMMITTED_QUALIFIED_JOINED_SOURCE_CANDIDATE' else 1)
