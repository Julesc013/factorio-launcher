import hashlib,json
from pathlib import Path
E=Path(__file__).resolve().parent
R=Path(r'D:\Projects\Factorio\factorio-launcher')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
before=json.loads((E/'make-ready-joined-frozen-02.json').read_bytes())
after=json.loads((E/'make-ready-joined-frozen-03.json').read_bytes())
old={row['path']:row['sha256'] for row in before['files']}
new={row['path']:row['sha256'] for row in after['files']}
path='runtime/factorio/application/presentation_joined_preparation.cpp'
assert old.keys()==new.keys() and {n for n in old if old[n]!=new[n]}=={path}
data=(R/path).read_bytes()
include=b'#include "fl_path_safety.h"\n'
if include not in data: include=b'#include "fl_path_safety.h"\r\n'
assert data.count(include)==1 and hashlib.sha256(data.replace(include,b'',1)).hexdigest()==old[path]
assert before['root_owned_preserved']==after['root_owned_preserved']
origin=E/'make-ready-joined-source-review-01.py'
code=origin.read_text().replace('make-ready-joined-frozen-02.json','make-ready-joined-frozen-03.json').replace('make-ready-joined-independent-review-01.json','make-ready-joined-independent-review-02.json')
extra={'prior_review_sha256':sha(E/'make-ready-joined-independent-review-01.json'),
    'failed_windows_qualification_sha256':sha(E/'make-ready-joined-windows-qualification-01.json'),
    'compile_repair':'One direct declaration-header include; all other authored files and root Q files unchanged',
    'source_review_origin_sha256':sha(origin),'changed_from_previous_review':[path]}
code=code.replace('OUT.write_text(', 'record.update('+repr(extra)+')\nOUT.write_text(',1)
exec(compile(code,str(origin)+'#freeze03-reviewed','exec'))
