import hashlib,json,os,sys,unittest
from pathlib import Path
R=Path("/mnt/d/Projects/Factorio/factorio-launcher");E=Path(__file__).resolve().parent
assert os.getuid()==65534 and os.getgid()==65534 and not os.getgroups()
assert os.environ["TMPDIR"].startswith(str(E))
sys.path[:0]=[str(R),str(R/"tests")]
import importlib.metadata
expected={line.split("==")[0]:line.split("==")[1] for line in (R/"tools/requirements-dev.lock").read_text().splitlines() if "==" in line}
versions={n:importlib.metadata.version(n) for n in expected}
assert versions==expected,versions
suite=unittest.defaultTestLoader.loadTestsFromNames(["test_configuration_preparation","test_selected_save_preparation","test_posix_preparation_publication"])
r=unittest.TextTestRunner(verbosity=2).run(suite)
a=dict(schema="facman.posix_preparation_unprivileged_source_tests.v1",
uid=os.getuid(),gid=os.getgid(),groups=os.getgroups(),tests=r.testsRun,
skips=[(str(t),reason) for t,reason in r.skipped],failures=len(r.failures),errors=len(r.errors),
CLI_sha256=hashlib.sha256(Path(os.environ["FACMAN_CLI_EXE"]).read_bytes()).hexdigest(),
status="PASS_LINUX_SOURCE_OWNERS" if r.wasSuccessful() and len(r.skipped)==4 else "ACTIONABLE_FIXTURE_FAILURE",
locked_validators=versions,filesystem="private128MiB tmpfs",produced_package=False,physical_host=False,power_loss=False,game=False,beta=False)
p=E/"posix-preparation-publication-linux-fixtures-result-03.json"
with p.open("x") as f:json.dump(a,f,indent=2);f.write("\n")
raise SystemExit(0 if a["status"]=="PASS_LINUX_SOURCE_OWNERS" else 1)
