import hashlib,json,os,signal,subprocess,sys,time,traceback
from pathlib import Path
R=Path("/mnt/d/Projects/Factorio/factorio-launcher");E=Path(__file__).resolve().parent;W=E.parent;B=W/"native-save-context-linux"
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads((E/"posix-preparation-publication-source-assurance-02.json").read_bytes())
def bound():
    for n,h in a["source_files_sha256"].items():assert sha(R/n)==h,n
bound()
assert os.getpid()==1 and os.readlink("/proc/self/ns/mnt")!=os.environ["FACMAN_PARENT_MOUNT_NAMESPACE"]
out=E/"posix-preparation-publication-linux-result-03.json";assert not out.exists()
record=dict(schema="facman.posix_preparation_linux_qualification.v1",status="CONFIGURING_EXISTING_BUILD",
source_assurance_sha256=sha(E/"posix-preparation-publication-source-assurance-02.json"),commands=[],new_roots=0,new_clones=0,new_worktrees=0,goal_status_mutated=False)
def save():out.write_text(json.dumps(record,indent=2)+"\n")
def run(label,args,timeout,env=None):
    bound()
    stdout=E/("posix-publication-linux03-"+label+".stdout");stderr=E/("posix-publication-linux03-"+label+".stderr")
    with stdout.open("xb") as o,stderr.open("xb") as er:
        p=subprocess.Popen([str(x) for x in args],cwd=R,env=env,stdout=o,stderr=er,start_new_session=True)
        timed=False
        try:code=p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed=True;os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=30)
    record["commands"].append(dict(label=label,argv=[str(x) for x in args],exit=code,execution_limit_exceeded=timed,stdout_sha256=sha(stdout),stderr_sha256=sha(stderr)))
    save();assert code==0 and not timed,(label,code,str(stderr))
    bound()
os.environ.update(PYTHONDONTWRITEBYTECODE="1",PYTHONOPTIMIZE="0",TMPDIR=str(W/"t"),TEMP=str(W/"t"),TMP=str(W/"t"),FACMAN_DEV_ROOT="/mnt/d/Projects/Factorio/.task-builds",CMAKE_BUILD_PARALLEL_LEVEL="2")
mountpoint=E/"posix-publication-private-fixtures-01";mounted=False
try:
    ulk=W/"providers/universal-launcher-5479939ca5cb";usk=W.parent/"task-facman-u-507ecf4b41/providers/universal-setup-2749a15b835a"
    # Exact successful configuration and compiled provider objects are reused.
    record["status"]="BUILDING_LINUX_OWNER_SOURCE";save()
    run("build",["cmake","--build",B,"--parallel","2","--target","facman_cli","fl_platform_io_smoke"],3600)
    record["cli_sha256"]=sha(B/"facman");record["status"]="RUNNING_UNPRIVILEGED_PRIVATE_FIXTURES";save()
    assert not mountpoint.exists();mountpoint.mkdir()
    subprocess.run(["mount","-t","tmpfs","-o","size=128m,nosuid,nodev,mode=1777","facman-posix-publication",str(mountpoint)],check=True,timeout=30);mounted=True
    env=dict(os.environ,TMPDIR=str(mountpoint),TMP=str(mountpoint),TEMP=str(mountpoint),FACMAN_CLI_EXE=str(B/"facman"),PYTHONPATH=str(R)+":"+str(R/"tests"))
    privilege=["setpriv","--reuid=65534","--regid=65534","--clear-groups"]
    run("native",[*privilege,"ctest","--test-dir",B,"-R","^fl_platform_io_smoke$","--output-on-failure"],300,env)
    run("fixtures",[*privilege,"python3","-B",E/"posix-preparation-publication-linux-fixture-worker-01.py"],900,env)
    result=json.loads((E/"posix-preparation-publication-linux-fixtures-result-01.json").read_bytes())
    assert result["status"]=="PASS_LINUX_SOURCE_OWNERS" and result["CLI_sha256"]==record["cli_sha256"]
    assert not list(mountpoint.iterdir()),"Remaining fixture state must be preserved"
    bound();record.update(status="PASS_LINUX_SOURCE_PUBLICATION_AND_RECOVERY",fixture_result_sha256=sha(E/"posix-preparation-publication-linux-fixtures-result-01.json"),produced_package=False,physical_ext4_host=False,macos=False,existing_ini=False,beta=False)
except BaseException as exc:record.update(status="ACTIONABLE_LINUX_QUALIFICATION_FAILURE",error=str(exc),traceback=traceback.format_exc())
finally:
    if mounted:
        leftovers=list(mountpoint.iterdir())
        if leftovers:
            archive=E/"posix-publication-unresolved-fixture-state-01.tar"
            subprocess.run(["tar","-cf",str(archive),"-C",str(mountpoint),"."],check=True,timeout=60)
            record["preserved_unresolved_fixture_archive_sha256"]=sha(archive)
        subprocess.run(["umount",str(mountpoint)],check=True,timeout=30)
    record["private_mount_absent"]=not os.path.ismount(mountpoint)
    record["source_files_sha256"]=a["source_files_sha256"]
    save();print(json.dumps({k:v for k,v in record.items() if k not in ("commands","source_files_sha256")},indent=2))
    raise SystemExit(0 if record["status"]=="PASS_LINUX_SOURCE_PUBLICATION_AND_RECOVERY" else 1)
