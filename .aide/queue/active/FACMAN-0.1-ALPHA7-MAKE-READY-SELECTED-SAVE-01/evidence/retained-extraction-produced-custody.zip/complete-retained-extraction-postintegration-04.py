"""Receipt-owned completion; never queries CI or mutates active parallel work."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
P = 'retained-extraction-coverage-policy'
assert __debug__, 'Assertions must remain enabled'
decision_path=E/'retained-extraction-produced-drivers-review-04.json'
decision_bytes=decision_path.read_bytes();decision=json.loads(decision_bytes)
review_sha256=hashlib.sha256(decision_bytes).hexdigest()
self_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
assert decision['verdict']=='PASS' and decision['independent'] and decision['non_authoring']
assert decision['scripts_sha256'][Path(__file__).name]==self_sha256
assert decision['source']=='1f517c39f91810d693e0f2c5c08ae3f97b9045e1'
publication_bytes=(E/'retained-extraction-coverage-policy-published-01.json').read_bytes()
reviewed_publication=json.loads(publication_bytes)
assert decision['publication_sha256']==hashlib.sha256(publication_bytes).hexdigest()
assert reviewed_publication['source']==decision['source'] and reviewed_publication['pr']['number']==402
os.environ['FACMAN_DEV_ROOT']=r'D:\Projects\Factorio\.task-builds'
with (E/(Path(__file__).stem+'.claim.json')).open('x',encoding='utf-8') as claim:
    json.dump(dict(pid=os.getpid(),script_sha256=self_sha256,review_sha256=review_sha256,
        source=decision['source'],no_automatic_replay=True),claim,indent=2)

os.environ['FACMAN_DEV_ROOT'] = r'D:\Projects\Factorio\.task-builds'
sys.path.insert(0, str(R / '.aide/scripts'))
import aide_lite

def run(root, *args):
    value = subprocess.run(args, cwd=root, capture_output=True, text=True,
                           encoding='utf-8', timeout=180)
    assert value.returncode == 0, dict(root=str(root), command=args[:4], error=value.stderr[-1800:])
    return value.stdout.rstrip('\r\n')

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

c = read(E / (P + '-committed-01.json'))
p = reviewed_publication
head, branch, pr = c['head'], c['branch'], p['pr']['number']
assert head==decision['source'] and pr==402
assert p['source'] == head and p['commit_parent'] == c['base']
assert p['base'] == c['integration_base'] == 'e43d9264ab4bc35517fcb314a357b7c2ad92e8ac'
receipt = E / (P + '-integration-' + head[:8] + '.json')
output = E / (P + '-postintegration-completion-01.json')
assert not output.exists()
record = dict(status='waiting_on_existing_integration_receipt', source=head,
              pull_request=pr, roots_deleted=0, parallel_task_roots_mutated=False,
              local_timeout_resolved=False, full_local_campaign_complete=False)
save(output, record)
deadline = time.monotonic() + 18000
try:
    while True:
        if receipt.exists():
            try: integration = read(receipt)
            except json.JSONDecodeError:
                time.sleep(1)
                continue
            if integration['status'] == 'actionable_stop_preserve_execution':
                raise RuntimeError(dict(integration_receipt=str(receipt), error=integration.get('error')))
            if integration['status'] == 'required_source_and_merge_CI_pass':
                break
        assert time.monotonic() < deadline, 'Receipt deadline; preserve observer and jobs'
        time.sleep(5)
    assert integration['source'] == head and integration['pull_request'] == pr
    assert integration['base'] == p['base']
    decision = integration['independent_integration_decision']
    assert decision['approve_normal_checked_integration'] is True
    assert decision['independent'] and decision['non_authoring']
    merge = integration['merge']
    assert run(R, 'git', 'branch', '--show-current') == 'dev'
    assert run(R, 'git', 'rev-parse', 'HEAD') == merge
    assert not run(R, 'git', 'status', '--porcelain')
    identity = run(R, 'powershell', '-NoProfile', '-Command',
                   '[System.Security.Principal.WindowsIdentity]::GetCurrent().Name')
    assert identity.casefold() == r'BLACKGLASS-WIN1\Jules'.casefold()
    run(R, 'gh', 'auth', 'status')
    assert run(R, 'gh', 'api', 'user', '--jq', '.login') == 'Julesc013'
    record.update(status='synchronizing_clean_Universal_primaries', facman_dev=merge, roots=[])
    record['driver_review_sha256']=review_sha256
    assert hashlib.sha256(decision_path.read_bytes()).hexdigest()==review_sha256
    save(output, record)
    for name in ('universal-launcher', 'universal-setup'):
        root = Path(r'D:\Projects\Universal') / name
        assert root.resolve() == root
        before = run(root, 'git', 'rev-parse', 'HEAD')
        current_branch = run(root, 'git', 'branch', '--show-current')
        item = dict(repository=name, root=str(root), before=before, branch=current_branch)
        if current_branch != 'dev' or run(root, 'git', 'status', '--porcelain'):
            item['status'] = 'preserved_active_work'
        else:
            gitdir = Path(run(root, 'git', 'rev-parse', '--absolute-git-dir'))
            assert not (gitdir / 'index.lock').exists()
            run(root, 'git', 'fetch', '--no-tags', 'origin', 'dev')
            assert run(root, 'git', 'rev-parse', 'HEAD') == before
            assert run(root, 'git', 'branch', '--show-current') == current_branch
            assert not run(root, 'git', 'status', '--porcelain')
            remote = run(root, 'git', 'rev-parse', 'origin/dev')
            run(root, 'git', 'merge-base', '--is-ancestor', before, remote)
            run(root, 'git', 'merge', '--ff-only', 'origin/dev')
            assert run(root, 'git', 'rev-parse', 'HEAD') == remote
            assert not run(root, 'git', 'status', '--porcelain')
            item.update(status='clean_dev_synchronized', after=remote)
        record['roots'].append(item)
        save(output, record)
    assert run(R, 'git', 'rev-parse', 'refs/heads/' + branch) == head
    assert not run(R, 'git', 'rev-list', head, '--not', merge)
    assert 'branch refs/heads/' + branch not in run(R, 'git', 'worktree', 'list', '--porcelain').splitlines()
    assert not json.loads(run(R, 'gh', 'pr', 'list', '--repo', 'Julesc013/factorio-launcher',
                              '--base', branch, '--state', 'open', '--json', 'number'))
    pull = json.loads(run(R, 'gh', 'api', 'repos/Julesc013/factorio-launcher/pulls/' + str(pr)))
    assert pull['merged'] and pull['head']['sha'] == head and pull['merge_commit_sha'] == merge
    assert pull['base']['ref'] == 'dev'
    marker = read(E.parent / '.facman-development-root.v1.json')
    assert Path(marker['source_root']).resolve() == R and marker['task_id'] == branch
    for command in ('policy', 'detect', 'plan'):
        run(R, 'py', '-3', '.aide/scripts/aide_lite.py', 'git', command)
    prune = aide_lite.make_git_helper_plan(R, 'prune', target='dev')
    candidates = [item for item in prune['prune_candidates'] if item['branch'] == branch]
    assert len(candidates) == 1 and candidates[0]['eligible']
    remote = run(R, 'git', 'ls-remote', '--heads', 'origin', 'refs/heads/' + branch)
    if remote:
        assert remote.split()[0] == head
        run(R, 'git', 'push', 'origin', '--delete', branch)
    assert not run(R, 'git', 'ls-remote', '--heads', 'origin', 'refs/heads/' + branch)
    run(R, 'git', 'update-ref', '-d', 'refs/heads/' + branch, head)
    tracking = subprocess.run(['git', 'rev-parse', '--verify', 'refs/remotes/origin/' + branch],
                              cwd=R, capture_output=True, text=True)
    if tracking.returncode == 0:
        assert tracking.stdout.rstrip('\r\n') == head
        run(R, 'git', 'update-ref', '-d', 'refs/remotes/origin/' + branch, head)
    record.update(status='reviewed_retained_extraction_integrated_and_clean_primaries_synchronized',
                  active_primary_work_preserved=any(item['status']=='preserved_active_work' for item in record['roots']),
                  all_three_primaries_synchronized=all(item['status']=='clean_dev_synchronized' for item in record['roots']),
                  task_refs_retired=True, unique_work_deleted=False,
                  finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save(output, record)
    print(json.dumps(record), flush=True)
except Exception as error:
    record.update(status='actionable_stop_preserve_execution', error=str(error))
    save(output, record)
    print(json.dumps(record), flush=True)
    raise
