"""Consume this PR's automatic Windows delivery once, with bounded extraction."""
import datetime,hashlib,io,json,os,re,shutil,stat,subprocess,time,zipfile
from pathlib import Path,PurePosixPath
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
publication=json.loads((E/'retained-extraction-coverage-policy-published-01.json').read_text(encoding='utf-8'));HEAD=publication['source'];PR=publication['pr']['number'];REPO='Julesc013/factorio-launcher'

assert __debug__, 'Assertions must remain enabled'
decision_path=E/'retained-extraction-produced-drivers-review-04.json'
decision_bytes=decision_path.read_bytes();decision=json.loads(decision_bytes)
review_sha256=hashlib.sha256(decision_bytes).hexdigest()
self_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
assert decision['verdict']=='PASS' and decision['independent'] and decision['non_authoring']
assert decision['scripts_sha256'][Path(__file__).name]==self_sha256
assert decision['source']=='1f517c39f91810d693e0f2c5c08ae3f97b9045e1'
publication_bytes=(E/'retained-extraction-coverage-policy-published-01.json').read_bytes()
reviewed_publication=json.loads(publication_bytes)
assert decision['publication_sha256']==hashlib.sha256(publication_bytes).hexdigest()
assert reviewed_publication['source']==decision['source'] and reviewed_publication['pr']['number']==402
os.environ['FACMAN_DEV_ROOT']=r'D:\Projects\Factorio\.task-builds'
with (E/(Path(__file__).stem+'.claim.json')).open('x',encoding='utf-8') as claim:
    json.dump(dict(pid=os.getpid(),script_sha256=self_sha256,review_sha256=review_sha256,
        source=decision['source'],no_automatic_replay=True),claim,indent=2)

publication=reviewed_publication;HEAD=publication['source'];PR=publication['pr']['number']
assert HEAD==decision['source'] and PR==402
OUT=E/'produced-retained-extraction-admission-01.json';ZIP=E/'produced-retained-extraction-artifact-01.zip'
DEST=W/'t'/'produced-retained-extraction-01';LIMIT=128*1024*1024
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def api(path):
    p=subprocess.run(['gh','api',path],cwd=R,capture_output=True,timeout=90)
    assert p.returncode==0,(p.returncode,p.stderr[-1000:].decode(errors='replace'))
    return json.loads(p.stdout)
def save():
    temporary=OUT.with_suffix('.writing');temporary.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');temporary.replace(OUT)
def inventory(archive):
    entries=archive.infolist();seen=set();total=0
    assert len(entries)<=2000
    for entry in entries:
        p=PurePosixPath(entry.filename)
        assert p.parts and not p.is_absolute() and '\\' not in entry.filename and ':' not in entry.filename
        assert '..' not in p.parts and '.' not in p.parts
        assert entry.filename.casefold() not in seen;seen.add(entry.filename.casefold())
        assert not stat.S_ISLNK(entry.external_attr>>16)
        assert entry.file_size<=LIMIT;total+=entry.file_size
        assert total<=LIMIT
    assert archive.testzip() is None
    return entries,total
assert __debug__ and not OUT.exists() and not ZIP.exists() and not DEST.exists()
marker=json.loads((W/'.facman-development-root.v1.json').read_text(encoding='utf-8-sig'))
assert marker['kind']=='task-root' and Path(marker['canonical_path']).resolve()==W.resolve()
assert Path(marker['source_root']).resolve()==R.resolve()
committed=json.loads((E/'retained-extraction-coverage-policy-committed-01.json').read_text());assert committed['head']==decision['source'] and publication['source']==committed['head'] and publication['base']==committed['integration_base']=='e43d9264ab4bc35517fcb314a357b7c2ad92e8ac'
assert marker['task_id']==publication['branch']
assert subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).rstrip('\r\n')==''
assert subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=R,text=True)==subprocess.check_output(['git','rev-parse',HEAD+'^{tree}'],cwd=R,text=True)
record=dict(status='waiting_on_existing_Windows_source_result',source=HEAD,pull_request=PR,pid=os.getpid(),
    new_task_roots=0,new_worktrees=0,new_clones=0,builds=0,candidate_dispatches=0,job_reruns=0,
    model_requests_by_observer=0,driver_review_sha256=review_sha256,whole_workunit_closed=False,beta_qualified=False)
save()
try:
    # The existing observer already completed all gates; do not start another observer.
    integration=json.loads((E/'retained-extraction-coverage-policy-integration-1f517c39.json').read_text())
    assert integration['status']=='required_source_and_merge_CI_pass' and integration['source']==HEAD
    checks=json.loads((E/'retained-extraction-coverage-policy-source-latest-checks.json').read_text())
    windows=[c for c in checks if c['name']=='windows-native-package' and c['head_sha']==HEAD and c['app']['id']==15368]
    assert len(windows)==1 and windows[0]['status']=='completed' and windows[0]['conclusion']=='success'
    record['Windows_check']=windows[0]
    identity=subprocess.check_output(['powershell','-NoProfile','-Command','[System.Security.Principal.WindowsIdentity]::GetCurrent().Name'],text=True).strip()
    assert identity.casefold()==r'BLACKGLASS-WIN1\Jules'.casefold()
    assert subprocess.run(['gh','auth','status'],capture_output=True,timeout=30).returncode==0
    assert api('user')['login']=='Julesc013'
    selected_check=record['Windows_check']
    binding=re.fullmatch(r'https://github\.com/Julesc013/factorio-launcher/actions/runs/(\d+)/job/(\d+)',selected_check['details_url'])
    assert binding
    expected_run,expected_job=map(int,binding.groups())
    job=api(f'repos/{REPO}/actions/jobs/{expected_job}')
    assert job['id']==expected_job and job['run_id']==expected_run and job['head_sha']==HEAD
    assert job['name']=='windows-native-package' and job['status']=='completed' and job['conclusion']=='success'
    assert job['check_run_url']==f'https://api.github.com/repos/{REPO}/check-runs/{selected_check["id"]}'
    record['producer_job']=job
    artifact_name='windows-self-setup-'+HEAD
    artifacts=api(f'repos/{REPO}/actions/artifacts?name={artifact_name}&per_page=100')
    matching=[a for a in artifacts['artifacts'] if a['name']==artifact_name and not a['expired'] and a['workflow_run']['head_sha']==HEAD and a['workflow_run']['id']==expected_run]
    assert len(matching)==1 and artifacts['total_count']<=100
    artifact=matching[0];assert artifact['size_in_bytes']<=LIMIT
    run=api(f"repos/{REPO}/actions/runs/{artifact['workflow_run']['id']}")
    assert run['id']==expected_run
    assert run['head_sha']==HEAD and run['event']=='pull_request' and run['path']=='.github/workflows/ci.yml'
    assert run['status']=='completed' and run['conclusion']=='success'
    assert run['repository']['full_name']==REPO and run['head_repository']['full_name']==REPO
    # GitHub's completed run may omit a now-merged PR from pull_requests.
    # Bind the actual merged PR separately to the exact observed source/base/merge,
    # in addition to the existing exact source-check -> job -> run -> artifact chain.
    producer_pr=api(f'repos/{REPO}/pulls/{PR}')
    completion=json.loads((E/'retained-extraction-coverage-policy-postintegration-completion-01.json').read_text())
    assert producer_pr['number']==PR and producer_pr['merged'] and producer_pr['state']=='closed'
    assert producer_pr['head']['sha']==HEAD and producer_pr['base']['sha']==publication['base']
    assert producer_pr['head']['repo']['full_name']==REPO and producer_pr['base']['repo']['full_name']==REPO
    assert producer_pr['merge_commit_sha']==integration['merge']==completion['facman_dev']
    assert completion['status']=='reviewed_retained_extraction_integrated_and_clean_primaries_synchronized'
    assert completion['source']==HEAD and completion['task_refs_retired'] and not completion['unique_work_deleted']
    associated={p['number'] for p in run['pull_requests']}
    assert not associated or PR in associated
    record['producer_pr']=producer_pr
    record['run_pr_list_empty_after_merge']=not associated
    record.update(status='admitting_existing_produced_delivery',artifact=artifact,producer_run=run,execution_identity=identity);save()
    env=dict(os.environ,FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',FACMAN_TASK_ROOT=str(W),TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONOPTIMIZE='0')
    doctor=E/'produced-retained-extraction-admission-01-doctor.log'
    with doctor.open('xb') as f:result=subprocess.run(['py','-3','tools/workspace_hygiene.py','doctor','--measure'],cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
    assert result.returncode in {0,1};hygiene=json.loads(doctor.read_text())
    assert set(hygiene['violations'])<={'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
    peak=512*1024*1024
    assert len(hygiene['task_roots'])<=8 and hygiene['task_root_bytes']+peak<20*1024**3 and shutil.disk_usage(W).free>=10*1024**3
    record['resources']=dict(task_root_bytes=hygiene['task_root_bytes'],peak_extra_bytes=peak,free_before=shutil.disk_usage(W).free,doctor_sha256=sha(doctor));save()
    assert hashlib.sha256(decision_path.read_bytes()).hexdigest()==review_sha256
    with ZIP.open('xb') as f,(E/'produced-retained-extraction-artifact-01.stderr.log').open('xb') as errors:
        result=subprocess.run(['gh','api',f"repos/{REPO}/actions/artifacts/{artifact['id']}/zip"],cwd=R,stdout=f,stderr=errors,timeout=180)
    assert result.returncode==0 and ZIP.stat().st_size<=LIMIT and 'sha256:'+sha(ZIP)==artifact['digest']
    with zipfile.ZipFile(ZIP) as outer:
        entries,_=inventory(outer)
        records=[e for e in entries if e.filename.endswith('self-setup-package.v1.json')];assert len(records)==1
        package=json.loads(outer.read(records[0]));assert package['facman_source_revision']==HEAD and package['source_dirty'] is False
        payloads=[e for e in entries if PurePosixPath(e.filename).name==package['payload']['filename']];assert len(payloads)==1
        data=outer.read(payloads[0]);assert len(data)==package['payload']['size_bytes'] and hashlib.sha256(data).hexdigest()==package['payload']['sha256']
        recordbytes=outer.read(records[0])
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        entries,total=inventory(archive);files=[e for e in entries if not e.is_dir()]
        assert len(files)==package['payload']['file_count']
        table=bytearray()
        for e in sorted(files,key=lambda e:e.filename.encode('utf-8')):
            raw=archive.read(e);table.extend(e.filename.encode()+b'\0'+str(len(raw)).encode()+b'\0'+hashlib.sha256(raw).hexdigest().encode()+b'\n')
        assert hashlib.sha256(table).hexdigest()==package['payload']['tree_digest']
        prefix='facman/generations/'+package['version']+'/'
        selected=[e for e in files if e.filename.startswith(prefix)]
        expected_inventory={e.filename[len(prefix):]:hashlib.sha256(archive.read(e)).hexdigest() for e in selected}
        assert len(expected_inventory)==len(selected)
        required={prefix+'bin/'+p for p in ('facman.exe','flb_factorio.dll','ulk.dll','usk.dll')}
        assert required<={e.filename for e in selected}
        DEST.mkdir();(DEST/'package-record.v1.json').write_bytes(recordbytes)
        for e in selected:
            target=DEST/e.filename;assert target.resolve().is_relative_to(DEST.resolve())
            target.parent.mkdir(parents=True,exist_ok=True)
            with target.open('xb') as f:f.write(archive.read(e))
        delivery=DEST/prefix
    current={p.relative_to(delivery).as_posix():sha(p) for p in delivery.rglob('*') if p.is_file()}
    assert current==expected_inventory,'Extracted inventory/bytes must equal every selected archive entry'
    normalized={('bin/FacMan.WinForms.exe' if p=='FacMan.exe' else p):h for p,h in current.items()}
    assert len(normalized)==len(current)
    hashed={}
    for line in (delivery/'manifest/hashes.sha256').read_text().splitlines():
        h,p=line.split('  ',1)
        assert re.fullmatch('[0-9a-f]{64}',h) and p==PurePosixPath(p).as_posix()
        assert not PurePosixPath(p).is_absolute() and '..' not in PurePosixPath(p).parts and '\\' not in p and ':' not in p
        assert p not in hashed and p in normalized and normalized[p]==h
        hashed[p]=h
    covered={p for p in normalized if p!='manifest/hashes.sha256' and not p.endswith('.sig')}
    assert set(hashed)==covered,'Exact writer exclusions only; empty/incomplete/duplicate manifest refused'
    build=json.loads((delivery/'manifest/build_info.v1.json').read_text())
    assert build['profile_id']=='windows_legacy_winforms_x64'
    record.update(status='ADMITTED_EXACT_PRODUCED_RETAINED_EXTRACTION_DELIVERY',artifact_sha256=sha(ZIP),
        payload_sha256=package['payload']['sha256'],package_record=package,build_info=build,
        payload_uncompressed_bytes=total,delivery=str(delivery),inventory_sha256=current,
        executable=str(delivery/'bin/facman.exe'),executable_sha256=current['bin/facman.exe'],
        completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
    print(json.dumps(dict(status=record['status'],artifact_id=artifact['id'],producer_run=run['id'],files=len(current))),flush=True)
except Exception as error:
    record.update(status='ACTIONABLE_FAILURE',error=repr(error));save();raise
