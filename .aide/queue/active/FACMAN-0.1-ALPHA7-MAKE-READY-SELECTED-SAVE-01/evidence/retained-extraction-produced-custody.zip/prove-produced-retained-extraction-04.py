"""Execute the admitted produced runtime outside checkout, using synthetic inputs."""
import ast,datetime,hashlib,importlib,types,json,os,subprocess,sys,tempfile,threading,time,unittest
from pathlib import Path
E=Path(__file__).resolve().parent;W=E.parent;R=Path(r'D:\Projects\Factorio\factorio-launcher')

assert __debug__, 'Assertions must remain enabled'
decision_path=E/'retained-extraction-produced-drivers-review-04.json'
decision_bytes=decision_path.read_bytes();decision=json.loads(decision_bytes)
review_sha256=hashlib.sha256(decision_bytes).hexdigest()
self_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
assert decision['verdict']=='PASS' and decision['independent'] and decision['non_authoring']
assert decision['scripts_sha256'][Path(__file__).name]==self_sha256
assert decision['source']=='1f517c39f91810d693e0f2c5c08ae3f97b9045e1'
publication_bytes=(E/'retained-extraction-coverage-policy-published-01.json').read_bytes()
reviewed_publication=json.loads(publication_bytes)
assert decision['publication_sha256']==hashlib.sha256(publication_bytes).hexdigest()
assert reviewed_publication['source']==decision['source'] and reviewed_publication['pr']['number']==402
os.environ['FACMAN_DEV_ROOT']=r'D:\Projects\Factorio\.task-builds'
with (E/(Path(__file__).stem+'.claim.json')).open('x',encoding='utf-8') as claim:
    json.dump(dict(pid=os.getpid(),script_sha256=self_sha256,review_sha256=review_sha256,
        source=decision['source'],no_automatic_replay=True),claim,indent=2)

OUT=E/'produced-retained-extraction-proof-01.json';assert not OUT.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
admission_path=E/'produced-retained-extraction-admission-01.json'
admission=json.loads(admission_path.read_text());assert admission['status']=='ADMITTED_EXACT_PRODUCED_RETAINED_EXTRACTION_DELIVERY'
assert admission['source']==decision['source'] and admission['pull_request']==402
HEAD=admission['source'];CLI=Path(admission['executable']);DELIVERY=Path(admission['delivery'])
assert sha(CLI)==admission['executable_sha256']
assert DELIVERY.resolve().is_relative_to((W/'t').resolve()) and not DELIVERY.resolve().is_relative_to(R.resolve())
os.chdir(DELIVERY)
git=lambda *args:subprocess.check_output(['git',*args],cwd=R,text=True).rstrip('\r\n')
assert not git('status','--porcelain')
assert git('rev-parse','HEAD^{tree}')==git('rev-parse',HEAD+'^{tree}')
os.environ.update(FACMAN_CLI_EXE=str(CLI),FACMAN_NATIVE_CLI=str(CLI),FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',
    FACMAN_TASK_ROOT=str(W),TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONOPTIMIZE='0')
for key in list(os.environ):
    if key.startswith('FACMAN_TEST_'):os.environ.pop(key)
tempfile.tempdir=str(W/'t');sys.path[:0]=[str(R/'tests'),str(R)]
fixture=R/'tests/fixtures/fake_factorio_install'
inventory=lambda root:{p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file()}
before_fixture=inventory(fixture);before_delivery=inventory(DELIVERY)
assert before_delivery==admission['inventory_sha256']
cmake_sources={name:sha(R/name) for name in ('apps/cli/CMakeLists.txt','runtime/factorio/CMakeLists.txt','runtime/client/CMakeLists.txt')}
assert 'add_library(flb_factorio ALIAS flb_factorio_static)' in (R/'runtime/factorio/CMakeLists.txt').read_text()

record=dict(status='RUNNING_PRODUCED_RETAINED_EXTRACTION_PROOF',source=HEAD,pid=os.getpid(),
    admission_sha256=sha(admission_path),executable_sha256=sha(CLI),cwd=str(DELIVERY),commands=[],
    builds=0,new_task_roots=0,new_candidates=0,job_reruns=0,
    synthetic_public_fixture_inputs=True,real_factorio_execution=False,human_UI_acceptance=False,
    whole_workunit_closed=False,beta_qualified=False,retained_extraction_package_qualified=False,
    source_qualification_reference='.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01/evidence/retained-extraction-relative.v1.json')
guard=threading.Lock();command_dir=E/'produced-retained-extraction-commands-01';assert not command_dir.exists();command_dir.mkdir()
def save_locked():
    temporary=OUT.with_suffix('.writing');temporary.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');temporary.replace(OUT)
def save():
    with guard:save_locked()
def invoke(args,env=None):
    assert '--workspace' in args
    workspace_path=Path(args[args.index('--workspace')+1]).resolve()
    assert workspace_path.is_relative_to((W/'t').resolve()),'Only owned synthetic workspaces may be mutated'
    environment=dict(os.environ if env is None else env)
    with guard:
        index=len(record['commands'])+1
        entry=dict(index=index,argv=[str(CLI),*args],cwd=str(DELIVERY),status='RUNNING',
            seams={k:v for k,v in environment.items() if k in {'FACMAN_TEST_CONFIGURATION_EXIT','FACMAN_TEST_CONFIGURATION_PAUSE'}})
        record['commands'].append(entry);save_locked()
    started=time.monotonic();deadline=started+45
    def remaining(limit=None):
        available=deadline-time.monotonic()
        if available<=0:raise subprocess.TimeoutExpired(entry['argv'],45)
        return min(available,limit) if limit is not None else available
    release=None;failure=None;out=b'';err=b'';raw_streams_complete=False
    lifetime=dict(deadline_exceeded=False,kill_errors=[])
    timer=None
    def deadline_kill():
        if process.poll() is None:
            lifetime['deadline_exceeded']=True
            try:process.kill()
            except BaseException as error:lifetime['kill_errors'].append(repr(error))
    process=subprocess.Popen(entry['argv'],cwd=DELIVERY,env=environment,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
        creationflags=subprocess.CREATE_NO_WINDOW)
    try:
        entry.update(pid=process.pid,lifetime_deadline_seconds=45)
        # Arm before fallible postspawn custody; cleanup also covers timer setup.
        timer=threading.Timer(max(0.001,deadline-time.monotonic()),deadline_kill)
        timer.daemon=True;timer.start()
        with guard:save_locked()
        if environment.get('FACMAN_TEST_CONFIGURATION_PAUSE')=='rewrite_after_write':
            workspace=Path(args[args.index('--workspace')+1]);root=workspace/'instances/main'
            marker=root/'.facman-test-configuration-rewrite_after_write';release=root/'.facman-test-configuration-release'
            marker_deadline=min(deadline,time.monotonic()+15)
            while not marker.exists() and process.poll() is None and time.monotonic()<marker_deadline:time.sleep(0.01)
            assert marker.exists(),'Produced owner did not reach final held-file observation'
            script="Get-Process -Id "+str(process.pid)+" | Select-Object -ExpandProperty Modules | Where-Object { $_.ModuleName -in @('flb_factorio.dll','ulk.dll','usk.dll') } | Select-Object ModuleName,FileName | ConvertTo-Json -Compress"
            audit_out,audit_err=b'',b''
            try:
                audit=subprocess.run(['powershell','-NoProfile','-Command',script],capture_output=True,timeout=remaining(10))
                audit_out,audit_err=audit.stdout,audit.stderr
            except subprocess.TimeoutExpired as error:
                audit_out,audit_err=error.stdout or b'',error.stderr or b''
                raise
            finally:
                audit_streams={}
                for name,data in [('stdout',audit_out),('stderr',audit_err)]:
                    path=command_dir/(f'{index:04d}.audit.'+name)
                    with path.open('xb') as f:f.write(data)
                    audit_streams[name]=dict(path=str(path),sha256=sha(path))
                with guard:entry['audit_streams']=audit_streams;save_locked()
            assert process.poll() is None,'Owned paused consumer exited during module audit'
            assert audit.returncode==0,audit.stderr.decode(errors='replace')
            modules=json.loads(audit.stdout);assert {m['ModuleName'].lower() for m in modules}=={'ulk.dll','usk.dll'}
            for item in modules:
                path=Path(item['FileName']);assert path.resolve()==(DELIVERY/'bin'/item['ModuleName']).resolve()
                assert sha(path)==before_delivery['bin/'+item['ModuleName']]
            record['actual_loaded_shared_modules']=modules
            record['factorio_application_linkage']='static_in_produced_cli'
            record['Factorio_shared_DLL_execution_qualified']=False
            record['primary_cmake_source_sha256']=cmake_sources
            release.write_bytes(b'release')
        out,err=process.communicate(timeout=remaining())
        raw_streams_complete=True
        assert not lifetime['deadline_exceeded'] and not lifetime['kill_errors'],'Owned child exceeded lifetime guard'
    except BaseException as error:
        failure=error;entry['cleanup_errors']=[]
        out=getattr(error,'stdout',None) or out;err=getattr(error,'stderr',None) or err
        try:
            if process.poll() is None:process.kill()
        except BaseException as kill_error:entry['cleanup_errors'].append(dict(step='owned_child_kill',error=repr(kill_error)))
        try:
            out,err=process.communicate(timeout=10)
            raw_streams_complete=True
        except BaseException as drain_error:
            if not raw_streams_complete:
                out=getattr(drain_error,'stdout',None) or out;err=getattr(drain_error,'stderr',None) or err
            entry['cleanup_errors'].append(dict(step='bounded_drain',error=repr(drain_error)))
            entry['possible_live_owned_pid']=process.pid if process.poll() is None else None
    finally:
        if timer is not None and process.poll() is not None:timer.cancel()
        entry['lifetime_guard']=lifetime
        entry['raw_streams_complete']=raw_streams_complete
        try:
            if release is not None and not release.exists():release.write_bytes(b'release')
        except BaseException as release_error:
            entry.setdefault('cleanup_errors',[]).append(dict(step='synthetic_pause_release',error=repr(release_error)))
            if failure is None:failure=release_error
        paths={}
        for name,data in [('stdout',out),('stderr',err)]:
            path=command_dir/(f'{index:04d}.'+name)
            try:
                with path.open('xb') as f:f.write(data)
                paths[name]=dict(path=str(path),sha256=sha(path),bytes=len(data))
            except BaseException as custody_error:
                paths[name]=dict(path=str(path),expected_bytes=len(data),custody_error=repr(custody_error))
                if failure is None:failure=custody_error
        with guard:
            entry.update(status='ACTIONABLE_PROCESS_FAILURE' if failure else 'TERMINAL',exit_code=process.poll(),
                streams=paths,seconds=round(time.monotonic()-started,3),error=repr(failure) if failure else None)
            save_locked()

    if failure is not None:raise failure
    return process.returncode,out.decode('utf-8'),err.decode('utf-8')

save()
try:
    original_temporary_directory=tempfile.TemporaryDirectory
    class OwnedTemporaryDirectory(original_temporary_directory):
        def __init__(self,*args,**kwargs):
            kwargs['delete']=False;super().__init__(*args,**kwargs)
            assert Path(self.name).resolve().is_relative_to((W/'t').resolve())
        def __exit__(self,exc_type,exc,tb):
            if exc_type is None:self.cleanup()
            else:
                record.setdefault('preserved_failed_workspaces',[]).append(dict(path=self.name,error=repr(exc)))
                save()
            return False
    tempfile.TemporaryDirectory=OwnedTemporaryDirectory
    import native_cli
    original=native_cli.invoke_machine
    modules=[importlib.import_module(name) for name in ('test_configuration_reconciliation','test_configuration_preparation','test_selected_save_preparation',
        'test_readiness_builtin_content','test_local_modset_solver','test_save_index_retention','test_presentation_profile_preparation',
        'test_portable_modpack_import','test_presentation_pack_import')]
    native_cli.ROOT=DELIVERY
    for module in [native_cli,*modules]:
        for name,value in list(vars(module).items()):
            if value is original:setattr(module,name,invoke)
    config=modules[0]
    with tempfile.TemporaryDirectory(prefix='configuration-package-modules-') as value:
        workspace=Path(value);case=config.ExistingConfigurationTests()
        instance,original,expected=case.prepare(workspace,'load_save',True);preserved=case.preserved(instance)
        args=case.args(workspace,case.query(workspace,'launch_deck','load_save')['revision'],identity='package-modules',scope='launch_deck',intent='load_save')
        code,out,err=invoke(args,env=dict(os.environ,FACMAN_TEST_CONFIGURATION_PAUSE='rewrite_after_write'))
        assert code==0 and not err and json.loads(out)['payload']['outcome']=='completed'
        assert (instance/'config/config.ini').read_bytes()==expected and case.preserved(instance)==preserved
        record['loaded_module_case_preserved_selected_inputs']=True;save()
    helper_path=E/'owned-produced-native-text-child-custody-03.py'
    helper_bytes=helper_path.read_bytes();helper_sha=hashlib.sha256(helper_bytes).hexdigest()
    assert decision['scripts_sha256'][helper_path.name]==helper_sha
    helper=types.ModuleType('produced_text_child_custody');helper.__file__=str(helper_path)
    exec(compile(helper_bytes,str(helper_path),'exec'),helper.__dict__)
    helper.install(CLI,W/'t',command_dir,record,save,DELIVERY)
    record['legacy_child_guard_sha256']=helper_sha
    portable=modules[-2].PortableModpackImportTests;presentation=modules[-1].PresentationPackImportTests
    mixed='test_published_marker_substitution_refuses_and_preserves_incomplete_journal'
    selected=[(portable,n) for n in vars(portable) if n.startswith('test_') and n!=mixed]
    selected += [(presentation,n) for n in vars(presentation) if n.startswith('test_') and n!='test_compiled_content_entry_preserves_inputs_and_adopts_returned_selection']
    assert len(selected)==16
    test_source=R/'tests/test_portable_modpack_import.py'
    tree=ast.parse(test_source.read_text(encoding='utf-8'))
    original_class=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='PortableModpackImportTests')
    method=next(n for n in original_class.body if isinstance(n,ast.FunctionDef) and n.name==mixed)
    loops=[n for n in ast.walk(method) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='substitution']
    assert len(loops)==1 and ast.literal_eval(loops[0].iter)==('dangling_symlink','foreign_bytes')
    loops[0].iter=ast.Tuple(elts=[ast.Constant('foreign_bytes')],ctx=ast.Load())
    selected_tree=ast.fix_missing_locations(ast.Module(body=[method],type_ignores=[]))
    selector=E/'produced-retained-extraction-marker-selector-01.py'
    with selector.open('x',encoding='utf-8') as f:f.write(ast.unparse(selected_tree)+'\n')
    namespace=dict(vars(modules[-2]));exec(compile(selected_tree,str(selector),'exec'),namespace)
    selected_type=type('SelectedForeignMarkerCells',(portable,),{mixed:namespace[mixed]})
    selected.append((selected_type,mixed))
    record.update(selected_methods=[c.__name__+'.'+n for c,n in selected],full_methods=16,
        selected_marker_cells=[dict(point=p,substitution='foreign_bytes') for p in ('published','committed')],
        selector_sha256=sha(selector),original_marker_test_sha256=sha(test_source),
        driver_review_sha256=review_sha256,
        retained_host_gaps=['published dangling_symlink','committed dangling_symlink'],
        original_all17_zero_skip_qualification=False,
        compiled_control_qualified_by_this_run=False);save()
    assert hashlib.sha256(decision_path.read_bytes()).hexdigest()==review_sha256
    suite=unittest.TestSuite(c(n) for c,n in selected)
    testlog=E/'produced-retained-extraction-proof-01-tests.log'
    with testlog.open('x',encoding='utf-8') as stream:result=unittest.TextTestRunner(stream=stream,verbosity=2,failfast=True).run(suite)
    record.update(test_log=str(testlog),test_log_sha256=sha(testlog),tests_run=result.testsRun,skipped=len(result.skipped));save()
    assert result.testsRun==17 and result.wasSuccessful() and not result.skipped
    assert all(x['status']=='TERMINAL' and x['exit_code'] is not None and not x['deadline_exceeded']
        and not x['kill_error'] and 'drain_error' not in x and 'audit_error' not in x and x['raw_streams_complete']
        for x in record['legacy_direct_children'])
    assert all(x['status']=='TERMINAL' and x['raw_streams_complete'] and not x.get('cleanup_errors')
        and not x['lifetime_guard']['deadline_exceeded'] and not x['lifetime_guard']['kill_errors'] for x in record['commands'])
    for child in [*record['commands'],*record['legacy_direct_children']]:
        assert Path(child['cwd']).resolve()==DELIVERY.resolve()
        for stream in child['streams'].values():
            p=Path(stream['path']);assert sha(p)==stream['sha256'] and p.stat().st_size==stream['bytes']
    assert inventory(DELIVERY)==before_delivery and inventory(fixture)==before_fixture
    assert not git('status','--porcelain')
    record.update(status='PASS_EXACT_PRODUCED_WINDOWS_RETAINED_EXTRACTION_PUBLIC_OWNERS',
        commands_total=len(record['commands']),legacy_direct_children_total=len(record['legacy_direct_children']),
        delivery_unchanged=True,source_fixture_unchanged=True,retained_extraction_package_qualified=True,
        POSIX_qualified=False,full_F09_qualified=False,full_F11_qualified=False,
        excluded_scope='16 full public runtime methods plus two foreign-marker cells; two dangling-symlink cells remain host-unqualified; no compiled control/live GUI/game claim',
        completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
    print(json.dumps(dict(status=record['status'],commands=record['commands_total'],legacy_direct_children=record['legacy_direct_children_total'],full_methods=16,foreign_marker_cells=2,skipped=0)),flush=True)
except Exception as error:
    record.update(status='ACTIONABLE_FAILURE',error=repr(error));save();raise
