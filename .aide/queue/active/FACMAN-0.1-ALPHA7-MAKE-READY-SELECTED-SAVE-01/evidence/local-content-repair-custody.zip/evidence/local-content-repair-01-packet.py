import datetime, hashlib, json, re, subprocess, tomllib, zipfile
from pathlib import Path
R=Path('D:/Projects/Factorio/factorio-launcher')
W=Path('D:/Development/FacMan/repositories/factorio-launcher-5db2844e2f29/tasks/task-facman-w-bc5cd0812e')
E=W/'evidence'
U='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
D=R/'.aide/queue/active'/U/'evidence'
BASE='1d5391cb7bf4dcf506eca5819d966a2f025a3717'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def out(*args): return subprocess.check_output(args,cwd=R,text=True,encoding='utf-8').strip()
def read(name): return json.loads((E/name).read_text(encoding='utf-8'))
def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f: json.dump(value,f,indent=2);f.write('\n')
assert out('git','rev-parse','HEAD') == BASE
assert out('git','branch','--show-current') == 'task/facman-world-restore-retention-01'
review=read('local-content-repair-review-03.json')
assert review['status']=='PASS'
for path,digest in review['reviewed_sha256'].items():
    p=Path(path)
    if not p.is_absolute(): p=R/p
    assert sha(p)==digest,(path,'changed after source review')
assert read('local-content-repair-03-build.json')['status']=='PASS'
assert read('local-content-repair-01-solver.json')['status']=='PASS'
cli=W/'native-developer/Debug/facman.exe'
assert sha(cli)=='6369860a65348399de84d9cf2d38347e602c6747601ce7b0d010850d40a494c3'
first=(E/'local-content-repair-01-focused-01.log').read_text(encoding='utf-8')
final=(E/'local-content-repair-01-solver-01.log').read_text(encoding='utf-8')
pattern=r'^test_\S+ \(([^)]+)\) \.\.\. (ok|skipped [^\r\n]+)$'
first_results=dict(re.findall(pattern,first,re.M))
solver_results=dict(re.findall(pattern,final,re.M))
assert len(solver_results)==13 and all(value=='ok' for value in solver_results.values())
passed={key for key,value in first_results.items() if value=='ok'}|set(solver_results)
skipped={key:value for key,value in first_results.items() if value.startswith('skipped')}
assert len(passed)==48 and len(skipped)==1
product_paths=out('git','diff','--name-only').splitlines()
source_hashes={path:sha(R/path) for path in product_paths}
plan_path=R/'release/index/plan.v1.toml'
plan_text=plan_path.read_text(encoding='utf-8')
plan=tomllib.loads(plan_text)
unit=next(unit for unit in plan['workunit'] if unit['id']==U)
assert unit['status']=='active' and len(unit['acceptance'])==2 and len(unit['close_after'])==5
ref=(D/'local-content-repair.v1.json').relative_to(R).as_posix()
assert ref not in unit['evidence']
members={}
def admit(path,member):
    assert path.is_file() and not path.is_symlink()
    assert not (getattr(path.stat(),'st_file_attributes',0)&0x400)
    assert path.suffix.lower() not in {'.exe','.dll','.pdb'}
    assert member not in members
    members[member]=path
for pattern_name in ('local-content-repair*.log','local-content-repair*.json','local-content-repair*.py',
                     'local-content-produced*.json','local-content-produced*.py','local-content-produced*.log'):
    for path in sorted(E.glob(pattern_name)):
        if path.name.endswith('branch-plan.json'): continue
        if path.name not in {p.name for p in members.values()}: admit(path,'evidence/'+path.name)
scenario=W/'instance-configuration-produced-01/local-content-produced-01'
for path in sorted(scenario.rglob('*')):
    if path.is_file(): admit(path,'produced-baseline/'+path.relative_to(scenario).as_posix())
custody=D/'local-content-repair-custody.zip'
with zipfile.ZipFile(custody,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for member,path in sorted(members.items()): z.write(path,member)
receipt=dict(status='PASS_SCOPED_WINDOWS_SOURCE_FIXTURE',work_item=U,base=BASE,
    behavior=['Verify solver-pinned archives and trusted install-derived built-ins without rejecting unselected versions',
              'Retry restored failed apply with a separate rollback identity while retaining all prior evidence',
              'Apply and rollback share the existing instance configuration lock',
              'Human content commands expose owner inventory, selected packages, changes, explanations and rollback identity'],
    source_hashes=source_hashes,CLI_sha256=sha(cli),
    source_review=dict(path='evidence/local-content-repair-review-03.json',sha256=sha(E/'local-content-repair-review-03.json'),status='PASS'),
    verification=dict(baseline=dict(binary_sha256='b39d0495638f7f4a1d11d3ca023f8ce07a4452dee0bd08b10c166d020a3a93d6',
        actual_producer_source=read('local-content-produced-01.json')['producer_source'],packaged_commands=32,
        demonstrated_runtime_defects=2,selected_regression_tests=3,expected_assertion_failures=8,
        log='evidence/local-content-repair-01-baseline.log',sha256=sha(E/'local-content-repair-01-baseline.log')),
        native_build='evidence/local-content-repair-03-build.json',
        first_focused_campaign=dict(status='FAIL_RETAINED_TEST_ORACLE_ISSUES',tests=49,failed_or_error_tests=2,
            not_applicable=1,log='evidence/local-content-repair-01-focused-01.log',sha256=sha(E/'local-content-repair-01-focused-01.log')),
        corrected_solver_module=dict(status='PASS',actual_tests=13,log='evidence/local-content-repair-01-solver-01.log',
            sha256=sha(E/'local-content-repair-01-solver-01.log')),
        qualified_distinct_test_ids=sorted(passed),not_applicable=skipped,
        entire_49_test_campaign_rerun=False,product_source_changed_after_successful_build=False),
    custody=dict(path=custody.relative_to(R).as_posix(),sha256=sha(custody),members=len(members),
        files={member:sha(path) for member,path in sorted(members.items())},executables_included=False,licensed_game_inputs_included=False),
    original_acceptance=unit['acceptance'],close_after=unit['close_after'],whole_workunit_closed=False,
    qualification=dict(current_produced_package=False,genuine_game=False,human_experience=False,Beta=False),
    remaining=['Current-source produced-package replay of corrected verification and retry',
               'Concurrent external source-change acceptance',
               'Solver selection export/offline reconstruction and full content frontend coverage',
               'Original federated Make Ready clauses and three unfinished close-after gates'],
    external_gates_preserved=['PR343 owner-only protected-control gate',
                             'Source-distinct A5-to-A6 produced update/rollback proof',
                             'Genuine game/human and applicable host qualifications'],
    resource_use=dict(new_roots=0,new_worktrees=0,workers=2,heavy_local_jobs=1,
                      retained_native_images_capsule='local-content-repair-01-before-build-images.zip'),
    next_acceptance='Integrate qualified source; inspect current-source produced artifact once and finish remaining local-content acceptance',
    finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
write(D/'local-content-repair.v1.json',receipt)
block='id = "'+U+'"'
start=plan_text.index(block)
end=plan_text.find('\n[[workunit]]',start)
if end<0: end=len(plan_text)
section=plan_text[start:end]
old='  "'+unit['evidence'][-1]+'"\n]'
assert section.count(old)==1
section=section.replace(old,'  "'+unit['evidence'][-1]+'",\n  "'+ref+'"\n]',1)
updated=plan_text[:start]+section+plan_text[end:]
new_plan=tomllib.loads(updated)
new_unit=next(unit for unit in new_plan['workunit'] if unit['id']==U)
expected=dict(unit,evidence=unit['evidence']+[ref])
assert new_unit==expected
plan_path.write_text(updated,encoding='utf-8',newline='\n')
print(json.dumps(dict(status=receipt['status'],receipt=ref,sha256=sha(D/'local-content-repair.v1.json'),
    custody_sha256=sha(custody),distinct_tests_passed=len(passed),not_applicable=len(skipped),whole_workunit_closed=False)))
