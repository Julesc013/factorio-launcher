"""Resume after harness field correction without replaying completed calls."""
import json,os
from pathlib import Path
P=Path(__file__).with_name('local-content-produced-01.py');source=P.read_text(encoding='utf-8')
exec(compile(source.split('try:\n    assert __debug__')[0],str(P),'exec'))
assert __debug__ and os.environ['PYTHONOPTIMIZE']=='0' and os.environ['PYTHONDONTWRITEBYTECODE']=='1'
rec=json.loads(OUT.read_text());assert rec['status']=='FAILED' and rec['failure']=="KeyError('valid')" and rec['commands'][-1]['label']=='malformed-inventory'
with (E/'local-content-produced-01-harness-failure.json').open('x',encoding='utf-8') as f:json.dump(rec,f,indent=2)
with (E/'local-content-produced-01-continuation-2.claim.json').open('x',encoding='utf-8') as f:json.dump({'PID':os.getpid(),'last_command':len(rec['commands'])},f)
rec['harness_correction']='inventory uses validation_status/refusal, not private valid member';rec['status']='CONTINUING';save()
rw=S/'malformed';assert any(x.get('validation_status')=='refused' and x['refusal']['code']=='mod_zip_malformed_info_json' for x in rec['malformed_records'])
before=state(rw);capture('malformed-before',rw)
refusal=run('malformed-refusal',rw,['modsets','plan','solver','--enable','malformed_info'],ok=False);assert refusal['refusal']['code']=='local_dependency_unavailable';assert state(rw)==before;capture('malformed-after',rw);passed('malformed-refusal')
ws=S/'positive';mods=ws/'instances/solver/mods'
archives={p.name:sha(p) for p in (S/'states/positive-initial/instances/solver/mods').glob('*.zip')}
suffix=source[source.index("    for label,fault in"):]
suffix=suffix.replace("rec['status']='PASS'","rec['status']='PARTIAL_WITH_DEMONSTRATED_VERIFY_DEFECT'")
exec(compile('try:\n'+suffix,str(P),'exec'))
