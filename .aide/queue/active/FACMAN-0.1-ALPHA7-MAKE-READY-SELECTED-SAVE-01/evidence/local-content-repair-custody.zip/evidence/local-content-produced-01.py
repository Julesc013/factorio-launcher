"""Single claimed produced-package local-content scenario; no source mutation."""
import hashlib, json, os, shutil, subprocess, sys, traceback, zipfile
from pathlib import Path
R=Path('D:/Projects/Factorio/factorio-launcher')
E=Path(__file__).resolve().parent
W=E.parent
S=W/'instance-configuration-produced-01/local-content-produced-01'
CLI=W/'instance-configuration-produced-01/facman/generations/0.1.0-alpha.6/bin/facman.exe'
OUT=E/'local-content-produced-01.json'
rec={'status':'PENDING','producer_source':'bb0bc47618b6e10347d6a4e91d36911147c3f5d1','consumer_source':'1d5391cb7bf4dcf506eca5819d966a2f025a3717','commands':[],'cells':[],'concurrency':'PENDING_NO_BARRIER','game_execution':False,'human_experience':False}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save():
    t=OUT.with_suffix('.writing'); t.write_text(json.dumps(rec,indent=2)+'\n',encoding='utf-8'); t.replace(OUT)
def tree(p): return {str(x.relative_to(p)):sha(x) for x in sorted(p.rglob('*')) if x.is_file()}
def capture(label, ws):
    d=S/'states'/label; assert not d.exists()
    for p in ws.rglob('*'):
        if p.is_file():
            q=d/p.relative_to(ws); q.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(p,q)
    rec.setdefault('states',{})[label]=tree(d);save()
def state(ws,id='solver'):
    paths=[ws/'instances'/id/'mods/mod-list.json',ws/'instances'/id/'mods/modset-lock.v1.json',ws/'modsets'/f'{id}.modset-lock.v1.json']
    return [p.read_bytes() if p.exists() else None for p in paths]
def run(label,ws,args,ok=True,human=False,fault=None):
    n=len(rec['commands'])+1; stem=S/f'{n:02d}-{label}'
    argv=[str(CLI),'--workspace',str(ws),*args]+([] if human else ['--json'])
    env=os.environ.copy()
    for k in list(env):
        if k.startswith('FACMAN_TEST_') or k.endswith('_FAULT'): env.pop(k)
    if fault:env['FACMAN_MODSET_FAULT']=fault
    entry={'label':label,'argv':argv,'cwd':str(CLI.parent),'supervisor_PID':os.getpid(),'fault':fault}
    with stem.with_suffix('.stdout').open('xb') as out,stem.with_suffix('.stderr').open('xb') as err:
        p=subprocess.Popen(argv,cwd=CLI.parent,env=env,stdout=out,stderr=err)
        entry['PID']=p.pid; rec['commands'].append(entry);save()
        try:p.wait(timeout=30)
        except BaseException:p.kill();p.wait(timeout=10);entry['timeout']=True;save();raise
    entry.update(exit_code=p.returncode,stdout=str(stem.with_suffix('.stdout')),stderr=str(stem.with_suffix('.stderr')),
                 stdout_sha256=sha(stem.with_suffix('.stdout')),stderr_sha256=sha(stem.with_suffix('.stderr')));save()
    assert (p.returncode==0)==ok,(label,p.returncode)
    assert not stem.with_suffix('.stderr').read_bytes(),label
    text=stem.with_suffix('.stdout').read_text(encoding='utf-8')
    if human:return text
    v=json.loads(text);assert v['schema']=='facman.transport_response.v2'
    if ok:assert v['error'] is None;return v['payload']
    return v['payload'] or {'refusal':{'code':v['error']['code']}}
def mod(ws,name,ver,deps):
    p=ws/'instances/solver/mods'/f'{name}_{ver}.zip'
    info={'name':name,'title':name,'version':ver,'factorio_version':'2.0','dependencies':deps}
    z=zipfile.ZipInfo(f'{name}_{ver}/info.json',(2026,7,12,0,0,0));z.external_attr=0o644<<16
    with zipfile.ZipFile(p,'x',compression=zipfile.ZIP_STORED) as f:f.writestr(z,json.dumps(info,sort_keys=True)+'\n')
def setup(label):
    ws=S/label
    run(label+'-import',ws,['installs','import',str(R/'tests/fixtures/fake_factorio_install'),'--id','fixture'])
    run(label+'-create',ws,['instances','create','Solver','--id','solver','--install','fixture'])
    return ws
def passed(name):rec['cells'].append({'name':name,'result':'PASS'});save()
try:
    assert __debug__ and os.environ['PYTHONOPTIMIZE']=='0' and os.environ['PYTHONDONTWRITEBYTECODE']=='1'
    assert not OUT.exists() and not S.exists()
    marker=json.loads((W/'.facman-development-root.v1.json').read_text())
    assert marker['task_id']=='task/facman-world-restore-retention-01'
    assert Path(marker['canonical_path']).resolve()==W.resolve() and Path(marker['source_root']).resolve()==R.resolve()
    doctor=json.loads((E/'local-content-doctor-preflight.log').read_text(encoding='utf-8-sig'))
    assert len(doctor['task_roots'])==8 and doctor['task_root_bytes']+64*1024**2<=20*1024**3
    free=shutil.disk_usage(W).free;assert free>=8*1024**3+64*1024**2
    rec['resource']={'roots':8,'measured_bytes':doctor['task_root_bytes'],'peak_bound_bytes':64*1024**2,'free_bytes':free,'floor_bytes':8*1024**3}
    assert sha(CLI)=='b39d0495638f7f4a1d11d3ca023f8ce07a4452dee0bd08b10c166d020a3a93d6'
    admission=json.loads((E/'instance-configuration-produced-admission-01.json').read_text());assert admission['status']=='ADMITTED_EXISTING_PRODUCED_WINDOWS_DELIVERY' and admission['source']==rec['producer_source']
    rec['CLI_sha256']=sha(CLI);rec['admission_sha256']=sha(E/'instance-configuration-produced-admission-01.json')
    rec['preserved_configuration_before']=tree(W/'instance-configuration-produced-01/scenario')
    with (E/'local-content-produced-01.claim.json').open('x',encoding='utf-8') as f:json.dump({'PID':os.getpid(),'scenario':str(S)},f)
    S.mkdir();save()
    sys.path.insert(0,str(R));from tools import json_contract
    ws=setup('positive');mods=ws/'instances/solver/mods'
    mod(ws,'library','1.0.0',['base >= 2.0']);mod(ws,'library','2.0.0',['base >= 2.0']);mod(ws,'application','1.0.0',['base >= 2.0','library >= 1.0']);mod(ws,'addon','1.0.0',['base >= 2.0'])
    archives={p.name:sha(p) for p in mods.glob('*.zip')};initial=state(ws);capture('positive-initial',ws)
    inv=run('inventory',ws,['mods','list']);assert inv['portal_access'] is False and inv['source_mutation'] is False
    assert not json_contract.validate(inv,json_contract.load_schema(R/'contracts/schema/factorio/factorio_mod_inventory.v1.schema.json'))
    a=['--enable','application','--enable','addon']
    first=run('plan',ws,['modsets','plan','solver',*a]);second=run('permuted-plan',ws,['modsets','plan','solver','--enable','addon','--enable','application']);assert first==second
    assert not json_contract.validate(first,json_contract.load_schema(R/'contracts/schema/factorio/factorio_modset_plan.v1.schema.json'))
    assert next(x['version'] for x in first['desired_mods'] if x['name']=='library')=='2.0.0'
    for command in [['mods','list'],['mods','index','--root',str(mods)],['modsets','plan','solver',*a],['modsets','explain','solver',*a]]:
        run('human-'+command[0]+'-'+command[1],ws,command,human=True)
    assert state(ws)==initial;passed('read-only-deterministic-highest')
    applied=run('apply',ws,['modsets','apply','solver',*a]);capture('applied',ws)
    assert all(x is not None for x in state(ws))
    ml=json.loads(state(ws)[0]);assert {'application','library','addon'}<={x['name'] for x in ml['mods'] if x['enabled']}
    assert state(ws)[1]==state(ws)[2]
    run('verify',ws,['modsets','verify','solver'])
    run('rollback',ws,['modsets','rollback','solver',applied['plan_id']]);assert state(ws)==initial;passed('apply-verify-exact-rollback')
    lock={'lockfile_version':1,'schema':'factorio.modset_lock.v1','instance_id':'solver','factorio_version':'2.0.77','mods':[{'name':'library','version':'1.0.0','enabled':True}]}
    text=(json.dumps(lock,separators=(',',':'))+'\n').encode()
    (mods/'modset-lock.v1.json').write_bytes(text);(ws/'modsets/solver.modset-lock.v1.json').write_bytes(text)
    locked=run('current-lock-preference',ws,['modsets','plan','solver','--enable','application','--prefer','library=2.0.0']);assert next(x['version'] for x in locked['desired_mods'] if x['name']=='library')=='1.0.0';passed('current-lock-over-explicit-preference')
    for label,kind in [('missing','missing'),('conflict','conflict'),('malformed','malformed')]:
        rw=setup(label);rp=rw/'instances/solver/mods'
        if kind=='missing':mod(rw,'needs_missing','1.0.0',['missing >= 1.0']);args=['--enable','needs_missing']
        elif kind=='conflict':mod(rw,'conflict_a','1.0.0',['! conflict_b']);mod(rw,'conflict_b','1.0.0',['base >= 2.0']);args=['--enable','conflict_a','--enable','conflict_b']
        else:
            shutil.copyfile(R/'tests/fixtures/factorio_mods/malformed_info_json/malformed_info_1.0.0.zip',rp/'malformed_info_1.0.0.zip');args=['--enable','malformed_info']
            malformed=run('malformed-inventory',rw,['mods','list']);rec['malformed_records']=malformed['records'];save()
            assert any(not x['valid'] for x in malformed['records'] if not x['virtual_package'])
        before=state(rw);capture(label+'-before',rw)
        refusal=run(label+'-refusal',rw,['modsets','plan','solver',*args],ok=False);assert refusal['refusal']['code']=='local_dependency_unavailable';assert state(rw)==before;capture(label+'-after',rw);passed(label+'-refusal')
    for label,fault in [('apply-fault','after_first_commit'),('rollback-fault','rollback_after_first_restore')]:
        fw=setup(label);mod(fw,'simple','1.0.0',['base >= 2.0']);before=state(fw);capture(label+'-before',fw)
        if label=='apply-fault':
            v=run(label,fw,['modsets','apply','solver','--enable','simple'],ok=False,fault=fault);assert v['refusal']['code']=='modset_fault_injected';assert state(fw)==before;capture(label+'-refused',fw)
            retry=run(label+'-retry',fw,['modsets','apply','solver','--enable','simple']);run(label+'-cleanup-rollback',fw,['modsets','rollback','solver',retry['plan_id']]);assert state(fw)==before
        else:
            v=run(label+'-apply',fw,['modsets','apply','solver','--enable','simple']);appliedstate=state(fw)
            v2=run(label,fw,['modsets','rollback','solver',v['plan_id']],ok=False,fault=fault);assert v2['refusal']['code']=='modset_fault_injected';assert state(fw)==appliedstate;capture(label+'-refused',fw)
            run(label+'-retry',fw,['modsets','rollback','solver',v['plan_id']]);assert state(fw)==before
        capture(label+'-after',fw);passed(label+'-recovery-retry')
    assert archives=={p.name:sha(p) for p in mods.glob('*.zip')}
    assert rec['preserved_configuration_before']==tree(W/'instance-configuration-produced-01/scenario')
    rec['archives']=archives;rec['status']='PASS';save();print('PASS',len(rec['commands']),len(rec['cells']))
except BaseException as exc:
    rec['status']='FAILED';rec['failure']=repr(exc);rec['traceback']=traceback.format_exc();save();print(rec['status'],repr(exc));sys.exit(1)
