"""Continue the single retained packet after verify defect; never replay calls."""
import json, os
from pathlib import Path
P=Path(__file__).with_name('local-content-produced-01.py')
source=P.read_text(encoding='utf-8')
exec(compile(source.split('try:\n    assert __debug__')[0],str(P),'exec'))
assert __debug__ and os.environ['PYTHONOPTIMIZE']=='0' and os.environ['PYTHONDONTWRITEBYTECODE']=='1'
rec=json.loads(OUT.read_text())
assert rec['status']=='FAILED' and rec['commands'][-1]['label']=='verify' and len(rec['commands'])==11
assert rec['commands'][-1]['exit_code']==1
with (E/'local-content-produced-01-initial-failure.json').open('x',encoding='utf-8') as f:json.dump(rec,f,indent=2)
with (E/'local-content-produced-01-continuation.claim.json').open('x',encoding='utf-8') as f:json.dump({'PID':os.getpid(),'last_command':11},f)
rec['cells'].append({'name':'apply-verify','result':'FAIL','defect':'legacy_verify_rejects_solver_lock_virtual_base_and_unselected_versions'})
rec['status']='CONTINUING';save()
sys.path.insert(0,str(R));from tools import json_contract
ws=S/'positive';mods=ws/'instances/solver/mods'
initial=state(S/'states/positive-initial')
archives={p.name:sha(p) for p in (S/'states/positive-initial/instances/solver/mods').glob('*.zip')}
applied=json.loads(Path(rec['commands'][9]['stdout']).read_text())['payload']
suffix=source[source.index("    run('rollback',ws"):]
suffix=suffix.replace("passed('apply-verify-exact-rollback')","passed('exact-rollback-after-verify-defect')")
suffix=suffix.replace("rec['status']='PASS'","rec['status']='PARTIAL_WITH_DEMONSTRATED_VERIFY_DEFECT'")
exec(compile('try:\n'+suffix,str(P),'exec'))
