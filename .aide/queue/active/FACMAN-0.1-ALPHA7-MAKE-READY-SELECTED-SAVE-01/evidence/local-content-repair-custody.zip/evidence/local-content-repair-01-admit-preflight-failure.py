import hashlib, json, shutil, subprocess, tomllib
from pathlib import Path

R = Path('D:/Projects/Factorio/factorio-launcher')
W = Path('D:/Development/FacMan/repositories/factorio-launcher-5db2844e2f29/tasks/task-facman-w-bc5cd0812e')
E = W / 'evidence'
BASE = '1d5391cb7bf4dcf506eca5819d966a2f025a3717'
B = 'task/facman-world-restore-retention-01'
U = 'FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
def out(*args):
    return subprocess.check_output(args, cwd=R, text=True, encoding='utf-8').strip()
assert out('git', 'branch', '--show-current') == 'dev'
assert not out('git', 'status', '--porcelain')
assert out('git', 'rev-parse', 'HEAD') == out('git', 'rev-parse', 'origin/dev') == BASE
assert not out('git', 'branch', '--list', B)
assert not out('git', 'ls-remote', '--heads', 'origin', B)
prior = json.loads((E/'instance-configuration-produced-integration-01.json').read_text(encoding='utf-8'))
assert prior['branch_retired'] and prior['merge_commit'] == BASE
helper = json.loads((R/'.aide/git/latest-helper-plan.json').read_text(encoding='utf-8'))
assert helper['status'] == 'ready_dry_run' and helper['state']['current_commit'] == BASE
assert not helper['state']['worktree_dirty'] and not helper['blockers']
marker = json.loads((W/'.facman-development-root.v1.json').read_text(encoding='utf-8'))
assert marker['task_id'] == B
assert shutil.disk_usage(W).free >= 8*1024**3 + 1024**3
argv = ['git', 'switch', '--no-track', '-c', B, BASE]
plan = dict(schema='facman.exact-base-task-branch-plan.v1', work_item=U, branch=B,
    start_commit=BASE, helper_plan=helper, planned_command=argv,
    scope='Repair demonstrated solver apply verification and preserved-history retry; readable local content results',
    authority='Existing implementation continuation authorizes ordinary task-owned work and qualified integration',
    new_root=False, new_worktree=False, marker_reassigned=False,
    prior_integration=str(E/'instance-configuration-produced-integration-01.json'),
    peak_additional_bytes=1024**3, free_space_reserve_bytes=8*1024**3,
    workers=2, heavy_local_jobs=1, workunit_closed=False)
path=E/'local-content-repair-01-branch-plan.json'
with path.open('x', encoding='utf-8') as f: json.dump(plan,f,indent=2); f.write('\n')
subprocess.run(argv,cwd=R,check=True)
assert out('git','rev-parse','HEAD') == BASE
print(json.dumps(dict(branch=B,base=BASE,plan=str(path),new_root=False)))
