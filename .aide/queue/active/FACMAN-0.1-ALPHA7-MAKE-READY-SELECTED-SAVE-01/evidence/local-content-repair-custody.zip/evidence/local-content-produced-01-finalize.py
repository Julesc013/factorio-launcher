"""Seal measurements for the terminal packet without external commands."""
import json,os
from pathlib import Path
P=Path(__file__).with_name('local-content-produced-01.py');source=P.read_text(encoding='utf-8')
exec(compile(source.split('try:\n    assert __debug__')[0],str(P),'exec'))
assert __debug__ and os.environ['PYTHONOPTIMIZE']=='0' and os.environ['PYTHONDONTWRITEBYTECODE']=='1'
rec=json.loads(OUT.read_text());assert rec['status']=='PARTIAL_WITH_DEMONSTRATED_DEFECTS' and 'terminal_measurements' not in rec
archive_counts={}
for label in ['positive','missing','conflict','malformed','apply-fault','rollback-fault']:
    ws=S/label;old=S/'states'/('positive-initial' if label=='positive' else label+'-before')
    current={str(p.relative_to(ws)):sha(p) for p in ws.rglob('*.zip')}
    expected={str(p.relative_to(old)):sha(p) for p in old.rglob('*.zip')}
    assert current==expected,label;archive_counts[label]=len(current)
human={x['label']:Path(x['stdout']).read_text(encoding='utf-8') for x in rec['commands'] if x['label'].startswith('human-')}
assert len(rec['commands'])==32 and all('exit_code' in x for x in rec['commands'])
assert rec['preserved_configuration_before']==tree(W/'instance-configuration-produced-01/scenario')
rec['terminal_measurements']={'commands':32,'cells_pass':sum(x['result']=='PASS' for x in rec['cells']),'cells_fail':sum(x['result']=='FAIL' for x in rec['cells']),
 'archive_counts':archive_counts,'all_archives_byte_unchanged':True,'old_configuration_byte_unchanged':True,
 'journals':len(list(S.glob('*/transactions/*.json'))),'activation_manifests':len(list(S.glob('*/instances/solver/mods/.facman-modset-history/*/activation.v1.json'))),
 'human_stdout':human,'runtime_dll_sha256':sha(CLI.parent/'flb_factorio.dll'),'producer_package_record_sha256':sha(W/'instance-configuration-produced-01/package-record.v1.json'),
 'scenario_bytes':sum(p.stat().st_size for p in S.rglob('*') if p.is_file()),'pending':['controlled concurrent source changes','solver-owned lock verification','ordinary retry after failed apply','full LocalContent and MakeReady qualification']}
rec['terminal_measurements']['scenario_tree']=tree(S)
save();print(json.dumps({k:v for k,v in rec['terminal_measurements'].items() if k not in ['scenario_tree','human_stdout']},indent=2))
