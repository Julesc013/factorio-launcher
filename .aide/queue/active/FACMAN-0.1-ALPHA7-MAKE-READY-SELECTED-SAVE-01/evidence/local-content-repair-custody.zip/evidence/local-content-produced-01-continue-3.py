"""Finish the independent rollback fault cell; preserve failed apply retry."""
import json,os
from pathlib import Path
P=Path(__file__).with_name('local-content-produced-01.py');source=P.read_text(encoding='utf-8')
exec(compile(source.split('try:\n    assert __debug__')[0],str(P),'exec'))
assert __debug__ and os.environ['PYTHONOPTIMIZE']=='0' and os.environ['PYTHONDONTWRITEBYTECODE']=='1'
rec=json.loads(OUT.read_text());assert rec['status']=='FAILED' and rec['commands'][-1]['label']=='apply-fault-retry' and rec['commands'][-1]['exit_code']==1
with (E/'local-content-produced-01-apply-retry-failure.json').open('x',encoding='utf-8') as f:json.dump(rec,f,indent=2)
with (E/'local-content-produced-01-continuation-3.claim.json').open('x',encoding='utf-8') as f:json.dump({'PID':os.getpid(),'last_command':len(rec['commands'])},f)
rec['cells'].append({'name':'apply-fault-restoration','result':'PASS'})
rec['cells'].append({'name':'apply-fault-ordinary-retry','result':'FAIL','defect':'retained_failed_activation_history_blocks_same_plan'})
rec['status']='CONTINUING';save()
ws=S/'positive';mods=ws/'instances/solver/mods'
archives={p.name:sha(p) for p in (S/'states/positive-initial/instances/solver/mods').glob('*.zip')}
suffix=source[source.index("    for label,fault in"):]
suffix=suffix.replace("[('apply-fault','after_first_commit'),('rollback-fault','rollback_after_first_restore')]","[('rollback-fault','rollback_after_first_restore')]")
suffix=suffix.replace("rec['status']='PASS'","rec['status']='PARTIAL_WITH_DEMONSTRATED_DEFECTS'")
exec(compile('try:\n'+suffix,str(P),'exec'))
