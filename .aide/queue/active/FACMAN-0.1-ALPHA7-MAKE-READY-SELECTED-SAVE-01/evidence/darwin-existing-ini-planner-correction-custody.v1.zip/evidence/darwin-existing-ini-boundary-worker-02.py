import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys
import unittest

R = Path('/mnt/d/Projects/Factorio/factorio-launcher')
E = Path(__file__).resolve().parent
assert os.getuid() == 65534 and os.getgid() == 65534 and os.getgroups() == []
assert os.environ['TMPDIR'] == str(E / 'posix-publication-private-fixtures-01')
sys.path[:0] = [str(R), str(R / 'tests')]
expected = {line.split('==')[0]: line.split('==')[1] for line in (R / 'tools/requirements-dev.lock').read_text().splitlines() if '==' in line}
versions = {name: importlib.metadata.version(name) for name in expected}
assert versions == expected
selection=json.loads((E/'darwin-existing-ini-nonmac-source-assurance-02.json').read_bytes())['test_selection']
class Results(unittest.TextTestResult):
    def __init__(self,*args,**kwargs):super().__init__(*args,**kwargs);self.successes=[];self.subtests=[]
    def addSuccess(self,test):super().addSuccess(test);self.successes.append(test.id())
    def addSubTest(self,test,subtest,err):
        super().addSubTest(test,subtest,err);self.subtests.append(dict(test=test.id(),parameters=str(subtest),passed=err is None))
assurance=json.loads((E/'darwin-existing-ini-nonmac-source-assurance-02.json').read_bytes())
import ast,importlib
mac_source=(R/'tests/test_macos_configuration_reconciliation.py').read_text();tree=ast.parse(mac_source)
mac_class=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='MacOSExistingConfigurationTests')
assert [n.name for n in mac_class.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]==assurance['mac_test_methods']
assert not any(isinstance(n,ast.Call) and getattr(n.func,'attr',getattr(n.func,'id','')) in ('skipTest','SkipTest') for n in ast.walk(tree))
module=importlib.import_module('test_macos_configuration_reconciliation');cls=module.MacOSExistingConfigurationTests
assert cls.__unittest_skip__ and cls.__unittest_skip_why__.startswith('unsupported: ')
mac_static=dict(ast_valid=True,imported_on_linux=True,mandatory_darwin_method_count=14,platform_classification=cls.__unittest_skip_why__,mac_test_methods_executed=0,mac_skips_counted_as_acceptance=0)
suite=unittest.defaultTestLoader.loadTestsFromNames(assurance['remaining_test_names'])
result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=Results).run(suite)
actual=[p for p in result.subtests if 'test_actual_cli_sigkill_at_prefix_write_and_truncate_then_recovery' in p['test']]
new_success=[n for n in result.successes if n.startswith('test_linux_configuration_reconciliation.')]
record = dict(mac_static_validation=mac_static,actual_macos_native_qualification=False,schema='facman.posix_retained_combined_unprivileged_owner_tests.v1',
              status='PASS_LINUX_EXISTING_INI_OWNER_AND_ORDINARY_REGRESSIONS' if result.wasSuccessful() and len(new_success)==0 and len(actual)==0 and result.testsRun==1 and not result.skipped and not any('test_linux_configuration_reconciliation' in str(t) for t,reason in result.skipped) else 'ACTIONABLE_FIXTURE_FAILURE',
              successful_tests=result.successes,subtests=result.subtests,new_linux_methods_passed=len(new_success),actual_cli_sigkill_combinations=len(actual),actual_cli_repeated_prefix_recovery_losses=3 if len(actual)==9 and result.wasSuccessful() else None,failing_tests=[dict(test=str(t),traceback=detail) for t,detail in result.failures+result.errors],reused_accepted_passes=assurance['reuse']['reused_accepted_passes'],test_selection=assurance['remaining_test_names'],tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
              skips=[(str(test), reason) for test,reason in result.skipped],
              cli_sha256=hashlib.sha256(Path(os.environ['FACMAN_CLI_EXE']).read_bytes()).hexdigest(),
              uid=os.getuid(), gid=os.getgid(), groups=os.getgroups(), locked_validators=versions,
              existing_ini_linux_owner_admitted=True, physical_ext4=False, macos=False, game=False, power_loss=False)
out = E / 'darwin-existing-ini-boundary-result-02.json'
with out.open('x') as stream:
    json.dump(record, stream, indent=2); stream.write('\n')
raise SystemExit(0 if record['status'].startswith('PASS_') else 1)
