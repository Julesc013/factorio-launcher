import hashlib, json, subprocess
from pathlib import Path

E = Path(__file__).resolve().parent
W = E.parent
R = Path(r'D:\Projects\Factorio\factorio-launcher')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_bytes())
packet = E/'snapshot-local-install-author-packet-01.json'
assert sha(packet) == '370d7daa72eaf121abb59c810daac58e2475bd64cb50eae2d4a763243dff173f'
p = load(packet)
assert p['head'] == subprocess.check_output(['git','rev-parse','HEAD'], cwd=R, text=True).strip()
assert p['branch'] == subprocess.check_output(['git','branch','--show-current'], cwd=R, text=True).strip()
assert p['head'] == '04ee08d4df646019112fc32e92150098111ac045'
dirty = set(subprocess.check_output(['git','diff','--name-only'], cwd=R, text=True).splitlines())
dirty |= set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'], cwd=R, text=True).splitlines())
assert dirty == set(p['source_files']) and len(dirty) == 43
for name, digest in p['source_files'].items():
    assert sha(R/name) == digest
for name, row in p['artifacts'].items():
    path = (E/name).resolve(strict=True)
    assert path.is_relative_to(W.resolve()) and path.stat().st_size == row['bytes'] and sha(path) == row['sha256']
assert len(p['artifacts']) == 81
assert sha(p['source_patch']['path']) == p['source_patch']['sha256']
assert p['resource_admission']['current_bytes'] + p['resource_admission']['conservative_additional_peak_bytes'] < 20*1024**3
assert p['resource_admission']['free_bytes_before'] - p['resource_admission']['conservative_additional_peak_bytes'] >= 12*1024**3
for path, digest in p['cache_files'].items():
    assert sha(path) == digest
assert sha(p['windows_cli']['path']) == p['windows_cli']['sha256']
for item in p['qualification']['final_checks']:
    assert item['exit_code'] == 0 and sha(item['raw_log']) == item['raw_log_sha256']

for name, count, suffix in [('test_snapshot_local_install', 8, '04'), ('test_instance_snapshots', 5, '04'), ('test_environment_reconstruction', 3, '06')]:
    raw = (E/f'snapshot-local-install-windows-{name}-{suffix}.log').read_text(encoding='utf-8')
    assert f'Ran {count} tests' in raw and '\nOK' in raw and 'FAILED' not in raw
    if name == 'test_snapshot_local_install':
        assert 'skipped=1' in raw
native = (E/'snapshot-local-install-windows-native-03.log').read_text(encoding='utf-8')
assert '100% tests passed, 0 tests failed out of 5' in native
linux = load(E/'snapshot-local-install-linux-private-result-04.json')
assert linux['status'] == 'FAIL_RETAINED'  # the environment import failure is not a pass
assert not linux['physical_ext4'] and linux['private_tmpfs_bytes'] == 128*1024**2
def hostpath(value):
    assert value.startswith('/mnt/d/')
    return Path('D:/'+value[len('/mnt/d/'):])
for command in linux['commands']:
    assert command['termination'] == 'completed' and command['namespace_children_empty']
    for stream in ('stdout', 'stderr'):
        assert sha(hostpath(command[stream])) == command[stream+'_sha256']
    if command['name'] == 'test_environment_reconstruction':
        assert command['exit_code'] != 0
        assert 'ModuleNotFoundError' in hostpath(command['stderr']).read_text(encoding='utf-8')
    else:
        assert command['exit_code'] == 0
for name, count in [('test_snapshot_local_install', 8), ('test_instance_snapshots', 5)]:
    raw = (E/f'snapshot-local-install-linux-private-{name}-04.stderr').read_text(encoding='utf-8')
    assert f'Ran {count} tests' in raw and '\nOK' in raw and 'skipped' not in raw and 'FAILED' not in raw
assert '100% tests passed, 0 tests failed out of 5' in (E/'snapshot-local-install-linux-private-native-04.stdout').read_text(encoding='utf-8')
assert p['preservation']['private_fixture_unmounted'] and p['preservation']['private_fixture_parent_empty']
assert p['preservation']['all_private_command_children_empty']
assert not p['preservation']['current_linux']['relevant_remaining_processes']
for key in ('real_factorio_executed','provider_source_edits','new_persistent_roots','new_provider_caches','new_worktrees','commits','pushes','ci_runs'):
    assert not p['preservation'][key]

helper = (R/'runtime/transaction/fl_transaction_snapshot_restore.cpp').read_text(encoding='utf-8')
snapshot = (R/'runtime/factorio/snapshots/flb_factorio_snapshots.cpp').read_text(encoding='utf-8')
recovery = (R/'runtime/transaction/fl_transaction.cpp').read_text(encoding='utf-8')
assert 'bytes == (expect_empty ? std::string() : snapshot_restore_lock_text(record, lock))' in helper
assert 'parent.revalidate().ok()' in helper and 'Never rewrite it merely' in helper
assert 'POSIX\'s final compare/unlink interval remains observable' in helper
assert snapshot.index('lease.lock.create(') < snapshot.index('TransactionSession::begin(workspace, std::move(transaction))', snapshot.index('lease.lock.create('))
assert 'session.leave_durable_state_unchanged();' in snapshot and 'if (!lease.release(write_detail))' in snapshot
assert 'record_json(current) != record_json(record)' in recovery
assert 'if (bound_snapshot && terminal(record.state))' in recovery
assert 'restored_from_install_ref' in snapshot and 'selected_install' in snapshot

out = E/'snapshot-local-install-independent-review-01.json'
assert not out.exists()
result = dict(schema='facman.independent_snapshot_local_install_review.v1',
    verdict='PASS_SCOPED_SOURCE_FOR_REQUIRED_CURRENT_CI', base=p['head'], branch=p['branch'],
    non_authoring=True, packet_sha256=sha(packet), source_files_sha256=p['source_files'],
    reviewer_script_sha256=sha(__file__), artifacts_verified=81,
    actual_source_review=['CLI and JSON selected-install dispatch','same captured bytes for installation record decoding and generated configuration',
        'exact inspected archive source binding','selected installation root/executable/base/state identity and content',
        'deterministic regenerated target inventory','writer lease before journal and recovery post-lock reload',
        'held lease bytes/path/parent validation and checked release','journal destructor disengagement on proved lease loss',
        'foreign/torn staging and targets preserved','legacy journal and filesystem shape explicit','provenance and full environment regression'],
    windows_native=5, windows_new_snapshot_applicable=7, windows_existing_snapshot=5, windows_environment=3,
    linux_private_tmpfs_native=5, linux_new_snapshot=8, linux_existing_snapshot=5,
    linux_same_inode_foreign_bytes_writer_and_recovery_preserved=True,
    linux_environment_cases_locally_executed=0, hosted_current_head_environment_pass_required=True,
    final_post_test_deltas_reviewed='CLI single-return formatting, unsupported skip prefix, generated truth and qualification prose',
    required_current_CI_pending=True, produced_current_package_pending=True, workunit_closed=False,
    real_game=False, physical_ext4=False, posix_atomic_byte_conditioned_unlink=False,
    new_roots=0,new_caches=0,new_clones=0,new_worktrees=0, beta=False,rc=False)
out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ('source_files_sha256','actual_source_review')},indent=2))
