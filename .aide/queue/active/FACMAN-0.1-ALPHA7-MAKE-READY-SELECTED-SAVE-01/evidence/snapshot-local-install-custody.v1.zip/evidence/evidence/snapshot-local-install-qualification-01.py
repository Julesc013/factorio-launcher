import datetime, hashlib, json, os, pathlib, shutil, subprocess, sys
R=pathlib.Path(r"D:\Projects\Factorio\factorio-launcher")
W=pathlib.Path(r"D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e")
E=W/"evidence"; B=W/"native-developer"
env=os.environ.copy();env.update(FACMAN_DEV_ROOT=r"D:\Projects\Factorio\.task-builds",TEMP=str(W/"t"),TMP=str(W/"t"),PYTHONDONTWRITEBYTECODE="1",PYTHONUTF8="1",FACMAN_MIN_FREE_GIB="12",CMAKE_BUILD_PARALLEL_LEVEL="2",MSBUILDDISABLENODEREUSE="1")
def git(*a): return subprocess.check_output(["git","-c","core.safecrlf=false",*a],cwd=R,text=True,encoding="utf-8").strip()
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
changed=set(git("diff","--name-only").splitlines()+git("ls-files","--others","--exclude-standard").splitlines());before={p:digest(R/p) for p in changed if (R/p).is_file()}
fixture={str(p.relative_to(R)):digest(p) for p in (R/"tests/fixtures/fake_factorio_install").rglob("*") if p.is_file()}
doctor=json.loads((E/"snapshot-local-install-doctor-01.json").read_text(encoding="utf-8-sig"))
assert len(doctor["task_roots"])==8 and doctor["task_root_bytes"]+2*1024**3 <20*1024**3 and set(doctor["violations"]) <= {"unmanaged_secondary_worktrees_present"}
assert shutil.disk_usage(W).free-2*1024**3 >=12*1024**3
resource={"doctor":str(E/"snapshot-local-install-doctor-01.json"),"current_bytes":doctor["task_root_bytes"],"conservative_additional_peak_bytes":2*1024**3,"peak_within_20GiB":True,"free_bytes_before":shutil.disk_usage(W).free,"reserve_bytes":12*1024**3,"build_roots":{"windows":str(B),"linux":str(W/"native-save-context-linux")},"profiles":{"windows":"Visual Studio 18 2026/Release/source","linux":"Ninja/Debug/source"},"pins":{"ULK":"5479939ca5cbc9ee0f901608a92012778b4752ae","USK":"2749a15b835a6c1c9968598a2b434d85809691ad"},"workers":2,"one_heavy_job":True,"source_before":before}
(E/"snapshot-local-install-resource-01.json").write_text(json.dumps(resource,indent=2)+"\n",encoding="utf-8")
record={"schema":"facman.snapshot_local_install_qualification.v1","source_head":git("rev-parse","HEAD"),"branch":git("branch","--show-current"),"started_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"commands":[],"real_factorio_executed":False,"provider_changed":False}
def run(name,argv,timeout=1800):
 log=E/("snapshot-local-install-"+name+"-01.log")
 assert not log.exists(),log
 with log.open("x",encoding="utf-8") as f:
  child=subprocess.Popen(argv,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
  try: code=child.wait(timeout=timeout)
  except BaseException:
   if child.poll() is None:
    subprocess.run(["taskkill","/PID",str(child.pid),"/T","/F"],capture_output=True,timeout=30);child.wait(timeout=30)
   raise
 record["commands"].append({"name":name,"argv":argv,"PID":child.pid,"exit_code":code,"raw_log":str(log),"raw_log_sha256":digest(log)})
 (E/"snapshot-local-install-windows-result-01.json").write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8")
 print(json.dumps(record["commands"][-1]),flush=True)
 if code:
  print(log.read_text(encoding="utf-8",errors="replace")[-6000:],flush=True)
  raise SystemExit(code)
targets=["facman_cli","facman_application_types_smoke","facman_snapshot_policy_smoke","fl_workspace_store_smoke","fl_transaction_session_smoke","fl_workspace_root_authority_smoke"]
argv=["py","-3","-B","tools/dev.py","build","developer","--task-root",str(W),"--build-root",str(B),"--configuration","Release"]
for t in targets:argv += ["--target",t]
run("windows-build",argv)
run("windows-native",["ctest","--test-dir",str(B),"-C","Release","--output-on-failure","--no-tests=error","-R","^(facman_application_types_smoke|facman_snapshot_policy_smoke|fl_workspace_store_smoke|fl_transaction_session_smoke|fl_workspace_root_authority_smoke)$"])
exe=B/"Release/facman.exe";env["FACMAN_CLI_EXE"]=str(exe)
for name in ["test_snapshot_local_install","test_instance_snapshots","test_environment_reconstruction"]:
 run("windows-"+name,["py","-3","-B","-m","unittest","discover","-s","tests","-p",name+".py","-v"],600)
assert before=={p:digest(R/p) for p in before},"Source changed during qualification"
assert fixture=={str(p.relative_to(R)):digest(p) for p in (R/"tests/fixtures/fake_factorio_install").rglob("*") if p.is_file()},"Fixture inputs changed"
record.update(result="pass",source_unchanged=True,fixture_inputs_unchanged=True,cli=str(exe),cli_sha256=digest(exe),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(E/"snapshot-local-install-windows-result-01.json").write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"result":"pass","receipt":str(E/"snapshot-local-install-windows-result-01.json")}),flush=True)
