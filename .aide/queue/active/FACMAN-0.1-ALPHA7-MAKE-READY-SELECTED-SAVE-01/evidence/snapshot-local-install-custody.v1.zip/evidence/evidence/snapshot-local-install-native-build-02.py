import json, pathlib, subprocess, sys
sys.path.insert(0,str(pathlib.Path.cwd()))
from tools import native_build
root=pathlib.Path(sys.argv[1])
marker=json.loads((root.parent/".facman-development-root.v1.json").read_text())
assert marker["task_id"]=="task/facman-world-restore-retention-01"
assert root.name=="native-developer"
native_build.require_disk_reserve(root)
argv=native_build.command(root,"Release",sys.argv[2:],{})
print(repr(argv),flush=True)
raise SystemExit(subprocess.run(argv,check=False).returncode)
