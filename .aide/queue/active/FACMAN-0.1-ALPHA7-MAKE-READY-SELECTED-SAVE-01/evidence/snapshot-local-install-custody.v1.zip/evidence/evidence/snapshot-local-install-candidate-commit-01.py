import hashlib, json, os, subprocess, traceback, zipfile, sys
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher'); E=Path(__file__).resolve().parent; W=E.parent
BASE='04ee08d4df646019112fc32e92150098111ac045'; BRANCH='task/facman-snapshot-local-install-01'
ITEM='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'; Q='.aide/queue/active/'+ITEM
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),
 PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.safecrlf',GIT_CONFIG_VALUE_0='false')
sys.path.insert(0,str(R)); from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
dirty=lambda:set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
out=E/'snapshot-local-install-candidate-commit-result-01.json'; assert not out.exists()
record=dict(status='QUALIFYING_REVIEWED_LOCAL_INSTALL_RESTORE',commands=[],new_roots=0,new_clones=0,new_worktrees=0)
def save():out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
def run(label,args,timeout=180,codes=(0,)):
 r=owned.command(args,cwd=R,environment=dict(os.environ),timeout=timeout,directory=E/('snapshot-local-install-commit01-'+label),
  output_limit=8*1024**2,wait_for_job_empty_after_primary=True)
 record['commands'].append(dict(label=label,exit=r.returncode,receipt_sha256=sha(r.directory/'receipt.json')));save()
 assert r.returncode in codes and r.receipt['termination']=='completed' and r.receipt['primary_stopped'] and r.receipt['job_empty_observed'],(label,(r.stdout[-1500:]+r.stderr[-1500:]).decode('utf-8','replace'))
 return r
try:
 assert git('rev-parse','HEAD')==BASE and git('branch','--show-current')==BRANCH and not git('diff','--cached','--name-only')
 packet=E/'snapshot-local-install-author-packet-01.json';p=json.loads(packet.read_bytes())
 review=E/'snapshot-local-install-independent-review-01.json';v=json.loads(review.read_bytes())
 assert v['verdict']=='PASS_SCOPED_SOURCE_FOR_REQUIRED_CURRENT_CI' and v['packet_sha256']==sha(packet)
 expected=set(p['source_files']);assert dirty()==expected
 for name,digest in p['source_files'].items():assert sha(R/name)==digest
 for label in ('policy','detect','plan'):run(label,['py','-3','-B','.aide/scripts/aide_lite.py','git',label])
 run('paths',['py','-3','-B','tools/workspace_hygiene.py','paths'])
 h=json.loads(run('doctor',['py','-3','-B','tools/workspace_hygiene.py','doctor','--measure'],600,(0,1)).stdout)
 assert set(h['violations'])<={'unmanaged_secondary_worktrees_present'} and len(h['task_roots'])==8 and h['task_root_bytes']<20*1024**3
 artifacts=[E/name for name in p['artifacts']]+[packet,review,E/'snapshot-local-install-independent-review-01.py',Path(__file__)]
 manifest={}
 for path in artifacts:
  path=path.resolve(strict=True);assert path.is_relative_to(W.resolve()) and path.suffix.lower() not in ('.exe','.dll','.zip')
  manifest['evidence/'+path.relative_to(W).as_posix()]=sha(path)
 archive=R/Q/'evidence/snapshot-local-install-custody.v1.zip';evidence=R/Q/'evidence/snapshot-local-install.v1.json'
 assert not archive.exists() and not evidence.exists();archive.parent.mkdir(exist_ok=True)
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
  z.writestr('custody-manifest.json',json.dumps(manifest,indent=2,sort_keys=True)+'\n')
  for name in sorted(manifest):z.write(W/name.removeprefix('evidence/'),name)
 with zipfile.ZipFile(archive) as z:
  assert set(z.namelist())==set(manifest)|{'custody-manifest.json'}
  for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
 assert archive.stat().st_size<8*1024**2
 evidence.write_text(json.dumps(dict(schema='facman.snapshot_local_install.qualified_source.v1',base_head=BASE,
  base_tree=git('rev-parse',BASE+'^{tree}'),author_packet_sha256=sha(packet),independent_review_sha256=sha(review),
  authored_files_sha256=p['source_files'],windows_native=5,windows_new_snapshot_applicable=7,windows_existing_snapshot=5,windows_environment=3,
  linux_private_tmpfs_native=5,linux_new_snapshot=8,linux_existing_snapshot=5,linux_environment_cases_locally_executed=0,
  hosted_current_head_environment_pass_required=True,explicit_local_install_bound=True,archived_provenance_preserved=True,
  active_writer_and_recovery_same_lease=True,foreign_same_inode_bytes_preserved=True,verified_unpublished_recovery='rolled_back',
  original_package_silently_ignored_install_option=True,physical_ext4=False,posix_atomic_byte_conditioned_unlink=False,
  custody=archive.name,custody_sha256=sha(archive),custody_files=len(manifest),
  required_checks_pending=True,produced_package_qualified=False,workunit_closed=False,
  real_game_qualified=False,human_qualified=False,beta=False,rc=False,new_roots=0,new_clones=0,new_worktrees=0),indent=2)+'\n',encoding='utf-8')
 plan=R/Q/'ExecPlan.md';assert plan.is_file()
 with plan.open('a',encoding='utf-8',newline='\n') as f:
  f.write('\n### Selected local installation during snapshot reconstruction\n\n'
   'The restore owner now accepts an explicit compatible registered installation,\n'
   'regenerates local configuration against the exact captured record, and retains\n'
   'the archive installation identifier as provenance. The ordinary environment\n'
   'reconstruction no longer registers a duplicate original installation ID.\n\n'
   'New transactions bind the selected installation, inspected archive and final\n'
   'inventory. Writer and recovery share a checked lease; foreign or torn evidence\n'
   'is retained. Verified unpublished staging rolls back; exact publication can\n'
   'finalize. Historical unbound journals keep their recorded legacy behavior.\n\n'
   'Windows focused reconstruction and native tests pass. Linux private tmpfs\n'
   'passes the affected native and snapshot suites, including both live same-inode\n'
   'foreign metadata cases. Local Linux environment cases did not execute because\n'
   'referencing/rpds are absent; required hosted current-head execution must pass.\n'
   'Qualification is recorded in evidence/snapshot-local-install.v1.json and its\n'
   'hash-closed custody. Delivered-package proof and required checks remain open;\n'
   'F11, real-game execution and release gates remain open.\n')
 allowed=expected|{Q+'/ExecPlan.md',Q+'/evidence/'+archive.name,Q+'/evidence/'+evidence.name}
 run('project-state',['py','-3','-B','tools/project_state.py','--write'],600)
 run('metadata',['py','-3','-B','tools/codegen/generate_metadata.py','--write'])
 changed=dirty();assert changed==allowed
 for name,digest in p['source_files'].items():
  if name not in {'.aide/memory/project-state.md','.aide/memory/project-state.v2.json','README.md'}:assert sha(R/name)==digest
 run('strict',['py','-3','-B','tools/strict_check.py'],1800)
 run('portable-aide',['py','-3','-B','.aide/scripts/aide_lite.py','test'],1800)
 message=('feat(snapshots): restore against a selected local installation\n\n'
  'Bind reconstruction and recovery to the selected local record while\n'
  'preserving archive provenance and refusing changed or foreign data.\n\n'
  'Work-Item: '+ITEM+'\nEvidence-Ref: '+Q+'/evidence/'+evidence.name+'\n')
 msg=E/'snapshot-local-install-candidate-commit-message-01.txt';msg.write_text(message,encoding='utf-8',newline='\n')
 run('message',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--message',message])
 changes=[dict(path=name,state='content',sha256=sha(R/name),git_blob_oid=git('hash-object','--path',name,str(R/name)),ownership='task_owned') for name in sorted(changed)]
 digest=hashlib.sha256((json.dumps(changes,indent=2,sort_keys=True,separators=(',',': '))+'\n').encode()).hexdigest()
 cr=E/'snapshot-local-install-candidate-commit-review-01.json'
 cr.write_text(json.dumps(dict(schema_version='aide.git-commit-review.v1',verdict='PASS',reviewer='/root',
  author='/root/managed_update_acceptance',non_authoring=True,branch=BRANCH,base_commit=BASE,snapshot_sha256=digest,message_sha256=sha(msg),
  independent_source_review_sha256=sha(review),review='Independently reviewed selected-install dispatch, exact source/binding/inventory/lease recovery and81 retained artifacts; current hosted CI and delivered proof remain required'),indent=2)+'\n',encoding='utf-8')
 classification=E/'snapshot-local-install-candidate-commit-classification-01.json'
 classification.write_text(json.dumps(dict(schema_version='aide.git-commit-classification.v1',branch=BRANCH,base_commit=BASE,
  work_item=ITEM,snapshot_sha256=digest,message_sha256=sha(msg),changed_paths=changes,
  reviews=[dict(path=str(cr),sha256=sha(cr),verdict='PASS')]),indent=2)+'\n',encoding='utf-8')
 helper=['py','-3','-B','.aide/scripts/aide_lite.py','git','commit-plan','--classification',str(classification),'--message-file',str(msg)]
 run('plan-stage',helper);run('stage',['git','add','--',*sorted(changed)]);run('staged-diff',['git','diff','--cached','--check']);run('plan-commit',helper)
 assert git('rev-parse','HEAD')==BASE;run('commit',['git','commit','-F',str(msg)],600)
 run('range',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--range',BASE+'..HEAD'])
 remaining=git('diff','--name-only').splitlines()
 if remaining:
  assert set(remaining)<={'.aide/memory/project-state.md','.aide/memory/project-state.v2.json','README.md'}
  for name in remaining:assert git('hash-object','--path',name,str(R/name))==git('rev-parse','HEAD:'+name)
  run('refresh-generated-index',['git','add','--',*remaining])
 assert not git('status','--porcelain') and not git('diff','--cached','--name-only')
 record.update(status='COMMITTED_REVIEWED_SNAPSHOT_LOCAL_INSTALL_CANDIDATE',source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),
  review_sha256=sha(cr),evidence_sha256=sha(evidence),required_checks_pending=True,remote_not_pushed=True,workunit_closed=False)
except BaseException as error:record.update(status='ACTIONABLE_SNAPSHOT_LOCAL_INSTALL_COMMIT_FAILURE',error=str(error),traceback=traceback.format_exc())
finally:save();print(json.dumps({k:v for k,v in record.items() if k not in ('commands','traceback')},indent=2))
raise SystemExit(0 if record['status']=='COMMITTED_REVIEWED_SNAPSHOT_LOCAL_INSTALL_CANDIDATE' else 1)
