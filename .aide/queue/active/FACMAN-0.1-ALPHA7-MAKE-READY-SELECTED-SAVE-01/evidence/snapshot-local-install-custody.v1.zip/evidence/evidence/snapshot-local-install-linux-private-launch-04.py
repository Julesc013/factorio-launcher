import hashlib,json,os,subprocess
from pathlib import Path
E=Path(__file__).resolve().parent
probe=['wsl.exe','-d','Ubuntu-24.04','-u','root','--exec','readlink','/proc/self/ns/mnt']
namespace=subprocess.check_output(probe,text=True).strip()
driver='/mnt/d/'+str(E/'snapshot-local-install-linux-private-driver-04.py')[3:].replace('\\','/')
argv=['wsl.exe','-d','Ubuntu-24.04','-u','root','--exec','env','FACMAN_PARENT_MOUNT_NAMESPACE='+namespace,'timeout','--signal=TERM','--kill-after=15s','1800s','unshare','--mount','--pid','--fork','--mount-proc','--kill-child=SIGKILL','python3','-B',driver]
log=E/'snapshot-local-install-linux-private-launch-04.log'
with log.open('x',encoding='utf-8') as output:code=subprocess.run(argv,stdout=output,stderr=subprocess.STDOUT,timeout=1845).returncode
(E/'snapshot-local-install-linux-private-launch-04.json').write_text(json.dumps({'argv':argv,'exit_code':code,'parent_mount_namespace':namespace,'raw_log':str(log),'raw_log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()},indent=2)+'\n',encoding='utf-8')
print(log.read_text(encoding='utf-8'),flush=True);raise SystemExit(code)
