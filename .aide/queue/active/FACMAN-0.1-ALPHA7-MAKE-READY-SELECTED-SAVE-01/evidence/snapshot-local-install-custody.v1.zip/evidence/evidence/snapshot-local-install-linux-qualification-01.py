import datetime,hashlib,json,os,pathlib,shutil,subprocess
R=pathlib.Path(r"D:\Projects\Factorio\factorio-launcher");W=pathlib.Path(r"D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e");E=W/"evidence";L=W/"native-save-context-linux"
linuxW="/mnt/d/Projects/Factorio/.task-builds/repositories/factorio-launcher-5db2844e2f29/tasks/task-facman-w-bc5cd0812e";linuxR="/mnt/d/Projects/Factorio/factorio-launcher";linuxL=linuxW+"/native-save-context-linux"
windows=json.loads((E/"snapshot-local-install-windows-result-06.json").read_text());assert windows.get("result")=="pass"
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(["git","-c","core.safecrlf=false",*a],cwd=R,text=True,encoding="utf-8").strip()
changed=set(git("diff","--name-only").splitlines()+git("ls-files","--others","--exclude-standard").splitlines());before={p:digest(R/p) for p in changed if (R/p).is_file()};fixture={str(p.relative_to(R)):digest(p) for p in (R/"tests/fixtures/fake_factorio_install").rglob("*") if p.is_file()}
cache=L/"CMakeCache.txt";cache_before=cache.read_text()
for expected in ["CMAKE_BUILD_TYPE:STRING=Debug","CMAKE_GENERATOR:INTERNAL=Ninja","FACMAN_PROVIDER_MODE:STRING=source","universal-setup-2749a15b835a","universal-launcher-5479939ca5cb","CMAKE_HOME_DIRECTORY:INTERNAL="+linuxR]:assert expected in cache_before,expected
assert shutil.disk_usage(W).free-2*1024**3>=12*1024**3
common=["wsl.exe","-d","Ubuntu-24.04","--cd",linuxR,"--","env","FACMAN_DEV_ROOT=/mnt/d/Projects/Factorio/.task-builds","TMPDIR="+linuxW+"/t","TEMP="+linuxW+"/t","TMP="+linuxW+"/t","PYTHONDONTWRITEBYTECODE=1","PYTHONUTF8=1","FACMAN_MIN_FREE_GIB=12","CMAKE_BUILD_PARALLEL_LEVEL=2","FACMAN_CLI_EXE="+linuxL+"/facman"]
record={"schema":"facman.snapshot_local_install_linux_qualification.v1","source_head":git("rev-parse","HEAD"),"started_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"commands":[],"real_factorio_executed":False,"provider_changed":False,"source_before":before}
def run(name,args,timeout=1800):
 log=E/("snapshot-local-install-linux-"+name+"-01.log");assert not log.exists()
 argv=common+args
 with log.open("x",encoding="utf-8") as f:
  child=subprocess.Popen(argv,cwd=R,stdout=f,stderr=subprocess.STDOUT)
  try:code=child.wait(timeout=timeout)
  except BaseException:
   if child.poll() is None:
    subprocess.run(["taskkill","/PID",str(child.pid),"/T","/F"],capture_output=True,timeout=30);child.wait(timeout=30)
   raise
 record["commands"].append({"argv":argv,"PID":child.pid,"exit_code":code,"raw_log":str(log),"raw_log_sha256":digest(log)})
 (E/"snapshot-local-install-linux-result-01.json").write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8");print(json.dumps(record["commands"][-1]),flush=True)
 if code:print(log.read_text(encoding="utf-8",errors="replace")[-6000:],flush=True);raise SystemExit(code)
targets=["facman_cli","facman_application_types_smoke","facman_snapshot_policy_smoke","fl_workspace_store_smoke","fl_transaction_session_smoke","fl_workspace_root_authority_smoke"]
run("build",["cmake","--build",linuxL,"--parallel","2","--target",*targets])
run("native",["ctest","--test-dir",linuxL,"--output-on-failure","--no-tests=error","-R","^(facman_application_types_smoke|facman_snapshot_policy_smoke|fl_workspace_store_smoke|fl_transaction_session_smoke|fl_workspace_root_authority_smoke)$"])
for name in ["test_snapshot_local_install","test_instance_snapshots","test_environment_reconstruction"]:run(name,["python3","-B","-m","unittest","discover","-s","tests","-p",name+".py","-v"],600)
assert before=={p:digest(R/p) for p in before};assert fixture=={str(p.relative_to(R)):digest(p) for p in (R/"tests/fixtures/fake_factorio_install").rglob("*") if p.is_file()}
cache_after=cache.read_text()
for expected in ["CMAKE_BUILD_TYPE:STRING=Debug","CMAKE_GENERATOR:INTERNAL=Ninja","FACMAN_PROVIDER_MODE:STRING=source","universal-setup-2749a15b835a","universal-launcher-5479939ca5cb","CMAKE_HOME_DIRECTORY:INTERNAL="+linuxR]:assert expected in cache_after,expected
record.update(result="pass",source_unchanged=True,fixture_inputs_unchanged=True,cli_sha256=digest(L/"facman"),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(E/"snapshot-local-install-linux-result-01.json").write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8");print(json.dumps({"result":"pass","receipt":str(E/"snapshot-local-install-linux-result-01.json")}),flush=True)
