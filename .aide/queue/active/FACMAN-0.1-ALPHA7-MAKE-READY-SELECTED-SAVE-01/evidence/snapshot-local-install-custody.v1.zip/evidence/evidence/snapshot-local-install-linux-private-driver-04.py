import datetime,hashlib,json,os,signal,subprocess,time,traceback
from pathlib import Path
R=Path('/mnt/d/Projects/Factorio/factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent;L=W/'native-save-context-linux';M=E/'posix-publication-private-fixtures-01'
assert os.getpid()==1 and os.getuid()==0 and os.readlink('/proc/self/ns/mnt')!=os.environ['FACMAN_PARENT_MOUNT_NAMESPACE']
marker=json.loads((W/'.facman-development-root.v1.json').read_text());assert marker['owner']=='facman-development' and marker['task_id']=='task/facman-world-restore-retention-01'
os.environ.update(GIT_CONFIG_COUNT='2',GIT_CONFIG_KEY_0='core.autocrlf',GIT_CONFIG_VALUE_0='true',GIT_CONFIG_KEY_1='core.filemode',GIT_CONFIG_VALUE_1='false',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',FACMAN_DEV_ROOT='/mnt/d/Projects/Factorio/.task-builds',TMPDIR=str(W/'t'),TMP=str(W/'t'),TEMP=str(W/'t'),FACMAN_CLI_EXE=str(L/'facman'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
paths=set(git('diff','--name-only').splitlines()+git('ls-files','--others','--exclude-standard').splitlines());before={p:sha(R/p) for p in paths if (R/p).is_file()};fixture={str(p.relative_to(R)):sha(p) for p in (R/'tests/fixtures/fake_factorio_install').rglob('*') if p.is_file()}
cache=(L/'CMakeCache.txt').read_bytes();images={p.name:sha(p) for p in L.iterdir() if p.is_file() and p.name.startswith(('libusk','libulk'))};executables={name:sha(L/name) for name in ['facman','facman_application_types_smoke','facman_snapshot_policy_smoke','fl_workspace_store_smoke','fl_transaction_session_smoke','fl_workspace_root_authority_smoke']}
out=E/'snapshot-local-install-linux-private-result-04.json';assert not out.exists()
record={'schema':'facman.snapshot_local_install_private_linux_qualification.v1','status':'prepared','source_head':git('rev-parse','HEAD'),'source_before':before,'native_images_sha256':executables,'provider_images_before':images,'mount_namespace':os.readlink('/proc/self/ns/mnt'),'pid_namespace':os.readlink('/proc/self/ns/pid'),'private_tmpfs_bytes':128*1024**2,'physical_ext4':False,'real_factorio_executed':False,'new_persistent_roots':0,'new_caches':0,'commands':[]}
def save():out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
def reap():
 while True:
  try:pid,_=os.waitpid(-1,os.WNOHANG)
  except ChildProcessError:break
  if pid==0:break
def run(name,args,timeout=600):
 stdout=E/('snapshot-local-install-linux-private-'+name+'-04.stdout');stderr=stdout.with_suffix('.stderr');item={'name':name,'argv':[str(a) for a in args],'stdout':str(stdout),'stderr':str(stderr)};record['commands'].append(item);save()
 with stdout.open('xb') as o,stderr.open('xb') as er:
  child=subprocess.Popen(item['argv'],cwd=R,stdout=o,stderr=er,stdin=subprocess.DEVNULL,start_new_session=True);item.update(pid=child.pid,pgid=os.getpgid(child.pid));assert item['pgid']==child.pid
  try:code=child.wait(timeout=timeout);item['termination']='completed'
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=30);item['termination']='timed_out'
  try:os.killpg(child.pid,0);alive=True
  except ProcessLookupError:alive=False
  if alive:os.killpg(child.pid,signal.SIGKILL)
  deadline=time.monotonic()+5
  while True:
   reap();remaining=[n for n in os.listdir('/proc') if n.isdigit() and int(n)!=1]
   if not remaining or time.monotonic()>=deadline:break
   time.sleep(.02)
 item.update(exit_code=code,owned_group_cleanup=alive,namespace_children_empty=not remaining,stdout_sha256=sha(stdout),stderr_sha256=sha(stderr));save();assert code==0 and item['termination']=='completed' and item['namespace_children_empty'],name
mounted=False;save()
try:
 assert M.is_dir() and not list(M.iterdir()) and not os.path.ismount(M)
 assert os.statvfs(W).f_bavail*os.statvfs(W).f_frsize>=12*1024**3
 run('mount',['mount','-t','tmpfs','-o','size=128m,nosuid,nodev,mode=1777','facman-snapshot-local-install',M],30);mounted=True
 os.environ.update(TMPDIR=str(M),TMP=str(M),TEMP=str(M))
 assert os.statvfs(M).f_blocks*os.statvfs(M).f_frsize==128*1024**2
 record['fixture_filesystem']=subprocess.check_output(['stat','-f','-c','%T',M],text=True).strip();save()
 run('native',['ctest','--test-dir',L,'--output-on-failure','--no-tests=error','-R','^(facman_application_types_smoke|facman_snapshot_policy_smoke|fl_workspace_store_smoke|fl_transaction_session_smoke|fl_workspace_root_authority_smoke)$'])
 for name in ['test_snapshot_local_install','test_instance_snapshots','test_environment_reconstruction']:run(name,['python3','-B','-m','unittest','discover','-s','tests','-p',name+'.py','-v'],600)
 assert before=={p:sha(R/p) for p in before};assert fixture=={str(p.relative_to(R)):sha(p) for p in (R/'tests/fixtures/fake_factorio_install').rglob('*') if p.is_file()};assert cache==(L/'CMakeCache.txt').read_bytes();assert images=={p.name:sha(p) for p in L.iterdir() if p.is_file() and p.name.startswith(('libusk','libulk'))};assert executables=={p:sha(L/p) for p in executables}
 record.update(status='PASS_SCOPED_PRIVATE_TMPFS',source_unchanged=True,fixture_inputs_unchanged=True,cache_unchanged=True,provider_images_unchanged=True,native_images_unchanged=True,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
except BaseException as error:record.update(status='FAIL_RETAINED',error=str(error),traceback=traceback.format_exc())
finally:
 if mounted:
  try:run('unmount',['umount',M],30)
  except BaseException as error:record.update(status='FAIL_RETAINED',unmount_error=str(error))
 record['private_fixture_unmounted']=not os.path.ismount(M);record['private_fixture_parent_empty']=not list(M.iterdir());save();print(json.dumps({'status':record['status'],'error':record.get('error'),'private_fixture_unmounted':record['private_fixture_unmounted'],'private_fixture_parent_empty':record['private_fixture_parent_empty']}),flush=True)
raise SystemExit(0 if record['status']=='PASS_SCOPED_PRIVATE_TMPFS' else 1)
