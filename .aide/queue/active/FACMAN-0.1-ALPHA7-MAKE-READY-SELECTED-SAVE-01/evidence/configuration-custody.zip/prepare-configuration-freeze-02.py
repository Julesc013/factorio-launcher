"""Resolve reviewed discovery defect and freeze once; no native work."""
import datetime, hashlib, json, os, subprocess, sys, unittest
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher'); E=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((E/'configuration-source-freeze-01.json').read_text())
prior=json.loads((E/'configuration-source-preflight-01.json').read_text())
assert not (E/'configuration-source-freeze-02.json').exists()
assert prior['status']=='source_preflight_pass_requires_exact_independent_review_and_native_qualification'
assert sha(E/'configuration-source-preflight-01.json')==old['source_preflight_sha256']
for s in prior['steps']: assert s['exit_code']==0 and sha(Path(s['log']))==s['log_sha256']
changed='tests/test_configuration_preparation.py'
for p,h in old['changed_paths_raw_sha256'].items():
    if p!=changed: assert sha(R/p)==h,p
assert sha(R/changed)!=old['changed_paths_raw_sha256'][changed]
env=dict(os.environ,FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',FACMAN_TASK_ROOT=str(E.parent),
    TEMP=str(E.parent/'t'),TMP=str(E.parent/'t'),PYTHONOPTIMIZE='0',PYTHONPATH=os.pathsep.join([str(R/'tests'),str(R)]))
os.environ.update(env); sys.path[:0]=[str(R/'tests'),str(R)]
modules=['test_configuration_preparation','test_selected_save_preparation','test_readiness_builtin_content',
    'test_save_index_retention','test_presentation_service','test_presentation_profile_preparation','test_presentation_intent',
    'test_local_modset_solver.LocalModsetSolverTests.test_applied_selection_exports_exact_lock_and_only_selected_archives']
suite=unittest.defaultTestLoader.loadTestsFromNames(modules)
assert not unittest.defaultTestLoader.errors,unittest.defaultTestLoader.errors
assert suite.countTestCases()==59,suite.countTestCases()
discovery=E/'configuration-discovery-02.log'
with discovery.open('x') as f:f.write('Discovery only: 59 methods; test methods executed: 0\n')
record=dict(prior,steps=[s for s in prior['steps'] if s['name'] not in {'strict','diff'}],
    retained_preflight_sha256=sha(E/'configuration-source-preflight-01.json'),
    resolved_review_sha256=sha(E/'configuration-source-review-01.json'),discovery_only_methods=59)
record['steps'].append(dict(name='discovery',exit_code=0,log=str(discovery),log_sha256=sha(discovery)))
for name,args in [('strict',['py','-3','tools/strict_check.py']),('diff',['git','diff','--check'])]:
    log=E/('configuration-preflight-02-'+name+'.log')
    with log.open('xb') as f:
        result=subprocess.run(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=900)
    assert result.returncode==0,(name,result.returncode,str(log))
    record['steps'].append(dict(name=name,exit_code=0,log=str(log),log_sha256=sha(log)))
for item in record['changed_paths']:item['sha256']=sha(R/item['path'])
record['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
preflight=E/'configuration-source-preflight-02.json'
with preflight.open('x',encoding='utf-8') as f:json.dump(record,f,indent=2);f.write('\n')
runner=(E/'qualify-configuration-01.py').read_text().replace('configuration-source-freeze-01','configuration-source-freeze-02').replace('configuration-source-review-01','configuration-source-review-02').replace('configuration-qualification-01','configuration-qualification-02').replace('configuration-source-preflight-01','configuration-source-preflight-02').replace('configuration-q01','configuration-q02')
runner=runner.replace('    frozen()\n    review =', "    assert sha(Path(__file__).resolve()) == freeze['qualification_runner_sha256']\n    frozen()\n    review =")
runner=runner.replace("    assert review['changed_paths_raw_sha256'] == freeze['changed_paths_raw_sha256']", "    assert review['changed_paths_raw_sha256'] == freeze['changed_paths_raw_sha256']\n    assert review['qualification_runner_sha256'] == sha(Path(__file__).resolve())")
runnerpath=E/'qualify-configuration-02.py'
with runnerpath.open('x',encoding='utf-8',newline='\n') as f:f.write(runner)
compile(runner,str(runnerpath),'exec')
freeze=dict(old,changed_paths_raw_sha256={p:sha(R/p) for p in old['changed_paths_raw_sha256']},
    source_preflight_sha256=sha(preflight),qualification_runner_sha256=sha(runnerpath),
    prior_freeze_sha256=sha(E/'configuration-source-freeze-01.json'),
    review_correction='Module-qualified fixture prevents duplicate unittest discovery; runner self-SHA admission added',
    created_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
with (E/'configuration-source-freeze-02.json').open('x',encoding='utf-8') as f:json.dump(freeze,f,indent=2);f.write('\n')
print(json.dumps(dict(freeze_sha256=sha(E/'configuration-source-freeze-02.json'),runner_sha256=sha(runnerpath),
    changed_paths=27,discovered_methods=59,native_runs=0)))
