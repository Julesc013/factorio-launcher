"""Single reviewed campaign in the existing owned cache, no packaging."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import traceback

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
W, B = E.parent, E.parent / 'native-developer'
F = E / 'configuration-source-freeze-02.json'
V = E / 'configuration-source-review-02.json'
OUT = E / 'configuration-qualification-02.json'
env = dict(os.environ, FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',
    FACMAN_TASK_ROOT=str(W), TEMP=str(W / 't'), TMP=str(W / 't'),
    CMAKE_BUILD_PARALLEL_LEVEL='2', FACMAN_MIN_FREE_GIB='10', PYTHONOPTIMIZE='0',
    PYTHONPATH=os.pathsep.join([str(R / 'tests'), str(R)]))
os.environ['CMAKE_BUILD_PARALLEL_LEVEL'] = '2'
sys.path.insert(0, str(R))
from tools import native_build, provider_workspace
freeze = json.loads(F.read_text())
record = dict(schema='facman.configuration_qualification.v1', status='running',
    source_parent=freeze['base'], source_freeze_sha256='', source_review_sha256='', steps=[],
    new_roots=0, new_worktrees=0, new_clones=0, new_candidates=0, native_workers=2,
    missing_configuration_component_available=True, full_make_ready_execution_available=False, play_authority=False, visible_UI_acceptance=False, real_game_effects=False,
    whole_workunit_closed=False, beta_qualified=False, prior_q02_timeout_resolved=False)

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git', *args], cwd=R, text=True).rstrip('\r\n')
def save(): OUT.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
def frozen():
    assert git('rev-parse', 'HEAD') == freeze['base']
    assert git('branch', '--show-current') == freeze['branch']
    assert not git('diff', '--cached', '--name-only')
    assert {p[3:] for p in git('status', '--porcelain', '--untracked-files=all').splitlines()} == set(freeze['changed_paths_raw_sha256'])
    assert {p: sha(R / p) for p in freeze['changed_paths_raw_sha256']} == freeze['changed_paths_raw_sha256']

def step(name, args, timeout=300, accepted=(0,)):
    frozen()
    log = E / ('configuration-q02-' + name + '.log')
    started = time.monotonic()
    print('START ' + name, flush=True)
    with log.open('xb') as stream:
        child = subprocess.Popen(args, cwd=R, env=env, stdout=stream, stderr=subprocess.STDOUT)
        try: child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            child.kill()
            child.wait(timeout=30)
            record['steps'].append(dict(name=name, command=args, timeout_seconds=timeout,
                owned_pid=child.pid, log=str(log), log_sha256=sha(log), status='TIMEOUT'))
            save()
            raise
    record['steps'].append(dict(name=name, command=args, exit_code=child.returncode,
        seconds=round(time.monotonic() - started, 3), log=str(log), log_sha256=sha(log)))
    save()
    print('DONE ' + name + ': ' + str(child.returncode), flush=True)
    if child.returncode not in accepted:
        print('\n'.join(log.read_text(errors='replace').splitlines()[-65:]), flush=True)
        raise RuntimeError(name + ' failed; full log retained: ' + str(log))
    return log

assert __debug__ and not OUT.exists()
assert F.exists() and V.exists()
try:
    assert sha(Path(__file__).resolve()) == freeze['qualification_runner_sha256']
    frozen()
    review = json.loads(V.read_text())
    assert review['verdict'] == 'PASS' and review['independent'] and review['non_authoring']
    assert review['freeze_sha256'] == sha(F)
    assert review['changed_paths_raw_sha256'] == freeze['changed_paths_raw_sha256']
    assert review['qualification_runner_sha256'] == sha(Path(__file__).resolve())
    record.update(source_freeze_sha256=sha(F), source_review_sha256=sha(V))
    preflight_path=E/'configuration-source-preflight-02.json'; preflight=json.loads(preflight_path.read_text())
    assert sha(preflight_path)==freeze['source_preflight_sha256']
    assert preflight['status']=='source_preflight_pass_requires_exact_independent_review_and_native_qualification'
    assert {p['path']:p['sha256'] for p in preflight['changed_paths']}==freeze['changed_paths_raw_sha256']
    for entry in preflight['steps']:assert entry['exit_code']==0 and sha(Path(entry['log']))==entry['log_sha256']
    record.update(retained_preflight_sha256=sha(preflight_path),product_change_requires_fresh_native=True)
    marker = json.loads((W / '.facman-development-root.v1.json').read_text(encoding='utf-8-sig'))
    assert marker['kind'] == 'task-root' and Path(marker['canonical_path']).resolve() == W.resolve()
    assert Path(marker['source_root']).resolve() == R.resolve() and marker['task_id'] == freeze['branch']
    assert B.is_dir() and (W / 't').is_dir()
    with (E / 'configuration-qualification-02.claim.json').open('x') as stream:
        json.dump(dict(pid=os.getpid(), freeze_sha256=sha(F)), stream)
    step('paths', ['py', '-3', 'tools/workspace_hygiene.py', 'paths'])
    doctor_log = step('doctor', ['py', '-3', 'tools/workspace_hygiene.py', 'doctor', '--measure'], accepted=(0, 1))
    doctor = json.loads(doctor_log.read_text())
    assert set(doctor['violations']) <= {'unmanaged_secondary_worktrees_present', 'merged_local_task_branches_present'}
    assert len(doctor['task_roots']) <= 8 and doctor['task_root_bytes'] + 2147483648 <= 21474836480
    record['resources'] = dict(task_root_bytes=doctor['task_root_bytes'], reserved_peak_bytes=2147483648,
        free_before_bytes=shutil.disk_usage(W).free, retained_findings=doctor['violations'])
    query = "Get-CimInstance Win32_Process | Where-Object { ($_.Name -match '^(cmake|MSBuild|cl|link|ninja|ctest)\\.exe$' -and $_.CommandLine -notmatch '[-/]nodemode:') -or ($_.Name -eq 'dotnet.exe' -and $_.CommandLine -match ' (build|msbuild) ') } | Select-Object ProcessId,Name | ConvertTo-Json -Compress"
    deadline, previous = time.monotonic() + 1200, None
    while True:
        active = subprocess.check_output(['powershell', '-NoProfile', '-Command', query], text=True).strip()
        if not active: break
        if active != previous:
            record.setdefault('preserved_foreign_heavy_jobs', []).append(active)
            save()
            print('Existing heavy job owns machine: ' + active, flush=True)
            previous = active
        assert time.monotonic() < deadline, 'Heavy-job deadline; no duplicate build started'
        time.sleep(10)
    providers = freeze['provider_roots_reused_readonly']
    components = provider_workspace.locked_components(R)
    for key, alias in (('universal_launcher', 'ULK'), ('universal_setup', 'USK')):
        provider_workspace.verify_checkout(Path(providers[alias]), components[key])
    step('generated-before-build', ['py', '-3', 'tools/codegen/generate_contracts.py', '--check'])
    targets = ['facman_cli', 'flb_factorio_instance_model_smoke', 'facman_presentation_service_smoke', 'fl_transaction_session_smoke']
    assert shutil.disk_usage(W).free >= 10737418240
    step('configure', ['cmake', '-S', str(R), '-B', str(B),
        '-DFACMAN_PROVIDER_SOURCE_LINKAGE=shared', '-DFACMAN_WARNINGS_AS_ERRORS=ON',
        '-DFLAUNCH_UNIVERSAL_LAUNCHER_ROOT=' + providers['ULK'],
        '-DFLAUNCH_UNIVERSAL_SETUP_ROOT=' + providers['USK']])
    step('build', native_build.command(B, 'Release', targets, {}), timeout=2400)
    exe = B / 'Release/facman.exe'
    env.update(FACMAN_CLI_EXE=str(exe), FACMAN_NATIVE_CLI=str(exe))
    record['binaries'] = {p.name: dict(path=str(p), sha256=sha(p), bytes=p.stat().st_size)
        for p in sorted((B / 'Release').glob('*')) if p.suffix.lower() in {'.exe', '.dll'}}
    native = step('native', ['ctest', '--test-dir', str(B), '-C', 'Release', '--output-on-failure',
        '-R', '^(' + '|'.join(targets[1:]) + ')$'], timeout=300).read_text()
    assert '100% tests passed, 0 tests failed out of 3' in native and 'Skipped' not in native
    modules = ['test_configuration_preparation', 'test_selected_save_preparation', 'test_readiness_builtin_content', 'test_save_index_retention', 'test_presentation_service',
        'test_presentation_profile_preparation', 'test_presentation_intent',
        'test_local_modset_solver.LocalModsetSolverTests.test_applied_selection_exports_exact_lock_and_only_selected_archives']
    focused = step('focused', ['py', '-3', '-B', '-m', 'unittest', '-v', *modules], timeout=900).read_text()
    match = re.search(r'Ran (\d+) tests in ', focused)
    assert match and int(match.group(1)) == 59 and '\nOK\n' in focused and 'skipped=' not in focused and 'FAILED' not in focused
    record['tests'] = dict(native_passed=3, focused_passed=int(match.group(1)), skipped=0, new_methods=13)
    legacy = json.loads((E / 'presentation-intent-legacy-frozen.json').read_text(encoding='utf-8-sig'))
    workspace, receipt = Path(legacy['workspace']), Path(legacy['receipt_path'])
    def inventory(): return {p.relative_to(workspace).as_posix(): sha(p) for p in workspace.rglob('*') if p.is_file()}
    assert sha(receipt) == legacy['receipt_sha256'] and inventory() == legacy['workspace_inventory_sha256']
    record['historical_replays'] = []
    for index, (label, intent) in enumerate((('absent-default', None), ('explicit-menu', 'menu'), ('different-intent-conflict', 'load_save')), 1):
        args = [str(exe), *legacy['replay_argv'][1:]]
        if intent is not None: args += ['--intent', intent]
        result = subprocess.run(args, cwd=R, env=env, capture_output=True, timeout=45)
        streams = {}
        for name, data in [('stdout', result.stdout), ('stderr', result.stderr)]:
            path = E / ('configuration-q02-legacy-' + str(index) + '.' + name)
            with path.open('xb') as stream: stream.write(data)
            streams[name] = dict(path=str(path), sha256=sha(path))
        value = json.loads(result.stdout)
        assert not result.stderr
        if intent != 'load_save': assert result.returncode == 0 and value['payload'] == json.loads(legacy['result_json'])
        else: assert result.returncode != 0 and value['error']['code'] == 'idempotency_key_conflict'
        assert sha(receipt) == legacy['receipt_sha256'] and inventory() == legacy['workspace_inventory_sha256']
        record['historical_replays'].append(dict(label=label, exit_code=result.returncode, streams=streams, workspace_unchanged=True))
    step('generated', ['py', '-3', 'tools/codegen/generate_contracts.py', '--check'])
    step('diff', ['git', 'diff', '--check'])
    frozen()
    record.update(status='PASS', resources={**record['resources'], 'free_after_bytes':shutil.disk_usage(W).free})
    save()
    print(json.dumps(dict(status='PASS', tests=record['tests'], historical_replays=3)), flush=True)
except Exception as error:
    record.update(status='ACTIONABLE_FAILURE', error=str(error), traceback=traceback.format_exc())
    save()
    print(traceback.format_exc(), flush=True)
    raise
