"""Admit the existing dependency-ready outcome without allocating a root."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tomllib

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
U = 'FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
B = 'task/facman-world-restore-retention-01'
H = 'fbc721fcf6bfd1d441b58a883855621eda3c0d37'
P = E/'make-ready-admission-01-plan.json'
C = E/'make-ready-admission-01.claim.json'
Q = R/'.aide/queue/next'/U
sys.path.insert(0, str(R/'.aide/scripts'))
import aide_lite


def out(*a):
    c = subprocess.run(a,cwd=R,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=120)
    assert c.returncode == 0,(a[:4],c.returncode,c.stderr[:600])
    return c.stdout.strip()


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f: f.write(json.dumps(v,indent=2)+'\n')


def log(n,*a):
    with (E/('make-ready-admission-01-'+n+'.log')).open('x',encoding='utf-8') as f:
        c = subprocess.run(a,cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=600)
    assert c.returncode == 0,(n,c.returncode)


assert __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0' and not P.exists() and not C.exists()
assert out('git','branch','--show-current') == 'dev' and out('git','rev-parse','HEAD') == out('git','rev-parse','origin/dev') == H
assert not out('git','status','--porcelain')
old_path = E/'world-restore-recovery-integration-04.json'
assert sha(old_path) == 'd11dfc1f65e150f5f20de7f63a1ad2c6dddb514f2b0c7f666a7f18807e605673'
old = json.loads(old_path.read_text())
assert old['status'] == 'integration_and_automatic_merge_CI_pass' and old['merge'] == H and old['branch_retired'] and old['whole_workunit_closed']
marker_path = E.parent/'.facman-development-root.v1.json'
marker = json.loads(marker_path.read_text())
assert Path(marker['canonical_path']).samefile(E.parent) and Path(marker['source_root']).samefile(R) and marker['task_id'] == B
plan = tomllib.loads((R/'release/index/plan.v1.toml').read_text())
u = next(x for x in plan['workunit'] if x['id'] == U)
assert u['status'] == 'planned' and not u['depends_on'] and Q.is_dir()
assert len([x for x in plan['workunit'] if x['status'] == 'active']) < plan['wip_limit']
assert out('powershell','-NoProfile','-Command','[System.Security.Principal.WindowsIdentity]::GetCurrent().Name') == 'BLACKGLASS-WIN1\\Jules'
auth = subprocess.run(['gh','auth','status'],cwd=R,capture_output=True,timeout=60); assert auth.returncode == 0
assert out('gh','api','user','--jq','.login') == 'Julesc013'
assert out('gh','api','repos/Julesc013/factorio-launcher/git/ref/heads/dev','--jq','.object.sha') == H
assert not out('git','ls-remote','--heads','origin','refs/heads/'+B)
assert subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/'+B],cwd=R).returncode == 1
assert json.loads(out('gh','pr','list','--repo','Julesc013/factorio-launcher','--head',B,'--state','open','--json','number')) == []
for name,extra in [('paths',[]),('doctor',['--measure'])]:
    c = subprocess.run([sys.executable,'-B','tools/workspace_hygiene.py',name,*extra],cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
    d = json.loads(c.stdout); write(E/('make-ready-admission-01-'+name+'.json'),d)
    if name == 'doctor':
        assert c.returncode in {0,1} and set(d['violations']) <= {'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
        assert len(d['task_roots']) <= 8 and d['task_root_bytes']+32*1024**2 <= 20*1024**3
    else: assert c.returncode == 0
assert shutil.disk_usage(E).free >= 8*1024**3+32*1024**2
for op in ['inspect','noop-check','recover']:
    log('task-'+op,sys.executable,'-B','.aide/scripts/aide_lite.py','task',op,'--task-id',U)
for op in ['policy','detect','plan']:
    log('git-'+op,sys.executable,'-B','.aide/scripts/aide_lite.py','git',op)
helper = aide_lite.make_git_helper_plan(R,'plan'); assert helper['status'] == 'ready_dry_run' and not helper['blockers']
inputs = {p:sha(R/p) for p in ['release/index/plan.v1.toml','.aide/queue/index.yaml',Q.relative_to(R).as_posix()+'/task.yaml',Q.relative_to(R).as_posix()+'/status.yaml']}
argv = ['git','switch','--no-track','-c',B,H]
write(P,dict(schema='facman.exact-base-task-branch-plan.v1',work_item=U,branch=B,start_commit=H,helper_plan=helper,
    planned_command=argv,operator_authority='Standing compact-restart authorization for new sequential dependency-ready implementation from latest qualified dev; existing marker-owned branch identifier/root reused only after prior exact-head merged task retirement',
    root_reuse=dict(path=str(E.parent),marker_sha256=sha(marker_path),immutable_owner_identity=marker,reason='Same source/toolchain/native cache; prior WorldRestore unit closed, its unique receipts/source preserved in integrated dev. One new WorkUnit in this branch incarnation; root and marker ownership are not reassigned.'),
    canonical_input_hashes=inputs,original_acceptance=u['acceptance'],close_after_preserved=u['close_after'],
    new_roots=0,new_worktrees=0,builds=0,candidate_dispatches=0,review_required_before_qualified_commit=True,
    script_sha256=sha(Path(__file__)),created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
for p,digest in inputs.items(): assert sha(R/p) == digest,p
write(C,dict(PID=os.getpid(),plan_sha256=sha(P),no_automatic_replay=True))
log('branch-create',*argv)
log('task-start',sys.executable,'-B','.aide/scripts/aide_lite.py','task','start','--task-id',U)
active = R/'.aide/queue/active'/U
assert active.is_dir() and not Q.exists()
path = active/'task.yaml'; text = path.read_text()
needle = '  - ".aide/queue/next/'+U+'/**"'
assert text.count(needle) == 1
extras = ['.aide/queue/active/'+U+'/**','.aide/queue/index.yaml','release/index/plan.v1.toml','release/index/current_state.v1.toml','release/index/project_status.v2.toml','.aide/memory/project-state.md','.aide/memory/project-state.v2.json','README.md','todo.md','CMakeLists.txt']
text = text.replace(needle,needle+'\n'+''.join('  - '+json.dumps(p)+'\n' for p in extras).rstrip())
path.write_text(text,encoding='utf-8',newline='\n')
path = R/'release/index/plan.v1.toml'; text = path.read_text(); start = text.index('id = "'+U+'"'); end = text.index('\n[[workunit]]',start); block = text[start:end]
assert block.count('status = "planned"') == block.count('horizon = "backlog"') == 1
block = block.replace('status = "planned"','status = "active"').replace('horizon = "backlog"','horizon = "next"').replace('.aide/queue/next/'+U+'/task.yaml','.aide/queue/active/'+U+'/task.yaml')
text = text[:start]+block+text[end:]
old_primary = 'primary_workunit = "FACMAN-0.1-ALPHA6-SETUP-NATIVE-RECOVERY-01"'; assert text.count(old_primary) == 1
path.write_text(text.replace(old_primary,'primary_workunit = "'+U+'"'),encoding='utf-8',newline='\n')
parsed = tomllib.loads(path.read_text()); new = next(x for x in parsed['workunit'] if x['id'] == U)
assert new['acceptance'] == u['acceptance'] and new['close_after'] == u['close_after'] and parsed['active_release'] == plan['active_release']
for p in [active/'task.yaml',active/'status.yaml',R/'.aide/queue/index.yaml']:
    p.write_text(p.read_text(),encoding='utf-8',newline='\n')
for name,args in [('plan-generate',['tools/generate_plan_views.py']),('state-generate',['tools/project_state.py','--write']),('plan-check',['tools/generate_plan_views.py','--check']),('state-check',['tools/project_state.py','--validate'])]:
    log(name,sys.executable,'-B',*args)
assert sha(marker_path) == json.loads(P.read_text())['root_reuse']['marker_sha256']
write(E/'make-ready-admission-01.json',dict(status='existing_MakeReady_workunit_active_for_implementation',work_item=U,base=H,branch=B,original_acceptance=u['acceptance'],close_after=u['close_after'],source_scope='Implement explicit typed local preparation using existing instance/profile/content/save owners; selected-save stays distinct from menu; no global atomicity or new engine',
    prior_original_machine_workunit_closed=True,new_roots=0,new_worktrees=0,builds=0,candidate_dispatches=0,acceptance_complete=False,full_programme_complete=False,finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
print(json.dumps(dict(status='MakeReady_admitted',work_item=U,base=H,branch=B,new_roots=0,source_root=str(E.parent))))
