"""Preserve qualified binaries, build once, and validate the bounded correction."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
BUILD = E.parent/'native-developer'
CLI = BUILD/'Debug/facman.exe'
CLAIM = E/'make-ready-intent-source-proof-02.claim.json'
RECEIPT = E/'make-ready-intent-source-proof-02.json'
BRANCH = 'task/facman-world-restore-retention-01'
sys.path.insert(0,str(R))
from tools import development_layout


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def out(*a):
    c = subprocess.run(a,cwd=R,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=120)
    assert c.returncode == 0,(a[:4],c.returncode,c.stderr[:600])
    return c.stdout.strip()


def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f: f.write(json.dumps(v,indent=2)+'\n')


def update(v):
    t = RECEIPT.with_suffix('.json.writing'); write(t,v); t.replace(RECEIPT)


def log(n,argv,timeout):
    p = E/('make-ready-intent-source-proof-02-'+n+'.log')
    with p.open('x',encoding='utf-8') as f:
        c = subprocess.run(argv,cwd=R,env=os.environ.copy(),stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
    result = dict(check=n,exit_code=c.returncode,log=str(p),sha256=sha(p))
    if c.returncode != 0:
        record['checks'].append(result); update(record)
        raise AssertionError((n,c.returncode,str(p)))
    return result


assert __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0' and not CLAIM.exists() and not RECEIPT.exists()
assert out('git','branch','--show-current') == BRANCH and out('git','rev-parse','HEAD') == 'fbc721fcf6bfd1d441b58a883855621eda3c0d37'
marker = development_layout.read_marker(E.parent,R); assert marker['task_id'] == BRANCH
assert json.loads((E/'make-ready-intent-regression-baseline.json').read_text())['status'] == 'demonstrated_menu_readiness_profile_intent_mismatch'
heavy = out('powershell','-NoProfile','-Command',"@(Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('MSBuild.exe','cl.exe','ninja.exe','cmake.exe') } | Select-Object ProcessId,Name) | ConvertTo-Json -Compress")
assert heavy in {'','[]'},'An existing heavy native job must finish before this one'
memory = int(out('powershell','-NoProfile','-Command','(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory'))*1024
assert memory >= 4*1024**3
for name,extra in [('paths',[]),('doctor',['--measure'])]:
    c = subprocess.run([sys.executable,'-B','tools/workspace_hygiene.py',name,*extra],cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
    d = json.loads(c.stdout); write(E/('make-ready-intent-source-proof-02-'+name+'.json'),d)
    if name == 'doctor':
        assert c.returncode in {0,1} and set(d['violations']) <= {'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
        assert len(d['task_roots']) <= 8 and d['task_root_bytes']+2*1024**3+64*1024**2 <= 20*1024**3
    else: assert c.returncode == 0
assert shutil.disk_usage(E).free >= 8*1024**3+2*1024**3+64*1024**2
prior = json.loads((E/'make-ready-intent-source-proof-01.json').read_text())
assert prior['status'] == 'stopped_for_actionable_failure' and prior['native_builds'] == 1
assert len(prior['checks']) == 2 and prior['checks'][0]['check'] == 'build' and prior['checks'][1]['check'] == 'native-model'
assert sha(CLI) == prior['CLI_sha256']
archive = Path(prior['old_qualified_native_images']['path'])
assert archive.parent == E and sha(archive) == prior['old_qualified_native_images']['sha256']
digests = prior['old_qualified_native_images']['members']
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist()) == set(digests)
    for n,digest in digests.items(): assert hashlib.sha256(z.read(n)).hexdigest() == digest
source_paths = ['runtime/factorio/instance/flb_factorio_instance_model.cpp','tests/test_profiles_templates.py','apps/cli/command_dispatch.cpp','apps/cli/report_text.cpp','apps/cli/report_text.h','docs/architecture/instance_model_and_readiness.md']
source_hashes = {p:sha(R/p) for p in source_paths}
write(CLAIM,dict(PID=os.getpid(),script_sha256=sha(Path(__file__)),source_hashes=source_hashes,created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),no_automatic_replay=True))
record = dict(prior_failure_receipt_sha256=sha(E/'make-ready-intent-source-proof-01.json'),status='admitted_one_heavy_source_build',base=out('git','rev-parse','HEAD'),branch=BRANCH,
    source_hashes=source_hashes,old_qualified_native_images=dict(path=str(archive),sha256=sha(archive),members=digests),
    resource_peak_bytes=2*1024**3+64*1024**2,available_memory_bytes=memory,new_roots=0,new_worktrees=0,
    native_builds=0,candidate_dispatches=0,CI_reruns=0,model_wait_calls=0,checks=[])
update(record)
os.environ.update(CMAKE_BUILD_PARALLEL_LEVEL='2',MSBUILDDISABLENODEREUSE='1',PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='0',PYTHONUTF8='1',FACMAN_CLI_EXE=str(CLI),PYTHONPATH=os.pathsep.join([str(R/'tests'),str(R)]))
temp = E/'make-ready-query-01-temp'; assert temp.is_dir() and not any(temp.iterdir()); os.environ['TEMP'] = os.environ['TMP'] = str(temp)
try:
    record['native_builds'] = 1; update(record)
    record['checks'].append(log('build',[sys.executable,'-B','tools/dev.py','build','developer','--task-root',str(E.parent),'--build-root',str(BUILD),'--configuration','Debug','--target','facman_cli','--target','flb_factorio_instance_model_smoke'],1800))
    for p,digest in source_hashes.items(): assert sha(R/p) == digest,p
    record['CLI_sha256'] = sha(CLI)
    record['checks'].append(log('native-model',['ctest','--test-dir',str(BUILD),'-C','Debug','-R','^flb_factorio_instance_model_smoke$','--output-on-failure','--no-tests=error'],180))
    native = Path(record['checks'][-1]['log']).read_text(); assert '0 tests failed out of 1' in native
    record['checks'].append(log('profiles-and-query',[sys.executable,'-B','-m','unittest','tests.test_profiles_templates','tests.test_cli.CliTests.test_instance_projection_is_deterministic_intent_specific_and_read_only'],600))
    text = Path(record['checks'][-1]['log']).read_text()
    assert re.search(r'Ran \d+ tests?',text) and '\nOK\n' in text and 'skipped=' not in text
    record['public_suite_tests'] = int(re.search(r'Ran (\d+) tests?',text).group(1))
    for name,args in [('state-tests',['-m','unittest','tests.test_plan_views','tests.test_current_truth_roles','tests.test_aide_target_truth','tests.test_aide_compaction']),('plan-check',['tools/generate_plan_views.py','--check']),('state-check',['tools/project_state.py','--validate']),('strict',['tools/strict_check.py']),('format',['tools/source_format_check.py']),('portable',['.aide/scripts/aide_lite.py','test'])]:
        record['checks'].append(log(name,[sys.executable,'-B',*args],600))
    record['checks'].append(log('diff',['git','diff','--check'],60))
    assert not any(temp.iterdir())
    for p,digest in source_hashes.items(): assert sha(R/p) == digest,p
    assert sha(archive) == record['old_qualified_native_images']['sha256']
    renewed = development_layout.read_marker(E.parent,R)
    assert all(renewed[k] == marker[k] for k in marker if k != 'last_used_at')
    record.update(status='PASS_SCOPED_WINDOWS_MENU_READINESS_INTENT',public_regression_cases=4,temp_parent_empty=True,
        actual_Factorio=False,produced_package=False,whole_workunit_closed=False,full_programme_complete=False)
except BaseException as exc:
    record.update(status='stopped_for_actionable_failure',error=repr(exc),next_action='Inspect retained exact source/build/test state; do not replay an already successful build or completed proof')
record['finished_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat(); update(record)
print(json.dumps({k:record.get(k) for k in ['status','native_builds','public_regression_cases','CLI_sha256','error','finished_at_utc']}))
