import hashlib,json,zipfile
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent
Q=R/'.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
obs_path=E/'windows-delivered-joined-checked-integration-result-01.json';obs=json.loads(obs_path.read_bytes())
assert obs['status']=='merged_exact_source' and obs['required_checks_all_pass'] and obs['pr']==418
assert obs['source']=='a4bed76234360a3f127ccad22742587daa6bb9cf'
assert obs['pr_state']['mergeCommit']['oid']=='cb97d8cff22b400dbfdf8a24b9659fbb7adb9605'
proof=obs['actual_windows_delivered_GUI_qualification'];mac=obs['actual_mac_delivered_package_qualification']
assert proof['status']=='PASS_INDEPENDENT_ACTUAL_GUI_CUSTODY' and proof['qualification']=='factory-produced Windows legacy WinForms portable file closure'
assert proof['source']==obs['source'] and proof['actual_GUI_sessions']==2 and proof['complete_owner_effects']==2 and proof['all_owned_jobs_empty']
assert mac['method_count']==11 and mac['method_skips']==0 and mac['compiled_checkout_tree']=='74c58e940ea8e3944f4bb2743b51fa50c5f525fe'
assert mac['compiled_checkout_parents']==['3b12f8e36786ef8cdb5c3bb897440d1566b91c51',obs['source']]
names={Path(__file__).name,obs_path.name,'windows-delivered-joined-log-custody-01.py','windows-delivered-joined-checked-observer-01.py',
 'macos-delivered-pack-checked-observer-01.py','make-ready-joined-log-custody-04.py',
 'macos-delivered-pack-log-custody-01.py','macos-delivered-tui-log-custody-02.py','macos-delivered-pack-independent-review-01.json',
 'windows-delivered-joined-candidate-commit-result-02.json','windows-delivered-joined-candidate-commit-result-03.json',
 'windows-delivered-joined-candidate-commit-review-02.json','windows-delivered-joined-independent-review-02.json',
 'windows-delivered-joined-postmerge-dev-sync-result-01.json','windows-delivered-joined-retirement-result-01.json',
 Path(proof['log_path']).name,Path(mac['log_path']).name}
dirs=[E/('windows-delivered-joined-actual-job-'+str(proof['job_id'])),Path(mac['decoded_joined_evidence_directory']),
 Path(mac['retained_nine']['decoded_pack_evidence_directory']),Path(mac['retained_nine']['retained_tui']['decoded_evidence_directory'])]
for directory in dirs:
 assert directory.is_dir()
 names.update(p.relative_to(E).as_posix() for p in directory.rglob('*') if p.is_file())
for row in obs['commands']:
 if row['label'] in ('windows-job','windows-run','compiled-checkout','mac-job','mac-run'):
  directory=Path(row['receipt']).parent
  names.update((directory/n).relative_to(E).as_posix() for n in ('receipt.json','stdout.raw','stderr.raw'))
manifest={n:sha(E/n) for n in sorted(names)}
archive=Q/'evidence/produced-windows-live-joined-gui-custody.v1.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 z.writestr('custody-manifest.json',json.dumps(manifest,indent=2,sort_keys=True)+'\n')
 for n in sorted(manifest):z.write(E/n,'evidence/'+n)
with zipfile.ZipFile(archive) as z:
 for n,d in manifest.items():assert hashlib.sha256(z.read('evidence/'+n)).hexdigest()==d
record=dict(schema='facman.windows_live_joined_gui_accepted_slice.v1',reviewed_source=obs['source'],
 integration=obs['pr_state']['mergeCommit']['oid'],pr=418,windows_actual=proof,
 actual_GUI_method_skips=0,required_checks=obs['observations'][-1]['checks'],required_checks_all_pass=True,
 observer_sha256=sha(obs_path),source_review_sha256=sha(E/'windows-delivered-joined-independent-review-02.json'),
 retained_mac_package_methods_passed=11,retained_mac_method_skips=0,retained_mac_native_tests=57,
 retained_mac_owner_methods=41,retained_mac_joined_source_methods=12,retained_mac_source=mac['compiled_checkout_source'],
 retained_mac_tree=mac['compiled_checkout_tree'],retained_mac_parents=mac['compiled_checkout_parents'],
 custody=archive.name,custody_sha256=sha(archive),custody_files=len(manifest),
 actual_factory_portable_file_closure=True,original_portable_ZIP_acceptance=False,
 previous_reconstructed_local_proof_retained=True,installed_generation_refusal_retained=True,
 canonical_installed_desktop_owner_dependency='PR404 protected control owner authorization',
 no_runtime_provider_policy_changes=True,minimum_or_named_physical_host=False,
 real_game=False,human=False,whole_workunit=False,full_make_ready=False,beta=False,rc=False)
out=Q/'evidence/produced-windows-live-joined-gui.v1.json'
with out.open('x',encoding='utf-8') as f:json.dump(record,f,indent=2);f.write('\n')
with (Q/'ExecPlan.md').open('a',encoding='utf-8',newline='\n') as f:
 f.write('\n### Accepted factory-produced Windows live GUI slice\n\nPR418 integrated revieweda4bed762 as devcb97d8cf after all required checks passed. A single observer waited about89minutes without model polling and independently decoded actual new-head factory-produced Windows legacy portable GUI custody before merging. Two ordinary offscreen GUI sessions use the real input form, native cancellation/confirmation, live store and production backend. Cancellation and stale confirmation preserve input bytes/identity; a fresh request completes both journaled routing and selected-save owners. Eight fixture/query CLI calls and68observed packaged backend process identities are retained, with exact pre-execution job assignment, normal exits and zero active owned processes. The readonly598file package closure remains unchanged under empty PATH and cleared source/backend overrides. Four Windows native builds pass55tests each. Retained Mac acceptance also passes all11package methods without skips,57native,41existingowner and12joinedsource cases; its synthetic41bd8bef tree74c58e94 equals the reviewed source with expected base/source parents. Full call/CAS bytes and actual control frames were preserved before runner cleanup and independently verified.\n\nThis closes the ordinary delivered legacy portable GUI-to-backend slice. The actual malformed Setup generation remains refused and PR404 owner-only integration stays separate. Canonical installed Desktop, original portable ZIP, whole-workunit/full Make Ready/Play, real game/human/minimum/named physical hosts and Beta/RC remain open. Task refs were retired and dev synchronized. Continue the joined clean-workspace reconstruction of declared content, profile and world through existing owners.\n\nEvidence: evidence/produced-windows-live-joined-gui.v1.json and hash-closed custody.\n')
print(json.dumps(dict(status='SEALED_ACCEPTED_FACTORY_WINDOWS_GUI',receipt_sha256=sha(out),archive_bytes=archive.stat().st_size,
 actual_GUI_sessions=2,observed_backend_processes=68,retained_Mac_methods=11,new_roots=0)))
