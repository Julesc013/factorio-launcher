from pathlib import Path
E=Path(__file__).resolve().parent
origin=E/'macos-delivered-pack-checked-observer-01.py'
code=origin.read_text(encoding='utf-8')
changes={
'e0809f002865906dcaee56455a88761ccad0e56e':'a4bed76234360a3f127ccad22742587daa6bb9cf',
'e504c5ed6d7366f0cf43df5105ae8ce415a8ffdc':'3b12f8e36786ef8cdb5c3bb897440d1566b91c51',
"macos-delivered-pack-log-custody-01.py":"make-ready-joined-log-custody-04.py",
'macos-delivered-pack-':'windows-delivered-joined-',
'COMMITTED_REVIEWED_DELIVERED_TUI_CANDIDATE':'COMMITTED_REVIEWED_LIVE_WINDOWS_GUI_CANDIDATE',
'pr=416':'pr=418',"'416'":"'418'",'assert len(actual_records)==9':'assert len(actual_records)==11',
'windows-delivered-joined-candidate-commit-result-01.json':'windows-delivered-joined-candidate-commit-result-03.json',
'windows-delivered-joined-candidate-commit-review-01.json':'windows-delivered-joined-candidate-commit-review-02.json',
'windows-delivered-joined-candidate-commit-message-01.txt':'windows-delivered-joined-candidate-commit-message-02.txt',
}
for old,new in changes.items():
 assert old in code,old
 code=code.replace(old,new)
marker='    import runpy\n'
extra="""    joined_source=[]
    frozen=json.loads((E/'make-ready-joined-frozen-06.json').read_bytes())
    for name in frozen['test_selection']['methods']:
        if name=='test_compiled_ordinary_gui_control_preserves_actual_preparation_receipt':continue
        test_id='tests.test_make_ready_joined.JoinedMakeReadyTests.'+name
        lines=[line for line in text.splitlines() if f'{name} ({test_id})' in line]
        assert len(lines)==1 and re.search(r'\\.\\.\\. ok\\s*$',lines[0]),('retained joined Mac method',test_id)
        joined_source.append(test_id)
    assert len(joined_source)==12
    record['actual_mac_joined_source_methods_passed']=joined_source
"""
assert code.count(marker)==1
code=code.replace(marker,extra+marker,1)
marker='\ntry:\n    ident='
extra="""
def verify_windows(rows):
    import runpy
    windows=[x for x in rows if x['name']=='windows-native-package']
    assert len(windows)==1 and windows[0]['state']=='SUCCESS' and windows[0]['bucket']=='pass'
    run_id,job_id=re.search(r'/actions/runs/(\\d+)/job/(\\d+)',windows[0]['link']).groups()
    job=call('windows-job',['api',f'repos/{REPO}/actions/jobs/{job_id}']);assert job.ok
    j=json.loads(job.stdout);assert str(j['run_id'])==run_id and j['status']=='completed' and j['conclusion']=='success'
    run=call('windows-run',['api',f'repos/{REPO}/actions/runs/{run_id}']);assert run.ok
    w=json.loads(run.stdout);assert w['head_sha']==S and w['event']=='pull_request'
    logs=call('windows-actual-tests',['api',f'repos/{REPO}/actions/jobs/{job_id}/logs'],120);assert logs.ok
    log=E/f'windows-delivered-joined-windows-job-{job_id}.log'
    with log.open('xb') as stream:stream.write(logs.stdout)
    text=logs.stdout.decode('utf-8','replace')
    assert text.count('100% tests passed, 0 tests failed out of 55')==4
    method='test_actual_joined_controls_dispatch_production_packaged_backend'
    test_id='tests.test_windows_delivered_joined_gui.WindowsDeliveredJoinedGuiTests.'+method
    lines=[line for line in text.splitlines() if f'{method} ({test_id})' in line]
    assert len(lines)==1 and 'skipped' not in lines[0] and 'ERROR' not in lines[0],('new actual GUI method',lines)
    proof=runpy.run_path(str(E/'windows-delivered-joined-log-custody-01.py'))['extract'](
        log,S,E/f'windows-delivered-joined-actual-job-{job_id}',
        expected_qualification='factory-produced Windows legacy WinForms portable file closure')
    proof.update(run_id=int(run_id),job_id=int(job_id),job_conclusion=j['conclusion'],runner_name=j.get('runner_name'),
        log_path=str(log),log_sha256=sha(log),native_builds_passed=4,native_tests_per_build=55,
        actual_GUI_method=test_id,source=S)
    record['actual_windows_delivered_GUI_qualification']=proof
    save()
"""
assert code.count(marker)==1
code=code.replace(marker,extra+marker,1)
assert code.count('            verify_mac(rows)')==2
code=code.replace('            verify_mac(rows)','            verify_mac(rows)\n            verify_windows(rows)')
exec(compile(code,str(origin)+'#live-windows418','exec'))
