from pathlib import Path
import contextlib, hashlib, importlib, io, json, locale, os, shutil, subprocess, sys, tempfile, threading, time, traceback, unittest
from unittest.mock import patch
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent;B=W/'native-developer';F=W/'t/j3/pt4';I=F/'i';C=F/'c';RAW=E/'tui-pack-import-ci-focused-raw-01'
sys.dont_write_bytecode=True;sys.path[:0]=[str(E),str(R/'tests'),str(R)]
from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
plan_path=E/'tui-pack-import-ci-focused-plan-01.json';plan=json.loads(plan_path.read_bytes())
assert sys.argv[1:]==['--reviewed-plan-sha256',sha(plan_path)]
probe=importlib.import_module('tui-pack-import-ci-focused-probe-01');probe.PLAN=plan_path;probe.guard(plan)
assert sys.version_info[:3]==(3,11,9) and sys.flags.utf8_mode==0 and locale.getpreferredencoding(False)=='cp1252'
assert json.loads((E/'tui-pack-import-ci-test-fix-source-review-01.json').read_bytes())['findings']==[]
native=json.loads((E/'tui-context-native-result-01.json').read_bytes());assert all(sha(Path(n))==v['sha256'] for n,v in native['outputs'].items())
result=dict(status='RESOURCE_WAIT',python=sys.version,utf8_mode=sys.flags.utf8_mode,default_text_encoding=locale.getpreferredencoding(False),plan_sha256=sha(plan_path),calls=[],new_builds=0,new_roots=0,all_original_assertions_retained=True)
out=E/'tui-pack-import-ci-focused-result-01.json';assert not out.exists()
lock=threading.Lock()
def save():out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
try:
    save();review=dict(verdict='ADMIT_SCOPED_TUI_OFFLINE_PACK_RESOURCE_PROBE',plan_sha256=sha(plan_path),prepared_scripts=plan['prepared_scripts']);result['resources']=probe.wait_for_resources(review,'before-worker');save()
    assert not F.exists() and not RAW.exists()
    for ancestor in [F.parent,*F.parent.parents]:assert ancestor.is_dir() and not ancestor.is_symlink() and not ancestor.lstat().st_file_attributes&0x400
    F.mkdir();C.mkdir();RAW.mkdir();(RAW/'cas').mkdir();shutil.copytree(R/'tests/fixtures/fake_factorio_install',I)
    marker=F/'.facman-diagnostic-fixture.v1.json';marker.write_text(json.dumps(dict(owner='tui-pack-import-ci-focused-01',plan_sha256=sha(plan_path))),encoding='utf-8');mark=sha(marker)
    os.environ.update(FACMAN_CLI_EXE=str(B/'Release/facman.exe'),FACMAN_TUI_EXE=str(B/'Release/facman.exe'),TEMP=str(F),TMP=str(F));tempfile.tempdir=None
    import native_cli,test_tui_product as tui,test_presentation_pack_import as presentation,test_local_modset_solver as solver,test_instance_snapshots as snapshots,test_snapshot_local_install as recovery
    deadline=time.monotonic()+240
    def call(kind,args,data=b'',extra=None):
        assert sha(marker)==mark and time.monotonic()<deadline
        with lock:index=len(result['calls']);assert index<64;result['calls'].append(dict(kind=kind,argv=args,state='dispatching'));save()
        env={k:v for k,v in os.environ.items() if not k.startswith('FACMAN_')};env.update(PATH='',TEMP=str(F),TMP=str(F))
        if extra:env.update(extra)
        cap=owned.command([str(B/'Release/facman.exe'),*args],cwd=C,environment=env,directory=RAW/f'call-{index:03d}',input_bytes=data,timeout=min(15 if kind=='tui' else 30,deadline-time.monotonic()),output_limit=4*1024**2,wait_for_job_empty_after_primary=True)
        with lock:result['calls'][index].update(state='finished',exit_code=cap.returncode,receipt_sha256=sha(cap.directory/'receipt.json'));save()
        assert cap.receipt['termination']=='completed' and cap.receipt['primary_stopped'] and cap.receipt['job_empty_observed'] and not cap.receipt['job_terminated']
        return cap
    def machine(args,env=None):
        allowed={'FACMAN_TEST_SNAPSHOT_RESTORE_EXIT_AFTER_VERIFIED','FACMAN_TEST_SNAPSHOT_RECOVERY_BEFORE_LOCK_PAUSE'}
        extra={k:v for k,v in (env or {}).items() if k.startswith('FACMAN_TEST_')}
        assert set(extra)<=allowed and all(v=='1' for v in extra.values())
        cap=call('cli',args,extra=extra);return cap.returncode,cap.stdout.decode('utf-8').replace('\r\n','\n'),cap.stderr.decode('utf-8').replace('\r\n','\n')
    def terminal(self,args,*,stdin=None,environment=None):
        assert not environment;cap=call('tui',['tui',*args],(stdin or '').encode('utf-8'))
        return subprocess.CompletedProcess([str(B/'Release/facman.exe'),'tui',*args],cap.returncode,cap.stdout.decode('utf-8').replace('\r\n','\n'),cap.stderr.decode('utf-8').replace('\r\n','\n'))
    class RetainedDirectory:
        count=0
        def __init__(self,*args,**kw):
            assert not args and set(kw)=={'prefix'} and kw['prefix'] in ('tui offline pack Ω ','snapshot-late-recovery-')
            type(self).count+=1;assert type(self).count<=4;self.path=F/(kw['prefix']+str(type(self).count));self.path.mkdir();self.name=str(self.path)
        def __enter__(self):return self.name
        def __exit__(self,*args):return False
    with contextlib.ExitStack() as stack:
        for module,name,value in [(native_cli,'invoke_machine',machine),(presentation,'invoke_machine',machine),(native_cli,'ROOT',C),(presentation,'FIXTURE_INSTALL',I),(solver,'FIXTURE_INSTALL',I),(snapshots,'FIXTURE_INSTALL',I),(recovery,'FIXTURE_INSTALL',I),(tui.TuiProductTests,'invoke',terminal),(tempfile,'TemporaryDirectory',RetainedDirectory)]:stack.enter_context(patch.object(module,name,value))
        code,text,err=machine(['product','inspect','--json']);assert code==0 and not err and json.loads(text)['payload']['backend_identity']==native['backend_identity']
        stream=io.StringIO();suite=unittest.TestSuite([tui.TuiProductTests('test_ordinary_offline_pack_import_cancels_then_reconstructs_without_selected_instance'),recovery.SnapshotLocalInstallTests('test_recovery_rechecks_journal_target_and_stage_after_acquiring_shared_lease')])
        tested=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite);(RAW/'unittest.txt').write_text(stream.getvalue(),encoding='utf-8')
        result.update(tests_run=tested.testsRun,failures=len(tested.failures),errors=len(tested.errors),skips=len(tested.skipped),retained_case_count=RetainedDirectory.count)
        assert tested.wasSuccessful() and tested.testsRun==2 and not tested.skipped,stream.getvalue()
    assert RetainedDirectory.count==4
    result.update(status='PASS_PYTHON311_CP1252_UNICODE_IMPORT_AND_ALL_THREE_LATE_RECOVERY_CASES')
except BaseException as error:result.update(status='FAIL_RETAINED',error=repr(error),traceback=traceback.format_exc())
finally:
    if F.exists():
        files={}
        for p in F.rglob('*'):
            assert not p.is_symlink() and not p.lstat().st_file_attributes&0x400
            if p.is_file():
                raw=p.read_bytes();h=hashlib.sha256(raw).hexdigest();files[p.relative_to(F).as_posix()]=dict(bytes=len(raw),sha256=h)
                if RAW.exists() and not (RAW/'cas'/h).exists():(RAW/'cas'/h).write_bytes(raw)
        result['fixture_inventory']=files
    try:probe.guard(plan);assert all(sha(Path(n))==v['sha256'] for n,v in native['outputs'].items());result['exact_source_native_guards']=True
    except BaseException as error:result.update(status='FAIL_RETAINED_GUARD',guard_error=repr(error))
    save();print(json.dumps({k:result.get(k) for k in ['status','tests_run','failures','errors','skips','error']},ensure_ascii=True),flush=True)
raise SystemExit(0 if result['status'].startswith('PASS_') else 1)
