"""One owned packaged linear-TUI interruption, cancel and ordinary recovery."""
from pathlib import Path
import contextlib,ctypes,hashlib,importlib,json,os,shutil,subprocess,sys,threading,time,traceback,zipfile
from unittest.mock import patch
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
G=W/'t/j3/g6';F=W/'t/j3/pt5';C=F/'c';I=F/'i';RAW=E/'pack-tui-interrupted-raw-01'
sys.dont_write_bytecode=True;sys.path[:0]=[str(E),str(R/'tests'),str(R)]
from tools import provider_canary_process as owned
from tools.package.runtime_identity import require_backend_identity
import native_cli,test_presentation_pack_import as presentation,test_local_modset_solver as solver,test_portable_modpack_import as portable,test_make_ready_joined as joined,test_windows_delivered_joined_gui as lifetime
fault=importlib.import_module('pack-gui-interrupted-fault-01')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
digest=lambda b:hashlib.sha256(b).hexdigest()
P=E/'pack-tui-interrupted-plan-01.json';plan=json.loads(P.read_bytes())
assert sys.argv[1:]==['--reviewed-plan-sha256',sha(P)]
probe=importlib.import_module('pack-tui-interrupted-probe-01');probe.PLAN=P;probe.guard(plan)
out=E/'pack-tui-interrupted-result-01.json';assert not out.exists()
result=dict(status='RESOURCE_WAIT',plan_sha256=sha(P),execution_head=plan['execution_head'],artifact_source=plan['artifact_source'],artifact=plan['artifact'],calls=[],sessions=[],intentional_loss=None,new_builds=0,new_downloads=0,new_task_roots=0,vm_changes=False,fullscreen=False,real_game=False,human=False,workunit_closed=False)
def save():out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
def inventory(root):
    rows={}
    for p in root.rglob('*'):
        assert not p.is_symlink() and not p.lstat().st_file_attributes&0x400
        if p.is_file():rows[p.relative_to(root).as_posix()]=dict(bytes=p.stat().st_size,sha256=sha(p),identity=joined.file_identity(p))
    return rows
def retain(p):
    raw=p.read_bytes();h=digest(raw);cas=RAW/'cas'/h
    if not cas.exists():cas.write_bytes(raw)
    return dict(bytes=len(raw),sha256=h,identity=joined.file_identity(p))
try:
    save();review=dict(verdict='ADMIT_SCOPED_TUI_OFFLINE_PACK_RESOURCE_PROBE',plan_sha256=sha(P),prepared_scripts=plan['prepared_scripts']);result['resources']=probe.wait_for_resources(review,'before-worker');save()
    admission=json.loads((E/'tui-pack-import-delivered-extract-01.json').read_bytes())
    def package_guard():assert {p.relative_to(G).as_posix():sha(p) for p in G.rglob('*') if p.is_file()}==admission['file_inventory']
    package_guard();assert admission['source']==plan['artifact_source'] and admission['artifact']==plan['artifact']
    assert not F.exists() and not RAW.exists()
    for p in [F.parent,*F.parent.parents]:assert p.is_dir() and not p.is_symlink() and not p.lstat().st_file_attributes&0x400
    F.mkdir();C.mkdir();RAW.mkdir();(RAW/'cas').mkdir();shutil.copytree(R/'tests/fixtures/fake_factorio_install',I)
    marker=F/'.facman-diagnostic-fixture.v1.json';marker.write_text(json.dumps(dict(owner='pack-tui-interrupted-01',plan_sha256=sha(P))),encoding='utf-8');mark=sha(marker)
    environment={k:v for k,v in os.environ.items() if not k.startswith('FACMAN_')};environment.update(PATH='',TEMP=str(F),TMP=str(F))
    os.environ.update(FACMAN_CLI_EXE=str(G/'bin/facman.exe'))
    deadline=time.monotonic()+240
    def machine(args,env=None):
        assert not env and sha(marker)==mark and time.monotonic()<deadline
        index=len(result['calls']);d=RAW/f'call-{index:03d}'
        cap=owned.command([str(G/'bin/facman.exe'),*args],cwd=C,environment=environment,directory=d,timeout=min(30,deadline-time.monotonic()),output_limit=4*1024**2,wait_for_job_empty_after_primary=True)
        result['calls'].append(dict(args=args,exit_code=cap.returncode,receipt_sha256=sha(d/'receipt.json')));save()
        assert cap.receipt['termination']=='completed' and cap.receipt['primary_stopped'] and cap.receipt['job_empty_observed'] and not cap.receipt['job_terminated']
        return cap.returncode,cap.stdout.decode('utf-8').replace('\r\n','\n'),cap.stderr.decode('utf-8').replace('\r\n','\n')
    def query(scope):
        code,text,err=machine(['--workspace',str(WS),'presentation','query',scope,'--json']);assert code==0 and not err
        return json.loads(text)['payload']
    with contextlib.ExitStack() as stack:
        for module,name,value in [(native_cli,'invoke_machine',machine),(presentation,'invoke_machine',machine),(presentation,'FIXTURE_INSTALL',I),(solver,'FIXTURE_INSTALL',I)]:stack.enter_context(patch.object(module,name,value))
        code,text,err=machine(['product','inspect','--json']);assert code==0 and not err;result['backend_identity']=require_backend_identity(G,G/'bin/facman.exe',json.loads(text)['payload']);assert result['backend_identity']['compiled_source_revision']==plan['artifact_source']
        owner=presentation.PresentationPackImportTests();producer,WS,pack=owner.prepare(F,b'\x00preserved TUI settings\xff')
        sentinel=WS/'user-owned/sentinel.bin';sentinel.parent.mkdir();sentinel.write_bytes(b'foreign player data\x00\xff')
        protected=inventory(producer),inventory(I),retain(sentinel)
        content=query('content');assert content['selected_context']['instance_id'] is None
        index=next(i for i,a in enumerate(content['available_semantic_actions']) if a['action_id']=='modsets.import')
        form='4\n'+'tab\n'*index+'space\nsource_path='+str(pack)+'\nnew_instance_id=reconstructed\ninstallation_id=fixture\ndisplay_name=Restored pack\nspace\nspace\nq\n'
        signal=WS/'.facman-modpack-import-verified-paused';release=WS/'.facman-modpack-import-verified-release';stage=WS/'.facman-pack-import-reconstructed';target=WS/'instances/reconstructed'
        frozen=None;original_receipt=None;journal_path=None;stage_before=None
        def binding():
            global frozen,original_receipt,journal_path,stage_before
            assert signal.read_bytes()==b'paused\n' and not release.exists() and not target.exists()
            receipts=[(p,json.loads(p.read_bytes())) for p in (WS/'.facman/action-receipts-v2').glob('*.v2.json') if json.loads(p.read_bytes())['action_id']=='modsets.import'];assert len(receipts)==1
            rp,receipt=receipts[0];request=json.loads(receipt['request_json']);assert receipt['state']=='accepted_outcome_unknown' and json.loads(receipt['result_json'])['outcome']=='outcome_unknown'
            expected=dict(action_id='modsets.import',scope='content',confirmation='explicit',source_path=str(pack),new_instance_id='reconstructed',installation_id='fixture',display_name='Restored pack',selected_instance_id='',template_id='vanilla')
            assert all(request.get(k)==v for k,v in expected.items())
            assert request['expected_snapshot_revision']==content['revision'] and receipt['request_id']==request['request_id']==receipt['idempotency_key']
            assert request['request_id'].startswith('tui-modsets-import-') and receipt['request_fingerprint']==digest(receipt['request_json'].encode()) and receipt['result_digest']==digest(receipt['result_json'].encode())
            journals=[(p,json.loads(p.read_bytes())) for p in (WS/'transactions').glob('*.transaction.v1.json') if json.loads(p.read_bytes())['command_id']=='modsets.import'];assert len(journals)==1
            jp,journal=journals[0];assert journal['state']=='verified' and journal['commit_strategy']=='modpack_instance_no_replace_v1' and Path(journal['target'])==target
            assert list(map(Path,journal['source_identities']))==[pack,I] and list(map(Path,journal['owned_staging_roots']))==[stage]
            assert journal['effect_file_identity']==joined.file_identity(stage) and journal['effect_parent_identity']==joined.file_identity(target.parent)
            context=json.loads(journal['operation_context']);assert context['install_id']=='fixture' and context['root_identity']==joined.file_identity(I)
            source=context['source_binding'];assert source['archive_sha256']==sha(pack) and source['archive_size']==pack.stat().st_size and source['instance_id']=='reconstructed' and source['install_id']=='fixture' and source['display_name']=='Restored pack'
            with zipfile.ZipFile(pack) as archive:
                assert source['manifest_sha256']==digest(archive.read('modpack-manifest.v1.json')) and source['lock_sha256']==digest(archive.read('modset-lock.v1.json'))
            expected_files={x['path']:dict(bytes=x['size'],sha256=x['sha256']) for x in journal['expected_files']};assert len(expected_files)==len(journal['expected_files'])==9
            for name,row in expected_files.items():
                p=stage/name;assert stage in p.parents and p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
            for p in stage.rglob('*'):
                if p.is_file():retain(p)
            value=dict(request=retain(rp),journal=retain(jp),transaction_id=journal['transaction_id'],stage_identity=joined.file_identity(stage),parent_identity=joined.file_identity(target.parent),stage=inventory(stage),expected_files=expected_files,source=retain(pack),installation=inventory(I),signal=retain(signal))
            if frozen is None:frozen=value;original_receipt=rp;journal_path=jp;stage_before=value['stage'];result['pre_fault_binding']=value;save()
            assert value==frozen
            return value
        def persist_fault(event):
            result['intentional_loss']=event
            with (RAW/'intentional-loss.json').open('wb') as stream:stream.write((json.dumps(event,indent=2)+'\n').encode());stream.flush();os.fsync(stream.fileno())
            save()
        Job=fault.reviewed_job_class(lifetime,persist_fault,binding)
        def session(text,*,interrupt=False):
            assert time.monotonic()<deadline and sha(marker)==mark
            number=len(result['sessions'])+1;d=RAW/f'session-{number:02d}';d.mkdir();(d/'stdin.raw').write_bytes(text.encode('utf-8'))
            env=dict(environment)
            if interrupt:env['FACMAN_TEST_MODPACK_IMPORT_PAUSE']='verified'
            startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
            process=subprocess.Popen([str(G/'bin/facman.exe'),'tui','--workspace',str(WS),'--ordinary','--plain','--transport','process','--cli-path',str(G/'bin/facman.exe')],cwd=C,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,startupinfo=startup,creationflags=0x08000004)
            job=None;thread=None;captured=[];errors=[];row=dict(pid=process.pid,safety_termination=False,frontend='linear_process_tui');result['sessions'].append(row);save()
            try:
                job=Job(process,G/'bin/facman.exe');row.update(launch=job.launch,primary_identity=job.identity(int(process._handle)))
                def communicate():
                    try:captured.append(process.communicate(text.encode('utf-8'),timeout=min(60,deadline-time.monotonic())))
                    except BaseException as error:errors.append(repr(error))
                thread=threading.Thread(target=communicate,daemon=True);thread.start();faulted=False
                while thread.is_alive():
                    assert time.monotonic()<deadline and not errors
                    job.observe()
                    if interrupt and not faulted and signal.is_file():
                        try:ready=signal.read_bytes()==b'paused\n'
                        except OSError as error:
                            if getattr(error,'winerror',None)!=32:raise
                            ready=False
                        if ready:job.interrupt_verified_import();faulted=True
                    thread.join(.025)
                assert not errors and len(captured)==1 and process.returncode==0
                assert faulted is interrupt
                job.finish();row.update(exit_code=process.returncode,job_empty=True,observed_descendants=job.records,intentional_loss=job.intentional)
                stdout,stderr=captured[0];(d/'stdout.raw').write_bytes(stdout);(d/'stderr.raw').write_bytes(stderr)
                row['stdout_sha256']=sha(d/'stdout.raw');row['stderr_sha256']=sha(d/'stderr.raw');save()
                return stdout.decode('utf-8').replace('\r\n','\n')
            finally:
                if process.poll() is None:
                    row['safety_termination']=True
                    if job is not None and not job.closed:job.api.TerminateJobObject(job.job,1)
                    else:process.kill()
                if thread is not None:thread.join(10)
                if job is not None and not job.closed:
                    try:job.finish()
                    except BaseException as error:row['cleanup_error']=repr(error)
                if captured:
                    (d/'stdout.raw').write_bytes(captured[0][0]);(d/'stderr.raw').write_bytes(captured[0][1])
                save()
        lost=session(form,interrupt=True);assert 'unknown' in lost.lower(),lost
        assert result['intentional_loss']['termination_succeeded'] and not target.exists() and json.loads(journal_path.read_bytes())['state']=='verified'
        uncertainty=original_receipt.read_bytes();assert digest(uncertainty)==frozen['request']['sha256']
        assert protected==(inventory(producer),inventory(I),retain(sentinel))
        activity=query('activity_recovery');aindex=next(i for i,a in enumerate(activity['available_semantic_actions']) if a['action_id']=='recovery.apply_supported')
        opening='6\n'+'tab\n'*aindex+'space\ntransaction_id='+frozen['transaction_id']+'\nspace\n'
        preserved=inventory(WS);cancelled=session(opening+'7\nq\n');assert 'Confirm Apply supported recovery' in cancelled and inventory(WS)==preserved
        recovered=session(opening+'space\nq\n');assert 'Apply supported recovery completed' in recovered and 'Instance: Restored pack' in recovered,recovered
        portable.PortableModpackImportTests().assert_reconstruction(WS,pack)
        assert original_receipt.read_bytes()==uncertainty and json.loads(journal_path.read_bytes())['state']=='complete' and joined.file_identity(target)==frozen['stage_identity']
        now=inventory(target)
        for name,row in stage_before.items():
            if name not in ('.facman-transaction-staging.v2.json','.facman-archive-staging.v1'):assert now[name]==row,name
        assert protected==(inventory(producer),inventory(I),retain(sentinel))
        receipts=[json.loads(p.read_bytes()) for p in (WS/'.facman/action-receipts-v2').glob('*.v2.json')]
        recoveries=[r for r in receipts if r['action_id']=='recovery.apply_supported'];assert len(recoveries)==1
        r=recoveries[0];request=json.loads(r['request_json']);outcome=json.loads(r['result_json']);assert request['transaction_id']==frozen['transaction_id'] and request['confirmation']=='explicit' and outcome['outcome']=='completed'
        before=inventory(WS)
        for args in [['workspace','recovery','inspect'],['workspace','recovery','plan',frozen['transaction_id']]]:
            code,text,err=machine(['--workspace',str(WS),*args,'--json']);assert code==0 and not err
        assert inventory(WS)==before
        result.update(status='PASS_PACKAGED_TUI_INTERRUPTED_IMPORT_CANCEL_AND_ORDINARY_RECOVERY',transaction_id=frozen['transaction_id'],original_uncertainty_sha256=digest(uncertainty),recovery_semantic_receipt=r,all_final_protected_data_preserved=True,original_import_not_replayed=True,terminal_inspection_readonly=True)
except BaseException as error:result.update(status='FAIL_RETAINED',error=repr(error),traceback=traceback.format_exc())
finally:
    if F.exists() and RAW.exists():result['final_fixture_inventory']={p.relative_to(F).as_posix():retain(p) for p in F.rglob('*') if p.is_file()}
    try:probe.guard(plan);package_guard();result['source_and_original_package_unchanged']=True
    except BaseException as error:result.update(status='FAIL_RETAINED_FINAL_GUARD',final_guard_error=repr(error))
    save();print(json.dumps({k:result.get(k) for k in ['status','transaction_id','error']},ensure_ascii=True),flush=True)
raise SystemExit(0 if result['status'].startswith('PASS_') else 1)
