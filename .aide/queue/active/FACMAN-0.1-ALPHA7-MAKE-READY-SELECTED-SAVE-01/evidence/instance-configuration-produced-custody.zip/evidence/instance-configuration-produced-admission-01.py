"""Admit one existing produced Windows artifact; no build or job dispatch."""
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import subprocess
import sys
import zipfile

R = Path(r'D:/Projects/Factorio/factorio-launcher')
E = Path(__file__).resolve().parent
W = E.parent
P = 'instance-configuration-produced-admission-01'
BASE = 'bb0bc47618b6e10347d6a4e91d36911147c3f5d1'
OUT = E / (P + '.json')
ZIP = E / 'instance-configuration-current-Windows-self-setup-01.zip'
DEST = W / 'instance-configuration-produced-01'
record = {'status': 'PENDING', 'source': BASE, 'checks': [], 'new_task_roots': 0,
          'builds': 0, 'candidate_dispatches': 0, 'CI_reruns': 0,
          'model_wait_calls': 0, 'whole_workunit_closed': False}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')

def update():
    temporary = OUT.with_suffix('.writing')
    write(temporary, record)
    temporary.replace(OUT)

def check(name, argv, timeout=120):
    log = E / (P + '-' + name + '.log')
    with log.open('xb') as stream:
        run = subprocess.run(argv, cwd=R, stdout=stream, stderr=subprocess.STDOUT,
                             timeout=timeout)
    record['checks'].append({'name': name, 'argv': argv, 'exit_code': run.returncode,
                             'log': str(log), 'sha256': sha(log)})
    update()
    return run, log

def git(*args):
    return subprocess.check_output(['git', *args], cwd=R, text=True).strip()

def inventory(archive, limit):
    entries = archive.infolist()
    folded = set()
    total = 0
    for entry in entries:
        name = entry.filename
        path = PurePosixPath(name)
        assert not path.is_absolute() and '\\' not in name and ':' not in name
        assert all(part not in ('..', '.') for part in path.parts) and path.parts
        assert name.casefold() not in folded
        folded.add(name.casefold())
        assert not stat.S_ISLNK(entry.external_attr >> 16)
        assert entry.file_size <= limit
        total += entry.file_size
    assert total <= limit and len(entries) <= 2000
    assert archive.testzip() is None
    return entries, total

assert __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0'
assert not OUT.exists() and not ZIP.exists() and not DEST.exists()
assert git('rev-parse', 'HEAD') == git('rev-parse', 'origin/dev') == BASE
assert git('branch', '--show-current') == 'dev' and not git('status', '--porcelain')
marker_path = W / '.facman-development-root.v1.json'
marker = json.loads(marker_path.read_text(encoding='utf-8'))
assert marker['task_id'] == 'task/facman-world-restore-retention-01'
assert Path(marker['canonical_path']).samefile(W) and Path(marker['source_root']).samefile(R)
record['marker_sha256_before'] = sha(marker_path)
write(E / (P + '.claim.json'), {'PID': os.getpid(), 'source': BASE, 'no_automatic_replay': True})
update()
try:
    for name, args in [('task-inspect', ['task', 'inspect']),
                       ('task-noop', ['task', 'noop-check']),
                       ('task-recover', ['task', 'recover'])]:
        run, _ = check(name, [sys.executable, '-B', '.aide/scripts/aide_lite.py', *args,
                            '--task-id', 'FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'])
        assert run.returncode == 0, name
    for name, argv in [('git-policy', ['git', 'policy']), ('git-detect', ['git', 'detect']),
                       ('git-plan', ['git', 'plan'])]:
        run, _ = check(name, [sys.executable, '-B', '.aide/scripts/aide_lite.py', *argv])
        assert run.returncode == 0, name
    run, log = check('resource', [sys.executable, '-B', 'tools/workspace_hygiene.py',
                                'doctor', '--measure'], 180)
    hygiene = json.loads(log.read_text(encoding='utf-8'))
    assert set(hygiene['violations']) <= {'unmanaged_secondary_worktrees_present',
                                         'merged_local_task_branches_present'}
    assert len(hygiene['task_roots']) <= 8
    peak = 512 * 1024 * 1024
    reserve = 8 * 1024**3
    free = shutil.disk_usage(W).free
    assert hygiene['task_root_bytes'] + peak < 20 * 1024**3 and free >= reserve + peak
    record['resource_admission'] = {'retained_bytes': hygiene['task_root_bytes'],
                                   'roots': len(hygiene['task_roots']), 'peak_extra_bytes': peak,
                                   'free_bytes': free, 'reserve_bytes': reserve,
                                   'preserved_violations': hygiene['violations'],
                                   'peak_includes': ['outer_artifact', 'payload_zip', 'extracted_delivery',
                                                     'public_fixture_workspaces', 'journals', 'custody']}
    run, log = check('windows-identity', ['powershell', '-NoProfile', '-Command',
                         '[System.Security.Principal.WindowsIdentity]::GetCurrent().Name'])
    assert run.returncode == 0 and log.read_text().strip() == r'BLACKGLASS-WIN1\Jules'
    # Only a return code is retained: auth status may contain credential details.
    auth = subprocess.run(['gh', 'auth', 'status'], cwd=R, capture_output=True, timeout=30)
    assert auth.returncode == 0
    record['real_user_auth_status_exit'] = auth.returncode
    run, log = check('github-user', ['gh', 'api', 'user', '--jq', '.login'])
    assert run.returncode == 0 and log.read_text().strip() == 'Julesc013'
    run, log = check('artifact-metadata', ['gh', 'api',
                           'repos/Julesc013/factorio-launcher/actions/artifacts/11336873964'])
    assert run.returncode == 0
    artifact = json.loads(log.read_text(encoding='utf-8'))
    assert artifact['id'] == 11336873964 and not artifact['expired']
    assert artifact['digest'] == 'sha256:a7306345b3dc67f3d84501444d3c6a3c0bcbeeac3a3b039b87d44b71af5ecd18'
    assert artifact['workflow_run']['id'] == 37287317294
    assert artifact['workflow_run']['head_sha'] == BASE
    record['artifact'] = artifact
    update()
    with ZIP.open('xb') as stream, (E / (P + '-download.stderr.log')).open('xb') as errors:
        run = subprocess.run(['gh', 'api', 'repos/Julesc013/factorio-launcher/actions/artifacts/11336873964/zip'],
                             cwd=R, stdout=stream, stderr=errors, timeout=180)
    assert run.returncode == 0 and sha(ZIP) == artifact['digest'].split(':')[1]
    with zipfile.ZipFile(ZIP) as archive:
        entries, total = inventory(archive, 128 * 1024 * 1024)
        records = [entry for entry in entries if entry.filename.endswith('self-setup-package.v1.json')]
        assert len(records) == 1
        package = json.loads(archive.read(records[0]))
        assert package['facman_source_revision'] == BASE and not package['source_dirty']
        payloads = [entry for entry in entries if PurePosixPath(entry.filename).name == package['payload']['filename']]
        assert len(payloads) == 1
        payload_bytes = archive.read(payloads[0])
        assert hashlib.sha256(payload_bytes).hexdigest() == package['payload']['sha256']
        assert len(payload_bytes) == package['payload']['size_bytes']
        DEST.mkdir()
        (DEST / 'package-record.v1.json').write_bytes(archive.read(records[0]))
        payload = DEST / package['payload']['filename']
        payload.write_bytes(payload_bytes)
    with zipfile.ZipFile(payload) as archive:
        entries, total = inventory(archive, 128 * 1024 * 1024)
        files = [entry for entry in entries if not entry.is_dir()]
        assert len(files) == package['payload']['file_count']
        lines = bytearray()
        for entry in sorted(files, key=lambda value: value.filename.encode('utf-8')):
            data = archive.read(entry)
            lines.extend(entry.filename.encode('utf-8') + b'\0' + str(len(data)).encode() + b'\0'
                         + hashlib.sha256(data).hexdigest().encode() + b'\n')
        assert hashlib.sha256(lines).hexdigest() == package['payload']['tree_digest']
        generation = f"facman/generations/{package['version']}/"
        selected = [entry for entry in files if entry.filename.startswith(generation)]
        assert any(entry.filename == generation + 'bin/facman.exe' for entry in selected)
        assert all((DEST / entry.filename).resolve().is_relative_to(DEST.resolve()) for entry in selected)
        for entry in selected:
            target = DEST / entry.filename
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream:
                stream.write(archive.read(entry))
        cli = DEST / generation / 'bin/facman.exe'
        manifest_names = [entry.filename for entry in selected if any(
                        word in entry.filename.lower() for word in ('hash', 'identity', 'manifest'))]
    record.update(status='ADMITTED_EXISTING_PRODUCED_WINDOWS_DELIVERY',
                  package_record=package, artifact_sha256=sha(ZIP),
                  payload_sha256=sha(payload), payload_uncompressed_bytes=total,
                  delivery=str(cli.parent.parent), executable=str(cli), executable_sha256=sha(cli),
                  manifest_candidates=manifest_names, generation_files=len(selected),
                  finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    marker['last_used_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00', 'Z')
    temporary = marker_path.with_suffix('.writing')
    write(temporary, marker)
    temporary.replace(marker_path)
    record['marker_sha256_after'] = sha(marker_path)
    update()
    print(json.dumps({key: record[key] for key in ('status', 'artifact_sha256',
                  'executable', 'executable_sha256', 'generation_files', 'manifest_candidates')}))
except BaseException as error:
    record['status'] = 'ACTIONABLE_FAILURE'
    record['error'] = repr(error)
    update()
    raise
