"""One current produced-package configuration journey with independent file oracles."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

R = Path(r'D:/Projects/Factorio/factorio-launcher')
E = Path(__file__).resolve().parent
W = E.parent
P = 'instance-configuration-produced-proof-01'
OUT = E / (P + '.json')
ADMISSION = E / 'instance-configuration-produced-admission-01.json'
BASE = 'bb0bc47618b6e10347d6a4e91d36911147c3f5d1'
FIXTURE = R / 'tests/fixtures/fake_factorio_install'
SCENARIO = W / 'instance-configuration-produced-01/scenario'
WORKSPACE = SCENARIO / 'workspace'
record = {'status': 'PENDING', 'source': BASE, 'observations': [], 'commands': [],
          'builds': 0, 'candidate_dispatches': 0, 'CI_reruns': 0, 'model_wait_calls': 0,
          'factorio_execution': False, 'human_experience': False,
          'whole_workunit_closed': False, 'new_task_roots': 0}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')

def update():
    temporary = OUT.with_suffix('.writing')
    write(temporary, record)
    temporary.replace(OUT)

def snapshot(root):
    return {path.relative_to(root).as_posix(): sha(path)
            for path in sorted(root.rglob('*')) if path.is_file()}

def observe(name, **facts):
    record['observations'].append({'name': name, 'result': 'PASS', **facts})
    update()

def capture_state(name):
    target = SCENARIO / 'states' / name
    assert not target.exists()
    paths = [path for path in WORKSPACE.rglob('*') if path.is_file()]
    assert sum(path.stat().st_size for path in paths) < 16 * 1024 * 1024
    for path in paths:
        destination = target / path.relative_to(WORKSPACE)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, destination)
    return snapshot(target)

def command(label, args, *, code=0, machine=True, fault=None, stdin=None, raw=False):
    index = len(record['commands']) + 1
    output = E / (P + f'-command-{index:02d}-{label}.stdout')
    errors = output.with_suffix('.stderr')
    argv = [str(CLI), *args] if raw else [str(CLI), '--workspace', str(WORKSPACE), *args]
    if machine:
        argv.append('--json')
    environment = os.environ.copy()
    for name in list(environment):
        if name.startswith('FACMAN_TEST_'):
            environment.pop(name)
    environment.pop('FACMAN_INSTANCE_LIFECYCLE_FAULT', None)
    if fault:
        environment[fault] = '1'
    with output.open('xb') as stream, errors.open('xb') as error_stream:
        process = subprocess.Popen(argv, cwd=DELIVERY, env=environment, stdin=subprocess.PIPE,
                                   stdout=stream, stderr=error_stream)
        entry = {'label': label, 'argv': argv, 'cwd': str(DELIVERY), 'PID': process.pid,
                 'supervisor_PID': os.getpid(), 'fault': fault, 'stdin': stdin,
                 'status': 'RUNNING', 'stdout': str(output), 'stderr': str(errors)}
        record['commands'].append(entry)
        update()
        try:
            process.communicate(None if stdin is None else stdin.encode('utf-8'), timeout=30)
        except BaseException:
            # Only this exact child is owned. Never kill an application directory tree.
            process.kill()
            process.wait(timeout=10)
            raise
    entry.update(status='TERMINAL', exit_code=process.returncode,
                 stdout_sha256=sha(output), stderr_sha256=sha(errors))
    update()
    text = output.read_text(encoding='utf-8')
    assert process.returncode == code, (label, process.returncode, str(output), str(errors))
    assert not errors.read_bytes(), (label, str(errors))
    if not machine:
        return text
    envelope = json.loads(text)
    assert envelope['schema'] == 'facman.transport_response.v2', label
    if code == 0:
        assert envelope['error'] is None and envelope['payload'] is not None, label
    return envelope

def product(label, args):
    return command(label, args)['payload']

def query(label, scope):
    return product(label, ['presentation', 'query', scope, '--instance', 'copy'])

def select(label, snap, identity, code=0):
    return command(label, ['presentation', 'action', 'profile.select', '--scope', snap['page']['scope'],
                          '--instance', 'copy', '--profile', 'alternate', '--expected-revision', snap['revision'],
                          '--request-id', 'request-' + identity, '--idempotency-key', 'idempotency-' + identity,
                          '--operation-id', 'operation-' + identity, '--attempt-id', 'attempt-' + identity,
                          '--confirmation', 'explicit'], code=code)

assert __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0'
assert os.environ.get('PYTHONDONTWRITEBYTECODE') == '1'
assert not OUT.exists() and not SCENARIO.exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == BASE
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=R, text=True).strip()
admission = json.loads(ADMISSION.read_text(encoding='utf-8'))
assert admission['status'] == 'ADMITTED_EXISTING_PRODUCED_WINDOWS_DELIVERY'
assert admission['source'] == BASE
CLI = Path(admission['executable'])
DELIVERY = Path(admission['delivery'])
assert CLI.resolve().is_relative_to(W.resolve()) and sha(CLI) == admission['executable_sha256']
marker = json.loads((W / '.facman-development-root.v1.json').read_text(encoding='utf-8'))
assert marker['task_id'] == 'task/facman-world-restore-retention-01'
assert Path(marker['canonical_path']).samefile(W) and Path(marker['source_root']).samefile(R)
assert shutil.disk_usage(W).free >= 8 * 1024**3 + 128 * 1024**2
write(E / (P + '.claim.json'), {'PID': os.getpid(), 'source': BASE, 'no_automatic_replay': True,
                              'admission_sha256': sha(ADMISSION), 'driver_sha256': sha(Path(__file__))})
SCENARIO.mkdir()
update()
try:
    fixture_before = snapshot(FIXTURE)
    delivery_before = snapshot(DELIVERY)
    normalized = {('bin/FacMan.WinForms.exe' if path == 'FacMan.exe' else path): digest
                  for path, digest in delivery_before.items()}
    assert len(normalized) == len(delivery_before) == 587
    with zipfile.ZipFile(E / 'instance-configuration-current-Windows-composition-01.zip') as archive:
        composition = json.loads(archive.read('windows-package-composition-proof.v1.json'))
    assert composition['status'] == 'pass' and composition['source_revisions']['factorio_launcher'] == BASE
    package = composition['packages']['windows_legacy_winforms_x64']
    tree = hashlib.sha256(json.dumps(normalized, separators=(',', ':'), sort_keys=True).encode()).hexdigest()
    assert tree == package['tree_sha256'] and sorted(normalized) == package['inventory']
    for line in (DELIVERY / 'manifest/hashes.sha256').read_text(encoding='utf-8').splitlines():
        digest, name = line.split('  ', 1)
        assert normalized[name] == digest, name
    build_info = json.loads((DELIVERY / 'manifest/build_info.v1.json').read_text(encoding='utf-8'))
    assert build_info['profile_id'] == 'windows_legacy_winforms_x64'
    assert hashlib.sha256(build_info['build_identity'].encode()).hexdigest() == package['build_identity_sha256']
    record['delivery_identity'] = {'artifact_id': 11336873964, 'run_id': 37287317294,
                                   'head_sha': BASE, 'artifact_sha256': admission['artifact_sha256'],
                                   'payload_sha256': admission['payload_sha256'], 'file_count': len(normalized),
                                   'portable_tree_sha256': tree, 'executable_sha256': sha(CLI),
                                   'build_identity_sha256': package['build_identity_sha256'],
                                   'components': {name: normalized[name] for name in
                                                  ('bin/facman.exe', 'bin/flb_factorio.dll', 'bin/ulk.dll', 'bin/usk.dll')}}
    observe('exact_produced_delivery_and_shared_components', gui_remap='FacMan.exe -> bin/FacMan.WinForms.exe')
    product('import-readonly-fixture', ['installs', 'import', str(FIXTURE), '--id', 'fixture'])
    product('create-main', ['instances', 'create', 'Main', '--id', 'main', '--install', 'fixture'])
    main = WORKSPACE / 'instances/main'
    original = (main / 'instance.v1.json').read_bytes()
    assert json.loads(original)['install_ref'] == 'fixture'
    assert main.is_dir() and not main.resolve().is_relative_to(FIXTURE.resolve())
    product('create-profile', ['profiles', 'create', 'quiet', '--audio', 'disabled', '--graphics-quality', 'low'])
    before = snapshot(WORKSPACE)
    planned = product('plan-config', ['profiles', 'plan', 'main', 'quiet', '--window-mode', 'fullscreen'])
    assert planned['source_manifest_sha256'] == hashlib.sha256(original).hexdigest()
    assert planned['settings']['audio'] == 'disabled' and planned['settings']['window_mode'] == 'fullscreen'
    assert planned['provenance']['setting_sources']['audio'] == 'profile'
    assert planned['provenance']['setting_sources']['window_mode'] == 'request_override'
    assert not planned['mutation_executed'] and not planned['execution_enabled']
    human = command('human-config-plan', ['profiles', 'plan', 'main', 'quiet', '--window-mode', 'fullscreen'], machine=False)
    assert 'audio: disabled [profile]' in human and 'window_mode: fullscreen [request override]' in human
    assert 'No files changed.' in human and snapshot(WORKSPACE) == before
    applied = product('apply-config', ['profiles', 'apply', 'main', 'quiet', '--window-mode', 'fullscreen',
                        '--expected-plan', planned['plan_sha256'], '--expected-revision', planned['source_manifest_sha256']])
    assert applied['settings'] == planned['settings'] and applied['provenance'] == planned['provenance']
    assert json.loads((main / 'instance.v1.json').read_text())['profile'] == 'quiet'
    overrides = json.loads((main / 'instance-overrides.v1.json').read_text())
    assert overrides['profile_id'] == 'quiet' and overrides['values']['window_mode'] == 'fullscreen'
    observe('create_review_and_configure_isolated_instance', manifest_before_sha256=hashlib.sha256(original).hexdigest(),
            plan_sha256=planned['plan_sha256'], requested_settings=planned['settings'])
    (main / 'script-output/preserved.txt').write_text('owned public fixture\n', encoding='utf-8')
    (main / 'logs/volatile.log').write_text('volatile public fixture\n', encoding='utf-8')
    source_before = snapshot(main)
    product('clone', ['instances', 'clone', 'main', 'copy'])
    copy = WORKSPACE / 'instances/copy'
    assert (copy / 'script-output/preserved.txt').read_bytes() == (main / 'script-output/preserved.txt').read_bytes()
    assert not (copy / 'logs/volatile.log').exists()
    assert {k: v for k, v in source_before.items() if k != 'locks/configuration.write.lock'} == {
        k: v for k, v in snapshot(main).items() if k != 'locks/configuration.write.lock'}
    manifest_path = copy / 'instance.v1.json'
    cloned = json.loads(manifest_path.read_text())
    assert cloned['source_instance'] == 'main' and cloned['profile'] == 'quiet'
    revision = sha(manifest_path)
    product('rename-copy', ['instances', 'rename', 'copy', '--name', 'Configured Copy', '--expected-revision', revision])
    renamed = json.loads(manifest_path.read_text())
    expected = dict(cloned, display_name='Configured Copy')
    assert renamed == expected
    before = snapshot(WORKSPACE)
    stale = command('stale-rename', ['instances', 'rename', 'copy', '--name', 'Stale', '--expected-revision', revision], code=1)
    assert stale['error']['code'] == 'instance_manifest_revision_changed'
    assert snapshot(WORKSPACE) == before
    product('verify-copy', ['instances', 'verify', 'copy'])
    observe('clone_and_rename_preserve_identity_provenance_source_and_owned_content',
            source_snapshot=source_before, copy_manifest_sha256=sha(manifest_path))
    product('create-alternate', ['profiles', 'create', 'alternate', '--audio', 'enabled'])
    stale_snapshots = {scope: query('old-' + scope, scope) for scope in ('instances', 'content')}
    product('archive-alternate', ['profiles', 'archive', 'alternate'])
    product('replace-alternate', ['profiles', 'create', 'alternate', '--audio', 'disabled'])
    before = snapshot(WORKSPACE)
    fresh = {scope: query('fresh-' + scope, scope) for scope in ('instances', 'content')}
    assert snapshot(WORKSPACE) == before
    for scope, old in stale_snapshots.items():
        assert old['revision'] != fresh[scope]['revision']
        refusal = select('stale-select-' + scope, old, 'stale-' + scope, code=1)
        assert refusal['error']['code'] == 'stale_snapshot_revision'
        assert snapshot(WORKSPACE) == before
    selected = select('select-fresh', fresh['instances'], 'fresh')
    assert selected['payload']['outcome'] == 'completed'
    assert json.loads(manifest_path.read_text())['profile'] == 'alternate'
    before = snapshot(WORKSPACE)
    assert select('select-replay', fresh['instances'], 'fresh') == selected
    assert snapshot(WORKSPACE) == before
    observe('ordinary_selection_binds_replaced_profile_in_both_scopes_and_replays',
            stale_scopes=['instances', 'content'], preserved_manifest_fields=['source_instance', 'cloned_at'])
    original_manifest = manifest_path.read_bytes()
    original_overrides = (copy / 'instance-overrides.v1.json').read_bytes()
    next_plan = product('plan-before-loss', ['profiles', 'plan', 'copy', 'quiet'])
    command('process-loss-after-manifest', ['profiles', 'apply', 'copy', 'quiet',
              '--expected-plan', next_plan['plan_sha256']], code=86, machine=False,
              fault='FACMAN_TEST_PROFILE_APPLY_EXIT_AFTER_MANIFEST')
    assert json.loads(manifest_path.read_text())['profile'] == 'quiet'
    assert (copy / 'instance-overrides.v1.json').read_bytes() == original_overrides
    crash_state = capture_state('after-process-loss')
    before = snapshot(WORKSPACE)
    inspected = product('recovery-inspect', ['workspace', 'recovery', 'inspect'])
    pending = [transaction for transaction in inspected['transactions']
               if transaction['command_id'] == 'profiles.apply' and transaction['state'] == 'committing']
    assert len(pending) == 1
    transaction = pending[0]['transaction_id']
    recovery_plan = product('recovery-plan', ['workspace', 'recovery', 'plan', transaction])
    assert 'verify_and_reconcile_profile_pair' in recovery_plan['transactions'][0]['actions']
    assert snapshot(WORKSPACE) == before
    recovered = product('recovery-apply', ['workspace', 'recovery', 'apply', transaction])
    assert recovered['transactions'][0]['state'] == 'complete'
    assert json.loads((copy / 'instance-overrides.v1.json').read_text())['profile_id'] == 'quiet'
    backup = WORKSPACE / 'backups/profiles' / (transaction + '-copy')
    assert (backup / 'instance.v1.json').read_bytes() == original_manifest
    assert (backup / 'instance-overrides.v1.json').read_bytes() == original_overrides
    recovered_state = capture_state('after-recovery')
    before = snapshot(WORKSPACE)
    refused = command('stale-plan-after-recovery', ['profiles', 'apply', 'copy', 'quiet',
                      '--expected-plan', next_plan['plan_sha256']], code=1)
    assert refused['error']['code'] == 'profile_preparation_revision_changed'
    assert snapshot(WORKSPACE) == before
    retry = product('fresh-retry-plan', ['profiles', 'plan', 'copy', 'quiet', '--audio', 'enabled'])
    human = command('fresh-retry-apply', ['profiles', 'apply', 'copy', 'quiet', '--audio', 'enabled',
                    '--expected-plan', retry['plan_sha256'], '--expected-revision', retry['source_manifest_sha256']], machine=False)
    assert 'Applied profile quiet for instance copy' in human and 'audio: enabled [request override]' in human
    assert json.loads((copy / 'instance-overrides.v1.json').read_text())['values']['audio'] == 'enabled'
    observe('real_child_process_loss_recovery_original_pair_custody_stale_refusal_and_fresh_retry',
            transaction_id=transaction, crash_exit=86, crash_snapshot=crash_state, recovery_snapshot=recovered_state)
    before = snapshot(WORKSPACE)
    launch = product('launch-plan', ['launch', 'plan', 'copy'])
    readiness = product('readiness', ['instances', 'readiness', 'copy'])
    assert launch['profile_id'] == 'quiet'
    assert next(dimension for dimension in readiness['dimensions'] if dimension['id'] == 'profile')['state'] == 'satisfied'
    assert 'instance_launch_intent_mismatch' not in {item['code'] for item in readiness['blockers']}
    assert all(value is False for value in readiness['operation_guarantees'].values())
    human = command('human-readiness', ['instances', 'readiness', 'copy'], machine=False)
    assert 'Configuration:' in human
    tui = command('ordinary-linear-tui', ['tui', '--workspace', str(WORKSPACE), '--instance', 'copy',
                  '--ordinary', '--plain'], machine=False, stdin='2\n4\nq\n', raw=True)
    assert 'FacMan - Factorio Manager' in tui and 'quiet' in tui and 'Configured Copy' in tui
    assert snapshot(WORKSPACE) == before
    final_manifest = json.loads(manifest_path.read_text())
    for name in ('source_instance', 'cloned_at', 'save_policy', 'export_policy', 'instance_id'):
        assert final_manifest[name] == cloned[name]
    assert snapshot(FIXTURE) == fixture_before and snapshot(DELIVERY) == delivery_before
    observe('selected_profile_readiness_and_ordinary_linear_tui_read_only',
            profile_dimension='satisfied', configuration_state=readiness['configuration_state'],
            launch_plan_profile=launch['profile_id'], genuine_game_readiness_claimed=False,
            fixture_unchanged=True, produced_delivery_unchanged=True)
    record.update(status='PASS_SCOPED_CURRENT_PRODUCED_WINDOWS_INSTANCE_CONFIGURATION',
                  fixture_identity=fixture_before, final_workspace_snapshot=snapshot(WORKSPACE),
                  command_count=len(record['commands']), finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  limits=['public fake install; no Factorio execution', 'automated linear TUI only; no human/fullscreen experience',
                          'Windows shared WinForms package only; no Linux or macOS qualification',
                          'InstanceConfiguration remains planned; federated Make Ready remains active'])
    update()
    print(json.dumps({key: record[key] for key in ('status', 'command_count', 'builds', 'CI_reruns', 'whole_workunit_closed')}))
except BaseException as error:
    record['status'] = 'ACTIONABLE_FAILURE'
    record['error'] = repr(error)
    record['failure_workspace_snapshot'] = snapshot(WORKSPACE)
    update()
    raise
