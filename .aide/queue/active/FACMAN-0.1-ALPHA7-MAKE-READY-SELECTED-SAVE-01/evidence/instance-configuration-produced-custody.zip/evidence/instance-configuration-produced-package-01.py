"""Bind final delivery/state, preserve proof custody, and prepare scoped evidence."""
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tomllib
import zipfile

R = Path(r'D:/Projects/Factorio/factorio-launcher')
E = Path(__file__).resolve().parent
W = E.parent
P = 'instance-configuration-produced'
U = 'FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
BASE = 'bb0bc47618b6e10347d6a4e91d36911147c3f5d1'
B = 'task/facman-world-restore-retention-01'
Q = R / '.aide/queue/active' / U / 'evidence'
sys.path.insert(0, str(R / '.aide/scripts'))
import aide_lite as aide

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=R, text=True, encoding='utf-8').strip()

def check(name, args):
    log = E / (P + '-precommit-' + name + '.log')
    with log.open('x', encoding='utf-8') as stream:
        run = subprocess.run(args, cwd=R, stdout=stream, stderr=subprocess.STDOUT, timeout=900)
    entry = dict(check=name, argv=args, exit_code=run.returncode, log=str(log), sha256=sha(log))
    assert run.returncode == 0, entry
    return entry

assert __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0'
assert os.environ.get('PYTHONDONTWRITEBYTECODE') == '1'
assert git('rev-parse', 'HEAD') == BASE and git('branch', '--show-current') == B
assert not git('status', '--porcelain')
admission_path = E / (P + '-admission-01.json')
admission = json.loads(admission_path.read_text())
proof_path = E / (P + '-completion-02.json')
proof = json.loads(proof_path.read_text())
assert proof['status'] == 'PASS_SCOPED_CURRENT_PRODUCED_WINDOWS_INSTANCE_CONFIGURATION'
assert proof['total_commands'] == 34 and proof['new_command_count'] == 1
prior_path = E / (P + '-proof-01.json')
assert sha(prior_path) == proof['prior_receipt_sha256']
prior = json.loads(prior_path.read_text())
for entry in [*prior['commands'], *proof['new_commands']]:
    assert sha(Path(entry['stdout'])) == entry['stdout_sha256']
    assert sha(Path(entry['stderr'])) == entry['stderr_sha256']
delivery = Path(admission['delivery'])
payload = W / 'instance-configuration-produced-01' / admission['package_record']['payload']['filename']
assert sha(payload) == admission['payload_sha256']
with zipfile.ZipFile(payload) as archive:
    prefix = 'facman/generations/' + admission['package_record']['version'] + '/'
    files = [entry for entry in archive.infolist() if entry.filename.startswith(prefix) and not entry.is_dir()]
    assert len(files) == 587
    for entry in files:
        path = delivery / entry.filename[len(prefix):]
        assert path.resolve().is_relative_to(delivery.resolve())
        assert hashlib.sha256(archive.read(entry)).hexdigest() == sha(path), path
    assert sorted(path.relative_to(delivery).as_posix() for path in delivery.rglob('*') if path.is_file()) == sorted(
        entry.filename[len(prefix):] for entry in files)
fixture = R / 'tests/fixtures/fake_factorio_install'
tracked = git('ls-files', 'tests/fixtures/fake_factorio_install').splitlines()
assert sorted(str(path.relative_to(R)).replace('\\', '/') for path in fixture.rglob('*') if path.is_file()) == sorted(tracked)
fixture_identity = {}
for path in tracked:
    oid = git('hash-object', '--path', path, path)
    assert oid == git('rev-parse', BASE + ':' + path)
    fixture_identity[path] = dict(final_raw_sha256=sha(R / path), git_filtered_blob=oid)
terminal = E / (P + '-final-state.json')
write(terminal, dict(status='PASS_FINAL_DELIVERY_AND_COMMITTED_PUBLIC_FIXTURE', source=BASE,
                     payload_sha256=sha(payload), verified_delivery_files=587, fixture=fixture_identity,
                     fixture_comparison='Final complete fixture file set and Git-filtered bytes match exact source; no invented initial raw-byte baseline'))
members = {}
for pattern in (P + '-admission-01*', P + '-proof-01*', P + '-completion-02*',
                P + '-proof-nonauthoring-review-0*', P + '-branch-01*', P + '-prebranch*'):
    for path in E.glob(pattern):
        if path.is_file() and path.suffix != '.writing':
            members['evidence/' + path.name] = path
members['evidence/' + terminal.name] = terminal
members['evidence/' + Path(__file__).name] = Path(__file__)
members['artifacts/windows-package-composition-proof.v1.json'] = E / 'instance-configuration-current-Windows-composition-01.zip'
for path in (W / 'instance-configuration-produced-01/scenario').rglob('*'):
    if path.is_file():
        assert path.suffix.lower() not in ('.exe', '.dll')
        members['scenario/' + path.relative_to(W / 'instance-configuration-produced-01/scenario').as_posix()] = path
for name in ('build_info.v1.json', 'components.v1.json', 'hashes.sha256', 'package.v1.toml'):
    members['delivery-manifest/' + name] = delivery / 'manifest' / name
archive_path = Q / 'instance-configuration-produced-custody.zip'
member_digests = {}
with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name, path in sorted(members.items()):
        if name == 'artifacts/windows-package-composition-proof.v1.json':
            with zipfile.ZipFile(path) as original:
                data = original.read('windows-package-composition-proof.v1.json')
        else:
            data = path.read_bytes()
        archive.writestr(name, data)
        member_digests[name] = hashlib.sha256(data).hexdigest()
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    assert {name: hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist()} == member_digests
canonical = R / 'release/index/plan.v1.toml'
original = canonical.read_text(encoding='utf-8')
plan = tomllib.loads(original)
unit = next(item for item in plan['workunit'] if item['id'] == U)
assert unit['status'] == 'active' and len(unit['close_after']) == 5
dependencies = {item['id']: item['status'] for item in plan['workunit'] if item['id'] in unit['close_after']}
assert sorted(dependencies.values()) == ['active', 'complete', 'complete', 'planned', 'planned']
receipt_path = Q / 'instance-configuration-produced.v1.json'
write(receipt_path, dict(schema='facman.partial_acceptance.v1',
    status='PASS_SCOPED_CURRENT_PRODUCED_WINDOWS_INSTANCE_CONFIGURATION', work_item=U, base=BASE,
    related_work_item='FACMAN-0.1-ALPHA7-INSTANCE-CONFIGURATION-01',
    execution_kind='Existing CI self-setup payload extracted; genuine produced shared runtime executed outside source checkout',
    produced_delivery=proof['delivery_identity'],
    evidence_links=dict(producer_run='https://github.com/Julesc013/factorio-launcher/actions/runs/37287317294',
                        artifact_id=11336873964, composition_artifact_id=11337113330),
    acceptance_scope=dict(create_isolated_instance=True, review_and_edit_profile_provenance=True,
                          clone_and_rename_identity=True, ordinary_profile_selection=True,
                          stale_both_scopes_refused=True, exact_replay=True, real_child_process_loss_exit=86,
                          interrupted_pair_recovered=True, original_pair_backups_verified=True,
                          stale_plan_after_recovery_refused=True, fresh_retry_persisted=True,
                          selected_profile_readiness=True, ordinary_linear_TUI=True,
                          total_process_commands=34, retained_invalid_driver_invocations=1,
                          completion_only_commands=1, completed_journey_replayed=False),
    failures=dict(pre_execution_driver_oracles_corrected=True,
                  retained_driver_failure='Unsupported TUI --instance option refused with exit 2; corrected final TUI only',
                  original_receipt_sha256=sha(prior_path)),
    proof_sha256=sha(proof_path), admission_sha256=sha(admission_path), final_state_sha256=sha(terminal),
    custody=dict(path=archive_path.relative_to(R).as_posix(), sha256=sha(archive_path), members=member_digests),
    close_after_status=dependencies, original_acceptance_unchanged=True,
    whole_workunit_closed=False, related_workunit_status_changed=False,
    authority=dict(factorio_execution=False, human_experience=False, release_qualification=False,
                   protected_control=False, provider_adoption=False, publication=False),
    resource=dict(new_roots=0, new_worktrees=0, builds=0, candidate_dispatches=0, CI_reruns=0, model_wait_calls=0),
    remaining=['Federated typed Make Ready and selected-world preparation remain open',
               'InstanceConfiguration still planned; no Linux/macOS, real-game or human/fullscreen qualification',
               'PR343 protected-control owner gate and genuine distinct A5/A6 maintenance remain external gates'],
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
start = original.index('id = "' + U + '"')
end = original.index('\n\n[[workunit]]', start)
section = original[start:end]
needle = '\n]\nqueue_task = '
assert section.count(needle) == 1
section = section.replace(needle, '\n  ' + json.dumps(receipt_path.relative_to(R).as_posix()) + ',\n]\nqueue_task = ', 1)
canonical.write_text(original[:start] + section + original[end:], encoding='utf-8', newline='\n')
expected = copy.deepcopy(plan)
next(item for item in expected['workunit'] if item['id'] == U)['evidence'].append(receipt_path.relative_to(R).as_posix())
assert tomllib.loads(canonical.read_text(encoding='utf-8')) == expected
checks = []
for name, args in [('plan-generate', ['tools/generate_plan_views.py']), ('state-generate', ['tools/project_state.py', '--write']),
                   ('plan-check', ['tools/generate_plan_views.py', '--check']), ('state-check', ['tools/project_state.py', '--validate']),
                   ('state-tests', ['-m', 'unittest', 'tests.test_plan_views', 'tests.test_current_truth_roles', 'tests.test_aide_target_truth', 'tests.test_aide_compaction']),
                   ('strict', ['tools/strict_check.py']), ('format', ['tools/source_format_check.py'])]:
    checks.append(check(name, [sys.executable, '-B', *args]))
checks.append(check('diff', ['git', 'diff', '--check']))
message = E / (P + '-commit.txt')
text = ('test(instances): prove current Windows configuration delivery\n\n'
        'Work-Item: ' + U + '\nEvidence-Ref: ' + receipt_path.relative_to(R).as_posix() + '\n')
with message.open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(text)
checks.append(check('template', [sys.executable, '-B', '.aide/scripts/aide_lite.py', 'commit', 'template']))
checks.append(check('message', [sys.executable, '-B', '.aide/scripts/aide_lite.py', 'commit', 'check', '--message', text]))
paths = set(git('diff', '--name-only').splitlines()) | set(git('ls-files', '--others', '--exclude-standard').splitlines())
allowed = {canonical.relative_to(R).as_posix(), receipt_path.relative_to(R).as_posix(), archive_path.relative_to(R).as_posix(),
           'README.md', 'docs/roadmap.md', 'docs/release/checkpoints/README.md', 'release/index/current_state.v1.toml',
           'release/index/project_status.v2.toml', '.aide/memory/project-state.md', '.aide/memory/project-state.v2.json', 'todo.md'}
assert paths <= allowed, sorted(paths - allowed)
changed = [dict(path=path, state='content', sha256=sha(R / path), git_blob_oid=git('hash-object', '--path', path, path),
                ownership='task_owned') for path in sorted(paths)]
classification = dict(schema_version=aide.GIT_COMMIT_CLASSIFICATION_SCHEMA, branch=B, base_commit=BASE, work_item=U,
                      message_sha256=sha(message), snapshot_sha256=aide.helper_commit_snapshot_sha256(changed),
                      changed_paths=changed, reviews=[])
write(E / (P + '-commit-classification.json'), classification)
write(E / (P + '-precommit-QA.json'), dict(status='PASS', metadata_checks=checks, proof_sha256=sha(proof_path),
          receipt_sha256=sha(receipt_path), snapshot_sha256=classification['snapshot_sha256'],
          product_source_changed=False, new_builds=0, whole_workunit_closed=False))
print(json.dumps(dict(status='PASS_PACKAGED_AND_CLASSIFIED', changed_paths=len(changed), custody_members=len(members),
                     receipt_sha256=sha(receipt_path), custody_sha256=sha(archive_path),
                     classification_sha256=sha(E / (P + '-commit-classification.json')))))
