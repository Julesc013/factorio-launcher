"""Finish only the valid ordinary TUI observation after a driver option refusal."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

R = Path(r'D:/Projects/Factorio/factorio-launcher')
E = Path(__file__).resolve().parent
W = E.parent
P = 'instance-configuration-produced-completion-02'
OUT = E / (P + '.json')
PRIOR = E / 'instance-configuration-produced-proof-01.json'
ADMISSION = E / 'instance-configuration-produced-admission-01.json'
BASE = 'bb0bc47618b6e10347d6a4e91d36911147c3f5d1'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot(root):
    return {path.relative_to(root).as_posix(): sha(path)
            for path in sorted(root.rglob('*')) if path.is_file()}

def write(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')

def update():
    temporary = OUT.with_suffix('.writing')
    write(temporary, record)
    temporary.replace(OUT)

assert __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0'
assert os.environ.get('PYTHONDONTWRITEBYTECODE') == '1'
assert not OUT.exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == BASE
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=R, text=True).strip()
admission = json.loads(ADMISSION.read_text(encoding='utf-8'))
prior = json.loads(PRIOR.read_text(encoding='utf-8'))
assert prior['status'] == 'ACTIONABLE_FAILURE' and prior['source'] == BASE
assert len(prior['commands']) == 33 and len(prior['observations']) == 5
assert prior['commands'][-1]['label'] == 'ordinary-linear-tui'
assert prior['commands'][-1]['exit_code'] == 2
for entry in prior['commands']:
    assert entry['status'] == 'TERMINAL'
    assert sha(Path(entry['stdout'])) == entry['stdout_sha256']
    assert sha(Path(entry['stderr'])) == entry['stderr_sha256']
assert 'Invalid TUI option' in Path(prior['commands'][-1]['stderr']).read_text()
CLI = Path(admission['executable'])
DELIVERY = Path(admission['delivery'])
WORKSPACE = W / 'instance-configuration-produced-01/scenario/workspace'
assert CLI.resolve().is_relative_to(W.resolve()) and sha(CLI) == admission['executable_sha256']
marker = json.loads((W / '.facman-development-root.v1.json').read_text())
assert marker['task_id'] == 'task/facman-world-restore-retention-01'
assert Path(marker['canonical_path']).samefile(W) and Path(marker['source_root']).samefile(R)
before = snapshot(WORKSPACE)
assert before == prior['failure_workspace_snapshot']
fixture_before = snapshot(R / 'tests/fixtures/fake_factorio_install')
delivery_before = snapshot(DELIVERY)
assert all(snapshot(W / 'instance-configuration-produced-01/scenario/states' / name) ==
           prior['observations'][-1][key]
           for name, key in [('after-process-loss', 'crash_snapshot'), ('after-recovery', 'recovery_snapshot')])
record = dict(status='PENDING', source=BASE, prior_receipt_sha256=sha(PRIOR),
              driver_sha256=sha(Path(__file__)), preserved_failure='unsupported --instance TUI driver option; no package defect',
              delivery_identity=prior['delivery_identity'], completed_observations=prior['observations'],
              new_commands=[], previous_commands=33, completed_journey_replayed=False,
              builds=0, candidate_dispatches=0, CI_reruns=0, model_wait_calls=0, new_task_roots=0,
              whole_workunit_closed=False, factorio_execution=False, human_experience=False)
write(E / (P + '.claim.json'), {'PID': os.getpid(), 'no_automatic_replay': True, 'prior_receipt_sha256': sha(PRIOR)})
update()
try:
    output, errors = E / (P + '-tui.stdout'), E / (P + '-tui.stderr')
    argv = [str(CLI), 'tui', '--workspace', str(WORKSPACE), '--ordinary', '--plain']
    environment = os.environ.copy()
    for name in list(environment):
        if name.startswith('FACMAN_TEST_') or name == 'FACMAN_INSTANCE_LIFECYCLE_FAULT':
            environment.pop(name)
    with output.open('xb') as stream, errors.open('xb') as error_stream:
        child = subprocess.Popen(argv, cwd=DELIVERY, env=environment, stdin=subprocess.PIPE,
                                 stdout=stream, stderr=error_stream)
        entry = dict(argv=argv, cwd=str(DELIVERY), PID=child.pid, supervisor_PID=os.getpid(),
                     stdin='2\n4\nq\n', stdout=str(output), stderr=str(errors), status='RUNNING')
        record['new_commands'].append(entry)
        update()
        try:
            child.communicate(b'2\n4\nq\n', timeout=30)
        except BaseException:
            child.kill()
            child.wait(timeout=10)
            raise
    entry.update(status='TERMINAL', exit_code=child.returncode, stdout_sha256=sha(output), stderr_sha256=sha(errors))
    update()
    text = output.read_text(encoding='utf-8')
    assert child.returncode == 0 and not errors.read_bytes()
    assert 'FacMan - Factorio Manager' in text and 'quiet' in text
    assert 'Instance: Configured Copy' in text
    assert snapshot(WORKSPACE) == before and snapshot(DELIVERY) == delivery_before
    assert snapshot(R / 'tests/fixtures/fake_factorio_install') == fixture_before
    copy = WORKSPACE / 'instances/copy'
    manifest = json.loads((copy / 'instance.v1.json').read_text())
    assert manifest['instance_id'] == 'copy' and manifest['source_instance'] == 'main'
    assert manifest['display_name'] == 'Configured Copy' and manifest['profile'] == 'quiet'
    assert 'cloned_at' in manifest and 'save_policy' in manifest and 'export_policy' in manifest
    assert json.loads((copy / 'instance-overrides.v1.json').read_text())['values']['audio'] == 'enabled'
    record.update(status='PASS_SCOPED_CURRENT_PRODUCED_WINDOWS_INSTANCE_CONFIGURATION',
                  total_commands=34, expected_process_loss_exit=86, retained_driver_refusal_count=1,
                  new_command_count=1, readonly_TUI=True, source_fixture_unchanged=True,
                  produced_delivery_unchanged=True, final_workspace_snapshot=before,
                  finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  limits=['public fake install; no Factorio execution', 'automated linear TUI only; no human/fullscreen experience',
                          'Windows shared WinForms package only; no Linux or macOS qualification',
                          'InstanceConfiguration remains planned; federated Make Ready remains active'])
    update()
    print(json.dumps({key: record[key] for key in ('status', 'total_commands', 'new_command_count', 'completed_journey_replayed')}))
except BaseException as error:
    record.update(status='ACTIONABLE_FAILURE', error=repr(error), failure_workspace_snapshot=snapshot(WORKSPACE))
    update()
    raise
