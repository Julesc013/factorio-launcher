import hashlib,json,os,shlex,subprocess,traceback
from pathlib import Path
R=Path('/mnt/d/Projects/Factorio/factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent;B=W/'native-save-context-linux'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads((E/'posix-preparation-publication-source-assurance-05.json').read_bytes())
for n,h in a['source_files_sha256'].items():assert sha(R/n)==h,n
os.environ.update(PYTHONDONTWRITEBYTECODE='1',GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.autocrlf',GIT_CONFIG_VALUE_0='true',FACMAN_DEV_ROOT='/mnt/d/Projects/Factorio/.task-builds',TMPDIR=str(W/'t'))
out=E/'posix-publication-ci-warning-linux-result-01.json';assert not out.exists()
v=dict(status='QUALIFYING_LINUX_ONLY_TEST_CORRECTION',source_assurance_sha256=sha(E/'posix-preparation-publication-source-assurance-05.json'),commands=[])
def run(label,args,expected=0,timeout=300,env=None):
 with (E/('posix-ci-warning-'+label+'.stdout')).open('xb') as o,(E/('posix-ci-warning-'+label+'.stderr')).open('xb') as err:
  p=subprocess.run(args,cwd=R,env=env,stdout=o,stderr=err,timeout=timeout)
 v['commands'].append(dict(label=label,argv=args,exit=p.returncode,stdout_sha256=sha(E/('posix-ci-warning-'+label+'.stdout')),stderr_sha256=sha(E/('posix-ci-warning-'+label+'.stderr'))))
 assert p.returncode==expected,(label,p.returncode)
fixture=E/'posix-publication-private-fixtures-01';mounted=False
try:
 raw=subprocess.check_output(['ninja','-C',str(B),'-t','commands','fl_platform_io_smoke'],text=True,timeout=30)
 (E/'posix-ci-warning-cached-compile-commands-01.txt').write_text(raw)
 matches=[shlex.split(s) for s in raw.splitlines() if '-c ' in s and str(R/'tests/native/fl_platform_io_smoke.cpp') in s]
 assert len(matches)==1
 args=matches[0];filtered=[];index=0
 while index<len(args):
  if args[index] in ('-o','-MF','-MT','-MQ'):index+=2;continue
  if args[index] in ('-c','-MD','-MMD'):index+=1;continue
  filtered.append(args[index]);index+=1
 source=str(R/'tests/native/fl_platform_io_smoke.cpp');assert filtered.count(source)==1
 strict=filtered+['-Wall','-Wextra','-Wpedantic','-Werror','-fsyntax-only']
 original=list(strict);original[original.index(source)]=str(E/'posix-publication-ci-warning-author-01/fl_platform_io_smoke.before.cpp')
 run('baseline-strict-syntax',original,expected=1)
 assert 'range-loop-construct' in (E/'posix-ci-warning-baseline-strict-syntax.stderr').read_text()
 run('corrected-strict-syntax',strict)
 run('native-target-build',['cmake','--build',str(B),'--parallel','2','--target','fl_platform_io_smoke'])
 v['native_smoke_sha256']=sha(B/'tests/native/fl_platform_io_smoke')
 assert fixture.is_dir() and not list(fixture.iterdir()) and not os.path.ismount(fixture)
 subprocess.run(['mount','-t','tmpfs','-o','size=128m,nosuid,nodev,mode=1777','facman-warning-regression',str(fixture)],check=True,timeout=30);mounted=True
 env=dict(os.environ,TMPDIR=str(fixture),TMP=str(fixture),TEMP=str(fixture))
 run('native-unprivileged',['setpriv','--reuid=65534','--regid=65534','--clear-groups',str(B/'tests/native/fl_platform_io_smoke')],env=env)
 assert not list(fixture.iterdir())
 for n,h in a['source_files_sha256'].items():assert sha(R/n)==h,n
 v.update(status='PASS_STRICT_GCC_AND_REBUILT_LINUX_PLATFORM_SMOKE',uid=65534,groups=[],runtime_source_unchanged=True,windows_qualification_reused=True,linux_owner_qualification_reused=True,new_build_roots=0,new_clones=0)
except BaseException as ex:v.update(status='ACTIONABLE_WARNING_CORRECTION_QUALIFICATION_FAILURE',error=str(ex),traceback=traceback.format_exc())
finally:
 if mounted:
  if list(fixture.iterdir()):
   archive=E/'posix-ci-warning-unresolved-fixture-state-01.tar';assert not archive.exists()
   subprocess.run(['tar','-cf',str(archive),'-C',str(fixture),'.'],check=True,timeout=60);v['unresolved_fixture_sha256']=sha(archive)
  subprocess.run(['umount',str(fixture)],check=True,timeout=30)
 v['private_mount_absent']=not os.path.ismount(fixture);out.write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v))
raise SystemExit(0 if v['status']=='PASS_STRICT_GCC_AND_REBUILT_LINUX_PLATFORM_SMOKE' else 1)
