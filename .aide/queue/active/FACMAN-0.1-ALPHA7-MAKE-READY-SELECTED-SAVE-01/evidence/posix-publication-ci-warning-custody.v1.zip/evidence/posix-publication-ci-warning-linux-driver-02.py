import hashlib,json,os,subprocess,traceback
from pathlib import Path
R=Path('/mnt/d/Projects/Factorio/factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent;B=W/'native-save-context-linux'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads((E/'posix-preparation-publication-source-assurance-05.json').read_bytes());old=E/'posix-publication-ci-warning-linux-result-01.json';q=json.loads(old.read_bytes())
assert q['source_assurance_sha256']==sha(E/'posix-preparation-publication-source-assurance-05.json')
assert [(x['label'],x['exit']) for x in q['commands']]==[('baseline-strict-syntax',1),('corrected-strict-syntax',0),('native-target-build',0)]
for n,h in a['source_files_sha256'].items():assert sha(R/n)==h,n
info=json.loads(subprocess.check_output(['ctest','--test-dir',str(B),'-N','--show-only=json-v1','-R','^fl_platform_io_smoke$'],timeout=30))
assert len(info['tests'])==1 and info['tests'][0]['name']=='fl_platform_io_smoke'
exe=Path(info['tests'][0]['command'][0]);assert exe.resolve().is_relative_to(B.resolve()) and exe.is_file() and not exe.is_symlink()
fixture=E/'posix-publication-private-fixtures-01';assert fixture.is_dir() and not list(fixture.iterdir()) and not os.path.ismount(fixture)
out=E/'posix-publication-ci-warning-linux-result-02.json';assert not out.exists()
v=dict(status='RUNNING_EXACT_CTEST_NATIVE_IMAGE',prior_qualification_sha256=sha(old),source_assurance_sha256=q['source_assurance_sha256'],native_image=str(exe),native_sha256=sha(exe),uid=65534,groups=[],prior_build_and_strict_syntax_reused=True)
mounted=False
try:
 subprocess.run(['mount','-t','tmpfs','-o','size=128m,nosuid,nodev,mode=1777','facman-warning-regression',str(fixture)],check=True,timeout=30);mounted=True
 env=dict(os.environ,TMPDIR=str(fixture),TMP=str(fixture),TEMP=str(fixture),FACMAN_DEV_ROOT='/mnt/d/Projects/Factorio/.task-builds')
 with (E/'posix-ci-warning-native02.stdout').open('xb') as o,(E/'posix-ci-warning-native02.stderr').open('xb') as er:
  r=subprocess.run(['setpriv','--reuid=65534','--regid=65534','--clear-groups',str(exe)],cwd=R,env=env,stdout=o,stderr=er,timeout=300)
 assert r.returncode==0 and not list(fixture.iterdir())
 for n,h in a['source_files_sha256'].items():assert sha(R/n)==h,n
 v.update(status='PASS_STRICT_GCC_AND_REBUILT_LINUX_PLATFORM_SMOKE',native_exit=0,runtime_source_unchanged=True,windows_qualification_reused=True,linux_owner_qualification_reused=True,new_build_roots=0,new_clones=0)
except BaseException as ex:v.update(status='ACTIONABLE_WARNING_CORRECTION_QUALIFICATION_FAILURE',error=str(ex),traceback=traceback.format_exc())
finally:
 if mounted:
  if list(fixture.iterdir()):
   archive=E/'posix-ci-warning-unresolved-fixture-state-02.tar';assert not archive.exists();subprocess.run(['tar','-cf',str(archive),'-C',str(fixture),'.'],check=True,timeout=60);v['unresolved_fixture_sha256']=sha(archive)
  subprocess.run(['umount',str(fixture)],check=True,timeout=30)
 v['private_mount_absent']=not os.path.ismount(fixture);out.write_text(json.dumps(v,indent=2));print(json.dumps(v))
raise SystemExit(0 if v['status']=='PASS_STRICT_GCC_AND_REBUILT_LINUX_PLATFORM_SMOKE' else 1)
