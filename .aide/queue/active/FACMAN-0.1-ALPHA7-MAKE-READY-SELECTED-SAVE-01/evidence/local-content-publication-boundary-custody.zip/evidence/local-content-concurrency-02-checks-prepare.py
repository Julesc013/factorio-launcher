import json
from pathlib import Path

E=Path(__file__).resolve().parent
s=(E/'local-content-concurrency-01-checks.py').read_text(encoding='utf-8')
start=s.index("    active=subprocess.run(")
end=s.index("    measured=subprocess.run(",start)
replacement=r'''    classify = """
$facmanHeavy=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('MSBuild.exe','cl.exe','cmake.exe','ninja.exe') })
$facmanResult=@(foreach ($facmanProcess in $facmanHeavy) {
    $facmanParent=@(Get-CimInstance Win32_Process -Filter "ProcessId=$($facmanProcess.ParentProcessId)")
    $facmanOrphan=($facmanProcess.Name -eq 'MSBuild.exe' -and $facmanParent.Count -eq 0 -and $facmanProcess.CommandLine -match '/nodemode:[1-9]' -and $facmanProcess.CommandLine -match '/nodeReuse:true')
    $facmanIdle=$false
    $facmanDelta=$null
    if ($facmanOrphan) {
        $facmanCpu=(Get-Process -Id $facmanProcess.ProcessId -ErrorAction SilentlyContinue).CPU
        Start-Sleep -Seconds 2
        $facmanNow=Get-Process -Id $facmanProcess.ProcessId -ErrorAction SilentlyContinue
        $facmanDelta=if ($null -eq $facmanNow) {0} else {$facmanNow.CPU-$facmanCpu}
        $facmanIdle=($facmanDelta -eq 0)
    }
    [pscustomobject]@{name=$facmanProcess.Name;pid=$facmanProcess.ProcessId;created=$facmanProcess.CreationDate;parent_alive=($facmanParent.Count -gt 0);orphan_reusable_node=$facmanOrphan;cpu_delta_seconds=$facmanDelta;idle_preexisting_node=$facmanIdle;active_job=(-not $facmanIdle)}
})
ConvertTo-Json -InputObject $facmanResult -Compress
"""
    active=subprocess.run(['powershell','-NoProfile','-Command',classify],capture_output=True,text=True,encoding='utf-8',timeout=60)
    assert active.returncode==0
    classified=json.loads(active.stdout)
    with (E/f'{P}-build-process-admission.json').open('x',encoding='utf-8') as f:json.dump(classified,f,indent=2)
    assert not any(p['active_job'] for p in classified),'Preserve active heavy job; never duplicate it'
'''
s=s[:start]+replacement+s[end:]
compile(s,'local-content-concurrency-02-checks.py','exec')
with (E/'local-content-concurrency-02-checks.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
with (E/'local-content-concurrency-01-fixed-build-blocked.json').open('x',encoding='utf-8',newline='\n') as f:
    f.write(json.dumps(dict(status='NO_BUILD_ISSUED_RESOURCE_GUARD',reason='Name-only guard counted MSBuild.exe PID25776. Read-only follow-up found orphan /nodemode:1 /nodeReuse:true, no live parent and CPU delta0 across2seconds. It was preserved; refined guard distinguishes idle nodes and still refuses every active heavy job.',source='transcript and deterministic pre-child harness guard',processes_terminated=0),indent=2)+'\n')
