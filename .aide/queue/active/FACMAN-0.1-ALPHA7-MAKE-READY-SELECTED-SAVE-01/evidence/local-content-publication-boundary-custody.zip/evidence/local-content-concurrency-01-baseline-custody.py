import hashlib
import json
from pathlib import Path
import zipfile

R=Path(r'D:\Projects\Factorio\factorio-launcher')
E=Path(__file__).resolve().parent
W=E.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=['runtime/factorio/modsets/flb_factorio_modset_solver.cpp','tests/test_local_modset_solver.py']
binary=W/'native-developer/Debug/facman.exe'
archive=E/'local-content-concurrency-01-hook-baseline-custody.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for path in source:z.write(R/path,'source/'+path)
    z.write(binary,'native/facman.exe')
files={name:sha(E/name) for name in ['local-content-concurrency-01-hook-build.json','local-content-concurrency-01-baseline-concurrency.json','local-content-concurrency-01-baseline-concurrency-01.log']}
with (E/'local-content-concurrency-01-hook-baseline-custody.json').open('x',encoding='utf-8',newline='\n') as f:
    f.write(json.dumps(dict(status='DEMONSTRATED_LATE_SOURCE_AND_MANAGED_STATE_DRIFT',base='7671fe3f63c269fde9956356a9d174cc143421a9',tests=2,failures=2,instrumentation_only='Owned deterministic pause, no drift revalidation repair yet',native_sha256=sha(binary),source_sha256={p:sha(R/p) for p in source},evidence_sha256=files,archive_sha256=sha(archive),private_inputs_included=False),indent=2)+'\n')
print('Two publication-boundary failures and instrumented source/binary preserved')
