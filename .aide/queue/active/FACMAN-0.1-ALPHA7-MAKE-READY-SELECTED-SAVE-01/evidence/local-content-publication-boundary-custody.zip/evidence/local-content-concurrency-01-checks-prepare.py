from pathlib import Path

E=Path(__file__).resolve().parent
s=(E/'local-content-repair-01-checks.py').read_text(encoding='utf-8')
s=s.replace("else 'local-content-repair-01'", "else 'local-content-concurrency-01'")
s=s.replace('local-content-repair-01-before-build-images','local-content-concurrency-01-before-build-images')
s=s.replace(" 'solver':", " 'concurrency': [['py','-3','-m','unittest','-v','test_local_modset_solver.LocalModsetSolverTests.test_apply_refuses_selected_archive_change_at_publication_boundary','test_local_modset_solver.LocalModsetSolverTests.test_apply_preserves_external_managed_state_change_at_publication_boundary']],\n 'solver':")
s=s.replace("mode in ('focused','solver')", "mode in ('focused','solver','concurrency')")
needle="if mode=='build':\n"
checks="""if mode=='build':
    import shutil
    active=subprocess.run(['powershell','-NoProfile','-Command',"@(Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('MSBuild.exe','cl.exe','cmake.exe','ninja.exe') }).Count"],capture_output=True,text=True,timeout=60)
    assert active.returncode==0 and active.stdout.strip()=='0','Preserve active heavy job; never duplicate it'
    measured=subprocess.run([sys.executable,'-B','tools/workspace_hygiene.py','doctor','--measure'],cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=180)
    doctor=json.loads(measured.stdout)
    with (E/f'{P}-build-resource.json').open('x',encoding='utf-8') as f:json.dump(doctor,f,indent=2)
    assert measured.returncode in {0,1} and set(doctor['violations']) <= {'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
    assert len(doctor['task_roots'])<=8 and doctor['task_root_bytes']+1024**3<=20*1024**3
    assert shutil.disk_usage(W).free>=9*1024**3
"""
s=s.replace(needle,checks,1)
compile(s,'local-content-concurrency-01-checks.py','exec')
with (E/'local-content-concurrency-01-checks.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
