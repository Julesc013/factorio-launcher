import hashlib
import json
from pathlib import Path

E = Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
metadata = E/'local-content-current-artifacts-02.json'
assert sha(metadata) == '568944371c1e18c094d69c5ef3c3d7e64d298055ee693364090f65e5e58d48e9'
m = json.loads(metadata.read_text(encoding='utf-8'))
assert m['source'] == '7671fe3f63c269fde9956356a9d174cc143421a9'
new = (E/'instance-configuration-produced-admission-01.py').read_text(encoding='utf-8')
new = new.replace('instance-configuration-produced-admission-01','local-content-produced-admission-02')
new = new.replace('instance-configuration-current-Windows-self-setup-01.zip','local-content-current-Windows-self-setup-02.zip')
new = new.replace('instance-configuration-produced-01','local-content-produced-02')
new = new.replace('bb0bc47618b6e10347d6a4e91d36911147c3f5d1',m['source'])
new = new.replace('11336873964','11355477681').replace('37287317294','37328110880')
new = new.replace('a7306345b3dc67f3d84501444d3c6a3c0bcbeeac3a3b039b87d44b71af5ecd18','8ddec3deea42e9b99b23c4407073ea88dca30226f44891d6e842f4135bf7169d')
new = new.replace('log.read_text().strip()', "log.read_text(encoding='utf-8').strip()")
extra = '''    composition_artifact = json.loads((E/'local-content-current-artifacts-02.json').read_text(encoding='utf-8'))['artifacts']['windows-package-composition-'+BASE]
    assert composition_artifact['id'] == 11355916649 and composition_artifact['workflow_run']['id'] == 37328110880
    composition_zip = E/'local-content-current-Windows-composition-02.zip'
    with composition_zip.open('xb') as stream, (E/(P+'-composition-download.stderr.log')).open('xb') as errors:
        run = subprocess.run(['gh','api','repos/Julesc013/factorio-launcher/actions/artifacts/11355916649/zip'],cwd=R,stdout=stream,stderr=errors,timeout=180)
    assert run.returncode == 0 and sha(composition_zip) == composition_artifact['digest'].split(':')[1] == '332fc8fccbd4591dfb16bfd30356bf0d2882456a9c9013eaa6d097c9c957e317'
    with zipfile.ZipFile(composition_zip) as archive:
        members,_ = inventory(archive,2*1024**2)
        assert len(members) == 1 and not members[0].is_dir()
        composition = json.loads(archive.read(members[0]))
    assert composition['schema'] == 'facman.windows_package_composition_proof.v1' and composition['status'] == 'pass'
    assert composition['source_revisions']['factorio_launcher'] == BASE and not any(composition['authority'].values())
    for key,path in {'workspace_lock':'release/index/workspace_lock.v1.toml','provider_lock':'release/index/providers.lock.v2.toml','route_v1':'release/index/successor_play_route.v1.toml'}.items():
        assert composition['governing_digests'][key] == sha(R/path)
    actual = {p.relative_to(cli.parent.parent).as_posix():sha(p) for p in sorted(cli.parent.parent.rglob('*')) if p.is_file()}
    closure = composition['packages']['windows_legacy_winforms_x64']
    assert closure['hash_manifest'] == 'pass' and closure['file_count'] == len(actual) == 587
    assert set(closure['inventory']) == set(actual)
    assert closure['tree_sha256'] == hashlib.sha256(json.dumps(actual,separators=(',',':'),sort_keys=True).encode('utf-8')).hexdigest()
    build_info = json.loads((cli.parent.parent/'manifest/build_info.v1.json').read_text(encoding='utf-8'))
    assert build_info['profile_id'] == 'windows_legacy_winforms_x64'
    assert closure['build_identity_sha256'] == hashlib.sha256(str(build_info['build_identity']).encode('utf-8')).hexdigest()
    record['composition'] = dict(artifact=composition_artifact,zip_sha256=sha(composition_zip),proof=composition,verified_delivery_files=len(actual),profile='windows_legacy_winforms_x64')
    record['delivery_files_before'] = actual
    record['binding_DLL_sha256'] = sha(cli.parent/'flb_factorio.dll')
'''
new = new.replace("    record.update(status='ADMITTED_EXISTING_PRODUCED_WINDOWS_DELIVERY',",extra+"    record.update(status='ADMITTED_EXISTING_PRODUCED_WINDOWS_DELIVERY',",1)
new = new.replace("for name, args in [('task-inspect'", "for name, args in [('task-inspect'",1)
# The original admission uses the existing owned W root and refuses overwriting
# any artifact, receipt or extraction. No new root, build, dispatch or retry.
compile(new,'local-content-produced-admission-02.py','exec')
dest = E/'local-content-produced-admission-02.py'
with dest.open('x',encoding='utf-8',newline='\n') as f: f.write(new)
print('Prepared exact produced-delivery admission '+sha(dest))
