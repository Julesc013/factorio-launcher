from pathlib import Path

E=Path(__file__).resolve().parent
s=(E/'instance-configuration-produced-branch-01.py').read_text(encoding='utf-8')
s=s.replace('instance-configuration-produced','local-content-concurrency-01')
s=s.replace('bb0bc47618b6e10347d6a4e91d36911147c3f5d1','7671fe3f63c269fde9956356a9d174cc143421a9')
s=s.replace('make-ready-save-terminal-integration-01.json','local-content-repair-integration-01.json')
s=s.replace('8983c0894ea6ab10c8d9af3913764f0fee6d4c953bd7dd3e3fa1bea0fabad260','5d71793648c95a99c12059b85bf6d0588e8a02e86f38c2a7827d630f4af54be0')
s=s.replace('make-ready-save-terminal-final-commit.review.json','local-content-repair-integration-01.review.json')
s=s.replace('92e3b2eb1bdbf6949eccc4b11dc715fdd015a7fdb372f747f4556eadc36c6f61','deff1c328cd4191a286ceb027ca9b5f4cb4c41ecb9aa0cbb0fef6410e3c452eb')
s=s.replace("run('gh', 'auth', 'status')", "assert subprocess.run(['gh','auth','status'],cwd=R,capture_output=True,timeout=60).returncode == 0, 'Real-user authentication check failed; no credential output retained'")
s=s.replace(".read_text())", ".read_text(encoding='utf-8'))")
s=s.replace('same active MakeReady outcome and retired immutable owned-root branch identifier.', 'same active MakeReady content preparation outcome and retired immutable owned-root branch identifier; bounded publication-boundary external source/state drift acceptance, without activating or closing planned units.')
compile(s,'local-content-concurrency-01-branch.py','exec')
with (E/'local-content-concurrency-01-branch.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
