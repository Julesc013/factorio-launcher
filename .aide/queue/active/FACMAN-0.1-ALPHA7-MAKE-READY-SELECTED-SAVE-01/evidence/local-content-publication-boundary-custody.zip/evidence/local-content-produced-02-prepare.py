import hashlib
from pathlib import Path

E=Path(__file__).resolve().parent
new=(E/'local-content-produced-01.py').read_text(encoding='utf-8')
new=new.replace("S=W/'instance-configuration-produced-01/local-content-produced-01'", "S=W/'local-content-produced-02/scenario'")
new=new.replace("CLI=W/'instance-configuration-produced-01/facman/", "CLI=W/'local-content-produced-02/facman/")
new=new.replace('local-content-produced-01.json','local-content-produced-02.json')
new=new.replace('local-content-produced-01.claim.json','local-content-produced-02.claim.json')
new=new.replace("'producer_source':'bb0bc47618b6e10347d6a4e91d36911147c3f5d1','consumer_source':'1d5391cb7bf4dcf506eca5819d966a2f025a3717'", "'producer_source':'7671fe3f63c269fde9956356a9d174cc143421a9','consumer_source':'7671fe3f63c269fde9956356a9d174cc143421a9'")
new=new.replace("'b39d0495638f7f4a1d11d3ca023f8ce07a4452dee0bd08b10c166d020a3a93d6'", "'a1a85f77bbbdbd7d1f1b65be2c053e7e42b1b68eb5cec2a37d5c767d63aee3f1'")
new=new.replace("E/'local-content-doctor-preflight.log'", "E/'local-content-produced-admission-02-resource.log'")
new=new.replace("E/'instance-configuration-produced-admission-01.json'", "E/'local-content-produced-admission-completion-02.json'")
new=new.replace("read_text())", "read_text(encoding='utf-8'))")
new=new.replace("rec['CLI_sha256']=sha(CLI);", "assert sha(E/'local-content-produced-admission-completion-02.json')=='5fdd16b76465f1cfc8d2d0071aa9f94921737ee54ebfd39f847e4e6f01995803'\n    rec['DLL_sha256']=sha(CLI.parent/'flb_factorio.dll');assert rec['DLL_sha256']=='606c93aeffec6c8f6cdf287a201aa7923c1c0cc7e1d2fe90dddaa4f0170bb1da'\n    rec['CLI_sha256']=sha(CLI);")
new=new.replace("assert any(not x['valid'] for x in malformed['records'] if not x['virtual_package'])", "assert any(x['validation_status']!='valid' and x['refusal'] is not None for x in malformed['records'] if not x['virtual_package'])")
new=new.replace("applied['plan_id']", "applied['transaction_id']")
new=new.replace("retry['plan_id']", "retry['transaction_id']")
new=new.replace("v['plan_id']", "v['transaction_id']")
new=new.replace("mod(ws,'addon','1.0.0',['base >= 2.0'])", "mod(ws,'addon','1.0.0',['base >= 2.0']);shutil.copyfile(R/'tests/fixtures/factorio_mods/malformed_info_json/malformed_info_1.0.0.zip',mods/'malformed_info_1.0.0.zip')")
new=new.replace("['modsets','plan','solver',*a],['modsets','explain','solver',*a]", "['modsets','plan','solver',*a],['modsets','diff','solver',*a],['modsets','explain','solver',*a]")
new=new.replace("run('human-'+command[0]+'-'+command[1],ws,command,human=True)", "text=run('human-'+command[0]+'-'+command[1],ws,command,human=True);assert 'application' in text and 'library' in text,(command,text)")
# Capture history/journal/stage contents before retry; require bytes remain after
# successful retry, verify and rollback. The retry's own transaction is distinct.
new=new.replace("retry=run(label+'-retry',fw,['modsets','apply','solver','--enable','simple']);run(label+'-cleanup-rollback'", "retained={str(p.relative_to(fw)):sha(p) for p in fw.rglob('*') if p.is_file() and ('.facman-modset-' in str(p) or p.is_relative_to(fw/'.facman/journal'))};assert retained\n            retry=run(label+'-retry',fw,['modsets','apply','solver','--enable','simple']);assert retry['transaction_id']!=retry['plan_id'];run(label+'-verify',fw,['modsets','verify','solver']);run(label+'-cleanup-rollback'")
new=new.replace("assert state(fw)==before\n        else:", "assert state(fw)==before;assert all((fw/p).is_file() and sha(fw/p)==digest for p,digest in retained.items())\n        else:")
new=new.replace("for label,fault in [('apply-fault','after_first_commit'),('rollback-fault','rollback_after_first_restore')]", "for label,fault in [('apply-fault','after_first_commit'),('apply-backup-fault','after_backup'),('rollback-fault','rollback_after_first_restore')]")
new=new.replace("if label=='apply-fault':", "if label.startswith('apply-'):")
new=new.replace("rec['archives']=archives;rec['status']='PASS'", "assert admission['delivery_files_before']==tree(CLI.parent.parent)\n    rec['verified_delivery_files_unchanged']=len(admission['delivery_files_before']);rec['new_roots']=rec['builds']=rec['candidate_dispatches']=rec['CI_reruns']=rec['model_wait_calls']=0\n    rec['archives']=archives;rec['status']='PASS_SCOPED_CURRENT_PRODUCED_WINDOWS_LOCAL_CONTENT'")
compile(new,'local-content-produced-02.py','exec')
dest=E/'local-content-produced-02.py'
with dest.open('x',encoding='utf-8',newline='\n') as f:f.write(new)
print('Prepared produced package scenario '+hashlib.sha256(dest.read_bytes()).hexdigest())
