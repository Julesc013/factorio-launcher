"""Complete retained admission after correcting only documented path projection."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

R=Path(r'D:\Projects\Factorio\factorio-launcher')
E=Path(__file__).resolve().parent
W=E.parent
DEST=W/'local-content-produced-02'
HEAD='7671fe3f63c269fde9956356a9d174cc143421a9'
OUT=E/'local-content-produced-admission-completion-02.json'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(v,indent=2)+'\n')
assert not OUT.exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==HEAD
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()
failed=E/'local-content-produced-admission-02.json'
d=json.loads(failed.read_text(encoding='utf-8'))
assert d['status']=='ACTIONABLE_FAILURE' and d['error']=='AssertionError()' and d['source']==HEAD
assert all(c['exit_code'] in {0,1} if c['name']=='resource' else c['exit_code']==0 for c in d['checks'])
outer=E/'local-content-current-Windows-self-setup-02.zip'
assert sha(outer)==d['artifact']['digest'].split(':')[1]=='8ddec3deea42e9b99b23c4407073ea88dca30226f44891d6e842f4135bf7169d'
package_path=DEST/'package-record.v1.json'
package=json.loads(package_path.read_text(encoding='utf-8'))
assert package['facman_source_revision']==HEAD and not package['source_dirty']
with zipfile.ZipFile(outer) as z:
    records=[n for n in z.namelist() if n.endswith('self-setup-package.v1.json')]
    assert len(records)==1 and z.read(records[0])==package_path.read_bytes()
payload=DEST/package['payload']['filename']
assert sha(payload)==package['payload']['sha256'] and payload.stat().st_size==package['payload']['size_bytes']
root=DEST/'facman/generations'/package['version']
actual={p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file()}
with zipfile.ZipFile(payload) as z:
    files=[i for i in z.infolist() if not i.is_dir()]
    assert len(files)==package['payload']['file_count'] and z.testzip() is None
    lines=bytearray()
    for i in sorted(files,key=lambda v:v.filename.encode('utf-8')):
        data=z.read(i)
        lines.extend(i.filename.encode('utf-8')+b'\0'+str(len(data)).encode()+b'\0'+hashlib.sha256(data).hexdigest().encode()+b'\n')
    assert hashlib.sha256(lines).hexdigest()==package['payload']['tree_digest']
    generation='facman/generations/'+package['version']+'/'
    expected={i.filename[len(generation):]:hashlib.sha256(z.read(i)).hexdigest() for i in files if i.filename.startswith(generation)}
    assert actual==expected
composition_zip=E/'local-content-current-Windows-composition-02.zip'
assert sha(composition_zip)=='332fc8fccbd4591dfb16bfd30356bf0d2882456a9c9013eaa6d097c9c957e317'
with zipfile.ZipFile(composition_zip) as z:
    assert len(z.namelist())==1 and z.testzip() is None
    composition=json.loads(z.read(z.namelist()[0]))
assert composition['status']=='pass' and composition['source_revisions']['factorio_launcher']==HEAD and not any(composition['authority'].values())
for key,path in {'workspace_lock':'release/index/workspace_lock.v1.toml','provider_lock':'release/index/providers.lock.v2.toml','route_v1':'release/index/successor_play_route.v1.toml'}.items():
    assert composition['governing_digests'][key]==sha(R/path)
assert set(actual)-set(composition['packages']['windows_legacy_winforms_x64']['inventory'])=={'FacMan.exe'}
assert set(composition['packages']['windows_legacy_winforms_x64']['inventory'])-set(actual)=={'bin/FacMan.WinForms.exe'}
projected=dict(actual); projected['bin/FacMan.WinForms.exe']=projected.pop('FacMan.exe')
closure=composition['packages']['windows_legacy_winforms_x64']
assert closure['file_count']==len(projected)==len(actual)==587 and closure['hash_manifest']=='pass'
assert closure['tree_sha256']==hashlib.sha256(json.dumps(projected,separators=(',',':'),sort_keys=True).encode('utf-8')).hexdigest()
build=json.loads((root/'manifest/build_info.v1.json').read_text(encoding='utf-8'))
assert build['source_commit']==HEAD and not build['source_dirty'] and build['profile_id']=='windows_legacy_winforms_x64'
assert closure['build_identity_sha256']==hashlib.sha256(str(build['build_identity']).encode('utf-8')).hexdigest()
write(OUT,dict(status='ADMITTED_EXISTING_PRODUCED_WINDOWS_DELIVERY',source=HEAD,failed_receipt_sha256=sha(failed),correction='Self-setup relocates exactly bin/FacMan.WinForms.exe to FacMan.exe without changing bytes; exact inverse path projection matches original CI composition tree.',executable=str(root/'bin/facman.exe'),executable_sha256=sha(root/'bin/facman.exe'),binding_DLL_sha256=sha(root/'bin/flb_factorio.dll'),artifact=d['artifact'],package_record=package,payload_sha256=sha(payload),composition_zip_sha256=sha(composition_zip),composition=composition,delivery_files_before=actual,verified_delivery_files=587,new_roots=0,additional_downloads=0,additional_extractions=0,builds=0,candidate_dispatches=0,CI_reruns=0,model_wait_calls=0,whole_workunit_closed=False,finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
print(json.dumps(dict(status='ADMITTED_EXISTING_PRODUCED_WINDOWS_DELIVERY',source=HEAD,CLI_sha256=sha(root/'bin/facman.exe'),DLL_sha256=sha(root/'bin/flb_factorio.dll'),files=587,receipt_sha256=sha(OUT))))
