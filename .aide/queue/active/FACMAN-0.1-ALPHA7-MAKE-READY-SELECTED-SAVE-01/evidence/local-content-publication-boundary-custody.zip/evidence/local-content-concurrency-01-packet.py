import copy
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time
import tomllib
import zipfile

R=Path(r'D:\Projects\Factorio\factorio-launcher')
E=Path(__file__).resolve().parent
W=E.parent
UNIT='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
BASE='7671fe3f63c269fde9956356a9d174cc143421a9'
D=R/'.aide/queue/active'/UNIT/'evidence'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(v,indent=2)+'\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==BASE
review_path=E/'local-content-concurrency-review-03.json'
deadline=time.monotonic()+300
while not review_path.exists() and time.monotonic()<deadline:time.sleep(1)
assert review_path.exists(),'Final scoped source/runtime review pending; packet not generated'
review=read(review_path)
assert review.get('verdict',review.get('status'))=='PASS'
sources=['runtime/factorio/modsets/flb_factorio_modset_solver.cpp','tests/test_local_modset_solver.py','docs/product/local_modset_solver.md']
reviewed=review.get('reviewed_sha256',review.get('source_sha256',{}))
assert set(sources)<=set(reviewed),review.keys()
for p in sources:assert sha(R/p)==reviewed[p]
build_path=E/'local-content-concurrency-03-fixed-build.json'
tests_path=E/'local-content-concurrency-04-fixed-solver.json'
assert read(build_path)['status']==read(tests_path)['status']=='PASS'
for p in (build_path,tests_path):
    for c in read(p)['commands']:assert c['exit_code']==0 and sha(Path(c['log']))==c['sha256']
log_path=Path(read(tests_path)['commands'][0]['log'])
log=log_path.read_text(encoding='utf-8')
passed=re.findall(r'^test_\S+ \(([^)]+)\) \.\.\. ok$',log,re.M)
skipped=re.findall(r'^\s+test_\S+ \(([^)]+)\) \(([^)]+)\) \.\.\. skipped ([^\r\n]+)$',log,re.M)
assert len(passed)==16 and len(skipped)==2 and 'Ran 17 tests' in log and 'OK (skipped=2)' in log
produced_path=E/'local-content-produced-02.json'
produced=read(produced_path)
produced_review=E/'local-content-produced-review-02.json'
assert sha(produced_review)=='c506eda8bf9e392c89e3215f02b73060ad1e607577c7d5eeb867cbb980e45385'
assert produced['status']=='PASS_SCOPED_CURRENT_PRODUCED_WINDOWS_LOCAL_CONTENT' and produced['producer_source']==produced['consumer_source']==BASE
assert len(produced['commands'])==41 and len(produced['cells'])==9 and all(c['result']=='PASS' for c in produced['cells'])
for c in produced['commands']:
    assert sha(Path(c['stdout']))==c['stdout_sha256'] and sha(Path(c['stderr']))==c['stderr_sha256']
members={}
def admit(p,member):
    assert p.is_file() and not p.is_symlink() and not(getattr(p.stat(),'st_file_attributes',0)&0x400)
    assert p.suffix.lower() not in {'.exe','.dll','.pdb'} and member not in members
    members[member]=p
for pattern in ['local-content-concurrency*.json','local-content-concurrency*.log','local-content-concurrency*.py','local-content-produced-02*','local-content-produced-review-02.json','local-content-produced-admission-02*','local-content-produced-admission-completion-02*','local-content-current-artifacts-02.json']:
    for p in sorted(E.glob(pattern)):
        if p.is_file() and p.suffix.lower() in {'.json','.log','.py'} and p not in members.values():admit(p,'evidence/'+p.name)
scenario=W/'local-content-produced-02/scenario'
for p in sorted(scenario.rglob('*')):
    if p.is_file():admit(p,'produced-base/'+p.relative_to(scenario).as_posix())
archive=D/'local-content-publication-boundary-custody.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,p in sorted(members.items()):z.write(p,name)
plan_path=R/'release/index/plan.v1.toml'
text=plan_path.read_text(encoding='utf-8')
before=tomllib.loads(text)
unit=next(x for x in before['workunit'] if x['id']==UNIT)
assert unit['status']=='active' and len(unit['acceptance'])==2 and len(unit['close_after'])==5
public=D/'local-content-publication-boundary.v1.json'
ref=public.relative_to(R).as_posix()
assert ref not in unit['evidence']
receipt=dict(status='PASS_SCOPED_WINDOWS_PUBLICATION_BOUNDARY_SOURCE_FIXTURE',work_item=UNIT,base=BASE,
    behavior=['Revalidate selected physical archives and exact managed-state presence/bytes immediately before publication','Preserve unknown, changed or unsafe staged/history bytes and require recovery before effects','Retain original fault detail through verified restoration'],
    source_hashes={p:sha(R/p) for p in sources},native_CLI_sha256=sha(W/'native-developer/Debug/facman.exe'),
    source_review=dict(path='evidence/'+review_path.name,sha256=sha(review_path),status='PASS'),
    verification=dict(native_build=dict(path='evidence/'+build_path.name,sha256=sha(build_path)),solver=dict(path='evidence/'+tests_path.name,sha256=sha(tests_path),reported_methods=17,passing_applicable_methods=16,passed_ids=passed,not_applicable_subcases=skipped,log_sha256=sha(log_path)),baseline=dict(tests=2,failures=2,custody_sha256=sha(E/'local-content-concurrency-01-hook-baseline-custody.json'))),
    produced_base_proof=dict(status=produced['status'],producer_source=BASE,consumer_source=BASE,commands=41,cells=9,CLI_sha256=produced['CLI_sha256'],DLL_sha256=produced['DLL_sha256'],receipt_sha256=sha(produced_path),review_sha256=sha(produced_review),delivery_files_unchanged=587,scope='Selected-package verification, restored apply retry and rollback, human reports; this predates the new publication-boundary guard',diagnostic_gap='Prior produced first-commit fault loses detail; corrected new source is native-fixture qualified'),
    custody=dict(path=archive.relative_to(R).as_posix(),sha256=sha(archive),members=len(members),files={n:sha(p) for n,p in sorted(members.items())},executables_included=False,licensed_game_inputs_included=False),
    original_acceptance=unit['acceptance'],close_after=unit['close_after'],whole_workunit_closed=False,
    qualification=dict(new_guard_current_produced_package=False,virtual_metadata_drift=False,total_unmanaged_writer_serialization=False,genuine_game=False,human_experience=False,Beta=False),
    retained_failures=['Two instrumented late-drift baseline failures','Initial unsafe cleanup/staging source draft independently rejected','Name-only build guard stopped before build; unrelated idle orphan node preserved','Typed InstallId comparison compilation failure','Invalid altered ZIP retry test-oracle failure','Base package path-projection admission assertion retained; exact existing-byte completion verified'],
    remaining=['Current produced-package proof of publication guard and restored fault diagnostics','Solver-selection export/offline reconstruction and content frontend acceptance','Original federated Make Ready clauses and three unfinished close-after gates'],
    external_gates_preserved=['PR343 owner-only protected-control gate','Source-distinct A5-to-A6 produced update/rollback','Applicable game/human/host qualification'],resource_use=dict(new_roots=0,new_worktrees=0,workers=2,heavy_local_jobs=1,build_peak_bytes=1024**3,reserve_bytes=8*1024**3),finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
write(public,receipt)
start=text.index('id = "'+UNIT+'"'); end=text.find('\n[[workunit]]',start)
if end<0:end=len(text)
section=text[start:end]
last='  "'+unit['evidence'][-1]+'",'
assert section.count(last)==1
section=section.replace(last,last+'\n  "'+ref+'",',1)
updated=text[:start]+section+text[end:]
expected=copy.deepcopy(before)
next(x for x in expected['workunit'] if x['id']==UNIT)['evidence'].append(ref)
assert tomllib.loads(updated)==expected
plan_path.write_text(updated,encoding='utf-8',newline='\n')
write(E/'local-content-concurrency-01-packet.json',dict(status=receipt['status'],public_receipt=ref,public_receipt_sha256=sha(public),custody_sha256=sha(archive),custody_members=len(members),canonical_change='Exactly one evidence append; original status/acceptance/five gates preserved',whole_workunit_closed=False))
print(json.dumps(dict(status=receipt['status'],source_methods_passed=16,not_applicable_subcases=2,base_produced_commands=41,custody_members=len(members),public_receipt_sha256=sha(public),custody_sha256=sha(archive))))
