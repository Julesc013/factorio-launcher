"""Validate the completed real GUI run's existing custody; never relaunch it.

The original driver tests and validates all custody before summarizing owner
commands. Its receipt summary used command_id instead of the actual owner_command
field. Correct only that external extractor; preserve the actual run and log.
"""
import base64
import hashlib
import json
from pathlib import Path
import zlib

R = Path(r'D:\Projects\Factorio\factorio-launcher')
W = Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e')
consumer = W / 't/j3/cpass05'
log_path = W / 'evidence/windows-delivered-gui-pass-regression-01.log'
driver = W / 'evidence/windows-delivered-gui-pass-regression-01.py'
validation = driver.read_text().split('lines = log_path.read_text().splitlines()', 1)[1]
validation = 'lines = log_path.read_text().splitlines()' + validation
validation = validation.replace("item['command_id']", "item['owner_command']")
validation = validation.replace('windows-delivered-gui-pass-regression-result-01.json',
    'windows-delivered-gui-diagnostic-pass-regression-result-01.json')
exec(compile(validation, str(driver) + ':custody-validator', 'exec'))
