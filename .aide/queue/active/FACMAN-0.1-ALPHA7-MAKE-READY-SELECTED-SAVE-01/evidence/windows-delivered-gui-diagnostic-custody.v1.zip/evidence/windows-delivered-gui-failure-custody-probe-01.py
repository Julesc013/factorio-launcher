import base64
from contextlib import redirect_stdout
import hashlib
import json
import os
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
import zlib

R = Path(r'D:\Projects\Factorio\factorio-launcher')
W = Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e')
G = W / 't/j3/g'
consumer = W / 't/j3/cfail03'
consumer.mkdir(exist_ok=False)
sys.path[:0] = [str(R / 'tests'), str(R)]
import test_windows_delivered_joined_gui as tested

original = tested.OwnedControls.inputs
def controlled_timeout(self, main):
    dialog = original(self, main)
    try:
        self.wait(lambda: None, 'controlled failure-custody timeout', seconds=.15)
    finally:
        self.click(self.control(dialog, 'Cancel'))
        self.wait(lambda: dialog not in self.enumerate(), 'controlled probe cancellation')

log_path = W / 'evidence/windows-delivered-gui-failure-custody-probe-01.log'
assert not log_path.exists()
test_result = unittest.TestResult()
with log_path.open('w', encoding='utf-8') as stream, redirect_stdout(stream), \
     patch.dict(os.environ, FACMAN_DELIVERED_GUI_PACKAGE=str(G),
         FACMAN_DELIVERED_GUI_CONSUMER=str(consumer)), \
     patch.object(tested.OwnedControls, 'inputs', controlled_timeout):
    tested.WindowsDeliveredJoinedGuiTests(
        'test_actual_joined_controls_dispatch_production_packaged_backend').run(test_result)

assert test_result.testsRun == 1 and len(test_result.failures) == 1 and not test_result.errors
assert 'controlled failure-custody timeout' in test_result.failures[0][1]
lines = log_path.read_text().splitlines()
prefix = 'delivered-windows-gui-custody '
custody_lines = [line for line in lines if line.startswith(prefix)]
assert len(custody_lines) == 1
custody = json.loads(custody_lines[0][len(prefix):])
compressed = base64.b64decode(custody['payload_base64'], validate=True)
assert hashlib.sha256(compressed).hexdigest() == custody['compressed_sha256']
canonical = zlib.decompress(compressed)
assert hashlib.sha256(canonical).hexdigest() == custody['canonical_sha256']
manifest = json.loads(canonical)
assert len(manifest) == custody['file_count']
raw = {}
for name, item in manifest.items():
    data = base64.b64decode(item['bytes_base64'], validate=True)
    assert len(data) == item['size_bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
    assert data == (consumer / 'evidence' / name).read_bytes()
    raw[name] = data
record = json.loads(raw['result.json'])
assert record['result'] == 'FAIL' and 'controlled failure-custody timeout' in record['exception']
assert 'cleanup_exception' not in record
session, = record['sessions']
assert session['terminal']['exit_code'] == 0 and not session['terminal']['safety_termination']
assert session['terminal']['owned_job_active_processes'] == 0
assert session['launch']['exact_job_membership_before_resume']
assert session['observed_backend_processes']
assert any(event['stage'] == 'timeout: controlled failure-custody timeout' for event in session['events'])
for snapshot in record['snapshots']:
    for name, item in snapshot['inventory'].items():
        assert raw['objects/' + item['sha256']]
prefix = 'delivered-windows-gui-result '
summary, = [json.loads(line[len(prefix):]) for line in lines if line.startswith(prefix)]
assert summary['result'] == 'FAIL'
assert summary['result_sha256'] == hashlib.sha256(raw['result.json']).hexdigest()
receipt = dict(schema='facman.windows_delivered_fail_custody_probe.v1', result='PASS_EXPECTED_FAILURE_CUSTODY',
    qualification='reused-source regression; controlled diagnostic failure, not GUI acceptance PASS',
    source_sha256=hashlib.sha256((R / 'tests/test_windows_delivered_joined_gui.py').read_bytes()).hexdigest(),
    consumer=str(consumer), log=str(log_path), log_sha256=hashlib.sha256(log_path.read_bytes()).hexdigest(),
    result_sha256=summary['result_sha256'], custody_sha256=custody['canonical_sha256'],
    file_count=len(raw), log_bytes=log_path.stat().st_size, gui_pid=session['terminal']['pid'],
    observed_processes=len(session['observed_backend_processes']),
    exit_code=session['terminal']['exit_code'], owned_job_active_processes=0,
    expected_failure=test_result.failures[0][1])
receipt_path = W / 'evidence/windows-delivered-gui-failure-custody-probe-result-01.json'
assert not receipt_path.exists()
receipt_path.write_text(json.dumps(receipt, indent=2))
print(json.dumps({k: v for k, v in receipt.items() if k != 'expected_failure'}, indent=2))
