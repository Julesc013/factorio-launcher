import base64, hashlib, json, re, runpy, subprocess, zlib
from pathlib import Path

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
packet_path = E / 'windows-delivered-gui-failure-author-packet-01.json'
packet = json.loads(packet_path.read_bytes())
out = E / 'windows-delivered-gui-diagnostic-independent-review-01.json'
assert not out.exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == '68ab566523386f87153acc92557d08055e43c921'
for row in packet['author_files']:
    assert sha((R / row['path']).read_bytes()) == row['sha256']
probe = json.loads((E / 'windows-delivered-gui-failure-custody-probe-result-02.json').read_bytes())
assert probe['source_sha256'] == sha((R / 'tests/test_windows_delivered_joined_gui.py').read_bytes())
log = Path(probe['log'])
assert sha(log.read_bytes()) == probe['log_sha256']
lines = log.read_text(encoding='utf-8').splitlines()
custody, = [json.loads(line.split(' ', 1)[1]) for line in lines if line.startswith('delivered-windows-gui-custody ')]
compact, = [json.loads(line.split(' ', 1)[1]) for line in lines if line.startswith('delivered-windows-gui-result ')]
assert len(custody['payload_base64']) < 512 * 1024
compressed = base64.b64decode(custody['payload_base64'], validate=True)
assert sha(compressed) == custody['compressed_sha256']
decoder = zlib.decompressobj()
canonical = decoder.decompress(compressed, 12 * 1024 ** 2 + 1)
assert decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail and len(canonical) < 12 * 1024 ** 2
assert sha(canonical) == custody['canonical_sha256'] == compact['custody_sha256']
manifest = json.loads(canonical)
assert len(manifest) == custody['file_count']
files = {}
for name, item in manifest.items():
    assert name == 'result.json' or re.fullmatch(r'objects/[0-9a-f]{64}', name)
    data = base64.b64decode(item['bytes_base64'], validate=True)
    assert len(data) == item['size_bytes'] and sha(data) == item['sha256']
    assert data == (Path(probe['consumer']) / 'evidence' / name).read_bytes()
    if name.startswith('objects/'):
        assert name == 'objects/' + sha(data)
    files[name] = data
record = json.loads(files['result.json'])
assert sha(files['result.json']) == compact['result_sha256'] == probe['result_sha256']
assert record['result'] == compact['result'] == 'FAIL'
assert 'controlled failure-custody timeout' in record['exception'] and 'cleanup_exception' not in record
for snapshot in record['snapshots']:
    for item in snapshot['inventory'].values():
        assert len(files['objects/' + item['sha256']]) == item['size_bytes']
session, = record['sessions']
terminal = session['terminal']
assert terminal['exit_code'] == 0 and not terminal['safety_termination'] and terminal['owned_job_active_processes'] == 0
assert session['launch']['exact_job_membership_before_resume']
assert session['observed_backend_processes'] == terminal['backend_processes']
clicked = [event for event in session['events'] if event['stage'] == 'BM_CLICK']
assert clicked and all(event['post_succeeded'] and event['posted_at'] >= event['observed_at'] for event in clicked)
assert all(event['pid'] == terminal['pid'] for event in session['events'])
assert any(event['stage'] == 'timeout: last click target' for event in session['events'])
positive = json.loads((E / 'windows-delivered-gui-diagnostic-pass-regression-result-01.json').read_bytes())
assert positive['source_sha256'] == probe['source_sha256']
positive_log = Path(positive['log'])
assert sha(positive_log.read_bytes()) == positive['log_sha256']
accepted = runpy.run_path(str(E / 'windows-delivered-joined-log-custody-01.py'))['extract'](
    positive_log, '002824ea9f2ac4d3844ec5141b455d5733a8008b',
    E / 'windows-delivered-gui-diagnostic-independent-pass-01',
    'original portable file closure reconstructed from produced self-setup payload')
assert accepted['actual_GUI_sessions'] == 2 and accepted['complete_owner_effects'] == 2
review = dict(schema='facman.windows_delivered_gui_diagnostic_independent_review.v1',
    verdict='PASS_DIAGNOSTIC_CORRECTION_FOR_REQUIRED_CURRENT_CI', non_authoring=True,
    author='/root/windows_delivered_gui_failure_implementation', reviewer='/root',
    author_packet_sha256=sha(packet_path.read_bytes()), authored_files_sha256={row['path']: row['sha256'] for row in packet['author_files']},
    truthful_failure_custody=True, failure_objects=len(files)-1, normal_failure_probe_exit=True,
    unchanged_pass_oracle=accepted, CI_cause_resolved=False,
    original_CI_failure_preserved=True, no_timeout_increase=True, no_dispatch_retry=True,
    no_focus_or_foreign_process_manipulation=True, no_runtime_or_provider_change=True,
    reused_source_regression=True, current_head_factory_proof_pending=True,
    full_environment_acceptance_repeated=False, beta=False, rc=False,
    review='Only owned-state diagnostics and truthful bounded FAIL custody change. Partial frames survive normal disposal; queued controls, first-dialog timeout, final receipt/effects, exact snapshots and owned process lifetime retain their existing success requirements. A real injected timeout remains a failing unittest and exports hash-closed original exception and normal cleanup evidence. Original two-session GUI oracle independently passes on reused compiled source. The actual hosted first-dialog cause remains unresolved; new required campaign is necessary to retain hosted failure diagnostics or qualify exact new source, without a speculative product correction.')
out.write_text(json.dumps(review, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in review.items() if key in ('verdict', 'non_authoring', 'truthful_failure_custody', 'failure_objects', 'CI_cause_resolved', 'current_head_factory_proof_pending')}))
