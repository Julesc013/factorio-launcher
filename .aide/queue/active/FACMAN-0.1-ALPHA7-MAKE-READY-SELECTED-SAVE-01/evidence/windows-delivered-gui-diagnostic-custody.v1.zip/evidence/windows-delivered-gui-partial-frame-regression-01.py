import ast
import hashlib
import json
from pathlib import Path
import sys
from types import SimpleNamespace

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e\evidence')
sys.path[:0] = [str(R / 'tests'), str(R)]
import test_windows_delivered_joined_gui as tested

source = R / 'tests/test_windows_delivered_joined_gui.py'
ast.parse(source.read_text())
owned = tested.OwnedControls.__new__(tested.OwnedControls)
owned.process = SimpleNamespace(pid=12, poll=lambda: None)
owned.events = []
owned.deadline = float('inf')
owned.enumerate = lambda parent=None, observe=True: [1, 2] if parent else [10]
def text(hwnd, class_name=False):
    if hwnd == 2:
        raise tested.ControlGone('controlled normal child disposal')
    return 'class' if class_name else 'owned-control'
owned.text = text
owned.control_state = lambda hwnd: dict(enabled=True, visible=True)
frame = owned.frame(10, 'controlled diagnostic child disposal')
assert frame['controls'][0]['hwnd'] == 1 and frame['controls'][0]['text'] == 'owned-control'
assert frame['controls'][1] == dict(hwnd=2, control_gone=True)
def gone_root(parent=None, observe=True):
    if parent:
        raise tested.ControlGone('controlled normal root disposal')
    return [10]
owned.enumerate = gone_root
frame = owned.frame(10, 'controlled diagnostic root disposal')
assert frame['title'] == 'owned-control' and frame['control_gone'] and frame['controls'] == []
owned.events.append(dict(stage='BM_CLICK', pid=12, hwnd=2))
def gone_target(hwnd):
    raise tested.ControlGone('controlled disposed prior click')
owned.control_state = gone_target
try:
    owned.wait(lambda: None, 'original timeout survives disposal', seconds=0)
except AssertionError as failure:
    assert str(failure) == 'Owned GUI did not reach original timeout survives disposal'
else:
    raise AssertionError('Timeout was lost')
assert owned.events[-1]['stage'] == 'timeout: last click target' and owned.events[-1]['control_gone']
result = dict(schema='facman.windows_delivered_diagnostic_regressions.v1', result='PASS',
    qualification='synthetic diagnostic disposal regressions; no product acceptance claim',
    source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    checks=['Python AST', 'child disposal keeps surviving controls',
        'root disposal keeps partial frame', 'disposed click retains original timeout'])
path = E / 'windows-delivered-gui-partial-frame-regression-result-01.json'
assert not path.exists()
path.write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
