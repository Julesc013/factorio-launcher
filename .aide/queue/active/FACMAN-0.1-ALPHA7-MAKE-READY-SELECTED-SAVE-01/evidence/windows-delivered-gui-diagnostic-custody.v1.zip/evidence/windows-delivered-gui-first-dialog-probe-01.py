import ctypes
from ctypes import wintypes as wt
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time
import traceback
from unittest.mock import patch

R = Path(r'D:\Projects\Factorio\factorio-launcher')
W = Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e')
G = Path(r'D:\Projects\Factorio\TASK-B~1\REPOSI~1\FACTOR~1\tasks\TASK-F~2\t\j3\g')
sys.path[:0] = [str(R / 'tests'), str(R)]
import test_windows_delivered_joined_gui as tested

consumer = W / 't/j3/cfail01'
consumer.mkdir(exist_ok=False)
fixture = consumer / 'fixture-install-source'
shutil.copytree(tested.modsets.FIXTURE_INSTALL, fixture)
workspace = consumer / 'workspace'
environment = {k: v for k, v in os.environ.items() if not k.startswith('FACMAN_')}
environment['PATH'] = ''
environment['PYTHONDONTWRITEBYTECODE'] = '1'
result = dict(schema='facman.windows_delivered_first_dialog_probe.v1',
    qualification='reused-source regression, not fresh-head package',
    compiled_source='002824ea9f2ac4d3844ec5141b455d5733a8008b',
    tested_source_sha256=hashlib.sha256((R / 'tests/test_windows_delivered_joined_gui.py').read_bytes()).hexdigest(),
    consumer=str(consumer), gui_sha256=hashlib.sha256((G / 'bin/FacMan.WinForms.exe').read_bytes()).hexdigest(),
    backend_sha256=hashlib.sha256((G / 'bin/facman.exe').read_bytes()).hexdigest())
started = time.monotonic()
active = None
try:
    case = tested.WindowsDeliveredJoinedGuiTests()
    with patch.dict(os.environ, FACMAN_CLI_EXE=str(G / 'bin/facman.exe')), \
         patch.object(tested.native_cli, 'ROOT', consumer), \
         patch.object(tested.builtin, 'FIXTURE_INSTALL', fixture):
        tested.existing.ExistingConfigurationTests.prepare(case, workspace, 'load_save', raw=True, crlf=True)
    active = tested.OwnedControls(G / 'bin/FacMan.WinForms.exe', consumer, workspace, environment, started + 120)
    result['events'] = active.events
    api = active.api
    api.GetForegroundWindow.argtypes = []
    api.GetForegroundWindow.restype = wt.HWND
    api.ShowWindow.argtypes = [wt.HWND, ctypes.c_int]
    foreground = api.GetForegroundWindow()
    main = active.window('FacMan')
    active.selected_observation(main)
    result['main_state'] = active.control_state(main)
    active.frame(main, 'before first input click')
    dialog = active.inputs(main)
    result['original_hidden_first_dialog'] = 'OPENED'
    result['dialog_state'] = active.control_state(dialog)
    result['global_foreground_unchanged'] = foreground == api.GetForegroundWindow()
    active.click(active.control(dialog, 'Cancel'))
    active.wait(lambda: dialog not in active.enumerate(), 'probe input cancellation')
    result['result'] = 'PASS_ORIGINAL_HIDDEN_CONDITION'
except Exception:
    result['result'] = 'FAIL_ORIGINAL_HIDDEN_CONDITION'
    result['exception'] = traceback.format_exc()
finally:
    if active is not None:
        try:
            active.finish()
        except Exception:
            result['cleanup_exception'] = traceback.format_exc()
        result['terminal'] = active.terminal
        result['processes'] = active.job.records
        result['launch'] = active.job.launch
    result['elapsed_seconds'] = time.monotonic() - started
    path = W / 'evidence/windows-delivered-gui-first-dialog-probe-result-01.json'
    assert not path.exists()
    path.write_text(json.dumps(result, indent=2))
    print(json.dumps({k: v for k, v in result.items() if k not in ('events', 'processes', 'terminal')}, indent=2))
    if active is not None:
        print(json.dumps(dict(gui_pid=active.process.pid, backend_process_count=len(active.job.records),
            terminal_exit=active.terminal['exit_code'] if active.terminal else None)))
