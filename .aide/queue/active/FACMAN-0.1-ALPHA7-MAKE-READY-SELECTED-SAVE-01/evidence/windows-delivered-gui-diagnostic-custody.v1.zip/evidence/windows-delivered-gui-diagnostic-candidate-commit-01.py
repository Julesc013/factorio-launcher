import hashlib, json, os, subprocess, sys, traceback, zipfile
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher'); E=Path(__file__).resolve().parent; W=E.parent
BASE='68ab566523386f87153acc92557d08055e43c921'; BRANCH='task/facman-linux-delivered-environment-01'
Q='.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01'
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds', TEMP=str(W/'t'), TMP=str(W/'t'), PYTHONDONTWRITEBYTECODE='1', GIT_CONFIG_COUNT='1', GIT_CONFIG_KEY_0='core.safecrlf', GIT_CONFIG_VALUE_0='false')
sys.path.insert(0,str(R)); from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True,encoding='utf-8').strip()
dirty=lambda:set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
out=E/'windows-delivered-gui-diagnostic-candidate-commit-result-01.json'; assert not out.exists()
record=dict(status='QUALIFYING_GUI_DIAGNOSTIC_CORRECTION',commands=[],new_roots=0,new_clones=0,new_worktrees=0,native_rebuild=False,goal_status_mutated=False)
def save():out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
def run(label,args,timeout=180,codes=(0,)):
 r=owned.command(args,cwd=R,environment=dict(os.environ),timeout=timeout,directory=E/('gui-diagnostic-commit01-'+label),output_limit=8*1024**2,wait_for_job_empty_after_primary=True)
 record['commands'].append(dict(label=label,exit=r.returncode,receipt_sha256=sha(r.directory/'receipt.json')));save()
 assert r.returncode in codes and r.receipt['termination']=='completed' and r.receipt['primary_stopped'] and r.receipt['job_empty_observed'] and not r.receipt['job_terminated'],(label,(r.stdout[-1000:]+r.stderr[-1500:]).decode('utf-8','replace'))
 return r
try:
 assert git('rev-parse','HEAD')==BASE and git('branch','--show-current')==BRANCH and not git('diff','--cached','--name-only')
 packet=E/'windows-delivered-gui-failure-author-packet-01.json'; p=json.loads(packet.read_bytes())
 review=E/'windows-delivered-gui-diagnostic-independent-review-01.json'; v=json.loads(review.read_bytes())
 assert v['verdict']=='PASS_DIAGNOSTIC_CORRECTION_FOR_REQUIRED_CURRENT_CI' and v['non_authoring'] and v['author_packet_sha256']==sha(packet)
 expected={row['path'] for row in p['author_files']}; assert expected=={'tests/test_windows_delivered_joined_gui.py','docs/development/make-ready-preparation.md'} and dirty()==expected
 for row in p['author_files']:assert sha(R/row['path'])==row['sha256']
 for label in ('policy','detect','plan'):run(label,['py','-3','-B','.aide/scripts/aide_lite.py','git',label])
 run('paths',['py','-3','-B','tools/workspace_hygiene.py','paths'])
 h=json.loads(run('doctor',['py','-3','-B','tools/workspace_hygiene.py','doctor','--measure'],600,(0,1)).stdout)
 assert set(h['violations'])<={'unmanaged_secondary_worktrees_present'} and len(h['task_roots'])==8 and h['task_root_bytes']<20*1024**3
 names={row['path'] for row in p['evidence_files']}
 names.update({packet.name,review.name,'windows-delivered-gui-diagnostic-independent-review-01.py',Path(__file__).name,'linux-delivered-failed-windows-job-result-01.json','linux-delivered-acceptance-failed-windows-job-115705425989.log'})
 archive=R/Q/'evidence/windows-delivered-gui-diagnostic-custody.v1.zip'; assert not archive.exists()
 manifest={}
 for name in sorted(names):
  path=(E/name).resolve(); assert path.is_relative_to(E.resolve()) and path.is_file() and path.suffix.lower() not in ('.exe','.dll','.zip')
  manifest['evidence/'+path.relative_to(E).as_posix()]=sha(path)
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
  z.writestr('custody-manifest.json',json.dumps(manifest,indent=2,sort_keys=True)+'\n')
  for name in sorted(manifest):z.write(E/name.removeprefix('evidence/'),name)
 with zipfile.ZipFile(archive) as z:
  assert set(z.namelist())==set(manifest)|{'custody-manifest.json'}
  for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
 assert archive.stat().st_size<4*1024**2
 evidence=R/Q/'evidence/windows-delivered-gui-diagnostic.v1.json'; assert not evidence.exists()
 evidence.write_text(json.dumps(dict(schema='facman.windows_delivered_gui_diagnostic_correction.v1',base_head=BASE,failed_source=BASE,failed_run_id=38519408885,failed_job_id=115705425989,failed_log_sha256=sha(E/'linux-delivered-acceptance-failed-windows-job-115705425989.log'),actual_failure='first Make Ready input dialog did not appear within unchanged 35-second bound',actual_CI_cause_resolved=False,author_packet_sha256=sha(packet),independent_review_sha256=sha(review),authored_files_sha256=v['authored_files_sha256'],truthful_failure_custody=True,normal_disposal_partial_frames=True,unchanged_control_dispatch_and_deadlines=True,unchanged_success_oracle=True,reused_package_source='002824ea9f2ac4d3844ec5141b455d5733a8008b',reused_GUI_sessions=2,source_regression_only=True,current_head_factory_proof_pending=True,required_checks_pending=True,custody=archive.name,custody_sha256=sha(archive),custody_files=len(manifest),runtime_or_provider_change=False,new_roots=0,new_clones=0,new_worktrees=0,native_rebuild=False,beta=False,rc=False),indent=2)+'\n',encoding='utf-8')
 with (R/Q/'ExecPlan.md').open('a',encoding='utf-8',newline='\n') as stream:
  stream.write('\n### Hosted Windows GUI failure: retain diagnostic custody\n\nPR420 source68ab5665 failed its required Windows job115705425989 at the first Make Ready input dialog. The original35-second dialog bound remains unchanged. Original runner log is preserved; because the previous test exported custody only on PASS, it cannot establish the hosted cause. Focused actual GUI probes reach the first dialog under the original hidden-main and queued BM_CLICK conditions. The original two-session GUI oracle also passes on the retained produced002824 package; neither result proves a runtime correction or fresh-head package acceptance.\n\nThe bounded diagnostic correction records owned control IDs, parent/root handles, visibility/enabled state and queued click timing, retains partial frames through normal disposal, and exports hash-closed custody with the actual PASS or FAIL outcome. A real controlled timeout remains a failing unittest, preserves its original exception and exports24 verified files while normally draining the GUI/job. The unchanged PASS decoder independently verifies two real sessions, cancellation, stale refusal, joined owner receipts, exact inputs and normal process lifetime. No click retry, focus manipulation, timeout increase, runtime/provider edit or additional factory was introduced. Required exact-head hosted qualification remains pending; a repeated failure must be diagnosed from its retained evidence. Existing Linux and Windows/Mac reconstruction acceptance stays preserved.\n\nEvidence: evidence/windows-delivered-gui-diagnostic.v1.json and its hash-closed custody.\n')
 paths=expected|{Q+'/ExecPlan.md',Q+'/evidence/'+archive.name,Q+'/evidence/'+evidence.name}
 run('project-state',['py','-3','-B','tools/project_state.py','--write'],600)
 run('metadata',['py','-3','-B','tools/codegen/generate_metadata.py','--write'])
 changed=dirty();assert paths<=changed<=paths|{'.aide/memory/project-state.md','.aide/memory/project-state.v2.json','README.md'}
 for row in p['author_files']:assert sha(R/row['path'])==row['sha256']
 run('strict',['py','-3','-B','tools/strict_check.py'],1800)
 run('portable-aide',['py','-3','-B','.aide/scripts/aide_lite.py','test'],1800)
 message='fix(winforms): retain delivered GUI failure diagnostics\n\nPreserve owned control state and truthful failure custody without\nchanging the dialog deadline, queued dispatch or success requirements.\n\nWork-Item: FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01\nEvidence-Ref: '+Q+'/evidence/'+evidence.name+'\n'
 msg=E/'windows-delivered-gui-diagnostic-candidate-commit-message-01.txt';msg.write_text(message,encoding='utf-8',newline='\n')
 run('message',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--message',message])
 changes=[dict(path=name,state='content',sha256=sha(R/name),git_blob_oid=git('hash-object','--path',name,str(R/name)),ownership='task_owned') for name in sorted(changed)]
 snapshot=hashlib.sha256((json.dumps(changes,indent=2,sort_keys=True,separators=(',',': '))+'\n').encode()).hexdigest()
 commit_review=E/'windows-delivered-gui-diagnostic-candidate-commit-review-01.json'
 commit_review.write_text(json.dumps(dict(schema_version='aide.git-commit-review.v1',verdict='PASS',reviewer='/root',author='/root/windows_delivered_gui_failure_implementation',non_authoring=True,branch=BRANCH,base_commit=BASE,snapshot_sha256=snapshot,message_sha256=sha(msg),independent_source_review_sha256=sha(review),review=v['review']),indent=2)+'\n',encoding='utf-8')
 classification=E/'windows-delivered-gui-diagnostic-candidate-commit-classification-01.json'
 classification.write_text(json.dumps(dict(schema_version='aide.git-commit-classification.v1',branch=BRANCH,base_commit=BASE,work_item='FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01',snapshot_sha256=snapshot,message_sha256=sha(msg),changed_paths=changes,reviews=[dict(path=str(commit_review),sha256=sha(commit_review),verdict='PASS')]),indent=2)+'\n',encoding='utf-8')
 helper=['py','-3','-B','.aide/scripts/aide_lite.py','git','commit-plan','--classification',str(classification),'--message-file',str(msg)]
 run('plan-stage',helper);run('stage',['git','add','--',*sorted(changed)]);run('staged-diff',['git','diff','--cached','--check']);run('plan-commit',helper)
 assert git('rev-parse','HEAD')==BASE
 run('commit',['git','commit','-F',str(msg)])
 run('range',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--range',BASE+'..HEAD'])
 remaining=git('diff','--name-only').splitlines()
 if remaining:
  assert set(remaining)<={'.aide/memory/project-state.md','.aide/memory/project-state.v2.json','README.md'}
  for name in remaining:assert git('hash-object','--path',name,str(R/name))==git('rev-parse','HEAD:'+name)
  run('refresh-generated-index',['git','add','--',*remaining])
 assert not git('status','--porcelain') and not git('diff','--cached','--name-only')
 record.update(status='COMMITTED_REVIEWED_WINDOWS_GUI_DIAGNOSTIC_CANDIDATE',source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),review_sha256=sha(commit_review),evidence_sha256=sha(evidence),actual_CI_cause_resolved=False,current_head_factory_proof_pending=True,required_checks_pending=True,remote_not_pushed=True)
except BaseException as error:record.update(status='ACTIONABLE_GUI_DIAGNOSTIC_COMMIT_FAILURE',error=str(error),traceback=traceback.format_exc())
finally:save();print(json.dumps({k:v for k,v in record.items() if k not in ('commands','traceback')},indent=2))
raise SystemExit(0 if record['status']=='COMMITTED_REVIEWED_WINDOWS_GUI_DIAGNOSTIC_CANDIDATE' else 1)
