import copy, hashlib, io, json, os, pathlib, re, subprocess, sys, time, zipfile
ROOT = pathlib.Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\worktrees\task-facman-lab-input-registry-01')
E = pathlib.Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-46230f3671\evidence')
PY = pathlib.Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\beta1-admissi-68051e628e\python\Scripts\python.exe')
sys.path.insert(0,str(ROOT))
from tools import workspace_migration_closeout_check as gate, release_programme_check as programme, foundation_beta_readiness_check as readiness
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((E/'completion-gate-review-source.json').read_bytes())
def binding():
 files={p:sha((ROOT/p).read_bytes()) for p in manifest['files']}
 assert files==manifest['files']
 return sha(json.dumps(files,sort_keys=True,separators=(',',':')).encode())
report={'schema':'facman.independent-completion-gate-execution.v1','source_aggregate':binding(),'source_count':len(manifest['files'])}
def git(*args):
 return subprocess.check_output(['git',*args],cwd=ROOT).decode().strip()
report['before']={k:git('rev-parse',v) for k,v in [('head','HEAD'),('merge_head','MERGE_HEAD')]}
report['before']['index']=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=ROOT))
report['historical_objects']=git('show','-s','--format=%H %T %P','87aa7dc0662acff7fce5ee7368a3e16e077cbc6c','cd2936e79af79df0ddb11f758e149ac38745beea')
raw=(ROOT/gate.RECEIPT).read_bytes(); receipt=json.loads(raw)
assert sha(json.dumps(receipt,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode())==gate.RECEIPT_SEMANTIC_SHA256
archive=(ROOT/pathlib.Path(gate.RECEIPT).parent/'package-integration-custody.zip').read_bytes()
assert sha(archive)==gate.ARCHIVE_SHA256
with zipfile.ZipFile(io.BytesIO(archive)) as z:
 members=z.namelist(); assert len(members)==len(set(members))==20
 mm=json.loads(z.read('raw-member-manifest.json'));assert set(mm)==set(members)-{'raw-member-manifest.json'}
 for n,v in mm.items():
  b=z.read(n);assert len(b)==v['bytes'] and sha(b)==v['sha256'],n
 pre=json.loads(z.read('pr252-final-premerge.json'))
 checks=pre['statusCheckRollup'];assert len(checks)==12 and all(c['status']=='COMPLETED' and c['conclusion']=='SUCCESS' for c in checks)
 assert pre['headRefOid']==receipt['source']
 merged=json.loads(z.read('pr252-merged.json'));assert merged['state']=='MERGED' and merged['mergeCommit']==receipt['mergeCommit'] and merged['headRefOid']==receipt['source']
 rootreview=json.loads(z.read('workspace-repair-candidate-root-review.json'))
 parsed=[]
 with zipfile.ZipFile(io.BytesIO(z.read('workspace-repair-candidate-34048385176-logs.zip'))) as logs:
  for name in dict.fromkeys(row['log_member'] for row in rootreview['lifecycle_receipts']):
   original=logs.read(name).decode('utf-8')
   clean='\n'.join(re.sub(r'^\d{4}-\d{2}-\d{2}T\S+Z ?', '', line) for line in original.splitlines())
   for match in re.finditer(r'\{',clean):
    try: value,_=json.JSONDecoder().raw_decode(clean[match.start():])
    except ValueError: continue
    if isinstance(value,dict) and value.get('schema')=='facman.workspace_lifecycle_package_proof.v1': parsed.append({'log_member':name,'receipt':value})
 assert parsed==rootreview['lifecycle_receipts']
 assert len(parsed)==6
 assert {(r['receipt']['platform'],r['receipt']['package_mode']) for r in parsed}=={(p,m) for p in ('linux','win32','darwin') for m in ('portable','installed_stage')}
 for row in parsed:
  r=row['receipt'];assert r['status']=='pass' and r['source_dirty'] is False and r['source_revision']==receipt['source'] and r['source_tree']==receipt['source_tree']
  assert len(r['cases'])==11 and len({c['id'] for c in r['cases']})==11 and all(c['status']=='pass' for c in r['cases'])
  assert all(value is False for value in r['authority'].values())
 bundle=json.loads(z.read('candidate-evidence/product-candidate-bundle.v1.json'))
 assert len(bundle['assets'])==6 and bundle['source_revision']==receipt['source'] and bundle['source_tree']==receipt['source_tree']
 assert bundle['github']['run_id']==str(receipt['package_run']) and all(value is False for value in bundle['authority'].values())
 for row in [bundle['checksum'],*bundle['evidence']]:
  b=z.read('candidate-evidence/'+row['filename']);assert sha(b)==row['sha256'] and len(b)==row['bytes']
 for platform in ('linux','macos','windows'):
  r=json.loads(z.read(f'candidate-evidence/{platform}-candidate-evidence.v1.json'))
  assert r['source_revision']==receipt['source'] and r['source_tree']==receipt['source_tree'] and r['status']=='pass'
  assert all(a in bundle['assets'] for a in r['assets'])
 report['custody']={'archive_sha256':sha(archive),'raw_member_count':len(mm),'manifest_matched':True,'ci_checks':len(checks),'lifecycle_receipts_extracted_from_logs':len(parsed),'cases':sum(len(r['receipt']['cases']) for r in parsed),'bundle_assets':bundle['assets'],'source':receipt['source'],'tree':receipt['source_tree'],'all_authority_axes_false':True}
# Extra behavioral probes use only a fresh evidence-owned subtree, never source.
probe=E/'completion-gate-independent-probes';probe.mkdir(exist_ok=False)
p=probe/gate.RECEIPT;p.parent.mkdir(parents=True)
a=p.parent/'package-integration-custody.zip'
wu={'id':gate.TASK,'status':'complete','evidence':[gate.RECEIPT]}
probes=[]
def check(label,contains):
 errors=gate.validate(wu,probe);assert errors and any(contains in x for x in errors),(label,errors)
 probes.append({'name':label,'errors':errors})
check('missing receipt','refused')
p.write_bytes(raw);a.write_bytes(archive);assert gate.validate(wu,probe)==[]
a.write_bytes(b'x'*(16*1024*1024+1));check('oversized archive','byte budget')
a.write_bytes(archive)
value=raw.decode();value=value.replace('"beta1_ready": false','"beta1_ready": true, "beta1_ready": false')
assert value!=raw.decode();p.write_bytes(value.encode());check('duplicate authority field ending in original value','duplicate')
p.write_bytes(raw.replace(b'"oid":',b'"oid":"foreign", "oid":',1));check('nested duplicate merge field','duplicate')
p.write_bytes(raw)
plan=programme.load_plan();assert programme._validate_plan_milestones(plan)==[]
args=(readiness._load(readiness.READINESS),readiness._load(readiness.VERSION),readiness._load(readiness.RELEASE_INDEX),readiness._load(readiness.ARTIFACT_MATRIX))
assert readiness.validate(*args,plan=plan)==[]
future=['FACMAN-0.1-ALPHA6-MANAGED-INSTALL-LIFECYCLE-01','FACMAN-0.1-ALPHA7-CONTENT-WORLD-ROUTES-01','FACMAN-0.1-ALPHA7-PLAY-FRONTEND-CONVERGENCE-01']
for ident in future:
 changed=copy.deepcopy(plan);leaf=next(r for r in changed['workunit'] if r['id']==ident);leaf['status']='complete';leaf['evidence']=[gate.RECEIPT]
 for label,errors in [('programme',programme._validate_plan_milestones(changed)),('readiness',readiness.validate(*args,plan=changed))]:
  assert errors;probes.append({'name':label+' refuses forged '+ident,'errors':errors})
report['independent_probes']=probes
# Run source tests with bytecode disabled; source/index and all forty raw bytes must remain stable.
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8')
command=[str(PY),'-B','-m','unittest','tests.test_workspace_migration_closeout','tests.test_release_programme','tests.test_foundation_beta_readiness','tests.test_alpha5_final_candidate_closeout','tests.test_aide_target_truth','tests.test_test_architecture']
started=time.monotonic();result=subprocess.run(command,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);duration=time.monotonic()-started
log=E/'completion-gate-independent-tests.txt';log.write_bytes(result.stdout)
report['tests']={'command':command,'exit_code':result.returncode,'seconds':duration,'log_sha256':sha(result.stdout),'output':result.stdout.decode('utf-8','replace')}
report['source_aggregate_after']=binding()
report['after']={k:git('rev-parse',v) for k,v in [('head','HEAD'),('merge_head','MERGE_HEAD')]}
report['after']['index']=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=ROOT))
assert report['after']==report['before'];assert result.returncode==0
report['result']='PASS'
output=E/'completion-gate-independent-execution.json';output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'result':'PASS','source_aggregate':report['source_aggregate'],'probes':len(probes),'tests':report['tests'],'receipt':str(output),'sha256':sha(output.read_bytes())},indent=2))