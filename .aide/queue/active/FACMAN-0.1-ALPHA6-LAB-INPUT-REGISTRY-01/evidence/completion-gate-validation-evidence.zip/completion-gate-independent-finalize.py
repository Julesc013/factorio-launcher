import copy,hashlib,json,pathlib,subprocess,sys,zipfile
ROOT=pathlib.Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\worktrees\task-facman-lab-input-registry-01')
E=pathlib.Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-46230f3671\evidence')
C=pathlib.Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-230b4b08ab\evidence\workspace-repair-candidate-34048385176.zip')
sys.path.insert(0,str(ROOT))
from tools import workspace_migration_closeout_check as gate,release_programme_check as programme,foundation_beta_readiness_check as readiness
sha=lambda b:hashlib.sha256(b).hexdigest()
execution=json.loads((E/'completion-gate-independent-execution.json').read_bytes())
manifest=json.loads((E/'completion-gate-review-source.json').read_bytes())
assert all(sha((ROOT/p).read_bytes())==h for p,h in manifest['files'].items())
plan=programme.load_plan();args=(readiness._load(readiness.READINESS),readiness._load(readiness.VERSION),readiness._load(readiness.RELEASE_INDEX),readiness._load(readiness.ARTIFACT_MATRIX))
extra=[]
for ident in ('FACMAN-0.1-FEATURE-FREEZE-01','FACMAN-0.1-BETA1-EXACT-RELEASE-01'):
 changed=copy.deepcopy(plan);row=next(r for r in changed['workunit'] if r['id']==ident);row.update(status='complete',evidence=[gate.RECEIPT])
 for label,errors in [('programme',programme._validate_plan_milestones(changed)),('readiness',readiness.validate(*args,plan=changed))]:
  assert errors;extra.append({'case':label+' refuses '+ident,'errors':errors})
raw=C.read_bytes();assert sha(raw)=='cc9d99f5149aeceb66b199c718e956ec4810f6edbfa6fc95a3a3098de010f2d2'
with zipfile.ZipFile(C) as z:
 assert len(z.namelist())==len(set(z.namelist()))==14
 bundle=json.loads(z.read('product-candidate-bundle.v1.json'))
 for row in [*bundle['assets'],*bundle['evidence'],bundle['checksum']]:
  b=z.read(row['filename']);assert sha(b)==row['sha256'] and len(b)==row['bytes']
 for line in z.read('SHA256SUMS').decode().splitlines():
  digest,name=line.split(maxsplit=1);name=name.lstrip('* ');assert sha(z.read(name))==digest,name
normalization=json.loads((E/'completion-gate-generated-normalization.json').read_bytes())
with zipfile.ZipFile(E/'completion-gate-generated-raw.zip') as z:
 assert set(z.namelist())==set(normalization)
 for name,hashes in normalization.items():
  rawline=z.read(name);assert sha(rawline)==hashes['raw'] and sha(rawline.replace(b'\r\n',b'\n'))==hashes['lf']==sha((ROOT/name).read_bytes())
lab={}
for p in ['tools/lab_input_registry.py','tests/test_lab_input_registry.py','tools/development_layout.py','tests/test_development_layout.py','docs/development/lab-input-registry.md']:
 b=(ROOT/p).read_bytes();head=subprocess.check_output(['git','show','HEAD:'+p],cwd=ROOT);assert b==head;lab[p]=sha(b)
changed=set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT).decode().splitlines())
new=set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=ROOT).decode().splitlines())
assert changed|new==set(manifest['files'])
validation=json.loads((E/'completion-gate-final-validation.json').read_bytes())
for row in validation['checks']:
 assert row['exit_code']==0 and sha((E/(row['label']+'.txt')).read_bytes())==row['sha256']
index=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=ROOT));assert index==execution['before']['index']
assert all(sha((ROOT/p).read_bytes())==h for p,h in manifest['files'].items())
report={
 'schema':'facman.independent-workspace-completion-governance-review.v1',
 'result':'PASS','findings':[],'reviewer':'/root/native_ownership',
 'head':execution['before']['head'],'merge_head':execution['before']['merge_head'],
 'source_manifest_sha256':sha((E/'completion-gate-review-source.json').read_bytes()),
 'source_aggregate':manifest['aggregate'],'source_files':manifest['files'],
 'source_index_branch_remotes_unchanged':True,'index_entries_sha256':index,
 'review_scope':'Historical workspace leaf completion, immutable receipt/custody authority, release/foundation guards, roadmap projection, queue/claim bookkeeping and affected tests; no new product source change beyond already reviewed PR252 integration.',
 'independent_tests':{'count':96,'seconds_reported_by_unittest':2.364,'result':'PASS','receipt_sha256':sha((E/'completion-gate-independent-execution.json').read_bytes()),'log_sha256':sha((E/'completion-gate-independent-tests.txt').read_bytes())},
 'extra_probes':extra,'total_extra_behavioral_probes':14,
 'custody':execution['custody'],
 'candidate_asset_archive':{'path':str(C),'sha256':sha(C.read_bytes()),'member_count':14,'six_actual_asset_hashes_and_sizes_verified':True,'six_evidence_hashes_and_sizes_verified':True,'all_checksum_lines_verified':True},
 'lab_core_unchanged_from_head':lab,
 'generated_raw_line_endings_verified':normalization,
 'author_strict_receipt_sha256':sha((E/'completion-gate-final-validation.json').read_bytes()),
 'initial_test_invocation_failure':{'path':'completion-gate-independent-tests-initial-missing-import-path.txt','sha256':sha((E/'completion-gate-independent-tests-initial-missing-import-path.txt').read_bytes()),'reason':'Reviewer omitted repository tests import path; 71 tests passed and tests.test_test_architecture failed import native_cli. Replayed with PYTHONPATH=root+tests and identical forty-file source; all96 passed.'},
 'assessment':[
  'Only the named workspace leaf gains complete status. Full canonical semantic receipt hash and exact raw archive hash are necessary; later receipt field drift, authority promotion, wrong task, missing or duplicate custody and over-budget inputs are refused.',
  'Single captured receipt is canonicalized with recursive duplicate-key rejection; archive is bounded and hashed from one opened stream. Archive is not extracted by the gate. Independently audited all19 raw members plus manifest, then extracted six lifecycle receipts from retained raw logs and matched them to the review projection.',
  'Historical Git source87aa and normal mergecd2936 have identical reviewed tree06071. Twelve retained premerge checks are completed SUCCESS, six platform/mode receipts contain11 passing cases each and all authority ceilings remain false.',
  'Future Alpha6/Alpha7 leaves, feature freeze and Beta1 remain planned and cannot reuse workspace proof; independent mutations were refused by both programme and foundation validators. Canonical unfinished roadmap projection does not grant completion authority.',
  'Canonical queue/plan and claim ledger close only bounded known migration/recovery machine qualification; lab preparation, real game/human inputs and current final candidate qualification remain open.'
 ],
 'limitations':[
  'This is historical unsigned Alpha5 candidate workspace qualification, not a new full product qualification on the lab merge or final Beta1 candidate.',
  'Human acceptance, Factorio execution, live user-workspace use, signing/tagging/publication and Beta1 readiness remain unqualified; later candidate/source drift requires fresh qualification.',
  'No new native lifecycle execution or hosted CI was performed by this governance reviewer. The66 cases are independently audited source-bound hosted evidence; the96 governance tests and14 probes were independently executed.',
  'Source/index were frozen for review; post-review source changes require a new binding. Parent owns staged merge completion, commit and fresh hosted checks.'
 ]
}
output=E/'completion-gate-independent-final-review.json';output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
markdown='''# Independent workspace completion governance review

PASS: no P0/P1/P2 findings in the frozen bounded increment.

Reviewed HEAD `3541531422bf4e344d6f8120f2fe28c484bffabe`, pending normal merge `cd2936e79af79df0ddb11f758e149ac38745beea`, and all40 exact files bound by aggregate `30bf64029f7a757a5cdb88c5015d4dcc05d56c8101e8ac589aa881221e00fc9c`. Source, index, branch and remotes were not changed by this reviewer. Lab core remains byte-identical to the approved HEAD.

Independently reran96 affected source tests: PASS,2.364s. Fourteen extra probes passed, covering missing receipt, oversized archive, duplicate authority and nested merge keys, and attempted premature completion of Alpha6/Alpha7, feature freeze and Beta1 through both release gates. The initial reviewer invocation omitted the tests import path; its71 passes and one import error are retained. Corrected invocation used identical source.

Audited the pinned20-member custody ZIP:19 raw members plus exact manifest. Independently extracted all6 lifecycle receipts from raw hosted logs and matched all66 passing cases, exact source87aa/tree06071 and false authority ceilings. Local Git confirms normal PR252 mergecd2936 retains that source tree. The retained12 premerge checks are all completed SUCCESS. Also rehashed the actual retained six-asset candidate ZIP and every asset, evidence and checksum entry. Five generated raw/LF mappings were verified.

Only the reviewed historical workspace leaf is complete. The gate requires canonical receipt SHA `8259a695712fb089d144c00177add7fa40870f609e859686362840d2f93a2d3a` and archive SHA `bb852350a8112b4165ae9df4086e45d125d9f97a155b86a6c4a4c72979e0e1e2`. Other future status/dependency and Beta readiness guards remain unchanged. Roadmap projection follows the canonical unfinished sequence.

This supports the authorized governance checkpoint and fresh CI. It grants no human, Factorio, live user-workspace, signing, publication, or Beta1 authority. The66 hosted cases were audited, not rerun by this reviewer. Later product/candidate drift requires current qualification.

Exact bindings, evidence hashes, probes, retained invocation failure and limitations are in `completion-gate-independent-final-review.json` and `completion-gate-independent-execution.json`.
'''
md=E/'completion-gate-independent-final-review.md';md.write_text(markdown,encoding='utf-8')
print(json.dumps({'result':'PASS','json_sha256':sha(output.read_bytes()),'markdown_sha256':sha(md.read_bytes()),'source_aggregate':manifest['aggregate'],'independent_tests':96,'extra_probes':14,'actual_assets_hashed':6},indent=2))