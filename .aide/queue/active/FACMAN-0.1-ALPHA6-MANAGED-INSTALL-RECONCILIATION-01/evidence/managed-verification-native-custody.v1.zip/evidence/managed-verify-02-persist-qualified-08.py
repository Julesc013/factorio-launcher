import hashlib,json,sys,zipfile
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e');E=W/'evidence'
Q=R/'.aide/queue/active/FACMAN-0.1-ALPHA6-MANAGED-INSTALL-RECONCILIATION-01';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
result=json.loads((E/'managed-verify-02-qualification-result-08.json').read_bytes())
assert result['status']=='PASS_SCOPED_NATIVE_MANAGED_VERIFICATION_WITH_HUMAN_AND_RPC'
a=json.loads((E/'managed-verify-02-source-assurance-05.json').read_bytes())
for n,h in a['source_files_sha256'].items():assert sha(R/n)==h,n
for c in result['commands']:assert c['exit']==0 and c['primary_stopped'] and c['job_empty']
assert result['human_commands']>=8 and result['rpc_observation']['retained_data_unchanged']
proof=Path(result['public_root']);assert proof.is_relative_to(W) and sha(proof/'receipt.json')==result['public_receipt_sha256']
archive=Q/'evidence/managed-verification-native-custody.v1.zip';receipt=Q/'evidence/managed-verification-native.v1.json'
assert not archive.exists() and not receipt.exists()
inputs={};omitted=[]
for p in sorted(E.glob('managed-verify-02-*')):
 for path in sorted(p.rglob('*')) if p.is_dir() else [p]:
  if not path.is_file():continue
  assert path.resolve().is_relative_to(W.resolve()) and not path.is_symlink()
  assert not getattr(path.stat(follow_symlinks=False),'st_file_attributes',0)&1024
  size=path.stat().st_size
  if path.suffix.lower()=='.exe' or size>1024*1024:
   omitted.append(dict(path=str(path.relative_to(W)),bytes=size,sha256=sha(path),reason='local-only full log or failed native image'));continue
  inputs['evidence/'+str(path.relative_to(E)).replace('\\','/')]=path
for path in sorted(proof.rglob('*')):
 if not path.is_file():continue
 assert path.resolve().is_relative_to(proof.resolve()) and not path.is_symlink()
 assert not getattr(path.stat(follow_symlinks=False),'st_file_attributes',0)&1024
 assert path.stat().st_size<=1024*1024
 inputs['public-proof/'+str(path.relative_to(proof)).replace('\\','/')]=path
assert sum(p.stat().st_size for p in inputs.values())<=16*1024*1024
manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in inputs.items()}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in inputs.items():z.writestr(n,p.read_bytes())
 z.writestr('custody-manifest.v1.json',json.dumps(dict(schema='facman.managed_verification_custody.v1',files=manifest,local_only_omissions=omitted),indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(inputs)+1
 for n,c in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==c['sha256']
payload=dict(schema='facman.managed_verification_native_acceptance.v1',status='PASS_SCOPED_SOURCE_NATIVE_ENGINEERING',
 work_item=Q.name,source_base=a['base'],source_branch=a['branch'],source_files_sha256=a['source_files_sha256'],
 cli_sha256=result['cli_sha256'],parser_sha256=result['reused_parser_sha256'],provider_sha256=result['reused_provider_hashes'],
 proof_calls=result['public_commands'],human_cli_calls=result['human_commands'],json_rpc_calls=1,
 observations=['Registered installation verified through pinned Universal Setup installed.inspect and installed.verify; no archive or mutation needed.',
 'Healthy, changed, missing, wrong-type and wholly absent target reports; unknown data reported/preserved. Unsafe record/provider/link states refused.',
 'Human CLI prints provider status, owned/missing/changed counts, damaged paths and preserved unknown paths. JSON and declared v2 stdio RPC work.',
 'Every positive/refused public observation preserves retained target/workspace/provider bytes and paths. Native parser smoke, strict repository and AIDE pass.'],
 independent_source_review=dict(reviewer='/root',author='/root/managed_verify_impl',non_authoring=True,packet_sha256=sha(E/'managed-verify-02-source-assurance-05.json')),
 final_qualification_sha256=sha(E/'managed-verify-02-qualification-result-08.json'),
 custody=dict(path=str(archive.relative_to(R)).replace('\\','/'),sha256=sha(archive),bytes=archive.stat().st_size,members=len(inputs)+1),
 preserved_failures=['Native test used remapped __FILE__ for fixture location; embedded exact fixture corrected.',
 'Root partial MSBuild invocation failed to link and hit its own execution allowance; normal targeted Build corrected.',
 'Public proof misexpected default unavailable gate; oracle and configured refusal envelope corrected.',
 'Strict gate found five stale generated files; refreshed without milestone closure.',
 'Actual human CLI printed generic preview; formatter and native namespace correction qualified against real calls.',
 'Extra RPC probe omitted dry_run and used wrong payload field; invalid packet retained, declared schema request qualified.',
 'Root script budget exceeded helper maximum; no job dispatched; budget corrected.'],
 limitations=['Explicit acceptance configuration required; unconfigured production capability remains unavailable.',
 'Read-only observations are not an atomic target snapshot and grant no mutation, permit, repair or game execution.',
 'Synthetic source-native evidence only; no produced-package, human, physical-host, other-platform, F11 closure or Beta qualification.',
 'Present wrong-type roots and observed reparse links are conservatively refused; torn repair not claimed.'],
 commands=result['commands'],workunit_closed=False,beta_qualified=False,release_qualified=False)
receipt.write_text(json.dumps(payload,indent=2)+'\n',encoding='utf-8')
with (Q/'ExecPlan.md').open('a',encoding='utf-8',newline='\n') as f:
 f.write('\n## 2026-10-13 — read-only managed installation verification\n\n'
 '- Implemented registered installs.verify using pinned Universal Setup read-only inspection/verification with exact provider, record, ownership and report bindings. The default unconfigured capability remains unavailable.\n'
 '- Verified healthy, damaged and absent targets, archive independence, preserved foreign data, and record/provider/link refusals. Ordinary CLI, JSON and declared v2 stdio RPC report actual observations without mutation.\n'
 f"- Accepted {result['public_commands']} real public CLI calls including {result['human_commands']} human-format calls, one RPC call, native decoder smoke, strict gate and AIDE. See evidence/managed-verification-native.v1.json and its hash-closed custody for exact source/images, independent review, failures and owned execution receipts.\n"
 '- Scoped source-native synthetic engineering acceptance only. Produced packages, genuine host/game/human acceptance, remaining lifecycle transitions and complete F11/Beta remain open; the WorkUnit stays active.\n')
out=E/'managed-verify-02-persistence-review-08.json';assert not out.exists()
out.write_text(json.dumps(dict(schema='facman.managed_verification_persistence_review.v1',verdict='PASS',reviewer='/root',runtime_author='/root/managed_verify_impl',receipt_sha256=sha(receipt),archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,source_postimages_retained=True,exact_custody_verified=True,status_or_authority_promoted=False),indent=2)+'\n')
print(json.dumps(dict(receipt=str(receipt),archive_bytes=archive.stat().st_size,members=len(inputs)+1,verdict='PASS')))

