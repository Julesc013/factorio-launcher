
import hashlib,json,os,subprocess,sys,traceback
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e');E=W/'evidence';B=W/'native-developer'
sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools import native_build,provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads((E/'managed-verify-02-source-assurance-02.json').read_bytes())
assert a['independent'] and a['non_authoring'] and a['verdict']=='PASS_TEST_ONLY_CORRECTION_AND_NATIVE_REUSE'
def bound():
 assert subprocess.check_output(['git','branch','--show-current'],cwd=R,text=True).strip()==a['branch']
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==a['base']
 for name,digest in a['source_files_sha256'].items():assert sha(R/name)==digest,name
 for name,digest in a['reused_product_hashes'].items():assert sha(B/'Release'/name)==digest,name
bound()
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),
 PYTHONDONTWRITEBYTECODE='1',FACMAN_MIN_FREE_GIB='12',CMAKE_BUILD_PARALLEL_LEVEL='2')
assert not (W/'verify-02-public-proof').exists()
native_build.require_disk_reserve(B)
result_path=E/'managed-verify-02-qualification-result-03.json';assert not result_path.exists()
result=dict(schema='facman.managed_verify_native_qualification.v1',status='qualifying_test_only_correction',
 source_assurance_sha256=sha(E/'managed-verify-02-source-assurance-02.json'),prior_failure_sha256=sha(E/'managed-verify-02-qualification-result-02.json'),
 reused_product_hashes=a['reused_product_hashes'],commands=[],product_rebuilds=0,new_roots=0,new_clones=0,new_worktrees=0,
 product_candidates=0,goal_status_mutated=False,
 runner_correction='Use normal Build with project-reference builds disabled; retire only owned auxiliary descendants after primary completion, retaining all product hashes.')
def save():result_path.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
save();budget=owned.Budget(3600,900)
def run(name,args,timeout=600):
 r=owned.command([str(x) for x in args],cwd=R,environment=dict(os.environ),timeout=timeout,budget=budget,
  output_limit=8*1024*1024,directory=E/f'managed-verify-02-{name}-execution-03',wait_for_job_empty_after_primary=False)
 result['commands'].append(dict(name=name,argv=[str(x) for x in args],exit=r.returncode,termination=r.receipt['termination'],
  primary_stopped=r.receipt['primary_stopped'],job_empty=r.receipt['job_empty_observed'],
  receipt=str(r.directory/'receipt.json'),sha256=sha(r.directory/'receipt.json')));save()
 assert r.ok and r.receipt['primary_stopped'] and r.receipt['job_empty_observed'],name
 return r
try:
 build=list(a['smoke_only_build_command'])
 build[2]='/t:Build'
 run('smoke-build',build,300);bound()
 assert (B/'Release/flb_setup_gateway_smoke.exe').is_file(),'test executable was not linked'
 run('parser',['ctest','--test-dir',B,'-C','Release','-R','^flb_setup_gateway_smoke$','--output-on-failure'],300)
 result['corrected_parser_sha256']=sha(B/'Release/flb_setup_gateway_smoke.exe');save()
 os.environ['FACMAN_CLI_EXE']=str(B/'Release/facman.exe')
 run('public',['py','-3','-B','tests/integration/facman_managed_install_lifecycle.py','--facman',B/'Release/facman.exe',
  '--root',W/'verify-02-public-proof','--scenario','verification'],600)
 run('strict',['py','-3','-B','tools/strict_check.py'],900)
 run('aide',['py','-3','-B','.aide/scripts/aide_lite.py','test'],600)
 bound();proof=json.loads((W/'verify-02-public-proof/receipt.json').read_bytes());assert proof['result']=='pass'
 result.update(status='PASS_SCOPED_NATIVE_MANAGED_VERIFICATION',public_commands=len(proof['steps']),
  public_receipt_sha256=sha(W/'verify-02-public-proof/receipt.json'),classification='owned synthetic source-native engineering evidence',
  game_executed=False,human_qualified=False,other_host_qualified=False,produced_package_qualified=False,workunit_closed=False,beta_qualified=False)
except BaseException as exc:result.update(status='ACTIONABLE_FAILURE',error=str(exc),traceback=traceback.format_exc())
finally:save();print(json.dumps(result,indent=2))
