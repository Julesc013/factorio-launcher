import json,hashlib,subprocess,sys,os
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher'); E=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e\evidence');B=E.parent/'native-developer'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads((E/'managed-verify-02-source-assurance-03.json').read_bytes());p=json.loads((E/'managed-verify-02-source-review-04.json').read_bytes())
expected=dict(a['source_files_sha256'])
expected.update(p['root_refreshed_status_files_preserved_sha256'])
for n,x in p['changed_files'].items():expected[n]=x['postimage_sha256']
assert sha(p['delta_patch']['path'])==p['delta_patch']['sha256']
for n,h in expected.items():assert sha(R/n)==h,n
for n,h in a['reused_provider_hashes'].items():assert sha(B/'Release'/n)==h,n
assert subprocess.check_output(['git','branch','--show-current'],cwd=R,text=True).strip()==a['branch']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==a['base']
actual=set(subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R,text=True).splitlines())
assert actual==set(expected),(actual-set(expected),set(expected)-actual)
a.update(verdict='PASS_HUMAN_CLI_CORRECTION',prior_assurance_sha256=sha(E/'managed-verify-02-source-assurance-03.json'),source_delta_sha256=sha(E/'managed-verify-02-source-review-04.json'),source_files_sha256=expected,
 decisions=['Existing human verification route renders typed status/counts/damaged and preserved foreign paths through the existing report formatter. JSON and RPC/backend code unchanged.',
 'Default unavailable gate and configured safety refusals retained. Successful observation with fail report remains transport success; no mutation or repair capability implied.',
 'Report JSON already validated in provider gateway. Formatter refuses invalid field shape instead of emitting generic preview success.',
 'Real public human subprocess assertions bind expected fixture counts/paths and all retained bytes. New execution needed before acceptance.'],
 affected_build_commands=[[r'C:\Program Files\Microsoft Visual Studio\18\Enterprise\MSBuild\Current\Bin\MSBuild.exe',str(B/'apps/cli/facman_cli.vcxproj'),'/t:Build','/p:Configuration=Release','/p:Platform=x64','/p:BuildProjectReferences=false','/p:TrackFileAccess=false','/m:2','/nr:false']])
out=E/'managed-verify-02-source-assurance-04.json';assert not out.exists();out.write_text(json.dumps(a,indent=2)+'\n')
print('Independent CLI review PASS; 39 exact source postimages bound.')
sys.path.insert(0,str(R))
from tools import provider_canary_process as owned
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(E.parent/'t'),TMP=str(E.parent/'t'),PYTHONDONTWRITEBYTECODE='1')
result={'schema':'facman.checked_acceptance_integration.v1','source':'f6a4710aec0c72a24296b9d3baaa32301ed05997','pr':407,'prior_observer_result_sha256':sha(E/'pack-partial-produced-checked-integration-result-02.json'),'status':'qualifying_allowed_merge_method','method':'merge','new_ci_jobs':0,'new_candidates':0,'local_checkout_mutated':False,'goal_status_mutated':False,'commands':[]}
out=E/'pack-partial-produced-checked-integration-result-03.json';assert not out.exists()
def save():out.write_text(json.dumps(result,indent=2)+'\n')
def run(label,args):
 r=owned.command(args,cwd=R,timeout=120,directory=E/('pack-partial-produced-integration03-'+label))
 result['commands'].append({'label':label,'receipt':str(r.directory/'receipt.json'),'sha256':sha(r.directory/'receipt.json'),'exit':r.returncode});save()
 assert r.ok and r.receipt['primary_stopped'] and r.receipt['job_empty_observed'],(label,r.stderr[:1000])
 return r.stdout
save()
repo=json.loads(run('repository',['gh','api','repos/Julesc013/factorio-launcher']))
assert repo['allow_merge_commit'] and not repo['allow_squash_merge'] and not repo['allow_rebase_merge']
pr=json.loads(run('before',['gh','pr','view','407','--repo','Julesc013/factorio-launcher','--json','state,headRefOid,baseRefName,mergeStateStatus']))
assert pr['state']=='OPEN' and pr['headRefOid']==result['source'] and pr['baseRefName']=='dev' and pr['mergeStateStatus']=='CLEAN'
checks=json.loads(run('checks',['gh','pr','checks','407','--repo','Julesc013/factorio-launcher','--required','--json','name,state,bucket,link']))
assert len(checks)>=12 and all(c['state']=='SUCCESS' and c['bucket']=='pass' for c in checks)
result['required_checks']=checks
result['decision']='Repository permits only merge commits; preserve qualified single-WorkUnit history through normal merge without changing policy/settings or bypassing checks.'
save()
run('merge',['gh','pr','merge','407','--repo','Julesc013/factorio-launcher','--merge','--match-head-commit',result['source']])
after=json.loads(run('after',['gh','pr','view','407','--repo','Julesc013/factorio-launcher','--json','state,headRefOid,baseRefName,mergeCommit']))
assert after['state']=='MERGED' and after['headRefOid']==result['source']
result.update(status='MERGED_CHECKED_REQUIRED_GREEN',merge_commit=after['mergeCommit']['oid']);save()
print(json.dumps({'pr':407,'status':result['status'],'merge_commit':result['merge_commit'],'method':'merge','required_checks':len(checks)}))
