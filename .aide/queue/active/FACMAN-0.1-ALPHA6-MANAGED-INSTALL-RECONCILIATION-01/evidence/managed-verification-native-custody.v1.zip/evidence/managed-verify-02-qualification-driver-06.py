import hashlib,json,os,subprocess,sys,time,traceback
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e');E=W/'evidence';B=W/'native-developer'
sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools import native_build,provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads((E/'managed-verify-02-source-assurance-04.json').read_bytes())
assert a['independent'] and a['non_authoring'] and a['verdict']=='PASS_HUMAN_CLI_CORRECTION'
def bound():
 assert subprocess.check_output(['git','branch','--show-current'],cwd=R,text=True).strip()==a['branch']
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==a['base']
 for n,h in a['source_files_sha256'].items():assert sha(R/n)==h,n
 for n,h in a['reused_provider_hashes'].items():assert sha(B/'Release'/n)==h,n
bound()
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),
 PYTHONDONTWRITEBYTECODE='1',FACMAN_MIN_FREE_GIB='12',CMAKE_BUILD_PARALLEL_LEVEL='2',MSBUILDDISABLENODEREUSE='1')
proof=W/'verify-02-public-proof-06';assert not proof.exists()
result_path=E/'managed-verify-02-qualification-result-06.json';assert not result_path.exists()
result=dict(schema='facman.managed_verify_native_qualification.v1',status='qualifying_human_cli_correction',
 source_assurance_sha256=sha(E/'managed-verify-02-source-assurance-04.json'),commands=[],full_product_rebuilds=0,
 new_roots=0,new_clones=0,new_worktrees=0,product_candidates=0,goal_status_mutated=False,
 reused_provider_hashes=a['reused_provider_hashes'],reused_parser_sha256=sha(B/'Release/flb_setup_gateway_smoke.exe'))
def save():result_path.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
save();budget=owned.Budget(18000,1800)
def run(name,args,timeout=600,environment=None,input_bytes=b''):
 r=owned.command([str(x) for x in args],cwd=R,environment=environment or dict(os.environ),timeout=timeout,budget=budget,
  input_bytes=input_bytes,output_limit=8*1024*1024,directory=E/f'managed-verify-02-{name}-execution-06',wait_for_job_empty_after_primary=False)
 result['commands'].append(dict(name=name,exit=r.returncode,termination=r.receipt['termination'],
  primary_stopped=r.receipt['primary_stopped'],job_empty=r.receipt['job_empty_observed'],
  receipt=str(r.directory/'receipt.json'),sha256=sha(r.directory/'receipt.json')));save()
 assert r.ok and r.receipt['primary_stopped'] and r.receipt['job_empty_observed'],(name,r.stderr.decode('utf-8','replace')[-1200:])
 return r
try:
 # Active foreign native jobs are observed without model calls; their trees/processes remain untouched.
 started=time.monotonic();last=None;index=0
 while True:
  index+=1
  query=owned.command(['pwsh','-NoProfile','-Command',"@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(cl|cmake|ctest|link)\\.exe$' } | Select-Object Name,ProcessId,CommandLine) | ConvertTo-Json -Compress"],cwd=R,timeout=40,directory=E/f'managed-verify-02-native-resource-preflight-06-{index:03d}')
  assert query.ok
  active=json.loads(query.stdout or b'[]')
  if not active:break
  if active!=last:
   result['status']='waiting_for_foreign_native_job';result['foreign_native_jobs']=active;save();print('Waiting for active foreign native job; no source/job mutation.',flush=True);last=active
  assert time.monotonic()-started<14400,'foreign native job exceeds local observation allowance; preserved'
  time.sleep(60)
 result['status']='qualifying_human_cli_correction';save()
 native_build.require_disk_reserve(B)
 run('cli-build',a['affected_build_commands'][0],1800)
 bound()
 assert sha(B/'Release/flb_setup_gateway_smoke.exe')==result['reused_parser_sha256']
 result['cli_sha256']=sha(B/'Release/facman.exe');save()
 os.environ['FACMAN_CLI_EXE']=str(B/'Release/facman.exe')
 run('public',['py','-3','-B','tests/integration/facman_managed_install_lifecycle.py','--facman',B/'Release/facman.exe','--root',proof,'--scenario','verification'],600)
 public=json.loads((proof/'receipt.json').read_bytes());assert public['result']=='pass'
 result.update(public_commands=len(public['steps']),human_commands=sum(s.get('format')=='human' for s in public['steps']),public_root=str(proof),public_receipt_sha256=sha(proof/'receipt.json'));save()
 case=proof/'verification'
 def snapshot():
  return {str(p.relative_to(case)):('directory' if p.is_dir() else sha(p)) for p in sorted(case.rglob('*'))}
 before=snapshot()
 env=dict(os.environ)
 for k in list(env):
  if k.startswith('FACMAN_TEST_INSTALL_') or k in {'FACMAN_SETUP_STATE_ROOT','FACMAN_SETUP_ACCEPTANCE_ROOT','FACMAN_SETUP_POLICY_ACTIVATION'}:env.pop(k)
 env.update(FACMAN_SETUP_STATE_ROOT=str(case/'setup-state'),FACMAN_SETUP_ACCEPTANCE_ROOT=str(case),FACMAN_SETUP_POLICY_ACTIVATION='operator_acceptance_candidate')
 request=dict(schema='facman.transport_request.v2',protocol_version=2,request_id='verify-rpc-proof',operation_id='verify-rpc-operation',attempt_id='verify-rpc-attempt',workspace=str(case/'workspace'),command='installs.verify',dry_run=False,payload={'id':'managed-test'})
 rpc=run('rpc',[B/'Release/facman.exe','--workspace',case/'workspace','rpc','--stdio'],60,env,(json.dumps(request)+'\n').encode())
 response=json.loads(rpc.stdout)
 assert snapshot()==before,'RPC verification changed retained data'
 assert response['request_id']==request['request_id'] and response['command']==request['command'] and response['outcome']=='ok',response
 payload=response['payload'];assert payload['schema']=='usk.verification_report.v1' and payload['status']=='warn' and payload['unknown_paths']==['user-data.txt'],payload
 result['rpc_observation']={'status':payload['status'],'unknown_paths':payload['unknown_paths'],'retained_data_unchanged':True,'request_schema':request['schema']};save()
 run('strict',['py','-3','-B','tools/strict_check.py'],1800)
 run('aide',['py','-3','-B','.aide/scripts/aide_lite.py','test'],600)
 bound();result.update(status='PASS_SCOPED_NATIVE_MANAGED_VERIFICATION_WITH_HUMAN_AND_RPC',
 classification='owned synthetic source-native engineering evidence',game_executed=False,human_qualified=False,other_host_qualified=False,produced_package_qualified=False,workunit_closed=False,beta_qualified=False)
except BaseException as exc:result.update(status='ACTIONABLE_FAILURE',error=str(exc),traceback=traceback.format_exc())
finally:save();print(json.dumps({k:v for k,v in result.items() if k not in ('commands','foreign_native_jobs')},indent=2))
