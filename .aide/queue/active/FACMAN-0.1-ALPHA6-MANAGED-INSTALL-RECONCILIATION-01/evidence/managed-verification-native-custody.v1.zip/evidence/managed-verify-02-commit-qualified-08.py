import hashlib,json,os,subprocess,sys,traceback
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e');E=W/'evidence'
sys.path.insert(0,str(R))
from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1')
a=json.loads((E/'managed-verify-02-source-assurance-05.json').read_bytes())
qualified=json.loads((E/'managed-verify-02-qualification-result-08.json').read_bytes())
assert qualified['status']=='PASS_SCOPED_NATIVE_MANAGED_VERIFICATION_WITH_HUMAN_AND_RPC'
# The independent GUI result review must precede primary checkout mutation.
gui=json.loads((E/'make-ready-delivered-live-ui-final-review-01.json').read_bytes());assert gui['verdict']=='PASS' and gui['non_authoring'] and gui['independent']
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True,stderr=subprocess.PIPE).strip()
assert git('branch','--show-current')==a['branch'] and git('rev-parse','HEAD')==a['base']
for n,h in a['source_files_sha256'].items():assert sha(R/n)==h,n
assert not git('diff','--cached','--name-only')
result=dict(schema='facman.managed_verify_commit_submission.v1',status='preparing_checked_commit',commands=[],compiled_source_postimages_retained=True,goal_status_mutated=False)
out=E/'managed-verify-02-commit-result-08.json';assert not out.exists()
def save():out.write_text(json.dumps(result,indent=2)+'\n')
def run(label,args,timeout=120):
 r=owned.command([str(x) for x in args],cwd=R,timeout=timeout,directory=E/('managed-verify-02-commit08-'+label))
 result['commands'].append(dict(label=label,receipt=str(r.directory/'receipt.json'),sha256=sha(r.directory/'receipt.json'),exit=r.returncode));save()
 assert r.ok and r.receipt['primary_stopped'] and r.receipt['job_empty_observed'],(label,r.stderr.decode('utf-8','replace')[-1200:])
 return r.stdout.decode('utf-8','replace')
try:
 save()
 run('persist',['py','-3','-B',E/'managed-verify-02-persist-qualified-08.py'])
 run('fetch',['git','fetch','origin','dev'])
 target=git('rev-parse','origin/dev');assert target=='7ab7f73ed28ad1ef3ec65c886df8025d8dee606a',('new dev requires changed-source review',target)
 delta=git('diff','--name-only',a['base']+'..'+target).splitlines()
 prefix='.aide/queue/active/FACMAN-0.1-ALPHA7-MAKE-READY-SELECTED-SAVE-01/'
 assert len(delta)==3 and all(n.startswith(prefix) for n in delta)
 current=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
 assert not set(delta)&current
 plan=dict(schema='facman.managed_verify_synchronization_plan.v1',from_head=a['base'],to_head=target,
  branch=a['branch'],new_dev_paths=delta,all_dirty_changes_task_owned=True,source_receipt_sha256=sha(E/'managed-verify-02-source-assurance-05.json'),
  validation_sha256=sha(E/'managed-verify-02-qualification-result-08.json'),
  planned_argv=[['git','merge','--ff-only','origin/dev']],standing_user_authorization=True,
  qualification_reuse='Exact39 physical source postimages and native/provider images retained; integrated dev changes only disjoint accepted evidence.')
 (E/'managed-verify-02-synchronization-plan-08.json').write_text(json.dumps(plan,indent=2)+'\n')
 run('sync-base',['git','merge','--ff-only','origin/dev'])
 assert git('rev-parse','HEAD')==target
 for n,h in a['source_files_sha256'].items():assert sha(R/n)==h,n
 Q='.aide/queue/active/FACMAN-0.1-ALPHA6-MANAGED-INSTALL-RECONCILIATION-01'
 allowed=set(a['source_files_sha256'])|{Q+'/ExecPlan.md',Q+'/evidence/managed-verification-native.v1.json',Q+'/evidence/managed-verification-native-custody.v1.zip'}
 names=sorted(set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines()))
 assert set(names)==allowed,(set(names)-allowed,allowed-set(names))
 msg=E/'managed-verify-02-commit-message-08.txt';assert not msg.exists()
 message='feat(setup): verify registered managed installations without mutation\n\nWork-Item: FACMAN-0.1-ALPHA6-MANAGED-INSTALL-RECONCILIATION-01\nEvidence-Ref: '+Q+'/evidence/managed-verification-native.v1.json\n'
 msg.write_text(message,encoding='utf-8')
 changed=[dict(path=n,state='content',sha256=sha(R/n),git_blob_oid=git('hash-object','--path',n,n),ownership='task_owned') for n in names]
 canonical=json.dumps(changed,indent=2,sort_keys=True,separators=(',',': '))+'\n'
 snapshot=hashlib.sha256(canonical.encode()).hexdigest()
 review=dict(schema_version='aide.git-commit-review.v1',verdict='PASS',reviewer='/root',runtime_author='/root/managed_verify_impl',non_authoring_runtime=True,
  branch=a['branch'],base_commit=target,snapshot_sha256=snapshot,message_sha256=sha(msg),
  exact_runtime_review_sha256=sha(E/'managed-verify-02-source-assurance-05.json'),native_qualification_sha256=sha(E/'managed-verify-02-qualification-result-08.json'),
  persistence_review_sha256=sha(E/'managed-verify-02-persistence-review-08.json'))
 review_path=E/'managed-verify-02-commit-review-08.json';review_path.write_text(json.dumps(review,indent=2)+'\n')
 classification=dict(schema_version='aide.git-commit-classification.v1',branch=a['branch'],base_commit=target,work_item='FACMAN-0.1-ALPHA6-MANAGED-INSTALL-RECONCILIATION-01',snapshot_sha256=snapshot,message_sha256=sha(msg),changed_paths=changed,reviews=[dict(path=str(review_path),sha256=sha(review_path),verdict='PASS')])
 classification_path=E/'managed-verify-02-commit-classification-08.json';classification_path.write_text(json.dumps(classification,indent=2)+'\n')
 run('message-check',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--message',message])
 run('diff-check',['git','diff','--check'])
 before=run('plan-before',['py','-3','-B','.aide/scripts/aide_lite.py','git','commit-plan','--classification',classification_path,'--message-file',msg]);assert 'ready_to_stage' in before
 run('stage',['git','add','--',*names])
 after=run('plan-after',['py','-3','-B','.aide/scripts/aide_lite.py','git','commit-plan','--classification',classification_path,'--message-file',msg]);assert 'ready_to_commit' in after
 run('commit',['git','commit','-F',msg],180)
 source=git('rev-parse','HEAD');assert not git('status','--porcelain')
 result.update(status='COMMITTED_QUALIFIED_TASK',source=source,tree=git('rev-parse','HEAD^{tree}'),base=target,changed_paths=len(names));save()
 run('range',['py','-3','-B','.aide/scripts/aide_lite.py','commit','check','--range',target+'..'+source])
 run('push',['git','push','--set-upstream','origin',a['branch']],180)
 body=E/'managed-verify-02-pr-body-08.md'
 body.write_text('Registered Universal Setup installations can now be verified read-only through the existing explicit acceptance configuration. Ordinary CLI output shows pass/warn/fail, missing or changed owned paths, and preserved unknown data; JSON and stdio RPC return the same typed provider report. The unconfigured live-target gate remains closed.\n\nFacMan binds the retained record, provider state and ownership manifest to report coverage, hashes, counts and digest, and refuses ambiguous record/provider/link states. Verification changes no installation, workspace or provider data. It is an observation rather than an atomic target snapshot.\n\nValidation: 27 actual CLI calls (eight human-format), declared v2 RPC, native decoder smoke, strict repository checks and AIDE Lite. Exact source/images, independent review, preserved failures and execution receipts are in '+Q+'/evidence/managed-verification-native.v1.json and its compact custody archive.\n\nAuthority delta: none. This accepts synthetic source-native behavior only; produced packages, genuine host/game/human observations and full F11/Beta acceptance remain open.\n',encoding='utf-8')
 url=run('create-pr',['gh','pr','create','--repo','Julesc013/factorio-launcher','--base','dev','--head',a['branch'],'--title','feat(setup): verify registered managed installations without mutation','--body-file',body],180).strip()
 result.update(status='PUSHED_QUALIFIED_TASK_PR_OPEN',pr_url=url,merge_method='merge',required_checks_preserved=True);save()
except BaseException as exc:result.update(status='ACTIONABLE_COMMIT_OR_SUBMISSION_FAILURE',error=str(exc),traceback=traceback.format_exc());save()
print(json.dumps({k:v for k,v in result.items() if k!='commands'},indent=2))
