
import hashlib,json,os,subprocess,sys,time,traceback
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher')
W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e')
E=W/'evidence';B=W/'native-developer'
sys.dont_write_bytecode=True;sys.path.insert(0,str(R))
from tools import provider_canary_process as owned,native_build
p=json.loads((E/'managed-verify-02-source-review.json').read_bytes())
a=json.loads((E/'managed-verify-02-source-assurance-01.json').read_bytes())
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
assert a['independent'] and a['non_authoring'] and a['verdict']=='PASS_FOR_SCOPED_NATIVE_QUALIFICATION'
assert a['packet_sha256']==sha(E/'managed-verify-02-source-review.json')
def source_bound():
    assert subprocess.check_output(['git','branch','--show-current'],cwd=R,text=True).strip()==p['branch']
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==p['base']
    for name,digest in p['source_files_sha256'].items():assert sha(R/name)==digest,(name,'source review invalidated')
source_bound()
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),
    PYTHONDONTWRITEBYTECODE='1',CMAKE_BUILD_PARALLEL_LEVEL='2',FACMAN_MIN_FREE_GIB='12')
result_path=E/'managed-verify-02-qualification-result-01.json'
result=dict(schema='facman.managed_verify_native_qualification.v1',status='waiting_for_parallel_heavy_job',
    source_packet_sha256=sha(E/'managed-verify-02-source-review.json'),source_assurance_sha256=sha(E/'managed-verify-02-source-assurance-01.json'),
    commands=[],new_roots=0,new_clones=0,new_worktrees=0,product_candidates=0,goal_status_mutated=False)
assert not result_path.exists()
def save():result_path.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
save()
# This script owns waiting. Foreign builds are observed, never terminated or relocated.
query="""$p=Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('cl.exe','clang.exe','link.exe','ninja.exe','ctest.exe') -or ($_.Name -eq 'cmake.exe' -and $_.CommandLine -like '*--build*') -or ($_.Name -eq 'MSBuild.exe' -and $_.CommandLine -notlike '*/nodemode:*') }; ConvertTo-Json -InputObject @($p | Select-Object ProcessId,Name,CreationDate) -Compress"""
last=None
for delay in [15,30,60,120,300]+[300]*285:
    rows=json.loads(subprocess.check_output(['powershell','-NoProfile','-NonInteractive','-Command',query],text=True,timeout=30))
    if not rows:break
    current=sorted((x['ProcessId'],x['Name'],x['CreationDate']) for x in rows)
    if current!=last:
        result['observed_parallel_job']=current;save();last=current
    time.sleep(delay)
else:raise RuntimeError('resource observation boundary reached; goal remains active and foreign execution preserved')
source_bound()
native_build.require_disk_reserve(B)
result['status']='qualifying_scoped_native_change';save()
budget=owned.Budget(7200,3600)
def run(name,argv,timeout=600,environment=None):
    out=owned.command([str(x) for x in argv],cwd=R,environment=dict(os.environ) if environment is None else environment,
        timeout=timeout,budget=budget,output_limit=8*1024*1024,
        directory=E/f'managed-verify-02-{name}-execution-01',wait_for_job_empty_after_primary=True)
    result['commands'].append(dict(name=name,argv=[str(x) for x in argv],exit=out.returncode,
        termination=out.receipt['termination'],primary_stopped=out.receipt['primary_stopped'],
        job_empty_observed=out.receipt['job_empty_observed'],receipt=str(out.directory/'receipt.json'),
        receipt_sha256=sha(out.directory/'receipt.json')))
    save()
    assert out.ok and out.receipt['primary_stopped'] and out.receipt['job_empty_observed'],name
    return out
try:
    run('build',a['build_command'],3600)
    source_bound()
    run('parser',['ctest','--test-dir',B,'-C','Release','-R','^flb_setup_gateway_smoke$','--output-on-failure'],300)
    exe=B/'Release/facman.exe'
    assert exe.is_file()
    result['executable_sha256']=sha(exe);save()
    env=dict(os.environ);env['FACMAN_CLI_EXE']=str(exe)
    run('public',['py','-3','-B','tests/integration/facman_managed_install_lifecycle.py','--facman',exe,
        '--root',W/'verify-02-public-proof','--scenario','verification'],600,env)
    run('strict',['py','-3','-B','tools/strict_check.py'],600,env)
    run('aide',['py','-3','-B','.aide/scripts/aide_lite.py','test'],600,env)
    source_bound()
    proof=json.loads((W/'verify-02-public-proof/receipt.json').read_bytes())
    assert proof['result']=='pass',proof['result']
    result.update(status='PASS_SCOPED_NATIVE_MANAGED_VERIFICATION',public_receipt_sha256=sha(W/'verify-02-public-proof/receipt.json'),
        public_commands=len(proof['steps']),classification='owned synthetic source-native engineering evidence',
        game_executed=False,human_qualified=False,other_host_qualified=False,produced_package_qualified=False,workunit_closed=False,beta_qualified=False)
except BaseException as exc:
    result.update(status='ACTIONABLE_FAILURE',error=str(exc),traceback=traceback.format_exc())
finally:
    save();print(json.dumps(result,indent=2))
