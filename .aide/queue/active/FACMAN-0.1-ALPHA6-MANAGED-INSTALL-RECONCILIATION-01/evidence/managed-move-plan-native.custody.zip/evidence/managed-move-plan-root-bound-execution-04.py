import datetime, hashlib, json, os, runpy, shutil, sys, traceback
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher')
W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e')
E=W/'evidence'
C=E/'managed-move-plan-qualification-controller-04.py'
P=E/'managed-move-plan-qualification-plan-04.json'
review=E/'managed-move-plan-independent-controller-review-04.json'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(C)=='2ac413229c04a90a96f3a55e2a83f015420546f2b7799538bd377500faebfc76'
assert sha(P)=='40a5cddf150c93142c2214ec0c5ccf0b46905ab0b00d78fb8e836a8790026218'
assert sha(review)=='96d785a3b2fbe76bf290d21ff16d6f03f8794ebf2b7c82fce10a73241ad5af34'
checks={
 Path(r'C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.51.36231\bin\Hostx64\x64\cl.exe'):'c94cdac6a780142920110e5cb8b7339817029eead696e0e97700b45e03216a00',
 Path(r'C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.51.36231\bin\Hostx64\x64\link.exe'):'f233b8e337cec96a69868a8cde676808bfa81152493968d0b27b7cd0daac15be',
 W/'native-developer/CMakeFiles/4.2.3/CMakeCXXCompiler.cmake':'2dc7a71db06c49afbd599fc1dc81fd0c0b5e2f49539542d9103ccbada8062bc4'}
plan=json.loads(P.read_bytes())
for command,key in [('cmake','CMAKE_COMMAND'),('ctest','CMAKE_CTEST_COMMAND')]:
 path=Path(shutil.which(command)).resolve()
 assert str(path).casefold()==str(Path(plan['cache_configuration'][key]).resolve()).casefold(),command+' resolution drift'
 checks[path]=sha(path)
def tools_snapshot():
 rows=[]
 for path,digest in checks.items():
  actual=sha(path)
  if actual!=digest:raise RuntimeError('Exact compiler/tool boundary drift: '+str(path))
  rows.append(dict(path=str(path),sha256=actual,bytes=path.stat().st_size))
 for key in os.environ:
  if key.upper() in ('VSTEL_EWDK','CL','_CL_'):raise RuntimeError('Unexpected inherited compiler environment option: '+key)
 return rows
out=E/'managed-move-plan-root-bound-execution-04.json'
record=dict(schema='facman.root_bound_source_execution.v1',utc_started=datetime.datetime.now(datetime.timezone.utc).isoformat(),state='RUNNING_OUTCOME_UNKNOWN_IF_INTERRUPTED',controller_sha256=sha(C),plan_sha256=sha(P),independent_review_sha256=sha(review),root_wrapper_sha256=sha(Path(__file__)),scope='source03 behavior only; compiler primary success with scoped owned cleanup; natural compiler lifetime not qualified',native_build_lifetime_pass=False)
record['tool_preimage']=tools_snapshot()
with out.open('x',encoding='utf-8') as f:json.dump(record,f,indent=2)
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),TMPDIR=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1')
sys.dont_write_bytecode=True
exit_code=1
try:
 sys.argv=[str(C),'--plan-sha256',sha(P)]
 try:runpy.run_path(str(C),run_name='__main__')
 except SystemExit as ex:exit_code=int(ex.code or 0)
 record['tool_postimage']=tools_snapshot()
 assert record['tool_preimage']==record['tool_postimage']
 assert sha(C)==record['controller_sha256'] and sha(P)==record['plan_sha256']
 result=json.loads((E/'managed-move-plan-qualification-04/result.json').read_bytes())
 record['result_sha256']=sha(E/'managed-move-plan-qualification-04/result.json')
 record['controller_state']=result['state']
 record['state']='SOURCE_BEHAVIOR_PASS_WITH_COMPILER_OWNED_CLEANUP' if exit_code==0 and result['state']=='SOURCE_BEHAVIOR_PASS_WITH_COMPILER_OWNED_CLEANUP' else 'FAIL_RETAINED'
except BaseException as exc:
 record.update(state='FAIL_RETAINED',error=str(exc),traceback=traceback.format_exc());exit_code=1
record.update(utc_finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),controller_exit_code=exit_code)
out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:record.get(k) for k in ('state','controller_exit_code','controller_state','native_build_lifetime_pass','error')}))
raise SystemExit(0 if record['state']=='SOURCE_BEHAVIOR_PASS_WITH_COMPILER_OWNED_CLEANUP' else 1)
