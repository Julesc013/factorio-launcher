import hashlib,json,os,sys
from pathlib import Path
R=Path(r"D:\Projects\Factorio\factorio-launcher")
E=Path(__file__).resolve().parent
W=E.parent
sys.path.insert(0,str(R))
from tools import provider_canary_process as owned
env={k:v for k,v in os.environ.items() if not k.upper().startswith(("FACMAN_TEST","FACMAN_SETUP"))}
env.update(FACMAN_DEV_ROOT="D:/Projects/Factorio/.task-builds",FACMAN_TASK_ROOT=str(W),TEMP=str(W/"t"),TMP=str(W/"t"),TMPDIR=str(W/"t"),PYTHONDONTWRITEBYTECODE="1",PYTHONPATH=os.pathsep.join((str(R),str(R/"tests"))),GIT_OPTIONAL_LOCKS="0",FLAUNCH_UNIVERSAL_LAUNCHER_ROOT=str(W/"providers/universal-launcher-5479939ca5cb"),FLAUNCH_UNIVERSAL_SETUP_ROOT="D:/Projects/Factorio/.task-builds/repositories/factorio-launcher-5db2844e2f29/tasks/task-facman-u-507ecf4b41/providers/universal-setup-2749a15b835a")
raw=E/"managed-move-plan-source03-static-01"
raw.mkdir()
checks=[]
commands=[("strict",[sys.executable,"tools/strict_check.py"],600),("affected-static",[sys.executable,"-m","unittest","tests.test_command_contracts","tests.test_setup_workflows","tests.test_engineering_quality"],120)]
for name,cmd,timeout in commands:
    r=owned.command(cmd,cwd=R,environment=env,timeout=timeout,directory=raw/name,output_limit=8*1024**2,wait_for_job_empty_after_primary=True)
    c=r.receipt
    normal=r.returncode==0 and c["termination"]=="completed" and c["primary_stopped"] and c["job_empty_observed"] and not c["job_terminated"]
    checks.append(dict(name=name,command=cmd,normal_pass=normal,receipt=str(r.directory/"receipt.json"),receipt_sha256=hashlib.sha256((r.directory/"receipt.json").read_bytes()).hexdigest()))
    (raw/"result.json").write_text(json.dumps(dict(schema="facman.source03_static_validation.v1",checks=checks,result="PASS" if normal else "FAIL",native_or_product_execution=False),indent=2)+"\n")
    print(name,"PASS" if normal else "FAIL",flush=True)
    if not normal:
        print(r.stderr.decode("utf-8",errors="replace"),flush=True)
        raise SystemExit(1)
