"""Root-executable one-shot source qualification; no work runs on import.

Run only with the exact resource-plan SHA printed by preparation. Resource waits
retain first/latest observations indefinitely and never modify foreign actors.
"""
from __future__ import annotations
import argparse
import datetime
import hashlib
import json
import os
import re
from pathlib import Path
import shutil
import subprocess
import sys
import time

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
W = E.parent
B = W / 'native-developer'
PLAN = E / 'managed-move-plan-qualification-plan-02.json'
RAW = E / 'managed-move-plan-qualification-01'
GiB = 1024**3


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write(path, document, limit=8*1024**2):
    raw = (json.dumps(document, indent=2, sort_keys=True) + '\n').encode()
    if len(raw) > limit:
        raise ValueError('bounded receipt exceeded: ' + str(path))
    Path(path).write_bytes(raw)


def child_environment(plan):
    env = {key: value for key, value in os.environ.items()
           if not key.upper().startswith(('FACMAN_TEST', 'FACMAN_SETUP'))}
    env.update(plan['process_environment'])
    env['PYTHONPATH'] = os.pathsep.join((str(R), str(R/'tests')))
    env['GIT_OPTIONAL_LOCKS'] = '0'
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    return env


def capture(command, env, cwd=R, timeout=45):
    result = subprocess.run(command, cwd=cwd, env=env, capture_output=True,
                            timeout=timeout, text=True, encoding='utf-8', errors='strict')
    if len(result.stdout.encode()) + len(result.stderr.encode()) > 16*1024**2:
        raise ValueError('bounded read-only observation exceeded')
    if result.returncode:
        raise RuntimeError('read-only observation failed: ' + repr(command) + ': ' + result.stderr[:2048])
    return result.stdout.strip()


def git(env, *args, cwd=R):
    return capture(['git', '-c', 'core.longpaths=true', '-c', 'core.safecrlf=false', *args], env, cwd)


def cache_configuration(plan):
    result = {}
    for line in (B/'CMakeCache.txt').read_text(encoding='utf-8').splitlines():
        if not line or line.startswith(('#', '//')) or '=' not in line or ':' not in line.split('=', 1)[0]:
            continue
        key, value = line.split('=', 1)
        name = key.split(':', 1)[0]
        result[name] = value
    if result != plan['cache_configuration']:
        raise ValueError('existing native cache configuration drift: ' + repr(result))
    return {'sha256': sha(B/'CMakeCache.txt'), 'semantic_configuration': result}


def guard(plan, env):
    if git(env, 'branch', '--show-current') != plan['branch']:
        raise ValueError('task branch changed')
    if git(env, 'rev-parse', 'HEAD') != plan['base_head'] or git(env, 'rev-parse', 'HEAD^{tree}') != plan['head_tree']:
        raise ValueError('base HEAD/tree changed')
    dirty = set(filter(None, git(env, 'diff', '--name-only', '-z', 'HEAD').split('\0')))
    dirty.update(filter(None, git(env, 'ls-files', '--others', '--exclude-standard', '-z').split('\0')))
    expected = {row['path'] for row in plan['reviewed_paths']}
    if dirty != expected or len(expected) != 42:
        raise ValueError('reviewed dirty source set changed')
    for row in plan['reviewed_paths']:
        if sha(R/row['path']) != row['sha256']:
            raise ValueError('reviewed source hash changed: ' + row['path'])
    if sha(W/'.facman-development-root.v1.json') != plan['task_marker_sha256']:
        raise ValueError('task ownership marker changed')
    for relative, digest in plan['tool_inputs'].items():
        if sha(R/relative) != digest:
            raise ValueError('qualification tool changed: ' + relative)
    for relative, digest in plan['evidence_inputs'].items():
        if sha(E/relative) != digest:
            raise ValueError('retained evidence changed: ' + relative)
    for relative, digest in plan['prepared_scripts'].items():
        if sha(E/relative) != digest:
            raise ValueError('prepared script changed: ' + relative)
    providers = {}
    for name, item in plan['providers'].items():
        root = Path(item['root'])
        head = git(env, 'rev-parse', 'HEAD', cwd=root)
        status = git(env, 'status', '--porcelain=v1', '--untracked-files=all', cwd=root)
        if head != item['head'] or status != item['status']:
            raise ValueError('pinned provider HEAD/status drift: ' + name)
        providers[name] = {'root': str(root), 'head': head, 'status': status}
    return {'utc': utc(), 'providers': providers, 'cache': cache_configuration(plan)}


def source_cohort(env):
    tracked = git(env, 'ls-files', '-z').split('\0')
    others = git(env, 'ls-files', '--others', '--exclude-standard', '-z').split('\0')
    rows = []
    for name in sorted(set(filter(None, tracked + others))):
        path = R/name
        if path.is_symlink() or not path.is_file():
            raise ValueError('source cohort member missing or redirected: ' + name)
        rows.append({'path': name, 'bytes': path.stat().st_size, 'sha256': sha(path)})
    return rows


def directory_bytes(path):
    total = 0
    pending = [Path(path)]
    while pending:
        directory = pending.pop()
        for item in directory.iterdir():
            stat = item.lstat()
            if item.is_symlink() or getattr(stat, 'st_file_attributes', 0) & 0x400:
                continue  # Never traverse a redirect; fixture oracle checks its identity separately.
            if item.is_dir():
                pending.append(item)
            elif item.is_file():
                total += stat.st_size
    return total


def fresh_storage(plan, roots=None, additional=None):
    selected = roots if roots is not None else plan['known_task_roots']
    tasks = W.parent
    actual = {str(p.resolve()).casefold() for p in tasks.iterdir() if p.is_dir()}
    expected = {str(Path(p).resolve()).casefold() for p in selected}
    if actual != expected or len(actual) > 8:
        raise ValueError('task root topology changed; no cleanup authorized')
    total = 0
    for root in selected:
        path = Path(root)
        if path.is_symlink() or path.stat().st_file_attributes & 0x400:
            raise ValueError('task root is redirected')
        marker = json.loads((path/'.facman-development-root.v1.json').read_bytes())
        if marker['schema'] != 'facman.development_root.v1' or marker['owner'] != 'facman-development':
            raise ValueError('task root ownership invalid')
        total += directory_bytes(path)
    free = shutil.disk_usage(W).free
    extra = plan['limits']['new_total_bytes'] if additional is None else additional
    if total + extra >= plan['limits']['task_root_bytes'] or free - extra <= 12*GiB:
        raise ValueError('fresh root-byte/reserve admission failed')
    return {'utc': utc(), 'task_roots': len(selected), 'measured_root_bytes': total,
            'additional_peak_bytes': extra, 'projected_root_bytes': total+extra,
            'free_bytes': free, 'free_after_peak_bytes': free-extra}


LINUX = """import json,os
active=[]
for n in os.listdir('/proc'):
 if n.isdigit():
  try:
   comm=open('/proc/'+n+'/comm').read().strip()
   if comm in {'facman','factorio','cmake','ninja','make','cc1plus','ctest','g++','c++','clang','clang++','gcc','cc','ld','ld.lld','as'} or comm.startswith(('flb_','facman_','m1_three_repos')):
    active.append(dict(pid=int(n),command=open('/proc/'+n+'/cmdline','rb').read().decode(errors='replace').replace(chr(0),' ')))
  except FileNotFoundError:pass
print(json.dumps(dict(mount_namespace=os.readlink('/proc/self/ns/mnt'),active=active)))"""


def wait_for_resources(plan, env, phase, extra):
    output = RAW/('resources-' + phase + '.json')
    first, count = None, 0
    with output.open('x+b') as retained:
        while True:
            sample = json.loads(capture(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command',
                (E/'managed-move-plan-resource-probe-01.ps1').read_text(encoding='utf-8')], env))
            if sample['Identity'].casefold() != r'BLACKGLASS-WIN1\Jules'.casefold():
                raise ValueError('resource observation under unexpected Windows identity')
            if type(sample['ProbePID']) is not int or not sample['ProbeCreationUtc']:
                raise ValueError('resource probe has no exact self identity')
            def own(row, key):
                return row[key] == sample['ProbePID'] and row.get('CreationUtc') == sample['ProbeCreationUtc']
            sample['OwnExactProbeCPU'] = [r for r in sample['HeavyCPU'] if own(r, 'PID')]
            sample['OwnExactProbeIO'] = [r for r in sample['HeavyIO'] if own(r, 'IDProcess')]
            if any(r['Name'].casefold() not in ('powershell', 'pwsh') for r in sample['OwnExactProbeCPU']):
                raise ValueError('CPU self-exclusion identity/name mismatch')
            if any(not r['Name'].casefold().startswith(('powershell', 'pwsh')) for r in sample['OwnExactProbeIO']):
                raise ValueError('IO self-exclusion identity/name mismatch')
            sample['HeavyCPU'] = [r for r in sample['HeavyCPU'] if not own(r, 'PID')]
            sample['HeavyIO'] = [r for r in sample['HeavyIO'] if not own(r, 'IDProcess')]
            sample['Linux'] = json.loads(capture(['wsl.exe', '-d', 'Ubuntu-24.04', '-u', 'root',
                '--exec', '/usr/bin/python3', '-B', '-c', LINUX], env))
            sample['quiet'] = (not sample['HeavyCPU'] and not sample['HeavyIO'] and
                not sample['Toolchains'] and not sample['Linux']['active'] and
                sample['AvailablePhysicalBytes'] >= 3*GiB and shutil.disk_usage(W).free-extra > 12*GiB)
            count += 1
            if first is None:
                first = sample
            encoded = (json.dumps({'schema': 'facman.live_resource_wait.v1', 'phase': phase,
                'sample_count': count, 'first_sample': first, 'latest_sample': sample,
                'intermediate_censuses_retained': False, 'product_dispatched_in_wait': False}, sort_keys=True)+'\n').encode()
            if len(encoded) > 16*1024**2:
                raise ValueError('resource first/latest storage budget exceeded')
            retained.seek(0); retained.write(encoded); retained.truncate(); retained.flush(); os.fsync(retained.fileno())
            if sample['quiet']:
                guard(plan, env)
                return fresh_storage(plan, additional=extra)
            delay = (60, 120, 300, 600)[min(count-1, 3)]
            for _ in range(delay//60):
                time.sleep(60)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan-sha256', required=True)
    args = parser.parse_args()
    if os.name != 'nt' or sha(PLAN) != args.plan_sha256:
        raise ValueError('Windows/exact resource plan hash required')
    plan = json.loads(PLAN.read_bytes())
    env = child_environment(plan)
    sys.path.insert(0, str(R))
    from tools import provider_canary_process as owned
    if not (W/'t').is_dir():
        raise ValueError('existing owned TEMP/TMP location absent')
    if RAW.exists() or Path(plan['public_fixture']).exists():
        raise ValueError('one-shot raw/public result location already exists; no cleanup/retry authorized')
    guard(plan, env)
    claim = E/'managed-move-plan-qualification-01.claim.json'
    with claim.open('x') as lock:
        json.dump({'pid': os.getpid(), 'utc': utc(), 'plan_sha256': args.plan_sha256}, lock)
    RAW.mkdir()
    result = {'schema': 'facman.managed_move_plan_qualification.v1', 'utc_started': utc(),
              'state': 'RUNNING', 'plan_sha256': args.plan_sha256, 'cohorts': [],
              'scope': 'dirty source checkout synthetic qualification only; no package/host/game/human release acceptance',
              'first_failure': None}
    phase = 'source-preimage'
    before = None
    baseline_storage = None

    def save():
        write(RAW/'result.json', result)

    def run_owned(name, command, timeout, cap=8*1024**2, codes=(0,)):
        nonlocal phase
        phase = name
        guard(plan, env)
        receipt = owned.command(command, cwd=R, environment=env, timeout=timeout,
            directory=RAW/name, output_limit=cap, wait_for_job_empty_after_primary=True)
        normal = (receipt.receipt['termination'] == 'completed' and receipt.returncode in codes and
                  receipt.receipt['primary_stopped'] and receipt.receipt['job_empty_observed'] and
                  not receipt.receipt['job_terminated'] and receipt.receipt['waited_for_job_empty_after_primary'] and
                  receipt.receipt['process_identity'] is not None)
        result['cohorts'].append({'phase': name, 'command': command, 'normal_primary_and_empty_job': normal,
            'exit_code': receipt.returncode, 'receipt': str(receipt.directory/'receipt.json'),
            'receipt_sha256': sha(receipt.directory/'receipt.json')})
        save()
        if not normal:
            raise RuntimeError('command/lifetime failure at ' + name + '; inspect retained raw receipt')
        guard(plan, env)
        return receipt

    try:
        before = source_cohort(env)
        write(RAW/'source-before.json', {'files': before}, 16*1024**2)
        result['source_before_sha256'] = sha(RAW/'source-before.json')
        result['provider_configuration_before'] = guard(plan, env)
        save()
        phase = 'resource-before-doctor'
        baseline_storage = wait_for_resources(plan, env, 'before-doctor', plan['limits']['new_total_bytes'])
        result['storage_before'] = baseline_storage
        run_owned('paths', [sys.executable, 'tools/workspace_hygiene.py', 'paths'], 60)
        doctor = run_owned('doctor', [sys.executable, 'tools/workspace_hygiene.py', 'doctor', '--measure',
            '--base', 'origin/dev', '--max-task-roots', '8', '--max-worktrees', '2',
            '--max-bytes', str(20*GiB)], 600, codes=(0, 1))
        report = json.loads(doctor.stdout)
        if set(report['violations']) - {'unmanaged_secondary_worktrees_present'}:
            raise ValueError('fresh doctor has non-advisory violations: ' + repr(report['violations']))
        secondary = [r for r in report['worktrees'] if not r['primary']]
        if [str(Path(r['path']).resolve()).casefold() for r in secondary] != [str(Path(plan['known_unmanaged_secondary']).resolve()).casefold()]:
            raise ValueError('doctor secondary-worktree topology changed')
        if any(not r['owned'] for r in report['task_roots']) or len(report['task_roots']) > 8:
            raise ValueError('doctor task-root ownership/count admission failed')
        if report['task_root_bytes'] + 3*GiB >= 20*GiB:
            raise ValueError('doctor measured roots plus conservative peak exceed quota')
        result['doctor_advisory_only'] = report['violations']
        phase = 'resource-before-build'
        result['build_admission'] = wait_for_resources(plan, env, 'before-build', 3*GiB)
        save()
        run_owned('build', plan['build_command'], 1200, 32*1024**2)
        exe = B/'Release/facman.exe'
        if not exe.is_file():
            raise ValueError('actual compiled CLI missing in existing B/Release')
        result['binary'] = {'path': str(exe), 'sha256': sha(exe), 'bytes': exe.stat().st_size}
        result['native_binary_cohort'] = []
        for name in ('facman.exe', 'flb_setup_gateway_smoke.exe', 'm1_three_repository_system_proof.exe'):
            path = B/'Release'/name
            if not path.is_file():
                raise ValueError('selected built executable missing: ' + str(path))
            result['native_binary_cohort'].append({'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)})
        phase = 'resource-before-native'
        result['native_admission'] = wait_for_resources(plan, env, 'before-native', 512*1024**2)
        identity = run_owned('binary-identity', [str(exe), '--workspace', str(W/'t'), 'product', 'inspect', '--json'], 30)
        observed = json.loads(identity.stdout)
        payload = observed['payload']
        backend = payload['backend_identity']
        build = backend['build']
        if (build['source_revision'] != plan['base_head'] or build['source_dirty'] is not True or
            build['universal_launcher_revision'] != plan['providers']['ULK']['head'] or
            build['universal_setup_revision'] != plan['providers']['USK']['head'] or
            backend['package']['mode'] != 'source_checkout'):
            raise ValueError('compiled dirty/base/provider/source-checkout identity mismatch')
        result['compiled_identity'] = backend
        native = run_owned('native-ctest', ['ctest', '--test-dir', str(B), '-C', 'Release', '--output-on-failure',
            '--timeout', '300', '--no-tests=error', '-j', '1', '-R', '^(flb_setup_gateway_smoke|m1_three_repository_system_proof)$'], 300)
        native_text = native.stdout.decode('utf-8', errors='strict')
        if not re.search(r'100% tests passed, 0 tests failed out of 2\b', native_text) or any(
                name not in native_text for name in ('flb_setup_gateway_smoke', 'm1_three_repository_system_proof')):
            raise ValueError('native CTest did not prove exactly both selected targets passed')
        phase = 'resource-before-public'
        result['public_admission'] = wait_for_resources(plan, env, 'before-public', 512*1024**2)
        if Path(plan['public_fixture']).exists():
            raise ValueError('planned public fixture exists before the sole dispatch')
        run_owned('public-move-preview', [sys.executable, 'tests/integration/facman_managed_install_lifecycle.py',
            '--facman', str(exe), '--root', plan['public_fixture'], '--scenario', 'move-preview'], 600)
        public_bytes = directory_bytes(plan['public_fixture'])
        if public_bytes > 256*1024**2:
            raise ValueError('public fixture retained storage exceeds 256MiB')
        public_receipt = json.loads((Path(plan['public_fixture'])/'receipt.json').read_bytes())
        if public_receipt['result'] != 'pass' or public_receipt['open_gaps']:
            raise ValueError('public owned-fixture receipt did not pass')
        result['public_fixture_bytes'] = public_bytes
        result['public_receipt_sha256'] = sha(Path(plan['public_fixture'])/'receipt.json')
        run_owned('cli-regressions', [sys.executable, '-m', 'unittest',
            'tests.test_cli.CliTests.test_managed_move_cli_requires_exact_destination_grammar_without_writes',
            'tests.test_cli.CliTests.test_managed_install_operations_are_setup_gated'], 300)
        phase = 'resource-before-static'
        result['static_admission'] = wait_for_resources(plan, env, 'before-static', 256*1024**2)
        run_owned('strict', [sys.executable, 'tools/strict_check.py'], 600)
        run_owned('aide', [sys.executable, '.aide/scripts/aide_lite.py', 'test'], 600)
        run_owned('generated-metadata', [sys.executable, 'tools/codegen/generate_metadata.py', '--check'], 120)
        run_owned('generated-census', [sys.executable, 'tools/technical_preview_census.py', '--check'], 120)
        run_owned('diff-check', ['git', '-c', 'core.safecrlf=false', 'diff', '--check'], 60)
        phase = 'final-source-provider-custody'
        after = source_cohort(env)
        write(RAW/'source-after.json', {'files': after}, 16*1024**2)
        result['source_after_sha256'] = sha(RAW/'source-after.json')
        if before != after:
            raise ValueError('full source byte cohort changed across qualification')
        result['provider_configuration_after'] = guard(plan, env)
        if any(sha(row['path']) != row['sha256'] for row in result['native_binary_cohort']):
            raise ValueError('compiled binary cohort changed after product test dispatch')
        end_storage = fresh_storage(plan, additional=0)
        if end_storage['measured_root_bytes']-baseline_storage['measured_root_bytes'] > 3*GiB:
            raise ValueError('qualification retained growth exceeds total 3GiB budget')
        result['storage_after'] = end_storage
        result['state'] = 'PASS'
    except BaseException as error:
        result['state'] = 'FAIL'
        result['first_failure'] = {'phase': phase, 'type': type(error).__name__, 'message': str(error)[:4096]}
        try:
            after = source_cohort(env)
            write(RAW/'source-after-failure.json', {'files': after}, 16*1024**2)
            result['failure_source_unchanged'] = before == after
            result['failure_source_after_sha256'] = sha(RAW/'source-after-failure.json')
            result['provider_configuration_after_failure'] = guard(plan, env)
        except BaseException as custody_error:
            result['failure_custody_error'] = str(custody_error)[:2048]
    result['utc_finished'] = utc()
    save()
    if result['state'] == 'PASS':
        print('PASS: managed move source/native/public synthetic qualification; ' + str(RAW/'result.json'))
        return 0
    print('FAIL: ' + result['first_failure']['phase'] + ': ' + result['first_failure']['message'] + '; ' + str(RAW/'result.json'))
    return 1


if __name__ == '__main__':
    try:
        exit_code = main()
    except BaseException as admission_error:
        failure = {'schema': 'facman.qualification_admission_failure.v1', 'utc': utc(),
                   'type': type(admission_error).__name__, 'message': str(admission_error)[:4096]}
        target = E/'managed-move-plan-qualification-admission-failure-01.json'
        try:
            with target.open('x') as retained:
                json.dump(failure, retained, indent=2)
        except FileExistsError:
            pass
        print('FAIL: controller-admission: ' + str(admission_error)[:4096])
        exit_code = 1
    raise SystemExit(exit_code)
