"""Apply only the exact reviewed F07 evidence proposal. No build/product/Git calls."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
PROPOSAL = E/'managed-move-plan-durable-proposal-01.json'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def safe(path, root):
    path = Path(path)
    if not path.resolve().is_relative_to(root.resolve()):
        raise ValueError('path escapes exact owner root')
    for item in (path, *path.parents):
        if item.exists() and (item.is_symlink() or getattr(item.lstat(), 'st_file_attributes', 0) & 0x400):
            raise ValueError('redirected proposal/source path')
        if item == root:
            break
    return path

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--proposal-sha256', required=True)
    args = parser.parse_args()
    if sha(PROPOSAL) != args.proposal_sha256:
        raise ValueError('exact reviewed proposal SHA required')
    plan = json.loads(PROPOSAL.read_bytes())
    if sha(__file__) != plan['apply_script_sha256']:
        raise ValueError('apply script changed')
    if (R/'.git/HEAD').read_text().strip() != 'ref: refs/heads/' + plan['source_branch']:
        raise ValueError('task branch changed')
    if (R/'.git/refs/heads'/plan['source_branch']).read_text().strip() != plan['source_base']:
        raise ValueError('task base changed')
    for name, digest in plan['external_inputs'].items():
        if sha(safe(E/name, E)) != digest:
            raise ValueError('reviewed proposal input changed: ' + name)
    frozen = json.loads((E/plan['frozen_source_cohort']).read_bytes())['files']
    for row in frozen:
        path = safe(R/row['path'], R)
        if path.stat().st_size != row['bytes'] or sha(path) != row['sha256']:
            raise ValueError('frozen full source preimage changed: ' + row['path'])
    for row in plan['frozen_source_files']:
        if sha(R/row['path']) != row['sha256']:
            raise ValueError('frozen47 preimage changed: ' + row['path'])
    append = (E/plan['append_file']).read_bytes()
    target = safe(R/plan['execplan_path'], R)
    postimage = target.read_bytes() + append
    if hashlib.sha256(postimage).hexdigest() != plan['execplan_postimage_sha256']:
        raise ValueError('exact ExecPlan postimage mismatch')
    for row in plan['new_evidence']:
        if safe(R/row['target'], R).exists():
            raise ValueError('durable evidence already exists; no overwrite/retry')
    archive = E/plan['archive_file']
    with zipfile.ZipFile(archive) as pack:
        manifest = json.loads(pack.read('custody-manifest.v1.json'))['files']
        if pack.testzip() is not None or len(pack.namelist()) != len(manifest)+1:
            raise ValueError('custody membership/CRC mismatch')
        for name, row in manifest.items():
            data = pack.read(name)
            if len(data) != row['bytes'] or hashlib.sha256(data).hexdigest() != row['sha256']:
                raise ValueError('custody member hash mismatch: ' + name)
    for row in plan['new_evidence']:
        with (R/row['target']).open('xb') as output:
            output.write((E/row['source']).read_bytes())
    target.write_bytes(postimage)
    for row in plan['expected_final49']:
        if sha(R/row['path']) != row['sha256']:
            raise ValueError('durable postimage mismatch: ' + row['path'])
    for row in frozen:
        if row['path'] != plan['execplan_path'] and sha(R/row['path']) != row['sha256']:
            raise ValueError('unrelated source byte changed: ' + row['path'])
    result = {'schema': 'facman.managed_move_durable_apply.v1',
        'result': 'EXACT_REVIEWED_EVIDENCE_AND_EXECPLAN_APPLIED',
        'proposal_sha256': args.proposal_sha256, 'final_changed_files': 49,
        'runtime_source_unchanged': True, 'git_or_product_execution': False,
        'scope_or_release_gate_promoted': False}
    receipt = E/'managed-move-plan-durable-apply-result-01.json'
    with receipt.open('x', encoding='utf-8') as output:
        json.dump(result, output, indent=2); output.write('\n')
    print('APPLIED: exact49 reviewed source/evidence paths; no Git/build/product or gate change')

if __name__ == '__main__':
    main()
