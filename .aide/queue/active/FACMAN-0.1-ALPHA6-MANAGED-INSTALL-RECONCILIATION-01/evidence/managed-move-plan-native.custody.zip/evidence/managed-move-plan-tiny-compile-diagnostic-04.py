"""Experimental unpublished VSTEL_EWDK tiny A/B; no support guarantee; preserves diagnostic03. Run only after review."""
import ctypes as C
from ctypes import wintypes as W
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import struct

REPO = Path(r"D:\Projects\Factorio\factorio-launcher")
TASK = Path(r"D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e")
E = TASK / "evidence"
BUILD = TASK / "native-developer"
PATH_INVENTORY = E / "managed-move-plan-author-packet-02.json"  # Path inventory only; old source hashes are not admission requirements.
OUT = E / "managed-move-plan-lifetime-tiny-compile-04"
TINY = TASK / "t" / "j3" / "md04"
BASE_INPUT = TASK / "t" / "j3" / "md03" / "job_probe.cpp"
BASE_OBJECT = TASK / "t" / "j3" / "md03" / "job_probe.obj"
META = BUILD / "CMakeFiles/4.2.3/CMakeCXXCompiler.cmake"
COMPILER = Path("C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/cl.exe")
INPUT = TINY / "job_probe.cpp"
OBJECT = TINY / "job_probe.obj"
INPUT_BYTES = b"int facman_job_probe() { return 7; }\n"
COMMAND = [str(COMPILER), "/nologo", "/c", "/TP", "/O2", "/Fo" + str(OBJECT), str(INPUT)]
EXPECTED = {"tools/provider_canary_process_windows.py": "f85cde780237ac5189bd6b7a10d2fb6a176f4bc649ce2e78e6d34d762ddaaace", "tools/provider_canary_process.py": "d22980556e480ab055f2958199c4194cbf9b3d843916dabb7c3d6af25e47523c"}
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def runner_closed():
    for name, expected in EXPECTED.items():
        assert sha(REPO / name) == expected, name

def source_snapshot():
    assert sha(PATH_INVENTORY) == "9113ff3b763d210d21c3965c5632d7eb21ec505c9fc071221033606d9a21b5b3"
    rows = []
    for item in json.loads(PATH_INVENTORY.read_text())["changed_paths"]:
        row = {"path": item["path"]}
        try:
            raw = (REPO / item["path"]).read_bytes()
            row.update(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
        except OSError as error:
            row["observation_error"] = str(error)[:1024]
        rows.append(row)
    return {"scope": "Current observations of the42 prior affected paths; not full source qualification or an atomic snapshot", "files": rows}

def coff_sections(path):
    raw = path.read_bytes()
    assert 20 <= len(raw) <= 65536
    machine, count, stamp, symbols, symbol_count, optional, flags = struct.unpack_from("<HHIIIHH", raw)
    assert machine == 0x8664 and optional == 0 and 0 < count <= 16 and 20 + count*40 <= len(raw)
    rows = []
    for index in range(count):
        offset = 20 + index*40
        name = raw[offset:offset+8].split(b"\0")[0].decode("ascii")
        virtual, address, size, position, reloc, lines, reloc_count, line_count, characteristics = struct.unpack_from("<IIIIIIHHI", raw, offset+8)
        assert position <= len(raw) and size <= len(raw)-position
        rows.append({"name": name, "bytes": size, "flags": characteristics, "relocations": reloc_count, "sha256": hashlib.sha256(raw[position:position+size]).hexdigest()})
    return rows


def main():
    if sys.argv[1:] != ["--execute"]:
        print(json.dumps({"status": "prepared_only", "command": COMMAND, "seconds": 20, "cleanup_seconds": 5, "execute": "explicit --execute required"}))
        return 2
    assert os.name == "nt" and not OUT.exists()
    sys.path.insert(0, str(REPO))
    from tools import development_layout, provider_canary_process as runner
    from tools import provider_canary_process_windows as windows
    development_layout.read_marker(TASK, REPO)
    runner_closed()
    cache_before = sha(BUILD / "CMakeCache.txt")
    cache = (BUILD / "CMakeCache.txt").read_text()
    assert "CMAKE_HOME_DIRECTORY:INTERNAL=D:/Projects/Factorio/factorio-launcher" in cache
    assert "CMAKE_GENERATOR:INTERNAL=Visual Studio 18 2026" in cache
    assert sha(META) == "2dc7a71db06c49afbd599fc1dc81fd0c0b5e2f49539542d9103ccbada8062bc4"
    assert 'set(CMAKE_CXX_COMPILER "C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/cl.exe")' in META.read_text()
    assert sha(COMPILER) == "c94cdac6a780142920110e5cb8b7339817029eead696e0e97700b45e03216a00"
    assert BASE_INPUT.read_bytes() == INPUT_BYTES
    assert sha(BASE_OBJECT) == "c14368c67a2ad21fc68d9e635f403ab67964fa9fb081cb1d7ec99e65ccfcf926"
    baseline_sections = coff_sections(BASE_OBJECT)
    assert not os.path.lexists(TINY)
    for candidate_path in (TASK / "t", TINY):
        assert candidate_path.resolve(strict=False).is_relative_to(TASK.resolve())
        cursor = candidate_path
        while cursor != TASK:
            if os.path.lexists(cursor):
                status = cursor.lstat()
                assert not cursor.is_symlink() and not (getattr(status, "st_file_attributes", 0) & 0x400)
            cursor = cursor.parent
    if not (TASK / "t").exists():
        (TASK / "t").mkdir()
    TINY.mkdir()
    with INPUT.open("xb") as stream:
        stream.write(INPUT_BYTES)
    assert INPUT.read_bytes() == INPUT_BYTES and not OBJECT.exists()
    environment = dict(os.environ)
    for key in list(environment):
        if key.upper() in {"CL", "_CL_"}:
            environment.pop(key)  # Same compiler-option-injection prevention as tiny03.
    environment.update(TMP=str(TINY), TEMP=str(TINY))
    for key in list(environment):
        if key.upper() == "VSTEL_EWDK":
            environment.pop(key)
    environment["VSTEL_EWDK"] = "1"  # Experimental unpublished pinned-binary hypothesis, not a documented control.
    old_kernel = windows.kernel
    events, errors, retained, known = [], [], {}, {}
    owner = {"job_handle": None, "primary_pid": None, "primary_creation_ticks": None, "observer_pid": os.getpid()}
    started, last = time.monotonic(), [-10.0]
    class IdList(C.Structure):
        _fields_ = [("assigned", W.DWORD), ("count", W.DWORD), ("pids", C.c_size_t * 16)]
    def handle_number(handle):
        return int(handle.value if hasattr(handle, "value") else handle)
    class ObserverApi:
        def __init__(self, api):
            self.api = api
            for name, args, result in [
                ("OpenProcess", [W.DWORD, W.BOOL, W.DWORD], W.HANDLE),
                ("IsProcessInJob", [W.HANDLE, W.HANDLE, C.POINTER(W.BOOL)], W.BOOL),
                ("GetProcessId", [W.HANDLE], W.DWORD),
                ("QueryFullProcessImageNameW", [W.HANDLE, W.DWORD, W.LPWSTR, C.POINTER(W.DWORD)], W.BOOL)]:
                fn = getattr(api, name); fn.argtypes, fn.restype = args, result
        def __getattr__(self, name):
            return getattr(self.api, name)
        def ticks(self, handle):
            values = [C.c_uint64() for _ in range(4)]
            windows.require(self.api.GetProcessTimes(handle, *(C.byref(x) for x in values)), "GetProcessTimes observer")
            return values[0].value
        def AssignProcessToJobObject(self, job, process):
            result = self.api.AssignProcessToJobObject(job, process)
            saved = C.get_last_error()
            try:
                if result:
                    owner.update(job_handle=handle_number(job), primary_pid=int(self.api.GetProcessId(process)), primary_creation_ticks=self.ticks(process))
                    assert owner["primary_pid"], "primary PID unavailable"
                    self.observe(job, "assigned_suspended_primary")
            except Exception as error:
                errors.append("assign observation: " + str(error)[:1024])
            finally:
                C.set_last_error(saved)
            return result
        def snapshot(self, job, phase):
            if handle_number(job) != owner["job_handle"] or len(events) >= 8:
                return
            if phase != "immediately_before_exact_job_termination" and len(events) >= 7:
                return  # Reserve one bounded event for original forced-cleanup observation.
            values = IdList()
            windows.require(self.api.QueryInformationJobObject(job, 3, C.byref(values), C.sizeof(values), None), "exact-job PID list")
            assert values.count <= values.assigned <= 16, "owned job exceeds bounded 16-member observation"
            event = {"phase": phase, "seconds": round(time.monotonic()-started, 6), "job_handle": owner["job_handle"], "assigned": values.assigned, "listed": values.count, "members": [], "snapshot_complete": False}
            events.append(event)  # Preserve partial evidence even if a later member races exit.
            for index in range(values.count):
                pid = int(values.pids[index])
                row = {"pid": pid, "role": "primary" if pid == owner["primary_pid"] else "descendant", "identity_complete": False}
                event["members"].append(row)
                process = self.api.OpenProcess(0x1000 | 0x100000, False, pid)  # Query+sync only; never termination rights.
                if not process:
                    row.update(observation="exited_or_query_unavailable", windows_error=C.get_last_error())
                    continue
                keep = False
                try:
                    row["stopped"] = self.api.WaitForSingleObject(process, 0) == 0
                    member = W.BOOL()
                    windows.require(self.api.IsProcessInJob(process, job, C.byref(member)), "IsProcessInJob observer")
                    if not member.value:
                        row["observation"] = "no_longer_in_exact_job"
                        continue
                    row["exact_job_membership"] = True
                    assert self.api.GetProcessId(process) == pid, "opened identity differs from exact-job PID list"
                    creation = self.ticks(process)
                    row["creation_ticks"] = creation
                    if pid == owner["primary_pid"]:
                        assert creation == owner["primary_creation_ticks"], "primary identity changed"
                    key = (pid, creation)
                    if key not in retained:
                        retained[key] = process
                        keep = True
                    if key in known:
                        row.update(image=known[key], identity_complete=True, image_observation="retained_identity_from_prior_exact_job_observation")
                    else:
                        name, length = C.create_unicode_buffer(4096), W.DWORD(4096)
                        windows.require(self.api.QueryFullProcessImageNameW(process, 0, name, C.byref(length)), "QueryFullProcessImageNameW observer")
                        row.update(image=name.value, identity_complete=True, image_observation="queried_exact_member")
                        known[key] = name.value
                except Exception as error:
                    row.update(observation="exited_before_full_identity" if self.api.WaitForSingleObject(process, 0) == 0 else "member_identity_query_unavailable", error=str(error)[:1024])
                finally:
                    if not keep:
                        self.api.CloseHandle(process)
            event["snapshot_complete"] = True
        def observe(self, job, phase):
            saved = C.get_last_error()
            try:
                self.snapshot(job, phase)
            except Exception as error:
                errors.append(phase + ": " + str(error)[:1024])
            finally:
                C.set_last_error(saved)
        def QueryInformationJobObject(self, job, kind, data, size, returned):
            result = self.api.QueryInformationJobObject(job, kind, data, size, returned)
            if result and kind == 1 and time.monotonic()-last[0] >= 2:
                last[0] = time.monotonic(); self.observe(job, "primary_exit_or_cleanup_accounting")
            return result
        def TerminateJobObject(self, job, code):
            self.observe(job, "immediately_before_exact_job_termination")
            return self.api.TerminateJobObject(job, code)
    observed = ObserverApi(old_kernel())
    windows.kernel = lambda: observed
    try:
        source_before = source_snapshot()
        cache_before = sha(BUILD / "CMakeCache.txt")
        result = runner.command(COMMAND, cwd=TINY, environment=environment, timeout=20, directory=OUT, output_limit=1024*1024, wait_for_job_empty_after_primary=True)
        cache_after = sha(BUILD / "CMakeCache.txt")
        source_after = source_snapshot()
    finally:
        windows.kernel = old_kernel
        for process in retained.values():
            observed.api.CloseHandle(process)
    tools_unchanged = True
    try:
        runner_closed()
        assert sha(COMPILER) == "c94cdac6a780142920110e5cb8b7339817029eead696e0e97700b45e03216a00"
        assert sha(META) == "2dc7a71db06c49afbd599fc1dc81fd0c0b5e2f49539542d9103ccbada8062bc4"
    except Exception as error:
        tools_unchanged = False; errors.append("tool postimage: " + str(error)[:1024])
    source_equal = source_before == source_after
    cache_equal = cache_before == cache_after
    natural_pass = bool(result.ok and result.receipt["job_empty_observed"] and not result.receipt["job_terminated"])
    primary_bound = any(event["phase"] == "assigned_suspended_primary" and any(row["role"] == "primary" and row.get("identity_complete") and row.get("exact_job_membership") for row in event["members"]) for event in events)
    gaps = [row for event in events for row in event["members"] if not row.get("identity_complete")]
    observation_pass = bool(primary_bound and not errors and all(event["snapshot_complete"] for event in events))
    object_evidence = {"exists": OBJECT.is_file()}
    if OBJECT.is_file() and not OBJECT.is_symlink() and OBJECT.resolve().is_relative_to(TINY.resolve()):
        object_evidence.update(sha256=sha(OBJECT), bytes=OBJECT.stat().st_size, machine_header=OBJECT.read_bytes()[:2].hex())
    input_unchanged = INPUT.read_bytes() == INPUT_BYTES
    section_evidence = {"baseline": baseline_sections, "candidate": [], "layout_equal": False, "code_and_directives_equal": False}
    try:
        current_sections = coff_sections(OBJECT)
        section_evidence["candidate"] = current_sections
        section_evidence["layout_equal"] = [{k: v for k, v in row.items() if k != "sha256"} for row in current_sections] == [{k: v for k, v in row.items() if k != "sha256"} for row in baseline_sections]
        select_code = lambda rows: [row for row in rows if row["name"].startswith(".text") or row["name"] == ".drectve"]
        section_evidence["code_and_directives_equal"] = bool(select_code(current_sections)) and select_code(current_sections) == select_code(baseline_sections)
    except Exception as error:
        errors.append("COFF comparison: " + str(error)[:1024])
    # Concurrent product-source changes are observations; this compile consumes only identical tiny input.
    passed = bool(natural_pass and observation_pass and not gaps and tools_unchanged and cache_equal and input_unchanged and object_evidence.get("machine_header") == "6486" and section_evidence["layout_equal"] and section_evidence["code_and_directives_equal"])
    runner.write_json(OUT / "owned-job-observations.json", {"schema": "facman.exact_owned_job_observation.v1", "candidate_sha256": sha(Path(__file__)), "experimental_unpublished_control": {"VSTEL_EWDK": "1"}, "support_claim": "None; empirical pinned-compiler hypothesis only", "owner": owner, "observations": events, "observer_errors": errors, "identity_gaps": gaps, "observation_pass": observation_pass, "source_snapshots": {"before": source_before, "after": source_after, "equal": source_equal}, "cache_snapshots": {"before_sha256": cache_before, "after_sha256": cache_after, "equal": cache_equal}, "tool_inputs_unchanged": tools_unchanged, "input": {"path": str(INPUT), "sha256": sha(INPUT), "unchanged": input_unchanged}, "object": object_evidence, "COFF_comparison": section_evidence, "COFF_scope": "Identical input/flags, section layout, executable .text and .drectve bytes support equivalence only of this tiny compile; debug/path/checksum metadata hashes can differ. No whole-product or full-build equivalence.", "compiler": {"path": str(COMPILER), "sha256": sha(COMPILER), "metadata_sha256": sha(META)}, "strict_natural_lifetime_pass": natural_pass, "combined_diagnostic_pass": passed, "original_run_receipt": str(OUT / "receipt.json"), "scope": "One experimental tiny compile only; retained exact-job observation and original strict cleanup; no supported-control/product/release claim, foreign/global process search or control"})
    print(json.dumps({"strict_natural_lifetime_pass": natural_pass, "combined_diagnostic_pass": passed, "receipt": str(OUT / "receipt.json"), "observations": str(OUT / "owned-job-observations.json")}))
    return 0 if passed else 1
if __name__ == "__main__":
    raise SystemExit(main())
