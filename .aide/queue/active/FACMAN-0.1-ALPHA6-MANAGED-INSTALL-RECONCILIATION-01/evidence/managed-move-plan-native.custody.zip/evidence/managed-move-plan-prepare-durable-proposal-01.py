"""External-only preparation; never execute products or mutate the checkout."""
from pathlib import Path
import argparse, ast, difflib, hashlib, json, zipfile
R=Path(r'D:\Projects\Factorio\factorio-launcher')
E=Path(__file__).resolve().parent
Q='.aide/queue/active/FACMAN-0.1-ALPHA6-MANAGED-INSTALL-RECONCILIATION-01'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):Path(p).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
def main():
 a=argparse.ArgumentParser();a.add_argument('--qualification-review',required=True);a.add_argument('--review-sha256',required=True);args=a.parse_args()
 review=E/args.qualification_review
 assert review.resolve().is_relative_to(E.resolve()) and sha(review)==args.review_sha256
 rv=json.loads(review.read_bytes());assert str(rv['verdict']).startswith('PASS')
 result=E/'managed-move-plan-qualification-04/result.json'
 assert sha(result)=='05f7c59a57b07d3b89b409ce9c296672e84203f3b485fa3b596f1a8c1e851f75'
 r=json.loads(result.read_bytes());assert r['state']=='SOURCE_BEHAVIOR_PASS_WITH_COMPILER_OWNED_CLEANUP'
 assert r['build_natural_descendant_lifetime_pass'] is False and r['build_natural_descendant_lifetime_status']=='NOT_QUALIFIED'
 author=json.loads((E/'managed-move-plan-author-packet-03.json').read_bytes());assert len(author['changed_paths'])==47
 frozen='managed-move-plan-source03-full-source-cohort-01.json';rows=json.loads((E/frozen).read_bytes())['files'];assert len(rows)==5181
 assert rows==json.loads((E/'managed-move-plan-qualification-04/source-before.json').read_bytes())['files']==json.loads((E/'managed-move-plan-qualification-04/source-after.json').read_bytes())['files']
 public=json.loads((E/'managed-move-plan-public-04/receipt.json').read_bytes());assert public['result']=='pass' and not public['open_gaps'] and len(public['steps'])==22
 build=json.loads((E/'managed-move-plan-qualification-04/build/receipt.json').read_bytes());assert build['exit_code']==0 and build['termination']=='completed' and build['job_terminated'] and build['job_empty_observed'] and build['active_processes_at_primary_exit']==2
 for c in r['cohorts']:
  assert sha(c['receipt'])==c['receipt_sha256']
  if c['phase']!='build':assert c['normal_primary_and_empty_job'] and not c['job_terminated'] and c['waited_for_job_empty_after_primary']
 output_names=['managed-move-plan-native.v1.json','managed-move-plan-native.custody.zip','managed-move-plan-execplan-append-01.md','managed-move-plan-durable-proposal-01.json','managed-move-plan-custody-manifest-01.json','managed-move-plan-execplan-append-01.diff']
 assert all(not (E/n).exists() for n in output_names)
 names=['managed-move-plan-prepare-durable-proposal-01.py','managed-move-plan-apply-durable-proposal-01.py','managed-move-plan-author-packet-01.json','managed-move-plan-author-packet-02.json','managed-move-plan-author-packet-03.json','managed-move-plan-author-static-checks-01.json','managed-move-plan-author-static-checks-02.json','managed-move-plan-independent-source-review-01.json','managed-move-plan-independent-source-review-02.json','managed-move-plan-independent-source-review-03.json','managed-move-plan-independent-controller-review-04.json','managed-move-plan-owned-job-diagnostic-review-04.json','managed-move-plan-root-bound-execution-04.py','managed-move-plan-root-bound-execution-04.json','managed-move-plan-root-retained-build-cohort-01.json','managed-move-plan-qualification-controller-02.py','managed-move-plan-qualification-plan-02.json','managed-move-plan-qualification-controller-03.py','managed-move-plan-qualification-plan-03.json','managed-move-plan-qualification-controller-04.py','managed-move-plan-qualification-plan-04.json','managed-move-plan-qualification-04.diff','managed-move-plan-resource-probe-01.ps1','managed-move-plan-source03-static-runner-01.py',frozen,'managed-move-plan-source03-delta-01.json','managed-move-plan-qualification-01/result.json','managed-move-plan-qualification-01/source-before.json','managed-move-plan-qualification-03/result.json','managed-move-plan-public-01/receipt.json','managed-move-plan-public-04/receipt.json','managed-move-plan-tiny-compile-diagnostic-03.py','managed-move-plan-tiny-compile-diagnostic-04.py','managed-move-plan-tiny-compile-root-execution-review-03.json','managed-move-plan-tiny-compile-root-execution-review-04.json',args.qualification_review]
 roots=['managed-move-plan-qualification-04','managed-move-plan-source03-static-01','managed-move-plan-qualification-01/build']
 roots += ['managed-move-plan-qualification-03/'+n for n in ('binary-identity','native-ctest','public-move-preview','cli-regressions','strict')]
 roots += ['managed-move-plan-lifetime-tiny-compile-'+n for n in ('03','04')]
 for root in roots:
  for path in sorted((E/root).rglob('*')):
   if path.is_file():names.append(path.relative_to(E).as_posix())
 inputs={}
 for name in sorted(set(names)):
  path=E/name
  assert path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(E.resolve()),name
  assert not getattr(path.lstat(),'st_file_attributes',0)&0x400
  assert path.suffix.lower() in {'.json','.raw','.py','.ps1','.diff'} and path.stat().st_size<=4*1024**2,name
  inputs['evidence/'+name]=path
 for name,path in [('facman_managed_install_lifecycle.py','tests/integration/facman_managed_install_lifecycle.py'),('provider_canary_process.py','tools/provider_canary_process.py'),('provider_canary_process_windows.py','tools/provider_canary_process_windows.py')]:inputs['qualification-tools/'+name]=R/path
 total=sum(p.stat().st_size for p in inputs.values());assert total<=16*1024**2
 manifest={'schema':'facman.managed_move_plan_custody.v1','files':{n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in sorted(inputs.items())},'selected_uncompressed_bytes':total,'selection':'Selected receipts/results/raw logs/resource observations/byte manifests/driver and oracle scripts only. No EXEs/DLLs/provider copies/build cache/full source backups/fixture trees. Public receipts retain actual human/JSON/RPC results.','omitted_classes':['compiled images (hashes retained)','cache/objects/libraries','provider sources/state copies','fixture trees/archives (receipts retained)','unrelated history']}
 write(E/'managed-move-plan-custody-manifest-01.json',manifest)
 archive=E/'managed-move-plan-native.custody.zip'
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as pack:
  for name,path in sorted(inputs.items()):
   info=zipfile.ZipInfo(name,date_time=(2026,10,16,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
   pack.writestr(info,path.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
  pack.writestr('custody-manifest.v1.json',(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode())
 assert archive.stat().st_size<=4*1024**2
 with zipfile.ZipFile(archive) as pack:
  assert pack.testzip() is None and len(pack.namelist())==len(inputs)+1
  for name,row in manifest['files'].items():assert len(pack.read(name))==row['bytes'] and hashlib.sha256(pack.read(name)).hexdigest()==row['sha256']
 commands=[]
 for c in r['cohorts']:
  actual=json.loads(Path(c['receipt']).read_bytes())
  commands.append({**c,'receipt':'evidence/'+Path(c['receipt']).relative_to(E).as_posix(),'elapsed_seconds':actual['elapsed_seconds'],'termination':actual['termination'],'primary_stopped':actual['primary_stopped'],'job_empty_observed':actual['job_empty_observed']})
 resource=json.loads((E/'managed-move-plan-qualification-plan-04.json').read_bytes())
 payload={'schema':'facman.managed_move_plan_native_acceptance.v1','status':r['state'],'work_item':Q.rsplit('/',1)[-1],'source_base':author['base_head'],'source_branch':author['branch'],'source_head_tree':author['head_tree'],'source_dirty':True,'qualified_source_files_sha256':{x['path']:x['sha256'] for x in author['changed_paths']},'qualified_changed_file_count':47,'full_source_cohort':{'path':'evidence/'+frozen,'sha256':sha(E/frozen),'members':5181,'before_after_equal':True,'qualification_before_after_sha256':r['source_before_sha256']},'publication_delta':'Only exact reviewed ExecPlan append and two evidence files follow qualification; runtime unchanged. Original qualified ExecPlan hash remains in frozen47.','compiled_identity':r['compiled_identity'],'image_cohort':[{**x,'path':Path(x['path']).name} for x in r['native_binary_cohort']],'providers':r['provider_configuration_before']['providers'],'provider_and_full_semantic_cache_unchanged':True,'cmake_cache_sha256':r['provider_configuration_before']['cache']['sha256'],
 'compiler_output_admission':{'primary_exit_code':0,'elapsed_seconds':build['elapsed_seconds'],'termination':'completed','primary_stopped':True,'job_empty_after_owned_cleanup':True,'job_terminated':True,'active_members_at_primary_exit':2,'wait_for_natural_empty_job':False,'natural_descendant_lifetime_pass':False,'natural_descendant_lifetime_status':'NOT_QUALIFIED','canary_qualification':False,'member_identity_limit':'Original/full-build remaining members were not individually identified; later tiny-compile VCTIP observations do not identify them. Existing helper terminates only its exact assigned owned Job; no name exemptions/foreign cleanup.'},
 'proof_calls':22,'public_dispatches':{'json':20,'human':1,'v2_rpc':1,'fixture_setup':2,'closed_move_apply':1,'move_plan':19,'move_plan_success':4,'move_plan_refusals':14,'move_plan_default_unavailable':1},'fixture_setup_calls':2,'human_cli_calls':1,'json_rpc_calls':1,'public_receipt_sha256':r['public_receipt_sha256'],'public_fixture_bytes':r['public_fixture_bytes'],
 'observations':['Pinned-provider synthetic M1 and gateway smoke passed exactly both selected native CTest targets.','Public scenario made22actual calls including synthetic fixture install plan/apply, ordinary human CLI, JSON previews and v2 RPC. Preview/refusal oracles preserve source/foreign/empty-directory/workspace/FacMan-record/provider-state/audit/parent bytes and absent destination.','Both CLI regressions passed. Exact source03 strict and11static receipts were consumed on the identical5181-member cohort, including generated metadata and technical census; AIDE/diff passed normally.','Every noncompiler dispatched/consumed command passed normal primary/empty-Job/no-termination checks. Compiler-output admission is separate and never natural-lifetime PASS.'],
 'private_public_contract_limits':{'raw_provider_plan_and_digest':'Preserved unchanged in facman.managed_move_plan.v1; exact file/effect coverage and pinned private digest validated.','copy_scope':'complete_source_files_including_foreign','grants_ownership':False,'owned_label_limit':'Raw copy_owned_file/ownership_required labels can describe foreign content. grants_ownership=false governs all such labels; no mutation authority.','empty_directory_preservation':'not_promised','apply_available':False,'observation_atomic':False,'default_unconfigured_capability':'unavailable; explicit existing acceptance configuration required'},
 'independent_source_review':{'path':'evidence/managed-move-plan-independent-source-review-03.json','sha256':sha(E/'managed-move-plan-independent-source-review-03.json'),'verdict':'PASS_SOURCE_REVIEW_ONLY'},'independent_actual_qualification_review':{'path':'evidence/'+args.qualification_review,'sha256':args.review_sha256,'verdict':rv['verdict']},'qualification_result':{'path':'evidence/managed-move-plan-qualification-04/result.json','sha256':sha(result)},'commands':commands,'consumed_source_static':r['consumed_source_static'],
 'resource_budget':{'limits':resource['limits'],'actual_before':r['storage_before'],'actual_build_admission':r['build_admission'],'actual_after':r['storage_after'],'actual_retained_growth_bytes':r['storage_after']['measured_root_bytes']-r['storage_before']['measured_root_bytes'],'doctor_advisory_only':r['doctor_advisory_only'],'no_foreign_cleanup':True},'preserved_failures':resource['historical_failures']+[{'campaign':'managed-move-plan-independent-source-review-01','verdict':'FAIL','reason':'Original decoder staging expectation setup/staging rejected real sibling destinations; source02 corrected destination.parent_path(), exact golden, native/public positive and wrong-root negative. Failed review retained.'}],
 'historical_source02_passing_cohorts':{'result':'evidence/managed-move-plan-qualification-03/result.json','phases':['binary-identity','native-ctest','public-move-preview','cli-regressions'],'limit':'Old source02 images passed these normal cohorts before normal strict failure. No source03 or natural-build acceptance inferred.'},'custody':{'path':Q+'/evidence/managed-move-plan-native.custody.zip','sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(inputs)+1,'selected_uncompressed_bytes':total,'manifest_member':'custody-manifest.v1.json'},'limitations':['Synthetic dirty source_checkout behavior only; no fresh-commit/produced-package claim.','Natural compiler descendant lifetime NOT_QUALIFIED; original build/tiny lifetime failures remain FAIL.','Read-only observations are not atomic; no ownership/move apply/mutation permit/repair/game authority.','No genuine Factorio input read/copied/adopted/run.','Complete F07/F11/lifecycle, canonical installed owner gate, game/human/physical hosts/other platforms/Beta/release remain open.'],'move_apply_available':False,'f07_closed':False,'f11_closed':False,'workunit_closed':False,'game_qualified':False,'human_qualified':False,'host_qualified':False,'beta_qualified':False,'release_qualified':False}
 write(E/'managed-move-plan-native.v1.json',payload)
 append='''
### Scoped managed move preview qualification

Source03's exact 47-file postimage and complete 5,181-member source byte cohort
passed independent source review. Fresh source/shared pinned-provider outputs
qualified binary identity, both selected native CTest proofs, the public synthetic
move-preview scenario (22 actual calls including fixture setup, ordinary human
CLI, JSON and v2 stdio RPC), both CLI regressions, AIDE and diff checks. Exact
source03 strict/generated metadata/census and 11 focused static PASS receipts
were consumed from the identical unchanged full source cohort.

The compiler primary exited 0 in 457.69s, with 2 active Job members observed at
primary exit. The existing exact-owned Job cleanup completed and emptied that
Job. This admits compiler outputs for source behavior evidence only; natural
compiler-descendant lifetime remains false/NOT_QUALIFIED and no canary is claimed.
The original full-build members were not individually identified; later tiny
compile observations do not identify them. Every product, native, CLI, AIDE and
diff command retains normal primary/empty-Job/no-termination acceptance. The failed
source01 staging-root review, source02 build lifetime and strict checks, and
tiny03/04 lifetime experiments remain preserved alongside source02's historical
passing behavior cohorts.

The nested provider plan and digest remain unchanged. Provider copy-owned labels
can include foreign files; the public wrapper grants no ownership or mutation
authority. Empty-directory preservation is not promised, observations are not
atomic, default unconfigured behavior stays unavailable and move apply stays
closed. Independent actual qualification review and bounded hash-closed custody
are recorded in evidence/managed-move-plan-native.v1.json and
evidence/managed-move-plan-native.custody.zip.

This accepts only synthetic source behavior with compiler-owned cleanup. No
genuine Factorio input was read or used. Complete F07/F11, remaining lifecycle
transitions, canonical installed owner gate, genuine game/human/physical-host and
other-platform acceptance, produced packages, Beta and release remain open. The
WorkUnit stays active; no queue status or release gate changes.
'''
 ap=E/'managed-move-plan-execplan-append-01.md';ap.write_text(append,encoding='utf-8',newline='\n')
 ep=Q+'/ExecPlan.md';original=(R/ep).read_bytes();post=original+ap.read_bytes();final=[dict(x) for x in author['changed_paths']]
 (E/'managed-move-plan-execplan-append-01.diff').write_text(''.join(difflib.unified_diff(original.decode('utf-8').splitlines(keepends=True),post.decode('utf-8').splitlines(keepends=True),fromfile=ep,tofile=ep)),encoding='utf-8',newline='\n')
 for row in final:
  if row['path']==ep:row.update(bytes=len(post),sha256=hashlib.sha256(post).hexdigest())
 new=[]
 for name in ('managed-move-plan-native.v1.json','managed-move-plan-native.custody.zip'):
  path=E/name;target=Q+'/evidence/'+name;new.append({'source':name,'target':target});final.append({'path':target,'bytes':path.stat().st_size,'sha256':sha(path)})
 assert len(final)==49
 ext={n:sha(E/n) for n in output_names if n!='managed-move-plan-durable-proposal-01.json'}
 ext.update({frozen:sha(E/frozen),args.qualification_review:args.review_sha256,'managed-move-plan-author-packet-03.json':sha(E/'managed-move-plan-author-packet-03.json')})
 apply=E/'managed-move-plan-apply-durable-proposal-01.py';ast.parse(apply.read_text())
 proposal={'schema':'facman.managed_move_durable_proposal.v1','status':'REVIEW_ONLY_NOT_APPLIED','source_base':author['base_head'],'source_branch':author['branch'],'qualified_source_count':47,'final_changed_count':49,'frozen_source_files':author['changed_paths'],'frozen_source_cohort':frozen,'external_inputs':ext,'new_evidence':new,'append_file':ap.name,'archive_file':archive.name,'execplan_path':ep,'execplan_preimage_sha256':sha(R/ep),'execplan_postimage_sha256':hashlib.sha256(post).hexdigest(),'expected_final49':sorted(final,key=lambda x:x['path']),'apply_script_sha256':sha(apply),'apply_script':apply.name,'boundary':'Two new reviewed evidence files plus exact ExecPlan append only; no runtime/Git/build/product/network/status/gate action. Full frozen5181 preimage checked.','storage':{'selected_uncompressed_bytes':total,'archive_bytes':archive.stat().st_size,'custody_member_count':len(inputs)+1,'new_output_limit_bytes':12*1024**2}}
 write(E/'managed-move-plan-durable-proposal-01.json',proposal)
 for name in output_names+[apply.name]:print(name,sha(E/name),(E/name).stat().st_size)
 print('External proposal only; exact reviewed47/full5181 cohort bound without further source checks; archive CRC/all member hashes verified; no Git/build/product/network/apply execution')
if __name__=='__main__':main()
