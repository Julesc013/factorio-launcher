import hashlib,json,subprocess,zipfile
from pathlib import Path
E=Path(__file__).resolve().parent;R=Path(r'D:\Projects\Factorio\factorio-launcher');W=E.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_bytes())
packet=E/'reconciliation-target-alias-author-packet-01.json'
assert sha(packet)=='dfcfeae74531bbffe8f1f13bccc6aa7988edb2d6f5a688e9111afdd8dd791acd'
p=load(packet)
assert p['base']=='361da48beaea506b2cff7e48ae5b09353fa5eb0c'
assert p['branch']=='task/facman-reconciliation-target-alias-01' and not p['self_approval']
for item in p['preserved_artifacts']:
 path=Path(item['path']).resolve(strict=True);assert path.is_relative_to(W) and sha(path)==item['sha256'],str(path)
assert len(p['preserved_artifacts'])==162
for name,digest in p['source_files_sha256'].items():assert sha(R/name)==digest,name
assert len(p['source_files_sha256'])==7
assert subprocess.check_output(['git','branch','--show-current'],cwd=R,text=True).strip()==p['branch']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==p['base']
changed=subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).splitlines()
assert {line[3:] for line in changed}==set(p['source_files_sha256'])

for name in ('validation','proof','first_actual_product_regression'):
 assert sha(p[name]['path'])==p[name]['sha256']
first=load(p['first_actual_product_regression']['path'])
required={'external_root_requires_distinct_managed_target','in_place_authority_conversion_refused'}
assert set(first['missing_required_blockers'])==required and first['same_model_source']
assert first['before']==first['after'] and first['bytes_unchanged']
assert not first['mutation_executed'] and not first['apply_available']
failure_capture=Path(first['command_directory'])
original=load(failure_capture/'receipt.json')
assert original['termination']=='completed' and original['exit_code']==0 and original['primary_stopped'] and original['job_empty_observed']
original_output=load(failure_capture/'stdout.raw')
original_plan=original_output.get('payload',original_output)
assert set(original_plan['blockers'])==set(first['actual_blockers'])
assert not required & set(original_plan['blockers'])

v=load(p['validation']['path'])
assert v['status']=='PASS_SCOPED_READ_ONLY_RECONCILIATION_ALIASES' and v['source_files_sha256']==p['source_files_sha256']
assert v['native_workers']==2 and not v['clean_first'] and not v['produced_successor_package']
assert v['actual_cli_commands']==22 and v['cli_tests_run']==2 and v['cli_success']
assert len(v['commands'])==30
native_outputs=[];cli_plans=[]
for command in v['commands']:
 path=Path(command['receipt']);assert sha(path)==command['receipt_sha256']
 c=load(path);assert c['termination']=='completed' and c['primary_stopped'] and c['job_empty_observed']
 assert not c['waited_for_job_empty_after_primary']
 for stream in ('stdout','stderr'):
  raw=path.parent/c[stream]['file'];assert sha(raw)==c[stream]['sha256'] and raw.stat().st_size==c[stream]['captured_bytes']
 if command['name']=='native':
  assert c['exit_code']==0
  text=(path.parent/'stdout.raw').read_text(encoding='utf-8',errors='replace')
  assert 'flb_factorio_install_model_smoke' in text and '100% tests passed' in text
 if command['name'] in ('strict','aide','diff','build'):assert c['exit_code']==0
 if command['name'].startswith('cli-'):
  response=load(path.parent/'stdout.raw');cli_plans.append(response.get('payload',response))
assert len(cli_plans)==22
for name,digest in v['provider_images_sha256'].items():assert sha(W/'native-developer/Release'/name)==digest
for name,digest in v['binary_images_sha256'].items():assert sha(W/'native-developer/Release'/name)==digest

proof=load(p['proof']['path']);assert len(proof['cases'])==7
assert len(proof['same_targets'])==4
assert proof['availability']==dict(windows_case_alias=True,distinct_short_name_alias=True,directory_link_alias=False,directory_link_error=1314)
for case in proof['cases']:
 plan=case['plan'];assert plan in cli_plans
 assert case['after_inventory']==proof['before_inventory']
 assert plan['desired_state']['target_root']==case['target']
 assert not plan['mutation_executed'] and not plan['apply_available']
 assert all(value is False for value in plan['no_write_guarantees'].values())
 if case['target'] in proof['same_targets']:
  assert required<=set(plan['blockers'])
  assert plan['desired_state']['source']['trust_status']=='selected_unverified'
 elif 'target_identity_unresolved' in plan['blockers']:
  assert required<=set(plan['blockers'])
 else:
  assert not required&set(plan['blockers']) and 'source_candidate_required_for_materialisation' in plan['blockers']
for target in proof['same_targets']:
 assert any(x.get('desired_state',{}).get('target_root')==target and x.get('summary',{}).get('status')=='already_reconciled' for x in cli_plans)

# The only production change is conservative read-only target classification.
diff=subprocess.check_output(['git','diff','--','runtime/factorio/installation/flb_factorio_install_model.cpp'],cwd=R,text=True)
assert 'fs::equivalent(current, requested, error)' in diff
assert 'fs::canonical(current, error)' in diff and 'fs::weakly_canonical(requested, error)' in diff
assert 'target_identity_unresolved' in diff
assert 'effective_target_root == current_root' in diff and 'target != TargetRelation::distinct' in diff
assert not any(token in diff for token in ('create_directories(', 'fs::remove(', 'fs::rename(', 'write_text(', 'apply_install('))
Q=R/'.aide/queue/active/FACMAN-0.1-ALPHA6-MANAGED-INSTALL-RECONCILIATION-01/evidence'
with zipfile.ZipFile(Q/'managed-install-coordination-integrated-metadata-custody.zip') as z:
 assert len(z.namelist())==3
 for name in z.namelist():
  assert '/' not in name and '\\' not in name and name.endswith('.json')
  assert hashlib.sha256(z.read(name)).hexdigest()==sha(E/name)
assert not p['real_game_touched'] and all(p[x]==0 for x in ('new_root','new_clone','new_worktree'))
assert len(p['retained_gaps'])==4
out=E/'reconciliation-target-alias-independent-review-01.json';assert not out.exists()
review=dict(schema='facman.independent_reconciliation_target_alias_review.v1',verdict='PASS_SCOPED_SOURCE_FOR_REQUIRED_CURRENT_CI',
 base=p['base'],branch=p['branch'],packet_sha256=sha(packet),source_files_sha256=p['source_files_sha256'],
 reviewer_script_sha256=sha(__file__),actual_original_missing_blockers=sorted(required),
 actual_cli_commands=22,actual_captured_commands=30,changed_paths=7,preserved_artifacts=162,
 windows_dot_parent_case_and_distinct_short_aliases=True,all_public_nodes_preserved=True,
 genuine_existing_and_absent_distinct_targets=True,malformed_file_ancestor_blocked=True,
 windows_directory_link_qualified=False,required_successor_CI_pending=True,produced_successor_package_pending=True,
 workunit_closed=False,game_executed=False,release_gate_closed=False,all_member_natural_exit_claimed=False)
out.write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8');print(json.dumps(review,indent=2))
