import hashlib, io, json, os, shutil, subprocess, sys, time, traceback, unittest
from pathlib import Path
from unittest.mock import patch
R=Path(r'D:\Projects\Factorio\factorio-launcher')
W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e')
E,B=W/'evidence',W/'native-developer'
sys.path[:0]=[str(R/'tests'),str(R)];sys.dont_write_bytecode=True
from tools import native_build,provider_canary_process as owned
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),
 PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',FACMAN_MIN_FREE_GIB='12',CMAKE_BUILD_PARALLEL_LEVEL='2',MSBUILDDISABLENODEREUSE='1')
Q='.aide/queue/active/FACMAN-0.1-ALPHA6-MANAGED-INSTALL-RECONCILIATION-01'
files=['runtime/factorio/installation/flb_factorio_install_model.cpp','tests/native/flb_factorio_install_model_smoke.cpp',
 'tests/test_cli.py','docs/architecture/installation_model_and_reconciliation.md',Q+'/ExecPlan.md',
 Q+'/evidence/managed-install-coordination-integrated.v1.json',Q+'/evidence/managed-install-coordination-integrated-metadata-custody.zip']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R).decode('utf-8').strip()
assert git('branch','--show-current')=='task/facman-reconciliation-target-alias-01'
assert git('rev-parse','HEAD')=='361da48beaea506b2cff7e48ae5b09353fa5eb0c'
source={name:sha(R/name) for name in files}
assert source[files[0]]=='da9a634e04f7fc2e7088f23230d28f5e63f6e64f955136c2a78b189280ef89a8'
providers={name:sha(B/'Release'/name) for name in ('ulk.dll','usk.dll')}
result=dict(schema='facman.reconciliation_target_alias_validation.v1',status='prepared',base=git('rev-parse','HEAD'),
 branch=git('branch','--show-current'),source_files_sha256=source,provider_images_sha256=providers,commands=[],
 native_workers=2,clean_first=False,tracking_enabled=True,new_roots=0,new_clones=0,new_worktrees=0,
 self_approval=False,real_game=False,produced_successor_package=False,workunit_closed=False)
path=E/'reconciliation-target-alias-native-result-01.json'
assert not path.exists()
def save():owned.write_json(path,result)
def bound():
 assert git('branch','--show-current')==result['branch'] and git('rev-parse','HEAD')==result['base']
 assert all(sha(R/name)==value for name,value in source.items())
 assert all(sha(B/'Release'/name)==value for name,value in providers.items())
def dispatch(name,args,seconds=600,accepted=(0,),environment=None):
 capture=owned.command([str(a) for a in args],cwd=R,environment=dict(os.environ) if environment is None else environment,
  timeout=seconds,budget=budget,directory=E/('reconciliation-target-alias-'+name+'-execution-01'),output_limit=8*1024*1024,
  wait_for_job_empty_after_primary=False)
 result['commands'].append(dict(name=name,argv=[str(a) for a in args],receipt=str(capture.directory/'receipt.json'),
  receipt_sha256=sha(capture.directory/'receipt.json'),exit_code=capture.returncode,termination=capture.receipt['termination'],
  job_empty=capture.receipt['job_empty_observed']))
 save()
 assert capture.receipt['termination']=='completed' and capture.returncode in accepted and capture.receipt['job_empty_observed'],name
 return capture
budget=None
save()
try:
 dispatch('paths',['py','-3','-B','tools/workspace_hygiene.py','paths'],90)
 measured=dispatch('doctor',['py','-3','-B','tools/workspace_hygiene.py','doctor','--measure'],180,accepted=(0,1))
 resources=json.loads(measured.stdout.decode('utf-8'))
 assert len(resources['task_roots'])<=8 and resources['task_root_bytes']+1024**3<=20*1024**3
 assert set(resources['violations'])<={'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
 native_build.require_disk_reserve(B)
 result['resources']=dict(owned_roots=len(resources['task_roots']),owned_bytes=resources['task_root_bytes'],free_bytes=shutil.disk_usage(W).free)
 counter=0
 while True:
  counter+=1
  query="$p=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(cl|clang|link|ninja|ctest)\\.exe$' -or ($_.Name -eq 'cmake.exe' -and $_.CommandLine -like '*--build*') -or ($_.Name -eq 'MSBuild.exe' -and $_.CommandLine -notlike '*/nodemode:*') } | Select-Object Name,ProcessId,CreationDate); ConvertTo-Json -InputObject $p -Compress"
  observed=dispatch('admission-'+str(counter),['pwsh','-NoProfile','-Command',query],45)
  active=json.loads(observed.stdout or b'[]')
  if not active:break
  result.update(status='waiting_for_foreign_native_job',foreign_job_count=len(active));save();time.sleep(60)
 bound();budget=owned.Budget(5400,1800)
 result['status']='build_affected';save()
 dispatch('build',['cmake','--build',B,'--config','Release','--parallel','2','--target','facman_cli','flb_factorio_install_model_smoke','--','/nr:false'],1800)
 bound();result['binary_images_sha256']={n:sha(B/'Release'/n) for n in ('facman.exe','flb_factorio_install_model_smoke.exe')};save()
 dispatch('native',['ctest','--test-dir',B,'-C','Release','--output-on-failure','--no-tests=error','-R','^flb_factorio_install_model_smoke$'],300)
 import native_cli,test_cli
 cli_counter=0
 def invoke_machine(args,env=None):
  global cli_counter
  cli_counter+=1
  capture=dispatch('cli-'+str(cli_counter).zfill(3),[B/'Release/facman.exe',*args],40,accepted=tuple(range(0,16)),environment=env)
  return capture.returncode,capture.stdout.decode('utf-8'),capture.stderr.decode('utf-8')
 cases=[test_cli.CliTests('test_reconciliation_target_aliases_preserve_external_authority'),
        test_cli.CliTests('test_install_model_and_reconciliation_are_read_only_and_conservative')]
 output=io.StringIO()
 with patch.object(native_cli,'invoke_machine',invoke_machine):
  tests=unittest.TextTestRunner(stream=output,verbosity=2).run(unittest.TestSuite(cases))
 (E/'reconciliation-target-alias-cli-tests-01.log').write_text(output.getvalue(),encoding='utf-8')
 owned.write_json(E/'reconciliation-target-alias-public-oracles-01.json',getattr(cases[0],'target_alias_observations',{}))
 result.update(actual_cli_commands=cli_counter,cli_tests_run=tests.testsRun,cli_success=tests.wasSuccessful())
 save();assert tests.wasSuccessful(),output.getvalue()
 dispatch('strict',['py','-3','-B','tools/strict_check.py'],1800)
 dispatch('aide',['py','-3','-B','.aide/scripts/aide_lite.py','test'],600)
 dispatch('diff',['git','diff','--check'],90)
 bound();result['status']='PASS_SCOPED_READ_ONLY_RECONCILIATION_ALIASES'
except BaseException as error:
 result.update(status='FAIL_RETAINED',error=str(error),traceback=traceback.format_exc())
finally:
 save();print(json.dumps(dict(status=result['status'],commands=len(result['commands']),cli_commands=result.get('actual_cli_commands',0))))
sys.exit(0 if result['status'].startswith('PASS_') else 1)
