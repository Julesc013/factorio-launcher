import hashlib, json, os, subprocess, sys
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher')
W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e')
E=W/'evidence'
sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools import provider_canary_process as owned
def sha(b): return hashlib.sha256(b).hexdigest()
def inventory(root):
    return {p.relative_to(root).as_posix():sha(p.read_bytes()) if p.is_file() else 'directory' for p in sorted(root.rglob('*'))}
model='runtime/factorio/installation/flb_factorio_install_model.cpp'
old=subprocess.check_output(['git','show','32d68eb74707722b55ff48932b52c9b6a8988895:'+model],cwd=R)
assert sha(old)==sha((R/model).read_bytes().replace(b'\r\n',b'\n'))
fixture=W/'t/j3/alias03';fixture.mkdir(exist_ok=False)
target=fixture/'target';(target/'data/base').mkdir(parents=True);(target/'bin/x64').mkdir(parents=True)
(target/'data/base/info.json').write_text('{"version":"2.0.77"}',encoding='utf-8')
(target/'bin/x64/factorio.exe').write_bytes(b'synthetic-unexecutable-fixture')
workspace=fixture/'workspace';refs=workspace/'installs/refs';refs.mkdir(parents=True)
record=json.loads((W/'t/j3/mc39/p-Ω/workspace/installs/refs/managed-test.json').read_text(encoding='utf-8'))
record.update(install_id='alias-fixture',root=str(target),executable=str(target/'bin/x64/factorio.exe'),app_dir=str(target),
    ownership='foreign',source='steam',provider_id='factorio-discovery',distribution_origin='steam',platform_integration='steam',
    setup_state_ref='',last_verification_identity='',source_ref='',strict_isolation_eligibility='',external_state_domains=[])
(refs/'alias-fixture.json').write_text(json.dumps(record,ensure_ascii=False)+'\n',encoding='utf-8')
before=inventory(fixture)
owned.write_json(E/'reconciliation-target-alias-before-03.json',before)
env={k:v for k,v in os.environ.items() if not k.startswith(('FACMAN_','FLAUNCH_','ULK_','USK_'))}
env.update(FACMAN_DEV_ROOT=str(W.parents[3]),TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1')
env['PATH']=str(Path(env['SYSTEMROOT'])/'System32')+os.pathsep+env['SYSTEMROOT']
cli=W/'t/j3/g32/bin/facman.exe'
assert sha(cli.read_bytes())=='9711addfc82d4f3decdf6fcc59c55cd6cc8f3f10f6319a7da61fbc07249244fb'
requested=str(target)+'\\.'
result=owned.command([str(cli),'--workspace',str(workspace),'installs','reconcile','plan','alias-fixture',
    '--management','managed','--source-ref','synthetic-source:2.0.77','--target',requested,'--json'],
    cwd=W/'t/j3/cwd39',environment=env,timeout=40,directory=E/'reconciliation-target-alias-first-command-03')
after=inventory(fixture)
assert result.ok and result.receipt['job_empty_observed'] and before==after
plan=json.loads(result.stdout.decode('utf-8'))['payload']
required={'external_root_requires_distinct_managed_target','in_place_authority_conversion_refused'}
missing=sorted(required-set(plan['blockers']))
receipt={'result':'observed_assertion_failure' if missing else 'unexpected_pass','source_sha256':sha(old),
    'binary_sha256':sha(cli.read_bytes()),'source_revision':'361da48beaea506b2cff7e48ae5b09353fa5eb0c',
    'package_revision':'32d68eb74707722b55ff48932b52c9b6a8988895','same_model_source':True,
    'requested_target':requested,'missing_required_blockers':missing,'actual_blockers':plan['blockers'],
    'command_directory':str(result.directory),'before':before,'after':after,'bytes_unchanged':before==after,
    'mutation_executed':plan['mutation_executed'],'apply_available':plan['apply_available']}
owned.write_json(E/'reconciliation-target-alias-first-failure-03.json',receipt)
print(json.dumps({k:receipt[k] for k in ('result','missing_required_blockers','bytes_unchanged','apply_available')}))
assert not missing, 'same physical root omitted required authority-preservation blockers: '+','.join(missing)
