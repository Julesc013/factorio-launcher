import hashlib, json, os, subprocess, sys, traceback, zipfile
from pathlib import Path

R = Path(r"D:\Projects\Factorio\factorio-launcher")
E = Path(__file__).resolve().parent
W = E.parent
BASE = "8486d842e1d6a01926066bbee1d3746e367ba1e2"
BRANCH = "task/facman-reconciliation-target-alias-01"
ITEM = "FACMAN-0.1-ALPHA6-MANAGED-INSTALL-RECONCILIATION-01"
Q = ".aide/queue/active/" + ITEM
os.environ.update(FACMAN_DEV_ROOT=r"D:\Projects\Factorio\.task-builds", TEMP=str(W/"t"), TMP=str(W/"t"),
                  PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1", GIT_CONFIG_COUNT="1",
                  GIT_CONFIG_KEY_0="core.safecrlf", GIT_CONFIG_VALUE_0="false")
sys.path.insert(0, str(R))
from tools import provider_canary_process as owned
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
git = lambda *a: subprocess.check_output(["git", *a], cwd=R).decode("utf-8").strip()
dirty = lambda: set(git("diff", "--name-only").splitlines()) | set(git("ls-files", "--others", "--exclude-standard").splitlines())
out = E/"reconciliation-held-metadata-candidate-commit-result-01.json"
assert not out.exists()
record = dict(status="QUALIFYING_SCOPED_READONLY_TARGET_ALIASES", commands=[], new_roots=0, new_clones=0, new_worktrees=0)
def save():
    out.write_text(json.dumps(record, indent=2)+"\n", encoding="utf-8")
def run(label, args, timeout=180, codes=(0,)):
    r = owned.command(args, cwd=R, environment=dict(os.environ), timeout=timeout,
        directory=E/("reconciliation-held-metadata-commit01-"+label), output_limit=8*1024**2,
        wait_for_job_empty_after_primary=True)
    record["commands"].append(dict(label=label, exit=r.returncode, receipt_sha256=sha(r.directory/"receipt.json")))
    save()
    assert r.returncode in codes and r.receipt["termination"] == "completed" and r.receipt["primary_stopped"] and r.receipt["job_empty_observed"], (label, (r.stdout[-1000:]+r.stderr[-1500:]).decode("utf-8", "replace"))
    return r
try:
    assert git("rev-parse", "HEAD") == BASE and git("branch", "--show-current") == BRANCH
    assert not git("diff", "--cached", "--name-only")
    packet = E/"reconciliation-held-metadata-author-packet-01.json"
    p = json.loads(packet.read_bytes())
    review = E/"reconciliation-held-metadata-independent-review-01.json"
    v = json.loads(review.read_bytes())
    assert v["verdict"] == "PASS_SCOPED_SOURCE_FOR_REQUIRED_CURRENT_CI"
    assert v["packet_sha256"] == sha(packet) and not v["workunit_closed"]
    expected = set(p["source_files_sha256"])
    assert dirty() == expected
    for name, digest in p["source_files_sha256"].items():
        assert sha(R/name) == digest
    for label in ("policy", "detect", "plan"):
        run(label, ["py", "-3", "-B", ".aide/scripts/aide_lite.py", "git", label])
    run("paths", ["py", "-3", "-B", "tools/workspace_hygiene.py", "paths"])
    h = json.loads(run("doctor", ["py", "-3", "-B", "tools/workspace_hygiene.py", "doctor", "--measure"], 600, (0, 1)).stdout)
    assert set(h["violations"]) <= {"unmanaged_secondary_worktrees_present"}
    assert len(h["task_roots"]) == 8 and h["task_root_bytes"] < 20*1024**3
    manifest = {}
    artifacts = [Path(row["path"]).resolve() for row in p["preserved_artifacts"]]
    artifacts += [packet, review, E/"reconciliation-held-metadata-independent-review-01.py", Path(__file__)]
    for path in artifacts:
        assert path.is_relative_to(W.resolve()) and path.is_file()
        assert path.suffix.lower() not in (".exe", ".dll", ".zip")
        name = "evidence/" + path.relative_to(W).as_posix()
        manifest[name] = sha(path)
    archive = R/Q/"evidence/reconciliation-held-metadata-custody.v1.zip"
    evidence = R/Q/"evidence/reconciliation-held-metadata.v1.json"
    assert not archive.exists() and not evidence.exists()
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr("custody-manifest.json", json.dumps(manifest, indent=2, sort_keys=True)+"\n")
        for name in sorted(manifest):
            z.write(W/name.removeprefix("evidence/"), name)
    with zipfile.ZipFile(archive) as z:
        assert set(z.namelist()) == set(manifest) | {"custody-manifest.json"}
        for name, digest in manifest.items():
            assert hashlib.sha256(z.read(name)).hexdigest() == digest
    assert archive.stat().st_size < 8*1024**2
    evidence.write_text(json.dumps(dict(
        schema="facman.held_metadata_checkpoint.qualified_source.v1",
        base_head=BASE, base_tree=git("rev-parse", BASE+"^{tree}"),
        author_packet_sha256=sha(packet), independent_review_sha256=sha(review),
        authored_files_sha256=p["source_files_sha256"],
        linux_Debug_native_tests_passed=2, windows_Release_native_tests_passed=2,
        observed_requested_checkpoint=True, observed_recovery_required_no_entry=True,
        ordinary_exact_owner_recovery_passed=True, foreign_bytes_preserved=True,
        original_coverage_failure_sha256=p["original_hosted_failure"]["sha256"],
        original_hosted_journal_state_observed=False, causal_explanation="source/timing inference retained",
        worker_scoped_internal_observer=True, default_enabled_pause_seconds=2,
        refused_recovery_admitted=False, no_external_CLI_API_or_filesystem_observer_writes=True,
        existing_caches_reused=True, new_provider_modular_archives=6,
        provider_sources_pins_profile_preserved=True,
        resource_admission=p["resource_admission"],
        custody=archive.name, custody_sha256=sha(archive), custody_files=len(manifest),
        required_checks_pending=True, produced_current_package_qualified=False,
        workunit_closed=False, real_game_qualified=False, human_qualified=False,
        physical_ext4=False, all_member_natural_exit_claimed=False, beta=False, rc=False,
        new_roots=0, new_caches=0, new_clones=0, new_worktrees=0),indent=2)+"\n",encoding="utf-8")
    with (R/Q/"ExecPlan.md").open("a",encoding="utf-8",newline="\n") as stream:
        stream.write("\n### Synchronize the POSIX held-metadata proof checkpoint\n\n"
            "Source8486's required Linux coverage job116098627804 failed the same-inode metadata test after0.25s. "
            "The exact log lacks the original durable journal state; acquisition/flush versus cell-observation timing is a source-supported inference. "
            "The test now uses an internal worker-local observer at the existing enabled post-acquisition pause and a bounded ready/release handshake. "
            "It binds REQUESTED/no-entry and the retained inode before editing; abort/release/join and callback restoration cover failed assertions. "
            "Unset observer behavior and the two-second pause remain unchanged. Refused recovery is still excluded.\n\n"
            "Independent review verifies affected Linux Debug and Windows Release native tests, actual REQUESTED then recovery_required diagnostics, exact foreign-byte/provider/target preservation and ordinary recovery. "
            "Strict/AIDE pass. The existing Linux cache required six modular provider archives; exact provider sources, pins and profile stay unchanged. "
            "Three admission stops and the original required failure remain preserved; no new cache, root or clone was created. "
            "Fresh current-head checks and delivered proof remain pending. No genuine game, human, whole maintenance, WorkUnit, Beta or release gate closes. "
            "Evidence: evidence/reconciliation-held-metadata.v1.json and its hash-closed custody.\n")
    paths = expected | {Q+"/ExecPlan.md", Q+"/evidence/"+archive.name, Q+"/evidence/"+evidence.name}
    run("project-state", ["py", "-3", "-B", "tools/project_state.py", "--write"], 600)
    run("metadata", ["py", "-3", "-B", "tools/codegen/generate_metadata.py", "--write"])
    changed = dirty()
    assert paths <= changed <= paths | {".aide/memory/project-state.md", ".aide/memory/project-state.v2.json", "README.md"}
    for name, digest in p["source_files_sha256"].items():
        assert sha(R/name) == digest
    run("strict", ["py", "-3", "-B", "tools/strict_check.py"], 1800)
    run("portable-aide", ["py", "-3", "-B", ".aide/scripts/aide_lite.py", "test"], 1800)
    message = ("test(setup): synchronize held metadata corruption checkpoint\n\n"
        "Bind the existing post-acquisition pause before editing foreign bytes\n"
        "so the proof exercises a held lease rather than unfinished creation.\n\n"
        "Work-Item: "+ITEM+"\nEvidence-Ref: "+Q+"/evidence/"+evidence.name+"\n")
    msg = E/"reconciliation-held-metadata-candidate-commit-message-01.txt"
    msg.write_text(message, encoding="utf-8", newline="\n")
    run("message", ["py", "-3", "-B", ".aide/scripts/aide_lite.py", "commit", "check", "--message", message])
    changes = [dict(path=name, state="content", sha256=sha(R/name),
        git_blob_oid=git("hash-object", "--path", name, str(R/name)), ownership="task_owned") for name in sorted(changed)]
    snapshot = hashlib.sha256((json.dumps(changes, indent=2, sort_keys=True, separators=(",", ": "))+"\n").encode()).hexdigest()
    commit_review = E/"reconciliation-held-metadata-candidate-commit-review-01.json"
    commit_review.write_text(json.dumps(dict(schema_version="aide.git-commit-review.v1", verdict="PASS",
        reviewer="/root", author="/root/managed_install_coordination_implementation", non_authoring=True, branch=BRANCH, base_commit=BASE,
        snapshot_sha256=snapshot, message_sha256=sha(msg), independent_source_review_sha256=sha(review),
        review="Independently inspected worker-local observer and abort/release/join; verified affected POSIX/Windows native, actual durable diagnostics, resource bounds and164 artifacts; original hosted cause remains inference"), indent=2)+"\n", encoding="utf-8")
    classification = E/"reconciliation-held-metadata-candidate-commit-classification-01.json"
    classification.write_text(json.dumps(dict(schema_version="aide.git-commit-classification.v1", branch=BRANCH,
        base_commit=BASE, work_item=ITEM, snapshot_sha256=snapshot, message_sha256=sha(msg), changed_paths=changes,
        reviews=[dict(path=str(commit_review), sha256=sha(commit_review), verdict="PASS")]), indent=2)+"\n", encoding="utf-8")
    helper = ["py", "-3", "-B", ".aide/scripts/aide_lite.py", "git", "commit-plan", "--classification", str(classification), "--message-file", str(msg)]
    run("plan-stage", helper)
    run("stage", ["git", "add", "--", *sorted(changed)])
    run("staged-diff", ["git", "diff", "--cached", "--check"])
    run("plan-commit", helper)
    assert git("rev-parse", "HEAD") == BASE
    run("commit", ["git", "commit", "-F", str(msg)])
    run("range", ["py", "-3", "-B", ".aide/scripts/aide_lite.py", "commit", "check", "--range", BASE+"..HEAD"])
    remaining = git("diff", "--name-only").splitlines()
    if remaining:
        assert set(remaining) <= {".aide/memory/project-state.md", ".aide/memory/project-state.v2.json", "README.md"}
        for name in remaining:
            assert git("hash-object", "--path", name, str(R/name)) == git("rev-parse", "HEAD:"+name)
        run("refresh-generated-index", ["git", "add", "--", *remaining])
    assert not git("status", "--porcelain") and not git("diff", "--cached", "--name-only")
    record.update(status="COMMITTED_REVIEWED_HELD_METADATA_CHECKPOINT_CANDIDATE",
        source=git("rev-parse", "HEAD"), tree=git("rev-parse", "HEAD^{tree}"),
        review_sha256=sha(commit_review), evidence_sha256=sha(evidence),
        required_checks_pending=True, remote_not_pushed=True, workunit_closed=False)
except BaseException as error:
    record.update(status="ACTIONABLE_MANAGED_INSTALL_COORDINATION_COMMIT_FAILURE", error=str(error), traceback=traceback.format_exc())
finally:
    save()
    print(json.dumps({k:v for k,v in record.items() if k not in ("commands", "traceback")}, indent=2))
raise SystemExit(0 if record["status"] == "COMMITTED_REVIEWED_HELD_METADATA_CHECKPOINT_CANDIDATE" else 1)
