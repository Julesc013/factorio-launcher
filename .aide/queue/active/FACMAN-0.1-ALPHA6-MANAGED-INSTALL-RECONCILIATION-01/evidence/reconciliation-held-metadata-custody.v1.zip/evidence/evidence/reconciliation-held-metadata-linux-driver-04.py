import hashlib,json,os,signal,subprocess,time,traceback
from pathlib import Path
R=Path('/mnt/d/Projects/Factorio/factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
L=W/'native-save-context-linux';M=E/'posix-publication-private-fixtures-01'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
freeze=json.loads((E/'reconciliation-target-alias-held-metadata-source-review-01.json').read_text(encoding='utf-8'))
assert os.getpid()==1 and os.getuid()==0 and os.readlink('/proc/self/ns/mnt')!=os.environ['FACMAN_PARENT_MOUNT_NAMESPACE']
marker=json.loads((W/'.facman-development-root.v1.json').read_text(encoding='utf-8'))
assert marker['owner']=='facman-development' and marker['task_id']=='task/facman-world-restore-retention-01'
os.environ.update(GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.autocrlf',GIT_CONFIG_VALUE_0='true',
 PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',GIT_OPTIONAL_LOCKS='0',FACMAN_DEV_ROOT='/mnt/d/Projects/Factorio/.task-builds',
 TMPDIR=str(W/'t'),TMP=str(W/'t'),TEMP=str(W/'t'),CMAKE_BUILD_PARALLEL_LEVEL='2')
out=E/'reconciliation-held-metadata-linux-result-04.json';assert not out.exists()
record=dict(status='PREPARED',base=freeze['base'],source_files_sha256=freeze['source_files_sha256'],
 cache=str(L),parallel=2,new_roots=0,new_clones=0,new_worktrees=0,coverage_enabled=False,physical_ext4=False,
 mount_namespace=os.readlink('/proc/self/ns/mnt'),pid_namespace=os.readlink('/proc/self/ns/pid'),commands=[])
def save():out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
def bound():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode('utf-8').strip()==record['base']
 assert all(sha(R/name)==value for name,value in record['source_files_sha256'].items())
def reap():
 while True:
  try:pid,_=os.waitpid(-1,os.WNOHANG)
  except ChildProcessError:break
  if pid==0:break
def run(name,args,timeout=600):
 bound();stdout=E/('reconciliation-held-metadata-linux-'+name+'-04.stdout');stderr=stdout.with_suffix('.stderr')
 item=dict(name=name,argv=[str(a) for a in args],seconds=timeout,termination='prepared',stdout=str(stdout),stderr=str(stderr))
 record['commands'].append(item);save();started=time.monotonic()
 with stdout.open('xb') as o,stderr.open('xb') as er:
  p=subprocess.Popen(item['argv'],cwd=R,stdout=o,stderr=er,stdin=subprocess.DEVNULL,start_new_session=True)
  item.update(pid=p.pid,pgid=os.getpgid(p.pid));save();assert item['pgid']==p.pid
  try:code=p.wait(timeout=timeout);item['termination']='completed'
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=30);item['termination']='timed_out'
  try:os.killpg(p.pid,0);alive=True
  except ProcessLookupError:alive=False
  item['owned_group_cleanup']=alive
  if alive:os.killpg(p.pid,signal.SIGKILL)
  deadline=time.monotonic()+5
  while True:
   reap()
   remaining=[n for n in os.listdir('/proc') if n.isdigit() and int(n)!=1]
   if not remaining or time.monotonic()>=deadline:break
   time.sleep(.02)
 item.update(exit_code=code,namespace_children_empty=not remaining,stdout_sha256=sha(stdout),stderr_sha256=sha(stderr),elapsed_seconds=round(time.monotonic()-started,6))
 save();assert code==0 and item['termination']=='completed' and item['namespace_children_empty'],name
 bound();return stdout
mounted=False
save()
try:
 assert os.statvfs(W).f_bavail*os.statvfs(W).f_frsize>=12*1024**3
 providers={p.name:sha(p) for p in L.iterdir() if p.is_file() and p.name.startswith(('libusk','libulk'))}
 assert providers;record['provider_images_before']=providers;save()
 def cache_values():
  entries={}
  for line in (L/'CMakeCache.txt').read_text(encoding='utf-8').splitlines():
   if line and not line.startswith(('#','//')) and '=' in line:
    key,value=line.split('=',1);entries[key]=value
  return entries
 def inventory(root):
  return {p.relative_to(root).as_posix(): 'link:'+os.readlink(p) if p.is_symlink() else
          'directory' if p.is_dir() else sha(p) for p in sorted(root.rglob('*'))}
 before_cache=cache_values()
 provider_roots=[Path(before_cache[key]) for key in ('FLAUNCH_UNIVERSAL_LAUNCHER_ROOT:PATH','FLAUNCH_UNIVERSAL_SETUP_ROOT:PATH')]
 source_names=subprocess.check_output(['git','ls-files','-z'],cwd=R).decode('utf-8').split('\0')
 source_before={n:sha(R/n) for n in source_names if n and (R/n).is_file()}
 providers_before={str(root):inventory(root) for root in provider_roots}
 inventories_before=dict(cache=before_cache,source=source_before,providers=providers_before)
 qualified=json.loads((E/'reconciliation-held-metadata-regeneration-after-02.json').read_text(encoding='utf-8'))
 assert inventories_before==qualified,'qualified cache/source/provider inventory changed before continuation'
 (E/'reconciliation-held-metadata-plan-before-04.json').write_text(json.dumps(inventories_before,indent=2)+'\n',encoding='utf-8')
 manifest=E/'reconciliation-held-metadata-native-plan-04.ninja'
 original_manifest=L/'build.ninja';manifest.write_bytes(original_manifest.read_bytes())
 manifest_sha=sha(manifest);assert sha(original_manifest)==manifest_sha
 record['plan_manifest_sha256']=manifest_sha;record['prior_regeneration_result_sha256']=sha(E/'reconciliation-held-metadata-linux-result-02.json');save()
 plan=run('dry-run',['ninja','-C',L,'-f',manifest,'-n','m1_three_repository_system_proof','flb_factorio_install_model_smoke'],180)
 assert sha(original_manifest)==manifest_sha and sha(manifest)==manifest_sha
 inventories_after=dict(cache=cache_values(),source={n:sha(R/n) for n in source_names if n and (R/n).is_file()},providers={str(root):inventory(root) for root in provider_roots})
 (E/'reconciliation-held-metadata-plan-after-04.json').write_text(json.dumps(inventories_after,indent=2)+'\n',encoding='utf-8')
 assert inventories_before==inventories_after,'read-only graph changed cache/source/provider inventory'
 record['read_only_complete_graph_verified']=True;save()
 planned=plan.read_text(encoding='utf-8')
 assert 'Re-running CMake' not in planned,'cache needs source review before regeneration'
 sdk_objects=[line for line in planned.splitlines() if 'Building' in line and 'universal-setup/CMakeFiles/' in line]
 sdk_archives=[line.split()[-1] for line in planned.splitlines() if 'Linking' in line and 'libusk' in line]
 assert len(sdk_objects)==18 and len(sdk_archives)==6 and not any('Building' in line and 'universal-launcher/CMakeFiles/' in line for line in planned.splitlines()),'SDK plan differs from admitted eighteen-object/six-archive scope'
 record.update(admitted_sdk_compile_objects=len(sdk_objects),admitted_sdk_archives=sdk_archives);save()
 run('build',['cmake','--build',L,'--parallel','2','--target','m1_three_repository_system_proof','flb_factorio_install_model_smoke'],2400)
 after_providers={p.name:sha(p) for p in L.iterdir() if p.is_file() and p.name.startswith(('libusk','libulk'))}
 assert all(after_providers[n]==value for n,value in providers.items())
 record.update(provider_images_after=after_providers,provider_new_outputs=sorted(set(after_providers)-set(providers)),
               existing_monolithic_provider_images_unchanged=True,all_provider_output_unchanged_claimed=False)
 assert len(record['provider_new_outputs'])==6
 assert source_before=={n:sha(R/n) for n in source_names if n and (R/n).is_file()}
 assert providers_before=={str(root):inventory(root) for root in provider_roots}
 record['provider_source_inventory_unchanged_after_build']=True

 record['native_images_sha256']={n:sha(L/n) for n in ('m1_three_repository_system_proof','flb_factorio_install_model_smoke')};save()
 assert M.is_dir() and not list(M.iterdir()) and not os.path.ismount(M)
 run('mount',['mount','-t','tmpfs','-o','size=128m,nosuid,nodev,mode=1777','facman-held-metadata',M],30);mounted=True
 os.environ.update(TMPDIR=str(M),TMP=str(M),TEMP=str(M))
 assert os.statvfs(M).f_blocks*os.statvfs(M).f_frsize==128*1024**2
 model=run('model',[L/'flb_factorio_install_model_smoke'],120)
 native=run('m1',[L/'m1_three_repository_system_proof'],300)
 diagnostics=[line for line in native.read_text(encoding='utf-8').splitlines() if line.startswith('held-metadata ')]
 assert len(diagnostics)==3 and 'journal_state=requested' in diagnostics[0]
 assert 'apply error=recovery_write_refused' in diagnostics[1] and 'journal_state=recovery_required' in diagnostics[1]
 assert 'recovery inspection error= ' in diagnostics[2] and 'journal_state=recovery_required' in diagnostics[2]
 record.update(status='PASS_SCOPED_POSIX_HELD_METADATA_CHECKPOINT',observed_diagnostics=diagnostics,
  original_hosted_causal_state_observed=False,refused_recovery_admitted=False,directory_link_case_explicitly_observed=False)
except BaseException as error:record.update(status='FAIL_RETAINED',error=str(error),traceback=traceback.format_exc())
finally:
 if mounted:
  run('unmount',['umount',M],30)
 record['private_fixture_unmounted']=not os.path.ismount(M);record['private_fixture_parent_empty']=not list(M.iterdir())
 save();print(json.dumps(dict(status=record['status'],commands=len(record['commands']),diagnostics=record.get('observed_diagnostics'))))
raise SystemExit(0 if record['status'].startswith('PASS_') else 1)
