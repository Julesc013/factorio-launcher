import hashlib,json,os,shutil,subprocess,sys,time,traceback
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent;B=W/'native-developer'
sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),
 PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',FACMAN_MIN_FREE_GIB='12',CMAKE_BUILD_PARALLEL_LEVEL='2',MSBUILDDISABLENODEREUSE='1')
freeze=json.loads((E/'reconciliation-target-alias-held-metadata-source-review-01.json').read_text(encoding='utf-8'))
result=dict(status='PREFLIGHT',base=freeze['base'],source_files_sha256=freeze['source_files_sha256'],commands=[],native_workers=2,
 clean_first=False,tracking_enabled=True,new_roots=0,new_caches=0,new_clones=0,new_worktrees=0,CI_dispatched=False)
path=E/'reconciliation-held-metadata-launch-result-02.json';assert not path.exists()
def save():owned.write_json(path,result)
def bound():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode('utf-8').strip()==result['base']
 assert all(sha(R/name)==value for name,value in result['source_files_sha256'].items())
def run(name,args,timeout=600,accepted=(0,)):
 bound();capture=owned.command([str(a) for a in args],cwd=R,environment=dict(os.environ),timeout=timeout,
  directory=E/('reconciliation-held-metadata-'+name+'-execution-02'),output_limit=8*1024**2,wait_for_job_empty_after_primary=False)
 result['commands'].append(dict(name=name,argv=[str(a) for a in args],exit_code=capture.returncode,termination=capture.receipt['termination'],
  job_empty=capture.receipt['job_empty_observed'],receipt=str(capture.directory/'receipt.json'),receipt_sha256=sha(capture.directory/'receipt.json')))
 save();assert capture.receipt['termination']=='completed' and capture.returncode in accepted and capture.receipt['job_empty_observed'],name
 return capture
query="$p=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(cl|clang|link|ninja|ctest)\\.exe$' -or ($_.Name -eq 'cmake.exe' -and $_.CommandLine -like '*--build*') -or ($_.Name -eq 'MSBuild.exe' -and $_.CommandLine -notlike '*/nodemode:*') } | Select-Object Name,ProcessId,CreationDate); ConvertTo-Json -InputObject $p -Compress"
probe="""import os,json
names={'cmake','ninja','g++','c++','cc1plus','clang','clang++','ctest'};count=0
for name in os.listdir('/proc'):
 if name.isdigit():
  try:
   if open('/proc/'+name+'/comm',encoding='utf-8').read().strip() in names:count+=1
  except FileNotFoundError:pass
print(json.dumps(dict(mount_namespace=os.readlink('/proc/self/ns/mnt'),active_count=count)))"""
save()
try:
 marker=json.loads((W/'.facman-development-root.v1.json').read_text(encoding='utf-8'))
 assert marker['owner']=='facman-development' and marker['canonical_path']==str(W) and marker['task_id']=='task/facman-world-restore-retention-01'
 run('paths',['py','-3','-B','tools/workspace_hygiene.py','paths'],90)
 doctor=run('doctor',['py','-3','-B','tools/workspace_hygiene.py','doctor','--measure'],180,accepted=(0,1))
 resources=json.loads(doctor.stdout.decode('utf-8'))
 assert len(resources['task_roots'])<=8 and resources['task_root_bytes']+1024**3<=20*1024**3
 assert set(resources['violations'])<={'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
 assert shutil.disk_usage(W).free>=13*1024**3
 result['resources']=dict(owned_roots=len(resources['task_roots']),owned_bytes=resources['task_root_bytes'],free_bytes=shutil.disk_usage(W).free);save()
 counter=0
 while True:
  counter+=1
  windows=json.loads(run('windows-admission-'+str(counter),['pwsh','-NoProfile','-Command',query],45).stdout or b'[]')
  linux=json.loads(run('linux-admission-'+str(counter),['wsl','-d','Ubuntu-24.04','-u','root','--','python3','-B','-c',probe],45).stdout)
  if not windows and linux['active_count']==0:break
  result.update(status='WAITING_FOR_FOREIGN_HEALTHY_JOB_UNTOUCHED',foreign_windows_count=len(windows),foreign_linux_count=linux['active_count']);save();time.sleep(60)
 linux_e='/mnt/d/'+str(E)[3:].replace('\\','/')
 result['status']='LINUX_FOCUSED_NATIVE';save()
 run('linux',['wsl','-d','Ubuntu-24.04','-u','root','--','env','FACMAN_PARENT_MOUNT_NAMESPACE='+linux['mount_namespace'],
  'timeout','--signal=TERM','--kill-after=15s','3300s','unshare','--mount','--pid','--fork','--mount-proc','--kill-child=SIGKILL',
  'python3','-B',linux_e+'/reconciliation-held-metadata-linux-driver-02.py'],3360)
 local=json.loads((E/'reconciliation-held-metadata-linux-result-02.json').read_text(encoding='utf-8'))
 assert local['status']=='PASS_SCOPED_POSIX_HELD_METADATA_CHECKPOINT' and local['private_fixture_unmounted']
 result['linux_result_sha256']=sha(E/'reconciliation-held-metadata-linux-result-02.json');save()
 # Re-admit before the second cache; never overlap with healthy foreign work.
 while True:
  counter+=1
  windows=json.loads(run('windows-admission-'+str(counter),['pwsh','-NoProfile','-Command',query],45).stdout or b'[]')
  linux=json.loads(run('linux-admission-'+str(counter),['wsl','-d','Ubuntu-24.04','-u','root','--','python3','-B','-c',probe],45).stdout)
  if not windows and linux['active_count']==0:break
  result.update(status='WAITING_FOR_FOREIGN_HEALTHY_JOB_UNTOUCHED',foreign_windows_count=len(windows),foreign_linux_count=linux['active_count']);save();time.sleep(60)
 providers={n:sha(B/'Release'/n) for n in ('ulk.dll','usk.dll')}
 result['status']='WINDOWS_AFFECTED_NATIVE';save()
 run('windows-build',['cmake','--build',B,'--config','Release','--parallel','2','--target',
  'm1_three_repository_system_proof','flb_factorio_install_model_smoke','--','/nr:false'],1800)
 assert providers=={n:sha(B/'Release'/n) for n in providers};result['windows_provider_images_unchanged']=providers
 result['windows_native_images_sha256']={n:sha(B/'Release'/n) for n in ('m1_three_repository_system_proof.exe','flb_factorio_install_model_smoke.exe')};save()
 run('windows-native',['ctest','--test-dir',B,'-C','Release','--output-on-failure','--no-tests=error',
  '-R','^(m1_three_repository_system_proof|flb_factorio_install_model_smoke)$'],300)
 run('strict',['py','-3','-B','tools/strict_check.py'],1800)
 run('aide',['py','-3','-B','.aide/scripts/aide_lite.py','test'],600)
 run('diff',['git','diff','--check'],90)
 bound();result['status']='PASS_SCOPED_HELD_METADATA_CHECKPOINT_REPAIR'
except BaseException as error:result.update(status='FAIL_RETAINED',error=str(error),traceback=traceback.format_exc())
finally:
 save();print(json.dumps(dict(status=result['status'],commands=len(result['commands']),error=result.get('error'))))
raise SystemExit(0 if result['status'].startswith('PASS_') else 1)
