import hashlib,json,subprocess
from pathlib import Path
E=Path(__file__).resolve().parent;W=E.parent;R=Path(r'D:\Projects\Factorio\factorio-launcher')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_bytes())
packet=E/'reconciliation-held-metadata-author-packet-01.json'
assert sha(packet)=='0513a2de22f7222f35a19da5421e0aa61dea3334b1031541c4706d71e3ffe6a3'
p=load(packet)
assert p['base']=='8486d842e1d6a01926066bbee1d3746e367ba1e2' and not p['self_approval']
assert p['verdict']=='PASS_SCOPED_HELD_METADATA_CHECKPOINT_REPAIR'
for row in p['preserved_artifacts']:
 path=Path(row['path']).resolve(strict=True);assert path.is_relative_to(W) and sha(path)==row['sha256']
assert len(p['preserved_artifacts'])==164
for name,digest in p['source_files_sha256'].items():assert sha(R/name)==digest
assert set(p['source_files_sha256'])=={
 'runtime/factorio/application/handlers/setup.cpp','runtime/factorio/application/handlers/setup.h',
 'tests/native/m1_three_repository_system_proof.cpp'}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==p['base']
assert {x[3:] for x in subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).splitlines()}==set(p['source_files_sha256'])
assert sha(p['source_review']['path'])==p['source_review']['sha256']
assert sha(p['original_hosted_failure']['path'])==p['original_hosted_failure']['sha256']
assert p['original_hosted_failure']['original_journal_state_observed'] is False
assert p['original_hosted_failure']['duration_seconds']==0.25
for n in ('new_roots','new_caches','new_clones','new_worktrees'):assert p[n]==0
assert not p['CI_dispatched'] and not p['git_mutated'] and not p['real_game_touched']
scope=p['instrument_scope']
assert scope['internal_Cpp_thread_local'] and scope['worker_scoped_previous_callback_restored']
assert scope['ready_release_seconds']==5 and scope['default_enabled_pause_seconds']==2
assert scope['abort_release_join_on_exception']
assert not any(scope[k] for k in ('filesystem_observer_writes','refused_recovery_admitted','provider_ownership_policy_changed','external_or_CLI_API_added'))
linux=p['linux_validation'];windows=p['windows_and_gates']
assert sha(linux['path'])==linux['sha256'] and sha(windows['path'])==windows['sha256']
assert linux['Debug'] and not linux['coverage'] and not linux['physical_ext4']
assert linux['provider_source_inventory_unchanged'] and linux['all_namespace_children_empty'] and linux['private_fixture_unmounted']
assert len(linux['legitimate_new_provider_outputs'])==6
def winpath(value):
 assert value.startswith('/mnt/d/')
 return Path('D:/'+value[len('/mnt/d/'):])
for c in linux['commands']:
 assert c['termination']=='completed' and c['exit_code']==0 and c['namespace_children_empty']
 for stream in ('stdout','stderr'):assert sha(winpath(c[stream]))==c[stream+'_sha256']
assert len(linux['commands'])==6
m1=next(c for c in linux['commands'] if c['name']=='m1')
text=winpath(m1['stdout']).read_text(encoding='utf-8')
assert len(linux['diagnostics'])==3 and all(x in text for x in linux['diagnostics'])
assert 'held-metadata post-acquisition checkpoint: journal_state=requested steps=\n' in text
assert 'apply error=recovery_write_refused journal_state=recovery_required' in text
assert 'recovery inspection error= journal_state=recovery_required' in text
assert 'provider_entry_started' not in '\n'.join(linux['diagnostics'])
assert windows['Windows_native_tests']==2 and windows['strict']=='PASS' and windows['AIDE']=='PASS' and windows['diff']=='PASS'
assert windows['all_jobs_empty'] and not windows['all_member_natural_exit_claimed']
for c in windows['commands']:
 path=Path(c['receipt']);assert sha(path)==c['receipt_sha256']
 actual=load(path);assert actual['termination']=='completed' and actual['primary_stopped'] and actual['job_empty_observed']
 for stream in ('stdout','stderr'):assert sha(path.parent/actual[stream]['file'])==actual[stream]['sha256']
assert len(windows['commands'])==12
resource=p['resource_admission']
assert resource['owned_total_plus_peak_bytes']<resource['limit_bytes']==20*1024**3
assert resource['free_after_estimated_peak_bytes']>=resource['reserve_bytes']==12*1024**3
assert len(p['preserved_admission_stops'])==3

cpp=(R/'runtime/factorio/application/handlers/setup.cpp').read_text(encoding='utf-8')
native=(R/'tests/native/m1_three_repository_system_proof.cpp').read_text(encoding='utf-8')
assert 'thread_local ManagedInstallPauseObserver managed_install_pause_observer;' in cpp
assert 'observer.swap(managed_install_pause_observer)' in cpp
assert 'if (testing::managed_install_pause_observer)' in cpp
assert 'std::this_thread::sleep_for(std::chrono::seconds(seconds));' in cpp
assert 'abort_proof.store(true);' in native and 'release_worker();' in native
assert 'if (held_operation.valid())' in native and 'held_operation.get()' in native
assert 'held_identity.same_object(altered_identity)' in native
assert 'checkpoint.state != facman::transaction::State::requested' in native
assert 'inspector_status=' in native and 'journal_state=' in native
diff=subprocess.check_output(['git','diff','--','runtime/factorio/application/handlers/setup.cpp'],cwd=R,text=True)
assert 'session.refused' not in diff and 'State::refused' not in diff and 'ManagedInstallOperationLease' not in diff
out=E/'reconciliation-held-metadata-independent-review-01.json';assert not out.exists()
v=dict(schema='facman.independent_held_metadata_checkpoint_review.v1',verdict='PASS_SCOPED_SOURCE_FOR_REQUIRED_CURRENT_CI',
 base=p['base'],branch=p['branch'],packet_sha256=sha(packet),source_files_sha256=p['source_files_sha256'],reviewer_script_sha256=sha(__file__),
 non_authoring=True,preserved_artifacts=164,linux_affected_native_tests=2,windows_affected_native_tests=2,
 observed_requested_checkpoint=True,observed_recovery_required_no_entry=True,ordinary_recovery_passed=True,
 original_hosted_state_observed=False,causal_explanation='source/timing inference retained',
 default_pause_preserved=True,worker_callback_scoped=True,foreign_bytes_preserved=True,
 new_provider_modular_archives=6,provider_sources_pins_profile_preserved=True,
 required_current_CI_pending=True,produced_current_package_pending=True,workunit_closed=False,
 physical_ext4_claimed=False,real_game=False,all_member_natural_exit_claimed=False)
out.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8');print(json.dumps(v,indent=2))
