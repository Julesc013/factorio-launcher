import ctypes
from ctypes import wintypes as wt
import time

def notification_controls(tested):
    class NotificationControls(tested.OwnedControls):
        def click(self, hwnd):
            self.require_owned(hwnd)
            if 'BUTTON' not in self.text(hwnd, True).upper():
                raise AssertionError('Button notification target is not a native button')
            ancestors = self.ancestors(hwnd)
            if not all(x['visible'] and x['enabled'] for x in ancestors):
                raise AssertionError('Button notification requires visible and enabled owned control ancestors')
            parent = self.api.GetParent(hwnd)
            self.require_owned(parent)
            if len(ancestors) < 2 or ancestors[1]['hwnd'] != parent:
                raise AssertionError('Button notification parent differs from observed owned ancestors')
            identifier = self.api.GetDlgCtrlID(hwnd)
            event = dict(stage='WM_COMMAND/BN_CLICKED', pid=self.process.pid, hwnd=hwnd,
                text=self.text(hwnd), notification_parent=parent, notification_control_id=identifier,
                notification_wparam=identifier & 0xFFFF, notification_lparam=hwnd,
                ancestors=ancestors, **self.control_state(hwnd))
            self.events.append(event)
            if not self.api.PostMessageW(parent, 0x111, identifier & 0xFFFF, hwnd):
                event['post_succeeded'] = False
                raise ctypes.WinError(ctypes.get_last_error())
            event.update(post_succeeded=True, posted_at=time.monotonic())
    return NotificationControls
