import ast, hashlib, json, subprocess, sys
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
sys.path[:0] = [str(R / 'tests'), str(R)]
import test_windows_delivered_joined_gui as tested

source = R / 'tests/test_windows_delivered_joined_gui.py'
before = subprocess.check_output(['git', 'show', 'HEAD:tests/test_windows_delivered_joined_gui.py'], cwd=R)
(E / 'windows-current-dialog-source-before-01.py').write_bytes(before)
old_ast, new_ast = ast.parse(before), ast.parse(source.read_bytes())
for tree in (old_ast, new_ast):
    for cls in tree.body:
        if isinstance(cls, ast.ClassDef) and cls.name == 'OwnedControls':
            cls.body = [m for m in cls.body if not isinstance(m, ast.FunctionDef) or m.name not in ('click', 'wait')]
assert ast.dump(old_ast) == ast.dump(new_ast), 'Non-dispatch product oracle changed'

checks = []
def control():
    c = tested.OwnedControls.__new__(tested.OwnedControls)
    c.process = SimpleNamespace(pid=12, poll=lambda: None)
    c.events = []
    c.require_owned = lambda hwnd: None
    c.text = lambda hwnd, class_name=False: 'WindowsForms10.BUTTON' if class_name else 'Cancel'
    states = [dict(hwnd=101, parent_hwnd=20, root_hwnd=10, control_id=0x123456, visible=True, enabled=True),
              dict(hwnd=20, parent_hwnd=10, root_hwnd=10, control_id=20, visible=True, enabled=True),
              dict(hwnd=10, parent_hwnd=None, root_hwnd=10, control_id=0, visible=True, enabled=True)]
    c.ancestors = lambda hwnd: deepcopy(states)
    c.control_state = lambda hwnd: {k:v for k,v in states[0].items() if k != 'hwnd'} | dict(observed_at=0)
    posted = []
    c.api = SimpleNamespace(GetParent=lambda hwnd:20, GetDlgCtrlID=lambda hwnd:0x123456,
        PostMessageW=lambda *args: posted.append(args) or 1)
    return c, states, posted

c, states, posted = control()
c.click(101)
assert posted == [(20, 0x111, 0x3456, 101)]
assert len(c.events) == 1 and c.events[0]['post_succeeded']
assert c.events[0]['notification_control_id'] == 0x123456
assert c.events[0]['notification_lparam'] == 101
checks.append('one exact-parent ordinary notification binds full ID and button HWND')

def expect_rejection(name, mutate, expected=AssertionError):
    c, states, posted = control()
    mutate(c, states)
    try:
        c.click(101)
    except expected:
        pass
    else:
        raise AssertionError('Unsafe target accepted: ' + name)
    assert not posted and not c.events
    checks.append(name)

expect_rejection('hidden target', lambda c,s:s[0].update(visible=False))
expect_rejection('disabled ancestor', lambda c,s:s[1].update(enabled=False))
expect_rejection('nonbutton', lambda c,s:setattr(c,'text',lambda hwnd, class_name=False:'WindowsForms10.EDIT'))
def foreign(which):
    def mutate(c, states):
        def retained(hwnd):
            if hwnd == which:
                raise tested.ControlGone('foreign or disposed exact identity')
        c.require_owned = retained
    return mutate
for which, label in [(101, 'foreign target'), (20, 'foreign parent'), (10, 'foreign root')]:
    expect_rejection(label, foreign(which), tested.ControlGone)
expect_rejection('parent changed after ancestor observation', lambda c,s:setattr(c.api,'GetParent',lambda hwnd:99))
expect_rejection('control ID changed after ancestor observation', lambda c,s:setattr(c.api,'GetDlgCtrlID',lambda hwnd:0x123457))
expect_rejection('root mismatch inside ancestor chain', lambda c,s:s[1].update(root_hwnd=99))
expect_rejection('ancestor chain does not start at target', lambda c,s:s[0].update(hwnd=102))
expect_rejection('ancestor chain does not end at root', lambda c,s:s[-1].update(hwnd=11))
def final_disabled(c, states):
    original = c.control_state
    c.control_state = lambda hwnd: original(hwnd) | dict(enabled=False)
expect_rejection('target disabled after initial ancestor observation', final_disabled)

c, states, posted = control()
c.api.PostMessageW = lambda *args: posted.append(args) or 0
try:
    c.click(101)
except OSError:
    pass
else:
    raise AssertionError('Failed notification reported success')
assert len(posted) == len(c.events) == 1 and c.events[0]['post_succeeded'] is False
checks.append('failed queue submission remains FAIL and is never retried')

for stage in ('BM_CLICK', 'WM_COMMAND/BN_CLICKED'):
    c, states, posted = control()
    c.deadline = float('inf')
    c.events.append(dict(stage=stage, pid=12, hwnd=101))
    c.enumerate = lambda observe=False: []
    try:
        c.wait(lambda: None, 'controlled diagnostic deadline', seconds=0)
    except AssertionError as error:
        assert str(error) == 'Owned GUI did not reach controlled diagnostic deadline'
    else:
        raise AssertionError('Original timeout disappeared')
    assert c.events[-1]['stage'] == 'timeout: last click target' and c.events[-1]['hwnd'] == 101
    checks.append('last-click diagnostics preserve original timeout for ' + stage)

receipt = dict(schema='facman.windows_delivered_notification_unit.v1', result='PASS',
    qualification='identity/refusal/diagnostic safety checks; no simulated backend acceptance',
    source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    unchanged_oracle_AST_except_click_and_wait=True, checks=checks)
(E / 'windows-current-dialog-frozen-unit-result-01.json').write_text(json.dumps(receipt, indent=2))
print(json.dumps(receipt, indent=2))
