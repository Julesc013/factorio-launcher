$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
$ilOpcodes = @{}
[System.Reflection.Emit.OpCodes].GetFields() | ForEach-Object {
    $ilOp = $_.GetValue($null)
    $ilOpcodes[[int]$ilOp.Value -band 65535] = $ilOp
}
$ilRows = @()
foreach ($ilSpec in @(@([System.Windows.Forms.ButtonBase], 'WndProc'), @([System.Windows.Forms.Button], 'PerformClick'), @([System.Windows.Forms.Control], 'CanSelectCore'))) {
    $ilMethod = $ilSpec[0].GetMethod($ilSpec[1], [System.Reflection.BindingFlags]'Instance, NonPublic, Public')
    if (!$ilMethod) { continue }
    $ilBytes = $ilMethod.GetMethodBody().GetILAsByteArray()
    $ilAt = 0
    while ($ilAt -lt $ilBytes.Length) {
        $ilOffset = $ilAt
        $ilCode = [int]$ilBytes[$ilAt++]
        if ($ilCode -eq 254) { $ilCode = 65280 -bor [int]$ilBytes[$ilAt++] }
        $ilOp = $ilOpcodes[$ilCode]
        $ilOperand = $null
        $ilSize = 0
        switch ([string]$ilOp.OperandType) {
            'InlineNone' { }
            'ShortInlineBrTarget' { $ilSize=1; $ilDelta=[int]$ilBytes[$ilAt]; if ($ilDelta -gt 127) {$ilDelta -= 256}; $ilOperand=$ilDelta + $ilAt + 1 }
            'InlineBrTarget' { $ilSize=4; $ilOperand=[BitConverter]::ToInt32($ilBytes,$ilAt) + $ilAt + 4 }
            'InlineMethod' { $ilSize=4; $ilOperand=[string]$ilMethod.Module.ResolveMethod([BitConverter]::ToInt32($ilBytes,$ilAt)) }
            'InlineField' { $ilSize=4; $ilOperand=[string]$ilMethod.Module.ResolveField([BitConverter]::ToInt32($ilBytes,$ilAt)) }
            'InlineType' { $ilSize=4; $ilOperand=[string]$ilMethod.Module.ResolveType([BitConverter]::ToInt32($ilBytes,$ilAt)) }
            'InlineI' { $ilSize=4; $ilOperand=[BitConverter]::ToInt32($ilBytes,$ilAt) }
            'ShortInlineI' { $ilSize=1; $ilOperand=[int]$ilBytes[$ilAt] }
            'ShortInlineVar' { $ilSize=1; $ilOperand=[int]$ilBytes[$ilAt] }
            'InlineVar' { $ilSize=2; $ilOperand=[BitConverter]::ToUInt16($ilBytes,$ilAt) }
            'InlineSwitch' { $ilSize=4 + 4 * [BitConverter]::ToInt32($ilBytes,$ilAt) }
            default { throw "Unsupported IL operand $($ilOp.OperandType)" }
        }
        $ilAt += $ilSize
        $ilRows += [pscustomobject]@{type=[string]$ilSpec[0]; method=$ilSpec[1]; offset=$ilOffset; opcode=$ilOp.Name; operand=$ilOperand}
    }
}
$ilAssembly = [System.Windows.Forms.ButtonBase].Assembly
[pscustomobject]@{assembly=$ilAssembly.FullName; image=$ilAssembly.Location; sha256=(Get-FileHash -Algorithm SHA256 -LiteralPath $ilAssembly.Location).Hash.ToLowerInvariant(); instructions=$ilRows} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath 'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e\evidence\windows-current-dialog-winforms-il-01.json'
$ilRows | Where-Object { $_.method -eq 'WndProc' -and $_.offset -lt 85 -or $_.method -eq 'PerformClick' } | Format-Table -AutoSize
