import ast, base64, hashlib, json, re, runpy, sys, zlib
from pathlib import Path
R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
W = E.parent
sys.path[:0] = [str(R / 'tests'), str(R)]
import test_make_ready_joined as joined
sha = lambda b: hashlib.sha256(b).hexdigest()
source = R / 'tests/test_windows_delivered_joined_gui.py'
old, new = [ast.parse(p.read_bytes()) for p in (E / 'windows-current-dialog-source-before-01.py', source)]
def wait(tree):
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'OwnedControls')
    return next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == 'wait')
old_wait, new_wait = wait(old), wait(new)
old_compare, = [n for n in ast.walk(old_wait) if isinstance(n, ast.Compare) and any(isinstance(x, ast.Constant) and x.value == 'BM_CLICK' for x in n.comparators)]
class RestoreHistoricalStage(ast.NodeTransformer):
    def visit_Compare(self, node):
        if (isinstance(node.comparators[0], ast.Tuple) and
                [x.value for x in node.comparators[0].elts if isinstance(x, ast.Constant)] == ['BM_CLICK', 'WM_COMMAND/BN_CLICKED']):
            return old_compare
        return self.generic_visit(node)
assert ast.dump(old_wait) == ast.dump(RestoreHistoricalStage().visit(new_wait))
extract = runpy.run_path(str(E / 'windows-current-dialog-log-custody-01.py'))['extract']
baseline = extract(E / 'windows-current-dialog-baseline-regression-01.log', '002824ea9f2ac4d3844ec5141b455d5733a8008b')
positive = extract(E / 'windows-current-dialog-frozen-regression-01.log', '002824ea9f2ac4d3844ec5141b455d5733a8008b')
negative = json.loads((E / 'windows-current-dialog-frozen-negative-result-01.json').read_bytes())
assert negative['source_sha256'] == sha(source.read_bytes())
negative_log = Path(negative['log'])
assert sha(negative_log.read_bytes()) == negative['log_sha256']
custody, = [json.loads(line.split(' ',1)[1]) for line in negative_log.read_text().splitlines() if line.startswith('delivered-windows-gui-custody ')]
assert len(custody['payload_base64']) < 512 * 1024
compressed = base64.b64decode(custody['payload_base64'], validate=True)
assert sha(compressed) == custody['compressed_sha256']
decoder = zlib.decompressobj()
canonical = decoder.decompress(compressed, 12 * 1024 ** 2 + 1)
assert decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail and len(canonical) < 12 * 1024 ** 2
assert sha(canonical) == custody['canonical_sha256'] == negative['custody_sha256']
manifest = json.loads(canonical)
assert len(manifest) == custody['file_count']
for name, item in manifest.items():
    assert name == 'result.json' or re.fullmatch(r'objects/[0-9a-f]{64}', name)
    data = base64.b64decode(item['bytes_base64'], validate=True)
    assert len(data) == item['size_bytes'] and sha(data) == item['sha256']
    assert data == (Path(negative['consumer']) / 'evidence' / name).read_bytes()
    assert name == 'result.json' or name == 'objects/' + sha(data)
assert sum(item['size_bytes'] for item in manifest.values()) < 12 * 1024 ** 2
assert manifest['result.json']['sha256'] == negative['result_sha256']
record = json.loads((Path(negative['consumer']) / 'evidence/result.json').read_bytes())
assert record['result'] == 'FAIL' and 'controlled failure-custody timeout' in record['exception']
assert 'cleanup_exception' not in record
workspace = Path(negative['consumer']) / 'workspace'
after = {p.relative_to(workspace).as_posix():dict(sha256=sha(p.read_bytes()), size_bytes=p.stat().st_size,
    file_identity=joined.file_identity(p)) for p in sorted(workspace.rglob('*')) if p.is_file()}
before, = [s['inventory'] for s in record['snapshots'] if s['stage'] == 'prepared fixture']
assert after == before
package = W / 't/j3/g'
manifest = package / 'manifest/hashes.sha256'
expected = dict(line.split('  ',1)[::-1] for line in manifest.read_text().splitlines())
actual = {p.relative_to(package).as_posix():sha(p.read_bytes()) for p in sorted(package.rglob('*')) if p.is_file()}
assert actual == expected | {'manifest/hashes.sha256':sha(manifest.read_bytes())}
units = json.loads((E / 'windows-current-dialog-frozen-unit-result-01.json').read_bytes())
assert units['source_sha256'] == sha(source.read_bytes()) and len(units['checks']) == 16
audit = dict(schema='facman.windows_delivered_notification_author_audit.v1', verdict='PASS_BOUNDED_SOURCE_QUALIFICATION',
    author=True, independent_review=False, source_sha256=sha(source.read_bytes()),
    source_wait_AST_unchanged_except_historical_and_current_stage_recognition=True,
    source_product_oracle_AST_unchanged=True, deadlines_seconds=35, original_GUI_budget_seconds=300,
    baseline=baseline, frozen_positive=positive, controlled_negative_result='FAIL',
    controlled_negative_bounded_custody_validated=True,
    controlled_negative_normal_exit=True, controlled_negative_whole_workspace_unchanged=True,
    controlled_negative_workspace_file_count=len(after), complete_current_package_hash_closure=actual,
    package_file_count=len(actual), unit_checks=units['checks'],
    hosted_failure_cause_unobserved=True, hosted_current_head_factory_qualification_pending=True)
(E / 'windows-current-dialog-final-audit-01.json').write_text(json.dumps(audit, indent=2))
print(json.dumps({k:v for k,v in audit.items() if k not in ('complete_current_package_hash_closure', 'unit_checks', 'baseline', 'frozen_positive')}, indent=2))
