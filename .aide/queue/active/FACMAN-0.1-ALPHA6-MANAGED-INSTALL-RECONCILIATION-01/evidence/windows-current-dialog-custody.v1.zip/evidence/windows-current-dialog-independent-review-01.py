import ast, base64, hashlib, json, re, runpy, subprocess, zlib
from pathlib import Path
R=Path(r"D:\Projects\Factorio\factorio-launcher")
E=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
packet=E/"windows-current-dialog-author-packet-01.json"
assert sha(packet)=="406005272f22916e5d9939420730876f57d790a8bbc0fd39cd73b0d68dc3c360"
p=json.loads(packet.read_bytes())
assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=R).decode().strip()==p["head"]=="1882e1434aa636310c7d6975be405833da162f11"
for row in p["author_files"]:
    assert sha(R/row["path"])==row["sha256"]
for row in p["preserved_artifacts"]:
    path=Path(row["path"]).resolve()
    assert path.is_relative_to(E.resolve()) and sha(path)==row["sha256"]
test="tests/test_windows_delivered_joined_gui.py"
old=subprocess.check_output(["git","show","HEAD:"+test],cwd=R).decode("utf-8")
new=(R/test).read_text(encoding="utf-8")
def methods(text):
    return {f"{node.name}.{method.name}":ast.dump(method,include_attributes=False)
        for node in ast.parse(text).body if isinstance(node,ast.ClassDef)
        for method in node.body if isinstance(method,(ast.FunctionDef,ast.AsyncFunctionDef))}
a,b=methods(old),methods(new)
assert a.keys()==b.keys()
assert {k for k in a if a[k]!=b[k]}=={"OwnedControls.click","OwnedControls.wait"}
positive=json.loads((E/"windows-current-dialog-frozen-regression-result-01.json").read_bytes())
negative=json.loads((E/"windows-current-dialog-frozen-negative-result-01.json").read_bytes())
units=json.loads((E/"windows-current-dialog-frozen-unit-result-01.json").read_bytes())
for record in (positive,negative,units):
    assert record["source_sha256"]==sha(R/test)
for record in (positive,negative):
    assert sha(record["log"])==record["log_sha256"]
accepted=runpy.run_path(str(E/"windows-current-dialog-log-custody-01.py"))["extract"](
    Path(positive["log"]),"002824ea9f2ac4d3844ec5141b455d5733a8008b",
    E/"windows-current-dialog-independent-positive-01")
assert accepted["actual_GUI_sessions"]==2 and accepted["complete_owner_effects"]==2
assert positive["observed_packaged_backends"]==68 and positive["fixture_cli_calls"]==8
lines=Path(negative["log"]).read_text(encoding="utf-8").splitlines()
custody,=[json.loads(l.split(" ",1)[1]) for l in lines if l.startswith("delivered-windows-gui-custody ")]
compact,=[json.loads(l.split(" ",1)[1]) for l in lines if l.startswith("delivered-windows-gui-result ")]
compressed=base64.b64decode(custody["payload_base64"],validate=True)
assert hashlib.sha256(compressed).hexdigest()==custody["compressed_sha256"]
decoder=zlib.decompressobj()
canonical=decoder.decompress(compressed,12*1024**2+1)
assert decoder.eof and not decoder.unconsumed_tail and not decoder.unused_data and len(canonical)<12*1024**2
assert hashlib.sha256(canonical).hexdigest()==custody["canonical_sha256"]==compact["custody_sha256"]
manifest=json.loads(canonical)
assert len(manifest)==custody["file_count"]==24
files={}
for name,item in manifest.items():
    assert name=="result.json" or re.fullmatch(r"objects/[0-9a-f]{64}",name)
    data=base64.b64decode(item["bytes_base64"],validate=True)
    assert len(data)==item["size_bytes"] and hashlib.sha256(data).hexdigest()==item["sha256"]
    if name.startswith("objects/"):assert name=="objects/"+item["sha256"]
    files[name]=data
result=json.loads(files["result.json"])
assert hashlib.sha256(files["result.json"]).hexdigest()==negative["result_sha256"]==compact["result_sha256"]
assert result["result"]==compact["result"]=="FAIL" and "controlled failure-custody timeout" in result["exception"]
assert not result.get("cleanup_exception")
for session in result["sessions"]:
    terminal=session["terminal"]
    assert terminal["exit_code"]==0 and not terminal["safety_termination"] and terminal["owned_job_active_processes"]==0
assert units["result"]=="PASS" and len(units["checks"])==16 and units["unchanged_oracle_AST_except_click_and_wait"]
review=dict(schema="facman.windows_button_notification.independent_review.v1",
    verdict="PASS_OWNED_BUTTON_NOTIFICATION_FOR_REQUIRED_CURRENT_CI",non_authoring=True,
    author=p["author"],reviewer="/root",author_packet_sha256=sha(packet),
    authored_files_sha256={r["path"]:r["sha256"] for r in p["author_files"]},
    source_head=p["head"],actual_GUI_sessions=2,actual_packaged_backend_children=68,complete_owner_effects=2,
    frozen_FAIL_files=24,identity_checks=16,current_head_factory_pending=True,hosted_internal_cause_observed=False,
    runtime_or_provider_changed=False,workunit_closed=False,
    review=[
        "Actual hosted421 FAIL retains matching revision, visible/enabled owned button/ancestors and a successful native-click post; exact internal cause remains unobserved.",
        "Only click invocation and its dual historical/current timeout diagnostics change. Complete product-test AST and original35-second predicates are unchanged.",
        "One ordinary WM_COMMAND/BN_CLICKED binds direct parent, full observed ID, root, lParam and live ownership/visibility/enabled ancestors to the registered production handler.",
        "Inspected application button path: no app Validating/AutoValidate/CausesValidation hooks; dialogs, intent/domain/readiness validation and stale/cancellation refusal remain the oracle.",
        "Reviewed decoder diff: complete original PASS assertions retained; additional notification ownership bindings and historical/current Cancel compatibility only.",
        "Independently decoded final positive two-session owner/effect oracle and controlled truthful FAIL with normal zero-job exit;16 focused identity checks pass.",
        "Reused package is historical002824, not current421 runtime. Old baseline also passes; new current-head factory remains mandatory.",
        "No focus takeover, retry, timeout increase, runtime/provider/policy/control authority change, full maintenance/Beta/RC closure."
    ])
out=E/"windows-current-dialog-independent-review-01.json"
assert not out.exists()
out.write_text(json.dumps(review,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"verdict":review["verdict"],"review_sha256":sha(out),"sessions":2,"backend_children":68,"controlled_fail_files":24}))
