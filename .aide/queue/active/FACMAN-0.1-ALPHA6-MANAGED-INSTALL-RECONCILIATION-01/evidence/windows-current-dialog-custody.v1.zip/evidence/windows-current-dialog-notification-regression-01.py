import base64
from contextlib import redirect_stdout
import hashlib
import json
import os
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
import zlib

R = Path(r'D:\Projects\Factorio\factorio-launcher')
W = Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e')
G = W / 't/j3/g'
consumer = W / 't/j3/ccurrent13'
consumer.mkdir(exist_ok=False)
sys.path[:0] = [str(R / 'tests'), str(R)]
import test_windows_delivered_joined_gui as tested
import delivered_environment_reconstruction as reconstruction

log_path = W / 'evidence/windows-current-dialog-notification-regression-01.log'
assert not log_path.exists()
import runpy
NotificationControls = runpy.run_path(str(W / 'evidence/windows-current-dialog-notification-controls-01.py'))['notification_controls'](tested)
test_result = unittest.TestResult()
# Focused GUI regression: the prior GUI oracle remains unmodified. The three
# unchanged portable-environment scenarios are outside this diagnostic change's
# local regression scope; required CI still executes all of them from source.
with log_path.open('w', encoding='utf-8') as stream, redirect_stdout(stream), \
     patch.dict(os.environ, FACMAN_DELIVERED_GUI_PACKAGE=str(G),
         FACMAN_DELIVERED_GUI_CONSUMER=str(consumer)), \
     patch.object(reconstruction, 'SCENARIOS', ()), patch.object(tested, 'OwnedControls', NotificationControls):
    tested.WindowsDeliveredJoinedGuiTests(
        'test_actual_joined_controls_dispatch_production_packaged_backend').run(test_result)

assert test_result.testsRun == 1 and not test_result.failures and not test_result.errors, \
    repr(test_result.failures + test_result.errors)
lines = log_path.read_text().splitlines()
prefix = 'delivered-windows-gui-custody '
custody, = [json.loads(line[len(prefix):]) for line in lines if line.startswith(prefix)]
compressed = base64.b64decode(custody['payload_base64'], validate=True)
assert hashlib.sha256(compressed).hexdigest() == custody['compressed_sha256']
canonical = zlib.decompress(compressed)
assert hashlib.sha256(canonical).hexdigest() == custody['canonical_sha256']
manifest = json.loads(canonical)
assert len(manifest) == custody['file_count']
raw = {}
for name, item in manifest.items():
    data = base64.b64decode(item['bytes_base64'], validate=True)
    assert len(data) == item['size_bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
    assert data == (consumer / 'evidence' / name).read_bytes()
    raw[name] = data
record = json.loads(raw['result.json'])
assert record['result'] == 'PASS' and 'exception' not in record and 'cleanup_exception' not in record
assert record['package_closure_unchanged'] and len(record['sessions']) == 2
for session in record['sessions']:
    terminal = session['terminal']
    assert terminal['exit_code'] == 0 and not terminal['safety_termination']
    assert terminal['owned_job_active_processes'] == 0
    assert terminal['launch']['exact_job_membership_before_resume']
    assert all(event['post_succeeded'] for event in session['events'] if event['stage'] == 'WM_COMMAND/BN_CLICKED')
    assert all(all(item['visible'] and item['enabled'] for item in event['ancestors'])
        for event in session['events'] if event['stage'] == 'WM_COMMAND/BN_CLICKED')
    passive_show, = [event for event in session['events'] if event['stage'] == 'owned main shown offscreen']
    assert passive_show['flags'] == 0x55 and passive_show['visible']
    assert passive_show['root_hwnd'] == passive_show['hwnd']
    assert passive_show['offscreen_rectangle']['right'] < -10000
    assert passive_show['offscreen_rectangle']['bottom'] < -10000
for snapshot in record['snapshots']:
    for name, item in snapshot['inventory'].items():
        assert raw['objects/' + item['sha256']]
prefix = 'delivered-windows-gui-result '
summary, = [json.loads(line[len(prefix):]) for line in lines if line.startswith(prefix)]
assert summary['result'] == 'PASS'
assert summary['result_sha256'] == hashlib.sha256(raw['result.json']).hexdigest()
processes = [process for session in record['sessions'] for process in session['terminal']['backend_processes']]
receipt = dict(schema='facman.windows_delivered_gui_diagnostic_pass_regression.v1', result='PASS_GUI_ONLY_REGRESSION',
    qualification='reused-source regression; two-session GUI oracle only, not fresh-head factory or full test acceptance',
    omitted_only_in_external_driver=['three unchanged portable-environment scenarios'],
    source_sha256=hashlib.sha256((R / 'tests/test_windows_delivered_joined_gui.py').read_bytes()).hexdigest(),
    consumer=str(consumer), log=str(log_path), log_sha256=hashlib.sha256(log_path.read_bytes()).hexdigest(),
    result_sha256=summary['result_sha256'], custody_sha256=custody['canonical_sha256'],
    file_count=len(raw), log_bytes=log_path.stat().st_size,
    gui_pids=[session['terminal']['pid'] for session in record['sessions']],
    total_observed_owned_descendants=len(processes),
    observed_packaged_backends=sum(p['role'] == 'packaged_backend' for p in processes),
    observed_console_hosts=sum(p['role'] == 'windows_console_host' for p in processes),
    fixture_cli_calls=len(record['calls']),
    passive_shows=[event for session in record['sessions'] for event in session['events']
        if event['stage'] == 'owned main shown offscreen'],
    normal_exits=True, owned_job_active_processes=0, package_closure_unchanged=True,
    completed_owner_commands=[item['owner_command'] for item in record['outcome']['action_payload']['completed_components']])
receipt_path = W / 'evidence/windows-current-dialog-notification-regression-result-01.json'
assert not receipt_path.exists()
receipt_path.write_text(json.dumps(receipt, indent=2))
print(json.dumps({key: value for key, value in receipt.items() if key != 'passive_shows'}, indent=2))
