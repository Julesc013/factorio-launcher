import base64, hashlib, json, re, zlib
from pathlib import Path
E = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
log = E / 'managed-install-coordination-failed-windows-job-115922317551.log'
assert sha(log.read_bytes()) == '788e753b3be538f26e577dbf63b6def2cb98fb40889e802de18d313a7dc85022'
lines = log.read_text(encoding='utf-8').splitlines()
def row(prefix):
    rows = [json.loads(line.split(prefix, 1)[1]) for line in lines if prefix in line]
    assert len(rows) == 1
    return rows[0]
c = row('delivered-windows-gui-custody ')
s = row('delivered-windows-gui-result ')
assert len(c['payload_base64']) < 512 * 1024
compressed = base64.b64decode(c['payload_base64'], validate=True)
assert sha(compressed) == c['compressed_sha256']
d = zlib.decompressobj()
canonical = d.decompress(compressed, 12 * 1024 ** 2 + 1)
assert d.eof and not d.unused_data and not d.unconsumed_tail and len(canonical) < 12 * 1024 ** 2
assert sha(canonical) == c['canonical_sha256'] == s['custody_sha256']
manifest = json.loads(canonical)
assert len(manifest) == c['file_count']
out = E / 'windows-current-dialog-actual-failure-01'
out.mkdir()
(out / 'objects').mkdir()
files = {}
for name, item in manifest.items():
    assert name == 'result.json' or re.fullmatch(r'objects/[0-9a-f]{64}', name)
    b = base64.b64decode(item['bytes_base64'], validate=True)
    assert len(b) == item['size_bytes'] and sha(b) == item['sha256']
    assert name == 'result.json' or name == 'objects/' + sha(b)
    files[name] = b
    (out / name).write_bytes(b)
assert sum(map(len, files.values())) < 12 * 1024 ** 2
assert sha(files['result.json']) == s['result_sha256']
r = json.loads(files['result.json'])
assert r['result'] == s['result'] == 'FAIL'
for snap in r['snapshots']:
    for item in snap['inventory'].values():
        assert len(files['objects/' + item['sha256']]) == item['size_bytes']
summary = dict(compact=s, decoded_files=len(files), decoded_bytes=sum(map(len, files.values())),
    exception=r.get('exception'), cleanup_exception=r.get('cleanup_exception'),
    package_closure_unchanged=r.get('package_closure_unchanged'),
    events=[x['events'] for x in r['sessions']],
    terminals=[x.get('terminal') for x in r['sessions']],
    snapshot_stages=[x['stage'] for x in r['snapshots']])
(E / 'windows-current-dialog-actual-failure-summary-01.json').write_text(json.dumps(summary, indent=2))
print(json.dumps({k:v for k,v in summary.items() if k not in ('events', 'terminals')}, indent=2))
for i, session in enumerate(r['sessions']):
    print('session', i, 'terminal', {k:v for k,v in session.get('terminal', {}).items() if k not in ('backend_processes', 'launch')})
    for event in session['events']:
        print(json.dumps(event))
