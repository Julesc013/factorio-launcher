import hashlib,io,json,os,shutil,stat,sys,traceback,zipfile,subprocess,time,datetime
from pathlib import Path,PurePosixPath
R=Path(r'D:\Projects\Factorio\factorio-launcher')
W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e')
E=W/'evidence';G=W/'t/j3/g4';F=E/'managed-move-preview-delivered-public-01'
sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools import provider_canary_process as owned
from tools.package.runtime_identity import require_backend_identity
sha=lambda b:hashlib.sha256(b).hexdigest();P=E/'managed-move-preview-delivered-plan-03.json'
plan=json.loads(P.read_bytes());assert sys.argv[1:]==['--plan-sha256',sha(P.read_bytes())]
review=json.loads((E/'managed-move-preview-delivered-root-review-03.json').read_bytes())
assert review['verdict']=='ADMIT_EXACT_PR432_PACKAGED_MOVE_PREVIEW' and review['plan_sha256']==sha(P.read_bytes()) and review['script_hashes']==plan['script_hashes']
for name,h in plan['script_hashes'].items():assert sha((E/name).read_bytes())==h,name
for name,h in plan['module_hashes'].items():assert sha((R/name).read_bytes())==h,name
for name,h in plan['evidence_inputs'].items():assert sha((E/name).read_bytes())==h,name
for row in (plan['producer_pattern'],plan['resource_probe']):assert sha(Path(row['path']).read_bytes())==row['sha256']
for name,row in plan['tools'].items():
    assert str(Path(shutil.which(name)).resolve()).casefold()==row['path'].casefold() and sha(Path(row['path']).read_bytes())==row['sha256'],name
assert str(Path(sys.executable).resolve()).casefold()==plan['python']['path'].casefold() and sha(Path(sys.executable).read_bytes())==plan['python']['sha256']
assert sha((W/'.facman-development-root.v1.json').read_bytes())==plan['marker_sha256']
def path_guard(path,absent=False):
    path=Path(path)
    assert path.is_absolute() and os.path.normcase(os.path.commonpath((str(W),str(path))))==os.path.normcase(str(W)),str(path)
    for ancestor in reversed((path,*path.parents)):
        if os.path.lexists(ancestor):
            status=ancestor.lstat()
            assert not ancestor.is_symlink() and not getattr(status,'st_file_attributes',0)&0x400,'redirected existing ancestor: '+str(ancestor)
    if absent:assert not os.path.lexists(path),'owned leaf already exists: '+str(path)
path_guard(E);path_guard(W/'t');path_guard(G,True);path_guard(F,True)
os.environ.update(FACMAN_TASK_ROOT=str(W),FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),TMPDIR=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1')
environment={k:v for k,v in os.environ.items() if not k.upper().startswith(('FACMAN_TEST','FACMAN_SETUP'))}
environment['GIT_OPTIONAL_LOCKS']='0'

GiB=1024**3
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def guard(plan,env):
    for name,h in plan['module_hashes'].items():assert sha((R/name).read_bytes())==h,name
    for name,h in plan['script_hashes'].items():assert sha((E/name).read_bytes())==h,name
    for name,h in plan['evidence_inputs'].items():assert sha((E/name).read_bytes())==h,name
    assert sha((W/'.facman-development-root.v1.json').read_bytes())==plan['marker_sha256']
    for p in (E,W/'t',G,F):path_guard(p)

def capture(command, env, cwd=R, timeout=45):
    result = subprocess.run(command, cwd=cwd, env=env, capture_output=True,
                            timeout=timeout, text=True, encoding='utf-8', errors='strict')
    if len(result.stdout.encode()) + len(result.stderr.encode()) > 16*1024**2:
        raise ValueError('bounded read-only observation exceeded')
    if result.returncode:
        raise RuntimeError('read-only observation failed: ' + repr(command) + ': ' + result.stderr[:2048])
    return result.stdout.strip()

def directory_bytes(path):
    total = 0
    pending = [Path(path)]
    while pending:
        directory = pending.pop()
        for item in directory.iterdir():
            stat = item.lstat()
            if item.is_symlink() or getattr(stat, 'st_file_attributes', 0) & 0x400:
                continue  # Never traverse a redirect; fixture oracle checks its identity separately.
            if item.is_dir():
                pending.append(item)
            elif item.is_file():
                total += stat.st_size
    return total

def fresh_storage(plan, roots=None, additional=None):
    selected = roots if roots is not None else plan['known_task_roots']
    tasks = W.parent
    actual = {str(p.resolve()).casefold() for p in tasks.iterdir() if p.is_dir()}
    expected = {str(Path(p).resolve()).casefold() for p in selected}
    if actual != expected or len(actual) > 8:
        raise ValueError('task root topology changed; no cleanup authorized')
    total = 0
    for root in selected:
        path = Path(root)
        if path.is_symlink() or path.stat().st_file_attributes & 0x400:
            raise ValueError('task root is redirected')
        marker = json.loads((path/'.facman-development-root.v1.json').read_bytes())
        if marker['schema'] != 'facman.development_root.v1' or marker['owner'] != 'facman-development':
            raise ValueError('task root ownership invalid')
        total += directory_bytes(path)
    free = shutil.disk_usage(W).free
    extra = plan['limits']['new_total_bytes'] if additional is None else additional
    if total + extra >= plan['limits']['task_root_bytes'] or free - extra <= 12*GiB:
        raise ValueError('fresh root-byte/reserve admission failed')
    return {'utc': utc(), 'task_roots': len(selected), 'measured_root_bytes': total,
            'additional_peak_bytes': extra, 'projected_root_bytes': total+extra,
            'free_bytes': free, 'free_after_peak_bytes': free-extra}

LINUX = """import json,os
active=[]
for n in os.listdir('/proc'):
 if n.isdigit():
  try:
   comm=open('/proc/'+n+'/comm').read().strip()
   if comm in {'facman','factorio','cmake','ninja','make','cc1plus','ctest','g++','c++','clang','clang++','gcc','cc','ld','ld.lld','as'} or comm.startswith(('flb_','facman_','m1_three_repos')):
    active.append(dict(pid=int(n),command=open('/proc/'+n+'/cmdline','rb').read().decode(errors='replace').replace(chr(0),' ')))
  except FileNotFoundError:pass
print(json.dumps(dict(mount_namespace=os.readlink('/proc/self/ns/mnt'),active=active)))"""

def wait_for_resources(plan, env, phase, extra):
    output = E/('managed-move-preview-delivered-resources-' + phase + '-03.json')
    first, count = None, 0
    with output.open('x+b') as retained:
        while True:
            sample = json.loads(capture(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command',
                (E/'managed-move-plan-resource-probe-01.ps1').read_text(encoding='utf-8')], env))
            if sample['Identity'].casefold() != r'BLACKGLASS-WIN1\Jules'.casefold():
                raise ValueError('resource observation under unexpected Windows identity')
            if type(sample['ProbePID']) is not int or not sample['ProbeCreationUtc']:
                raise ValueError('resource probe has no exact self identity')
            def own(row, key):
                return row[key] == sample['ProbePID'] and row.get('CreationUtc') == sample['ProbeCreationUtc']
            sample['OwnExactProbeCPU'] = [r for r in sample['HeavyCPU'] if own(r, 'PID')]
            sample['OwnExactProbeIO'] = [r for r in sample['HeavyIO'] if own(r, 'IDProcess')]
            if any(r['Name'].casefold() not in ('powershell', 'pwsh') for r in sample['OwnExactProbeCPU']):
                raise ValueError('CPU self-exclusion identity/name mismatch')
            if any(not r['Name'].casefold().startswith(('powershell', 'pwsh')) for r in sample['OwnExactProbeIO']):
                raise ValueError('IO self-exclusion identity/name mismatch')
            sample['HeavyCPU'] = [r for r in sample['HeavyCPU'] if not own(r, 'PID')]
            sample['HeavyIO'] = [r for r in sample['HeavyIO'] if not own(r, 'IDProcess')]
            sample['Linux'] = json.loads(capture(['wsl.exe', '-d', 'Ubuntu-24.04', '-u', 'root',
                '--exec', '/usr/bin/python3', '-B', '-c', LINUX], env))
            sample['quiet'] = (not sample['HeavyCPU'] and not sample['HeavyIO'] and
                not sample['Toolchains'] and not sample['Linux']['active'] and
                sample['AvailablePhysicalBytes'] >= 3*GiB and shutil.disk_usage(W).free-extra > 12*GiB)
            count += 1
            if first is None:
                first = sample
            encoded = (json.dumps({'schema': 'facman.live_resource_wait.v1', 'phase': phase,
                'sample_count': count, 'first_sample': first, 'latest_sample': sample,
                'intermediate_censuses_retained': False, 'product_dispatched_in_wait': False, 'capture_scope': 'bounded read-only subprocess observations; no owned Job lifetime qualification claimed'}, sort_keys=True)+'\n').encode()
            if len(encoded) > 16*1024**2:
                raise ValueError('resource first/latest storage budget exceeded')
            retained.seek(0); retained.write(encoded); retained.truncate(); retained.flush(); os.fsync(retained.fileno())
            if sample['quiet']:
                guard(plan, env)
                return fresh_storage(plan, additional=extra)
            delay = (60, 120, 300, 600)[min(count-1, 3)]
            for _ in range(delay//60):
                time.sleep(60)

def run(name,command,timeout=40,limit=4*1024**2,allow_nonzero=False):
    result=owned.command(command,cwd=R,environment=environment,timeout=timeout,directory=E/('managed-move-preview-delivered-'+name+'-03'),output_limit=limit,wait_for_job_empty_after_primary=True)
    assert result.receipt['termination']=='completed' and result.receipt['job_empty_observed'] and not result.receipt['job_terminated'],result.receipt
    assert allow_nonzero or result.ok,result.receipt
    return result
out=E/'managed-move-preview-delivered-result-03.json'
record=dict(status='RUNNING_OUTCOME_UNKNOWN_IF_INTERRUPTED',source=plan['source'],tree=plan['tree'],run=plan['run'],artifact=plan['artifact']['id'],plan_sha256=sha(P.read_bytes()),root_review_sha256=sha((E/'managed-move-preview-delivered-root-review-03.json').read_bytes()))
path_guard(out,True);owned.write_json(out,record)
try:
    doctor=json.loads((E/'managed-move-preview-delivered-doctor-01/stdout.raw').read_bytes())
    assert set(doctor['violations'])<={'unmanaged_secondary_worktrees_present'} and len(doctor['task_roots'])<=8 and all(r['owned'] for r in doctor['task_roots'])
    peak=640*1024**2
    record['doctor_admission_source']='managed-move-preview-delivered-doctor-01/stdout.raw; single original measured admission, fresh storage remeasured before effects'
    own_identity=run('preflight-identity',['powershell','-NoProfile','-Command','[System.Security.Principal.WindowsIdentity]::GetCurrent().Name']).stdout.decode().strip();assert own_identity==r'BLACKGLASS-WIN1\Jules'
    run('preflight-auth',['gh','auth','status']);assert run('preflight-account',['gh','api','user','--jq','.login']).stdout.decode().strip()=='Julesc013'
    metadata=json.loads((E/'managed-move-preview-delivered-discover-01/stdout.raw').read_bytes())
    artifact=next(a for a in metadata['artifacts'] if a['id']==plan['artifact']['id'])
    assert artifact==plan['artifact'] and not artifact['expired'] and artifact['workflow_run']['head_sha']==plan['source'] and artifact['workflow_run']['id']==plan['run']
    record['resource_admission']=wait_for_resources(plan,environment,'before-download',peak)
    path_guard(G,True);path_guard(F,True)
    download=run('download',['gh','api','repos/Julesc013/factorio-launcher/actions/artifacts/'+str(artifact['id'])+'/zip'],180,32*1024**2)
    assert len(download.stdout)==artifact['size_in_bytes'] and len(download.stdout)<=32*1024**2
    assert artifact['digest'].startswith('sha256:') and sha(download.stdout)==artifact['digest'].split(':',1)[1], 'Original GitHub artifact digest mismatch'
    def entries(archive,cap):
        infos=archive.infolist();assert 0<len(infos)<=8192 and sum(z.file_size for z in infos)<=cap
        names=set()
        for z in infos:
            name=z.filename;parts=PurePosixPath(name).parts
            rawparts=name[:-1].split('/') if z.is_dir() else name.split('/')
            reserved={'CON','PRN','AUX','NUL',*(('COM'+str(i)) for i in range(1,10)),*(('LPT'+str(i)) for i in range(1,10))}
            assert name and '\\' not in name and not PurePosixPath(name).is_absolute() and all(p and p not in ('.','..') and ':' not in p and not p.endswith((' ','.')) and p.split('.')[0].upper() not in reserved for p in rawparts)
            assert name.casefold() not in names;names.add(name.casefold())
            mode=(z.external_attr>>16)&0xffff
            assert not stat.S_ISLNK(mode) and (stat.S_IFMT(mode) in (0,stat.S_IFREG,stat.S_IFDIR)) and not z.flag_bits&1 and not z.external_attr&0x400 and z.compress_type in (zipfile.ZIP_STORED,zipfile.ZIP_DEFLATED)
        return infos
    with zipfile.ZipFile(io.BytesIO(download.stdout)) as outer:
        oi=entries(outer,64*1024**2)
        descnames=[z.filename for z in oi if z.filename.endswith('-self-setup-package.v1.json')];assert len(descnames)==1
        desc=json.loads(outer.read(descnames[0]));assert desc['schema']=='facman.self_setup_package.v1' and desc['facman_source_revision']==plan['source'] and desc['source_dirty'] is False
        assert desc['universal_setup_revision']==plan['providers']['universal_setup'] and desc['support']=='unsupported_private_alpha_candidate'
        assert desc['factorio_mutation'] is False and desc['automatic_update'] is False and desc['workspace_preserved'] is True and desc['offline'] is True
        assert desc['profile']=='windows_x64_per_user_self_setup' and desc['default_scope']=='per_user_non_administrator'
        assert set(z.filename for z in oi)=={descnames[0],desc['payload']['filename'],desc['setup_executable']['filename']}
        payload=outer.read(desc['payload']['filename']);assert len(payload)==desc['payload']['size_bytes'] and sha(payload)==desc['payload']['sha256']
        setup=outer.read(desc['setup_executable']['filename']);assert len(setup)==desc['setup_executable']['size_bytes'] and sha(setup)==desc['setup_executable']['sha256']
    files={};prefix='facman/generations/0.1.0-alpha.6/'
    with zipfile.ZipFile(io.BytesIO(payload)) as inner:
        ii=entries(inner,128*1024**2);assert len(ii)==desc['payload']['file_count']
        for z in ii:
            if not z.filename.startswith(prefix):continue
            n=z.filename[len(prefix):];assert n and not z.is_dir()
            if n=='FacMan.exe':n='bin/FacMan.WinForms.exe'
            assert n.casefold() not in {x.casefold() for x in files};files[n]=inner.read(z)
    assert len(files)==desc['portable_input']['generation_file_count']
    manifest={}
    for line in files['manifest/hashes.sha256'].decode('utf-8').splitlines():
        h,n=line.split('  ',1);assert n not in manifest and len(h)==64 and all(c in '0123456789abcdef' for c in h);manifest[n]=h
    assert set(files)==set(manifest)|{'manifest/hashes.sha256'} and all(sha(files[n])==h for n,h in manifest.items())
    info=json.loads(files['manifest/build_info.v1.json'])
    assert info['source_commit']==plan['source'] and info['source_revisions']==dict(factorio_launcher=plan['source'],**plan['providers']) and info['source_dirty'] is False
    assert info['profile_id']=='windows_legacy_winforms_x64' and all(info[k] is False for k in ('integration_coherent','provider_adoption','published','release_eligible','signed'))
    assert sum(map(len,files.values()))<=128*1024**2
    record['storage_before_extraction']=fresh_storage(plan,additional=peak)
    path_guard(G,True);path_guard(F,True)
    G.mkdir()
    for n,data in files.items():
        p=G/n;assert p.resolve().is_relative_to(G.resolve());p.parent.mkdir(parents=True,exist_ok=True)
        with p.open('xb') as stream:stream.write(data)
    inventory={p.relative_to(G).as_posix():sha(p.read_bytes()) for p in G.rglob('*') if p.is_file()};assert inventory=={n:sha(b) for n,b in files.items()}
    extracted=dict(status='VERIFIED_ORIGINAL_PORTABLE_CLOSURE',source=plan['source'],tree=plan['tree'],run=plan['run'],artifact=artifact['id'],package_root=str(G),outer_entries=[dict(name=z.filename,size=z.file_size) for z in oi],archive_sha256=sha(download.stdout),payload_sha256=sha(payload),original_manifest_hashes_verified=len(manifest),original_file_count=len(files),inverse_only='FacMan.exe -> bin/FacMan.WinForms.exe',download_count=1,extraction_count=1,build_info=info,self_setup_descriptor=desc,file_inventory=inventory,manifest_sha256=sha(files['manifest/hashes.sha256']),uncompressed_bytes=sum(map(len,files.values())),backend_sha256=sha(files['bin/facman.exe']),canonical_installed_desktop=False,real_game=False,beta=False)
    owned.write_json(E/'managed-move-preview-delivered-extract-03.json',extracted)
    record['product_resource_admission']=wait_for_resources(plan,environment,'before-product',peak)
    product=json.loads(run('product-inspect',[str(G/'bin/facman.exe'),'--workspace',str(W/'t'),'product','inspect','--json']).stdout)
    identity=require_backend_identity(G,G/'bin/facman.exe',product['payload'])
    assert identity['compiled_source_revision']==plan['source'] and identity['compiled_source_dirty'] is False
    owned.write_json(E/'managed-move-preview-delivered-product-identity-03.json',identity)
    run('worker',[sys.executable,str(E/'managed-move-preview-delivered-worker-03.py')],300)
    result=json.loads((E/'managed-move-preview-delivered-worker-result-03.json').read_bytes());assert result['status']=='PASS_ORIGINAL_PACKAGED_MOVE_PREVIEW'
    assert {p.relative_to(G).as_posix():sha(p.read_bytes()) for p in G.rglob('*') if p.is_file()}==inventory
    for name,h in plan['module_hashes'].items():assert sha((R/name).read_bytes())==h,name
    record.update(status='PASS_EXACT_PR432_PACKAGED_MOVE_PREVIEW',identity=identity,steps=result['steps'],counts=result['counts'],worker_result_sha256=sha((E/'managed-move-preview-delivered-worker-result-03.json').read_bytes()),download_count=1,extraction_count=1,original_file_count=len(files),canonical_installed_desktop=False,game=False,human=False,whole_F11=False,beta=False,release_eligible=False)
except BaseException as error:
    record.update(status='FAIL_RETAINED',error=str(error),traceback=traceback.format_exc());raise
finally:owned.write_json(out,record)
print(json.dumps({k:record.get(k) for k in ('status','source','artifact','original_file_count','counts','steps')}))
