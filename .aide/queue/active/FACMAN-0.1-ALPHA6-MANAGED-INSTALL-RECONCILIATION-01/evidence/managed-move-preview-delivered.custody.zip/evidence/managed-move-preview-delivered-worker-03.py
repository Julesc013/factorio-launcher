import hashlib,json,os,subprocess,sys,traceback,types,stat
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher')
W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e')
E=W/'evidence';G=W/'t/j3/g4';F=E/'managed-move-preview-delivered-public-01'
sys.path.insert(0,str(R));sys.dont_write_bytecode=True
from tools import provider_canary_process as owned
from tools import development_layout
sha=lambda b:hashlib.sha256(b).hexdigest()
P=E/'managed-move-preview-delivered-plan-03.json';plan=json.loads(P.read_bytes())
for name,h in plan['script_hashes'].items():assert sha((E/name).read_bytes())==h,name
for name,h in plan['module_hashes'].items():assert sha((R/name).read_bytes())==h,name
assert sha((W/'.facman-development-root.v1.json').read_bytes())==plan['marker_sha256']
def path_guard(path,absent=False):
    path=Path(path)
    assert path.is_absolute() and os.path.normcase(os.path.commonpath((str(W),str(path))))==os.path.normcase(str(W)),str(path)
    for ancestor in reversed((path,*path.parents)):
        if os.path.lexists(ancestor):
            status=ancestor.lstat()
            assert not ancestor.is_symlink() and not getattr(status,'st_file_attributes',0)&0x400,'redirected existing ancestor: '+str(ancestor)
    if absent:assert not os.path.lexists(path),'owned leaf already exists: '+str(path)
path_guard(E);path_guard(W/'t');path_guard(G);path_guard(F,True)
extract=json.loads((E/'managed-move-preview-delivered-extract-03.json').read_bytes())
def inventory():
    return {p.relative_to(G).as_posix():sha(p.read_bytes()) for p in G.rglob('*') if p.is_file()}
before=inventory();assert before==extract['file_inventory']
exe=G/'bin/facman.exe';calls=[];counter=0
def run(command,**kw):
    global counter
    command=[str(a) for a in command];kind='auxiliary'
    if Path(command[0]).resolve()==exe.resolve():kind='rpc' if command[1:]==['rpc','--stdio'] else 'json' if '--json' in command else 'human'
    elif command[:4]==['cmd','/c','mklink','/J']:
        assert len(command)==6 and all(Path(v).resolve().is_relative_to(F.resolve()) for v in command[4:])
        kind='junction-fixture'
    else:
        assert command==['git','-C',str(R),'rev-parse','--path-format=absolute','--git-common-dir'],command
    assert set(kw)<={'env','capture_output','text','timeout','check','input','cwd','stdout','stderr','encoding'},kw
    counter+=1
    data=kw.get('input',b'');data=data.encode('utf-8') if isinstance(data,str) else data
    result=owned.command(command,cwd=Path(kw.get('cwd') or R),environment=kw.get('env') or dict(os.environ),timeout=min(40,kw.get('timeout',40)),directory=E/('managed-move-preview-delivered-dispatch-03-%03d'%counter),input_bytes=data,output_limit=4*1024**2,wait_for_job_empty_after_primary=True)
    receipt=result.receipt
    calls.append(dict(kind=kind,command=command,receipt=str(result.directory/'receipt.json')))
    owned.write_json(E/'managed-move-preview-delivered-dispatch-index-03.json',{'calls':calls})
    assert receipt['termination']=='completed' and receipt['job_empty_observed'] and not receipt['job_terminated'],receipt
    if kw.get('check') and result.returncode:raise subprocess.CalledProcessError(result.returncode,command,result.stdout,result.stderr)
    text=kw.get('text',False);encoding=kw.get('encoding') or 'utf-8'
    return subprocess.CompletedProcess(command,result.returncode,result.stdout.decode(encoding) if text else result.stdout,result.stderr.decode(encoding) if text else result.stderr)
class Proxy:
    def __getattr__(self,name):return run if name=='run' else getattr(subprocess,name)
original=E/'managed-move-preview-delivered-oracle-01.py';raw=original.read_bytes();assert sha(raw)==plan['frozen_oracle_sha256']
ns={'__name__':'frozen_move_preview','__file__':str(R/'tests/integration/facman_managed_install_lifecycle.py')}
record={'status':'RUNNING_OUTCOME_UNKNOWN_IF_INTERRUPTED','actual_snapshot':str(original),'compiled_filename':str(original),'oracle___file__':ns['__file__'],'frozen_oracle_sha256':sha(raw),'root_binding':str(R),'adaptation':'execute immutable bytes; bind __file__ to original source location for ROOT; replace subprocess transport only, assertions unchanged'}
out=E/'managed-move-preview-delivered-worker-result-03.json';path_guard(out,True);owned.write_json(out,record)
try:
    exec(compile(raw,str(original),'exec'),ns)
    ns['subprocess']=Proxy();development_layout.subprocess=Proxy()
    sys.argv=[str(original),'--facman',str(exe),'--root',str(F),'--scenario','move-preview']
    assert ns['main']()==0
    receipt=json.loads((F/'receipt.json').read_bytes());assert receipt['result']=='pass' and not receipt['open_gaps'] and len(receipt['steps'])==22
    counts={kind:sum(c['kind']==kind for c in calls) for kind in ('json','human','rpc','junction-fixture')}
    assert counts=={'json':20,'human':1,'rpc':1,'junction-fixture':2},counts
    assert inventory()==before
    for name,h in plan['module_hashes'].items():assert sha((R/name).read_bytes())==h,name
    record.update(status='PASS_ORIGINAL_PACKAGED_MOVE_PREVIEW',counts=counts,steps=22,oracle_receipt_sha256=sha((F/'receipt.json').read_bytes()),package_before=before,package_after=inventory(),source=plan['source'],canonical_installed_desktop=False,game=False,human=False,whole_F11=False,release_eligible=False)
except BaseException as error:
    record.update(status='FAIL_RETAINED',error=str(error),traceback=traceback.format_exc());raise
finally:owned.write_json(out,record)
print(json.dumps({k:record.get(k) for k in ('status','counts','steps','source')}))
