import hashlib
import json
import subprocess
from pathlib import Path

R = Path(r"D:\Projects\Factorio\factorio-launcher")
E = Path(__file__).resolve().parent
W = E.parent
B = W / "native-developer"
BASE = "c089396b6210b8da18299fe8376bf1cea203826a"
BRANCH = "task/facman-managed-install-coordination-01"
PACKET_SHA = "5202b7f92577eb664538943190a1aca0dae1b294f3dde65041c11168cf446ac7"
GAP = "Windows provider path policy refuses before the prospective 8192-byte shared metadata limit can be reached"

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(["git", *args], cwd=R).decode("utf-8").strip()

def bound(row):
    path = Path(row["path"]).resolve(strict=True)
    assert path.is_relative_to(W.resolve()), str(path)
    assert sha(path) == row["sha256"], str(path)
    return path

packet_path = E / "managed-install-coordination-author-packet-01.json"
assert sha(packet_path) == PACKET_SHA
p = json.loads(packet_path.read_bytes())
assert p["status"] == "AUTHOR_READY_FOR_INDEPENDENT_REVIEW_WITH_RETAINED_HOST_GAP"
assert not p["self_approval"] and not p["overall_public_pass"] and not p["real_game_touched"]
assert git("rev-parse", "HEAD") == p["base"] == BASE
assert git("rev-parse", "HEAD^{tree}") == p["base_tree"]
assert git("branch", "--show-current") == p["branch"] == BRANCH
expected = {
    "runtime/factorio/application/handlers/setup.cpp",
    "runtime/factorio/application/setup_gateway.cpp",
    "runtime/factorio/application/setup_gateway.h",
    "tests/integration/facman_managed_install_lifecycle.py",
    "tests/native/m1_three_repository_system_proof.cpp",
    "docs/reviews/2026-10-15-managed-install-coordination.md",
}
assert {r["path"] for r in p["author_files"]} == expected
assert not git("diff", "--cached", "--name-only")
assert set(git("diff", "--name-only").splitlines()) | set(git("ls-files", "--others", "--exclude-standard").splitlines()) == expected
for row in p["author_files"]:
    assert sha(R / row["path"]) == row["sha256"]
    assert git("hash-object", "--path", row["path"], str(R / row["path"])) == row["git_blob"]
for row in p["preserved_artifacts"]:
    bound(row)
native = json.loads(bound(p["native_result"]).read_bytes())
qualification = json.loads(bound(p["qualification_result"]).read_bytes())
public = json.loads(bound(p["public_proof"]).read_bytes())
assert native["status"] == "FAIL_RETAINED" and native["error"] == "public"
assert qualification["status"] == "SCOPED_COORDINATION_CASES_PASSED_WITH_RETAINED_HOST_GAP"
assert public["result"] == qualification["public_result"] == "partial"
assert qualification["public_exit_code"] == 1 and public["open_gaps"] == [GAP]
assert len(public["steps"]) == 38 and p["public_proof"]["actual_command_count"] == 39
assert not qualification["overall_public_pass"] and not qualification["workunit_closed"]
for row in p["author_files"]:
    assert native["source_files_sha256"][row["path"]] == row["sha256"]
for name, digest in p["binary_images_sha256"].items():
    assert sha(B / "Release" / name) == digest == native["binary_images_sha256"][name]
for name, digest in p["provider_images_sha256"].items():
    assert sha(B / "Release" / name) == digest == native["provider_images_sha256"][name]
assert public["facman_sha256"] == p["binary_images_sha256"]["facman.exe"]
for row in p["native_commands"] + p["final_checks"]:
    receipt = Path(row["receipt"])
    assert receipt.resolve().is_relative_to(W.resolve())
    assert sha(receipt) == row["receipt_sha256"]
    command = json.loads(receipt.read_bytes())
    assert command["termination"] == "completed" and command["primary_stopped"] and command["job_empty_observed"]
    assert command["exit_code"] == (1 if row["name"] in ("doctor", "public") else 0)
ctest = next(r for r in p["native_commands"] if r["name"] == "ctest")
ctest_receipt = Path(ctest["receipt"])
ctest_log = (ctest_receipt.parent / "stdout.raw").read_text(encoding="utf-8")
assert "100% tests passed, 0 tests failed out of 4" in ctest_log
for name in ("m1_three_repository_system_proof", "flb_setup_gateway_smoke", "fl_workspace_store_smoke", "facman_isolation_lock_smoke"):
    assert name in ctest_log
identities = set()
timeouts = []
for row in p["public_process_receipts"]:
    command = json.loads(bound(row).read_bytes())
    assert command["dispatched"] and command["resumed"] and command["primary_stopped"] and command["job_empty_observed"]
    identity = tuple(command["process_identity"][k] for k in ("pid", "creation_ticks"))
    assert identity not in identities
    identities.add(identity)
    for stream in ("stdout", "stderr"):
        data = command[stream]
        path = Path(row["path"]).parent / data["file"]
        assert path.stat().st_size == data["captured_bytes"] and sha(path) == data["sha256"]
    if command["termination"] == "command_timeout":
        assert command["configured_seconds"] == 1.2 and command["job_terminated"]
        timeouts.append(command["command"])
    else:
        assert command["termination"] == "completed"
        assert command["active_processes_at_primary_exit"] is not None
assert len(identities) == 39 and len(timeouts) == 3
assert {r[4] for r in timeouts} == {"install", "repair", "uninstall"}
for row in p["byte_oracles"]:
    for before, after in (("generation_before", "generation_after"), ("product_before", "product_after"),
                          ("shared_namespace_before", "shared_namespace_after"),
                          ("terminal_journal_before_sha256", "terminal_journal_after_sha256")):
        if before in row:
            assert row[before] == row[after], row["case"]
assert len(p["byte_oracles"]) == 4
source = (R / "runtime/factorio/application/handlers/setup.cpp").read_text(encoding="utf-8")
lease_source = source.split("class ManagedInstallOperationLease {", 1)[1].split("void managed_install_test_pause(", 1)[0]
assert lease_source.index('metadata_document(root_text, workspace_text,') < lease_source.index("auto acquired = lease->lock_.create(lease->path_)")
assert source.count('"confirmed_no_provider_effect_before_closure"') == 3
assert source.count("plan.journal.state != facman::transaction::State::audited &&") == 3
review = {
    "schema": "facman.managed_install_coordination.independent_review.v1",
    "verdict": "PASS_SCOPED_SOURCE_FOR_REQUIRED_CURRENT_CI",
    "reviewer": "/root",
    "author": "/root/managed_install_coordination_implementation",
    "non_authoring": True,
    "base": BASE,
    "branch": BRANCH,
    "author_packet_sha256": PACKET_SHA,
    "authored_files_sha256": {r["path"]: r["sha256"] for r in p["author_files"]},
    "native_tests_passed": 4,
    "actual_public_commands": 39,
    "physical_death_commands": 3,
    "public_result": "partial",
    "public_primary_exit_then_owned_cleanup": 36,
    "all_member_natural_exit_claimed": False,
    "retained_gap": GAP,
    "custody_artifacts_verified": len(p["preserved_artifacts"]),
    "review": [
        "Reviewed shared guard physical namespace and exact owner metadata, strict typed codec, held bytes and identity revalidation.",
        "Reviewed nonblocking transaction/shared/provider/repository lock order and durable requested locator before guard creation.",
        "Required corrections preserve changed same-inode bytes, parent aliases, invalid terminal preflight and stale terminal retry cleanup.",
        "Physical requested-state crash proof reproduced and corrected install closure and repair early-state admission; audited and terminal states retain existing paths.",
        "Install, repair and uninstall physical no-entry death recovery preserve exact product/reference bytes and release only the bound guard.",
        "Reviewed original refusals, terminal race, case/8.3 alias contention, foreign/torn metadata and no provider-entry byte oracles.",
        "Actual capture uses waitFalse: 36 ordinary primary exits and 3 deliberate timeouts followed by scoped Job termination/empty observation. No all-member natural-exit or process-lifetime acceptance is inferred.",
        "Windows deep-path refusal occurs earlier than the 8192-byte lease bound. Static size-before-create/strict-read invariants reviewed; host boundary execution remains unqualified.",
        "Scope excludes direct USK actors, distinct state roots, default mutation authority, real game, complete maintenance, produced packages, human/other hosts, Beta and release.",
    ],
    "workunit_closed": False,
    "required_checks_pending": True,
    "produced_package_qualified": False,
}
out = E / "managed-install-coordination-independent-review-01.json"
assert not out.exists()
out.write_text(json.dumps(review, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"verdict": review["verdict"], "commands": 39, "native_tests": 4, "artifacts": len(p["preserved_artifacts"]), "review_sha256": sha(out)}))
