import ast, ctypes as C, ctypes.wintypes as T, hashlib, json, os, subprocess, sys, time
from pathlib import Path
E = Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e\evidence')
inspection_path = E/'managed-install-coordination-owned-job-inspection-01.json'
assert hashlib.sha256(inspection_path.read_bytes()).hexdigest() == '30cb2561abd0822b73ec619b7f7d739f9797e2167faacd1c8efe6626411b7ed3'
expected = json.loads(inspection_path.read_text(encoding='utf-8'))
inspector = E/'managed-install-coordination-owned-job-inspect-01.py'
tree = ast.parse(inspector.read_text(encoding='utf-8'))
prefix=[]
for node in tree.body:
    prefix.append(node)
    if isinstance(node,ast.FunctionDef) and node.name=='duplicate': break
exec(compile(ast.Module(prefix,type_ignores=[]),str(inspector),'exec'),globals())
build_receipt = E/'managed-install-coordination-build-execution-01/receipt.json'
assert json.loads(build_receipt.read_text(encoding='utf-8'))['termination'] == 'prepared_outcome_unknown'
driver = Path(expected['driver_script'])
assert hashlib.sha256(driver.read_bytes()).hexdigest() == expected['driver_script_sha256']
query="$p=@(Get-CimInstance Win32_Process -Filter \"ProcessId = 612\" | Select-Object ProcessId,ParentProcessId,CreationDate,CommandLine); ConvertTo-Json -InputObject $p -Compress"
controllers=json.loads(subprocess.check_output(['pwsh','-NoProfile','-Command',query],cwd=R).decode('utf-8'))
assert len(controllers)==1
controller=controllers[0]
assert hashlib.sha256(controller['CommandLine'].encode('utf-8')).hexdigest() == expected['driver_command_sha256']
source=api.OpenProcess(0x440,False,expected['driver_pid']); require(source,'exact controller OpenProcess')
current=api.GetCurrentProcess(); copies=[]
assert times(source)==expected['driver_creation_filetime']
def members_of(job):
    buffer=C.create_string_buffer(65536)
    require(api.QueryInformationJobObject(job,3,buffer,len(buffer),None),'exact held job members')
    count=T.DWORD.from_buffer(buffer,4).value; assert count<=1024
    return [C.c_size_t.from_buffer(buffer,8+i*C.sizeof(C.c_size_t)).value for i in range(count)]
def accounting_of(job):
    value=native.Accounting()
    require(api.QueryInformationJobObject(job,1,C.byref(value),C.sizeof(value),None),'exact held job accounting')
    return value
try:
    entries=snapshot(source)
    jobs=[item for item in entries if item.type==expected['source_job_type_index']]
    assert len(jobs)==1 and jobs[0].handle==expected['source_job_handle']
    job=duplicate(jobs[0].handle); copies.append(job)
    assert members_of(job)==expected['active_members']==[52048]
    assert accounting_of(job).active==1
    assert expected['driver_pid'] not in members_of(job) and controller['ParentProcessId'] not in members_of(job) and os.getpid() not in members_of(job)
    primary_handle=duplicate(expected['primary']['handle']); copies.append(primary_handle)
    assert api.GetProcessId(primary_handle)==expected['primary']['pid']==41488
    assert times(primary_handle)==expected['primary']['creation_filetime']
    assert image(primary_handle)==expected['primary']['image']
    code=T.DWORD(); require(api.GetExitCodeProcess(primary_handle,C.byref(code)),'exact held primary exit')
    assert code.value==expected['primary']['exit_code']==0
    member_query="$p=@(Get-CimInstance Win32_Process -Filter \"ProcessId = 52048\" | Select-Object ProcessId,ParentProcessId,Name,CreationDate,CommandLine); ConvertTo-Json -InputObject $p -Compress"
    observed=json.loads(subprocess.check_output(['pwsh','-NoProfile','-Command',member_query],cwd=R).decode('utf-8'))
    assert len(observed)==1 and len(expected['members'])==1
    member=observed[0]; baseline=expected['members'][0]
    assert member['Name'].lower()==baseline['name'].lower()=='vctip.exe'
    assert member['CreationDate']==baseline['creation'] and member['ParentProcessId']==baseline['parent_pid']
    assert hashlib.sha256(member['CommandLine'].encode('utf-8')).hexdigest()==baseline['command_sha256']
    member_handle=api.OpenProcess(0x400|0x100000,False,52048); require(member_handle,'owned member retained query handle'); copies.append(member_handle)
    assert api.GetProcessId(member_handle)==52048 and Path(image(member_handle)).name.lower()=='vctip.exe'
    member_birth=times(member_handle)
    assert members_of(job)==[52048] and accounting_of(job).active==1
    assert json.loads(build_receipt.read_text(encoding='utf-8'))['termination']=='prepared_outcome_unknown'
    result=dict(schema='facman.exact_owned_auxiliary_job_termination.v1',
                inspection_sha256=hashlib.sha256(inspection_path.read_bytes()).hexdigest(),
                driver_pid=612,driver_creation_filetime=expected['driver_creation_filetime'],
                source_job_handle=816,primary_pid=41488,primary_exit_code=0,
                member_pid=52048,member_creation_filetime=member_birth,member_name='vctip.exe',
                controller_or_ancestor_targeted=False,global_pid_name_kill=False,debug_privilege_enabled=False,
                all_members_exited_naturally=False,external_auxiliary_termination=True)
    require(api.TerminateJobObject(job,124),'reviewed exact owned Job termination')
    deadline=time.monotonic()+5
    while accounting_of(job).active and time.monotonic()<deadline: time.sleep(0.005)
    require(api.WaitForSingleObject(member_handle,1000)==0,'owned member stopped')
    assert accounting_of(job).active==0 and members_of(job)==[]
    result.update(status='OWNED_AUXILIARY_TERMINATED_JOB_EMPTY',job_empty_observed=True,member_stopped_observed=True)
    path=E/'managed-install-coordination-owned-job-finish-01.json'; assert not path.exists()
    path.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(status=result['status'],primary_exit_code=0,external_auxiliary_termination=True,
                         receipt_sha256=hashlib.sha256(path.read_bytes()).hexdigest())))
finally:
    for handle in copies: api.CloseHandle(handle)
    api.CloseHandle(source)
