import hashlib,json,os,subprocess,sys,traceback
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher')
W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e')
E=W/'evidence';B=W/'native-developer';sys.path.insert(0,str(R))
from tools import provider_canary_process as owned
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',FACMAN_MIN_FREE_GIB='12',CMAKE_BUILD_PARALLEL_LEVEL='2',MSBUILDDISABLENODEREUSE='1')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
native_path=E/'managed-install-coordination-native-result-11.json';native=json.loads(native_path.read_text(encoding='utf-8'))
assert native['status']=='FAIL_RETAINED' and native['error']=='public'
assert [(x['name'],x['exit_code']) for x in native['commands']]==[('paths',0),('doctor',1),('build',0),('ctest',0),('public',1)]
assert all(sha(R/n)==v for n,v in native['source_files_sha256'].items())
assert all(sha(B/'Release'/n)==v for n,v in native['binary_images_sha256'].items())
assert all(sha(B/'Release'/n)==v for n,v in native['provider_images_sha256'].items())
proof=W/'t/j3/mc11';public=json.loads((proof/'receipt.json').read_text(encoding='utf-8'))
gap='Windows provider path policy refuses before the prospective 8192-byte shared metadata limit can be reached'
assert public['result']=='partial' and public['open_gaps']==[gap]
outer=E/'managed-install-coordination-public-execution-11/receipt.json';o=json.loads(outer.read_text(encoding='utf-8'))
assert o['termination']=='completed' and o['exit_code']==1 and o['job_empty_observed'] and o['stderr']['captured_bytes']==0
process=[json.loads(p.read_text(encoding='utf-8')) for p in proof.glob('execution-*/receipt.json')]
assert len(process)==39 and sum(x['termination']=='command_timeout' for x in process)==3
assert all(x['primary_stopped'] and x['job_empty_observed'] and x['termination'] in ('completed','command_timeout') for x in process)
path=E/'managed-install-coordination-qualification-result-01.json';assert not path.exists()
result=dict(schema='facman.managed_install_coordination.qualification_continuation.v1',status='running',native_result=dict(path=str(native_path),sha256=sha(native_path)),source_files_sha256=native['source_files_sha256'],public_result='partial',public_exit_code=1,public_steps=len(public['steps']),actual_public_commands=len(process),intentional_physical_timeouts=3,all_public_jobs_empty=True,retained_gap=gap,public_receipt=dict(path=str(proof/'receipt.json'),sha256=sha(proof/'receipt.json')),commands=[],overall_public_pass=False,workunit_closed=False,self_approval=False)
def save():path.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
def run(name,args,timeout):
    x=owned.command(args,cwd=R,environment=dict(os.environ),timeout=timeout,directory=E/f'managed-install-coordination-final-{name}-execution-01',output_limit=8*1024*1024,wait_for_job_empty_after_primary=False)
    result['commands'].append(dict(name=name,command=args,exit_code=x.returncode,termination=x.receipt['termination'],job_empty=x.receipt['job_empty_observed'],receipt=str(x.directory/'receipt.json'),receipt_sha256=sha(x.directory/'receipt.json')));save()
    assert x.ok and x.receipt['job_empty_observed'],name
try:
    run('strict',['py','-3','-B','tools/strict_check.py'],1800)
    run('aide',['py','-3','-B','.aide/scripts/aide_lite.py','test'],600)
    run('diff',['git','diff','--check'],60)
    assert all(sha(R/n)==v for n,v in native['source_files_sha256'].items())
    result['status']='SCOPED_COORDINATION_CASES_PASSED_WITH_RETAINED_HOST_GAP'
except BaseException as exc:result.update(status='FAIL_RETAINED',error=str(exc),traceback=traceback.format_exc())
finally:save();print(json.dumps(dict(status=result['status'],commands=len(result['commands']),public_commands=len(process))))
