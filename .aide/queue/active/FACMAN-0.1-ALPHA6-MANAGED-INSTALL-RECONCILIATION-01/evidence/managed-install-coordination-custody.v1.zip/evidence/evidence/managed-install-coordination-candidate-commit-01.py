import hashlib, json, os, subprocess, sys, traceback, zipfile
from pathlib import Path

R = Path(r"D:\Projects\Factorio\factorio-launcher")
E = Path(__file__).resolve().parent
W = E.parent
BASE = "c089396b6210b8da18299fe8376bf1cea203826a"
BRANCH = "task/facman-managed-install-coordination-01"
ITEM = "FACMAN-0.1-ALPHA6-MANAGED-INSTALL-RECONCILIATION-01"
Q = ".aide/queue/active/" + ITEM
os.environ.update(FACMAN_DEV_ROOT=r"D:\Projects\Factorio\.task-builds", TEMP=str(W/"t"), TMP=str(W/"t"),
                  PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1", GIT_CONFIG_COUNT="1",
                  GIT_CONFIG_KEY_0="core.safecrlf", GIT_CONFIG_VALUE_0="false")
sys.path.insert(0, str(R))
from tools import provider_canary_process as owned
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
git = lambda *a: subprocess.check_output(["git", *a], cwd=R).decode("utf-8").strip()
dirty = lambda: set(git("diff", "--name-only").splitlines()) | set(git("ls-files", "--others", "--exclude-standard").splitlines())
out = E/"managed-install-coordination-candidate-commit-result-01.json"
assert not out.exists()
record = dict(status="QUALIFYING_SCOPED_MANAGED_INSTALL_COORDINATION", commands=[], new_roots=0, new_clones=0, new_worktrees=0)
def save():
    out.write_text(json.dumps(record, indent=2)+"\n", encoding="utf-8")
def run(label, args, timeout=180, codes=(0,)):
    r = owned.command(args, cwd=R, environment=dict(os.environ), timeout=timeout,
        directory=E/("managed-install-coordination-commit01-"+label), output_limit=8*1024**2,
        wait_for_job_empty_after_primary=True)
    record["commands"].append(dict(label=label, exit=r.returncode, receipt_sha256=sha(r.directory/"receipt.json")))
    save()
    assert r.returncode in codes and r.receipt["termination"] == "completed" and r.receipt["primary_stopped"] and r.receipt["job_empty_observed"], (label, (r.stdout[-1000:]+r.stderr[-1500:]).decode("utf-8", "replace"))
    return r
try:
    assert git("rev-parse", "HEAD") == BASE and git("branch", "--show-current") == BRANCH
    assert not git("diff", "--cached", "--name-only")
    packet = E/"managed-install-coordination-author-packet-01.json"
    p = json.loads(packet.read_bytes())
    review = E/"managed-install-coordination-independent-review-01.json"
    v = json.loads(review.read_bytes())
    assert v["verdict"] == "PASS_SCOPED_SOURCE_FOR_REQUIRED_CURRENT_CI" and v["non_authoring"]
    assert v["author_packet_sha256"] == sha(packet) and not v["workunit_closed"]
    expected = {row["path"] for row in p["author_files"]}
    assert dirty() == expected
    for row in p["author_files"]:
        assert sha(R/row["path"]) == row["sha256"]
    for label in ("policy", "detect", "plan"):
        run(label, ["py", "-3", "-B", ".aide/scripts/aide_lite.py", "git", label])
    run("paths", ["py", "-3", "-B", "tools/workspace_hygiene.py", "paths"])
    h = json.loads(run("doctor", ["py", "-3", "-B", "tools/workspace_hygiene.py", "doctor", "--measure"], 600, (0, 1)).stdout)
    assert set(h["violations"]) <= {"unmanaged_secondary_worktrees_present"}
    assert len(h["task_roots"]) == 8 and h["task_root_bytes"] < 20*1024**3
    manifest = {}
    artifacts = [Path(row["path"]).resolve() for row in p["preserved_artifacts"]]
    artifacts += [packet, review, E/"managed-install-coordination-independent-review-01.py", Path(__file__)]
    for path in artifacts:
        assert path.is_relative_to(W.resolve()) and path.is_file()
        assert path.suffix.lower() not in (".exe", ".dll", ".zip")
        name = "evidence/" + path.relative_to(W).as_posix()
        manifest[name] = sha(path)
    archive = R/Q/"evidence/managed-install-coordination-custody.v1.zip"
    evidence = R/Q/"evidence/managed-install-coordination.v1.json"
    assert not archive.exists() and not evidence.exists()
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr("custody-manifest.json", json.dumps(manifest, indent=2, sort_keys=True)+"\n")
        for name in sorted(manifest):
            z.write(W/name.removeprefix("evidence/"), name)
    with zipfile.ZipFile(archive) as z:
        assert set(z.namelist()) == set(manifest) | {"custody-manifest.json"}
        for name, digest in manifest.items():
            assert hashlib.sha256(z.read(name)).hexdigest() == digest
    assert archive.stat().st_size < 8*1024**2
    evidence.write_text(json.dumps(dict(
        schema="facman.managed_install_coordination.qualified_source.v1",
        base_head=BASE, base_tree=p["base_tree"], author_packet_sha256=sha(packet),
        independent_review_sha256=sha(review), authored_files_sha256=v["authored_files_sha256"],
        native_tests_passed=4, actual_owned_public_commands=39, physical_death_commands=3,
        public_result="partial", public_exit_code=1, retained_host_gap=v["retained_gap"],
        public_primary_exit_then_owned_cleanup=36, all_member_natural_exit_claimed=False,
        shared_scope="FacMan actors sharing one configured Setup installation namespace",
        direct_USK_or_distinct_state_root_exclusion=False,
        requested_crash_recovery=["install", "repair", "uninstall"],
        custody=archive.name, custody_sha256=sha(archive), custody_files=len(manifest),
        provider_images_sha256=p["provider_images_sha256"],
        binary_images_sha256=p["binary_images_sha256"],
        required_checks_pending=True, produced_package_qualified=False, workunit_closed=False,
        real_game_qualified=False, human_qualified=False, beta=False, rc=False,
        new_roots=0, new_clones=0, new_worktrees=0), indent=2)+"\n", encoding="utf-8")
    with (R/Q/"ExecPlan.md").open("a", encoding="utf-8", newline="\n") as f:
        f.write("\n### Shared managed installation coordination and requested-crash recovery\n\n"
            "This continuation starts from integrated dev c089396b without another clone, worktree or task root. "
            "Install, repair, uninstall and operation-specific recovery now retain a shared OS-backed guard across FacMan workspaces using the same configured Setup installation namespace. "
            "A durable REQUESTED coordinator precedes guard creation; exact plan/reference preimages are revalidated under the guard before provider work and short repository projection. "
            "Physical termination reproduced a REQUESTED-to-AUDITED closure failure and missing early repair-state admission. "
            "Proved no-provider-effect recovery now follows the existing durable recovery-required/audit/complete transitions, preserving already-audited and terminal paths.\n\n"
            "Independent source/custody review verified four native regressions and39 actual owned public commands, including three physical install/repair/uninstall deaths, ordinary exact-owner recovery, cross-workspace contention, case/8.3 aliases, terminal retry races and foreign/torn metadata preservation. "
            "The original build helper exited naturally; a reviewed external termination attempt aborted without handle access or mutation. "
            "Ordinary public primary exits use scoped Job cleanup, so no all-member natural-exit or process-lifetime qualification is claimed. "
            "The public result remains partial/exit1: Windows provider path policy refuses before the prospective8192-byte metadata limit can be exercised. "
            "The size-before-create and deterministic bounded read/serialization invariants are reviewed source evidence only.\n\n"
            "The Setup-root leaf retains the documented portable ASCII identifier restriction; Unicode/spaces in existing parents are supported. "
            "Direct USK actors and distinct state roots targeting the same installation remain outside this guard. "
            "Default mutation authority and provider pins remain unchanged. "
            "Fresh required CI and delivered-package proof remain pending; complete maintenance, real game, human/other-host, WorkUnit, Beta and release acceptance remain open. "
            "Evidence: evidence/managed-install-coordination.v1.json and its hash-closed custody.\n")
    paths = expected | {Q+"/ExecPlan.md", Q+"/evidence/"+archive.name, Q+"/evidence/"+evidence.name}
    run("project-state", ["py", "-3", "-B", "tools/project_state.py", "--write"], 600)
    run("metadata", ["py", "-3", "-B", "tools/codegen/generate_metadata.py", "--write"])
    changed = dirty()
    assert paths <= changed <= paths | {".aide/memory/project-state.md", ".aide/memory/project-state.v2.json", "README.md"}
    for row in p["author_files"]:
        assert sha(R/row["path"]) == row["sha256"]
    run("strict", ["py", "-3", "-B", "tools/strict_check.py"], 1800)
    run("portable-aide", ["py", "-3", "-B", ".aide/scripts/aide_lite.py", "test"], 1800)
    message = ("fix(setup): coordinate managed installation mutations\n\n"
        "Share the installation guard across FacMan workspaces and recover\n"
        "physical no-entry crashes before durable reference projection.\n\n"
        "Work-Item: "+ITEM+"\nEvidence-Ref: "+Q+"/evidence/"+evidence.name+"\n")
    msg = E/"managed-install-coordination-candidate-commit-message-01.txt"
    msg.write_text(message, encoding="utf-8", newline="\n")
    run("message", ["py", "-3", "-B", ".aide/scripts/aide_lite.py", "commit", "check", "--message", message])
    changes = [dict(path=name, state="content", sha256=sha(R/name),
        git_blob_oid=git("hash-object", "--path", name, str(R/name)), ownership="task_owned") for name in sorted(changed)]
    snapshot = hashlib.sha256((json.dumps(changes, indent=2, sort_keys=True, separators=(",", ": "))+"\n").encode()).hexdigest()
    commit_review = E/"managed-install-coordination-candidate-commit-review-01.json"
    commit_review.write_text(json.dumps(dict(schema_version="aide.git-commit-review.v1", verdict="PASS",
        reviewer="/root", author=v["author"], non_authoring=True, branch=BRANCH, base_commit=BASE,
        snapshot_sha256=snapshot, message_sha256=sha(msg), independent_source_review_sha256=sha(review),
        review=v["review"]), indent=2)+"\n", encoding="utf-8")
    classification = E/"managed-install-coordination-candidate-commit-classification-01.json"
    classification.write_text(json.dumps(dict(schema_version="aide.git-commit-classification.v1", branch=BRANCH,
        base_commit=BASE, work_item=ITEM, snapshot_sha256=snapshot, message_sha256=sha(msg), changed_paths=changes,
        reviews=[dict(path=str(commit_review), sha256=sha(commit_review), verdict="PASS")]), indent=2)+"\n", encoding="utf-8")
    helper = ["py", "-3", "-B", ".aide/scripts/aide_lite.py", "git", "commit-plan", "--classification", str(classification), "--message-file", str(msg)]
    run("plan-stage", helper)
    run("stage", ["git", "add", "--", *sorted(changed)])
    run("staged-diff", ["git", "diff", "--cached", "--check"])
    run("plan-commit", helper)
    assert git("rev-parse", "HEAD") == BASE
    run("commit", ["git", "commit", "-F", str(msg)])
    run("range", ["py", "-3", "-B", ".aide/scripts/aide_lite.py", "commit", "check", "--range", BASE+"..HEAD"])
    remaining = git("diff", "--name-only").splitlines()
    if remaining:
        assert set(remaining) <= {".aide/memory/project-state.md", ".aide/memory/project-state.v2.json", "README.md"}
        for name in remaining:
            assert git("hash-object", "--path", name, str(R/name)) == git("rev-parse", "HEAD:"+name)
        run("refresh-generated-index", ["git", "add", "--", *remaining])
    assert not git("status", "--porcelain") and not git("diff", "--cached", "--name-only")
    record.update(status="COMMITTED_REVIEWED_MANAGED_INSTALL_COORDINATION_CANDIDATE",
        source=git("rev-parse", "HEAD"), tree=git("rev-parse", "HEAD^{tree}"),
        review_sha256=sha(commit_review), evidence_sha256=sha(evidence),
        required_checks_pending=True, remote_not_pushed=True, workunit_closed=False)
except BaseException as error:
    record.update(status="ACTIONABLE_MANAGED_INSTALL_COORDINATION_COMMIT_FAILURE", error=str(error), traceback=traceback.format_exc())
finally:
    save()
    print(json.dumps({k:v for k,v in record.items() if k not in ("commands", "traceback")}, indent=2))
raise SystemExit(0 if record["status"] == "COMMITTED_REVIEWED_MANAGED_INSTALL_COORDINATION_CANDIDATE" else 1)
