import hashlib, json, os, subprocess, sys, traceback
from pathlib import Path

R = Path(r'D:\Projects\Factorio\factorio-launcher')
W = Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e')
E = W/'evidence'
sys.path.insert(0, str(R))
sys.dont_write_bytecode = True
from tools import provider_canary_process as owned

os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds', TEMP=str(W/'t'), TMP=str(W/'t'),
                  PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1', FACMAN_MIN_FREE_GIB='12',
                  CMAKE_BUILD_PARALLEL_LEVEL='2', MSBUILDDISABLENODEREUSE='1')
files = ['runtime/factorio/application/handlers/setup.cpp', 'tests/native/m1_three_repository_system_proof.cpp',
         'tests/integration/facman_managed_install_lifecycle.py', 'docs/reviews/2026-10-15-managed-install-coordination.md']
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
hashes = {name: sha(R/name) for name in files}
result_path = E/'managed-install-coordination-source-check-result-01.json'
assert not result_path.exists()
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=R).decode('utf-8').strip() == 'task/facman-managed-install-coordination-01'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R).decode('utf-8').strip() == 'c089396b6210b8da18299fe8376bf1cea203826a'
result = dict(schema='facman.managed_install_coordination.source_checks.v1', status='running',
              source_files_sha256=hashes, commands=[], native_executed=False, self_approval=False)
def save(): result_path.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
save()
try:
    for name, args, timeout in [
        ('diff', ['git', 'diff', '--check'], 45),
        ('strict', ['py', '-3', '-B', 'tools/strict_check.py'], 1800),
        ('aide', ['py', '-3', '-B', '.aide/scripts/aide_lite.py', 'test'], 600),
    ]:
        execution = owned.command(args, cwd=R, environment=dict(os.environ), timeout=timeout,
                                  directory=E/f'managed-install-coordination-source-{name}-execution-01',
                                  output_limit=8*1024*1024, wait_for_job_empty_after_primary=False)
        result['commands'].append(dict(name=name, argv=args, exit_code=execution.returncode,
                                       termination=execution.receipt['termination'],
                                       job_empty=execution.receipt['job_empty_observed'],
                                       receipt=str(execution.directory/'receipt.json')))
        save()
        assert execution.ok and execution.receipt['job_empty_observed'], name
    assert all(sha(R/name) == value for name, value in hashes.items()), 'source changed during validation'
    result['status'] = 'PASS_SOURCE_CHECKS'
except BaseException as exc:
    result.update(status='FAIL_RETAINED', error=str(exc), traceback=traceback.format_exc())
finally:
    save()
    print(json.dumps(dict(status=result['status'], commands=len(result['commands']), native_executed=False)))
