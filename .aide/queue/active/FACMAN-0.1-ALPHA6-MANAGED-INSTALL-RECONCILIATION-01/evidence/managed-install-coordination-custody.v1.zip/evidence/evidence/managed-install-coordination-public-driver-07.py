import hashlib, json, os, subprocess, sys, traceback
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher')
W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e')
E=W/'evidence'; B=W/'native-developer'; sys.path.insert(0,str(R))
from tools import provider_canary_process as owned
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',FACMAN_MIN_FREE_GIB='12')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
original=json.loads((E/'managed-install-coordination-native-result-03.json').read_text(encoding='utf-8'))
hashes={name:sha(R/name) for name in original['source_files_sha256']}
assert hashes['tests/integration/facman_managed_install_lifecycle.py']=='49c4bd39311b97046c21521e8c3ffa0a072b92884473f8489e8620c8d5a25c36'
assert all(hashes[n]==v for n,v in original['source_files_sha256'].items() if n!='tests/integration/facman_managed_install_lifecycle.py')
assert all(sha(B/'Release'/n)==v for n,v in original['binary_images_sha256'].items())
proof=W/'t/j3/mc07'; assert not proof.exists()
out=E/'managed-install-coordination-public-result-07.json'; assert not out.exists()
result=dict(schema='facman.coordination.public_continuation.v1',status='running',source_files_sha256=hashes,commands=[],original_native_result_sha256=sha(E/'managed-install-coordination-native-result-03.json'),native_rebuild=False)
def save():out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
def run(name,args,timeout):
    x=owned.command([str(a) for a in args],cwd=R,environment=dict(os.environ),timeout=timeout,directory=E/f'managed-install-coordination-{name}-execution-07',output_limit=8*1024*1024,wait_for_job_empty_after_primary=False)
    result['commands'].append(dict(name=name,command=[str(a) for a in args],exit_code=x.returncode,termination=x.receipt['termination'],primary_stopped=x.receipt['primary_stopped'],job_empty=x.receipt['job_empty_observed'],receipt=str(x.directory/'receipt.json'),receipt_sha256=sha(x.directory/'receipt.json')));save()
    assert x.ok and x.receipt['job_empty_observed'],name
try:
    assert subprocess.check_output(['git','branch','--show-current'],cwd=R).decode('utf-8').strip()==original['branch']
    run('public',['py','-3','-B','tests/integration/facman_managed_install_lifecycle.py','--facman',B/'Release/facman.exe','--root',proof,'--scenario','coordination'],600)
    public=json.loads((proof/'receipt.json').read_text(encoding='utf-8'));assert public['result']=='pass'
    result.update(public_receipt=str(proof/'receipt.json'),public_receipt_sha256=sha(proof/'receipt.json'),public_steps=len(public['steps']))
    run('strict',['py','-3','-B','tools/strict_check.py'],1800)
    run('aide',['py','-3','-B','.aide/scripts/aide_lite.py','test'],600)
    run('diff',['git','diff','--check'],60)
    assert all(sha(R/n)==v for n,v in hashes.items())
    result['status']='PASS_SCOPED_SYNTHETIC_PUBLIC_COORDINATION'
except BaseException as exc:result.update(status='FAIL_RETAINED',error=str(exc),traceback=traceback.format_exc())
finally:save();print(json.dumps(dict(status=result['status'],commands=len(result['commands']),public_steps=result.get('public_steps',0))))
