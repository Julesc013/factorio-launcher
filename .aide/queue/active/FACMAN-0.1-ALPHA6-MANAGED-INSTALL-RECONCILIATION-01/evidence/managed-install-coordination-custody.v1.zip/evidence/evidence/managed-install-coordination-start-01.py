import hashlib,json,os,subprocess,sys,traceback
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher');E=Path(__file__).resolve().parent;W=E.parent
BASE='c089396b6210b8da18299fe8376bf1cea203826a';BRANCH='task/facman-managed-install-coordination-01'
os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds',TEMP=str(W/'t'),TMP=str(W/'t'),PYTHONDONTWRITEBYTECODE='1')
sys.path.insert(0,str(R));from tools import provider_canary_process as owned
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True,encoding='utf-8').strip()
out=E/'managed-install-coordination-start-result-01.json';assert not out.exists()
record=dict(status='VERIFYING_NEXT_ADMITTED_MANAGED_INSTALL_CLAUSE',commands=[],base=BASE,new_roots=0,new_worktrees=0,new_clones=0,parallel_Universal_checkout_preserved=True,goal_status_mutated=False)
def save():out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
def run(label,args,timeout=180,codes=(0,)):
 r=owned.command(args,cwd=R,environment=dict(os.environ),timeout=timeout,directory=E/('managed-install-start01-'+label),output_limit=2*1024**2,wait_for_job_empty_after_primary=True)
 record['commands'].append(dict(label=label,exit=r.returncode,receipt_sha256=sha(r.directory/'receipt.json')));save()
 assert r.returncode in codes and r.receipt['termination']=='completed' and r.receipt['primary_stopped'] and r.receipt['job_empty_observed'] and not r.receipt['job_terminated'],(label,r.stderr[-1200:].decode('utf-8','replace'))
 return r
try:
 assert git('branch','--show-current')=='dev' and git('rev-parse','HEAD')==BASE and git('rev-parse','origin/dev')==BASE and not git('status','--porcelain')
 previous=json.loads((E/'windows-delivered-gui-visible-controls-checked-integration-result-01.json').read_bytes())
 assert previous['status']=='merged_exact_source' and previous['required_checks_all_pass'] and previous['pr_state']['mergeCommit']['oid']==BASE
 for label in ('policy','detect','plan'):run(label,['py','-3','-B','.aide/scripts/aide_lite.py','git',label])
 run('paths',['py','-3','-B','tools/workspace_hygiene.py','paths'])
 h=json.loads(run('doctor',['py','-3','-B','tools/workspace_hygiene.py','doctor','--measure'],600,(0,1)).stdout)
 assert set(h['violations'])<={'unmanaged_secondary_worktrees_present'} and len(h['task_roots'])==8 and h['task_root_bytes']<20*1024**3
 assert not git('branch','--list',BRANCH)
 run('start-task',['git','switch','-c',BRANCH,BASE])
 assert git('branch','--show-current')==BRANCH and git('rev-parse','HEAD')==BASE and not git('status','--porcelain')
 record.update(status='STARTED_NEXT_READY_MANAGED_INSTALL_COORDINATION',branch=BRANCH,work_item='FACMAN-0.1-ALPHA6-MANAGED-INSTALL-RECONCILIATION-01',task_root=str(W),prior_qualification_sha256=sha(E/'windows-delivered-gui-visible-controls-checked-integration-result-01.json'))
except BaseException as error:record.update(status='ACTIONABLE_NEXT_MANAGED_CLAUSE_START_FAILURE',error=str(error),traceback=traceback.format_exc())
finally:save();print(json.dumps({k:v for k,v in record.items() if k not in ('commands','traceback')},indent=2))
raise SystemExit(0 if record['status']=='STARTED_NEXT_READY_MANAGED_INSTALL_COORDINATION' else 1)
