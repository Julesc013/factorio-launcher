import hashlib, json, os, shutil, subprocess, sys, time, traceback
from pathlib import Path

R = Path(r'D:\Projects\Factorio\factorio-launcher')
W = Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e')
E, B = W/'evidence', W/'native-developer'
sys.path.insert(0, str(R))
sys.dont_write_bytecode = True
from tools import native_build, provider_canary_process as owned

os.environ.update(FACMAN_DEV_ROOT=r'D:\Projects\Factorio\.task-builds', TEMP=str(W/'t'), TMP=str(W/'t'),
                  PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1', FACMAN_MIN_FREE_GIB='12',
                  CMAKE_BUILD_PARALLEL_LEVEL='2', MSBUILDDISABLENODEREUSE='1')
files = ['runtime/factorio/application/handlers/setup.cpp', 'runtime/factorio/application/setup_gateway.cpp',
         'runtime/factorio/application/setup_gateway.h', 'tests/native/m1_three_repository_system_proof.cpp',
         'tests/integration/facman_managed_install_lifecycle.py', 'docs/reviews/2026-10-15-managed-install-coordination.md']
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
hashes = {name: sha(R/name) for name in files}
assert hashes['runtime/factorio/application/handlers/setup.cpp'] == '4e3557ff63d3b555ba8afdb2577f27f442ad972243c24eef37b6eedf3bb3fabe'
assert hashes['runtime/factorio/application/setup_gateway.cpp'] == '2cdd37f7109ebaacc9ada5786b4ae288632c96cc94094295138630137742dc8e'
assert hashes['runtime/factorio/application/setup_gateway.h'] == '61063f6e9ce5ce377b0a7dc1a6ae7e82c45350f01836c10e883d6bf0af35238c'
def git(*args): return subprocess.check_output(['git', *args], cwd=R).decode('utf-8').strip()
assert git('branch', '--show-current') == 'task/facman-managed-install-coordination-01'
assert git('rev-parse', 'HEAD') == 'c089396b6210b8da18299fe8376bf1cea203826a'
provider_hashes = {name: sha(B/'Release'/name) for name in ('ulk.dll', 'usk.dll')}
result_path = E/'managed-install-coordination-native-result-03.json'
assert not result_path.exists()
proof = W/'t/j3/mc03'
assert not proof.exists()
result = dict(schema='facman.managed_install_coordination.native_validation.v1', status='resource_admission',
              base=git('rev-parse', 'HEAD'), branch=git('branch', '--show-current'),
              source_files_sha256=hashes, provider_images_sha256=provider_hashes,
              commands=[], new_roots=0, new_clones=0, new_worktrees=0, native_workers=2,
              clean_first=False, tracking_enabled=True, self_approval=False,
              genuine_game_touched=False, produced_package_qualified=False)
def save(): result_path.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
def bound():
    assert git('branch', '--show-current') == result['branch'] and git('rev-parse', 'HEAD') == result['base']
    assert all(sha(R/name) == value for name, value in hashes.items()), 'source changed during validation'
    assert all(sha(B/'Release'/name) == value for name, value in provider_hashes.items()), 'provider image changed'
def run(name, args, timeout=600, budget=None, accepted=(0,)):
    execution = owned.command([str(x) for x in args], cwd=R, environment=dict(os.environ), timeout=timeout,
                              budget=budget, directory=E/f'managed-install-coordination-{name}-execution-03',
                              output_limit=8*1024*1024, wait_for_job_empty_after_primary=False)
    result['commands'].append(dict(name=name, argv=[str(x) for x in args], exit_code=execution.returncode,
                                   termination=execution.receipt['termination'],
                                   primary_stopped=execution.receipt['primary_stopped'],
                                   job_empty=execution.receipt['job_empty_observed'],
                                   receipt=str(execution.directory/'receipt.json'),
                                   receipt_sha256=sha(execution.directory/'receipt.json')))
    save()
    assert execution.receipt['termination'] == 'completed' and execution.returncode in accepted and execution.receipt['job_empty_observed'], name
    return execution
save()
try:
    run('paths', ['py', '-3', '-B', 'tools/workspace_hygiene.py', 'paths'], 90)
    measured = run('doctor', ['py', '-3', '-B', 'tools/workspace_hygiene.py', 'doctor', '--measure'], 180, accepted=(0, 1))
    resources = json.loads(measured.stdout.decode('utf-8'))
    assert len(resources['task_roots']) <= 8 and resources['task_root_bytes'] + 1024**3 <= 20*1024**3
    assert set(resources['violations']) <= {'unmanaged_secondary_worktrees_present', 'merged_local_task_branches_present'}
    assert shutil.disk_usage(W).free >= 12*1024**3
    result['resources'] = dict(owned_roots=len(resources['task_roots']), owned_bytes=resources['task_root_bytes'],
                               free_bytes=shutil.disk_usage(W).free, additional_budget_bytes=1024**3)
    save()
    # Healthy foreign work has no admission timeout and is never terminated.
    previous, counter = None, 0
    while True:
        counter += 1
        query = "$p=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(cl|clang|link|ninja|ctest)\\.exe$' -or ($_.Name -eq 'cmake.exe' -and $_.CommandLine -like '*--build*') -or ($_.Name -eq 'MSBuild.exe' -and $_.CommandLine -notlike '*/nodemode:*') } | Select-Object Name,ProcessId,CreationDate); ConvertTo-Json -InputObject $p -Compress"
        observed = owned.command(['pwsh', '-NoProfile', '-Command', query], cwd=R, timeout=45,
                                 directory=E/f'managed-install-coordination-native-admission-03-{counter:03d}')
        assert observed.ok
        active = json.loads(observed.stdout or b'[]')
        if not active: break
        if active != previous:
            result.update(status='waiting_for_foreign_native_job', foreign_job_count=len(active))
            save()
            print('Waiting for foreign native job; preserved untouched.', flush=True)
            previous = active
        time.sleep(60)
    native_build.require_disk_reserve(B)
    bound()
    result['status'] = 'building_affected_targets'
    save()
    budget = owned.Budget(7200, 1800)
    run('build', ['cmake', '--build', B, '--config', 'Release', '--parallel', '2', '--target',
                  'facman_cli', 'm1_three_repository_system_proof', 'flb_setup_gateway_smoke',
                  'fl_workspace_store_smoke', 'facman_isolation_lock_smoke', '--', '/nr:false'], 1800, budget)
    bound()
    result['binary_images_sha256'] = {name: sha(B/'Release'/name) for name in (
        'facman.exe', 'm1_three_repository_system_proof.exe', 'flb_setup_gateway_smoke.exe',
        'fl_workspace_store_smoke.exe', 'facman_isolation_lock_smoke.exe')}
    save()
    run('ctest', ['ctest', '--test-dir', B, '-C', 'Release', '--output-on-failure', '--no-tests=error',
                  '-R', '^(m1_three_repository_system_proof|flb_setup_gateway_smoke|fl_workspace_store_smoke|facman_isolation_lock_smoke)$'], 600, budget)
    result['status'] = 'public_coordination_validation'
    save()
    run('public', ['py', '-3', '-B', 'tests/integration/facman_managed_install_lifecycle.py',
                   '--facman', B/'Release/facman.exe', '--root', proof, '--scenario', 'coordination'], 600, budget)
    public = json.loads((proof/'receipt.json').read_text(encoding='utf-8'))
    assert public['result'] == 'pass'
    result.update(public_steps=len(public['steps']), public_receipt=str(proof/'receipt.json'),
                  public_receipt_sha256=sha(proof/'receipt.json'))
    save()
    run('strict', ['py', '-3', '-B', 'tools/strict_check.py'], 1800, budget)
    run('aide', ['py', '-3', '-B', '.aide/scripts/aide_lite.py', 'test'], 600, budget)
    bound()
    result.update(status='PASS_SCOPED_SYNTHETIC_NATIVE_COORDINATION', workunit_closed=False,
                  human_qualified=False, physical_host_qualified=False, beta_qualified=False)
except BaseException as exc:
    result.update(status='FAIL_RETAINED', error=str(exc), traceback=traceback.format_exc())
finally:
    save()
    print(json.dumps(dict(status=result['status'], commands=len(result['commands']), public_steps=result.get('public_steps', 0))))
