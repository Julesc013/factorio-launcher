import ctypes as C, ctypes.wintypes as T, datetime, hashlib, json, os, subprocess, sys
from pathlib import Path
R = Path(r'D:\Projects\Factorio\factorio-launcher')
W = Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e')
E = W/'evidence'
sys.path.insert(0, str(R)); sys.dont_write_bytecode = True
from tools import provider_canary_process_windows as native
api = native.kernel()
for name, args, rest in [
    ('OpenProcess', [T.DWORD,T.BOOL,T.DWORD], T.HANDLE),
    ('GetCurrentProcess', [], T.HANDLE),
    ('DuplicateHandle', [T.HANDLE,T.HANDLE,T.HANDLE,C.POINTER(T.HANDLE),T.DWORD,T.BOOL,T.DWORD], T.BOOL),
    ('GetProcessId', [T.HANDLE], T.DWORD),
    ('QueryFullProcessImageNameW', [T.HANDLE,T.DWORD,T.LPWSTR,C.POINTER(T.DWORD)], T.BOOL),
]:
    function = getattr(api,name); function.argtypes=args; function.restype=rest
nt = C.WinDLL('ntdll')
nt.NtQueryInformationProcess.argtypes=[T.HANDLE,C.c_int,C.c_void_p,T.DWORD,C.POINTER(T.DWORD)]
nt.NtQueryInformationProcess.restype=C.c_long
class Entry(C.Structure):
    _fields_=[('handle',C.c_size_t),('handle_count',C.c_size_t),('pointer_count',C.c_size_t),
              ('access',T.DWORD),('type',T.DWORD),('attributes',T.DWORD),('reserved',T.DWORD)]
class Basic(C.Structure):
    _fields_=[('exit',C.c_long),('peb',C.c_void_p),('affinity',C.c_size_t),('priority',C.c_long),
              ('pid',C.c_size_t),('parent',C.c_size_t)]
def require(value,label):
    if not value: raise OSError(C.get_last_error(),label)
def snapshot(process):
    buffer=C.create_string_buffer(256*1024); needed=T.DWORD()
    status=nt.NtQueryInformationProcess(process,51,buffer,len(buffer),C.byref(needed))
    assert status==0,(status,needed.value)
    count=C.c_size_t.from_buffer(buffer,0).value
    assert count<=4096 and 2*C.sizeof(C.c_size_t)+count*C.sizeof(Entry)<=len(buffer)
    return [Entry.from_buffer_copy(buffer,2*C.sizeof(C.c_size_t)+i*C.sizeof(Entry)) for i in range(count)]
def times(process):
    values=[C.c_ulonglong() for _ in range(4)]
    require(api.GetProcessTimes(process,*[C.byref(v) for v in values]),'GetProcessTimes')
    return values[0].value
def image(process):
    value=C.create_unicode_buffer(32768); size=T.DWORD(len(value))
    if api.QueryFullProcessImageNameW(process,0,value,C.byref(size)): return value.value
    first_error=C.get_last_error()
    buffer=C.create_string_buffer(65536); length=T.DWORD()
    status=nt.NtQueryInformationProcess(process,27,buffer,len(buffer),C.byref(length))
    if status!=0: return None,first_error,status
    class Unicode(C.Structure):
        _fields_=[('length',T.WORD),('maximum',T.WORD),('buffer',C.c_void_p)]
    text=Unicode.from_buffer(buffer)
    assert text.length<=32768 and text.buffer>=C.addressof(buffer) and text.buffer+text.length<=C.addressof(buffer)+len(buffer)
    return C.wstring_at(text.buffer,text.length//2)
def duplicate(handle):
    copied=T.HANDLE()
    require(api.DuplicateHandle(source,handle,current,C.byref(copied),0,False,2),'DuplicateHandle exact driver')
    return copied
driver=E/'managed-install-coordination-native-driver-01.py'
query="$p=@(Get-CimInstance Win32_Process -Filter \"Name = 'python.exe'\" | Where-Object { $_.CommandLine -like '*managed-install-coordination-native-driver-01.py*' } | Select-Object ProcessId,ParentProcessId,CreationDate,CommandLine,ExecutablePath); ConvertTo-Json -InputObject $p -Compress"
observed=json.loads(subprocess.check_output(['pwsh','-NoProfile','-Command',query],cwd=R).decode('utf-8'))
assert len(observed)==1
selected=observed[0]; assert str(driver).lower() in selected['CommandLine'].replace('/','\\').lower()
pid=selected['ProcessId']; source=api.OpenProcess(0x440,False,pid); require(source,'OpenProcess exact driver')
current=api.GetCurrentProcess(); local_job=api.CreateJobObjectW(None,None); require(local_job,'local type probe')
receipt=E/'managed-install-coordination-build-execution-01/receipt.json'
command=json.loads(receipt.read_text(encoding='utf-8'))['command']
result=dict(schema='facman.owned_build_job_readonly_inspection.v1',driver_pid=pid,
            driver_creation_filetime=times(source),driver_script=str(driver),
            driver_script_sha256=hashlib.sha256(driver.read_bytes()).hexdigest(),
            driver_command_sha256=hashlib.sha256(selected['CommandLine'].encode('utf-8')).hexdigest(),
            selected_command=command,source_job_mutated=False,debug_privilege_enabled=False)
copies=[]
try:
    local=snapshot(current)
    job_type=next(item.type for item in local if item.handle==local_job)
    process_type=next(item.type for item in local if item.handle==source)
    entries=snapshot(source)
    jobs=[item for item in entries if item.type==job_type]
    assert len(jobs)==1,'exact driver must hold one child job'
    job=duplicate(jobs[0].handle); copies.append(job)
    accounting=native.Accounting()
    require(api.QueryInformationJobObject(job,1,C.byref(accounting),C.sizeof(accounting),None),'owned job accounting')
    buffer=C.create_string_buffer(65536)
    require(api.QueryInformationJobObject(job,3,buffer,len(buffer),None),'owned job member IDs')
    assigned=T.DWORD.from_buffer(buffer,0).value; count=T.DWORD.from_buffer(buffer,4).value
    assert count<=1024
    members=[C.c_size_t.from_buffer(buffer,8+i*C.sizeof(C.c_size_t)).value for i in range(count)]
    assert pid not in members and selected['ParentProcessId'] not in members and os.getpid() not in members
    primary=[]
    for entry in entries:
        if entry.type!=process_type: continue
        handle=duplicate(entry.handle); copies.append(handle)
        process_image=image(handle)
        if isinstance(process_image,str) and Path(process_image).name.lower()!='cmake.exe': continue
        basic=Basic(); length=T.DWORD()
        assert nt.NtQueryInformationProcess(handle,0,C.byref(basic),C.sizeof(basic),C.byref(length))==0
        code=T.DWORD(); require(api.GetExitCodeProcess(handle,C.byref(code)),'held primary exit')
        assert basic.parent==pid
        if isinstance(process_image,str): assert Path(process_image).name.lower()==Path(command[0]).name.lower()
        primary.append(dict(handle=entry.handle,pid=api.GetProcessId(handle),parent_pid=basic.parent,
                            image=process_image,expected_image=command[0],creation_filetime=times(handle),exit_code=code.value,
                            command_binding='unique held CMake created by exact frozen driver; selected command receipt'))
    assert len(primary)==1 and primary[0]['exit_code']!=259
    assert primary[0]['creation_filetime']>=result['driver_creation_filetime']
    member_query='$ids=@('+','.join(str(item) for item in members)+'); $p=@(Get-CimInstance Win32_Process | Where-Object { $ids -contains $_.ProcessId } | Select-Object ProcessId,ParentProcessId,Name,CreationDate,CommandLine); ConvertTo-Json -InputObject $p -Compress'
    details=json.loads(subprocess.check_output(['pwsh','-NoProfile','-Command',member_query],cwd=R).decode('utf-8'))
    result.update(status='READ_ONLY_BOUND',source_job_handle=jobs[0].handle,
                  source_job_type_index=job_type,active_members=members,assigned=assigned,
                  accounting_active=accounting.active,primary=primary[0],
                  members=[dict(pid=item['ProcessId'],parent_pid=item['ParentProcessId'],name=item['Name'],
                                creation=item['CreationDate'],command_sha256=hashlib.sha256(item['CommandLine'].encode('utf-8')).hexdigest()) for item in details])
    path=E/'managed-install-coordination-owned-job-inspection-01.json'; assert not path.exists()
    path.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(status=result['status'],primary_exit=result['primary']['exit_code'],
                         residual_members=len(members),member_names=[item['name'] for item in result['members']],
                         receipt_sha256=hashlib.sha256(path.read_bytes()).hexdigest())))
finally:
    for handle in copies: api.CloseHandle(handle)
    api.CloseHandle(local_job); api.CloseHandle(source)
