import hashlib,json,os,subprocess,sys
from pathlib import Path
R=Path(r'D:\Projects\Factorio\factorio-launcher')
W=Path(r'D:\Projects\Factorio\.task-builds\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e')
E=W/'evidence';B=W/'native-developer';sys.path.insert(0,str(R))
from tools import provider_canary_process as owned
os.environ.update(PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',TEMP=str(W/'t'),TMP=str(W/'t'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R).decode('utf-8').strip()
native_path=E/'managed-install-coordination-native-result-11.json'
native=json.loads(native_path.read_text(encoding='utf-8'))
assert native['status']=='FAIL_RETAINED' and native['error']=='public'
qualification_path=E/'managed-install-coordination-qualification-result-01.json'
qualification=json.loads(qualification_path.read_text(encoding='utf-8'))
assert qualification['status']=='SCOPED_COORDINATION_CASES_PASSED_WITH_RETAINED_HOST_GAP'
assert git('rev-parse','HEAD')==native['base'] and git('branch','--show-current')==native['branch']
assert all(sha(R/n)==v for n,v in native['source_files_sha256'].items())
assert all(sha(B/'Release'/n)==v for n,v in native['binary_images_sha256'].items())
assert all(sha(B/'Release'/n)==v for n,v in native['provider_images_sha256'].items())
assert len(native['source_files_sha256'])==6
diff_path=E/'managed-install-coordination-final-diff-execution-01/receipt.json'
diff=json.loads(diff_path.read_text(encoding='utf-8'))
assert diff['exit_code']==0 and diff['job_empty_observed']
proof=W/'t/j3/mc11';public=json.loads((proof/'receipt.json').read_text(encoding='utf-8'));assert public['result']=='partial' and len(public['open_gaps'])==1
process=[]
for p in sorted(proof.glob('execution-*/receipt.json')):
    x=json.loads(p.read_text(encoding='utf-8'))
    assert x['dispatched'] and x['primary_stopped'] and x['job_empty_observed']
    assert x['termination'] in ('completed','command_timeout')
    process.append(dict(path=str(p),sha256=sha(p),command=x['command'],exit_code=x['exit_code'],termination=x['termination'],primary_stopped=x['primary_stopped'],job_empty=x['job_empty_observed'],job_terminated=x['job_terminated'],elapsed_seconds=x['elapsed_seconds']))
assert sum(x['termination']=='command_timeout' for x in process)==3
artifacts=set()
for p in E.glob('managed-install-coordination-*'):
    if p.is_file():artifacts.add(p)
    elif p.is_dir():artifacts.update(q for q in p.rglob('*') if q.is_file() and q.suffix in ('.json','.py','.raw','.log','.txt'))
proof_roots=[W/'managed-install-coordination-public-proof-01']+[W/f't/j3/mc{i:02d}' for i in range(2,12)]
for root in proof_roots:
    if not root.exists():continue
    for p in root.rglob('*'):
        if not p.is_file():continue
        if p.name in ('receipt.json','stdout.raw','stderr.raw') or p.name.endswith(('.journal.json','.transaction.v1.json','.lock')):
            artifacts.add(p)
failure_layers={
    'public01':'existing provider journal temporary Windows259 UTF16 path policy',
    'public02':'new pre-entry refusal inherited internal_error; fixed explicit OutcomeKind::refused',
    'public03':'earlier provider Windows247 UTF16 planning policy blocks metadata8192 reachability',
    'public04':'observer attempted read of exact exclusively held transaction guard; explicit exclusion with separate lifetime oracle',
    'public05':'USK current_state completed versus FacMan complete; actual provider label corrected',
    'public06':'held sidecar ordinary Python sharing failure; exact shared raw handle read reused',
    'public07':'actual safe contention because2.094s uninstall exceeded2s race observation pause; BEFORE hook6s',
    'public08':'physical REQUESTED no-provider install recovery could inspect but not legally close; existing recovery_required closure route',
    'public09':'repair fixture had no damaged owned files; synthetic damaged input supplied before oracle',
    'public10':'physical REQUESTED repair refused before provider inspection; seven exact early nonterminal states admitted',
    'public11':'all executed assertions passed; actual partial/exit1 preserved solely for known Windows8192 reachability gap',
    'source_strict01':'handler raw JSON boundary violation; typed codec moved into setup_gateway',
}
packet=dict(schema='facman.managed_install_coordination.author_packet.v1',status='AUTHOR_READY_FOR_INDEPENDENT_REVIEW_WITH_RETAINED_HOST_GAP',self_approval=False,scope_verdict=qualification['status'],overall_public_pass=False,
    work_item='FACMAN-0.1-ALPHA6-MANAGED-INSTALL-RECONCILIATION-01',base=native['base'],base_tree=git('rev-parse','HEAD^{tree}'),branch=native['branch'],
    author_files=[dict(path=n,sha256=v,git_blob=git('hash-object','--',n)) for n,v in native['source_files_sha256'].items()],
    native_result=dict(path=str(native_path),sha256=sha(native_path)),qualification_result=dict(path=str(qualification_path),sha256=sha(qualification_path)),native_tests_passed=4,native_commands=native['commands'],final_checks=qualification['commands'],
    public_proof=dict(path=str(proof/'receipt.json'),sha256=sha(proof/'receipt.json'),steps=len(public['steps']),actual_command_count=len(process),actual_result='partial',actual_exit_code=1),
    public_process_receipts=process,physical_death_commands=3,
    byte_oracles=[x for x in public['steps'] if 'product_before' in x or 'generation_before' in x],
    final_diff_receipt=dict(path=str(diff_path),sha256=sha(diff_path)),
    binary_images_sha256=native['binary_images_sha256'],provider_images_sha256=native['provider_images_sha256'],
    preserved_first_failures=failure_layers,
    preserved_artifacts=[dict(path=str(p),sha256=sha(p)) for p in sorted(artifacts)],
    limits=public['open_gaps']+['portable ASCII Setup-root leaf required; Unicode/spaces in existing parents supported','coordinates only FacMan actors sharing configured provider-install identity; direct USK/different provider roots sharing target excluded','POSIX active same-inode foreign-edit branch retained in source but not executed on this Windows host','no real game, human, physical-host, package, Beta or release qualification'],
    resources=native['resources'],new_owned_task_roots=0,new_worktrees=0,new_clones=0,git_mutations=0,real_game_touched=False,
    manual_auxiliary_termination='aborted at first prepared-receipt assertion; no handle access or mutation; original build01 completed naturally',
    successful_build_auxiliary_cleanup='normal owned harness waitFalse Job cleanup; receipt job_terminated flags retained; no all-member natural-exit claim',
    custody_binary_payloads_included=False,console_count_note='public stdout reports38 evidence steps as fresh processes; actual owned dispatch receipt count39 is authoritative')
manifest=json.dumps(packet['author_files'],sort_keys=True,separators=(',',':')).encode('utf-8')
packet['author_source_manifest_sha256']=hashlib.sha256(manifest).hexdigest()
out=E/'managed-install-coordination-author-packet-01.json';assert not out.exists()
out.write_text(json.dumps(packet,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=packet['status'],packet_sha256=sha(out),author_files=6,native_tests=4,public_commands=len(process),public_steps=len(public['steps']),preserved_artifacts=len(artifacts))))
