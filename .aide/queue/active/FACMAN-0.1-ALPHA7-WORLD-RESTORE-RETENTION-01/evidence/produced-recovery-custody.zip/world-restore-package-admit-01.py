"""Admit and retain one exact-source unpublished bundle; no product execution."""
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import subprocess
import sys
import zipfile

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
HEAD = 'f6076c532148078e2c558705d389f0d936814b4b'
TREE = '88aae2d53fa5104f4bac34b3a3047b932b635449'
REPO = 'Julesc013/factorio-launcher'
PREFIX = 'world-restore-package-admit-01'
VERSION = '0.1.0-alpha.6'
CAP = 512 * 1024**2
PEAK = 6 * 1024**3
CAMPAIGN = E / 'world-restore-package-candidate-01.json'
BUNDLE = E / 'world-restore-repaired-bundle'
ARCHIVE = E / (PREFIX + '.zip')
OUT = E / (PREFIX + '.json')
sys.path.insert(0, str(R))
from tools.package.candidate_evidence import verify_bundle


def sha(p):
    with p.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        f.write(json.dumps(value, indent=2) + '\n')


def output(*args):
    result = subprocess.run(args, cwd=R, capture_output=True, text=True, encoding='utf-8', timeout=120)
    assert result.returncode == 0, (args[:4], result.returncode, result.stderr[:400])
    assert len(result.stdout.encode('utf-8')) <= 8 * 1024**2
    return result.stdout.strip()


def api(path):
    return json.loads(output('gh', 'api', f'repos/{REPO}/{path}'))


def source():
    assert output('git', 'branch', '--show-current') == 'dev'
    assert output('git', 'rev-parse', 'HEAD') == HEAD and output('git', 'rev-parse', 'HEAD^{tree}') == TREE
    assert not output('git', 'status', '--porcelain')


def safe(name):
    p = PurePosixPath(name)
    assert name and '\\' not in name and ':' not in name and not p.is_absolute()
    assert all(part not in {'', '.', '..'} for part in name.split('/'))
    return p


def main():
    assert __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0' and os.environ.get('PYTHONDONTWRITEBYTECODE') == '1'
    review_path = E / (PREFIX + '.review.json')
    review = json.loads(review_path.read_text())
    assert review['verdict'] == 'PASS' and review['independent'] and review['non_authoring']
    assert review['script_sha256'] == sha(Path(__file__))
    assert not ARCHIVE.exists() and not BUNDLE.exists() and not OUT.exists()
    marker = json.loads((E.parent / '.facman-development-root.v1.json').read_text())
    assert marker['task_id'] == 'task/facman-world-restore-retention-01' and Path(marker['canonical_path']).samefile(E.parent)
    assert marker['owner'] == 'facman-development' and marker['kind'] == 'task-root'
    source()
    assert output('powershell', '-NoProfile', '-Command', '[System.Security.Principal.WindowsIdentity]::GetCurrent().Name') == 'BLACKGLASS-WIN1\\Jules'
    assert subprocess.run(['gh', 'auth', 'status'], cwd=R, capture_output=True, timeout=60).returncode == 0
    assert output('gh', 'api', 'user', '--jq', '.login') == 'Julesc013'
    campaign = json.loads(CAMPAIGN.read_text())
    assert campaign['status'] == 'exact_dev_unpublished_candidate_PASS' and campaign['source_head'] == HEAD
    assert campaign['source_tree'] == TREE and campaign['dispatches'] == 1 and campaign['reruns'] == 0
    run_id = campaign['run_id']
    run = api(f'actions/runs/{run_id}')
    assert run['head_sha'] == HEAD and run['head_branch'] == 'dev' and run['run_attempt'] == 1
    assert run['workflow_id'] == 347619223 and run['event'] == 'workflow_dispatch'
    assert run['status'] == 'completed' and run['conclusion'] == 'success'
    pages = json.loads(output('gh', 'api', '--paginate', '--slurp', f'repos/{REPO}/actions/runs/{run_id}/artifacts?per_page=100'))
    artifacts = [a for page in pages for a in page['artifacts']]
    name = f'FacMan-{VERSION}-unsigned-unpublished-candidate-{run_id}-1-{HEAD}'
    matches = [a for a in artifacts if a['name'] == name]
    assert len(matches) == 1
    artifact = matches[0]
    assert not artifact['expired'] and 0 < artifact['size_in_bytes'] <= CAP
    assert artifact['workflow_run']['id'] == run_id and artifact['workflow_run']['head_sha'] == HEAD
    assert artifact['workflow_run']['head_branch'] == 'dev'
    measured = subprocess.run([sys.executable, '-B', 'tools/workspace_hygiene.py', 'doctor', '--measure'], cwd=R, capture_output=True, text=True, timeout=180)
    assert measured.returncode in (0, 1)
    doctor = json.loads(measured.stdout)
    assert set(doctor['violations']) <= {'unmanaged_secondary_worktrees_present', 'merged_local_task_branches_present'}
    assert len(doctor['task_roots']) <= 8 and doctor['task_root_bytes'] + PEAK <= 20 * 1024**3
    assert shutil.disk_usage(E).free >= PEAK + 8 * 1024**3
    write(E / (PREFIX + '.admission.json'), {'run': run, 'artifact': artifact, 'campaign_sha256': sha(CAMPAIGN), 'resources': doctor, 'peak_reserved_bytes': PEAK, 'script_sha256': sha(Path(__file__)), 'review_sha256': sha(review_path), 'new_roots': 0, 'product_executions': 0})
    with ARCHIVE.open('xb') as target, (E / (PREFIX + '.download.log')).open('x', encoding='utf-8') as log:
        result = subprocess.run(['gh', 'api', f'repos/{REPO}/actions/artifacts/{artifact["id"]}/zip'], cwd=R, stdin=subprocess.DEVNULL, stdout=target, stderr=log, timeout=300)
    assert result.returncode == 0 and 0 < ARCHIVE.stat().st_size <= CAP
    assert artifact['digest'] == 'sha256:' + sha(ARCHIVE)
    with zipfile.ZipFile(ARCHIVE) as archive:
        members = archive.infolist()
        assert len(members) == 14 and len({m.filename for m in members}) == 14
        assert sum(m.file_size for m in members) <= CAP
        for m in members:
            assert len(safe(m.filename).parts) == 1 and not m.is_dir() and not m.flag_bits & 1
            assert stat.S_IFMT(m.external_attr >> 16) in {0, stat.S_IFREG}
        BUNDLE.mkdir()
        for m in members:
            with archive.open(m) as incoming, (BUNDLE / m.filename).open('xb') as target:
                shutil.copyfileobj(incoming, target, 1024**2)
    proof = verify_bundle(BUNDLE)
    assert proof['source_revision'] == HEAD and proof['source_tree'] == TREE and proof['version'] == VERSION
    assert proof['github'] == {'repository': REPO, 'workflow_ref': f'{REPO}/.github/workflows/product-candidate.yml@refs/heads/dev', 'run_id': str(run_id), 'run_attempt': '1', 'job': 'bundle'}
    assert len(proof['assets']) == 6
    source()
    record = {'status': 'PASS', 'source_head': HEAD, 'source_tree': TREE, 'run_id': run_id, 'run_attempt': 1,
              'artifact_id': artifact['id'], 'artifact_zip_sha256': sha(ARCHIVE), 'bundle': str(BUNDLE),
              'bundle_inventory': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in sorted(BUNDLE.iterdir())},
              'assets': proof['assets'], 'manifest_sha256': sha(BUNDLE / 'product-candidate-bundle.v1.json'),
              'candidate_receipt_sha256': sha(CAMPAIGN), 'new_roots': 0, 'builds': 0, 'candidate_dispatches': 0,
              'produced_package_runtime_qualified': False, 'whole_workunit_closed': False,
              'finished_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    write(OUT, record)
    print(json.dumps({k: record[k] for k in ('status', 'source_head', 'run_id', 'artifact_id', 'produced_package_runtime_qualified')}))


if __name__ == '__main__':
    main()
