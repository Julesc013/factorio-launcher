"""Prepare and observe one qualified, exact-dev, unpublished package campaign."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
REPO = 'Julesc013/factorio-launcher'
HEAD = 'f6076c532148078e2c558705d389f0d936814b4b'
TREE = '88aae2d53fa5104f4bac34b3a3047b932b635449'
SOURCE = '7c5469a5e60b5dd58c2cc57dcec1f4cedbf03065'
BASE = '0cbf208e17b6ceeb934e366357fe0992f685212c'
OWNER = 'task/facman-world-restore-retention-01'
PLAN = E / 'world-restore-package-candidate-01-plan.json'
REVIEW = E / 'world-restore-package-candidate-01.review.json'
CLAIM = E / 'world-restore-package-candidate-01.claim.json'
OUT = E / 'world-restore-package-candidate-01.json'
INTEGRATION = E / 'world-restore-recovery-integration-02.json'
POSIX = E / 'world-restore-posix-source-runtime.review.json'
WORKFLOW = '.github/workflows/product-candidate.yml'
PEAK = 6 * 1024**3
EXPECTED_JOBS = {
    'Version-current candidate contract', 'Windows x64 unsigned candidate',
    'macOS Intel unsigned preview candidate', 'Linux x64 unsigned preview candidate',
    'Exact six-asset unpublished candidate bundle',
}


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def write(p, value):
    temporary = p.with_suffix(p.suffix + '.writing')
    with temporary.open('x', encoding='utf-8', newline='\n') as f:
        f.write(json.dumps(value, indent=2) + '\n')
    temporary.replace(p)


def output(*argv):
    result = subprocess.run(argv, cwd=R, capture_output=True, text=True,
                            encoding='utf-8', errors='replace', timeout=120)
    assert result.returncode == 0, (argv[:4], result.returncode, result.stderr[:600])
    assert len(result.stdout.encode('utf-8')) <= 8 * 1024**2
    return result.stdout.strip()


def api(path):
    return json.loads(output('gh', 'api', 'repos/' + REPO + '/' + path))


def resources():
    result = subprocess.run([sys.executable, '-B', 'tools/workspace_hygiene.py', 'doctor', '--measure'],
                            cwd=R, capture_output=True, text=True, timeout=180)
    assert result.returncode in (0, 1)
    measured = json.loads(result.stdout)
    assert set(measured['violations']) <= {'unmanaged_secondary_worktrees_present', 'merged_local_task_branches_present'}
    assert len(measured['task_roots']) <= 8 and measured['task_root_bytes'] + PEAK <= 20 * 1024**3
    assert shutil.disk_usage(E).free >= PEAK + 8 * 1024**3
    return measured


def evidence_and_source():
    assert sha(INTEGRATION) == '9af4e8b6c34344563c14171c78d0fb086a29ff0742ca502cdd30bfbf23ba3343'
    integrated = json.loads(INTEGRATION.read_text())
    assert integrated['status'] == 'integration_and_automatic_merge_CI_pass' and integrated['merge_CI_pass']
    assert integrated['expected_head'] == SOURCE and integrated['expected_base'] == BASE
    assert integrated['merge'] == integrated['local_dev'] == HEAD and integrated['merge_requests'] == 1
    assert sha(POSIX) == '7b81182e72b16c83e9875b400c813a21403307e25c476433a49ecf9d7dde5d77'
    posix = json.loads(POSIX.read_text())
    assert posix['verdict'] == 'PASS_SCOPED_POSIX_SOURCE_FIXTURE' and posix['independent'] and posix['non_authoring']
    marker = json.loads((E.parent / '.facman-development-root.v1.json').read_text())
    assert marker['task_id'] == OWNER and Path(marker['canonical_path']).samefile(E.parent)
    assert output('git', 'branch', '--show-current') == 'dev'
    assert output('git', 'rev-parse', 'HEAD') == HEAD and output('git', 'rev-parse', 'HEAD^{tree}') == TREE
    assert output('git', 'rev-parse', 'refs/remotes/origin/dev') == HEAD
    assert output('git', 'show', '-s', '--format=%P', HEAD).split() == [BASE, SOURCE]
    assert not output('git', 'status', '--porcelain')
    assert api('git/ref/heads/dev')['object']['sha'] == HEAD
    return marker


def identity():
    assert output('powershell', '-NoProfile', '-Command', '[System.Security.Principal.WindowsIdentity]::GetCurrent().Name') == 'BLACKGLASS-WIN1\\Jules'
    assert subprocess.run(['gh', 'auth', 'status'], cwd=R, capture_output=True, timeout=60).returncode == 0
    assert output('gh', 'api', 'user', '--jq', '.login') == 'Julesc013'


def workflow_admission():
    workflow = api('actions/workflows/product-candidate.yml')
    assert workflow['state'] == 'active' and workflow['path'] == WORKFLOW
    pages = json.loads(output('gh', 'api', '--paginate', '--slurp',
                             f'repos/{REPO}/actions/workflows/{workflow["id"]}/runs?per_page=100'))
    runs = [run for page in pages for run in page['workflow_runs']]
    assert not any(run['status'] != 'completed' for run in runs), 'Preserve existing candidate ownership'
    assert not any(run['head_sha'] == HEAD for run in runs), 'Reattach existing exact-source candidate; never redispatch'
    return workflow


def prepare():
    assert not PLAN.exists() and not CLAIM.exists() and not OUT.exists()
    identity()
    marker = evidence_and_source()
    measured = resources()
    workflow = workflow_admission()
    inputs = {name: sha(R / name) for name in [WORKFLOW, 'release/index/providers.lock.v2.toml',
                                               'release/index/workspace_lock.v1.toml', 'release/index/version.v2.toml']}
    key = {'head': HEAD, 'tree': TREE, 'inputs': inputs,
           'profiles': ['windows_product_x64', 'macos_portable_cli_x64', 'linux_portable_cli_x64'],
           'intent': 'Repaired restore/public recovery/retry and import plan lifetime; related produced Linux rollback restoration'}
    plan = {'schema': 'facman.exact_source_campaign.v1', 'status': 'prepared',
            'source_head': HEAD, 'source_tree': TREE, 'workflow_id': workflow['id'],
            'script_sha256': sha(Path(__file__)), 'integration_sha256': sha(INTEGRATION),
            'POSIX_review_sha256': sha(POSIX), 'campaign_key': key,
            'campaign_key_sha256': hashlib.sha256(json.dumps(key, sort_keys=True).encode()).hexdigest(),
            'marker': marker, 'resource_measurement': measured,
            'reserved_additional_peak_bytes': PEAK,
            'peak_budget': {'archive_cap': 2 * 1024**3, 'selected_material_and_extraction_cap': 2 * 1024**3,
                            'fixture_and_evidence_cap': 1024**3, 'rollback_cap': 1024**3},
            'future_download_requires_fresh_measured_admission': True,
            'dispatch_argv': ['gh', 'workflow', 'run', 'product-candidate.yml', '--repo', REPO, '--ref', 'dev'],
            'discovery_timeout_seconds': 900, 'campaign_timeout_seconds': 10800,
            'expected_jobs': sorted(EXPECTED_JOBS), 'dispatches': 0, 'reruns': 0,
            'new_roots': 0, 'local_native_builds': 0, 'artifact_downloads': 0,
            'release': False, 'signing': False, 'game': False, 'human': False,
            'produced_package_accepted': False, 'whole_workunit_closed': False, 'prepared_at_utc': now()}
    write(PLAN, plan)
    print(json.dumps({'status': 'prepared_independent_review_required', 'script_sha256': plan['script_sha256'],
                      'plan_sha256': sha(PLAN), 'head': HEAD, 'additional_peak_bytes': PEAK}))


def observe(record, plan):
    deadline = time.monotonic() + plan['campaign_timeout_seconds']
    discovery = time.monotonic() + plan['discovery_timeout_seconds']
    while time.monotonic() < discovery:
        pages = json.loads(output('gh', 'api', '--paginate', '--slurp',
                                 f'repos/{REPO}/actions/workflows/{plan["workflow_id"]}/runs?head_sha={HEAD}&event=workflow_dispatch&per_page=100'))
        runs = [run for page in pages for run in page['workflow_runs']]
        assert len(runs) <= 1, 'Ambiguous duplicate candidate; inspect without redispatch'
        if runs:
            run = runs[0]
            assert run['head_sha'] == HEAD and run['head_branch'] == 'dev'
            assert run['workflow_id'] == plan['workflow_id'] and run['event'] == 'workflow_dispatch'
            record.update(run_id=run['id'], run_attempt=1, status='script_owned_candidate_observation')
            write(OUT, record)
            break
        assert shutil.disk_usage(E).free >= 8 * 1024**3
        time.sleep(15)
    else:
        raise TimeoutError('Accepted dispatch has no exact observable run; never redispatch')
    while time.monotonic() < deadline:
        run = api(f'actions/runs/{record["run_id"]}')
        assert run['head_sha'] == HEAD and run['head_branch'] == 'dev' and run['workflow_id'] == plan['workflow_id']
        assert run['run_attempt'] == 1 and run['event'] == 'workflow_dispatch'
        pages = json.loads(output('gh', 'api', '--paginate', '--slurp',
                                 f'repos/{REPO}/actions/runs/{run["id"]}/attempts/1/jobs?per_page=100'))
        jobs = [job for page in pages for job in page['jobs']]
        assert all(job['head_sha'] == HEAD and job['run_id'] == run['id'] for job in jobs)
        assert len(jobs) <= len(EXPECTED_JOBS) and {job['name'] for job in jobs} <= EXPECTED_JOBS
        failed = [job for job in jobs if job['status'] == 'completed' and job['conclusion'] != 'success']
        record.update(run=run, candidate_jobs=jobs, last_observed_at_utc=now())
        if failed or (run['status'] == 'completed' and run['conclusion'] != 'success'):
            record.update(status='actionable_candidate_failure', failures=[
                {'id': job['id'], 'name': job['name'], 'conclusion': job['conclusion'], 'url': job['html_url']} for job in failed])
            return
        if run['status'] == 'completed':
            assert run['conclusion'] == 'success' and len(jobs) == len(EXPECTED_JOBS)
            assert {job['name'] for job in jobs} == EXPECTED_JOBS and all(job['status'] == 'completed' for job in jobs)
            artifacts = json.loads(output('gh', 'api', '--paginate', '--slurp',
                                          f'repos/{REPO}/actions/runs/{run["id"]}/artifacts?per_page=100'))
            record.update(status='exact_dev_unpublished_candidate_PASS', artifact_metadata=artifacts)
            return
        assert output('git', 'branch', '--show-current') == 'dev' and output('git', 'rev-parse', 'HEAD') == HEAD
        assert not output('git', 'status', '--porcelain')
        assert api('git/ref/heads/dev')['object']['sha'] == HEAD
        assert shutil.disk_usage(E).free >= 8 * 1024**3
        write(OUT, record)
        time.sleep(30)
    record.update(status='candidate_deadline', next_action='Preserve exact accepted run; inspect without redispatch')


def arm():
    assert not OUT.exists() and not CLAIM.exists()
    plan = json.loads(PLAN.read_text()); review = json.loads(REVIEW.read_text())
    assert review['verdict'] == 'PASS' and review['independent'] and review['non_authoring']
    assert review['script_sha256'] == sha(Path(__file__)) == plan['script_sha256']
    assert review['plan_sha256'] == sha(PLAN)
    identity(); evidence_and_source(); resources(); workflow_admission()
    assert {name: sha(R / name) for name in plan['campaign_key']['inputs']} == plan['campaign_key']['inputs']
    with CLAIM.open('x', encoding='utf-8', newline='\n') as f:
        f.write(json.dumps({'PID': os.getpid(), 'head': HEAD, 'script_sha256': sha(Path(__file__)),
                            'plan_sha256': sha(PLAN), 'review_sha256': sha(REVIEW), 'started_at_utc': now(),
                            'recovery': 'Persistent claim; inspect exact issued state; never replay automatically'}, indent=2) + '\n')
        f.flush(); os.fsync(f.fileno())
    record = {'schema': 'facman.exact_source_campaign.v1', 'status': 'candidate_dispatch_issued',
              'source_head': HEAD, 'source_tree': TREE, 'dispatches': 1, 'reruns': 0,
              'plan_sha256': sha(PLAN), 'review_sha256': sha(REVIEW), 'started_at_utc': now(),
              'new_roots': 0, 'local_native_builds': 0, 'artifact_downloads': 0,
              'produced_package_accepted': False, 'whole_workunit_closed': False}
    write(OUT, record)
    try:
        with (E / 'world-restore-package-candidate-01-dispatch.log').open('x', encoding='utf-8') as f:
            result = subprocess.run(plan['dispatch_argv'], cwd=R, stdout=f, stderr=subprocess.STDOUT, timeout=120)
        assert result.returncode == 0, 'Ambiguous dispatch outcome; inspect; never resubmit'
        record.update(status='candidate_dispatch_accepted', accepted_at_utc=now()); write(OUT, record)
        observe(record, plan)
    except BaseException as error:
        record.update(status='candidate_stopped_for_actionable_review', error=repr(error),
                      next_action='Inspect retained exact claim/run/operation before recovery; no automatic replay')
    record['finished_at_utc'] = now(); write(OUT, record)
    print(json.dumps({key: record.get(key) for key in ['status', 'run_id', 'source_head', 'dispatches', 'error', 'failures']}))


if __name__ == '__main__':
    assert __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0' and os.environ.get('PYTHONDONTWRITEBYTECODE') == '1'
    parser = argparse.ArgumentParser(); parser.add_argument('--prepare', action='store_true'); parser.add_argument('--arm', action='store_true')
    args = parser.parse_args(); assert args.prepare != args.arm
    prepare() if args.prepare else arm()
