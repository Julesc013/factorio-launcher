import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

R = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
W = E.parent
H = '1949aff0d1830ca25582aab205b179d955b839c1'
T = '459137e553e6542e8ed02bfbfe72b43ffcd7fab4'
WORKER = E / 'world-restore-native-rx3-tests.py'
REVIEW = E / 'world-restore-native-rx3-worker.review.json'
BUILD = E / 'world-restore-native-rx2-build.json'
QUAL = E / 'world-restore-native-rx3-qualification.json'
OUT = E / 'world-restore-native-rx3-parent.json'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def output(*argv):
    return subprocess.check_output(argv, cwd=R, stderr=subprocess.PIPE,
                                   timeout=120).decode('utf-8').strip()


assert __debug__ and os.name == 'nt'
assert not OUT.exists() and not QUAL.exists()
assert output('git', 'rev-parse', 'HEAD') == H
assert output('git', 'rev-parse', 'HEAD^{tree}') == T
assert not output('git', 'status', '--porcelain')
review = json.loads(REVIEW.read_text(encoding='utf-8'))
assert review['verdict'] == 'PASS' and review['script_sha256'] == sha(WORKER)
built = json.loads(BUILD.read_text(encoding='utf-8'))
assert built['status'] == 'PASS' and built['head'] == H and built['tree'] == T
exe = W / 'native-developer/Debug/facman.exe'
assert Path(built['CLI']).resolve() == exe.resolve()
assert built['CLI_sha256'] == sha(exe)
resources_process = subprocess.run(
    [str(Path(sys.executable).resolve()), '-B', 'tools/workspace_hygiene.py',
     'doctor', '--measure'], cwd=R, capture_output=True, text=True, timeout=120)
assert resources_process.returncode in (0, 1)
resources = json.loads(resources_process.stdout)
assert len(resources['task_roots']) <= 8
assert resources['task_root_bytes'] + 256 * 1024**2 <= 20 * 1024**3
assert set(resources['violations']) <= {
    'unmanaged_secondary_worktrees_present', 'merged_local_task_branches_present'}
assert shutil.disk_usage(W).free >= 8 * 1024**3
native_count = output(
    'powershell', '-NoProfile', '-Command',
    "@(Get-CimInstance Win32_Process -Filter \"Name = 'cmake.exe' OR Name = 'MSBuild.exe' OR Name = 'ninja.exe' OR Name = 'cl.exe'\").Count")
assert native_count == '0'
command = [str(Path(sys.executable).resolve()), '-B', '-u', str(WORKER)]
environment = os.environ.copy()
environment.update(PYTHONOPTIMIZE='0', PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1')
record = {
    'schema': 'facman.world_restore_native_parent.v1',
    'status': 'FAIL', 'head': H, 'tree': T,
    'parent_sha256': sha(Path(__file__)), 'worker_sha256': sha(WORKER),
    'worker_review_sha256': sha(REVIEW), 'build_receipt_sha256': sha(BUILD),
    'CLI_sha256': built['CLI_sha256'], 'command': command,
    'timeout_seconds': 900, 'cleanup_seconds': 20,
    'capture_limit_bytes_each': 8 * 1024**2,
    'resource_admission': resources,
    'whole_workunit_closed': False, 'produced_package_qualified': False,
    'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
write(E / 'world-restore-native-rx3-parent.claim.json', {
    'PID': os.getpid(), 'head': H, 'parent_sha256': record['parent_sha256'],
    'started_at_utc': record['started_at_utc'], 'no_automatic_replay': True,
})
try:
    sys.path.insert(0, str(R))
    from tools import provider_canary_process_windows as owned
    with open(os.devnull, 'rb') as stdin, \
            (E / 'world-restore-native-rx3-parent.stdout').open('xb') as stdout, \
            (E / 'world-restore-native-rx3-parent.stderr').open('xb') as stderr:
        result = owned.run(command, R, environment, (stdin, stdout, stderr),
                           seconds=900, cleanup_seconds=20,
                           output_limit=8 * 1024**2,
                           wait_for_job_empty_after_primary=True)
    record['runner'] = result
    runner_pass = (
        result['dispatched'] and result['resumed'] and
        result['termination'] == 'completed' and result['exit_code'] == 0 and
        result['primary_stopped'] and result['job_empty_observed'] and
        result['error'] is None and not result.get('cleanup_error'))
    qualification = json.loads(QUAL.read_text(encoding='utf-8')) if QUAL.exists() else None
    record['qualification'] = qualification
    qualification_pass = qualification is not None and (
        qualification['status'] == 'PASS' and qualification['head'] == H and
        qualification['tree'] == T and qualification['CLI_sha256'] == built['CLI_sha256'] and
        qualification['tests'] > 0 and qualification['failures'] == 0 and
        qualification['errors'] == 0 and qualification['skips'] == 0 and
        qualification['command_accounting_complete'] and
        qualification['commands'] == qualification['issued_commands'] and
        qualification['source_clean_after'] and qualification['CLI_unchanged_after'])
    record['source_clean_after'] = (
        output('git', 'rev-parse', 'HEAD') == H and
        output('git', 'rev-parse', 'HEAD^{tree}') == T and
        not output('git', 'status', '--porcelain'))
    record['CLI_unchanged_after'] = sha(exe) == built['CLI_sha256']
    if QUAL.exists():
        record['qualification_sha256'] = sha(QUAL)
    if runner_pass and qualification_pass and record['source_clean_after'] and record['CLI_unchanged_after']:
        record['status'] = 'PASS'
except Exception as error:
    record['error'] = str(error)[:4096]
finally:
    record['finished_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    write(OUT, record)
print(json.dumps({k: record.get(k) for k in (
    'status', 'head', 'qualification', 'runner', 'error', 'finished_at_utc')}))
raise SystemExit(0 if record['status'] == 'PASS' else 1)
