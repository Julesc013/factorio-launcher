import pathlib,subprocess,json,os,hashlib,datetime,time
R=pathlib.Path(r'D:\Projects\Factorio\factorio-launcher');W=pathlib.Path(r'D:\Development\FacMan\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e');E=W/'evidence';H='1949aff0d1830ca25582aab205b179d955b839c1';T='459137e553e6542e8ed02bfbfe72b43ffcd7fab4'
def out(*a):return subprocess.check_output(a,cwd=R,stderr=subprocess.PIPE).decode('utf-8').strip()
def write(p,v):
 with p.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(v,indent=2)+'\n')
assert __debug__ and out('git','rev-parse','HEAD')==H and out('git','rev-parse','HEAD^{tree}')==T and not out('git','status','--porcelain')
assert not (E/'world-restore-native-rx2-build.json').exists()
d=json.loads(out('py','-3','-B','tools/workspace_hygiene.py','paths'));z=subprocess.run(['py','-3','-B','tools/workspace_hygiene.py','doctor','--measure'],cwd=R,capture_output=True,text=True,timeout=120);resources=json.loads(z.stdout);assert z.returncode in [0,1] and len(resources['task_roots'])<=8 and resources['task_root_bytes']+2*1024**3<=20*1024**3 and set(resources['violations'])<= {'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
import shutil
assert shutil.disk_usage(W).free>=10*1024**3
native=out('powershell','-NoProfile','-Command',"@(Get-CimInstance Win32_Process -Filter \"Name = 'cmake.exe' OR Name = 'MSBuild.exe' OR Name = 'ninja.exe' OR Name = 'cl.exe'\").Count")
assert native=='0','Another heavy local job is active'
write(E/'world-restore-native-rx2-resource.json',{'measured':resources,'peak_additional_budget_bytes':2*1024**3,'free_bytes':shutil.disk_usage(W).free,'one_heavy_local_job':True,'native_workers':2})
write(E/'world-restore-native-rx2-build.claim.json',{'PID':os.getpid(),'head':H,'tree':T,'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'no_automatic_replay':True})
env=os.environ.copy();env.update(PYTHONOPTIMIZE='0',PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',CMAKE_BUILD_PARALLEL_LEVEL='2',MSBUILDDISABLENODEREUSE='1',FACMAN_MIN_FREE_GIB='8')
commands=[('build',['py','-3','-B','tools/dev.py','build','developer','--task-root',str(W),'--build-root',str(W/'native-developer'),'--configuration','Debug','--target','facman_cli','--target','fl_transaction_session_smoke','--target','fl_archive_core_smoke']),('ctest',['ctest','--test-dir',str(W/'native-developer'),'-C','Debug','--output-on-failure','--no-tests=error','-R','^(fl_transaction_session_smoke|fl_archive_core_smoke)$'])]
record={'head':H,'tree':T,'commands':[],'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'whole_workunit_closed':False,'package_qualified':False}
for name,argv in commands:
 p=E/('world-restore-native-rx2-'+name+'.log')
 with p.open('x',encoding='utf-8') as f:
  child=subprocess.Popen(argv,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
  try:code=child.wait(timeout=1800)
  except BaseException:
   if child.poll() is None:subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],capture_output=True,timeout=30);child.wait(timeout=30)
   raise
 record['commands'].append({'name':name,'argv':argv,'PID':child.pid,'exit_code':code,'log':str(p)})
 if code:record['status']='FAIL';record['failure']=name;write(E/'world-restore-native-rx2-build.json',record);print(p.read_text(encoding='utf-8')[-3500:]);raise SystemExit(code)
assert out('git','rev-parse','HEAD')==H and not out('git','status','--porcelain')
exe=W/'native-developer/Debug/facman.exe';record.update(status='PASS',CLI=str(exe),CLI_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),source_clean_after=True,finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());write(E/'world-restore-native-rx2-build.json',record);print(json.dumps(record))
