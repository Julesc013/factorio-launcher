// SPDX-FileCopyrightText: 2026 Jules C
// SPDX-License-Identifier: MIT

#include "flb_factorio_save_operations.h"
#include "flb_factorio_save_index.h"

#include "fl_archive.h"
#include "fl_archive_platform.h"
#include "fl_path_safety.h"
#include "fl_file_io.h"
#include "fl_json.h"
#include "fl_sha256.h"
#include "flb_factorio_launch_plan.h"
#include "flb_factorio_modsets.h"
#include "flb_factorio_version_family.h"
#include "fl_transaction.h"
#include "fl_workspace_store.h"
#include "fl_workspace_root_authority.h"

#include <algorithm>
#include <array>
#include <chrono>
#include <cstdlib>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <map>
#include <optional>
#include <set>
#include <sstream>
#include <thread>
#include <vector>

namespace facman::factorio::saves::operations {
namespace fs = std::filesystem;
namespace tx = facman::transaction;
namespace json = facman::core::json;
namespace {

struct Instance {
    std::string instance_id;
    std::string display_name;
    std::string install_ref;
    std::string factorio_version;
    std::string profile;
    std::string template_id;
    fs::path root;
};

struct ExportFile {
    std::string path;
    fs::path source;
    std::uint64_t size = 0;
    std::string sha256;
};

std::string path_string(const fs::path& path) { return path.lexically_normal().generic_string(); }

void replace_all(std::string& text, const std::string& from, const std::string& to)
{
    if (from.empty()) return;
    std::size_t position = 0;
    while ((position = text.find(from, position)) != std::string::npos) {
        text.replace(position, from.size(), to);
        position += to.size();
    }
}

std::string read_text(const fs::path& path)
{
    std::ifstream input(path, std::ios::binary);
    std::ostringstream output;
    output << input.rdbuf();
    return output.str();
}

facman::core::Result<json::Value> decode_document(const std::string& text, std::size_t maximum_bytes = 4U * 1024U * 1024U)
{
    json::Limits limits;
    limits.maximum_bytes = maximum_bytes;
    limits.maximum_depth = 24;
    limits.maximum_nodes = 100000;
    limits.maximum_string_bytes = 1024U * 1024U;
    return json::parse(text, limits);
}

std::string document_string(const json::Value& document, const char* key)
{
    const json::Value* value = document.find(key);
    if (value == nullptr) return {};
    auto result = value->string_value();
    return result ? result.take_value() : std::string {};
}

std::string utc_now()
{
    const std::time_t now = std::time(nullptr);
    std::tm value {};
#ifdef _WIN32
    gmtime_s(&value, &now);
#else
    gmtime_r(&now, &value);
#endif
    char buffer[32] = {};
    std::strftime(buffer, sizeof(buffer), "%Y-%m-%dT%H:%M:%SZ", &value);
    return buffer;
}

Refusal refuse(
    const std::string& command,
    const std::string& instance_id,
    const std::string& save,
    const std::string& code,
    const std::string& reason,
    const std::string& detail,
    bool recoverable = true)
{
    return {
        command,
        instance_id,
        save,
        code,
        reason,
        detail,
        recoverable,
        "facman saves list --instance <instance-id> --json"};
}

bool load_instance(const fs::path& workspace, const std::string& instance_id, Instance& instance)
{
    auto parsed_id = facman::core::InstanceId::parse(instance_id);
    if (!parsed_id) return false;
    auto record = facman::workspace::InstanceRepository(facman::workspace::WorkspaceLayout(workspace)).load(
        parsed_id.value());
    if (!record) return false;
    instance.instance_id = record.value().id.str();
    instance.display_name = record.value().display_name;
    instance.install_ref = record.value().install_ref.str();
    instance.factorio_version = record.value().factorio_version;
    instance.profile = record.value().profile;
    instance.template_id = record.value().template_id;
    instance.root = record.value().root;
    return true;
}

bool load_install_root(const fs::path& workspace, const std::string& install_id, fs::path& root)
{
    auto parsed_id = facman::core::InstallId::parse_legacy(install_id);
    if (!parsed_id) return false;
    auto record = facman::workspace::InstallRepository(facman::workspace::WorkspaceLayout(workspace)).load(
        parsed_id.value());
    if (!record) return false;
    root = record.value().root;
    return !root.empty() && fs::is_directory(root / "data");
}

fs::path unique_staging(const fs::path& parent, const std::string& prefix)
{
    const auto stamp = std::chrono::steady_clock::now().time_since_epoch().count();
    for (int attempt = 0; attempt < 100; ++attempt) {
        const fs::path candidate = parent / (prefix + std::to_string(stamp) + "-" + std::to_string(attempt));
        if (!fs::exists(candidate)) return candidate;
    }
    return {};
}

bool fault_requested(const char* stage)
{
    const char* requested = std::getenv("FACMAN_TEST_SAVE_TRANSFER_FAIL_STAGE");
    return requested != nullptr && std::string(requested) == stage;
}

struct StableCopyResult {
    std::uint64_t size = 0;
    std::string sha1;
    std::string sha256;
    std::string detail;
    bool source_changed = true;
};

std::optional<std::string> stable_input_sha256(
    facman::platform::StableInputFile& input)
{
    if (!input.open() || !input.identity().regular_file ||
        input.identity().link_count != 1U || !input.revalidate_path().ok())
        return std::nullopt;
    facman::base::Sha256Hasher hasher;
    std::vector<unsigned char> chunk(64U * 1024U);
    for (std::uint64_t offset = 0; offset < input.size();) {
        const auto count = static_cast<std::size_t>((std::min)(
            static_cast<std::uint64_t>(chunk.size()), input.size() - offset));
        if (input.read_at(offset, chunk.data(), count) != count)
            return std::nullopt;
        hasher.update(chunk.data(), count);
        offset += count;
    }
    if (!input.revalidate_path().ok()) return std::nullopt;
    return hasher.finish();
}

class OperationJournal {
public:
    bool start(
        const fs::path& workspace,
        const std::string& command,
        const fs::path& target,
        const std::vector<fs::path>& sources,
        const std::vector<fs::path>& staging,
        const std::string& effect_parent_identity = {})
    {
        tx::Record record;
        record.command_id = command;
        record.target = target;
        record.sources = sources;
        record.staging_roots = staging;
        record.commit_strategy = "destination_volume_stage_then_atomic_no_replace";
        record.effect_parent_identity = effect_parent_identity;
        auto started = tx::TransactionSession::begin(workspace, std::move(record));
        if (!started) { detail_ = started.error().message; return false; }
        session_.emplace(started.take_value());
        const bool ok = session_->validated("request_validated") &&
            session_->planned("target_and_sources_validated");
        if (!ok) detail_ = session_->detail();
        return ok;
    }
    bool step(const std::string& state, const std::string& completed)
    {
        if (!session_) { detail_ = "transaction session is unavailable"; return false; }
        bool ok = false;
        if (state == "staging") ok = session_->staging(completed);
        else if (state == "staged") ok = session_->staged(completed);
        else if (state == "verified") ok = session_->verified(completed);
        else if (state == "committing") ok = session_->committing(completed);
        else if (state == "committed") ok = session_->committed(completed);
        else { detail_ = "unsupported operation journal state: " + state; return false; }
        if (!ok) detail_ = session_->detail();
        return ok;
    }
    bool checkpoint(const std::string& completed)
    {
        if (!session_ || !session_->checkpoint(completed)) {
            detail_ = session_ ? session_->detail() : "transaction session is unavailable";
            return false;
        }
        return true;
    }
    bool finish()
    {
        if (!session_ || !session_->complete()) {
            if (session_) detail_ = session_->detail();
            return false;
        }
        return true;
    }
    void failed(const std::string& error)
    {
        if (session_) session_->failed(error);
    }
    tx::Record& record() { return session_->record(); }
    const std::string& detail() const { return detail_; }
private:
    std::optional<tx::TransactionSession> session_;
    std::string detail_;
};

bool stable_copy(const fs::path& source, const fs::path& destination,
    StableCopyResult& result, facman::platform::StableInputFile* held_source = nullptr)
{
    facman::platform::StableInputFile local_source;
    auto& input = held_source != nullptr ? *held_source : local_source;
    if (!input.open()) {
        const auto opened = input.open_no_follow(source);
        if (!opened.ok()) { result.detail = opened.detail; return false; }
    }
    result.size = input.size();
    auto source_sha256 = stable_input_sha256(input);
    if (!source_sha256.has_value()) {
        result.detail = "save source changed during identity hash";
        return false;
    }
    result.sha256 = *source_sha256;
    auto digest = facman::core::Sha256Digest::parse(result.sha256);
    if (!digest) { result.detail = digest.error().message; return false; }
    const bool interrupt_copy = fault_requested("during_cross_volume_copy");
    if (interrupt_copy && held_source == nullptr) {
        result.detail = "injected copy interruption";
        return false;
    }
    if (!tx::CrossVolumeCopyVerifyCommit::commit(
            source, destination, digest.value(), result.size, result.detail,
            &input.identity(), interrupt_copy)) {
        result.source_changed = stable_input_sha256(input) != source_sha256;
        return false;
    }
    if (!input.revalidate_path().ok()) {
        result.detail = "save source identity changed after stable copy";
        return false;
    }
    result.source_changed = false;
    result.sha1 = facman::factorio::modsets::sha1_hex_file(destination);
    if (result.sha1.empty()) result.detail = "staged save SHA-1 could not be read";
    return !result.sha1.empty();
}

bool rewrite_text_durable(const fs::path& destination, const std::string& text, std::string& detail)
{
    const fs::path temporary = unique_staging(destination.parent_path(), ".facman-rewrite-");
    if (temporary.empty()) { detail = "could not allocate a rewrite staging path"; return false; }
    facman::platform::DurableOutputFile output;
    auto status = output.create_exclusive(temporary, text.size());
    if (!status.ok()) { detail = status.detail; return false; }
    if (output.write_at(0, text.data(), text.size()) != text.size()) {
        output.close_without_flush();
        detail = "short durable rewrite";
        return false;
    }
    status = output.flush_file_and_parent();
    if (status.ok()) status = facman::platform::replace_existing_durable(temporary, destination);
    if (!status.ok()) {
        facman::platform::StableInputFile created;
        if (created.open_no_follow(temporary).ok()) {
            (void)facman::platform::remove_exact_object(temporary, created.identity());
        }
        detail = status.detail;
        return false;
    }
    detail.clear();
    return true;
}

bool recognized_factorio_save(const facman::archive::Plan& plan)
{
    for (const facman::archive::Entry& entry : plan.entries) {
        if (entry.directory) continue;
        if (entry.path == "level-init.dat" ||
            (entry.path.size() > 15 && entry.path.compare(entry.path.size() - 15, 15, "/level-init.dat") == 0)) {
            return true;
        }
    }
    return false;
}

bool inspect_save(const fs::path& path, SaveRef& save, std::string& detail)
{
    facman::archive::Plan plan;
    const facman::archive::Status status =
        facman::archive::inspect_archive(path, facman::archive::SaveArchivePolicy::limits(), plan);
    if (!status.ok()) {
        detail = status.code + ": " + status.detail;
        return false;
    }
    save.path = path;
    save.file_name = path.filename().string();
    save.name = path.stem().string();
    save.size = plan.archive_size;
    save.archive_structurally_valid = true;
    save.factorio_save_recognized = recognized_factorio_save(plan);
    save.deep_save_semantics_inspected = false;
    detail.clear();
    return true;
}

std::vector<SaveRef> instance_saves(const Instance& instance, bool inspect)
{
    std::vector<SaveRef> saves;
    const fs::path root = instance.root / "saves";
    std::error_code error;
    if (!fs::is_directory(root, error)) return saves;
    for (const fs::directory_entry& entry : fs::directory_iterator(root)) {
        if (entry.path().extension() != ".zip" || !entry.is_regular_file(error) || error) continue;
        SaveRef save;
        save.path = entry.path();
        save.file_name = entry.path().filename().string();
        save.name = entry.path().stem().string();
        save.size = entry.file_size(error);
        if (inspect) {
            std::string ignored;
            (void)inspect_save(entry.path(), save, ignored);
        }
        saves.push_back(save);
    }
    std::sort(saves.begin(), saves.end(), [](const SaveRef& left, const SaveRef& right) {
        return left.file_name < right.file_name;
    });
    return saves;
}

bool resolve_save(const Instance& instance, const std::string& name, SaveRef& save)
{
    std::string detail;
    if (!facman::base::validate_identifier(name, detail)) return false;
    fs::path candidate = instance.root / "saves" / name;
    if (!fs::is_regular_file(candidate) && candidate.extension() != ".zip") candidate += ".zip";
    if (!fs::is_regular_file(candidate)) return false;
    save.path = candidate;
    save.file_name = candidate.filename().string();
    save.name = candidate.stem().string();
    save.size = fs::file_size(candidate);
    (void)inspect_save(candidate, save, detail);
    return true;
}

std::optional<fs::path> save_lock_path(const Instance& instance)
{
    for (const char* name : {"run.lock", "save.write.lock"}) {
        const fs::path path = instance.root / "locks" / name;
        std::error_code error;
        const auto status = fs::symlink_status(path, error);
        if (error == std::errc::no_such_file_or_directory) continue;
        if (error || status.type() != fs::file_type::not_found) return path;
    }
    return std::nullopt;
}

bool save_locked(const Instance& instance)
{
    return save_lock_path(instance).has_value();
}

json::ObjectBuilder save_ref_builder(const SaveRef& save)
{
    json::ObjectBuilder output;
    output.add_string("name", save.name);
    output.add_string("file_name", save.file_name);
    output.add_string("path", path_string(save.path));
    (void)output.add_unsigned_integer("size", save.size);
    output.add_bool("archive_structurally_valid", save.archive_structurally_valid);
    output.add_bool("factorio_save_recognized", save.factorio_save_recognized);
    output.add_bool("deep_save_semantics_inspected", save.deep_save_semantics_inspected);
    return output;
}

std::string instance_json(const Instance& instance, const std::string& local_data_root)
{
    json::ObjectBuilder output;
    output.add_string("schema", "factorio.instance.v1");
    output.add_string("instance_id", instance.instance_id);
    output.add_string("display_name", instance.display_name);
    output.add_string("install_ref", instance.install_ref);
    output.add_string("factorio_version", instance.factorio_version);
    output.add_string("local_data_root", local_data_root);
    output.add_string("profile", instance.profile);
    output.add_string("template", instance.template_id);
    return output.serialize() + "\n";
}

std::string portable_instance_json(const Instance& instance)
{
    return instance_json(instance, "$FACMAN_INSTANCE_ROOT");
}

std::string local_instance_json(const Instance& instance)
{
    return instance_json(instance, path_string(instance.root));
}

std::string portable_config()
{
    return
        "[path]\n"
        "read-data=$FACMAN_INSTALL_ROOT/data\n"
        "write-data=$FACMAN_INSTANCE_ROOT\n"
        "token=[FACMAN_REDACTED]\n";
}

std::string effective_config(const Instance& instance, const fs::path& install_root)
{
    facman::factorio::launch::InstanceLaunchRef instance_ref;
    instance_ref.instance_id = instance.instance_id;
    instance_ref.profile_id = instance.profile;
    instance_ref.local_data_root = instance.root;
    facman::factorio::launch::InstallLaunchRef install_ref;
    install_ref.root = install_root;
    install_ref.executable = install_root / "bin" / "x64" / "factorio.exe";
    install_ref.ownership = "foreign";
    return facman::factorio::launch::effective_config_ini(instance_ref, install_ref);
}

bool write_generated(const fs::path& root, const std::string& relative, const std::string& text, ExportFile& file)
{
    const fs::path path = root / fs::path(relative);
    std::error_code error;
    fs::create_directories(path.parent_path(), error);
    std::string detail;
    if (error || !facman::base::write_text_new_atomic(path, text, detail)) return false;
    file.path = relative;
    file.source = path;
    file.size = fs::file_size(path);
    file.sha256 = facman::base::sha256_hex_file(path);
    return true;
}

std::string export_manifest(const Instance& instance, const std::vector<ExportFile>& files)
{
    json::ArrayBuilder redactions;
    redactions.add_string("local_data_root");
    redactions.add_string("config.ini paths and secrets");
    json::ArrayBuilder hashes;
    for (const ExportFile& file : files) {
        json::ObjectBuilder entry;
        entry.add_string("path", file.path);
        (void)entry.add_unsigned_integer("size", file.size);
        entry.add_string("sha256", file.sha256);
        hashes.add_object(entry);
    }
    json::ObjectBuilder output;
    output.add_string("schema", "factorio.instance_export_manifest.v2");
    output.add_string("instance_id", instance.instance_id);
    output.add_bool("portable", true);
    output.add_bool("deep_save_semantics_inspected", false);
    output.add_array("redactions", redactions);
    output.add_array("file_hashes", hashes);
    return output.serialize() + "\n";
}

bool stream_plan_entry(
    const facman::archive::Plan& plan,
    const std::string& path,
    std::string& text,
    std::size_t maximum)
{
    for (const facman::archive::Entry& entry : plan.entries) {
        if (entry.path != path || entry.directory || entry.expanded_size > maximum) continue;
        text.clear();
        const facman::archive::Status status = facman::archive::stream_entry(
            plan,
            entry.index,
            facman::archive::InstanceTransferPolicy::limits(),
            [&](const unsigned char* bytes, std::size_t size) {
                if (size > maximum - text.size()) return false;
                text.append(reinterpret_cast<const char*>(bytes), size);
                return true;
            });
        return status.ok();
    }
    return false;
}

std::map<std::string, std::string> manifest_hashes(const std::string& text)
{
    std::map<std::string, std::string> hashes;
    auto document = decode_document(text);
    if (!document || !document.value().is_object()) return hashes;
    const json::Value* entries = document.value().find("file_hashes");
    if (entries == nullptr || !entries->is_array()) return hashes;
    for (std::size_t index = 0; index < entries->size(); ++index) {
        const json::Value* entry = entries->at(index);
        if (entry == nullptr || !entry->is_object()) return {};
        const std::string path = document_string(*entry, "path");
        const std::string hash = document_string(*entry, "sha256");
        if (path.empty() || hash.size() != 64 || !hashes.emplace(path, hash).second) return {};
    }
    return hashes;
}

bool verify_staged_tree(
    const fs::path& staging,
    const std::map<std::string, std::string>& hashes,
    std::string& detail)
{
    std::set<std::string> actual;
    std::error_code error;
    for (const fs::directory_entry& entry : fs::recursive_directory_iterator(staging)) {
        if (entry.is_directory(error)) continue;
        const std::string relative = fs::relative(entry.path(), staging, error).generic_string();
        if (error) { detail = error.message(); return false; }
        if (relative == facman::archive::owned_staging_marker_name() ||
            relative == tx::transaction_staging_marker_name() ||
            relative == "manifest/export.v1.json") continue;
        actual.insert(relative);
        const auto expected = hashes.find(relative);
        if (expected == hashes.end() || facman::base::sha256_hex_file(entry.path()) != expected->second) {
            detail = "file closure or hash mismatch: " + relative;
            return false;
        }
    }
    if (actual.size() != hashes.size()) {
        detail = "file closure count mismatch";
        return false;
    }
    detail.clear();
    return true;
}

} // namespace

ListOutcome list_saves(const fs::path& workspace, const InstanceRequest& request)
{
    Instance instance;
    if (!load_instance(workspace, request.instance_id, instance)) {
        return refuse("saves.list", request.instance_id, "", "unknown_instance", "Instance is not registered", request.instance_id);
    }
    return ListResult {request.instance_id, instance_saves(instance, true)};
}

BackupOutcome backup_save(const fs::path& workspace, const BackupRequest& request)
{
    const std::string command = "saves.backup";
    Instance instance;
    if (!load_instance(workspace, request.instance_id, instance)) {
        return refuse(command, request.instance_id, request.save, "unknown_instance", "Instance is not registered", request.instance_id);
    }
    if (const auto lock = save_lock_path(instance)) {
        return refuse(command, request.instance_id, request.save, "save_locked",
            "Save writes are locked for this instance", path_string(*lock));
    }
    SaveRef save;
    if (!resolve_save(instance, request.save, save)) {
        return refuse(command, request.instance_id, request.save, "save_not_found", "Save is not present in the instance", "No matching structurally readable .zip save exists.");
    }
    auto inspected_workspace = facman::workspace::inspect_workspace_root(workspace);
    if (!inspected_workspace ||
        inspected_workspace.value().state != facman::workspace::WorkspaceRootState::facman_owned ||
        !inspected_workspace.value().mutation_allowed ||
        !inspected_workspace.value().root_authority) {
        return refuse(command, request.instance_id, save.file_name,
            "save_backup_destination_unowned", "Backup requires an owned workspace root",
            inspected_workspace ? inspected_workspace.value().detail : inspected_workspace.error().message,
            false);
    }
    auto authority = inspected_workspace.take_value();
    facman::platform::StableInputFile source_pin;
    if (!source_pin.open_no_follow(save.path).ok() ||
        !source_pin.identity().regular_file ||
        source_pin.identity().link_count != 1U ||
        !source_pin.revalidate_path().ok()) {
        return refuse(command, request.instance_id, save.file_name,
            "save_source_changed", "Save source cannot be pinned for backup",
            path_string(save.path));
    }
    std::error_code source_time_error;
    const auto source_write_time = fs::last_write_time(save.path, source_time_error);
    if (source_time_error) {
        return refuse(command, request.instance_id, save.file_name,
            "save_source_changed", "Save modification time cannot be pinned",
            source_time_error.message());
    }
    const auto source_unchanged = [&]() {
        std::error_code current_time_error;
        const auto current_time = fs::last_write_time(save.path, current_time_error);
        return !current_time_error && current_time == source_write_time &&
            source_pin.revalidate_path().ok();
    };
    SaveRef pinned_save;
    std::string inspection_detail;
    const bool inspected_save = inspect_save(save.path, pinned_save, inspection_detail);
    if (!source_unchanged()) {
        return refuse(command, request.instance_id, save.file_name,
            "save_source_changed", "Save changed during backup inspection",
            path_string(save.path));
    }
    if (!inspected_save || !pinned_save.factorio_save_recognized) {
        return refuse(command, request.instance_id, save.file_name,
            "save_malformed", "Save archive is not recognized as a Factorio save",
            inspected_save ? "level-init.dat is absent" : inspection_detail);
    }
    save = std::move(pinned_save);
    fs::path destination = request.output_path.empty()
        ? instance.root / "backups" / (save.name + ".backup.zip")
        : request.output_path;
    if (destination.is_relative()) destination = workspace / destination;
    std::error_code error;
    destination = fs::absolute(destination, error).lexically_normal();
    if (error || destination.filename().empty()) {
        return refuse(command, request.instance_id, save.file_name,
            "save_backup_destination_unsafe", "Backup destination is invalid",
            error ? error.message() : path_string(destination), false);
    }
    const fs::path manifest = fs::path(path_string(destination) + ".manifest.json");
    facman::platform::StableDirectoryObject destination_parent;
    if (request.output_path.empty()) {
        facman::platform::StableDirectoryObject instance_root;
        if (!authority.root_authority->validate_descendant(instance.root).ok() ||
            !instance_root.open_no_follow_for_relative_writes(instance.root).ok()) {
            return refuse(command, request.instance_id, save.file_name,
                "save_backup_destination_unsafe", "Instance backup root is not owned",
                path_string(instance.root), false);
        }
        const auto opened = instance_root.open_child_directory_no_follow_for_relative_writes(
            "backups", destination_parent);
        if (!opened.ok() &&
            !instance_root.create_child_directory_exclusive("backups", destination_parent).ok()) {
            return refuse(command, request.instance_id, save.file_name,
                "save_backup_destination_unsafe", "Instance backup root is linked or unreadable",
                path_string(destination.parent_path()), false);
        }
    } else if (!destination_parent.open_no_follow_for_relative_writes(
            destination.parent_path()).ok()) {
        return refuse(command, request.instance_id, save.file_name,
            "save_backup_destination_unsafe", "Explicit backup parent must already exist",
            path_string(destination.parent_path()), false);
    }
    // An explicit --to authorizes one new backup in this pinned parent. Paths
    // inside the workspace also retain workspace root authority checks.
    const auto safe_destination = [&]() {
        const fs::path parent = destination.parent_path();
        const bool root_parent = parent == authority.root_authority->path().lexically_normal();
        const bool workspace_parent = root_parent ||
            authority.root_authority->validate_descendant(parent).ok();
        if (request.output_path.empty() && !workspace_parent) return false;
        return (!workspace_parent ||
                (authority.root_authority->validate_descendant(destination, true).ok() &&
                 authority.root_authority->validate_descendant(manifest, true).ok())) &&
            destination_parent.revalidate().ok() &&
            facman::workspace::revalidate_workspace_root(authority).ok();
    };
    if (!safe_destination()) {
        return refuse(command, request.instance_id, save.file_name,
            "save_backup_destination_unsafe", "Backup destination parent is unsafe or changed",
            path_string(destination), false);
    }
    facman::platform::PathIdentity destination_identity, manifest_identity;
    const auto destination_status = facman::platform::inspect_path_no_follow(
        destination, destination_identity);
    const auto manifest_status = facman::platform::inspect_path_no_follow(
        manifest, manifest_identity);
    if (!destination_status.ok() || !manifest_status.ok()) {
        return refuse(command, request.instance_id, save.file_name,
            "save_backup_destination_unsafe", "Backup target cannot be safely inspected",
            path_string(destination), false);
    }
    if (destination_identity.exists || manifest_identity.exists) {
        return refuse(command, request.instance_id, save.file_name, "save_backup_target_exists", "Save backup target already exists", path_string(destination));
    }
    constexpr std::uint64_t kSidecarAndFilesystemReserve = 128U * 1024U;
    error.clear();
    const auto capacity = fs::space(destination.parent_path(), error);
    if (error || !safe_destination()) {
        return refuse(command, request.instance_id, save.file_name,
            "save_backup_destination_unsafe", "Backup destination capacity or ownership changed",
            error ? error.message() : path_string(destination), false);
    }
    if (capacity.available < kSidecarAndFilesystemReserve ||
        source_pin.size() > capacity.available - kSidecarAndFilesystemReserve) {
        return refuse(command, request.instance_id, save.file_name,
            "persistent_write_refused", "Insufficient space for a complete backup stage",
            path_string(destination.parent_path()));
    }
    const fs::path staging = unique_staging(workspace, ".facman-save-backup-");
    if (staging.empty()) {
        return refuse(command, request.instance_id, save.file_name,
            "save_backup_destination_unsafe", "Backup staging name cannot be reserved",
            path_string(destination.parent_path()));
    }
    OperationJournal journal;
    if (!journal.start(workspace, command, destination, {save.path}, {staging},
            tx::directory_effect_identity(destination_parent))) {
        return refuse(command, request.instance_id, save.file_name, "recovery_write_refused", "Backup journal preparation failed", journal.detail());
    }
    facman::archive::Status status = facman::archive::create_owned_staging_root(staging);
    if (!status.ok()) { journal.failed(status.detail); return refuse(command, request.instance_id, save.file_name, "persistent_write_refused", "Backup staging refused", status.code + ": " + status.detail); }
    if (!journal.step("staging", "owned_staging_created")) return refuse(command, request.instance_id, save.file_name, "recovery_write_refused", "Backup staging journal update failed", journal.detail());
    const fs::path staged = staging / destination.filename();
    StableCopyResult copied;
    if (!stable_copy(save.path, staged, copied, &source_pin)) {
        (void)facman::archive::cleanup_owned_staging_root(staging);
        journal.failed(copied.detail);
        return refuse(command, request.instance_id, save.file_name,
            copied.source_changed ? "save_source_changed" : "persistent_write_refused",
            copied.source_changed ? "Save source changed during backup" :
                "Backup staging copy could not complete",
            copied.detail);
    }
    if (!journal.step("staged", "stable_source_copied")) return refuse(command, request.instance_id, save.file_name, "recovery_write_refused", "Backup staged journal update failed", journal.detail());
    SaveRef staged_save;
    std::string detail;
    if (!inspect_save(staged, staged_save, detail) || !staged_save.factorio_save_recognized) {
        (void)facman::archive::cleanup_owned_staging_root(staging);
        journal.failed(detail);
        return refuse(command, request.instance_id, save.file_name, "save_malformed", "Staged backup verification failed", detail);
    }
    if (fault_requested("pause_after_staged_copy"))
        std::this_thread::sleep_for(std::chrono::seconds(2));
    const auto source_after_copy = stable_input_sha256(source_pin);
    if (!source_after_copy.has_value() || *source_after_copy != copied.sha256 ||
        !source_unchanged()) {
        (void)facman::archive::cleanup_owned_staging_root(staging);
        journal.failed("save source changed before backup publication");
        return refuse(command, request.instance_id, save.file_name,
            "save_source_changed", "Save changed while its backup was staged",
            path_string(save.path));
    }
    if (!safe_destination()) {
        (void)facman::archive::cleanup_owned_staging_root(staging);
        journal.failed("backup destination ownership changed before publication");
        return refuse(command, request.instance_id, save.file_name,
            "save_backup_destination_unsafe", "Backup destination changed before publication",
            path_string(destination), false);
    }
    if (const auto lock = save_lock_path(instance)) {
        (void)facman::archive::cleanup_owned_staging_root(staging);
        journal.failed("instance run ownership appeared during backup");
        return refuse(command, request.instance_id, save.file_name,
            "save_locked", "Save writes became locked during backup",
            path_string(*lock));
    }
    const BackupResult result {request.instance_id, save, destination, manifest,
        utc_now(), copied.sha1, copied.sha256, authority.workspace_id, copied.size,
        "pinned_source_two_pass_sha256_v1"};
    journal.record().operation_context = to_json(result) + "\n";
    const auto temporary = tx::RelativePath::parse(
        ".facman-save-backup-" + journal.record().transaction_id +
        ".staging.zip");
    const auto expected_sha256 = facman::core::Sha256Digest::parse(copied.sha256);
    if (!temporary || !expected_sha256) {
        return refuse(command, request.instance_id, save.file_name,
            "recovery_write_refused", "Backup publication identity is invalid",
            temporary ? expected_sha256.error().message : temporary.error().message);
    }
    journal.record().expected_files.push_back(
        {temporary.value(), expected_sha256.value(), copied.size});
    if (!journal.checkpoint("backup_manifest_bound")) {
        return refuse(command, request.instance_id, save.file_name,
            "recovery_write_refused", "Backup manifest journal update failed",
            journal.detail());
    }
    if (!journal.step("verified", "staged_save_verified") ||
        !journal.step("committing", "no_clobber_commit_started")) {
        return refuse(
            command,
            request.instance_id,
            save.file_name,
            "recovery_write_refused",
            "Backup commit journal update failed",
            journal.detail());
    }
    std::string commit_detail;
    if (!tx::publish_save_backup_file(workspace, journal.record(), commit_detail)) {
        return refuse(command, request.instance_id, save.file_name,
            "transaction_recovery_required", "Backup publication requires recovery",
            commit_detail, false);
    }
    if (!safe_destination() || !source_unchanged()) {
        return refuse(command, request.instance_id, save.file_name,
            "transaction_recovery_required", "Backup committed but source or destination identity changed",
            path_string(destination), false);
    }
    if (!journal.step("committed", "backup_file_committed")) return refuse(command, request.instance_id, save.file_name, "transaction_recovery_required", "Backup committed but journal update failed", journal.detail(), false);
    if (fault_requested("pause_after_backup_file_committed"))
        std::this_thread::sleep_for(std::chrono::seconds(2));
    std::string write_detail;
    if (!tx::finalize_save_backup_sidecar(journal.record(), write_detail)) {
        return refuse(command, request.instance_id, save.file_name, "transaction_recovery_required", "Backup committed but sidecar requires recovery", write_detail, false);
    }
    status = facman::archive::cleanup_owned_staging_root(staging);
    if (!status.ok()) return refuse(command, request.instance_id, save.file_name, "transaction_recovery_required", "Backup committed but staging cleanup requires recovery", status.detail, false);
    if (!journal.finish()) return refuse(command, request.instance_id, save.file_name, "transaction_recovery_required", "Backup committed but journal close requires recovery", journal.detail(), false);
    return result;
}

CloneOutcome clone_save(const fs::path& workspace, const CloneRequest& request)
{
    const std::string command = "saves.clone";
    Instance source;
    Instance target;
    if (!load_instance(workspace, request.source_instance_id, source) ||
        !load_instance(workspace, request.target_instance_id, target)) {
        return refuse(command, request.source_instance_id, request.save, "unknown_instance", "Source or target instance is not registered", request.target_instance_id);
    }
    if (save_locked(source) || save_locked(target)) {
        return refuse(command, request.source_instance_id, request.save, "save_locked", "Save writes are locked for source or target instance", request.save);
    }
    SaveRef save;
    std::string expected_backup_sha256;
    std::uint64_t expected_backup_size = 0;
    if (request.source_kind == "owned_backup") {
        auto backup = facman::factorio::saves::index::resolve_owned_backup(
            workspace, source.instance_id, request.save);
        if (!backup) return refuse(command, source.instance_id, request.save,
            backup.error().code, backup.error().message, backup.error().path);
        std::string detail;
        if (!inspect_save(backup.value().path, save, detail)) return refuse(command,
            source.instance_id, request.save, "save_backup_unproven", "Backup is not a readable save", detail);
        expected_backup_sha256 = backup.value().sha256;
        expected_backup_size = backup.value().size;
    } else if (request.source_kind == "live") {
        if (!resolve_save(source, request.save, save)) return refuse(command, source.instance_id,
            request.save, "save_not_found", "Save is not present in the source instance", request.save);
    } else return refuse(command, source.instance_id, request.save,
        "save_source_kind_invalid", "Save source kind is not supported", request.source_kind);
    if (!save.archive_structurally_valid || !save.factorio_save_recognized) {
        return refuse(command, source.instance_id, save.file_name, "save_malformed", "Save archive is not recognized as a Factorio save", "level-init.dat is absent");
    }
    const std::string destination_name = request.destination_save.empty()
        ? save.file_name : request.destination_save;
    const fs::path destination_filename = fs::u8path(destination_name);
    std::string destination_detail;
    if ((request.source_kind == "owned_backup" && request.destination_save.empty()) ||
        (!request.destination_save.empty() &&
         !facman::base::validate_identifier(destination_name, destination_detail)) ||
        destination_filename != destination_filename.filename() ||
        destination_filename.extension() != ".zip") return refuse(
        command, target.instance_id, destination_name, "save_clone_target_invalid",
        "Destination must be an explicit safe .zip filename for backup restoration", destination_name);
    const fs::path destination = target.root / "saves" / destination_filename;
    if (fs::exists(destination)) return refuse(command, target.instance_id, save.file_name, "save_clone_target_exists", "Save clone target already exists", path_string(destination));
    const fs::path staging = unique_staging(destination.parent_path(), ".facman-save-clone-");
    OperationJournal journal;
    if (!journal.start(workspace, command, destination, {save.path}, {staging})) {
        return refuse(command, source.instance_id, save.file_name, "recovery_write_refused", "Clone journal preparation failed", journal.detail());
    }
    facman::archive::Status status = facman::archive::create_owned_staging_root(staging);
    if (!status.ok()) { journal.failed(status.detail); return refuse(command, source.instance_id, save.file_name, "persistent_write_refused", "Clone staging refused", status.code + ": " + status.detail); }
    if (!journal.step("staging", "owned_staging_created")) return refuse(command, source.instance_id, save.file_name, "recovery_write_refused", "Clone staging journal update failed", journal.detail());
    const fs::path staged = staging / destination.filename();
    StableCopyResult copied;
    if (!stable_copy(save.path, staged, copied)) {
        (void)facman::archive::cleanup_owned_staging_root(staging);
        journal.failed(copied.detail);
        return refuse(command, source.instance_id, save.file_name, "save_source_changed", "Save source could not be read through one stable handle", copied.detail);
    }
    if ((!expected_backup_sha256.empty() &&
            (copied.sha256 != expected_backup_sha256 || copied.size != expected_backup_size)) ||
        save_locked(source) || save_locked(target)) {
        (void)facman::archive::cleanup_owned_staging_root(staging);
        journal.failed("Backup identity or instance lock changed during copy");
        return refuse(command, source.instance_id, request.save, "save_source_changed",
            "Backup identity or instance lock changed during copy", path_string(save.path));
    }
    if (!journal.step("staged", "stable_source_copied") ||
        !journal.step("verified", "staged_hash_verified") ||
        !journal.step("committing", "no_clobber_commit_started")) {
        return refuse(command, source.instance_id, save.file_name, "recovery_write_refused", "Clone journal update failed", journal.detail());
    }
    if (!expected_backup_sha256.empty()) {
        auto current = facman::factorio::saves::index::resolve_owned_backup(
            workspace, source.instance_id, request.save);
        if (!current || current.value().path != save.path ||
            current.value().sha256 != copied.sha256 || current.value().size != copied.size ||
            save_locked(source) || save_locked(target)) {
            (void)facman::archive::cleanup_owned_staging_root(staging);
            journal.failed("Backup ownership, content, or instance lock changed before publication");
            return refuse(command, source.instance_id, request.save, "save_backup_unproven",
                "Backup ownership, content, or instance lock changed before publication", path_string(save.path));
        }
    }
    const auto published = [&]() {
        facman::platform::StableDirectoryObject stage_parent;
        facman::platform::StableDirectoryObject target_parent;
        auto result = stage_parent.open_no_follow_for_relative_writes(staging);
        if (result.ok()) result = target_parent.open_no_follow_for_relative_writes(destination.parent_path());
#ifdef _WIN32
        facman::platform::DurableOutputFile private_copy;
        if (result.ok()) result = stage_parent.create_child_file_exclusive(
            "verified-private.tmp", copied.size, private_copy);
#else
        facman::platform::PrivatePublicationFile private_copy;
        if (result.ok()) result = private_copy.create(stage_parent, target_parent, copied.size);
#endif
        {
            facman::platform::StableInputFile staged_input;
            if (result.ok()) result = stage_parent.open_child_file_no_follow_pinned(staged.filename(), staged_input);
            if (result.ok() && (!staged_input.identity().regular_file ||
                staged_input.identity().link_count != 1U || staged_input.size() != copied.size)) {
                result = facman::platform::IoStatus::failure(
                    "save_source_changed", "Staged save identity changed before private copy");
            }
            facman::base::Sha256Hasher digest;
            std::array<unsigned char, 65536> block {};
            for (std::uint64_t offset = 0; result.ok() && offset < copied.size;) {
                const auto count = static_cast<std::size_t>(std::min<std::uint64_t>(
                    block.size(), copied.size - offset));
                if (staged_input.read_at(offset, block.data(), count) != count ||
                    private_copy.write_at(offset, block.data(), count) != count) {
                    result = facman::platform::IoStatus::failure(
                        "save_source_changed", "Private save copy failed");
                    break;
                }
                digest.update(block.data(), count);
                offset += count;
            }
            if (result.ok() &&
                (!staged_input.revalidate_path().ok() || digest.finish() != copied.sha256)) {
                result = facman::platform::IoStatus::failure(
                    "save_source_changed", "Private save copy differs from verified source");
            }
        }
        const char* pause_private = std::getenv("FACMAN_TEST_SAVE_CLONE_PAUSE_AFTER_PRIVATE_COPY");
        if (result.ok() && pause_private != nullptr && std::string(pause_private) == "1") {
            std::string marker_detail;
            if (!facman::base::write_text_new_atomic(
                    staging / ".facman-save-clone-private-paused", "copied\n", marker_detail)) {
                result = facman::platform::IoStatus::failure("persistent_write_refused", marker_detail);
            }
            const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(10);
            while (result.ok() &&
                !fs::exists(staging / ".facman-save-clone-private-release") &&
                std::chrono::steady_clock::now() < deadline) {
                std::this_thread::sleep_for(std::chrono::milliseconds(20));
            }
            if (result.ok() && !fs::exists(staging / ".facman-save-clone-private-release")) {
                result = facman::platform::IoStatus::failure(
                    "persistent_write_refused", "Private save copy test pause timed out");
            }
        }
        if (result.ok() && (save_locked(source) || save_locked(target))) {
            result = facman::platform::IoStatus::failure(
                "save_locked", "Save writes became locked before publication");
        }
        if (result.ok() && !expected_backup_sha256.empty()) {
            auto current = facman::factorio::saves::index::resolve_owned_backup(
                workspace, source.instance_id, request.save);
            if (!current || current.value().path != save.path ||
                current.value().sha256 != copied.sha256 || current.value().size != copied.size) {
                result = facman::platform::IoStatus::failure(
                    "save_backup_unproven", "Backup ownership or content changed before publication");
            }
        }
#ifdef _WIN32
        if (result.ok()) result = private_copy.publish_in_directory_no_replace(
            target_parent, destination.filename());
#else
        if (result.ok()) result = private_copy.publish_no_replace(destination.filename());
#endif
        return result;
    }();
    if (!published.ok()) {
        if (published.code == "output_published_unverified") {
            journal.failed(published.detail);
            return refuse(command, source.instance_id, save.file_name,
                "transaction_recovery_required", "Save publication requires recovery", published.detail, false);
        }
        const auto cleaned = facman::archive::cleanup_owned_staging_root(staging);
        if (!cleaned.ok()) {
            journal.failed(cleaned.detail);
            return refuse(command, source.instance_id, save.file_name,
                "transaction_recovery_required", "Save staging cleanup requires recovery", cleaned.detail, false);
        }
        journal.failed(published.detail);
        return refuse(command, source.instance_id, save.file_name,
            published.code == "save_source_changed" ? "save_source_changed" :
            published.code == "save_locked" ? "save_locked" :
            published.code == "save_backup_unproven" ? "save_backup_unproven" : "persistent_write_refused",
            "Clone publication refused", published.detail);
    }
    if (!journal.step("committed", "clone_file_committed")) return refuse(command, source.instance_id, save.file_name, "transaction_recovery_required", "Clone committed but journal update failed", journal.detail(), false);
    status = facman::archive::cleanup_owned_staging_root(staging);
    if (!status.ok()) return refuse(command, source.instance_id, save.file_name, "transaction_recovery_required", "Clone committed but staging cleanup requires recovery", status.detail, false);
    if (!journal.finish()) return refuse(command, source.instance_id, save.file_name, "transaction_recovery_required", "Clone committed but journal close requires recovery", journal.detail(), false);
    return CloneResult {source.instance_id, target.instance_id, save, destination, utc_now(),
        copied.sha1, copied.sha256, request.source_kind, destination_name};
}

ExportOutcome export_instance(const fs::path& workspace, const ExportRequest& request)
{
    const std::string command = "instance.export";
    Instance instance;
    if (!load_instance(workspace, request.instance_id, instance)) {
        return refuse(command, request.instance_id, "", "unknown_instance", "Instance is not registered", request.instance_id);
    }
    fs::path destination = request.output_path;
    if (destination.is_relative()) destination = fs::absolute(destination);
    if (fs::exists(destination)) {
        return refuse(command, request.instance_id, "", "instance_export_target_exists", "Instance export target already exists", path_string(destination));
    }
    for (const SaveRef& save : instance_saves(instance, true)) {
        if (!save.archive_structurally_valid || !save.factorio_save_recognized) {
            return refuse(command, request.instance_id, save.file_name, "save_malformed", "Instance contains a save that is not recognized", save.file_name);
        }
    }
    std::error_code error;
    fs::create_directories(destination.parent_path(), error);
    if (error) return refuse(command, request.instance_id, "", "persistent_write_refused", "Export parent could not be created", error.message());
    const fs::path payload_root = unique_staging(destination.parent_path(), ".facman-instance-payload-");
    const fs::path archive_staging = unique_staging(destination.parent_path(), ".facman-instance-archive-");
    OperationJournal journal;
    if (!journal.start(workspace, command, destination, {instance.root}, {payload_root, archive_staging})) {
        return refuse(command, request.instance_id, "", "recovery_write_refused", "Export journal preparation failed", journal.detail());
    }
    facman::archive::Status status = facman::archive::create_owned_staging_root(payload_root);
    if (!status.ok()) { journal.failed(status.detail); return refuse(command, request.instance_id, "", "persistent_write_refused", "Export payload staging refused", status.detail); }
    if (!journal.step("staging", "payload_staging_created")) return refuse(command, request.instance_id, "", "recovery_write_refused", "Export staging journal update failed", journal.detail());
    std::vector<ExportFile> files;
    ExportFile generated;
    if (!write_generated(payload_root, "instance.v1.json", portable_instance_json(instance), generated)) {
        (void)facman::archive::cleanup_owned_staging_root(payload_root);
        return refuse(command, request.instance_id, "", "persistent_write_refused", "Portable instance manifest staging failed", "instance.v1.json");
    }
    files.push_back(generated);
    if (!write_generated(payload_root, "config/config.ini", portable_config(), generated)) {
        (void)facman::archive::cleanup_owned_staging_root(payload_root);
        return refuse(command, request.instance_id, "", "persistent_write_refused", "Portable config staging failed", "config/config.ini");
    }
    files.push_back(generated);
    const std::vector<std::pair<fs::path, std::string>> roots = {
        {instance.root / "mods", "mods/"},
        {instance.root / "saves", "saves/"}};
    for (const auto& root : roots) {
        if (!fs::is_directory(root.first)) continue;
        for (const fs::directory_entry& entry : fs::directory_iterator(root.first)) {
            if (!entry.is_regular_file(error) || error) continue;
            ExportFile file;
            file.path = root.second + entry.path().filename().generic_string();
            file.source = payload_root / fs::path(file.path);
            fs::create_directories(file.source.parent_path(), error);
            StableCopyResult copied;
            if (error || !stable_copy(entry.path(), file.source, copied)) {
                (void)facman::archive::cleanup_owned_staging_root(payload_root);
                return refuse(command, request.instance_id, "", "instance_source_changed", "Instance source could not be read through one stable handle", file.path + ": " + copied.detail);
            }
            file.size = copied.size;
            file.sha256 = copied.sha256;
            if (root.second == "mods/" && entry.path().extension() == ".json") {
                std::string portable = read_text(file.source);
                replace_all(portable, path_string(instance.root), "$FACMAN_INSTANCE_ROOT");
                std::string rewrite_detail;
                if (!rewrite_text_durable(file.source, portable, rewrite_detail)) {
                    (void)facman::archive::cleanup_owned_staging_root(payload_root);
                    return refuse(command, request.instance_id, "", "persistent_write_refused", "Portable mod metadata rewrite failed", file.path + ": " + rewrite_detail);
                }
                file.size = fs::file_size(file.source);
                file.sha256 = facman::base::sha256_hex_file(file.source);
            }
            files.push_back(file);
        }
    }
    std::sort(files.begin(), files.end(), [](const ExportFile& left, const ExportFile& right) { return left.path < right.path; });
    if (!write_generated(payload_root, "manifest/export.v1.json", export_manifest(instance, files), generated)) {
        (void)facman::archive::cleanup_owned_staging_root(payload_root);
        return refuse(command, request.instance_id, "", "persistent_write_refused", "Export hash manifest staging failed", "manifest/export.v1.json");
    }
    std::vector<facman::archive::WriteEntry> entries;
    entries.push_back({generated.path, generated.source, false});
    for (const ExportFile& file : files) entries.push_back({file.path, file.source, false});
    if (!journal.step("staged", "portable_payload_materialized")) return refuse(command, request.instance_id, "", "recovery_write_refused", "Export payload journal update failed", journal.detail());
    facman::archive::WriteOptions options;
    options.method = facman::archive::CompressionMethod::deflate;
    options.reproducible = true;
    options.limits = facman::archive::InstanceTransferPolicy::limits();
    facman::archive::WriteResult written;
    status = facman::archive::write_to_new_owned_staging(
        archive_staging,
        destination.filename().string(),
        entries,
        options,
        written);
    if (!status.ok()) {
        (void)facman::archive::cleanup_owned_staging_root(payload_root);
        journal.failed(status.detail);
        return refuse(command, request.instance_id, "", "persistent_write_refused", "Instance export staging failed", status.code + ": " + status.detail);
    }
    if (!journal.step("verified", "archive_self_verified") ||
        !journal.step("committing", "no_clobber_commit_started")) {
        return refuse(
            command,
            request.instance_id,
            "",
            "recovery_write_refused",
            "Export commit journal update failed",
            journal.detail());
    }
    std::string commit_detail;
    if (!tx::StagedFileCommit::commit(archive_staging, written.archive_path, destination, commit_detail)) {
        (void)facman::archive::cleanup_owned_staging_root(archive_staging);
        (void)facman::archive::cleanup_owned_staging_root(payload_root);
        journal.failed(commit_detail);
        return refuse(command, request.instance_id, "", "persistent_write_refused", "Instance export commit failed", commit_detail);
    }
    if (!journal.step("committed", "export_archive_committed")) return refuse(command, request.instance_id, "", "transaction_recovery_required", "Export committed but journal update failed", journal.detail(), false);
    const facman::archive::Status archive_cleanup = facman::archive::cleanup_owned_staging_root(archive_staging);
    const facman::archive::Status payload_cleanup = facman::archive::cleanup_owned_staging_root(payload_root);
    if (!archive_cleanup.ok() || !payload_cleanup.ok()) {
        return refuse(command, request.instance_id, "", "transaction_recovery_required", "Export committed but staging cleanup requires recovery", archive_cleanup.detail + payload_cleanup.detail, false);
    }
    if (!journal.finish()) return refuse(command, request.instance_id, "", "transaction_recovery_required", "Export committed but journal close requires recovery", journal.detail(), false);
    return ExportResult {request.instance_id, destination, files.size() + 1, {"local_data_root", "config.ini paths and secrets"}};
}

ImportOutcome import_instance(const fs::path& workspace, const ImportRequest& request)
{
    const std::string command = "instance.import";
    facman::archive::Plan plan;
    facman::archive::Status status = facman::archive::inspect_archive(
        request.source_path,
        facman::archive::InstanceTransferPolicy::limits(),
        plan);
    if (!status.ok()) {
        const bool unsafe = status.code.find("path") != std::string::npos || status.code.find("collision") != std::string::npos;
        return refuse(command, request.instance_id_override, "", unsafe ? "unsafe_archive_path" : "instance_import_manifest_invalid", "Instance pack inspection failed", status.code + ": " + status.detail, !unsafe);
    }
    std::string manifest_text;
    std::string instance_text;
    if (!stream_plan_entry(plan, "manifest/export.v1.json", manifest_text, 4 * 1024 * 1024) ||
        !stream_plan_entry(plan, "instance.v1.json", instance_text, 1024 * 1024)) {
        return refuse(command, request.instance_id_override, "", "instance_import_manifest_invalid", "Instance pack manifest is missing or unsupported", path_string(request.source_path));
    }
    auto manifest_document = decode_document(manifest_text);
    auto instance_document = decode_document(instance_text, 1024U * 1024U);
    if (!manifest_document || !manifest_document.value().is_object() ||
        document_string(manifest_document.value(), "schema") != "factorio.instance_export_manifest.v2" ||
        !instance_document || !instance_document.value().is_object()) {
        return refuse(command, request.instance_id_override, "", "instance_import_manifest_invalid", "Instance pack manifest is missing or unsupported", path_string(request.source_path));
    }
    if (fault_requested("after_manifest_read")) {
        return refuse(command, request.instance_id_override, "", "transaction_recovery_required", "Injected interruption after manifest read", "no output created");
    }
    Instance instance;
    instance.instance_id = request.instance_id_override.empty()
        ? document_string(instance_document.value(), "instance_id")
        : request.instance_id_override;
    instance.display_name = document_string(instance_document.value(), "display_name");
    instance.install_ref = document_string(instance_document.value(), "install_ref");
    instance.factorio_version = document_string(instance_document.value(), "factorio_version");
    instance.profile = document_string(instance_document.value(), "profile");
    instance.template_id = document_string(instance_document.value(), "template");
    const auto version_family = facman::factorio::version::classify(instance.factorio_version);
    if (!version_family.valid || !version_family.version.has_patch ||
        !facman::factorio::version::is_target_family(version_family.family)) {
        return refuse(
            command,
            instance.instance_id,
            "",
            "instance_version_family_unsupported",
            "Imported instance does not name an exact F100, F110, F200, or F210 Factorio version",
            instance.factorio_version);
    }
    const facman::base::ManagedPathResult target =
        facman::base::managed_directory(workspace, "instances", instance.instance_id);
    if (!target.ok() || instance.instance_id.empty()) {
        return refuse(command, instance.instance_id, "", target.ok() ? "instance_import_manifest_invalid" : target.code, "Instance import id is invalid", target.detail, false);
    }
    instance.root = target.path;
    if (fs::exists(instance.root)) {
        return refuse(command, instance.instance_id, "", "instance_import_target_exists", "Instance import target already exists", path_string(instance.root));
    }
    if (fault_requested("after_target_planning")) {
        return refuse(command, instance.instance_id, "", "transaction_recovery_required", "Injected interruption after target planning", "no output created");
    }
    if (fault_requested("pause_after_target_planning")) {
        const char* marker = std::getenv("FACMAN_TEST_SAVE_TRANSFER_PAUSE_MARKER");
        std::string detail;
        if (marker == nullptr || *marker == '\0' ||
            !facman::base::write_text_new_atomic(marker, "planned\n", detail)) {
            return refuse(command, instance.instance_id, "", "persistent_write_refused",
                "Import test pause marker could not be created", detail);
        }
        const fs::path release = std::string(marker) + ".release";
        const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(10);
        std::error_code error;
        while (!fs::exists(release, error) && !error &&
            std::chrono::steady_clock::now() < deadline) {
            std::this_thread::sleep_for(std::chrono::milliseconds(20));
        }
        if (error || !fs::exists(release, error)) {
            return refuse(command, instance.instance_id, "", "persistent_write_refused",
                "Import test pause timed out", error.message());
        }
    }
    fs::path install_root;
    if (!load_install_root(workspace, instance.install_ref, install_root)) {
        return refuse(command, instance.instance_id, "", "unknown_install", "Instance pack references an unregistered install", instance.install_ref);
    }
    const std::map<std::string, std::string> hashes = manifest_hashes(manifest_text);
    if (hashes.empty()) {
        return refuse(command, instance.instance_id, "", "instance_import_manifest_invalid", "Instance pack hash closure is missing or malformed", "file_hashes");
    }
    std::set<std::string> planned_files;
    for (const facman::archive::Entry& entry : plan.entries) {
        if (!entry.directory && entry.path != "manifest/export.v1.json") planned_files.insert(entry.path);
    }
    std::set<std::string> declared_files;
    for (const auto& item : hashes) declared_files.insert(item.first);
    if (planned_files != declared_files) {
        return refuse(command, instance.instance_id, "", "instance_import_manifest_invalid", "Archive plan does not match the declared file closure", path_string(request.source_path), false);
    }
    const fs::path staging = unique_staging(instance.root.parent_path(), ".facman-instance-import-");
    tx::Record transaction;
    transaction.command_id = command;
    transaction.target = instance.root;
    transaction.sources = {request.source_path};
    transaction.staging_roots = {staging};
    for (const facman::archive::Entry& entry : plan.entries) {
        if (entry.directory || entry.path == "manifest/export.v1.json") continue;
        auto expected_path = tx::RelativePath::parse(entry.path);
        auto expected_digest = facman::core::Sha256Digest::parse(hashes.at(entry.path));
        if (!expected_path || !expected_digest) {
            return refuse(command, instance.instance_id, "", "instance_import_manifest_invalid", "Instance expectation could not be represented safely", entry.path, false);
        }
        transaction.expected_files.push_back(
            {expected_path.take_value(), expected_digest.take_value(), entry.expanded_size});
    }
    transaction.commit_strategy = "destination_volume_stage_then_atomic_no_replace";
    auto started = tx::TransactionSession::begin(workspace, std::move(transaction));
    if (!started) {
        return refuse(command, instance.instance_id, "", "recovery_write_refused", "Instance import journal could not be durably prepared", started.error().message);
    }
    tx::TransactionSession session = started.take_value();
    if (!session.validated("request_validated") ||
        !session.planned("archive_plan_and_hash_closure_validated") ||
        !session.staging("owned_staging_selected")) {
        return refuse(command, instance.instance_id, "", "recovery_write_refused", "Instance import journal could not be durably prepared", session.detail());
    }
    std::size_t middle_entry = plan.entries.size() / 2;
    status = facman::archive::extract_to_new_owned_staging(
        plan,
        staging,
        facman::archive::InstanceTransferPolicy::limits(),
        [&](std::uint32_t index, const char* checkpoint) {
            if (std::string(checkpoint) != "after_chunk") return true;
            if (fault_requested("during_first_file") && index == plan.entries.front().index) return false;
            if (fault_requested("during_middle_file") && index == plan.entries[middle_entry].index) return false;
            return true;
        });
    if (!status.ok()) {
        session.failed(status.code + ": " + status.detail);
        return refuse(command, instance.instance_id, "", "persistent_write_refused", "Instance extraction staging failed", status.code + ": " + status.detail);
    }
    if (!session.staged("archive_extracted")) {
        (void)facman::archive::cleanup_owned_staging_root(staging);
        return refuse(command, instance.instance_id, "", "recovery_write_refused", "Instance import staged but journal update failed", session.detail());
    }
    if (fault_requested("after_extraction")) {
        (void)facman::archive::cleanup_owned_staging_root(staging);
        return refuse(command, instance.instance_id, "", "transaction_recovery_required", "Injected interruption after extraction", "owned staging removed");
    }
    std::string detail;
    if (!verify_staged_tree(staging, hashes, detail)) {
        (void)facman::archive::cleanup_owned_staging_root(staging);
        session.failed(detail);
        return refuse(command, instance.instance_id, "", "instance_import_manifest_invalid", "Staged instance hash closure failed", detail, false);
    }
    if (!session.verified("staged_tree_hashes_verified")) {
        (void)facman::archive::cleanup_owned_staging_root(staging);
        return refuse(command, instance.instance_id, "", "recovery_write_refused", "Instance import verified but journal update failed", session.detail());
    }
    if (fault_requested("after_verification")) {
        (void)facman::archive::cleanup_owned_staging_root(staging);
        return refuse(command, instance.instance_id, "", "transaction_recovery_required", "Injected interruption after verification", "owned staging removed");
    }
    std::error_code error;
    fs::remove_all(staging / "manifest", error);
    fs::remove(staging / "config/config-path.cfg", error);
    fs::remove(staging / "config/config.ini", error);
    fs::remove(staging / "instance.v1.json", error);
    fs::create_directories(staging / "config", error);
    std::string write_detail;
    if (error || !facman::base::write_text_new_atomic(staging / "config/config.ini", effective_config(instance, install_root), write_detail) ||
        !facman::base::write_text_new_atomic(staging / "instance.v1.json", local_instance_json(instance), write_detail)) {
        (void)facman::archive::cleanup_owned_staging_root(staging);
        return refuse(command, instance.instance_id, "", "persistent_write_refused", "Local instance metadata staging failed", write_detail);
    }
    if (fault_requested("before_commit")) {
        (void)facman::archive::cleanup_owned_staging_root(staging);
        return refuse(command, instance.instance_id, "", "transaction_recovery_required", "Injected interruption before commit", "owned staging removed");
    }
    if (!session.committing("local_metadata_materialized")) {
        (void)facman::archive::cleanup_owned_staging_root(staging);
        return refuse(command, instance.instance_id, "", "recovery_write_refused", "Instance import commit journal update failed", session.detail());
    }
    if (!tx::StagedDirectoryCommit::commit(staging, instance.root, write_detail)) {
        (void)facman::archive::cleanup_owned_staging_root(staging);
        session.failed(write_detail);
        return refuse(command, instance.instance_id, "", "persistent_write_refused", "Instance import commit failed", write_detail);
    }
    if (!session.committed("target_committed")) {
        return refuse(command, instance.instance_id, "", "transaction_recovery_required", "Instance committed but journal update failed", session.detail(), false);
    }
    if (fault_requested("after_commit_before_journal_close")) {
        return refuse(command, instance.instance_id, "", "transaction_recovery_required", "Injected interruption after commit", path_string(instance.root), false);
    }
    fs::remove(instance.root / facman::archive::owned_staging_marker_name(), error);
    if (error) return refuse(command, instance.instance_id, "", "transaction_recovery_required", "Instance committed but ownership marker cleanup requires recovery", error.message(), false);
    if (!session.complete()) {
        return refuse(command, instance.instance_id, "", "transaction_recovery_required", "Instance committed but journal close requires recovery", session.detail(), false);
    }
    return ImportResult {instance.instance_id, instance.root, plan.entries.size()};
}

std::string to_json(const ListResult& value)
{
    json::ArrayBuilder saves;
    for (const SaveRef& save : value.saves) saves.add_object(save_ref_builder(save));
    json::ObjectBuilder output;
    output.add_string("schema", "factorio.saves.v1");
    output.add_string("command", "saves.list");
    output.add_string("instance_id", value.instance_id);
    output.add_array("saves", saves);
    return output.serialize();
}

std::string to_json(const BackupResult& value)
{
    json::ObjectBuilder output;
    output.add_string("schema", "factorio.save_backup.v1");
    output.add_string("command", "saves.backup");
    output.add_string("instance_id", value.instance_id);
    output.add_string("save", value.save.file_name);
    output.add_string("source_path", path_string(value.save.path));
    output.add_string("destination_path", path_string(value.destination_path));
    output.add_string("path", path_string(value.destination_path));
    output.add_string("manifest_path", path_string(value.manifest_path));
    output.add_string("created_at", value.created_at);
    output.add_string("sha1", value.sha1);
    output.add_string("sha256", value.sha256);
    output.add_string("workspace_id", value.workspace_id);
    (void)output.add_unsigned_integer("source_size", value.source_size);
    output.add_string("consistency_policy", value.consistency_policy);
    output.add_bool("archive_structurally_valid", true);
    output.add_bool("factorio_save_recognized", true);
    output.add_bool("deep_save_semantics_inspected", false);
    return output.serialize();
}

std::string to_json(const CloneResult& value)
{
    json::ObjectBuilder output;
    output.add_string("schema", "factorio.save_clone.v1");
    output.add_string("command", "saves.clone");
    output.add_string("source_instance_id", value.source_instance_id);
    output.add_string("target_instance_id", value.target_instance_id);
    output.add_string("save", value.save.file_name);
    output.add_string("source_path", path_string(value.save.path));
    output.add_string("destination_path", path_string(value.destination_path));
    output.add_string("path", path_string(value.destination_path));
    output.add_string("created_at", value.created_at);
    output.add_string("sha1", value.sha1);
    output.add_string("sha256", value.sha256);
    output.add_string("source_kind", value.source_kind);
    output.add_string("destination_save", value.destination_save);
    output.add_bool("archive_structurally_valid", true);
    output.add_bool("factorio_save_recognized", true);
    output.add_bool("deep_save_semantics_inspected", false);
    return output.serialize();
}

std::string to_json(const ExportResult& value)
{
    json::ArrayBuilder redactions;
    redactions.add_string("local_data_root");
    redactions.add_string("config.ini paths and secrets");
    json::ObjectBuilder output;
    output.add_string("schema", "factorio.instance_export.v1");
    output.add_string("command", "instance.export");
    output.add_string("instance_id", value.instance_id);
    output.add_string("path", path_string(value.output_path));
    (void)output.add_unsigned_integer("files", value.files);
    output.add_array("redactions", redactions);
    output.add_bool("file_hash_closure", true);
    output.add_bool("deep_save_semantics_inspected", false);
    return output.serialize();
}

std::string to_json(const ImportResult& value)
{
    json::ObjectBuilder output;
    output.add_string("schema", "factorio.instance_import.v1");
    output.add_string("command", "instance.import");
    output.add_string("instance_id", value.instance_id);
    output.add_string("path", path_string(value.destination_path));
    (void)output.add_unsigned_integer("files", value.files);
    return output.serialize();
}

std::string to_json(const Refusal& value)
{
    const bool save_command = value.command.rfind("saves.", 0) == 0;
    json::ObjectBuilder refusal;
    refusal.add_string("schema", "common.refusal.v1");
    refusal.add_string("code", value.code);
    refusal.add_string("reason", value.reason);
    refusal.add_bool("recoverable", value.recoverable);
    refusal.add_bool("retryable", value.recoverable);
    refusal.add_string("severity", "blocked");
    json::ObjectBuilder details;
    details.add_string("detail", value.detail);
    json::ObjectBuilder output;
    output.add_string("schema", save_command ? "factorio.save_refusal.v1" : "factorio.instance_transfer_refusal.v1");
    output.add_string("command", value.command);
    output.add_string("status", "refused");
    output.add_string("instance_id", value.instance_id);
    if (save_command) output.add_string("save", value.save);
    output.add_object("refusal", refusal);
    output.add_object("details", details);
    if (save_command) output.add_string("suggested_next_command", value.suggested_next_command);
    return output.serialize();
}

} // namespace facman::factorio::saves::operations
