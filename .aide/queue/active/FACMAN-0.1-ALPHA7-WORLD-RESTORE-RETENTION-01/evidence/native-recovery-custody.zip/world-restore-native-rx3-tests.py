import pathlib,json,hashlib,subprocess,os,sys,threading,unittest,datetime
R=pathlib.Path(r'D:\Projects\Factorio\factorio-launcher');E=pathlib.Path(__file__).resolve().parent;W=E.parent;HEAD='1949aff0d1830ca25582aab205b179d955b839c1';TREE='459137e553e6542e8ed02bfbfe72b43ffcd7fab4';EXE=W/'native-developer/Debug/facman.exe';OUT=E/'world-restore-native-rx3-qualification.json';RAW=E/'world-restore-native-rx3-commands'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def output(*a):return subprocess.check_output(a,cwd=R,stderr=subprocess.PIPE).decode('utf-8').strip()
def write(p,v):
 with p.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(v,indent=2)+'\n')
assert __debug__ and os.environ.get('PYTHONOPTIMIZE')=='0' and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1'
assert not OUT.exists() and not RAW.exists()
assert output('git','rev-parse','HEAD')==HEAD and output('git','rev-parse','HEAD^{tree}')==TREE and not output('git','status','--porcelain')
review=json.loads((E/'world-restore-native-rx3-worker.review.json').read_text());assert review['verdict']=='PASS' and review['script_sha256']==sha(pathlib.Path(__file__))
built=json.loads((E/'world-restore-native-rx2-build.json').read_text());assert built['status']=='PASS' and built['head']==HEAD and built['tree']==TREE and built['CLI_sha256']==sha(EXE)
write(E/'world-restore-native-rx3-worker.claim.json',{'PID':os.getpid(),'head':HEAD,'script_sha256':sha(pathlib.Path(__file__)),'review_sha256':sha(E/'world-restore-native-rx3-worker.review.json'),'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'no_automatic_replay':True})
RAW.mkdir();lock=threading.Lock();rows=[];count=0;OriginalPopen=subprocess.Popen
class RecordedPopen(OriginalPopen):
 def __init__(self,args,*a,**kw):
  global count
  assert isinstance(args,(list,tuple)) and pathlib.Path(args[0]).resolve()==EXE.resolve(), 'Unexpected subprocess during fixture proof'
  with lock:count+=1;self.proof_number=count
  self.proof_recorded=False;env=kw.get('env') or os.environ;self.proof_args=list(map(str,args));self.proof_prefix=RAW/f'{self.proof_number:04d}'
  write(self.proof_prefix.with_suffix('.issued.json'),{'argv':self.proof_args,'test_environment':{k:v for k,v in env.items() if k.startswith('FACMAN_TEST_') or k=='FACMAN_SAVE_RETENTION_FAULT'},'CLI_sha256':built['CLI_sha256']})
  self.proof_return_text=bool(kw.get('text') or kw.get('universal_newlines') or kw.get('encoding') or kw.get('errors'))
  self.proof_encoding=kw.pop('encoding',None) or 'utf-8';self.proof_errors=kw.pop('errors',None) or 'strict'
  kw.pop('universal_newlines',None);kw['text']=False
  assert kw.get('stdout')==subprocess.PIPE and kw.get('stderr')==subprocess.PIPE
  super().__init__(args,*a,**kw)
 def communicate(self,*a,**kw):
  if a and isinstance(a[0],str):a=(a[0].encode(self.proof_encoding,self.proof_errors),*a[1:])
  if isinstance(kw.get('input'),str):kw['input']=kw['input'].encode(self.proof_encoding,self.proof_errors)
  stdout,stderr=super().communicate(*a,**kw)
  assert isinstance(stdout,bytes) and isinstance(stderr,bytes)
  if not self.proof_recorded:
   self.proof_recorded=True
   for suffix,value in [('stdout',stdout),('stderr',stderr)]:
    self.proof_prefix.with_suffix('.'+suffix).write_bytes(value)
   row={'sequence':self.proof_number,'PID':self.pid,'argv':self.proof_args,'exit_code':self.returncode,'stdout':str(self.proof_prefix.with_suffix('.stdout')),'stderr':str(self.proof_prefix.with_suffix('.stderr')),'stdout_sha256':sha(self.proof_prefix.with_suffix('.stdout')),'stderr_sha256':sha(self.proof_prefix.with_suffix('.stderr'))}
   with lock:rows.append(row)
  if self.proof_return_text:
   stdout=stdout.decode(self.proof_encoding,self.proof_errors).replace('\r\n','\n').replace('\r','\n')
   stderr=stderr.decode(self.proof_encoding,self.proof_errors).replace('\r\n','\n').replace('\r','\n')
  return stdout,stderr
 def kill(self):
  if self.poll() is None:
   p=self.proof_prefix.with_suffix('.kill-intent.json')
   if not p.exists():write(p,{'PID':self.pid,'argv':self.proof_args,'method':'TerminateProcess exit1' if os.name=='nt' else 'SIGKILL9','owned_Popen_handle':True})
  return super().kill()
for p in [R,R/'tests']:sys.path.insert(0,str(p))
os.environ['FACMAN_CLI_EXE']=str(EXE);os.environ['FACMAN_NATIVE_BUILD_ROOT']=str(W/'native-developer');os.environ['FACMAN_NATIVE_CONFIGURATION']='Debug'
suite=unittest.defaultTestLoader.loadTestsFromNames(['tests.test_recovery','tests.test_save_transfer','tests.test_workspace_recovery_refusals','tests.test_save_index_retention'])
assert suite.countTestCases()>0
subprocess.Popen=RecordedPopen
try:
 with (E/'world-restore-native-rx3-unittest.log').open('x',encoding='utf-8') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
finally:subprocess.Popen=OriginalPopen
write(E/'world-restore-native-rx3-command-index.json',sorted(rows,key=lambda x:x['sequence']))
source_clean=output('git','rev-parse','HEAD')==HEAD and output('git','rev-parse','HEAD^{tree}')==TREE and not output('git','status','--porcelain');CLI_unchanged=sha(EXE)==built['CLI_sha256']
accounting_complete=len(rows)==count and sorted(x['sequence'] for x in rows)==list(range(1,count+1)) and all(isinstance(x['exit_code'],int) for x in rows)
record={'status':'PASS' if result.wasSuccessful() and not result.skipped and source_clean and CLI_unchanged and accounting_complete else 'FAIL','head':HEAD,'tree':TREE,'CLI_sha256':built['CLI_sha256'],'platform':'Windows x64 local Debug fixture','tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'commands':len(rows),'issued_commands':count,'command_accounting_complete':accounting_complete,'output_capture':'binary bytes before API-compatible text decoding','command_index_sha256':sha(E/'world-restore-native-rx3-command-index.json'),'source_clean_after':source_clean,'CLI_unchanged_after':CLI_unchanged,'whole_workunit_closed':False,'produced_package_qualified':False,'finished_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
write(OUT,record);print(json.dumps(record));raise SystemExit(0 if record['status']=='PASS' else 1)
