"""One bounded genuine final803 Linux CLI retention qualification campaign."""
from datetime import datetime, timezone
import hashlib
import importlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import signal
import stat
import subprocess
import sys
import tarfile
import threading
import time
import unittest

SOURCE = Path('/mnt/d/Projects/Factorio/factorio-launcher')
TASK = Path('/mnt/d/Development/FacMan/repositories/factorio-launcher-5db2844e2f29/tasks/task-facman-w-bc5cd0812e')
E = TASK / 'evidence'
PREFIX = 'world-restore-final803-retention-rx2'
WORK = E / (PREFIX + '.private')
REPORT = E / (PREFIX + '.json')
PACKET = E / (PREFIX + '-inputs.json')
CLAIM = E / (PREFIX + '.claim.json')
ARCHIVE = Path('/mnt/d/Development/FacMan/repositories/factorio-launcher-5db2844e2f29/tasks/task-facman-o-38884d9b48/evidence/world-backup-final-bundle/FacMan-0.1.0-alpha.6-linux-x64-portable.tar.zst')
HEAD = '803bd98af05c7343977934a7c1b21c67ed897720'
TREE = '0a038464f24deb5ff946b091dd7b48a78a0ed995'
ARCHIVE_SHA = '0c4330e8ccf5ee8523e2c0a2b64c0ea8981d1a101d44da8980c8cb90c92a9f94'
CLI_SHA = '9b0f2fbd3580d5df5a71238bce752eeef787bf4771158cf5515ec7c8b162b579'
sys.dont_write_bytecode = True
sys.path[:0] = [str(SOURCE), str(SOURCE / 'tests')]


def require(value, reason):
    if not value:
        raise ValueError(reason)


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, value):
    with path.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def relative(name):
    path = PurePosixPath(name)
    require(name and not path.is_absolute() and '\\' not in name and ':' not in name
            and all(part not in ('.', '..') for part in path.parts), 'Unsafe product member')
    return path


def inventory(root):
    result = {}
    for path in sorted(root.rglob('*')):
        require(not path.is_symlink(), 'Unexpected inventory link')
        if path.is_file():
            result[path.relative_to(root).as_posix()] = sha(path)
        else:
            require(path.is_dir(), 'Unexpected inventory object')
            result[path.relative_to(root).as_posix() + '/'] = 'directory'
    return result


def source_inputs(packet):
    require(packet['script_sha256'] == sha(Path(__file__)), 'Frozen supervisor changed')
    require(packet['producer_head'] == HEAD and packet['producer_tree'] == TREE
            and packet['archive_sha256'] == ARCHIVE_SHA, 'Producer binding differs')
    for rel, digest in packet['source_files'].items():
        path = SOURCE / rel
        require(path.is_file() and not path.is_symlink() and sha(path) == digest, 'Oracle input changed: ' + rel)
    require(inventory(SOURCE / 'tests/fixtures/fake_factorio_install') == packet['fixture_inventory'], 'Fixture closure changed')
    require({p.relative_to(SOURCE).as_posix() for p in (SOURCE / 'contracts/schema').rglob('*.json')}
            == {rel for rel in packet['source_files'] if rel.startswith('contracts/schema/')}, 'Schema closure changed')
    require(not ARCHIVE.is_symlink() and sha(ARCHIVE) == ARCHIVE_SHA, 'Retained public archive changed')


def extract_product():
    decoder = subprocess.Popen(['zstd', '-d', '-c', str(ARCHIVE)], stdin=subprocess.DEVNULL,
                               stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    try:
        seen, total = set(), 0
        with tarfile.open(fileobj=decoder.stdout, mode='r|') as archive:
            for member in archive:
                name = relative(member.name)
                total += member.size
                require(name not in seen and len(seen) < 20000 and total <= 64 * 1024**2
                        and (member.isfile() or member.isdir()) and not member.issparse()
                        and name.parts[0] == 'FacMan-0.1.0-alpha.6', 'Unsafe or over-budget product TAR')
                seen.add(name)
                path = WORK.joinpath(*name.parts)
                if member.isdir():
                    path.mkdir(parents=True, exist_ok=True)
                else:
                    path.parent.mkdir(parents=True, exist_ok=True)
                    with archive.extractfile(member) as incoming, path.open('xb') as outgoing:
                        shutil.copyfileobj(incoming, outgoing, 1024 * 1024)
                    path.chmod(member.mode & 0o777)
        decoder.stdout.close()
        require(decoder.wait(timeout=20) == 0, 'Product decoder failed')
    finally:
        if decoder.poll() is None:
            decoder.kill()
            decoder.wait(timeout=10)
    product = WORK / 'FacMan-0.1.0-alpha.6'
    manifest = product / 'share/facman/manifest'
    stage = json.loads((manifest / 'product-stage.v1.json').read_text(encoding='utf-8'))
    require(stage['source_revision'] == HEAD and stage['source_tree'] == TREE
            and not stage['source_dirty'] and stage['platform'] == 'linux', 'Actual product provenance differs')
    for item in stage['files']:
        path = product.joinpath(*relative(item['path']).parts)
        require(path.is_file() and path.stat().st_size == item['bytes'] and sha(path) == item['sha256']
                and stat.S_IMODE(path.stat().st_mode) == item['mode'], 'Product-stage file differs')
    checksums = {}
    for line in (manifest / 'MANIFEST.sha256').read_text(encoding='utf-8').splitlines():
        digest, name = line.split('  ', 1)
        require(name not in checksums and sha(product.joinpath(*relative(name).parts)) == digest, 'Product manifest differs')
        checksums[name] = digest
    require(set(checksums) == {p.relative_to(product).as_posix() for p in product.rglob('*')
                             if p.is_file() and p != manifest / 'MANIFEST.sha256'}, 'Product file closure differs')
    require(sha(product / 'facman') == CLI_SHA and (product / 'facman').stat().st_ino != (product / 'FacMan').stat().st_ino,
            'Produced CLI or case-sensitive object binding differs')
    return product


def worker(parent_namespace):
    require(os.geteuid() == 0 and os.getpid() == 1 and os.getppid() == 0
            and os.readlink('/proc/self/ns/mnt') != parent_namespace, 'Private mount/PID namespace init required')
    packet = json.loads(PACKET.read_text(encoding='utf-8'))
    report = dict(status='FAIL', source=HEAD, tree=TREE, candidate_run=37172494677, candidate_attempt=1,
        archive_sha256=ARCHIVE_SHA, produced_cli_sha256=CLI_SHA, packet_sha256=sha(PACKET),
        script_sha256=sha(Path(__file__)), scope='Existing full public retention suite against exact final803 Linux package bytes on WSL',
        observations=[], started_at_utc=now(), peak_tmpfs_bytes=128 * 1024**2, new_roots=0, builds=0,
        candidate_dispatches=0, physical_host=False, game=False, human=False, release=False, whole_workunit_closed=False)
    mounted = False
    try:
        source_inputs(packet)
        subprocess.run(['mount', '-t', 'tmpfs', '-o', 'size=128m,nodev,nosuid', 'tmpfs', str(WORK)], check=True, timeout=10)
        mounted = True
        product = extract_product()
        package_before = inventory(product)
        temporary = WORK / 'test-temp'
        temporary.mkdir()
        os.environ.update(FACMAN_CLI_EXE=str(product / 'facman'), TMPDIR=str(temporary),
                          PYTHONOPTIMIZE='0', PYTHONDONTWRITEBYTECODE='1')
        import tempfile
        tempfile.tempdir = str(temporary)
        native = importlib.import_module('native_cli')
        module = importlib.import_module('test_save_index_retention')
        contract = importlib.import_module('tools.json_contract')
        for loaded, rel in ((native, 'tests/native_cli.py'), (module, 'tests/test_save_index_retention.py'),
                            (contract, 'tools/json_contract.py')):
            require(Path(loaded.__file__).resolve() == (SOURCE / rel).resolve(), 'Loaded module closure differs')
        require(native.facman_executable().resolve() == (product / 'facman').resolve(), 'CLI selection differs')
        mutex = threading.Lock()
        ordinal = 0
        active_test = [None]
        deadline = time.monotonic() + 540

        def recorded(args, env=None):
            nonlocal ordinal
            require(len(args) >= 2 and args[0] == '--workspace'
                    and Path(args[1]).resolve().is_relative_to(temporary), 'Native call escaped owned fixture workspace')
            remaining = min(25, deadline - time.monotonic())
            require(remaining > 0, 'Shared worker command deadline expired')
            with mutex:
                ordinal += 1
                number = ordinal
                test = active_test[0]
            prefix = E / (PREFIX + '-command-' + str(number).zfill(3))
            observation = dict(ordinal=number, test=test, argv=[str(product / 'facman'), *args],
                timeout_seconds=remaining, fault={key: value for key, value in (env or {}).items()
                                                if key.startswith('FACMAN_TEST_') or key == 'FACMAN_SAVE_RETENTION_FAULT'})
            write(prefix.with_suffix('.json'), observation)
            with prefix.with_suffix('.stdout').open('xb') as stdout, prefix.with_suffix('.stderr').open('xb') as stderr:
                try:
                    result = subprocess.run(observation['argv'], cwd=SOURCE, env=env, check=False,
                                            stdout=stdout, stderr=stderr, timeout=remaining)
                except BaseException as exc:
                    stdout.flush()
                    stderr.flush()
                    observation.update(exit_code=None, execution_error=repr(exc), stdout_sha256=sha(prefix.with_suffix('.stdout')),
                                       stderr_sha256=sha(prefix.with_suffix('.stderr')))
                    with mutex:
                        report['observations'].append(observation)
                    raise
            observation.update(exit_code=result.returncode, stdout_sha256=sha(prefix.with_suffix('.stdout')),
                               stderr_sha256=sha(prefix.with_suffix('.stderr')))
            with mutex:
                report['observations'].append(observation)
            return result.returncode, prefix.with_suffix('.stdout').read_text(encoding='utf-8'), prefix.with_suffix('.stderr').read_text(encoding='utf-8')

        native.invoke_machine = recorded

        class Result(unittest.TextTestResult):
            def startTest(self, test):
                active_test[0] = test.id()
                super().startTest(test)

        suite = unittest.defaultTestLoader.loadTestsFromTestCase(module.SaveIndexRetentionTests)
        with (E / (PREFIX + '.unittest.log')).open('x', encoding='utf-8') as log:
            result = unittest.TextTestRunner(stream=log, verbosity=2, resultclass=Result).run(suite)
        report['observations'].sort(key=lambda item: item['ordinal'])
        report.update(tests_run=result.testsRun, failures=[dict(test=t.id(), detail=detail) for t, detail in result.failures],
                      errors=[dict(test=t.id(), detail=detail) for t, detail in result.errors], skipped=result.skipped)
        require(result.testsRun == 12 and result.wasSuccessful() and not result.skipped
                and not any('execution_error' in item for item in report['observations'])
                and [item['ordinal'] for item in report['observations']] == list(range(1, ordinal + 1)),
                'Produced-package retention suite failed, skipped or lost command evidence')
        require(not list(temporary.iterdir()) and inventory(product) == package_before, 'Retained fixture effects or changed product')
        source_inputs(packet)
        report.update(status='PASS', source_fixture_install_only=True, real_produced_package=True,
                      relevant_current_source_equivalence=packet['producer_object_binding'], commands=ordinal)
    except BaseException as exc:
        report.update(status='FAIL', error=repr(exc))
    finally:
        if mounted:
            cleanup = subprocess.run(['umount', str(WORK)], capture_output=True, text=True, timeout=10)
            report['private_volume_unmounted'] = cleanup.returncode == 0
            if cleanup.returncode:
                report.update(status='FAIL', cleanup_error=cleanup.stderr)
        report['finished_at_utc'] = now()
        write(REPORT, report)
    return 0 if report['status'] == 'PASS' else 1


def main():
    require(sys.platform.startswith('linux') and __debug__, 'Linux with assertions required')
    if len(sys.argv) == 3 and sys.argv[1] == '--worker':
        return worker(sys.argv[2])
    require(len(sys.argv) == 1 and os.geteuid() == 0, 'One explicit supervisor launch required')
    marker = json.loads((TASK / '.facman-development-root.v1.json').read_text(encoding='utf-8'))
    require(marker['task_id'] == 'task/facman-world-restore-retention-01' and marker['owner'] == 'facman-development'
            and marker['kind'] == 'task-root' and marker['source_root'] == r'D:\Projects\Factorio\factorio-launcher'
            and marker['canonical_path'] == r'D:\Development\FacMan\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e',
            'Compatible root identity differs')
    require(not WORK.exists() and not REPORT.exists() and not CLAIM.exists(), 'Preserve existing proof; never replay')
    require(shutil.disk_usage(E).free >= 8 * 1024**3 + 32 * 1024**2, 'External log reserve insufficient')
    require(int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines()
                     if line.startswith('MemAvailable:'))) * 1024 >= 1024**3 + 128 * 1024**2, 'Memory reserve insufficient')
    packet = json.loads(PACKET.read_text(encoding='utf-8'))
    source_inputs(packet)
    write(CLAIM, dict(PID=os.getpid(), packet_sha256=sha(PACKET), script_sha256=sha(Path(__file__)),
                     created_at_utc=now(), recovery='Persistent claim; no automatic replay after ambiguous execution'))
    WORK.mkdir()
    namespace = os.readlink('/proc/self/ns/mnt')
    with (E / (PREFIX + '.runner.log')).open('x', encoding='utf-8') as log:
        child = subprocess.Popen(['unshare', '--mount', '--pid', '--fork', '--kill-child=SIGKILL', '--mount-proc',
                                  '--propagation', 'private', sys.executable, '-B', str(Path(__file__).resolve()), '--worker', namespace],
                                 stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True,
                                 env=dict(os.environ, PYTHONOPTIMIZE='0', PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1'))
        try:
            code = child.wait(timeout=600)
        except subprocess.TimeoutExpired:
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGKILL)
            child.wait(timeout=10)
            raise ValueError('Owned namespace deadline; preserve claim and logs')
    require(code == 0 and REPORT.exists(), 'Native retention proof failed; inspect retained report')
    require(os.readlink('/proc/self/ns/mnt') == namespace and not list(WORK.iterdir()) and not os.path.ismount(WORK),
            'Namespace cleanup differs')
    source_inputs(packet)
    write(E / (PREFIX + '.parent-postcheck.json'), dict(status='PASS', report_sha256=sha(REPORT),
        private_mount_absent=True, underlying_child_empty=True, original_namespace_preserved=True))
    print(json.dumps(dict(status='PASS', report_sha256=sha(REPORT))))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
