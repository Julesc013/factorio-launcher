"""Bounded missing restore acceptance oracle; no package execution on import."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import tempfile
import time

from native_cli import facman_executable, invoke
from test_save_transfer import SaveTransferTests, SAVE_FIXTURES, ROOT

Popen = subprocess.Popen

class RestoreProcessLossTests(SaveTransferTests):
    def test_restore_process_loss_recovers_and_retries_identical_target(self):
        with tempfile.TemporaryDirectory() as temporary:
            workspace = Path(temporary)
            self.prepare(workspace)
            saves = workspace / 'instances/source-world/saves'
            original = (SAVE_FIXTURES / 'valid_simple_save/starter.zip').read_bytes()
            (saves / 'world.zip').write_bytes(original)
            unrelated = saves / 'unrelated.zip'
            unrelated.write_bytes(b'unrelated user save retained')
            code, stdout, stderr = invoke([
                '--workspace', temporary, 'saves', 'backup', 'world',
                '--instance', 'source-world', '--json',
            ])
            self.assertEqual(code, 0, stderr + stdout)
            backup = Path(json.loads(stdout)['destination_path'])
            sidecar = Path(str(backup) + '.manifest.json')
            backup_before = hashlib.sha256(backup.read_bytes()).hexdigest()
            sidecar_before = sidecar.read_bytes()
            destination = saves / 'restarted.zip'
            command = [str(facman_executable()), '--workspace', temporary,
                       'saves', 'restore', backup.name, '--instance', 'source-world',
                       '--as', destination.name, '--json']
            environment = os.environ.copy()
            environment['FACMAN_TEST_SAVE_CLONE_PAUSE_AFTER_PRIVATE_COPY'] = '1'
            process = Popen(command, cwd=ROOT, env=environment,
                                       text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            try:
                deadline = time.monotonic() + 8
                staged = []
                while process.poll() is None and time.monotonic() < deadline:
                    staged = [p for p in saves.glob('.facman-save-clone-*')
                              if (p / '.facman-save-clone-private-paused').is_file()]
                    if staged:
                        break
                    time.sleep(0.02)
                self.assertEqual(len(staged), 1, 'Restore did not pause after verified private copy')
                self.assertIsNone(process.poll())
                self.assertFalse(destination.exists(), 'Partial save became visible before publication')
                process.kill()
                stdout, stderr = process.communicate(timeout=20)
                self.assertEqual(process.returncode, -signal.SIGKILL, stderr + stdout)
            finally:
                if process.poll() is None:
                    process.kill()
                    process.communicate(timeout=20)
            self.assertFalse(destination.exists())
            self.assertEqual(backup.read_bytes(), original)
            self.assertEqual(sidecar.read_bytes(), sidecar_before)
            self.assertEqual(unrelated.read_bytes(), b'unrelated user save retained')
            code, stdout, stderr = invoke([
                '--workspace', temporary, 'workspace', 'recovery', 'inspect', '--json',
            ])
            self.assertEqual(code, 0, stderr + stdout)
            records = [record for record in json.loads(stdout)['transactions']
                       if record['command_id'] == 'saves.clone'
                       and Path(record['target']) == destination]
            self.assertEqual(len(records), 1)
            self.assertFalse(records[0]['target_exists'])
            transaction = records[0]['transaction_id']
            code, stdout, stderr = invoke([
                '--workspace', temporary, 'workspace', 'recovery', 'plan', transaction, '--json',
            ])
            self.assertEqual(code, 0, stderr + stdout)
            self.assertEqual(json.loads(stdout)['transactions'][0]['actions'], ['remove_owned_staging'])
            code, stdout, stderr = invoke([
                '--workspace', temporary, 'workspace', 'recovery', 'apply', transaction, '--json',
            ])
            self.assertEqual(code, 0, stderr + stdout)
            self.assertEqual(json.loads(stdout)['transactions'][0]['state'], 'rolled_back')
            self.assertFalse(destination.exists())
            self.assertEqual(list(saves.glob('.facman-save-clone-*')), [])
            code, stdout, stderr = invoke(command[1:])
            self.assertEqual(code, 0, stderr + stdout)
            receipt = json.loads(stdout)
            self.assertEqual(receipt['source_kind'], 'owned_backup')
            self.assertEqual(receipt['destination_save'], destination.name)
            self.assertEqual(destination.read_bytes(), original)
            code, stdout, stderr = invoke(command[1:])
            self.assertEqual(code, 1, stderr + stdout)
            self.assertEqual(json.loads(stdout)['refusal']['code'], 'save_clone_target_exists')
            self.assertEqual(destination.read_bytes(), original)
            self.assertEqual(hashlib.sha256(backup.read_bytes()).hexdigest(), backup_before)
            self.assertEqual(sidecar.read_bytes(), sidecar_before)
            self.assertEqual((saves / 'world.zip').read_bytes(), original)
            self.assertEqual(unrelated.read_bytes(), b'unrelated user save retained')
