"""Fresh resource admission and one reviewed produced-package retention job."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

TASK = Path(r'D:\Development\FacMan\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-w-bc5cd0812e')
E = TASK / 'evidence'
ROOT = Path(r'D:\Projects\Factorio\factorio-launcher')
PREFIX = 'world-restore-final803-retention-rx2'


def require(value, reason):
    if not value:
        raise ValueError(reason)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    with path.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


proof = E / 'world-restore-final803-retention-proof-rx2.py'
packet_path = E / (PREFIX + '-inputs.json')
review_path = E / (PREFIX + '-static.review.json')
require(sha(proof) == '9cebe67c506b4b47e433d14d3ea521ebe04b7a10cca6ca83f4a88c87dc377a3c', 'Reviewed supervisor changed')
require(sha(packet_path) == '22fde39722eb012fa7696786e55c3991d8fde98aecaff78c8bb466376b8dadf4', 'Reviewed inputs changed')
require(sha(review_path) == '0ffa8b2ab4bba9f1e7857afd1285d9092ac41d3662398da07c322f9dc4db8db9', 'Static review changed')
review = json.loads(review_path.read_text(encoding='utf-8'))
require(review['verdict'] == 'ACCEPTED_STATIC' and review['independent'] and review['non_authoring'] and not review['blockers'], 'Static acceptance differs')
packet = json.loads(packet_path.read_text(encoding='utf-8'))
require(all(sha(ROOT / rel) == digest for rel, digest in packet['source_files'].items()), 'Frozen oracle changed')
for suffix in ('.claim.json', '.json', '.private', '.admission.json', '.launch.json', '.launch.stdout', '.launch.stderr'):
    require(not (E / (PREFIX + suffix)).exists(), 'Preserve prior output; never replay')
doctor_path = E / (PREFIX + '-doctor.json')
doctor = json.loads(doctor_path.read_text(encoding='utf-8-sig'))
require(len(doctor['task_roots']) <= 8 and doctor['task_root_bytes'] <= 20 * 1024**3
        and set(doctor['violations']) <= {'unmanaged_secondary_worktrees_present', 'merged_local_task_branches_present'}, 'Aggregate budget or new hygiene issue')
require(shutil.disk_usage(E).free >= 8 * 1024**3 + 32 * 1024**2, 'External evidence reserve insufficient')
host_code = r'''[pscustomobject]@{
identity=[System.Security.Principal.WindowsIdentity]::GetCurrent().Name;
jobs=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(cmake|ninja|MSBuild|cl|wsl)\.exe$' } | Select-Object ProcessId,Name)
} | ConvertTo-Json -Compress -Depth 4'''
host = json.loads(subprocess.check_output(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', host_code],
                                         text=True, encoding='utf-8', timeout=30))
require(host['identity'] == r'BLACKGLASS-WIN1\Jules' and not host['jobs'], 'Real identity or one-job admission differs')
linux_code = '''import json,os,shutil
from pathlib import Path
jobs=[]
for p in Path('/proc').iterdir():
    if not p.name.isdigit() or int(p.name)==os.getpid(): continue
    try:
        comm=(p/'comm').read_text().strip()
        args=(p/'cmdline').read_bytes().replace(b'\\0',b' ').decode(errors='replace')
    except OSError: continue
    if comm in ('cmake','ninja','make','cc1','cc1plus','clang','clang++','g++','MSBuild') or (comm.startswith('python') and any(x in args for x in ('world-restore-final803-retention-proof','linux-rollback','linux-setup-produced803-proof','world-backup-final-linux-proof'))):
        jobs.append(dict(pid=int(p.name),comm=comm))
available=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
print(json.dumps(dict(jobs=jobs,available_memory_bytes=available,zstd=shutil.which('zstd'),unshare=shutil.which('unshare'))))
'''
linux = json.loads(subprocess.check_output(['wsl.exe', '-d', 'Ubuntu-24.04', '-u', 'root', '--', 'env',
    'PYTHONOPTIMIZE=0', 'PYTHONDONTWRITEBYTECODE=1', 'python3', '-B', '-c', linux_code],
    text=True, encoding='utf-8', timeout=30))
require(not linux['jobs'] and linux['zstd'] and linux['unshare'] and linux['available_memory_bytes'] >= 1024**3 + 128 * 1024**2,
        'Linux reserve/tool/sole-heavy-job guard failed')
marker_path = TASK / '.facman-development-root.v1.json'
marker = json.loads(marker_path.read_text(encoding='utf-8'))
require(marker['task_id'] == 'task/facman-world-restore-retention-01' and marker['owner'] == 'facman-development'
        and marker['kind'] == 'task-root' and marker['source_root'] == str(ROOT) and marker['canonical_path'] == str(TASK)
        and marker['created_at'] == '2026-09-28T15:05:35.861906Z', 'Compatible root ownership differs')
renewed = dict(marker, last_used_at=datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'))
marker_path.write_text(json.dumps(renewed, indent=2, sort_keys=True) + '\n', encoding='utf-8')
write(E / (PREFIX + '.admission.json'), dict(status='admitted_one_bounded_produced_retention_job',
    Windows_identity=host['identity'], resource_receipt_sha256=sha(doctor_path), task_roots=len(doctor['task_roots']),
    retained_bytes=doctor['task_root_bytes'], free_bytes=shutil.disk_usage(E).free, known_hygiene_violations=doctor['violations'],
    linux_probe=linux, private_tmpfs_peak_bytes=128 * 1024**2, external_evidence_budget_bytes=32 * 1024**2,
    script_sha256=sha(proof), packet_sha256=sha(packet_path), static_review_sha256=sha(review_path),
    original_marker=marker, renewed_marker=renewed, new_roots=0, builds=0, candidate_dispatches=0, whole_workunit_closed=False))
argv = ['wsl.exe', '-d', 'Ubuntu-24.04', '-u', 'root', '--', 'env', 'PYTHONOPTIMIZE=0',
        'PYTHONDONTWRITEBYTECODE=1', 'PYTHONUTF8=1', 'python3', '-B', '/mnt/d/' + str(proof)[3:].replace('\\', '/')]
with (E / (PREFIX + '.launch.stdout')).open('xb') as stdout, (E / (PREFIX + '.launch.stderr')).open('xb') as stderr:
    result = subprocess.run(argv, stdout=stdout, stderr=stderr, timeout=660, check=False,
                            creationflags=subprocess.CREATE_NO_WINDOW)
receipt = dict(exit_code=result.returncode, finished_at_utc=datetime.now(timezone.utc).isoformat(),
    stdout_sha256=sha(E / (PREFIX + '.launch.stdout')), stderr_sha256=sha(E / (PREFIX + '.launch.stderr')))
report_path = E / (PREFIX + '.json')
if report_path.exists():
    report = json.loads(report_path.read_text(encoding='utf-8'))
    receipt.update(status=report['status'], report_sha256=sha(report_path), tests_run=report.get('tests_run'),
        commands=report.get('commands'), failures=len(report.get('failures', [])), errors=len(report.get('errors', [])),
        error=report.get('error'))
else:
    receipt.update(status='FAIL', error='No terminal report; inspect retained claim and launch logs')
write(E / (PREFIX + '.launch.json'), receipt)
print(json.dumps(receipt))
raise SystemExit(result.returncode)
