"""Transcribe qualified original acceptance; never replay product campaigns."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tomllib
import zipfile

ROOT = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
UNIT = 'FACMAN-0.1-ALPHA7-WORLD-RESTORE-RETENTION-01'
BRANCH = 'task/facman-world-restore-retention-01'
BASE = '6c3c567d610c537dfe03225de7afa1fd312f0997'
SOURCE = '652e7dd9396fbef1f2f52a4a05dcdc4b51578412'
PR_BASE = 'f6076c532148078e2c558705d389f0d936814b4b'
TREE = 'e0cb2980773be432b5b826971759767e04cc747a'
NEXT = 'FACMAN-0.1-ALPHA6-SETUP-NATIVE-RECOVERY-01'
Q = ROOT/'.aide/queue/active'/UNIT
PLAN = E/'world-restore-closeout-plan.json'
REVIEW = E/'world-restore-closeout-prepare.review.json'
CLAIM = E/'world-restore-closeout.claim.json'
RECEIPT = E/'world-restore-closeout-prepared.json'
CLAUSES = [
    'Restore and import selected world bundles using validated plans, atomic visibility and recoverable journals.',
    'Test damaged sources, stale plans, live-session conflicts and retention restricted to proven owned backups.',
]
sys.path.insert(0, str(ROOT/'.aide/scripts'))
import aide_lite


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as handle:
        handle.write(json.dumps(value, indent=2)+'\n')


def update(value):
    temporary = RECEIPT.with_suffix('.json.writing')
    write(temporary, value)
    temporary.replace(RECEIPT)


def output(*args, timeout=60):
    c = subprocess.run(args, cwd=ROOT, capture_output=True, text=True,
                       encoding='utf-8', errors='replace', timeout=timeout)
    assert c.returncode == 0, (args[:4], c.returncode, c.stderr[:600])
    assert len(c.stdout.encode('utf-8')) <= 8*1024**2
    return c.stdout.strip()


def log(name, *args, timeout=600):
    with (E/('world-restore-closeout-'+name+'.log')).open('x', encoding='utf-8') as handle:
        c = subprocess.run(args, cwd=ROOT, stdout=handle, stderr=subprocess.STDOUT, timeout=timeout)
    assert c.returncode == 0, (name, c.returncode)


def integration_and_acceptance():
    integration_path = E/'world-restore-recovery-integration-03.json'
    assert sha(integration_path) == 'd7a9f4adeb24d74b81be5ee350e1862455692f96c94ca96f3e19b5eeef845ea9'
    i = json.loads(integration_path.read_text())
    assert i['status'] == 'integration_and_automatic_merge_CI_pass' and i['merge_CI_pass']
    assert i['expected_head'] == SOURCE and i['expected_base'] == PR_BASE and i['merge'] == BASE and i['PR'] == 376
    assert i['finished_at_utc'] and i['merge_requests'] == 1 and i['branch_retired']
    for name, app in i['required_contexts'].items():
        assert any(c['name'] == name and c['app']['id'] == app and c['head_sha'] == SOURCE
            and c['status'] == 'completed' and c['conclusion'] == 'success' for c in i['admitted_check_runs']), name
        if name != 'task-to-dev-promotion-check':
            assert any(c['name'] == name and c['app']['id'] == app and c['head_sha'] == BASE
                and c['status'] == 'completed' and c['conclusion'] == 'success' for c in i['merge_checks']), name
    audit_path = E/'world-restore-selected-remainder-audit.json'
    assert sha(audit_path) == 'a2770a9b95ead3533a2b209be9457f319eeb543eaba9407e6dfdf04bf8e83595'
    a = json.loads(audit_path.read_text())
    assert a['independent'] and a['non_authoring'] and a['work_item'] == UNIT and a['original_acceptance'] == CLAUSES
    assert [c['classification'] for c in a['classified_clauses']] == ['proof_exists','proof_exists']
    for k in ['behavior_missing','demonstrated_unresolved_defect','required_proof_missing']:
        assert not a['remainder_classification'][k]
    for name, digest in a['evidence_sha256'].items():
        assert sha(E/name) == digest, name
    retention_path = 'runtime/factorio/saves/flb_factorio_save_index.cpp'
    assert output('git','rev-parse','803bd98af05c7343977934a7c1b21c67ed897720:'+retention_path) == output('git','rev-parse',BASE+':'+retention_path) == a['source_binding']['retention_index_803_and_current_blob']
    p = tomllib.loads((ROOT/'release/index/plan.v1.toml').read_text())
    unit = next(u for u in p['workunit'] if u['id'] == UNIT)
    assert unit['status'] == 'active' and unit['acceptance'] == CLAUSES
    assert next(u for u in p['workunit'] if u['id'] == unit['depends_on'][0])['status'] == 'complete'
    next_unit = next(u for u in p['workunit'] if u['id'] == NEXT)
    assert next_unit['status'] == 'active'
    assert all(next(u for u in p['workunit'] if u['id'] == dep)['status'] == 'complete' for dep in next_unit['depends_on'])
    proof = json.loads((Q/'evidence/prepublication-recovery.v1.json').read_text())
    produced = proof['produced_linux_repair']
    assert produced['producer_head'] == PR_BASE and produced['candidate_run'] == 37204014296
    assert produced['tests'] == 3 and produced['commands'] == 21 and not produced['failures'] and not produced['errors'] and not produced['skips']
    for path, oid in produced['source_package_inputs'].items():
        assert output('git','rev-parse',BASE+':'+path) == oid, path
    for section in ['native_windows_repair','produced_linux_repair']:
        item = proof[section]
        assert sha(ROOT/item['custody']) == item['custody_sha256'], section
    return i, a, unit, proof


def live_binding():
    assert output('git','branch','--show-current') == 'dev'
    assert output('git','rev-parse','HEAD') == output('git','rev-parse','origin/dev') == BASE
    assert output('git','rev-parse','HEAD^{tree}') == TREE
    assert output('git','show','-s','--format=%P',BASE).split() == [PR_BASE,SOURCE]
    assert not output('git','status','--porcelain')
    marker = json.loads((E.parent/'.facman-development-root.v1.json').read_text())
    assert Path(marker['canonical_path']).samefile(E.parent) and marker['task_id'] == BRANCH
    assert output('powershell','-NoProfile','-Command','[System.Security.Principal.WindowsIdentity]::GetCurrent().Name') == 'BLACKGLASS-WIN1\\Jules'
    c = subprocess.run(['gh','auth','status'],cwd=ROOT,capture_output=True,timeout=60)
    assert c.returncode == 0, 'Real-user authentication check failed; credential output not stored'
    assert output('gh','api','user','--jq','.login') == 'Julesc013'
    assert output('gh','api','repos/Julesc013/factorio-launcher/git/ref/heads/dev','--jq','.object.sha') == BASE
    assert not output('git','ls-remote','--heads','origin','refs/heads/'+BRANCH)
    assert subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/'+BRANCH],cwd=ROOT).returncode == 1
    assert shutil.disk_usage(E).free >= 8*1024**3 + 32*1024**2


def prepare():
    assert not PLAN.exists() and not CLAIM.exists() and not RECEIPT.exists()
    live_binding()
    i,a,unit,proof = integration_and_acceptance()
    for name, extra in [('paths',[]),('doctor',['--measure'])]:
        c = subprocess.run([sys.executable,'-B','tools/workspace_hygiene.py',name,*extra],cwd=ROOT,
            capture_output=True,text=True,encoding='utf-8',timeout=120)
        data = json.loads(c.stdout)
        write(E/('world-restore-closeout-'+name+'.json'),data)
        if name == 'doctor':
            assert c.returncode in {0,1} and set(data['violations']) <= {'unmanaged_secondary_worktrees_present','merged_local_task_branches_present'}
            assert len(data['task_roots']) <= 8 and data['task_root_bytes'] + 32*1024**2 <= 20*1024**3
        else:
            assert c.returncode == 0
    for op in ['inspect','noop-check','recover']:
        log('task-'+op,sys.executable,'-B','.aide/scripts/aide_lite.py','task',op,'--task-id',UNIT)
    for op in ['policy','detect','plan']:
        log('git-'+op,sys.executable,'-B','.aide/scripts/aide_lite.py','git',op)
    helper = aide_lite.make_git_helper_plan(ROOT,'plan')
    assert helper['status'] == 'ready_dry_run' and not helper['blockers']
    names = ['world-restore-selected-remainder-audit.json','world-restore-recovery-integration-03.json',
        'world-restore-recovery-integration-03.py','world-restore-recovery-integration-03-plan.json',
        'world-restore-recovery-integration-03.review.json','world-restore-recovery-integration-03-history.json',
        'world-restore-recovery-integration-03-admission-trusted-publisher.json',
        'world-restore-recovery-integration-03-admission-trusted-publisher.log',
        'world-restore-recovery-integration-03-admission-producer-jobs.json',
        'world-restore-recovery-integration-03-admission-trusted-status.zip',*a['evidence_sha256']]
    inputs = ['release/index/plan.v1.toml','.aide/queue/index.yaml',
        (Q/'task.yaml').relative_to(ROOT).as_posix(),(Q/'status.yaml').relative_to(ROOT).as_posix(),
        (Q/'ExecPlan.md').relative_to(ROOT).as_posix(),(Q/'evidence/prepublication-recovery.v1.json').relative_to(ROOT).as_posix()]
    write(PLAN,dict(schema='facman.exact-base-task-branch-plan.v1',status='qualified_original_acceptance_closeout_prepared',
        work_item=UNIT,branch=BRANCH,start_commit=BASE,source_head=SOURCE,source_tree=TREE,
        helper_plan=helper,planned_command=['git','switch','--no-track','-c',BRANCH,BASE],
        operator_authority='User compact restart explicitly authorizes classified ordinary task edits/commits/pushes/qualified dev integration; same owned WorkUnit/root, exact latest dev; no release/provider control authority',
        script_sha256=sha(Path(__file__)),original_acceptance=CLAUSES,primary_after_closeout=NEXT,
        canonical_input_hashes={p:sha(ROOT/p) for p in inputs},evidence_pins={n:sha(E/n) for n in names},
        new_roots=0,new_worktrees=0,builds=0,candidate_dispatches=0,CI_reruns=0,prepared_at_utc=now()))
    print(json.dumps(dict(status='prepared_for_independent_review',plan_sha256=sha(PLAN),script_sha256=sha(Path(__file__)))))


def apply():
    plan = json.loads(PLAN.read_text()); review = json.loads(REVIEW.read_text())
    assert not CLAIM.exists() and not RECEIPT.exists()
    assert plan['script_sha256'] == sha(Path(__file__))
    assert review['verdict'] == 'PASS' and review['independent'] and review['non_authoring']
    assert review['script_sha256'] == sha(Path(__file__)) and review['plan_sha256'] == sha(PLAN)
    assert review['original_acceptance'] == CLAUSES and review['closure_supported_after_exact_integration_and_merge_CI']
    live_binding()
    i,a,unit,proof = integration_and_acceptance()
    for p,digest in plan['canonical_input_hashes'].items(): assert sha(ROOT/p) == digest,p
    for n,digest in plan['evidence_pins'].items(): assert sha(E/n) == digest,n
    write(CLAIM,dict(PID=os.getpid(),created_at_utc=now(),plan_sha256=sha(PLAN),script_sha256=sha(Path(__file__)),review_sha256=sha(REVIEW),recovery='Never replay a partial transition; inspect exact retained source/task state'))
    record = dict(status='branch_create_issued',base=BASE,branch=BRANCH,started_at_utc=now(),new_roots=0,new_worktrees=0,builds=0,candidate_dispatches=0,model_wait_calls=0)
    update(record)
    try:
        log('branch-create',*plan['planned_command'])
        assert output('git','branch','--show-current') == BRANCH and output('git','rev-parse','HEAD') == BASE
        names = list(plan['evidence_pins'])+['world-restore-closeout.py','world-restore-closeout-plan.json','world-restore-closeout-prepare.review.json']
        archive = Q/'evidence/integration-validation-custody.zip'
        digests = {n:sha(E/n) for n in names}
        with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
            for n in names: z.write(E/n,n)
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None and len(z.infolist()) == len(digests) and set(z.namelist()) == set(digests)
            for n,digest in digests.items(): assert hashlib.sha256(z.read(n)).hexdigest() == digest
        receipt = dict(schema='facman.exact_checked_integration.v1',status='world_restore_original_machine_acceptance_transcribed_for_review',
            work_item=UNIT,PR=376,PR_url='https://github.com/Julesc013/factorio-launcher/pull/376',expected_head=SOURCE,expected_base=PR_BASE,
            source_tree=TREE,merge=BASE,merge_tree=TREE,parents=[PR_BASE,SOURCE],merge_method='normal protected merge commit',merged_at=i['merged_at'],
            required_contexts=i['required_contexts'],required_checks=[dict(name=c['name'],id=c['id'],url=c['html_url'],conclusion=c['conclusion'],publisher_app_id=c['app']['id']) for c in i['admitted_check_runs'] if c['name'] in i['required_contexts']],
            automatic_merge_CI=dict(status=i['status'],qualified=True,dispatches=0,checks=[dict(name=c['name'],id=c['id'],url=c['html_url'],conclusion=c['conclusion']) for c in i['merge_checks'] if c['name'] in i['required_contexts']]),
            acceptance=[dict(criterion=c,status='PASS',evidence=a['classified_clauses'][n]['evidence']) for n,c in enumerate(CLAUSES)],
            custody=dict(path=archive.relative_to(ROOT).as_posix(),sha256=sha(archive),members=digests),
            produced_package_scope=proof['produced_linux_repair'],retention_scope=proof['retention'],
            qualification=dict(original_machine_clauses=True,actual_Factorio=False,human=False,physical_host=False,release=False,umbrella=False),
            historical_failures_preserved=True,canonical_closeout_commit_review_and_normal_integration_pending=True,full_programme_complete=False,
            separate_open_gates=['PR343 owner-only exact-head control authorization','F10/content-world ordinary-flow umbrella','Approved real-game/host and human qualification','Beta/RC/final delivery and publication'],recorded_at_utc=now())
        write(Q/'evidence/integration-closeout.v1.json',receipt)
        # These generator outputs are the only scope extension; no product/control paths.
        task = Q/'task.yaml'; text = task.read_text()
        assert '  - "release/index/project_status.v2.toml"' not in text
        text = text.replace('  - "release/index/current_state.v1.toml"','  - "release/index/current_state.v1.toml"\n  - "release/index/project_status.v2.toml"')
        task.write_text(text,encoding='utf-8',newline='\n')
        for op in ['verify','review','close']:
            args = [sys.executable,'-B','.aide/scripts/aide_lite.py','task',op,'--task-id',UNIT]
            if op == 'verify': args += ['--result','PASS']
            log('lifecycle-'+op,*args)
        for path in [Q/'task.yaml',Q/'status.yaml',ROOT/'.aide/queue/index.yaml']:
            path.write_text(path.read_text(),encoding='utf-8',newline='\n')
        path = Q/'status.yaml'
        path.write_text(path.read_text()+'\nreview_state: independent_original_source_runtime_acceptance_passed\nqualification_state: original_machine_clauses_and_required_checks_passed\nintegration_state: merged_to_dev\nintegration_receipt: '+(Q/'evidence/integration-closeout.v1.json').relative_to(ROOT).as_posix()+'\n',encoding='utf-8',newline='\n')
        path = ROOT/'release/index/plan.v1.toml'; text = path.read_text()
        start = text.index('id = "'+UNIT+'"'); end = text.index('\n[[workunit]]',start); block = text[start:end]
        assert block.count('status = "active"') == 1
        block = block.replace('status = "active"','status = "complete"')
        old = 'evidence = ["'+(Q/'evidence/prepublication-recovery.v1.json').relative_to(ROOT).as_posix()+'"]'
        assert block.count(old) == 1
        block = block.replace(old,'evidence = ['+', '.join('"'+(Q/'evidence'/n).relative_to(ROOT).as_posix()+'"' for n in ['integration-closeout.v1.json','prepublication-recovery.v1.json','integration-validation-custody.zip'])+']')
        text = text[:start]+block+text[end:]
        primary = 'primary_workunit = "'+UNIT+'"'; assert text.count(primary) == 1
        path.write_text(text.replace(primary,'primary_workunit = "'+NEXT+'"'),encoding='utf-8',newline='\n')
        parsed = tomllib.loads(path.read_text()); closed = next(u for u in parsed['workunit'] if u['id'] == UNIT)
        assert closed['acceptance'] == unit['acceptance'] and closed['depends_on'] == unit['depends_on'] and closed['epic'] == unit['epic']
        path = Q/'ExecPlan.md'
        path.write_text(path.read_text()+'\n2026-10-05: PR376 integrated as6c3c567 with all required automatic merge\nchecks. Independent original-clause audit found no missing behavior,\nunresolved defect or required proof gap within this machine WorkUnit. Both\nunchanged clauses are transcribed in integration-closeout.v1.json; exact\nsource/product/runtime reviews and checked integration are in validation\ncustody. Canonical/task closure is prepared for independent commit review\nand normal integration. Earlier803 restore FAIL and Windows strict-skip\nFAIL remain unchanged. Broader F10/content-world interfaces, real game/host,\nhuman and release qualification remain separate open outcomes. No new\ncandidate, native build, root, worktree or owner-control action was issued.\n',encoding='utf-8',newline='\n')
        for name,args in [('plan-generate',['tools/generate_plan_views.py']),('state-generate',['tools/project_state.py','--write']),
            ('plan-check',['tools/generate_plan_views.py','--check']),('state-check',['tools/project_state.py','--validate']),
            ('state-tests',['-m','unittest','tests.test_plan_views','tests.test_current_truth_roles','tests.test_aide_target_truth','tests.test_aide_compaction']),
            ('strict',['tools/strict_check.py']),('format',['tools/source_format_check.py']),('portable',['.aide/scripts/aide_lite.py','test'])]:
            log(name,sys.executable,'-B',*args)
        log('diff','git','diff','--check')
        changed = sorted(set(output('git','diff','--name-only').splitlines()+output('git','ls-files','--others','--exclude-standard').splitlines()))
        assert all(p.startswith(('.aide/memory/project-state','release/index/','.aide/queue/active/'+UNIT+'/')) or p in {'.aide/queue/index.yaml','README.md','todo.md','docs/roadmap/current.md','docs/roadmap.md','docs/platform/support_matrix.md','docs/release/checkpoints/README.md'} for p in changed),changed
        assert not aide_lite.protected_control_paths([{'filename':p} for p in changed])
        record.update(status='canonical_closeout_source_prepared_validated_review_pending',changed_paths=changed,changed_path_hashes={p:sha(ROOT/p) for p in changed},commit_push_merge_issued=False,full_programme_complete=False)
    except BaseException as exc:
        record.update(status='canonical_closeout_stopped_for_actionable_review',error=repr(exc),next_action='Inspect retained exact operation/source state; never delete work or replay a partial transition')
    record['finished_at_utc'] = now(); update(record)
    print(json.dumps({k:record.get(k) for k in ['status','base','branch','changed_paths','error','finished_at_utc']}))


if __name__ == '__main__':
    if not __debug__ or os.environ.get('PYTHONOPTIMIZE') != '0' or os.environ.get('PYTHONDONTWRITEBYTECODE') != '1':
        raise RuntimeError('Assertions must be enabled and bytecode disabled')
    parser = argparse.ArgumentParser(); group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--prepare',action='store_true'); group.add_argument('--apply',action='store_true')
    args = parser.parse_args(); prepare() if args.prepare else apply()
