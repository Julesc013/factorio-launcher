# SPDX-FileCopyrightText: 2026 Jules C
# SPDX-License-Identifier: MIT

from __future__ import annotations

import json
import os
import subprocess
import unittest
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


@lru_cache(maxsize=16)
def _discover_facman_executable(root: Path, explicit: str) -> Path:
    if explicit:
        path = Path(explicit)
        if path.is_file():
            return path
        raise AssertionError(f"FACMAN_CLI_EXE does not point to a file: {path}")

    preferred = [
        root / "build" / "native-smoke" / "Debug" / "facman.exe",
        root / "build" / "native-smoke" / "facman",
        root / "build" / "Debug" / "facman.exe",
    ]
    candidates: list[Path] = []
    for pattern in ("build/**/facman.exe", "build/**/facman"):
        candidates.extend(
            path
            for path in root.glob(pattern)
            if path.is_file()
            and ".install" not in path.parts
            and path.parent.name.lower() not in {"bin", "sbin"}
        )
    if candidates:
        ranks = {path: index for index, path in enumerate(preferred)}
        unique = set(candidates)
        return max(
            unique,
            key=lambda path: (path.stat().st_mtime_ns, -ranks.get(path, len(preferred))),
        )

    raise unittest.SkipTest("native facman executable has not been built")


def facman_executable() -> Path:
    # Raw unittest discovery does not rebuild the native CLI. Cache the bounded
    # selection for the process so each CLI-backed case does not recursively
    # rescan a potentially large historical build tree.
    return _discover_facman_executable(ROOT, os.environ.get("FACMAN_CLI_EXE", ""))


def invoke_machine(args: list[str], env: dict[str, str] | None = None) -> tuple[int, str, str]:
    completed = subprocess.run(
        [str(facman_executable()), *args],
        cwd=ROOT,
        check=False,
        encoding="utf-8",
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    return completed.returncode, completed.stdout, completed.stderr


def invoke(args: list[str], env: dict[str, str] | None = None) -> tuple[int, str, str]:
    """Project the normative machine envelope to its payload for product tests.

    Product-semantic tests predate the CLI envelope and intentionally validate
    payload schemas. Output-law tests use invoke_machine() and validate the
    actual process boundary without this projection.
    """
    code, stdout, stderr = invoke_machine(args, env=env)
    if "--json" not in args or not stdout.strip():
        return code, stdout, stderr
    document = json.loads(stdout)
    if document.get("schema") != "facman.transport_response.v2":
        return code, stdout, stderr
    payload = document.get("payload")
    if payload is None and document.get("error") is not None:
        error = document["error"]
        payload = {
            "schema": "facman.client_refusal.v1",
            "status": "refused",
            "refusal": {
                "code": error.get("code", "client_failure"),
                "reason": error.get("message", "Command failed"),
            },
        }
    return code, json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n", stderr
