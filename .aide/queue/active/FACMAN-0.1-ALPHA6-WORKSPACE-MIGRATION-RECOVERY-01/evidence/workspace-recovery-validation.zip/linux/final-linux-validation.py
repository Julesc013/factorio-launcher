from pathlib import Path
import os,subprocess,json,hashlib,tempfile
root=Path(__file__).resolve().parent
source=Path('/mnt/c/Users/Jules/AppData/Local/FacMan/Development/repositories/factorio-launcher-5db2844e2f29/worktrees/task-facman-workspace-package-recovery-01')
paths=['.github/workflows/product-candidate.yml','contracts/policy/test_impact.v1.json','docs/architecture/workspace-lifecycle-contract.v2.md','runtime/workspace/fl_workspace_migration_recovery.cpp','tests/test_workspace_recovery_refusals.py','tests/test_product_candidate_workflow.py','tools/workspace_lifecycle_package_proof.py']
for rel in paths:(root/'facman'/rel).write_bytes((source/rel).read_bytes())
hashes={rel:hashlib.sha256((source/rel).read_bytes()).hexdigest() for rel in paths}
tmp=Path(tempfile.mkdtemp(prefix='facman-owned-workspace-final-')).resolve(strict=True)
assert tmp.parent==Path('/tmp')
owner={'work_item':'FACMAN-0.1-ALPHA6-WORKSPACE-MIGRATION-RECOVERY-01','root':str(tmp),'controller_root':str(root),'purpose':'synthetic final validation; retained'}
(tmp/'.facman-diagnostic-owner.json').write_text(json.dumps(owner)+'\n')
(root/'final-ext4-owner.json').write_text(json.dumps(owner,indent=2)+'\n')
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(root/'facman/tests'),FACMAN_CLI_EXE=str(root/'native/facman'),TMPDIR=str(tmp),FLAUNCH_UNIVERSAL_LAUNCHER_ROOT=str(root/'universal-launcher'),FLAUNCH_UNIVERSAL_SETUP_ROOT=str(root/'universal-setup'))
commands=[('final-fixed-build',['cmake','--build',str(root/'native'),'--parallel','4','--target','facman','fl_workspace_store_smoke']),('final-native-workspace-smoke',[str(root/'native/fl_workspace_store_smoke')]),('final-native-python-regressions',[str(root/'python/bin/python'),'-B','-m','unittest','tests.test_workspace_store','tests.test_workspace_recovery_refusals','tests.test_workspace_lifecycle_characterization','tests.test_workspace_lifecycle_contracts','tests.test_recovery','-v']),('final-lifecycle-diagnostic',[str(root/'python/bin/python'),'-B','tools/workspace_lifecycle_package_proof.py','--executable',str(root/'native/facman'),'--profile','linux_product_x64','--package-mode','portable','--evidence',str(root/'final-lifecycle-diagnostic.json')])]
results={}
for label,cmd in commands:
 with (root/(label+'.txt')).open('w',encoding='utf-8') as out:
  result=subprocess.run(cmd,cwd=root/'facman',env=env,stdout=out,stderr=subprocess.STDOUT,timeout=600)
 results[label]={'exit_code':result.returncode,'sha256':hashlib.sha256((root/(label+'.txt')).read_bytes()).hexdigest()}
 print(label,result.returncode,flush=True)
 if result.returncode:break
assert hashes=={rel:hashlib.sha256((source/rel).read_bytes()).hexdigest() for rel in paths}
receipt={'source_files':hashes,'results':results,'diagnostic_only':True,'exact_package_qualification':False,'source_base':'37f7c542d18d27af7daa03c505e1574260fa52cc','source_dirty':True,'binary_sha256':hashlib.sha256((root/'native/facman').read_bytes()).hexdigest()}
(root/'final-linux-validation.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
raise SystemExit(result.returncode)