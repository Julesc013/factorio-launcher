from pathlib import Path
import os,sys,subprocess,json,hashlib
root=Path(__file__).resolve().parent
source=Path('/mnt/c/Users/Jules/AppData/Local/FacMan/Development/repositories/factorio-launcher-5db2844e2f29/worktrees/task-facman-workspace-package-recovery-01')
import tempfile
tmp=Path(tempfile.mkdtemp(prefix='facman-owned-workspace-regression-')).resolve(strict=True)
assert tmp.parent==Path('/tmp')
owner={'work_item':'FACMAN-0.1-ALPHA6-WORKSPACE-MIGRATION-RECOVERY-01','root':str(tmp),'controller_root':str(root),'purpose':'synthetic regression; retained'}
(tmp/'.facman-diagnostic-owner.json').write_text(json.dumps(owner)+'\n')
(root/'regression-ext4-owner.json').write_text(json.dumps(owner,indent=2)+'\n')
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(root/'facman/tests'),FACMAN_CLI_EXE=str(root/'native/facman'),TMPDIR=str(tmp))
command=[sys.executable,'-B','-m','unittest','tests.test_workspace_recovery_refusals','-v']
with (root/'new-regression-before-fix.txt').open('w',encoding='utf-8') as output:
 result=subprocess.run(command,cwd=root/'facman',env=env,stdout=output,stderr=subprocess.STDOUT,timeout=180)
print('before-fix',result.returncode,flush=True)
assert result.returncode==1
for relative in ('runtime/workspace/fl_workspace_migration_recovery.cpp','tools/workspace_lifecycle_package_proof.py'):
 (root/'facman'/relative).write_bytes((source/relative).read_bytes())
with (root/'rebuild-fixed.txt').open('w',encoding='utf-8') as output:
 result=subprocess.run(['cmake','--build',str(root/'native'),'--parallel','4','--target','facman','fl_workspace_store_smoke'],cwd=root/'facman',env=env,stdout=output,stderr=subprocess.STDOUT,timeout=900)
print('fixed-build',result.returncode,flush=True)
assert result.returncode==0
with (root/'new-regression-after-fix.txt').open('w',encoding='utf-8') as output:
 result=subprocess.run(command,cwd=root/'facman',env=env,stdout=output,stderr=subprocess.STDOUT,timeout=180)
print('after-fix',result.returncode,flush=True)
assert result.returncode==0
sys.path.insert(0,str(root/'facman'))
from tools import workspace_lifecycle_package_proof as proof
os.environ['TMPDIR']=str(tmp)
import tempfile
tempfile.tempdir=None
result=proof.prove(root/'native/facman','linux_product_x64','portable')
result['diagnostic_only']=True
result['package_qualification']=False
(root/'fixed-full-lifecycle-diagnostic.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print('all11-lifecycle-cases PASS diagnostic-only',flush=True)
with (root/'native-workspace-smoke.txt').open('w',encoding='utf-8') as output:
 result=subprocess.run([str(root/'native/fl_workspace_store_smoke')],cwd=tmp,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=180)
print('workspace-native-smoke',result.returncode,flush=True)
raise SystemExit(result.returncode)
