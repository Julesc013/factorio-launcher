from pathlib import Path
import json,os,sys,traceback
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'facman'))
from tools import workspace_lifecycle_package_proof as proof
os.environ['PYTHONDONTWRITEBYTECODE']='1'
case_root=root/'damaged-backup-reproduction'
case_root.mkdir(exist_ok=False)
cwd=case_root/'cwd'
cwd.mkdir()
class Capture(proof.Driver):
 def raw(self,arguments,**kwargs):
  result=super().raw(arguments,**kwargs)
  with (case_root/'commands.jsonl').open('a',encoding='utf-8') as log:
   log.write(json.dumps({'argv':arguments,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr})+'\n')
  return result
try:
 proof.prove_idempotency_and_backup_conflicts(Capture(root/'native/facman',cwd),case_root)
except Exception:
 traceback.print_exc()
 raise