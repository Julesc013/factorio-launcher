from pathlib import Path
import json,os,sys,traceback,tempfile,subprocess
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'facman'))
from tools import workspace_lifecycle_package_proof as proof
case_root=Path(tempfile.mkdtemp(prefix='facman-owned-workspace-recovery-')).resolve(strict=True)
assert case_root.parent==Path('/tmp') and case_root.name.startswith('facman-owned-workspace-recovery-')
owner={'work_item':'FACMAN-0.1-ALPHA6-WORKSPACE-MIGRATION-RECOVERY-01','root':str(case_root),'controller_root':str(root),'purpose':'synthetic ext4 diagnostic only','cleanup':'retain; exact owner and containment verification required before removal'}
(case_root/'.facman-diagnostic-owner.json').write_text(json.dumps(owner,indent=2)+'\n',encoding='utf-8')
(root/'ext4-reproduction-owner.json').write_text(json.dumps(owner,indent=2)+'\n',encoding='utf-8')
cwd=case_root/'cwd'
cwd.mkdir()
class Capture(proof.Driver):
 def raw(self,arguments,**kwargs):
  result=subprocess.run([str(self.executable),*arguments],cwd=self.cwd,env=kwargs.get('environment'),capture_output=True,text=True,encoding='utf-8')
  with (root/'ext4-reproduction-commands.jsonl').open('a',encoding='utf-8') as log:
   log.write(json.dumps({'argv':arguments,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr})+'\n')
  if result.returncode!=kwargs.get('expected',0):
   raise ValueError(f'unexpected return {result.returncode}: {result.stdout}')
  return result
try:
 proof.prove_idempotency_and_backup_conflicts(Capture(root/'native/facman',cwd),case_root)
except Exception:
 (root/'ext4-reproduction-failure.txt').write_text(traceback.format_exc(),encoding='utf-8')
 print(traceback.format_exc())
 rows=(root/'ext4-reproduction-commands.jsonl').read_text().splitlines()
 print(json.dumps(json.loads(json.loads(rows[-1])['stdout']),indent=2))
 raise SystemExit(1)