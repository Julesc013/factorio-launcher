using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using FacMan.WinForms;
class Geometry {
 static T Field<T>(object f,string n) where T:class {return typeof(C1ShellForm).GetField(n,BindingFlags.NonPublic|BindingFlags.Instance).GetValue(f) as T;}
 [STAThread] static int Main(string[] args) {
  Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
  var rows=new List<object>();
  foreach(float scale in new[]{1F,1.25F,1.5F,2F}) foreach(Size maximum in new[]{Size.Empty,new Size(1024,768),new Size(1280,720),new Size(960,640)}) {
   using(var form=new C1ShellForm(C1GallerySession.Parse(File.ReadAllText(args[0])))) {
    form.Show(); form.Scale(new SizeF(scale,scale)); form.Size=form.MinimumSize;
    if(!maximum.IsEmpty) {form.MaximumSize=maximum; form.Size=maximum;}
    form.PerformLayout(); Application.DoEvents();
    var button=Field<Button>(form,"primaryAction");button.Focus();Application.DoEvents();
    Rectangle bounds=button.RectangleToScreen(button.ClientRectangle),visible=bounds;
    var ancestors=new List<object>();
    for(Control p=button.Parent;p!=null;p=p.Parent){var b=p.RectangleToScreen(p.ClientRectangle);visible=Rectangle.Intersect(visible,b);ancestors.Add(new {kind=p.GetType().Name,name=p.AccessibleName,bounds=b,visible=visible});}
    bool reachable=visible.Width>=Math.Min(16,bounds.Width)&&visible.Height>=Math.Min(16,bounds.Height);
    rows.Add(new {scale=scale,maximum=maximum,size=form.Size,minimum=form.MinimumSize,font=form.Font.ToString(),dpi=form.CreateGraphics().DpiX,screen=Screen.FromControl(form).WorkingArea,bounds=bounds,visible=visible,reachable=reachable,ancestors=ancestors});
    Console.WriteLine("scale="+scale+" max="+maximum+" size="+form.Size+" visible="+visible+" reachable="+reachable);
    if(!reachable)using(var image=new Bitmap(form.Width,form.Height)){form.DrawToBitmap(image,new Rectangle(Point.Empty,form.Size));image.Save(Path.Combine(args[1],"clipped-"+scale+"-"+maximum.Width+"x"+maximum.Height+".png"));}
    form.Close();
   }
  }
  File.WriteAllText(Path.Combine(args[1],"geometry.json"),new JavaScriptSerializer().Serialize(rows));return 0;
 }
}
