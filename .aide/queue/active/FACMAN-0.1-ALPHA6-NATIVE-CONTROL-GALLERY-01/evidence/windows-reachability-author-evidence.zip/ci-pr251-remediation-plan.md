# PR251 Windows gallery reachability remediation

Exact source HEAD5b347dd7bea70c82fc07a7a27ff7a9de50aad3cc, treeca4d788227b4b7bb693d055fed14a6895a938fd5. Parent authorizes bounded gallery runner/WinForms/test remediation; no index, branch or remote changes. Current worktree is clean and measured hygiene passes.

Fresh run34045701748/job101520241965 fails blocked/baseline125% with InvalidOperationException: control must remain reachable: Play. The complete retained log SHA256 is1a18a4b46ae00a4838c33d899d40c20ba33f3e0eabef2c71ed0a56c5e6c76073. Exactly one Python error among1584 tests; later composition upload lacks skipped prerequisite output.

1. Diagnose geometry of the actual production C1ShellForm from the unchanged qualified assembly using recorder-only fixtures and constraints on only the test form; change no desktop settings or live transport.
2. Capture a local red case and exact clipped ancestor. Repair only the production layout responsible, and add the smallest deterministic native regression and useful context in failure diagnostics. Preserve reachability/keyboard/action/no-effect oracles.
3. Build within this owned gallery task root, run focused source and actual-control regressions, inspect exact source diff and obtain independent review before any checkpoint. Fresh hosted Windows qualification remains required.
