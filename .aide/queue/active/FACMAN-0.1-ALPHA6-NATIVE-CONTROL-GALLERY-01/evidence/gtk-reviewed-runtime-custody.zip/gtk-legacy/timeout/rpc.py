#!/usr/bin/env python3
import os
import pathlib
import subprocess
import time
child = subprocess.Popen(["sleep", "300"])
pathlib.Path(os.environ["FACMAN_PREVIEW_CHILD_PID_FILE"]).write_text(str(child.pid), encoding="utf-8")
time.sleep(300)
