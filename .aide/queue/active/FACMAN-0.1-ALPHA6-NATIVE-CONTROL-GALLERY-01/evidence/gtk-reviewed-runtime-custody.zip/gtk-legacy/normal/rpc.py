#!/usr/bin/env python3
import json
import os
import pathlib
import sys
import time
request = json.load(sys.stdin)
required = ("request_id", "operation_id", "attempt_id", "command")
if request.get("schema") != "facman.transport_request.v2" or request.get("protocol_version") != 2:
    raise SystemExit("fixture requires a FacMan v2 transport request")
if any(not isinstance(request.get(key), str) or not request[key] for key in required):
    raise SystemExit("fixture requires complete request correlation identity")
release = os.environ.get("FACMAN_PREVIEW_ATSPI_RELEASE_FILE")
if release:
    deadline = time.monotonic() + 20
    while not pathlib.Path(release).is_file() and time.monotonic() < deadline:
        time.sleep(0.05)
    if not pathlib.Path(release).is_file():
        raise SystemExit("external AT-SPI probe did not release the RPC fixture")
response = {
    "schema": "facman.transport_response.v2",
    "protocol_version": 2,
    "request_id": request["request_id"],
    "command": request["command"],
    "outcome": "ok",
    "payload": {"product_id": "factorio"},
    "error": None,
    "diagnostics": [],
    "effects": [],
    "operation": {
        "schema": "ulk.operation_outcome.v1",
        "operation_id": request["operation_id"],
        "attempt_id": request["attempt_id"],
        "outcome": "completed",
        "effects_may_have_occurred": False,
        "recovery": {"required": False, "transaction_id": "", "inspect_command": ""},
    },
}
print(json.dumps(response, separators=(",", ":")))
