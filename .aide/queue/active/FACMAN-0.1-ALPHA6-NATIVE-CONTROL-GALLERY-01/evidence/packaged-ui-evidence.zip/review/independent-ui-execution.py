from pathlib import Path
import hashlib,json,os,struct,subprocess,time,zipfile
REPO=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\worktrees\task-facman-resource-identity-01')
TASK=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-d9fce3b03d')
E=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-0-36077e5ebb\evidence\package-97e\source-remediation')
PY=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\beta1-admissi-68051e628e\python\Scripts\python.exe')
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def record(p):
    b=p.read_bytes()
    return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def emit(name,value):
    p=E/name
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n')
    return record(p)
mraw=(E/'frozen-source.json').read_bytes()
assert sha(mraw)=='fb86be9cd606ca0f6dcc00b0c6e5d777683e05a88bff32e32737551813ea57d4'
m=json.loads(mraw)
before={'head':git('rev-parse','HEAD').decode().strip(),'index_tree':git('write-tree').decode().strip() if False else git('diff','--cached','--binary','--full-index').decode(),'status':git('status','--porcelain=v1').decode()}
assert before['head']==m['base_commit']
assert before['index_tree']==''
rows=[]
source_bytes={}
for r in m['source_files']:
    b=(REPO/r['path']).read_bytes();source_bytes[r['path']]=b
    assert len(b)==r['bytes'] and sha(b)==r['sha256'],r['path']
    normalized=b.replace(b'\r\n',b'\n')
    blob=hashlib.sha1(b'blob '+str(len(normalized)).encode()+b'\0'+normalized).hexdigest()
    assert blob==r['git_blob'],r['path']
    rows.append({**r,'crlf_pairs':b.count(b'\r\n'),'git_projection':'explicit CRLF-to-LF normalization; no filters invoked'})
changed=git('diff','--name-only','-z').decode().split('\0')
assert set(filter(None,changed))==set(source_bytes)
patch=(E/'frozen-source.patch').read_bytes()
assert sha(patch)==m['patch_sha256']
patch_definitions=[]
for flags in [('--binary','--full-index','--no-ext-diff'),('--binary','--no-ext-diff'),('--binary',)]:
    actual=git('diff',*flags,'--',*source_bytes)
    if actual==patch:patch_definitions.append(['git','diff',*flags,'--','<five exact sorted source paths>'])
assert patch_definitions,'transport bytes differ from complete current diff'
author_validation=json.loads((E/'focused-validation-v2.json').read_bytes())
assert sha((E/'focused-validation-v2.json').read_bytes())==m['validation_sha256']
for c in author_validation['checks']:
    assert c['exit']==0
    assert sha((E/c['log']).read_bytes())==c['sha256']
old_find=E.parent/'packaged-ui-substitution-finding.json'
assert sha(old_find.read_bytes())==m['original_package_finding_sha256']
old_files=[]
for r in json.loads(old_find.read_bytes())['observed_files']:
    actual=record(Path(r['path']))
    assert actual==r,(actual,r)
    old_files.append(actual)
def pe(raw):
    assert raw[:2]==b'MZ'
    p=struct.unpack_from('<I',raw,0x3c)[0];assert raw[p:p+4]==b'PE\0\0'
    o=p+24;magic=struct.unpack_from('<H',raw,o)[0];assert magic==0x20b
    dd=o+112;rva,n=struct.unpack_from('<II',raw,dd+14*8)
    return {'bytes':len(raw),'sha256':sha(raw),'pe_optional_header_magic':hex(magic),'clr_runtime_header_rva':rva,'clr_runtime_header_bytes':n}
asset=TASK/'dist-p3/FacMan-0.1.0-alpha.5-windows-x64-portable.zip'
asset_record=record(asset);assert asset_record['sha256']=='194f4e914ae13ce24f6825714a72f1581165316bc62522a4241b7fab554f9f3b'
with zipfile.ZipFile(asset) as z:
    zip_pe={n:pe(z.read(n)) for n in z.namelist() if n.lower().endswith('.exe')}
assert set(zip_pe)=={'FacMan.exe','bin/facman.exe'}
assert zip_pe['FacMan.exe']==zip_pe['bin/facman.exe']
assert zip_pe['FacMan.exe']['clr_runtime_header_rva']==0
stage=TASK/'packages-p3/.install/windows_product_x64'
correct=pe((stage/'FacMan.exe').read_bytes())
assert correct==pe((TASK/'winforms-product/Release/FacMan.exe').read_bytes())
assert correct['clr_runtime_header_rva']==8192 and correct['clr_runtime_header_bytes']==72
assert correct['sha256']!=zip_pe['FacMan.exe']['sha256']
# Calling the corrected production resolver is read-only and binds real staging bytes.
import sys
sys.path.insert(0,str(REPO))
from tools.package import components
selected=components.resolve(stage,'apps/gui/windows/winforms',destination='FacMan.exe')
assert selected==stage/'FacMan.exe' and pe(selected.read_bytes())==correct
cli=components.resolve(stage,'facman_cli')
assert pe(cli.read_bytes())==zip_pe['bin/facman.exe']
cmd=[str(PY),'-B','-m','unittest','tests.test_package_external_component_staging','-v']
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONPATH']=str(REPO/'tests')+os.pathsep+str(REPO)
assert (TASK/'t').is_dir()
env['TEMP']=env['TMP']=str(TASK/'t')
start=time.monotonic()
with (E/'independent-ui-focused-tests.log').open('xb') as log:
    completed=subprocess.run(cmd,cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
seconds=time.monotonic()-start
testlog=(E/'independent-ui-focused-tests.log').read_bytes()
assert completed.returncode==0,testlog.decode(errors='replace')
assert b'Ran 8 tests' in testlog and b'\nOK' in testlog
after={'head':git('rev-parse','HEAD').decode().strip(),'index_tree':git('diff','--cached','--binary','--full-index').decode(),'status':git('status','--porcelain=v1').decode()}
assert before==after
for path,b in source_bytes.items():assert (REPO/path).read_bytes()==b,path
assert record(asset)==asset_record
assert (E/'frozen-source.json').read_bytes()==mraw
result={'schema':'facman.independent-packaged-ui-execution.v1','result':'PASS','source_before':before,'source_after':after,'source_files':rows,'author_manifest':record(E/'frozen-source.json'),'complete_patch':record(E/'frozen-source.patch'),'matching_patch_generation':patch_definitions,'independent_tests':{'command':cmd,'exit':completed.returncode,'seconds':round(seconds,6),'count':8,'log':record(E/'independent-ui-focused-tests.log')},'original_asset':asset_record,'original_zip_pe':zip_pe,'managed_build_and_install_stage':correct,'original_finding':record(old_find),'original_finding_file_bindings':old_files,'corrected_resolver_actual_stage':{'gui_path':str(selected),'gui_sha256':correct['sha256'],'cli_path':str(cli),'cli_sha256':zip_pe['bin/facman.exe']['sha256']},'author_validation':record(E/'focused-validation-v2.json'),'retained_red_log':record(E/'red-external-component-tests.log'),'effects':'Only ordinary synthetic unittest temporary files. Actual old asset/staging inspection and resolver reads only; no product process, build, package, stage, source/index, remote or host-setting mutation.','limits':['Fixed fresh clean product build/package and exact packaged managed-assembly gallery remain pending.','Original resource/workspace/payload-equivalence results retain their bounded scope; they never proved managed GUI identity.','Ordinary entrypoint/live backend, hosted six-asset qualification, genuine human/physical monitor and publication gates remain open.']}
print(json.dumps(emit('independent-ui-execution.json',result),indent=2))

