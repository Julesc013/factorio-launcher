#include <exception>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
int fixture_mode = 0;
int run_smoke() {
    if (fixture_mode == 2) throw std::runtime_error("fixture exception detail");
    if (fixture_mode == 3) throw 42;
    return fixture_mode == 1 ? 62 : 0;
}

int diagnostic_main()
{
    try {
        const int result = run_smoke();
        if (result != 0) {
            std::cerr << "facman_presentation_service_smoke failed with code "
                      << result << '\n';
        }
        return result;
    } catch (const std::exception& error) {
        std::cerr << "facman_presentation_service_smoke exception: "
                  << error.what() << '\n';
        return 1;
    } catch (...) {
        std::cerr << "facman_presentation_service_smoke unknown exception\n";
        return 1;
    }
}

int main() {
    const int expected_codes[] = {0, 62, 1, 1};
    const char* expected_outputs[] = {"", "facman_presentation_service_smoke failed with code 62\n", "facman_presentation_service_smoke exception: fixture exception detail\n", "facman_presentation_service_smoke unknown exception\n"};
    for (fixture_mode = 0; fixture_mode < 4; ++fixture_mode) {
        std::ostringstream captured;
        auto* original = std::cerr.rdbuf(captured.rdbuf());
        const int actual = diagnostic_main();
        std::cerr.rdbuf(original);
        if (actual != expected_codes[fixture_mode] || captured.str() != expected_outputs[fixture_mode]) return 10 + fixture_mode;
    }
    std::cout << "diagnostic wrapper: 4 native cases passed\n";
    return 0;
}
