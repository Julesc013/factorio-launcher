# PR251 native smoke diagnostic continuation

Exact primary HEAD6741b34983dabb095f1e51dc1db01d8510044b89, tree63dd9accdf6b1be3460ede4b870aef2ae615c6d3. Root authorizes focused replay, then a test-only numeric/exception diagnostic wrapper if not reproduced; no assertion weakening or speculative production fix. Existing user authority covers source/test evidence work. Root owns Git integration and canonical queue.

Hosted run34048043780/job101526531060 failed only facman_presentation_service_smoke in5.52s among42 static Windows tests; no child diagnostics. Full log SHA bc6bd6be24a93bbc2c976a0020c441c6a75c4f3f69ee770eba5710e4938115c1. Gallery never ran.

Read-only hygiene: seven marker-owned task roots,6.035GB, no in-checkout outputs, exactly2secondary worktrees. Doctor reports only already-base-contained active lab branch; root owns that uncommitted work, do not retire or mutate it.

Commands: tools/dev.py configure --profile developer --task-root <existing gallery root> --build-root <root>/native-presentation-debug; cmake --build that root --config Debug --target facman_presentation_service_smoke --parallel -- /p:TrackFileAccess=false; run this exact fresh executable once with TEMP/TMP=<root>/np-t. If it passes, preserve the result and add only existing-error diagnostic reporting in tests/native/facman_presentation_service_smoke.cpp, with focused diagnostic branch tests and exact source-body comparison. Root approves any necessary bounded LastTest.log retention separately within this task; do not change workflow unless needed. No source staging, branch changes, commits or remotes by worker.

The helper profile is positional: first configure attempt refused unknown --profile before effects. Correct exact command: tools/dev.py configure developer --task-root <owned root> --build-root <owned root>/native-presentation-debug. Initial CLI refusal retained separately.

Exact first local replay failed36 with existing concurrent-receipt diagnostic at owned TEMP length127; this differs from silent hosted failure. Preserve it. One same-binary replay now uses the unchanged test built-in Windows temporary root C:\Users\Jules\AppData\Local\Temp\facman-presentation-a79d2663062a after verifying it absent, to distinguish local path depth from the hosted failure. No global environment/settings changed.
