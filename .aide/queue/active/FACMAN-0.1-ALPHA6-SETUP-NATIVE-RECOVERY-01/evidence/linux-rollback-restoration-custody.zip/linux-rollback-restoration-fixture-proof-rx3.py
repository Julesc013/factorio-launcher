"""One owned full-suite source-fixture proof of corrected rollback restoration."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
from datetime import datetime, timezone

SOURCE = Path('/mnt/d/Development/FacMan/repositories/factorio-launcher-5db2844e2f29/tasks/task-facman-l-ea80d8496f/evidence/linux-rollback-restoration-patch')
TASK = Path('/mnt/d/Development/FacMan/repositories/factorio-launcher-5db2844e2f29/tasks/task-facman-l-ea80d8496f')
E = TASK / 'evidence'
WORK = E / 'linux-rollback-restoration-rx3-private'
REPORT = E / 'linux-rollback-restoration-rx3-fixture.json'
INPUTS = {'tools/linux_self_setup.py': 'b83b86ace4d3b6a6919e07760d90ec95c57db0d03f1309f4cf63ecd3cbc11fe7', 'tests/test_linux_self_setup_ownership.py': '5c5580e5d19477b1756e79028b8d27fcabbd706feb812b659d01466d46dcc84d', 'tools/package/linux_setup_predecessors.v1.toml': 'dc029acdd02ac9d9ec02f88e6cf271f38b62d62b376fec679c762b98255fe681'}
sys.dont_write_bytecode = True
sys.path.insert(0, str(SOURCE))


def require(ok, reason):
    if not ok:
        raise ValueError(reason)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, value):
    with path.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + '\n')


def source_inputs():
    require(not (SOURCE / 'tools/__init__.py').exists(), 'Namespace initialization changed')
    for rel, digest in INPUTS.items():
        require(sha(SOURCE / rel) == digest, 'Frozen input changed: ' + rel)


def worker(namespace):
    import time
    import unittest
    require(os.geteuid() == 0 and os.getpid() == 1 and os.getppid() == 0
            and os.readlink('/proc/self/ns/mnt') != namespace, 'Private namespace init required')
    report = dict(status='FAIL', scope='Full Linux ownership/recovery source fixture suite; not historical or produced-package qualification',
                  frozen_inputs=INPUTS, script_sha256=sha(Path(__file__)), observations=[],
                  source_base='5214835c95f6bf5c4f684d270ff16e099549f764', committed_patch=False,
                  builds=0, candidate_dispatches=0, new_roots=0, workunit_closed=False,
                  tmpfs_peak_bound_bytes=72*1024**2)
    mounted = False
    try:
        source_inputs()
        subprocess.run(['mount', '-t', 'tmpfs', '-o', 'size=64m,nodev,nosuid', 'tmpfs', str(WORK)], check=True, timeout=10)
        mounted = True
        temporary = WORK / 'temporary'; temporary.mkdir()
        os.environ.update(TMPDIR=str(temporary), FACMAN_TEST_PRIVATE_MOUNT_NAMESPACE='1')
        spec = importlib.util.spec_from_file_location('rollback_restoration_tests', SOURCE / 'tests/test_linux_self_setup_ownership.py')
        module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        module.tempfile.tempdir = str(temporary)
        require(Path(sys.modules['tools.linux_self_setup'].__file__).resolve()
                == (SOURCE / 'tools/linux_self_setup.py').resolve(), 'Loaded patched Setup module differs')
        deadline = time.monotonic() + 570

        def recorded(self, script, home, *args, path_prefix=None, extra_environment=None):
            ordinal = len(report['observations']) + 1
            prefix = E / ('linux-rollback-restoration-rx3-command-' + str(ordinal).zfill(3))
            environment = dict(os.environ, HOME=str(home))
            if path_prefix is not None:
                environment['PATH'] = str(path_prefix) + os.pathsep + environment['PATH']
            if extra_environment is not None:
                environment.update(extra_environment)
            argv = [str(script), *args]
            remaining = min(20, deadline-time.monotonic())
            require(remaining > 0, 'Owned full-suite deadline expired')
            observation = dict(ordinal=ordinal, test=self.id(), argv=argv, home=str(home),
                               fault=extra_environment or {}, path_prefix=str(path_prefix) if path_prefix else None,
                               timeout_seconds=remaining)
            write(prefix.with_suffix('.json'), observation)
            with prefix.with_suffix('.stdout').open('xb') as stdout, prefix.with_suffix('.stderr').open('xb') as stderr:
                try:
                    result = subprocess.run(argv, env=environment, stdout=stdout, stderr=stderr,
                                            check=False, timeout=remaining)
                except subprocess.TimeoutExpired:
                    stdout.flush(); stderr.flush()
                    observation.update(exit_code=None, timed_out=True,
                        stdout_sha256=sha(prefix.with_suffix('.stdout')), stderr_sha256=sha(prefix.with_suffix('.stderr')))
                    report['observations'].append(observation)
                    raise
            observation.update(exit_code=result.returncode, stdout_sha256=sha(prefix.with_suffix('.stdout')),
                               stderr_sha256=sha(prefix.with_suffix('.stderr')))
            report['observations'].append(observation)
            return subprocess.CompletedProcess(argv, result.returncode,
                prefix.with_suffix('.stdout').read_text(encoding='utf-8'), prefix.with_suffix('.stderr').read_text(encoding='utf-8'))

        module.LinuxSelfSetupOwnershipTests.invoke = recorded
        suite = unittest.defaultTestLoader.loadTestsFromTestCase(module.LinuxSelfSetupOwnershipTests)
        with (E / 'linux-rollback-restoration-rx3-unittest.log').open('x', encoding='utf-8') as log:
            result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
        report.update(tests_run=result.testsRun, failures=[dict(test=t.id(), detail=detail) for t,detail in result.failures],
                      errors=[dict(test=t.id(), detail=detail) for t,detail in result.errors], skipped=result.skipped)
        require(result.wasSuccessful() and not result.skipped, 'Full source-fixture suite failed or skipped; inspect unittest log')
        require(not list(temporary.iterdir()), 'Fixture suite retained temporary application effects')
        source_inputs()
        report.update(status='PASS', source_fixture_suite=True, historical_A5=False, produced_package=False,
                      physical_host=False, game=False, human=False, release=False)
    except BaseException as exc:
        report.update(status='FAIL', error=repr(exc))
    finally:
        if mounted:
            result = subprocess.run(['umount', str(WORK)], capture_output=True, text=True, timeout=10)
            report['private_volume_unmounted'] = result.returncode == 0
            if result.returncode:
                report.update(status='FAIL', cleanup_error=result.stderr)
        report['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
        write(REPORT, report)
    return 0 if report['status'] == 'PASS' else 1


def main():
    require(sys.platform.startswith('linux') and __debug__, 'Linux with assertions required')
    if len(sys.argv) == 3 and sys.argv[1] == '--worker':
        return worker(sys.argv[2])
    require(len(sys.argv) == 1 and os.geteuid() == 0, 'One explicit root supervisor required')
    marker = json.loads((TASK / '.facman-development-root.v1.json').read_text())
    require(marker['task_id'] == 'task/facman-linux-repair-recovery-10' and marker['owner'] == 'facman-development'
            and marker['kind'] == 'task-root' and marker['canonical_path'] == r'D:\Development\FacMan\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-l-ea80d8496f', 'Owned marker differs')
    require(not WORK.exists() and not REPORT.exists(), 'Preserve existing output; never replay')
    require(shutil.disk_usage(E).free >= 8 * 1024**3, 'Storage floor breached')
    require(int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines()
                     if line.startswith('MemAvailable:'))) * 1024 >= 1024**3, 'Memory reserve insufficient')
    source_inputs()
    write(E / 'linux-rollback-restoration.claim.json', dict(PID=os.getpid(), script_sha256=sha(Path(__file__)),
          created_at_utc=datetime.now(timezone.utc).isoformat(), recovery='Persistent claim; no automatic replay'))
    WORK.mkdir(); namespace = os.readlink('/proc/self/ns/mnt')
    with (E / 'linux-rollback-restoration.runner.log').open('x', encoding='utf-8') as log:
        child = subprocess.Popen(['unshare', '--mount', '--pid', '--fork', '--kill-child=SIGKILL', '--mount-proc',
                                  '--propagation', 'private', sys.executable, '-B', str(Path(__file__).resolve()), '--worker', namespace],
                                 stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True,
                                 env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONOPTIMIZE='0'))
        try:
            code = child.wait(timeout=600)
        except subprocess.TimeoutExpired:
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGKILL)
            child.wait(timeout=10)
            raise ValueError('Owned namespace deadline; preserve evidence')
    require(code == 0 and REPORT.exists(), 'Fixture diagnosis failed; inspect retained report')
    require(os.readlink('/proc/self/ns/mnt') == namespace and not list(WORK.iterdir()) and not os.path.ismount(WORK), 'Namespace cleanup differs')
    source_inputs()
    write(E / 'linux-rollback-restoration-rx3-parent-postcheck.json', dict(status='PASS', private_mount_absent=True,
          original_namespace_preserved=True, underlying_child_empty=True, report_sha256=sha(REPORT)))
    print(json.dumps(dict(status='PASS', report=str(REPORT), report_sha256=sha(REPORT))))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
