import time
from pathlib import Path
Path('grandchild-started').write_text('retained')
time.sleep(60)
