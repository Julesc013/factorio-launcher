import subprocess,sys,time
from pathlib import Path
p=subprocess.Popen([sys.executable,'grandchild.py'])
Path('grandchild.pid').write_text(str(p.pid))
print('nested-grandchild-started',flush=True)
time.sleep(60)
