import sys
from pathlib import Path
from tools import provider_canary_process as p
root=Path.cwd()
r=p.command([sys.executable,'child.py'],cwd=root,timeout=30,directory=root/'inner')
p.require(r)
