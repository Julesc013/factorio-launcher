import ctypes,json,os,subprocess,sys,tempfile,threading,time
from pathlib import Path
REPO=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\worktrees\task-facman-provider-canary-01');E=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-b48460c353\evidence');TASK=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-b48460c353')
sys.path.insert(0,str(REPO))
from tools import provider_canary_process as bounded
root=Path(tempfile.mkdtemp(prefix='ir-nested-',dir=TASK/'t'))
grandchild=root/'grandchild.py'
grandchild.write_text("import time\nfrom pathlib import Path\nPath('grandchild-started').write_text('retained')\ntime.sleep(60)\n",encoding='utf-8')
child=root/'child.py'
child.write_text("import subprocess,sys,time\nfrom pathlib import Path\n"
 "p=subprocess.Popen([sys.executable,'grandchild.py'])\n"
 "Path('grandchild.pid').write_text(str(p.pid))\n"
 "print('nested-grandchild-started',flush=True)\ntime.sleep(60)\n",encoding='utf-8')
worker=root/'worker.py'
worker.write_text("import sys\nfrom pathlib import Path\n"
 "from tools import provider_canary_process as p\n"
 "root=Path.cwd()\n"
 "r=p.command([sys.executable,'child.py'],cwd=root,timeout=30,directory=root/'inner')\n"
 "p.require(r)\n",encoding='utf-8')
api=bounded.windows.kernel()
api.OpenProcess.argtypes=[ctypes.c_uint32,ctypes.c_int,ctypes.c_uint32];api.OpenProcess.restype=ctypes.c_void_p
held=[]
def watch():
 end=time.monotonic()+4
 while time.monotonic()<end:
  p=root/'grandchild.pid'
  if p.exists():
   try:pid=int(p.read_text())
   except ValueError:continue
   h=api.OpenProcess(0x100000|0x1000,False,pid)
   if h:
    ticks=[ctypes.c_uint64() for _ in range(4)]
    if api.GetProcessTimes(h,*(ctypes.byref(t) for t in ticks)):
     held.append((h,pid,ticks[0].value));return
    api.CloseHandle(h)
  time.sleep(.005)
sentinel=subprocess.Popen([sys.executable,'-c','import time;time.sleep(60)'],creationflags=subprocess.CREATE_NO_WINDOW)
thread=threading.Thread(target=watch)
record={'schema':'facman.independent-nested-job-deadline-probe.v1','result':'FAIL','fixture':str(root),'source_packet_sha256':'c67e57dc45a693373a363a095014944281644b475f9d0ce8f42c20a2e926c90a','sentinel_pid':sentinel.pid}
try:
 thread.start()
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(REPO))
 outer=bounded.command([sys.executable,str(worker)],cwd=root,environment=env,timeout=1.5,directory=root/'outer')
 thread.join(timeout=4)
 record['outer_receipt']=outer.receipt
 record['grandchild_handles_observed']=len(held)
 record['unrelated_sentinel_running']=sentinel.poll() is None
 record['watcher_stopped']=not thread.is_alive()
 record['inner_receipt']=json.loads((root/'inner/receipt.json').read_bytes())
 record['grandchild_effect']=(root/'grandchild-started').read_text()
 if held:
  h,pid,ticks=held[0];record['grandchild']={'pid':pid,'creation_ticks':ticks,'wait_status':api.WaitForSingleObject(h,2000)}
 assert outer.receipt['termination']=='command_timeout',outer.receipt
 assert outer.receipt['primary_stopped'] and outer.receipt['job_empty_observed']
 assert record['watcher_stopped'] and len(held)==1
 assert record['grandchild']['wait_status']==0
 assert record['unrelated_sentinel_running']
 assert record['grandchild_effect']=='retained'
 assert record['inner_receipt']['termination']=='prepared_outcome_unknown'
 assert record['inner_receipt']['effects']=='unknown_if_interrupted'
 record['result']='PASS'
finally:
 sentinel.terminate();sentinel.wait(timeout=5)
 thread.join(timeout=4)
 for h,_,_ in held:api.CloseHandle(h)
 out=E/'independent-deadline-nested-probe.json'
 out.open('x',encoding='utf-8',newline='\n').write(json.dumps(record,indent=2,sort_keys=True)+'\n')
 import hashlib
 print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'result':record['result']},indent=2))

