from pathlib import Path
import hashlib,json,os,subprocess,time,zipfile
R=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\worktrees\task-facman-provider-canary-01');E=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-b48460c353\evidence');P=E/'deadline-review-v1'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def rec(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def git(*a,okay=(0,)):
 p=subprocess.run(['git',*a],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 assert p.returncode in okay,p.stderr.decode(errors='replace')
 return p.stdout
packet=(P/'source-packet.json').read_bytes();assert sha(packet)=='c67e57dc45a693373a363a095014944281644b475f9d0ce8f42c20a2e926c90a'
m=json.loads(packet);snapshot={}
assert git('rev-parse','HEAD').decode().strip()==m['head']
assert not git('diff','--cached','--binary','--full-index')
for r in m['sources']:
 b=(R/r['path']).read_bytes();snapshot[r['path']]=b
 assert sha(b)==r['raw_sha256'] and len(b)==r['bytes'],r['path']
 assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==r['git_blob']
assert sha(json.dumps(m['sources'],sort_keys=True,separators=(',',':')).encode())==m['source_aggregate_sha256']
# Compute projected Git tree directly from bytes, without touching a Git index/object store.
flat={}
for row in git('ls-tree','-r','-z',m['head']).split(b'\0'):
 if row:
  head,name=row.split(b'\t',1);mode,kind,oid=head.split();assert kind==b'blob'
  flat[name.decode()]=(mode.decode(),oid.decode())
for r in m['sources']:flat[r['path']]=(r['git_mode'],r['git_blob'])
nested={}
for path,v in flat.items():
 node=nested;parts=path.split('/')
 for part in parts[:-1]:node=node.setdefault(part,{})
 node[parts[-1]]=v
def tree(node):
 body=b''
 for name,v in sorted(node.items(),key=lambda kv:kv[0].encode()+ (b'/' if isinstance(kv[1],dict) else b'')):
  mode,oid=('40000',tree(v)) if isinstance(v,dict) else v
  body+=mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(oid)
 return hashlib.sha1(b'tree '+str(len(body)).encode()+b'\0'+body).hexdigest()
assert tree(nested)==m['projected_tree']
tracked=sorted(r['path'] for r in m['sources'] if r['status']=='modified')
new=sorted(r['path'] for r in m['sources'] if r['status']=='new')
patch=git('diff','HEAD','--no-ext-diff','--no-textconv','--binary','--full-index','--',*tracked)
for path in new:patch+=git('diff','--no-index','--no-ext-diff','--no-textconv','--binary','--full-index','--','/dev/null',path,okay=(1,))
assert patch==(P/'complete.patch').read_bytes() and sha(patch)==m['patch_sha256']
with zipfile.ZipFile(P/'source-raw.zip') as z:
 assert set(z.namelist())==set(snapshot)
 for n,b in snapshot.items():assert z.read(n)==b
with zipfile.ZipFile(P/'evidence-raw.zip') as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(m['artifacts'])
 assert set(z.namelist())=={r['archive_member'] for r in m['artifacts']}
 for r in m['artifacts']:
  captured=z.read(r['archive_member']);assert sha(captured)==r['sha256'] and len(captured)==r['bytes'],r['path']
  b=Path(r['path']).read_bytes();assert b==captured,r['path']
supplement=json.loads((P/'stable-inputs-supplement.json').read_bytes())
before_status=git('status','--porcelain=v1')
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(R/'tests')+os.pathsep+str(R),TEMP=r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-b48460c353\t',TMP=r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-b48460c353\t')
py=r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\beta1-admissi-68051e628e\python\Scripts\python.exe'
cmd=[py,'-B','-m','unittest','tests.test_provider_canary_process','tests.test_provider_local_source_canary','-v']
started=time.monotonic()
with (E/'independent-deadline-v1-tests.log').open('xb') as log:
 p=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
elapsed=time.monotonic()-started
log=(E/'independent-deadline-v1-tests.log').read_bytes()
assert p.returncode==0,log.decode(errors='replace')
assert b'Ran 32 tests' in log
for n,b in snapshot.items():assert (R/n).read_bytes()==b,n
assert before_status==git('status','--porcelain=v1')
assert not git('diff','--cached','--binary','--full-index')
assert (P/'source-packet.json').read_bytes()==packet
result={'schema':'facman.independent-canary-deadline-execution.v1','result':'PASS','source_packet':rec(P/'source-packet.json'),'source_aggregate':m['source_aggregate_sha256'],'head':m['head'],'projected_tree_recomputed_without_writes':tree(nested),'complete_patch_reconstructed':rec(P/'complete.patch'),'source_raw_zip':rec(P/'source-raw.zip'),'evidence_raw_zip':rec(P/'evidence-raw.zip'),'sources_verified':len(snapshot),'artifact_original_and_archive_rows_verified':len(m['artifacts']),'stable_supplement':rec(P/'stable-inputs-supplement.json'),'command':cmd,'exit':p.returncode,'seconds':round(elapsed,6),'tests':32,'log':rec(E/'independent-deadline-v1-tests.log'),'source_and_index_unchanged':True,'effects':'Ordinary synthetic Windows child/job/file tests and temporary synthetic Git repositories only. No build, real provider/source/index/ref change or adoption.'}
out=E/'independent-deadline-v1-execution.json'
with out.open('x',encoding='utf-8',newline='\n') as f:json.dump(result,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(rec(out),indent=2))

