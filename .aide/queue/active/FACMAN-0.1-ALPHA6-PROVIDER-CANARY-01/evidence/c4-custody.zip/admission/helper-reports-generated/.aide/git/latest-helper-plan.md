# AIDE Git Helper Plan

- schema_version: aide.git-helper-plan.v0
- generated_by: aide-lite
- operation: plan
- status: ready_dry_run
- dry_run: true
- apply_requested: false
- push_requested: false
- non_mutating: true
- remote_mutation: false
- force_push_allowed: false

## Current State

- branch: task/facman-provider-canary-01
- role: task
- commit: 6c5b545f50c675e5f57b657037e109ffbc55ea8f
- dirty_tree: false
- upstream: not detected
- policy_ready: true

## Planned Commands

- none

## Executed Commands

- none

## Blockers

- none

## Warnings

- upstream_unavailable: fatal: no upstream configured for branch 'task/facman-provider-canary-01'

## Recommendations

- run git land --dry-run --target dev

## Safety Boundary

Q29 helper plans are dry-run by default. Live AIDE branch creation, deletion,
merge, prune, promotion, push, and force-push are not performed by Q29
validation.
