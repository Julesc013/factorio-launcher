# AIDE Git Workflow Detection

- schema_version: aide.git-workflow-detection.v0
- generated_by: aide-lite
- non_mutating: true
- current_branch: task/facman-provider-canary-01
- current_commit: 6c5b545f50c675e5f57b657037e109ffbc55ea8f
- current_branch_role: task
- detected_workflow: trunk_with_dev_integration
- confidence: high
- canonical_branch: main
- integration_branch: dev
- recommended_next_action: continue bounded task work, validate locally, and plan future landing to dev

## Branch Summary

- local_branches: 4
- remote_branches: 13
- tags_count: 3

## Warnings

- none

## Q28 Boundary

This report was generated without branch creation, deletion, merge, prune, push,
fetch, GitHub API mutation, provider calls, model calls, or network calls.
