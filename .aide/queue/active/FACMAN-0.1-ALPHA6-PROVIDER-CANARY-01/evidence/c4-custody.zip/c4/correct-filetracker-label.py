import hashlib,json,subprocess
from pathlib import Path
TASK=Path(r"C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-b48460c353")
E=TASK/"evidence/c4-execution"
old=E/"review-handoff.json"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(old)=="6778e185ff59745e6fa6e36c53af008f0b1ad7128502ac3ee13568b1b4e13b2d"
h=json.loads(old.read_bytes())
WT=Path(h["source"]["root"])
tlog=Path(h["FileTracker_observation"]["path"])
assert sha(tlog)==h["FileTracker_observation"]["sha256"]
lines=tlog.read_bytes().decode("utf-16").splitlines()
keys=[line for line in lines if line.startswith("^")]
deps=[line for line in lines if line and not line.startswith("^")]
sections={}
current=None
for line in lines:
    if line.startswith("^"):current=line[1:];sections[current]=[]
    elif line and current is not None:sections[current].append(line)
product=[(key,rows) for key,rows in sections.items() if key.endswith("\\APPLICATION\\HANDLERS\\PRODUCT.CPP")]
assert len(product)==1
prefix=str(WT).lower()
real=[line for line in deps if prefix in line.lower()]
product_real=[line for line in product[0][1] if prefix in line.lower()]
actual={"path":str(tlog),"sha256":sha(tlog),"source_record_count":len(keys),"dependency_row_count":len(deps),
"worktree_source_record_count":sum(prefix in key.lower() for key in keys),
"worktree_dependency_count":len(real),"product_source_record":product[0][0],
"product_dependency_count":len(product[0][1]),"product_worktree_dependency_count":len(product_real),
"contains_generated_build_identity_header":any("build_identity.hpp" in row.lower() for row in deps),
"meaning":"Actual dependency rows exclude source-record keys prefixed '^'. Fresh compiled-identity readback passes, while incremental dependency tracking remains unqualified."}
correction={"schema":"facman.c4-custody-label-correction.v1","prior_handoff_sha256":sha(old),
"prior_artifact_custody_sha256":sha(E/"artifact-custody.json"),
"prior_archive_sha256":sha(E/"c4-raw-custody.zip"),
"reason":"The initial seal's contains_worktree_dependencies checked the whole tlog string and counted source-record keys as dependency rows. That scalar in original inventory/handoff is superseded by this parsed observation; raw evidence is preserved unchanged.",
"corrected_FileTracker_observation":actual,"execution_result_unchanged":True,"source_bytes_unchanged":True,
"no_build_or_test_repeated":True}
def write(path,value):
    assert not path.exists()
    path.write_text(json.dumps(value,indent=2)+"\n",encoding="utf-8",newline="\n")
path=E/"filetracker-label-correction.json";write(path,correction)
h["schema"]="facman.c4-review-handoff.v2"
h["FileTracker_observation"]=actual
h["superseded_label_only_handoff"]={"path":str(old),"sha256":sha(old)}
h["label_correction"]={"path":str(path),"sha256":sha(path),"bytes":path.stat().st_size}
h["raw_archive_and_inventory_unchanged"]=True
h["additional_external_transport_bindings"]=[h["label_correction"]]
final=E/"review-handoff-v2.json";write(final,h)
print(json.dumps({"final_path":str(final),"final_sha256":sha(final),"correction_sha256":sha(path),"FileTracker":actual}))
