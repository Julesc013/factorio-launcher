import hashlib,json
from pathlib import Path
T=Path(r"C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-b48460c353")
E=T/"evidence/c4-execution"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def row(p):return {"path":str(p),"bytes":p.stat().st_size,"sha256":sha(p)}
def write(p,v):
    assert not p.exists()
    p.write_text(json.dumps(v,indent=2)+"\n",encoding="utf-8",newline="\n")
old=E/"review-handoff.json"
assert sha(old)=="6778e185ff59745e6fa6e36c53af008f0b1ad7128502ac3ee13568b1b4e13b2d"
h=json.loads(old.read_bytes())
inv=json.loads((E/"artifact-custody.json").read_bytes())
WT=Path(h["source"]["root"])
product_obj=Path(inv["product_object"]["path"])
logs=list(product_obj.parent.glob("*/CL.read.1.tlog"))
assert len(logs)==1
log=logs[0]
entry=next(r for r in inv["files"] if r["path"]==str(log))
assert sha(log)==entry["sha256"]
sections={};key=None
for line in log.read_bytes().decode("utf-16").splitlines():
    if line.startswith("^"):key=line[1:];sections[key]=[]
    elif line and key is not None:sections[key].append(line)
matches=[(k,v) for k,v in sections.items() if k.endswith("\\APPLICATION\\HANDLERS\\PRODUCT.CPP")]
assert len(matches)==1
source,deps=matches[0]
actual={"path":str(log),"sha256":sha(log),"product_object":row(product_obj),
"product_source_record":source,"product_dependency_count":len(deps),
"product_worktree_dependency_count":sum(str(WT).lower() in d.lower() for d in deps),
"contains_generated_build_identity_header":any("build_identity.hpp" in d.lower() for d in deps),
"meaning":"Parsed the actual product.obj translation-unit section. Source-record keys prefixed '^' are not dependencies. This fresh build's typed readback passes; incremental dependency qualification remains excluded."}
failure={"schema":"facman.c4-evidence-preparation-failure.v1","failed_script":row(E/"correct-filetracker-label.py"),
"exit_code":1,"error":"AssertionError at assert len(product)==1, line21",
"cause":"First correction used the initial binding-library tlog, which does not contain product.cpp. Corrected selection uses the exact retained product.obj parent directory.",
"source_build_tests_not_rerun":True,"prior_raw_evidence_preserved":True}
write(E/"filetracker-correction-preparation-failure.json",failure)
correction={"schema":"facman.c4-custody-label-correction.v1","prior_handoff":row(old),
"prior_artifact_custody":row(E/"artifact-custody.json"),"prior_archive":row(E/"c4-raw-custody.zip"),
"reason":"Initial seal selected the binding-library tlog rather than the product application-library tlog, and its whole-string contains_worktree_dependencies scalar counted source-record keys. That observation is superseded by the explicit actual product section below. All initial raw bytes remain unchanged.",
"corrected_FileTracker_observation":actual,"execution_result_unchanged":True,"source_bytes_unchanged":True,
"no_build_or_test_repeated":True,"preparation_failure":row(E/"filetracker-correction-preparation-failure.json"),
"correction_script":row(E/"correct-filetracker-label-v2.py")}
write(E/"filetracker-label-correction.json",correction)
h["schema"]="facman.c4-review-handoff.v2"
h["FileTracker_observation"]=actual
h["superseded_label_only_handoff"]=row(old)
h["label_correction"]=row(E/"filetracker-label-correction.json")
h["raw_archive_and_inventory_unchanged"]=True
h["additional_external_transport_bindings"]=[row(E/name) for name in ("filetracker-label-correction.json","filetracker-correction-preparation-failure.json","correct-filetracker-label.py","correct-filetracker-label-v2.py")]
write(E/"review-handoff-v2.json",h)
print(json.dumps({"handoff":row(E/"review-handoff-v2.json"),"correction":row(E/"filetracker-label-correction.json"),"FileTracker":actual}))
