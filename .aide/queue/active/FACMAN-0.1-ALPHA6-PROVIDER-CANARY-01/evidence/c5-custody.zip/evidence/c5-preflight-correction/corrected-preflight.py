import hashlib

def normalized_git_blob(raw, normalization):
    if normalization not in ("raw", "CRLF_to_LF"):
        raise ValueError("unsupported source normalization")
    normalized = raw if normalization == "raw" else raw.replace(bytes((13, 10)), bytes((10,)))
    return hashlib.sha1(b"blob " + str(len(normalized)).encode() + bytes((0,)) + normalized).hexdigest()
