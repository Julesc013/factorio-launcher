import hashlib, json, os, stat, sys, time, traceback
from pathlib import Path

TASK = Path(r"C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-b48460c353")
PLAN_DIR = TASK / "evidence/c5-preflight-correction"
E = TASK / "evidence/c5-execution-2"
def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024*1024), b""): h.update(block)
    return h.hexdigest()
def pairs(rows):
    result = {}
    for key, value in rows:
        if key in result: raise ValueError("duplicate JSON key: " + key)
        result[key] = value
    return result
def read_json(path, cap=8*1024*1024):
    with path.open("rb") as f: raw=f.read(cap+1)
    if len(raw)>cap: raise ValueError("JSON limit exceeded: "+str(path))
    value=json.loads(raw.decode("utf-8"), object_pairs_hook=pairs, parse_constant=lambda s: (_ for _ in ()).throw(ValueError(s)))
    if type(value) is not dict: raise ValueError("JSON object required")
    return value
assert digest(PLAN_DIR/"canary-plan.json")=="78dc61b21c2ce8e6fed47945ac76987a6f3abd644929d4fe07f51b969549ca26"
assert read_json(PLAN_DIR/"root-review.json")["plan_sha256"]==digest(PLAN_DIR/"canary-plan.json")
plan=read_json(PLAN_DIR/"canary-plan.json")
WT=Path(plan["source_checkpoint"]["root"])
sys.path.insert(0,str(WT))
from tools import provider_canary_process as bounded
env=dict(os.environ)
env.update(plan["environment"])
env.update(GIT_OPTIONAL_LOCKS="0",GIT_TERMINAL_PROMPT="0",GIT_NO_LAZY_FETCH="1")
os.environ.update(plan["environment"])
META=E/"metadata"
META.mkdir()
counter=0
def meta(label, command, cwd=WT, timeout=30):
    global counter
    counter+=1
    result=bounded.command(command,cwd=cwd,environment=env,timeout=timeout,directory=META/f"{counter:03d}-{label}",output_limit=8*1024*1024)
    bounded.require(result)
    return result.stdout.decode("utf-8").strip()
def git(root,*args):
    return meta("git",["git","-c","safe.directory="+root.as_posix(),"-C",str(root),*args])
def observation():
    sources=[]
    for item in [plan["source_checkpoint"],*plan["provider_sources"]]:
        root=Path(item["root"])
        actual={"name":item["name"],"head":git(root,"rev-parse","HEAD"),"tree":git(root,"rev-parse","HEAD^{tree}"),"status":git(root,"status","--porcelain=v1")}
        if item["ref"]!="detached stable source":
            actual["ref"]=git(root,"symbolic-ref","HEAD")
            assert actual["ref"]==item["ref"]
        else:
            actual["detached_name"]=git(root,"rev-parse","--abbrev-ref","HEAD")
            assert actual["detached_name"]=="HEAD"
        assert actual["head"]==item["commit"] and actual["tree"]==item["tree"] and actual["status"]=="", actual
        sources.append(actual)
    hashes=[]
    for row in plan["stable_inputs"]+plan["supervisor_source_files"]:
        path=WT/row["path"]
        actual={"path":row["path"],"bytes":path.stat().st_size,"sha256":digest(path)}
        assert actual["bytes"]==row["bytes"] and actual["sha256"]==row["sha256"],actual
        hashes.append(actual)
    for key in ("review_receipt","ownership_marker"):
        assert digest(Path(plan[key]["path"]))==plan[key]["sha256"]
    assert digest(PLAN_DIR/"prerequisites.json")==plan["prerequisites_sha256"]
    merged=[]
    for row in plan["merged_source_files"]:
        path=WT/row["path"]
        assert path.stat().st_size==row["bytes"]
        raw=path.read_bytes()
        assert hashlib.sha256(raw).hexdigest()==row["raw_sha256"],row["path"]
        assert row["normalization"] in ("raw","CRLF_to_LF")
        normalized=raw if row["normalization"]=="raw" else raw.replace(bytes((13,10)),bytes((10,)))
        blob=hashlib.sha1(b"blob "+str(len(normalized)).encode()+bytes((0,))+normalized).hexdigest()
        assert blob==row["git_blob"],row["path"]
        merged.append(dict(row))
    for key in ("source_merge_receipt","source_merge_approval","source_commit_review"):
        assert digest(Path(plan[key]["path"]))==plan[key]["sha256"]
    assert git(WT,"show","-s","--format=%P","HEAD").split()==read_json(PLAN_DIR/"root-review.json")["reviewed_merge_parents"]
    return {"sources":sources,"bound_files":hashes,"merged_source_files":merged,"review_and_marker_match":True}
def fresh_paths():
    paths=[plan["write_scope"][key] for key in ("new_work","new_control","new_build")]+plan["write_scope"]["named_retained_fixtures"]
    rows=[]
    for spelling in paths:
        p=Path(spelling)
        assert p.resolve().is_relative_to(TASK.resolve()) and not p.exists() and not p.is_symlink(),spelling
        rows.append({"path":spelling,"absent":True,"contained":True})
    return rows
def save(name,value): bounded.write_json(E/name,value)
receipt={"schema":"facman.c5-execution.v1","result":"prepared_outcome_unknown","plan_sha256":digest(PLAN_DIR/"canary-plan.json"),
         "root_review_sha256":digest(PLAN_DIR/"root-review.json"),"scope":plan["scope"],"authority":plan["authority"],
         "automatic_retries":0,"effects":"unknown_if_interrupted"}
save("execution.json",receipt)
exitcode=1
try:
    print("C5 preflight: source, stable inputs and fresh paths",flush=True)
    before=observation()
    fresh=fresh_paths()
    save("before.json",{"observation":before,"fresh_paths":fresh})
    python=plan["canary_command"][0]
    for label,args,timeout in (("paths",["paths"],30),("doctor",["doctor","--measure","--max-task-roots","10"],60)):
        output=meta(label,[python,str(WT/"tools/workspace_hygiene.py"),*args],timeout=timeout)
        print("C5 hygiene "+label+": PASS",flush=True)
    # Reconfirm admission after hygiene, immediately before the one dispatch.
    assert observation()==before
    assert fresh_paths()==fresh
    budget=bounded.Budget(1900,1850)
    receipt.update(result="dispatched_outcome_unknown",effects="possible_retained")
    save("execution.json",receipt)
    print("C5 single source-static dispatch begins",flush=True)
    result=bounded.command(plan["canary_command"],cwd=WT,environment=env,timeout=1850,budget=budget,directory=E/"canary-command")
    receipt["canary_command"]={"receipt":str(result.directory/"receipt.json"),"sha256":digest(result.directory/"receipt.json"),
                               "termination":result.receipt["termination"],"exit_code":result.returncode}
    print("C5 source-static command: "+result.receipt["termination"]+" exit="+str(result.returncode),flush=True)
    bounded.require(result)
    supervision=read_json(TASK/"c5-control/supervision.json")
    worker=read_json(TASK/"c5/evidence/observation.json")
    assert supervision["result"]=="supervised_source_static_consumer_pass"
    assert worker["result"]=="source_static_consumer_pass"
    assert worker["stable_inputs_unchanged"] is True and worker["consumer_source_unchanged"] is True
    assert supervision["observation_sha256"]==digest(TASK/"c5/evidence/observation.json")
    receipt["source_static_result"]="PASS"
    identity_path=Path(plan["compiled_identity_command"][2])
    assert not identity_path.exists()
    print("C5 typed compiled-identity readback begins",flush=True)
    readback=bounded.command(plan["compiled_identity_command"],cwd=WT,environment=env,timeout=30,budget=budget,directory=E/"compiled-identity-command",output_limit=1024*1024)
    receipt["identity_command"]={"receipt":str(readback.directory/"receipt.json"),"sha256":digest(readback.directory/"receipt.json"),
                                 "termination":readback.receipt["termination"],"exit_code":readback.returncode}
    bounded.require(readback)
    data=read_json(readback.directory/"stdout.raw",1024*1024)
    oracle=plan["compiled_identity_oracle"]
    def match(actual,expected):
        assert type(actual) is dict
        for key,value in expected.items():
            assert key in actual and type(actual[key]) is type(value) and actual[key]==value,(key,actual.get(key),value)
    match(data,oracle["envelope"])
    payload=data["payload"]
    match(payload,oracle["payload"])
    backend=payload["backend_identity"]
    match(backend,{"schema":oracle["backend_schema"]})
    expected_build=dict(oracle["build"])
    identity_file=TASK/"c5/native/facman-build-identity.v1.txt"
    assert identity_file.stat().st_size<1024*1024
    expected_build["build_identity"]=identity_file.read_text(encoding="utf-8").strip()
    match(backend["build"],expected_build)
    match(backend,{"command_catalog_sha256":oracle["contract_constants"]["FACMAN_COMMAND_CATALOG_SHA256"],
                   "contract_set_sha256":oracle["contract_constants"]["FACMAN_CONTRACT_SET_SHA256"]})
    match(backend["package"],oracle["package_expectation"])
    receipt["compiled_identity_oracle"]={"result":"PASS","strict_types":True,"duplicate_keys_refused":True,
                                         "build_identity_file_sha256":digest(identity_file)}
    receipt["elapsed_shared_budget_seconds"]=round(1900-budget.remaining(),6)
    receipt["result"]="source_static_and_compiled_identity_pass_pending_independent_review"
    exitcode=0
except Exception as error:
    receipt["result"]="failed_retained"
    receipt["error_type"]=type(error).__name__
    receipt["error"]=str(error)[:4096]
    (E/"failure.txt").write_text(traceback.format_exc(),encoding="utf-8")
    print("C5 FAILED RETAINED: "+type(error).__name__+": "+str(error),flush=True)
finally:
    try:
        after=observation()
        save("after.json",{"observation":after,"matches_before":after==locals().get("before")})
        receipt["source_and_pins_unchanged"]=after==locals().get("before")
        if not receipt["source_and_pins_unchanged"]:
            receipt["result"]="failed_retained";exitcode=1
    except Exception as error:
        receipt["after_error"]=repr(error)
        receipt["result"]="failed_retained";exitcode=1
    receipt["retained_paths"]=[str(TASK/name) for name in ("c5","c5-control","t/c5-stored","t/c5-deflate","t/c5-identity-workspace") if (TASK/name).exists()]
    receipt["no_retry_performed"]=True
    save("execution.json",receipt)
    print(json.dumps({"result":receipt["result"],"receipt":str(E/"execution.json"),"sha256":digest(E/"execution.json")}),flush=True)
raise SystemExit(exitcode)
