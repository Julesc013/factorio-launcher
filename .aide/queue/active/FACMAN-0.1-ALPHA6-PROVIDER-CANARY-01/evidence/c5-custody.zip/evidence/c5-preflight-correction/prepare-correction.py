import hashlib,json,os,sys
from pathlib import Path
R=Path(r"C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29")
W=R/"worktrees/task-facman-provider-canary-01";T=R/"tasks/facman-0.1-al-b48460c353"
E=T/"evidence/c5-execution";O=T/"evidence/c5-preflight-correction";C=O/"diagnosis-commands";C.mkdir()
sys.path.insert(0,str(W))
from tools import provider_canary_process as bounded
env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1",TEMP=str(T/"t"),TMP=str(T/"t"),PYTHONPATH=str(W/"tests")+";"+str(W),GIT_OPTIONAL_LOCKS="0",GIT_NO_LAZY_FETCH="1",GIT_TERMINAL_PROMPT="0")
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def record(p):return {"path":str(p),"bytes":p.stat().st_size,"sha256":sha(p.read_bytes())}
def save(name,value):bounded.write_json(O/name,value)
plan_path=T/"evidence/c5-plan/canary-plan.json";plan=json.loads(plan_path.read_bytes())
assert sha(plan_path.read_bytes())=="d36dc1e3beeb107151cbd9dcebecc123092d8638d3ab66d1935adbb55915efa1"
assert sha((E/"execution.json").read_bytes())=="0774910b5f6c213ba4999c2fc47a6d56c6c667f3dd787e1c518ce1cfe44f30b0"
counter=0;commands=[]
def run(label,cmd,input_bytes=b""):
    global counter
    counter+=1
    result=bounded.command(cmd,cwd=W,environment=env,timeout=30,directory=C/f"{counter:02d}-{label}",input_bytes=input_bytes,output_limit=8*1024*1024)
    commands.append({"label":label,"receipt":record(result.directory/"receipt.json")})
    bounded.require(result);return result.stdout.decode().strip()
def git(root,*args):return run("git",["git","-c","safe.directory="+root.as_posix(),"-C",str(root),*args])
rows=[]
for row in plan["merged_source_files"]:
    path=W/row["path"];raw=path.read_bytes()
    assert len(raw)==row["bytes"] and sha(raw)==row["raw_sha256"]
    normalized=raw if row["normalization"]=="raw" else raw.replace(bytes((13,10)),bytes((10,)))
    python_blob=hashlib.sha1(b"blob "+str(len(normalized)).encode()+bytes((0,))+normalized).hexdigest()
    actual_git_blob=run("hash-object",["git","-c","safe.directory="+W.as_posix(),"hash-object","--no-filters","--stdin"],normalized)
    assert actual_git_blob==python_blob==row["git_blob"],row["path"]
    rows.append(dict(row,python_blob=python_blob,actual_git_hash_object=actual_git_blob,
                     normalized_sha256=sha(normalized),raw_input_unchanged=True))
sources=[]
for item in [plan["source_checkpoint"],*plan["provider_sources"]]:
    root=Path(item["root"]);current={"name":item["name"],"head":git(root,"rev-parse","HEAD"),"tree":git(root,"rev-parse","HEAD^{tree}"),"status":git(root,"status","--porcelain=v1")}
    assert current["head"]==item["commit"] and current["tree"]==item["tree"] and current["status"]==""
    current["ref"]=git(root,"symbolic-ref","HEAD") if item["ref"]!="detached stable source" else git(root,"rev-parse","--abbrev-ref","HEAD")
    assert current["ref"]==(item["ref"] if item["ref"]!="detached stable source" else "HEAD")
    sources.append(current)
assert git(W,"diff","--cached","--name-only")==""
for row in plan["stable_inputs"]+plan["supervisor_source_files"]:
    assert sha((W/row["path"]).read_bytes())==row["sha256"]
for name in ("ownership_marker","review_receipt","source_merge_receipt","source_merge_approval","source_commit_review"):
    assert sha(Path(plan[name]["path"]).read_bytes())==plan[name]["sha256"]
fresh=[]
for value in [plan["write_scope"][key] for key in ("new_work","new_control","new_build")]+plan["write_scope"]["named_retained_fixtures"]:
    path=Path(value)
    assert not path.exists() and not path.is_symlink() and path.resolve().is_relative_to(T.resolve())
    fresh.append({"path":value,"absent":True,"contained":True})
assert not (E/"canary-command").exists()
new_execution=T/"evidence/c5-execution-2"
assert not new_execution.exists() and new_execution.resolve().is_relative_to(T.resolve())
old_script=E/"execute-c5.py"
bad_lines=[line for line in old_script.read_text().splitlines() if line.strip().startswith(("normalized=raw if row","blob=hashlib.sha1"))]
snippet="""def normalized_git_blob(raw, normalization):
    if normalization not in ("raw", "CRLF_to_LF"):
        raise ValueError("unsupported source normalization")
    normalized = raw if normalization == "raw" else raw.replace(bytes((13, 10)), bytes((10,)))
    return hashlib.sha1(b"blob " + str(len(normalized)).encode() + bytes((0,)) + normalized).hexdigest()
"""
(O/"corrected-preflight.py").write_text("import hashlib\n\n"+snippet,encoding="utf-8",newline="\n")
scope={};exec(compile((O/"corrected-preflight.py").read_text(),str(O/"corrected-preflight.py"),"exec"),scope)
for row in rows:assert scope["normalized_git_blob"]((W/row["path"]).read_bytes(),row["normalization"])==row["actual_git_hash_object"]
diagnosis={"schema":"facman.c5-predispatch-preflight-diagnosis.v1","result":"CONFIRMED_ORCHESTRATION_BYTE_LITERAL_DEFECT",
"original_plan":record(plan_path),"original_execution":record(E/"execution.json"),"original_script":record(old_script),
"original_adapter":record(E/"prepare-and-execute.py"),"original_failure_traceback":record(E/"failure.txt"),
"bad_emitted_lines":bad_lines,"cause":"Generated byte literals represented backslash-r/backslash-n and backslash-zero rather than actual CRLF/LF/NUL bytes. The first raw digest matched; the synthetic Git object computation failed.",
"actual_git_oracle":"git hash-object --no-filters --stdin over explicitly supported normalized bytes, without -w, path attributes or clean filters",
"source_inputs":rows,"sources":sources,"corrected_preflight":record(O/"corrected-preflight.py"),
"all30_actual_git_and_python_results_match_reviewed_blobs":True,"new_effect_paths":fresh,
"canary_build_test_and_readback_dispatched":False,"execution_evidence_only_created":True,"production_source_index_refs_unchanged":True,
"new_execution_evidence":{"path":str(new_execution),"absent":True,"contained":True},"commands":commands}
save("diagnosis.json",diagnosis)
prereq={"schema":"facman.c5-successor-prerequisites.v1","diagnosis":record(O/"diagnosis.json"),"sources":sources,
"all30_actual_git_blob_oracles_pass":True,"source_inputs":rows,"stable_inputs":plan["stable_inputs"],"supervisor_source_files":plan["supervisor_source_files"],
"fresh_paths":fresh,"new_execution_evidence":{"path":str(new_execution),"absent":True,"contained":True},
"original_failed_preflight_retained":record(E/"execution.json"),"build_or_test_dispatched":False}
save("prerequisites.json",prereq)
successor=json.loads(plan_path.read_bytes())
successor["schema"]="facman.c5-successor-empty-build-canary-plan.v1"
successor["status"]="prepared_for_ROOT_review_no_effectful_dispatch"
successor["write_scope"]["external_execution_evidence"]=str(new_execution)
successor["prerequisites_sha256"]=record(O/"prerequisites.json")["sha256"]
successor["prior_predispatch_failure"]={key:diagnosis[key] for key in ("original_plan","original_execution","original_script","original_adapter","original_failure_traceback")}
successor["corrected_preflight"]=record(O/"corrected-preflight.py")
successor["preflight_diagnosis"]=record(O/"diagnosis.json")
successor["successor_delta"]="Only the corrected external literal-byte preflight and new absent execution-evidence directory. Original c5/control/native/fixture effect paths, allsource/providers, numeric limits, actual command vectors, TEMP and tracking are unchanged. Requires new ROOT approval before dispatch."
save("canary-plan.json",successor)
successor_sha=record(O/"canary-plan.json")["sha256"]
text=old_script.read_text(encoding="utf-8")
text=text.replace('PLAN_DIR = TASK / "evidence/c5-plan"','PLAN_DIR = TASK / "evidence/c5-preflight-correction"')
text=text.replace('E = TASK / "evidence/c5-execution"','E = TASK / "evidence/c5-execution-2"')
text=text.replace("d36dc1e3beeb107151cbd9dcebecc123092d8638d3ab66d1935adbb55915efa1",successor_sha)
old_assert='assert digest(PLAN_DIR/"root-review.json")=="3dea41c7b3bc28192c4f40e2e8dda6ceb2ed48d8e205240f9a0aebf8a0b76f36"'
assert text.count(old_assert)==1
text=text.replace(old_assert,'assert read_json(PLAN_DIR/"root-review.json")["plan_sha256"]==digest(PLAN_DIR/"canary-plan.json")')
lines=text.splitlines()
for i,line in enumerate(lines):
    if line.strip().startswith("normalized=raw if row"):
        lines[i]='        normalized=raw if row["normalization"]=="raw" else raw.replace(bytes((13,10)),bytes((10,)))'
    if line.strip().startswith("blob=hashlib.sha1"):
        lines[i]='        blob=hashlib.sha1(b"blob "+str(len(normalized)).encode()+bytes((0,))+normalized).hexdigest()'
text="\n".join(lines)+"\n"
compile(text,str(O/"execute-c5-corrected.py"),"exec")
(O/"execute-c5-corrected.py").write_text(text,encoding="utf-8",newline="\n")
for name in ("canary_command","compiled_identity_command","finite_execution","environment","provider_sources","source_checkpoint","merged_source_files","stable_inputs","supervisor_source_files"):
    assert successor[name]==plan[name],name
proposal={"schema":"facman.c5-corrected-preflight-successor-proposal.v1","status":"prepared_not_executed",
"successor_plan":record(O/"canary-plan.json"),"diagnosis":record(O/"diagnosis.json"),"prerequisites":record(O/"prerequisites.json"),
"minimal_preflight":record(O/"corrected-preflight.py"),"complete_corrected_external_script":record(O/"execute-c5-corrected.py"),
"original_failed_receipt":record(E/"execution.json"),"original_plan_and_script_preserved":True,
"new_execution_evidence":str(new_execution),"same_six_effect_paths_still_absent":True,"actual_git_hash_object_30_of_30":"PASS",
"effectful_dispatches_so_far":0,"corrected_dispatch_executed":False,"required_new_ROOT_review_fields":["plan_sha256","reviewed_merge_parents"],
"approval_guard":"Before any corrected dispatch, the invoking tool must independently verify ROOT's new approval receipt SHA256 and this prepared script SHA256; script rechecks the approved successor-plan digest.",
"no_production_source_settings_or_numeric_budget_change":True,"no_C4_or_other_output_reuse":True,"no_public_operation":True}
save("successor-proposal.json",proposal)
print(json.dumps({"proposal":record(O/"successor-proposal.json"),"successor_plan":record(O/"canary-plan.json"),"diagnosis":record(O/"diagnosis.json"),
"script":record(O/"execute-c5-corrected.py"),"actual_git_oracles_passed":len(rows),"effectful_dispatches":0}),flush=True)
