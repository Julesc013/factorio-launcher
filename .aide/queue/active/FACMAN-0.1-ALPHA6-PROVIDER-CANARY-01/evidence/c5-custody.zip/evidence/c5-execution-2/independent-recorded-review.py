from pathlib import Path
import hashlib,json,struct,subprocess,zipfile,re
E=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-b48460c353\evidence\c5-execution-2');T=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-b48460c353');R=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\worktrees\task-facman-provider-canary-01')
HEAD='7dafa130225dadae824c377b76140622486c39b8';TREE='71d941bb1ccb5d54985cc49df3bdbc3367146408'
def sha(b):return hashlib.sha256(b).hexdigest()
def fh(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def pairs(rows):
 d={}
 for k,v in rows:
  if k in d:raise ValueError('duplicate key')
  d[k]=v
 return d
def j(p):
 b=Path(p).read_bytes();assert len(b)<=8*1024*1024
 return json.loads(b.decode('utf-8'),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError('nonfinite')))
def git(root,*a):return subprocess.check_output(['git','-C',str(root),*a],timeout=30)
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
refs={}
def pin(p,expected=None):
 p=Path(p);row={'path':str(p),'bytes':p.stat().st_size,'sha256':fh(p)}
 if expected:assert row['sha256']==expected,p
 refs[str(p)]=row;return row
h=j(E/'review-handoff.json');ex=j(E/'execution.json');cp=T/'evidence/c5-preflight-correction';plan=j(cp/'canary-plan.json')
pin(cp/'canary-plan.json',ex['plan_sha256']);pin(cp/'root-review.json',ex['root_review_sha256'])
for key in ('review_receipt','ownership_marker','source_merge_receipt','source_merge_approval','source_commit_review'):
 pin(plan[key]['path'],plan[key]['sha256'])
assert ex['automatic_retries']==0 and ex['no_retry_performed'] is True and ex['source_and_pins_unchanged'] is True
assert all(v is False for v in ex['authority'].values()) and ex['effects']=='possible_retained'
before=j(E/'before.json');after=j(E/'after.json');assert after['matches_before'] is True and before['observation']==after['observation']
assert len(before['fresh_paths'])==6 and all(x['absent'] is True and x['contained'] is True and Path(x['path']).is_relative_to(T) for x in before['fresh_paths'])
for row in plan['merged_source_files']:
 b=(R/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['raw_sha256']
 normalized=b if row['normalization']=='raw' else b.replace(b'\r\n',b'\n')
 assert row['normalization'] in ('raw','CRLF_to_LF') and blob(normalized)==row['git_blob']
assert len(plan['merged_source_files'])==30
oldpin=pin(h['original_failed_preflight']['path'],h['original_failed_preflight']['sha256']);old=j(oldpin['path'])
assert old['result']=='failed_retained' and old['retained_paths']==[] and old['automatic_retries']==0
obs=j(T/'c5/evidence/observation.json');supervision=j(T/'c5-control/supervision.json')
pin(T/'c5/evidence/observation.json',supervision['observation_sha256']);pin(T/'c5-control/supervision.json')
assert supervision['result']=='supervised_source_static_consumer_pass' and obs['result']=='source_static_consumer_pass'
assert obs['source_consumption_only'] is True and obs['stable_inputs_unchanged'] is True and obs['consumer_source_unchanged'] is True
assert obs['stable_inputs_before']==obs['stable_inputs_after'] and len(obs['stable_inputs_before'])==5
for n,d in obs['stable_inputs_before'].items():pin(R/n,d)
assert obs['consumer_source_before']==obs['consumer_source_after'] and obs['consumer_source_before']['head']==HEAD and obs['consumer_source_before']['status']==''
bounds=obs['physical_source_observations']
assert [b['boundary'] for b in bounds]==['before_configure','before_build','after_build','after_tests']
phys=bounds[0]['observation'];assert all(b['observation']==phys for b in bounds) and phys['atomic_build_lease'] is False and len(phys['files'])==286
usk=Path(h['providers'][0]['root']);tree_entries={}
for rec in git(usk,'ls-tree','-r','-z',h['providers'][0]['commit']).split(b'\0'):
 if not rec:continue
 info,n=rec.split(b'\t',1);mode,kind,oid=info.split();assert kind==b'blob' and mode in (b'100644',b'100755');tree_entries[n.decode()]=oid.decode()
assert set(tree_entries)=={x['path'] for x in phys['files']}
for row in phys['files']:
 b=(usk/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['raw_sha256']
 assert row['normalization'] in ('raw','utf8_crlf_to_lf_v1')
 normalized=b if row['normalization']=='raw' else b.replace(b'\r\n',b'\n')
 assert blob(normalized)==row['git_blob']==tree_entries[row['path']]
stepnames=['configure','build','native','self-setup-stored','self-setup-deflate']
assert [x['name'] for x in obs['steps']]==stepnames
for row in obs['steps']:
 pin(row['receipt'],row['sha256']);receipt=j(row['receipt']);assert receipt['exit_code']==row['exit_code']==0 and receipt['termination']=='completed' and receipt['primary_stopped'] is True and receipt['job_empty_observed'] is True
 assert receipt['configured_seconds']<=900
for row in obs['executables']:pin(T/'c5/native'/row['path'],row['sha256'])
assert len(obs['executables'])==8
configure=obs['steps'][0]['command'];buildcmd=obs['steps'][1]['command']
assert '-DFACMAN_PROVIDER_MODE=source' in configure and '-DFACMAN_PROVIDER_SOURCE_LINKAGE=static' in configure
assert buildcmd[buildcmd.index('--parallel')+1]=='4'
native=(T/'c5/evidence/native/stdout.raw').read_text();assert '100% tests passed, 0 tests failed out of 4' in native
for n in ('flb_factorio_setup_recipe_smoke','flb_setup_gateway_smoke','fl_transaction_session_smoke','fl_archive_core_smoke'):assert n in native
identity_receipt=Path(ex['identity_command']['receipt']);pin(identity_receipt,ex['identity_command']['sha256'])
identity_cmd=j(identity_receipt);response=j(identity_receipt.parent/'stdout.raw')
oracle=plan['compiled_identity_oracle']
def equal(actual,expected):
 assert type(actual) is dict
 for k,v in expected.items():assert k in actual and type(actual[k]) is type(v) and actual[k]==v,(k,actual.get(k),v)
equal(response,oracle['envelope']);equal(response['payload'],oracle['payload'])
backend=response['payload']['backend_identity'];equal(backend,{'schema':oracle['backend_schema']})
identity_file=T/'c5/native/facman-build-identity.v1.txt';pin(identity_file,ex['compiled_identity_oracle']['build_identity_file_sha256'])
expected=dict(oracle['build']);expected['build_identity']=identity_file.read_text().strip();equal(backend['build'],expected)
fields={}
for term in expected['build_identity'].split(';'):
 k,v=term.split('=',1);assert k not in fields;fields[k]=v
for k,v in {'facman':HEAD,'universal_setup':h['providers'][0]['commit'],'universal_launcher':h['providers'][1]['commit'],'provider_mode':'source','provider_source_linkage':'static','provider_lock_kind':'sdk_candidate','provider_candidate_differs_from_tracked':'true','provider_release_identity_coherent':'false','provider_consumption_classification':'sdk_candidate_source','source_dirty':'false'}.items():assert fields[k]==v
equal(backend['package'],oracle['package_expectation']);assert backend['package']['mode']=='source_checkout' and backend['package']['verified'] is False and backend['package']['integrity']=='not_packaged'
assert backend['run_execute']['enabled'] is False and response['effects']==[] and response['operation']['effects_may_have_occurred'] is False
assert not Path(identity_cmd['command'][2]).exists()
version=(R/'runtime/core/generated/version.h').read_text();digest=hashlib.sha256();schema_count=0
for p in sorted((R/'contracts/schema').rglob('*'),key=lambda p:p.relative_to(R).as_posix()):
 if p.is_file():
  b=p.read_bytes().replace(b'\r\n',b'\n').replace(b'\r',b'\n');digest.update(p.relative_to(R).as_posix().encode()+b'\0'+b+b'\0');schema_count+=1
assert schema_count==416 and digest.hexdigest()==backend['contract_set_sha256']==oracle['contract_constants']['FACMAN_CONTRACT_SET_SHA256']
for name,key in [('FACMAN_COMMAND_CATALOG_SHA256','command_catalog_sha256'),('FACMAN_CONTRACT_SET_SHA256','contract_set_sha256')]:
 assert re.search(r'#define '+name+r' "([0-9a-f]{64})"',version).group(1)==backend[key]
calls_summary=[];expected_ops=[('install',4),('install',4),('install',0),('install',0),('verify',0),('verify',0),('repair',0),('verify',0),('uninstall',4),('uninstall',0)]
for mode in ('stored','deflate'):
 root=T/('t/c5-'+mode);package=root/'setup-payload.zip';raw=package.read_bytes()
 with zipfile.ZipFile(package) as z:
  infos=z.infolist();assert len(infos)==4 and all(x.compress_type==(0 if mode=='stored' else 8) for x in infos)
  z.testzip()
  assert z.read('facman/maintenance/FacManSetup.exe')==(T/'c5/native/Release/FacManSetup.exe').read_bytes()
  first=infos[0];local=first.header_offset;central=z.start_dir
  assert z.read(next(n for n in z.namelist() if n.endswith('/bin/facman.exe')))==b'synthetic-cli-v1\n'
  assert z.read(next(n for n in z.namelist() if n.endswith('/FacMan.exe')))==b'synthetic-gui-v1\n'
 bad=bytearray(raw);struct.pack_into('<I',bad,local+14,first.CRC^1);struct.pack_into('<I',bad,central+16,first.CRC^1)
 for name,expected_bytes in [('bad-crc',bytes(bad)),('truncated',raw[:-8])]:
  case=root/name;assert (case/'payload.zip').read_bytes()==expected_bytes and (case/'foreign.txt').read_bytes()==b'preserve foreign fixture bytes\n' and not (case/'target').exists()
  effects=j(case/'refusal-effects.json');pin(case/'refusal-effects.json')
  assert effects['target_exists'] is False and effects['response']['status']=='error'
  actual={p.relative_to(case).as_posix():fh(p) for p in case.rglob('*') if p.is_file() and p.name!='refusal-effects.json'}
  assert actual=={x['path']:x['sha256'] for x in effects['files']}
  error=effects['response']['error']
  if name=='bad-crc':
   assert error['code']=='self_setup_provider_refused';detail=json.loads(error['detail'],object_pairs_hook=pairs);assert detail['error']['code']=='lifecycle_refused' and detail['error']['message']=='ZIP streaming payload CRC does not match reviewed metadata'
   try:
    with zipfile.ZipFile(case/'payload.zip') as broken:broken.read(first.filename)
   except zipfile.BadZipFile:pass
   else:raise AssertionError('Independent CRC oracle failed to reject changed metadata')
  else:assert error['code']=='self_setup_payload_invalid'
 records=sorted((root/'calls').glob('*.json'));assert len(records)==10;responses=[]
 for i,p in enumerate(records):
  c=j(p);assert (c['command'][1],c['exit_code'])==expected_ops[i]
  assert '--no-shell-integration' in c['command'] and c['command'][0]==str(T/'c5/native/Release/FacManSetup.exe')
  for flag in ('--root','--state-root','--acceptance-root'):
   assert Path(c['command'][c['command'].index(flag)+1]).is_relative_to(root)
  resp=j(p.with_suffix('.stdout'));responses.append(resp);assert p.with_suffix('.stderr').read_bytes()==b''
 assert responses[2]['phase']=='plan' and responses[3]['phase']=='receipt'
 assert [responses[x]['provider']['payload']['status'] for x in (4,5,6,7,9)]==['pass','fail','completed','pass','completed']
 assert responses[8]['status']=='error'
 assert not (root/'Programs/FacMan').exists() and (root/'FacManWorkspace/keep.txt').read_text()=='preserve\n' and (root/'SetupState').is_dir()
 calls_summary.append({'mode':mode,'recorded_calls':10,'synthetic_payload':True,'compression':mode,'original_bytes':len(raw),'original_sha256':sha(raw),'CRC_semantic_refusal':True,'truncation_structural_refusal':True,'native_shell_integration_requested':False,'foreign_sentinels_unchanged':True})
ft=h['FileTracker_observation'];pin(ft['path'],ft['sha256']);pin(ft['product_object']['path'],ft['product_object']['sha256'])
lines=Path(ft['path']).read_text(encoding='utf-16').splitlines();key='^'+ft['product_source_record'];assert lines.count(key)==1
start=lines.index(key)+1;end=next((n for n in range(start,len(lines)) if lines[n].startswith('^')),len(lines));deps=lines[start:end]
assert len(deps)==152 and all(str(R).upper() not in x.upper() for x in deps) and not any('BUILD_IDENTITY' in x.upper() for x in deps)
assert Path(ft['path']).parent.parent==Path(ft['product_object']['path']).parent
for r in j(E/'artifact-custody.json')['files']:assert Path(r['path']).stat().st_size==r['bytes'] and fh(r['path'])==r['sha256']
for r in h['source_stable_inputs']:assert fh(r['path'])==r['sha256']
assert git(R,'rev-parse','HEAD').decode().strip()==HEAD and git(R,'status','--porcelain=v1')==b'' and git(R,'diff','--cached','--name-only')==b''
out={'schema':'facman.c5-independent-recorded-execution-review.v1','verdict':'PASS_BOUNDED_SOURCE_STATIC_RECORDED_RUN','source_commit':HEAD,'source_tree':TREE,'physical_provider_source_files':286,'identical_observation_boundaries':4,'merged_source_inputs':30,'stable_inputs':5,'native_suites':4,'setup_lifecycle':calls_summary,'typed_response_sha256':fh(identity_receipt.parent/'stdout.raw'),'typed_build':backend['build'],'package_mode':'source_checkout','package_verified':False,'contract_schema_count':schema_count,'contract_digest':digest.hexdigest(),'FileTracker':{'product_translation_unit_only':True,'system_dependency_count':152,'worktree_dependency_count':0,'generated_build_identity_header_tracked':False,'fresh_build_only':True},'recorded_elapsed_seconds':ex['elapsed_shared_budget_seconds'],'first_effectful_source_static_dispatches':1,'automatic_retries':0,'original_failed_preflight':oldpin,'references':list(refs.values()),'source_index_unchanged':True,'limits':['No replay/build/tool effects executed by independent reviewer.','Synthetic Stored/Deflate setup payloads contain synthetic GUI/CLI bytes; no actual product package or installed SDK qualification.','Fresh local source/static candidate is explicitly incoherent with stable release pins and package.verified=false; no provider adoption.','No C4 or P6 transfer, GUI/game/hosted/release claim.','Four sequential source observations are not a build lease; FileTracker omission remains for incremental AppData builds.','Owned jobs closed in these recorded executions; abrupt outer supervisor death before assignment remains unqualified.']}
with (E/'independent-recorded-review.json').open('x',encoding='utf-8') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps(pin(E/'independent-recorded-review.json')))
