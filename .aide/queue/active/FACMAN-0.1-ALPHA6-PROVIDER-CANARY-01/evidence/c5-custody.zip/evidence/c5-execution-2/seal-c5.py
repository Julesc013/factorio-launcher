import hashlib,json,os,stat,sys,time,zipfile
from pathlib import Path
R=Path(r"C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29")
T=R/"tasks/facman-0.1-al-b48460c353";E=T/"evidence/c5-execution-2";PLAN=T/"evidence/c5-preflight-correction"
plan=json.loads((PLAN/"canary-plan.json").read_bytes());W=Path(plan["source_checkpoint"]["root"])
sys.path.insert(0,str(W))
from tools import provider_canary_process as bounded
def sha(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for data in iter(lambda:f.read(1024*1024),b""):h.update(data)
    return h.hexdigest()
def record(path):return {"path":str(path),"bytes":path.stat().st_size,"sha256":sha(path)}
assert sha(E/"execution.json")=="79883f240b736f5576b32ebdae8fec0158f89729dbb6ee56810357eb1bcf14f5"
execution=json.loads((E/"execution.json").read_bytes())
assert execution["result"]=="source_static_and_compiled_identity_pass_pending_independent_review"
original_failure=T/"evidence/c5-execution/execution.json"
assert sha(original_failure)=="0774910b5f6c213ba4999c2fc47a6d56c6c667f3dd787e1c518ce1cfe44f30b0"
worker=json.loads((T/"c5/evidence/observation.json").read_bytes())
supervisor=json.loads((T/"c5-control/supervision.json").read_bytes())
assert worker["result"]=="source_static_consumer_pass" and supervisor["result"]=="supervised_source_static_consumer_pass"
assert [row["name"] for row in worker["steps"]]==["configure","build","native","self-setup-stored","self-setup-deflate"]
assert all(row["termination"]=="completed" and row["exit_code"]==0 for row in worker["steps"])
assert supervisor["observation_sha256"]==sha(T/"c5/evidence/observation.json")
env=dict(os.environ);env.update(plan["environment"]);os.environ.update(plan["environment"])
result=bounded.command([plan["canary_command"][0],str(W/"tools/workspace_hygiene.py"),"doctor","--measure","--max-task-roots","10"],
cwd=W,environment=env,timeout=60,directory=E/"post-hygiene",output_limit=8*1024*1024)
bounded.require(result)
started=time.monotonic()
current_roots=[T/"c5",T/"c5-control",T/"t/c5-stored",T/"t/c5-deflate",T/"t/c5-identity-workspace",E]
historical_roots=[T/"evidence/c5-plan",T/"evidence/c5-execution",PLAN]
files=[]
for root in current_roots+historical_roots:
    if not root.exists():continue
    for current,dirs,names in os.walk(root,followlinks=False):
        for name in dirs+names:
            path=Path(current)/name;info=path.lstat()
            if getattr(info,"st_file_attributes",0)&stat.FILE_ATTRIBUTE_REPARSE_POINT:raise ValueError("fixture indirection: "+str(path))
        files.extend(Path(current)/name for name in names)
        if len(files)>25000:raise ValueError("artifact count cap")
files=sorted(set(files),key=lambda p:str(p).lower())
if sum(p.stat().st_size for p in files)>4*1024**3:raise ValueError("artifact byte cap")
rows=[]
for path in files:
    if time.monotonic()-started>300:raise ValueError("custody observation deadline")
    before=path.stat();row=record(path);after=path.stat()
    assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)
    row["relative_path"]=path.relative_to(T).as_posix()
    row["phase"]="current_C5" if any(path.is_relative_to(root) for root in current_roots) else "retained_preflight_admission_diagnosis"
    rows.append(row)
source_names={row["path"] for row in plan["stable_inputs"]+plan["supervisor_source_files"]+plan["merged_source_files"]}
sources=[]
for name in sorted(source_names):
    path=W/name;row=record(path);row["relative_path"]=name;sources.append(row)
for row in plan["stable_inputs"]+plan["supervisor_source_files"]:assert sha(W/row["path"])==row["sha256"]
for row in plan["merged_source_files"]:assert sha(W/row["path"])==row["raw_sha256"]
products=[path for path in files if path.name=="product.obj"]
assert len(products)==1
product=products[0];logs=list(product.parent.glob("*/CL.read.1.tlog"));assert len(logs)==1
tlog=logs[0];sections={};key=None
for line in tlog.read_bytes().decode("utf-16").splitlines():
    if line.startswith("^"):key=line[1:];sections[key]=[]
    elif line and key is not None:sections[key].append(line)
matches=[(key,values) for key,values in sections.items() if key.upper().endswith("\\APPLICATION\\HANDLERS\\PRODUCT.CPP")]
assert len(matches)==1
source_record,deps=matches[0]
tracker={"path":str(tlog),"sha256":sha(tlog),"product_object":record(product),"product_source_record":source_record,
"product_dependency_count":len(deps),"product_worktree_dependency_count":sum(str(W).lower() in row.lower() for row in deps),
"contains_generated_build_identity_header":any("build_identity.hpp" in row.lower() for row in deps),
"source_record_keys_excluded_from_dependency_count":True,
"meaning":"Actual product.cpp translation-unit section bound from its product.obj parent. Fresh compiled readback passes; this does not qualify incremental AppData rebuilding."}
closed=[];counts={"current_C5":0,"retained_preflight_admission_diagnosis":0}
for row in rows:
    path=Path(row["path"])
    if path.name!="receipt.json":continue
    try:value=json.loads(path.read_bytes())
    except (ValueError,UnicodeError):continue
    if value.get("schema")!="facman.canary-command.v1":continue
    assert value["termination"]=="completed" and value.get("job_empty_observed") is True and value.get("primary_stopped") is True
    closed.append({"path":str(path),"sha256":row["sha256"],"phase":row["phase"],"termination":value["termination"],
                   "exit_code":value["exit_code"],"primary_stopped":True,"job_empty_observed":True})
    counts[row["phase"]]+=1
inventory={"schema":"facman.c5-artifact-custody.v1","file_count":len(rows),"total_bytes":sum(row["bytes"] for row in rows),"files":rows,
"source_inputs":sources,"closed_command_receipts":closed,"closed_command_counts_by_phase":counts,"FileTracker_observation":tracker,
"original_failed_preflight":record(original_failure),"current_execution":record(E/"execution.json"),
"scope":"Sequential closed-file custody, not an atomic source/build/namespace lease. Prior metadata-only failed preflight and one separately reviewed successful effectful C5 dispatch are preserved distinctly."}
bounded.write_json(E/"artifact-custody.json",inventory)
selected=[]
for path in files:
    native=path.is_relative_to(T/"c5/native")
    if (not native or path.suffix.lower() in (".exe",".tlog") or path.name in ("product.obj","build_identity.hpp","facman-build-identity.v1.txt","CMakeCache.txt") or path.is_relative_to(T/"c5/native/Testing")):
        selected.append((path,path.relative_to(T).as_posix()))
selected += [(W/name,"source-inputs/"+name) for name in sorted(source_names)]
selected.append((E/"artifact-custody.json","evidence/c5-execution-2/artifact-custody.json"))
members=[];archive=E/"c5-raw-custody.zip"
with zipfile.ZipFile(archive,"x",zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for path,name in selected:
        raw=path.read_bytes();z.writestr(name,raw)
        members.append({"member":name,"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()})
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())=={row["member"] for row in members}
    for row in members:
        raw=z.read(row["member"]);assert len(raw)==row["bytes"] and hashlib.sha256(raw).hexdigest()==row["sha256"]
bounded.write_json(E/"archive-member-map.json",{"schema":"facman.c5-selected-raw-archive.v1","archive":record(archive),"members":members,
"selection":"Original and successor plans/reviews, unchanged failed preflight, actual Git normalization diagnosis, all execution/fixture records, actual EXEs, native tlogs, product.obj, build identities/cache and43 source/stable inputs. Remaining mapped native objects/libraries stay in the owned c5 tree.",
"raw_byte_policy":"All archive members retain exact original bytes; no line-ending normalization occurs in custody.",
"not_exhaustive_task_root_archive":True,"no_publication":True})
handoff={"schema":"facman.c5-review-handoff.v1","result":"PASS_SOURCE_STATIC_ONLY_PENDING_INDEPENDENT_REVIEW","execution":record(E/"execution.json"),
"artifact_custody":record(E/"artifact-custody.json"),"archive_map":record(E/"archive-member-map.json"),"archive":record(archive),
"source":plan["source_checkpoint"],"providers":plan["provider_sources"],"source_stable_inputs":sources,
"original_failed_preflight":record(original_failure),"preflight_correction_approval":record(PLAN/"root-review.json"),
"first_effectful_dispatches":1,"automatic_retries":0,
"source_static_elapsed_seconds":json.loads((E/"canary-command/receipt.json").read_bytes())["elapsed_seconds"],
"shared_dispatch_readback_elapsed_seconds":execution["elapsed_shared_budget_seconds"],
"tests":{"native_suites":4,"stored_lifecycle":"PASS","deflate_lifecycle":"PASS","CRC_and_truncation_causal_negatives":"PASS",
"typed_compiled_identity":"PASS","source_dirty":False,"source_pins_and_30merged_inputs_unchanged":True},
"artifact_count":len(rows),"artifact_bytes":inventory["total_bytes"],"archived_members":len(members),
"closed_owned_command_counts_by_phase":counts,"FileTracker_observation":tracker,
"production_candidate_release_authority":False,
"ceilings":["Windows source/static only; no installed/shared/relocated SDK or provider adoption","No GUI/fullruntime/package/Factorio/human/release qualification",
"Sequential source observations, not an atomic build lease","Fresh empty build only; no incremental AppData qualification or C4/p6 reuse",
"Top-supervisor abrupt pre-job-assignment death remains unqualified","No automatic retry/settings/public action; original failed preflight retained"],
"review_instructions":"Read original-byte map/archive and actual typed response. All current command logs are closed. Preserve prior failed E and source7dafa. Do not rerun fixture names or rebuild existing c5 outputs during original-byte binding."}
bounded.write_json(E/"review-handoff.json",handoff)
print(json.dumps({"handoff":record(E/"review-handoff.json"),"artifacts":len(rows),"members":len(members),"source_inputs":len(sources),
"archive":record(archive),"closed_commands":counts,"FileTracker":tracker}),flush=True)
