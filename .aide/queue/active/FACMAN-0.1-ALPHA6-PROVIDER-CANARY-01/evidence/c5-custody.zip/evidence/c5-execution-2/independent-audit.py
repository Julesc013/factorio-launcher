from pathlib import Path
import hashlib,json,stat,subprocess,zipfile
E=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-b48460c353\evidence\c5-execution-2');T=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\tasks\facman-0.1-al-b48460c353');R=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\factorio-launcher-5db2844e2f29\worktrees\task-facman-provider-canary-01')
def fh(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def j(p):return json.loads(Path(p).read_bytes())
def ref(p):p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':fh(p)}
def save(n,d):
 with (E/n).open('x',encoding='utf-8') as f:json.dump(d,f,indent=2);f.write('\n')
 return ref(E/n)
def git(root,*a):return subprocess.check_output(['git','-C',str(root),*a],timeout=30).decode().strip()
h=j(E/'review-handoff.json');assert fh(E/'review-handoff.json')=='e0079151ccc95e74b8624605f8932b5779a668c182125f173639f1ad69c1e626'
save('independent-audit-plan.json',{'scope':'Read-only original artifact/archive/source/typed-output and recorded-process audit. No rebuild, fixture or product replay.','handoff':ref(E/'review-handoff.json'),'write_scope':'New independent-* files only in this existing evidence directory.'})
for k in ('execution','artifact_custody','archive_map','archive','original_failed_preflight','preflight_correction_approval'):
 row=h[k];assert ref(row['path'])=={k:row[k] for k in ('path','bytes','sha256')},k
observations=[]
for row in [h['source'],*h['providers']]:
 actual={'root':row['root'],'commit':git(row['root'],'rev-parse','HEAD'),'tree':git(row['root'],'rev-parse','HEAD^{tree}'),'status':git(row['root'],'status','--porcelain=v1')}
 assert actual['commit']==row['commit'] and actual['tree']==row['tree'] and actual['status']==''
 observations.append(actual)
assert git(R,'show','-s','--format=%P','HEAD').split()==['afc8c267b60e91b62ab98308751ff5dd3d349db0','f9d27901ede83d1ac21176dd36e35ceadc633881']
assert git(R,'diff','--cached','--name-only')==''
c=j(h['artifact_custody']['path']);seen=set();total=0
by_relative={}
for row in c['files']:
 p=Path(row['path']);assert p.is_relative_to(T) and str(p).casefold() not in seen
 seen.add(str(p).casefold());s=p.lstat();assert stat.S_ISREG(s.st_mode) and not s.st_file_attributes&stat.FILE_ATTRIBUTE_REPARSE_POINT,p
 assert s.st_size==row['bytes'] and fh(p)==row['sha256'],p
 assert p.relative_to(T).as_posix()==row['relative_path'];by_relative[row['relative_path']]=row;total+=s.st_size
assert len(seen)==c['file_count']==h['artifact_count']==2464 and total==c['total_bytes']==h['artifact_bytes']==293084533
assert c['source_inputs']==h['source_stable_inputs'] and len(c['source_inputs'])==43
for row in c['source_inputs']:
 p=Path(row['path']);assert p==R/row['relative_path'] and p.stat().st_size==row['bytes'] and fh(p)==row['sha256']
am=j(h['archive_map']['path']);assert am['archive']==h['archive']
with zipfile.ZipFile(h['archive']['path']) as z:
 assert len(z.infolist())==len(am['members'])==1721 and len(set(z.namelist()))==1721
 for row in am['members']:
  n=row['member'];assert not n.startswith('/') and '..' not in Path(n).parts and ':' not in n
  b=z.read(n);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
  p=R/n.removeprefix('source-inputs/') if n.startswith('source-inputs/') else T/n
  assert p.read_bytes()==b,p
counts={}
for row in c['closed_command_receipts']:
 p=Path(row['path']);assert fh(p)==row['sha256'];r=j(p)
 assert r['schema']=='facman.canary-command.v1' and r['termination']==row['termination'] and r['exit_code']==row['exit_code']
 assert r['primary_stopped'] is row['primary_stopped'] is True and r['job_empty_observed'] is row['job_empty_observed'] is True
 assert r['environment_values_logged'] is False
 for key in ('stdout','stderr'):
  v=r[key];raw=p.parent/v['file'];assert raw.stat().st_size==v['captured_bytes'] and fh(raw)==v['sha256']
  assert v['captured_bytes']<=r['output_limit_per_stream']
 counts[row['phase']]=counts.get(row['phase'],0)+1
assert counts==c['closed_command_counts_by_phase']==h['closed_owned_command_counts_by_phase']=={'current_C5':171,'retained_preflight_admission_diagnosis':88}
save('independent-initial-custody.json',{'schema':'facman.c5-independent-initial-custody.v1','status':'PASS','observations':observations,'original_files':2464,'original_bytes':total,'source_inputs':43,'archive_members':1721,'closed_commands':counts,'handoff':ref(E/'review-handoff.json'),'archive':ref(h['archive']['path']),'scope':'No code or fixture execution. Current C5 phase distinguished from retained failed preflight/admission diagnostics.'})
print(json.dumps(ref(E/'independent-initial-custody.json')))
