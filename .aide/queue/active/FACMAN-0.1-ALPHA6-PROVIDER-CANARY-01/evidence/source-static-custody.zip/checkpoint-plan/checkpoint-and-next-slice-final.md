# Local checkpoint and next canary slice

This is a proposal only. No staging, commit, ref update, provider publication or pin adoption
has occurred. The source checkpoint is the exact independently reviewed 31-path delta at
projected tree 493f2d769113aadb1970ce6955878db34823ff19, based on
b98fc920a0765f21ae5bd38907a902c8f2572f04. The four old queue paths are intentional deletions from
the authorized next-to-active move. Every other changed path is owned implementation, test,
contract, documentation or generated queue/metadata output. A separate exact manifest will
add only the three proposed durable custody files beneath this task's evidence directory.

The helper classifies the task partial and recommends continuing from evidence, consistent
with the PENDING whole task. Git plan is blocked on dirty-tree classification; this manifest
provides the proposed classification for ROOT review, not a bypass or a ready-to-merge claim.
The branch has no upstream, deliberately, because no remote publication is authorized.

After ROOT and independent review bind the final packet, copy only the three proposed custody
files, verify the resulting projected tree, stage the exact listed paths, and create the local
compact checkpoint. Keep the published/stable provider inputs unchanged. Do not execute these
steps before the requested checkpoint review.

The next bounded slice remains in PROVIDER-CANARY-01:

1. Plan a normal local merge from ROOT's clean resource checkpoint
   97e1446bc745e2b7a91706ed7707a3529e107ed7, tree 89fd3b82906ef2f6fb1f68e377c56a4ffe489cf4,
   into this checkpointed canary branch after
   fresh AIDE policy/detect/plan and workspace hygiene checks. Review conflicts, especially
   lifecycle tests, queue/plan projections and generated metadata. No reset, rebase, remote or
   merge execution is authorized by this proposal itself.
2. Add finite per-command and overall deadlines to the local canary subprocess wrappers and
   CMake custody execute_process boundary. Retain command, source identity, elapsed time,
   stdout/stderr, timeout phase and termination outcome; never convert timeout to PASS or
   retry automatically. Terminate only the owned subprocess/process group using a verified
   bounded mechanism. Preserve partial outputs and inspectable fixtures.
3. Exercise deterministic disposable helpers for normal completion, a hanging child, a child
   that spawns a descendant, and exhausted overall budget before dispatch. Prove diagnostics
   survive, no later command starts after expiry, and unrelated sentinel processes/files stay
   untouched. Validate the CMake timeout refusal separately. No live services or host policy
   changes are part of these tests.
4. Freeze and independently review the narrow harness delta, then rerun clean-source static
   consumer qualification after the checked resource sync and local source checkpoint. Bind
   fresh source/build bytes and the exact unchanged USK checkpoint and stable ULK inputs.
   Current supervised C3 results remain valid; they do not qualify autonomous scheduling.

Only after that slice should source-shared runtime closure be proposed using the existing
source_shared mode and exact DLL identities. Installed static/shared/relocated candidate
manifest admission remains separate. Do not label source-built outputs as installed SDK
qualification or relax stable-main/importer identity. Consumer interruption/replay, protected
commit success, generation/stale-owner recovery, retained cleanup and adoption remain open.

ROOT's resource source checkpoint is committed and independently reviewed. Its fresh Windows
package qualification is still running in separate p3 output roots; this source sync proposal
does not infer those results or consume its private outputs. Reverify exact source refs and
any final qualification handoff before execution. The prior cf44 planning note remains an
unchanged historical member of the v3 archive.
