from __future__ import annotations
import hashlib, json, os, shutil, signal, stat, subprocess, sys, tarfile, unittest
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

SOURCE = Path('/mnt/d/Projects/Factorio/factorio-launcher')
TASK = Path('/mnt/d/Development/FacMan/repositories/factorio-launcher-5db2844e2f29/tasks/task-facman-o-38884d9b48')
E = TASK/'evidence'
WORK = E/'world-backup-final-linux-private'
REPORT = E/'world-backup-final-linux-proof.json'
HEAD = '803bd98af05c7343977934a7c1b21c67ed897720'
TREE = '0a038464f24deb5ff946b091dd7b48a78a0ed995'
ARCHIVE = E/'world-backup-final-bundle/FacMan-0.1.0-alpha.6-linux-x64-portable.tar.zst'
ARCHIVE_SHA = '0c4330e8ccf5ee8523e2c0a2b64c0ea8981d1a101d44da8980c8cb90c92a9f94'
sys.dont_write_bytecode = True
sys.path[:0] = [str(SOURCE), str(SOURCE/'tests')]

def require(condition, detail):
    if not condition:
        raise ValueError(detail)

def sha(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data, 'sha256').hexdigest()

def inventory(root):
    result = {}
    for path in sorted(root.rglob('*')):
        require(not path.is_symlink(), 'inventory contains link')
        if path.is_file():
            result[path.relative_to(root).as_posix()] = sha(path)
        else:
            require(path.is_dir(), 'inventory contains nonregular object')
            result[path.relative_to(root).as_posix()+'/'] = 'directory'
    return result

def relative(name):
    path = PurePosixPath(name)
    require(name and '\\' not in name and ':' not in name and not path.is_absolute()
            and all(part not in {'.', '..'} for part in path.parts), 'unsafe member path')
    return path

def worker(parent_namespace):
    require(os.geteuid() == 0 and os.readlink('/proc/self/ns/mnt') != parent_namespace and
            os.readlink(f'/proc/{os.getppid()}/ns/mnt') == parent_namespace,
            'worker must own a new private namespace')
    mounted = False
    decoder = None
    report = dict(status='FAIL', source=HEAD, tree=TREE, candidate_run=37172494677,
                  candidate_attempt=1, archive_sha256=ARCHIVE_SHA, new_roots=0,
                  peak_tmpfs_bytes=128*1024**2+8*1024**2,
                  script_sha256=sha(Path(__file__)),
                  regression_sha256=sha(SOURCE/'tests/integration/facman_world_backup_low_space.py'),
                  save_transfer_sha256=sha(SOURCE/'tests/test_save_transfer.py'),
                  scope='Exact final803 Linux product bytes on WSL; test-only current source oracle. No physical-host, game, human, signing or release authority.')
    try:
        subprocess.run(['mount', '-t', 'tmpfs', '-o', 'size=128m,nodev,nosuid',
                        'tmpfs', str(WORK)], check=True, timeout=10)
        mounted = True
        decoder = subprocess.Popen(['zstd', '-d', '-c', str(ARCHIVE)],
                                   stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                   stderr=subprocess.DEVNULL)
        seen, total = set(), 0
        with tarfile.open(fileobj=decoder.stdout, mode='r|') as archive:
            for member in archive:
                name = relative(member.name)
                total += member.size
                require(name not in seen and len(seen) < 20000 and total <= 64*1024**2 and
                        (member.isfile() or member.isdir()) and not member.issparse() and
                        name.parts[0] == 'FacMan-0.1.0-alpha.6', 'unsafe TAR inventory')
                seen.add(name)
                path = WORK.joinpath(*name.parts)
                if member.isdir():
                    path.mkdir(parents=True, exist_ok=True)
                else:
                    path.parent.mkdir(parents=True, exist_ok=True)
                    with archive.extractfile(member) as data, path.open('xb') as destination:
                        shutil.copyfileobj(data, destination, 1024*1024)
                    path.chmod(member.mode & 0o777)
        decoder.stdout.close()
        require(decoder.wait(timeout=20) == 0, 'archive decoder failed')
        decoder = None
        product = WORK/'FacMan-0.1.0-alpha.6'
        manifest = product/'share/facman/manifest'
        stage = json.loads((manifest/'product-stage.v1.json').read_text())
        require(stage['source_revision'] == HEAD and stage['source_tree'] == TREE and
                not stage['source_dirty'] and stage['platform'] == 'linux', 'product identity differs')
        for item in stage['files']:
            path = product.joinpath(*relative(item['path']).parts)
            require(path.is_file() and path.stat().st_size == item['bytes'] and
                    sha(path) == item['sha256'] and stat.S_IMODE(path.stat().st_mode) == item['mode'],
                    'product stage file differs')
        checksums = {}
        for line in (manifest/'MANIFEST.sha256').read_text().splitlines():
            digest, name = line.split('  ', 1)
            require(name not in checksums and sha(product.joinpath(*relative(name).parts)) == digest,
                    'product checksum differs')
            checksums[name] = digest
        require(set(checksums) == {p.relative_to(product).as_posix() for p in product.rglob('*')
                if p.is_file() and p != manifest/'MANIFEST.sha256'}, 'manifest file closure differs')
        require((product/'FacMan').stat().st_ino != (product/'facman').stat().st_ino,
                'GUI and CLI must be distinct case-sensitive objects')
        before_package = inventory(product)
        before_fixture = inventory(SOURCE/'tests/fixtures/fake_factorio_install')
        starter = SOURCE/'tests/fixtures/factorio_saves/valid_simple_save/starter.zip'
        before_starter = sha(starter)
        os.environ.update(FACMAN_CLI_EXE=str(product/'facman'),
                          PYTHONDONTWRITEBYTECODE='1', PYTHONOPTIMIZE='0',
                          TMPDIR=str(WORK/'test-temp'))
        (WORK/'test-temp').mkdir()
        import tempfile
        tempfile.tempdir = str(WORK/'test-temp')
        suite = unittest.defaultTestLoader.loadTestsFromName('test_save_transfer')
        with (E/'world-backup-final-linux-save-transfer.log').open('x', encoding='utf-8') as log:
            result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
        report.update(tests_run=result.testsRun, skipped=result.skipped,
                      failures=len(result.failures), errors=len(result.errors))
        require(result.testsRun == 19 and result.wasSuccessful() and not result.skipped,
                'exact produced-package save-transfer suite failed; inspect retained log')
        low_space = E/'world-backup-final-linux-low-space.json'
        with (E/'world-backup-final-linux-low-space-supervisor.log').open('x', encoding='utf-8') as log:
            subprocess.run([sys.executable, '-B',
                str(SOURCE/'tests/integration/facman_world_backup_low_space.py'),
                '--executable', str(product/'facman'), '--package-root', str(product),
                '--source-root', str(SOURCE), '--evidence', str(low_space)],
                cwd=SOURCE, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                check=True, timeout=260)
        actual = json.loads(low_space.read_text())
        require(actual['status'] == 'pass' and actual['same_target_retry'], 'real low-space regression failed')
        require(inventory(product) == before_package and
                inventory(SOURCE/'tests/fixtures/fake_factorio_install') == before_fixture and
                sha(starter) == before_starter, 'package or input fixture changed')
        require(not list((WORK/'test-temp').iterdir()), 'suite retained private temporary data')
        report.update(status='PASS', executable_sha256=sha(product/'facman'),
                      product_manifest_files=len(checksums), product_inventory=before_package,
                      same_object_write='same inode, size and restored mtime; CRC-valid changed save refused',
                      low_space_result_sha256=sha(low_space), same_target_retry=True,
                      package_and_fixture_preserved=True, starter_sha256=before_starter)
    except Exception as error:
        report['error'] = repr(error)
    finally:
        if decoder is not None:
            if decoder.poll() is None:
                decoder.kill()
            decoder.wait(timeout=10)
        if mounted:
            cleanup = subprocess.run(['umount', str(WORK)], capture_output=True, text=True, timeout=10)
            report['private_product_unmounted'] = cleanup.returncode == 0
            if cleanup.returncode:
                report.update(status='FAIL', cleanup_error=cleanup.stderr)
        report['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
        with REPORT.open('x', encoding='utf-8') as target:
            target.write(json.dumps(report, indent=2, sort_keys=True)+'\n')
    return 0 if report['status'] == 'PASS' else 1

def main():
    require(sys.platform.startswith('linux') and __debug__, 'Linux and enabled assertions required')
    if len(sys.argv) == 3 and sys.argv[1] == '--worker':
        return worker(sys.argv[2])
    require(len(sys.argv) == 1 and os.geteuid() == 0, 'explicit real Linux root required')
    require(sha(ARCHIVE) == ARCHIVE_SHA and not WORK.exists() and not REPORT.exists(),
            'preserve prior work or archive mismatch')
    # Windows admission already used read_marker; bind its exact WSL path translation here.
    marker = json.loads((TASK/'.facman-development-root.v1.json').read_text())
    require(marker['task_id'] == 'task/facman-owned-backup-presentation-08' and
            marker['owner'] == 'facman-development' and marker['kind'] == 'task-root' and
            marker['source_root'] == r'D:\Projects\Factorio\factorio-launcher' and
            marker['canonical_path'] == r'D:\Development\FacMan\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-o-38884d9b48',
            'task ownership or exact Windows-to-WSL translation differs')
    require(shutil.disk_usage(E).free >= 8*1024**3, 'host storage floor breached')
    require(int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines()
                     if line.startswith('MemAvailable:')))*1024 >= 1024**3, 'Linux memory reserve insufficient')
    WORK.mkdir()
    namespace = os.readlink('/proc/self/ns/mnt')
    with (E/'world-backup-final-linux-proof.runner.log').open('x', encoding='utf-8') as log:
        process = subprocess.Popen(['unshare', '--mount', '--propagation', 'private',
            sys.executable, '-B', str(Path(__file__).resolve()), '--worker', namespace],
            stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
            start_new_session=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONOPTIMIZE='0'))
        try:
            code = process.wait(timeout=420)
        except subprocess.TimeoutExpired:
            if process.poll() is None:
                os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=10)
            raise ValueError('owned proof group exceeded deadline; retain all logs and inspect cleanup')
    require(code == 0 and REPORT.is_file(), 'produced-package proof failed; inspect report/runner log')
    require(os.readlink('/proc/self/ns/mnt') == namespace and not list(WORK.iterdir()),
            'original namespace or underlying mount child changed')
    print(json.dumps(dict(status='PASS', report=str(REPORT), report_sha256=sha(REPORT),
                         tests=19, same_target_retry=True, private_product_unmounted=True)))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
