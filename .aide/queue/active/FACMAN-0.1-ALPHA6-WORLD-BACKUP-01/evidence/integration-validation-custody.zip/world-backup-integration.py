"""Integrate reviewed WorldBackup evidence; reuse the existing source-CI observer."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import zipfile

ROOT = Path(r'D:\Projects\Factorio\factorio-launcher')
E = Path(__file__).resolve().parent
HEAD = 'bfa587f88884dcaed4c748a9c4f69c02f238ac19'
BASE = '6668ef2c55f0e59ed40782121b832878c71e40c9'
TREE = '1910fb74fa2187a5b35beb1b640bbd69989a4202'
BRANCH = 'task/facman-owned-backup-presentation-08'
UNIT = 'FACMAN-0.1-ALPHA6-WORLD-BACKUP-01'
REPO = 'Julesc013/factorio-launcher'
TRUSTED_REF = 'refs/remotes/origin/task-to-dev-trusted-main'
PLAN = E/'world-backup-integration-plan.json'
RECEIPT = E/'world-backup-integration.json'
REVIEW = E/'world-backup-integration.review.json'
CLAIM = E/'world-backup-integration.claim.json'
WORKFLOW_ID = 354614721
RULESET_ID = 23393886
MAIN = 'dc38a5ff2f613a1a13796e6610655bfdd1e00732'
sys.path.insert(0, str(ROOT/'.aide/scripts'))
import aide_lite


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write(path, value):
    temporary = path.with_suffix(path.suffix+'.writing')
    with temporary.open('x', encoding='utf-8', newline='\n') as handle:
        handle.write(json.dumps(value, indent=2)+'\n')
    temporary.replace(path)


def output(*args, timeout=120):
    c = subprocess.run(args, cwd=ROOT, capture_output=True, text=True,
                       encoding='utf-8', errors='replace', timeout=timeout)
    assert c.returncode == 0, {'operation': args[:4], 'exit': c.returncode, 'error': c.stderr[:600]}
    return c.stdout.strip()


def gh(*args):
    return json.loads(output('gh', *args, timeout=60))


def log_command(name, *args):
    path = E/('world-backup-integration-'+name+'.log')
    with path.open('x', encoding='utf-8') as log:
        c = subprocess.run(args, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=180)
    assert c.returncode == 0, {'operation': name, 'exit': c.returncode, 'log': str(path)}


def identity():
    who = output('powershell', '-NoProfile', '-Command',
                 '[System.Security.Principal.WindowsIdentity]::GetCurrent().Name')
    assert who == 'BLACKGLASS-WIN1\\Jules', who
    auth = subprocess.run(['gh', 'auth', 'status'], cwd=ROOT, capture_output=True, timeout=60)
    assert auth.returncode == 0, 'Real-user read-only auth check failed; credential output not stored or printed'
    assert output('gh', 'api', 'user', '--jq', '.login', timeout=60) == 'Julesc013'


def previous_controller_binding():
    """The predecessor is terminal and qualified; this is a new PR372 controller."""
    previous = Path(r'D:\Development\FacMan\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-e-b7250df31d\evidence\existing-install-closeout-integration-rx2.json')
    prior = json.loads(previous.read_text(encoding='utf-8'))
    assert prior['status'] == 'integration_and_automatic_merge_CI_pass' and prior['merge_CI_pass']
    assert prior['merge'] == BASE and prior['expected_head'] == '28843ba31aa6f9e83ab370a4a70ae5c8dba34f78'
    assert prior.get('finished_at_utc') and prior['merge_requests'] == 1
    return {str(previous): sha(previous)}


def local_source():
    marker = json.loads((E.parent/'.facman-development-root.v1.json').read_text(encoding='utf-8'))
    assert Path(marker['canonical_path']).samefile(E.parent) and marker['task_id'] == BRANCH
    assert output('git', 'rev-parse', '--show-toplevel').replace('\\', '/').lower() == str(ROOT).replace('\\', '/').lower()
    assert output('git', 'branch', '--show-current') == BRANCH
    assert output('git', 'rev-parse', 'HEAD') == HEAD
    assert output('git', 'rev-parse', 'HEAD^{tree}') == TREE
    assert not output('git', 'status', '--porcelain')
    assert output('git', 'rev-parse', 'refs/heads/dev') == BASE
    assert output('git', 'rev-parse', 'refs/remotes/origin/dev') == BASE


def source_evidence():
    pins = {'world-backup-regression-final.review.json': 'c80fe211d3b6bb80fc1d2e0f31ed968941da8ad04ca1523220242627c6685232', 'world-backup-regression-commit-classification.json': '438fba33d8c0824063ab70f5cc7b501bf6923478d4510e26f8d5419b0e36db87', 'world-backup-regression-commit-message.txt': 'f7c26d641950a42cf968fec0cee0ed913291ffbdc8db46efdc5f1df832d02098', 'world-backup-acceptance-final.review.json': '70679e7aab9da256f25cb9adef77bed4e80c23f4c33a6b8c1bcca4615ffe401a', 'world-backup-acceptance-commit-classification.json': '7903363305462736facd2684b2ddecdb6fd1e22556b94e802150cd0874d6ae18', 'world-backup-acceptance-commit-message.txt': 'fedea78c41309197bdc471176e1341b97a7e3643634faee12ed1ac10764bacb8', 'world-backup-final-produced-package-runtime.review.json': '4103033e05162cb30d00614ba1620e3e28748b43d60c56f281c323c695f6c4db', 'world-backup-final-linux-parent-postcheck.json': 'e8d5b4fcb1619bb707398c4c33add855c046efa912d10cfe1e7e5e15ea1fe60c', 'world-backup-acceptance-checks.py': 'a0d582331237167638b2c6a75ef50c890e8c3133f48fd63511637e399b4c8057'}
    for name, digest in pins.items():
        assert sha(E/name) == digest, name
    reviewed = [
        ('world-backup-regression', BASE, '803bd98af05c7343977934a7c1b21c67ed897720', '73d4e01b0520f1e2d38ca1618708f2893eeba8a1f1058ada9a524c91443f93a7'),
        ('world-backup-acceptance', '803bd98af05c7343977934a7c1b21c67ed897720', HEAD, 'dddf206d6527bbf7cd88bdd50668ed0a9d840f89432746f5c7cad2933c7b6133'),
    ]
    for prefix, base, head, snapshot in reviewed:
        review = json.loads((E/(prefix+'-final.review.json')).read_text())
        classification = json.loads((E/(prefix+'-commit-classification.json')).read_text())
        assert review['verdict'] == 'PASS'
        assert ((review.get('independent') is True and review.get('non_authoring') is True)
                or review.get('reviewer_role') == 'independent_non_authoring')
        assert classification['branch'] == BRANCH and classification['base_commit'] == base
        for key in ['branch', 'base_commit', 'snapshot_sha256', 'message_sha256']:
            assert review[key] == classification[key], key
        paths = classification['changed_paths']
        assert classification['snapshot_sha256'] == snapshot == aide_lite.helper_commit_snapshot_sha256(paths)
        assert output('git', 'show', '-s', '--format=%P', head) == base
        assert set(output('git', 'diff', '--no-renames', '--name-only', base, head).splitlines()) == {p['path'] for p in paths}
        for item in paths:
            assert item['ownership'] == 'task_owned'
            if item['state'] == 'deleted':
                assert subprocess.run(['git', 'cat-file', '-e', head+':'+item['path']], cwd=ROOT,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode != 0
            else:
                assert item['state'] == 'content'
                assert output('git', 'rev-parse', head+':'+item['path']) == item['git_blob_oid']
                if head == HEAD:
                    assert sha(ROOT/item['path']) == item['sha256']
        assert not aide_lite.protected_control_paths([{'filename': p['path']} for p in paths])
    candidate = json.loads((E/'world-backup-campaign.json').read_text())
    assert candidate['status'] == 'candidate_and_required_PR_checks_pass' and candidate['run_id'] == 37172494677
    proof = json.loads((ROOT/'.aide/queue/active/FACMAN-0.1-ALPHA6-WORLD-BACKUP-01/evidence/produced-package-acceptance.v1.json').read_text())
    assert proof['produced_package']['source_revision'] == '803bd98af05c7343977934a7c1b21c67ed897720'
    assert proof['regression']['linux_tests'] == 19 and proof['regression']['linux_skips'] == 0
    assert not proof['impact_binding']['newer_head_package_provenance'] and not proof['impact_binding']['reproducible_byte_equivalence']
    for path, oid in proof['impact_binding']['unchanged_producer_git_objects'].items():
        assert output('git', 'rev-parse', HEAD+':'+path) == oid
    return pins


def hygiene(prefix):
    stamp = str(time.time_ns())
    for name in ['paths', 'doctor']:
        command = [sys.executable, 'tools/workspace_hygiene.py', name]
        if name == 'doctor':
            command.append('--measure')
        c = subprocess.run(command, cwd=ROOT, capture_output=True, text=True,
                           encoding='utf-8', errors='replace', timeout=120)
        data = json.loads(c.stdout)
        write(E/('world-backup-integration-'+prefix+'-'+name+'-'+stamp+'.json'), data)
        if name == 'doctor':
            assert c.returncode in {0, 1}
            assert set(data['violations']) <= {'unmanaged_secondary_worktrees_present', 'merged_local_task_branches_present'}
            assert len(data['task_roots']) <= 8 and data['task_root_bytes'] <= 20*1024**3
        else:
            assert c.returncode == 0
    assert shutil.disk_usage(E).free >= 8*1024**3


def required_rules():
    rules = gh('api', f'repos/{REPO}/rules/branches/dev')
    checks = [r for r in rules if r['type'] == 'required_status_checks']
    assert checks and all(r['parameters']['strict_required_status_checks_policy'] for r in checks)
    required = {c['context']: c.get('integration_id') for r in checks
                for c in r['parameters']['required_status_checks']}
    original = json.loads((E/'world-backup-campaign.json').read_text(encoding='utf-8'))
    assert required == original['required_contexts']
    assert all(app == 15368 for app in required.values())
    return rules, required


def trusted_publisher(prefix):
    """Bind required promotion to the protected workflow, suite, run and artifact."""
    repository = gh('api', f'repos/{REPO}')
    assert repository['id'] == 1293124404 and repository['default_branch'] == 'main'
    assert gh('api', f'repos/{REPO}/git/ref/heads/main')['object']['sha'] == MAIN
    variable = gh('api', f'repos/{REPO}/actions/variables/FACMAN_TASK_TO_DEV_REQUIRED_WORKFLOW_ID')
    assert variable['value'] == str(WORKFLOW_ID)
    workflow = gh('api', f'repos/{REPO}/actions/workflows/{WORKFLOW_ID}')
    assert workflow['id'] == WORKFLOW_ID and workflow['state'] == 'active'
    assert workflow['path'] == '.github/workflows/task-to-dev-promotion-check.yml'
    ruleset = gh('api', f'repos/{REPO}/rulesets/{RULESET_ID}')
    assert ruleset['id'] == RULESET_ID and ruleset['enforcement'] == 'active' and ruleset['target'] == 'branch'
    assert ruleset['conditions']['ref_name'] == {'include': ['refs/heads/dev'], 'exclude': []}
    bound = [r for r in ruleset['rules'] if r['type'] == 'required_status_checks']
    assert len(bound) == 1 and bound[0]['parameters']['strict_required_status_checks_policy']
    assert bound[0]['parameters']['required_status_checks'] == [{'context': 'task-to-dev-promotion-check', 'integration_id': 15368}]
    effective, _ = required_rules()
    assert any(r['ruleset_id'] == RULESET_ID and r['type'] == 'required_status_checks'
               and r['parameters'] == bound[0]['parameters'] for r in effective)
    checks = [c for c in latest_checks(HEAD) if c['name'] == 'task-to-dev-promotion-check'
              and c['app']['id'] == 15368 and c['external_id'] == 'ruleset-workflow:'+str(WORKFLOW_ID)]
    assert len(checks) == 1 and checks[0]['status'] == 'completed' and checks[0]['conclusion'] == 'success'
    check = checks[0]
    pages = gh('api', '--paginate', '--slurp',
               f'repos/{REPO}/actions/workflows/{WORKFLOW_ID}/runs?head_sha={HEAD}&event=pull_request_target&per_page=100')
    runs = [r for page in pages for r in page['workflow_runs']
            if r['workflow_id'] == WORKFLOW_ID and r['head_sha'] == HEAD
            and r['head_branch'] == BRANCH and r['event'] == 'pull_request_target']
    assert len(runs) == 1, 'Promotion check must have one independently observed trusted workflow run'
    run = runs[0]
    assert run['workflow_id'] == WORKFLOW_ID and run['head_sha'] == HEAD and run['head_branch'] == BRANCH
    assert run['event'] == 'pull_request_target' and run['path'] == workflow['path']
    assert run['status'] == 'completed' and run['conclusion'] == 'success'
    suite = gh('api', f'repos/{REPO}/check-suites/{run["check_suite_id"]}')
    assert suite['app']['id'] == 15368 and suite['head_sha'] == HEAD and suite['head_branch'] == BRANCH
    jobs = gh('api', '--paginate', '--slurp',
              f'repos/{REPO}/actions/runs/{run["id"]}/attempts/{run["run_attempt"]}/jobs?per_page=100')
    write(E/('world-backup-integration-'+prefix+'-producer-jobs.json'), jobs)
    producers = [j for page in jobs for j in page['jobs'] if j['name'] == 'task-to-dev-promotion-check'
                 and any(s['name'] == 'Publish exact-head trusted task-to-dev admission' for s in j['steps'])]
    assert len(producers) == 1
    job = producers[0]
    assert job['run_id'] == run['id'] and job['head_sha'] == HEAD
    assert job['status'] == 'completed' and job['conclusion'] == 'success'
    assert any(s['name'] == 'Publish exact-head trusted task-to-dev admission' and s['conclusion'] == 'success' for s in job['steps'])
    producer_check = gh('api', f'repos/{REPO}/check-runs/{job["id"]}')
    assert producer_check['app']['id'] == 15368 and producer_check['head_sha'] == HEAD
    assert producer_check['check_suite']['id'] == run['check_suite_id']
    assert producer_check['status'] == 'completed' and producer_check['conclusion'] == 'success'
    log = output('gh', 'api', f'repos/{REPO}/actions/jobs/{job["id"]}/logs', timeout=60)
    assert len(log.encode('utf-8')) <= 2*1024**2
    log_path = E/('world-backup-integration-'+prefix+'-trusted-publisher.log')
    with log_path.open('x', encoding='utf-8', newline='\n') as handle:
        handle.write(log+'\n')
    values = {}
    for key in ['WORKFLOW_REF', 'WORKFLOW_SHA', 'BASE_SHA', 'RUN_ID']:
        matches = re.findall(r'(?m)^\d{4}-[^\n ]+Z\s{2,}'+key+r': ([^\r\n]+)$', log)
        assert len(matches) == 1, key
        values[key] = matches[0]
    assert values['BASE_SHA'] == BASE
    assert values['RUN_ID'] == str(run['id'])
    assert aide_lite.task_to_dev_workflow_identity_is_exact(
        run['event'], REPO, values['WORKFLOW_REF'], values['WORKFLOW_SHA'], BASE, HEAD,
        'main', MAIN, run['workflow_id'], WORKFLOW_ID, run['head_sha'])
    # The custom Check API POST may choose a separate app suite. Bind its
    # exact returned identity to the independently verified trusted producer.
    normalized = re.sub(r'(?m)^\d{4}-[^\n ]+Z\s{1,2}', '', log)
    published_responses = []
    for match in re.finditer(r'(?m)^\s*\{', normalized):
        try:
            value, _ = json.JSONDecoder().raw_decode(normalized[match.start():].lstrip())
        except json.JSONDecodeError:
            continue
        if (isinstance(value, dict) and value.get('name') == 'task-to-dev-promotion-check'
                and value.get('external_id') == 'ruleset-workflow:'+str(WORKFLOW_ID)):
            published_responses.append(value)
    assert len(published_responses) == 1, 'Require the exact custom check response in the trusted producer log'
    published_check = published_responses[0]
    for key in ['id', 'node_id', 'name', 'head_sha', 'external_id', 'status', 'conclusion', 'output']:
        assert published_check[key] == check[key], key
    assert published_check['app']['id'] == check['app']['id'] == 15368
    assert published_check['check_suite']['id'] == check['check_suite']['id']
    custom_suite = gh('api', f'repos/{REPO}/check-suites/{check["check_suite"]["id"]}')
    assert custom_suite['head_sha'] == HEAD and custom_suite['head_branch'] == BRANCH
    assert custom_suite['app']['id'] == 15368
    artifacts = gh('api', '--paginate', '--slurp', f'repos/{REPO}/actions/runs/{run["id"]}/artifacts?per_page=100')
    artifacts = [a for page in artifacts for a in page['artifacts']
                 if a['name'] == f'task-to-dev-promotion-status-372-{MAIN}']
    assert len(artifacts) == 1
    artifact = artifacts[0]
    assert not artifact['expired'] and artifact['size_in_bytes'] <= 64*1024
    assert artifact['workflow_run']['id'] == run['id'] and artifact['workflow_run']['head_sha'] == HEAD
    assert artifact['workflow_run']['repository_id'] == repository['id']
    archive = E/('world-backup-integration-'+prefix+'-trusted-status.zip')
    with archive.open('xb') as handle:
        c = subprocess.run(['gh', 'api', f'repos/{REPO}/actions/artifacts/{artifact["id"]}/zip'],
                           cwd=ROOT, stdout=handle, stderr=subprocess.PIPE, timeout=60)
    assert c.returncode == 0 and archive.stat().st_size <= 64*1024
    with zipfile.ZipFile(archive) as z:
        members = z.infolist()
        assert len(members) == 1 and members[0].filename == 'task-to-dev-promotion-status.v1.json'
        assert members[0].file_size <= 64*1024
        status = json.loads(z.read(members[0]))
    assert status['repository'] == REPO and status['pull_request_number'] == 372
    assert (status['head_oid'], status['base_oid'], status['trusted_main_oid']) == (HEAD, BASE, MAIN)
    assert status['conclusion'] == 'success' and status['full_history_checked'] and not status['blockers']
    assert status['candidate_code_executed'] is False
    assert gh('api', f'repos/{REPO}/git/ref/heads/main')['object']['sha'] == MAIN
    observation = dict(repository=repository, variable=variable, workflow=workflow, ruleset=ruleset,
                       check=check, run=run, suite=suite, job=job, producer_check=producer_check,
                       published_check_response=published_check, custom_check_suite=custom_suite, artifact=artifact,
                       protected_workflow_log_values=values, log_sha256=sha(log_path),
                       archive_sha256=sha(archive), hosted_status=status,
                       binding='Active ruleset requires exact context/app. Independently observed pinned protected workflow ID/run/suite/job and protected ref/SHA log return this exact custom check ID/response; the custom app suite may differ. Current main, exact dev base/head and hosted full-history artifact are independently bound. Variable alone is insufficient.',
                       observed_at_utc=now(), release_authority=False)
    write(E/('world-backup-integration-'+prefix+'-trusted-publisher.json'), observation)
    return dict(workflow_id=WORKFLOW_ID, ruleset_id=RULESET_ID, main=MAIN,
                run_id=run['id'], check_id=check['id'], check_suite_id=suite['id'],
                hosted_status_archive_sha256=sha(archive), observation=prefix)


def prepare():
    assert not PLAN.exists() and not RECEIPT.exists()
    prior_pins = previous_controller_binding()
    local_source(); source_evidence(); identity(); hygiene('prepare')
    for operation in ['inspect', 'noop-check', 'recover']:
        log_command('prepare-task-'+operation, sys.executable, '.aide/scripts/aide_lite.py',
                    'task', operation, '--task-id', UNIT)
    for operation in ['policy', 'detect', 'plan']:
        log_command('prepare-git-'+operation, sys.executable, '.aide/scripts/aide_lite.py', 'git', operation)
    land = aide_lite.make_git_helper_plan(ROOT, 'land', source=BRANCH, target='dev', validation_ok=True)
    assert land['status'] == 'ready_dry_run' and not land['blockers']
    message = aide_lite.git_helper_merge_message('land', BRANCH, 'dev')
    assert aide_lite.commit_message_result(aide_lite.validate_commit_message_text(message, repo_root=ROOT)) != 'FAIL'
    subject, body = message.split('\n\n', 1)
    body_path = E/'world-backup-merge-body.txt'
    assert not body_path.exists()
    body_path.write_text(body, encoding='utf-8', newline='\n')
    rules, required = required_rules()
    claim = json.loads((E/'world-backup-acceptance-checks.claim.json').read_text())
    state = json.loads((E/'world-backup-acceptance-checks.json').read_text())
    assert claim['head'] == state['head'] == HEAD and state['base'] == BASE
    assert claim['PID'] == state['PID']
    observer = dict(PID=claim['PID'], started_at_utc=state['started_at_utc'],
                    claim_sha256=sha(E/'world-backup-acceptance-checks.claim.json'),
                    script_sha256=sha(E/'world-backup-acceptance-checks.py'))
    assert observer['script_sha256'] == claim['script_sha256']
    if state.get('finished_at_utc'):
        assert state['status'] == 'current_head_checks_pass' and not state['missing_required']
        observer['already_terminal'] = True
    else:
        process = json.loads(output('powershell', '-NoProfile', '-Command',
            "Get-CimInstance Win32_Process -Filter 'ProcessId = "+str(claim['PID'])+"' | ForEach-Object { [pscustomobject]@{PID=$_.ProcessId;Created=$_.CreationDate.ToUniversalTime().ToString('o');CommandLine=$_.CommandLine} } | ConvertTo-Json -Compress"))
        assert process['PID'] == observer['PID']
        assert 'world-backup-acceptance-checks.py' in process['CommandLine']
        observer.update(process)
    argv = ['gh', 'pr', 'merge', '372', '--repo', REPO, '--merge', '--match-head-commit', HEAD,
            '--subject', subject, '--body-file', str(body_path)]
    write(PLAN, dict(schema='facman.exact_checked_integration_plan.v1', status='prepared',
                    source_head=HEAD, base=BASE, source_tree=TREE, branch=BRANCH, PR=372,
                    script_sha256=sha(Path(__file__)), merge_body_sha256=sha(body_path),
                    qualified_predecessor_pins=prior_pins,
                    source_review_pins=source_evidence(), required_contexts=required, rules=rules,
                    atomic_controller_claim=str(CLAIM), existing_observer=observer,
                    helper_land_plan=land, merge_argv=argv,
                    local_sync_argv=[['git', 'switch', 'dev'], ['git', 'merge', '--ff-only', '<verified-merge-oid>']],
                    local_retirement_argv=['git', 'branch', '-d', BRANCH],
                    authority='User continuation authorizes qualified normal PR integration, dev synchronization and exact-head merged task retirement',
                    trigger='All exact-head required and observed checks pass; previous base automatic merge CI passes; fresh exact source/base, strict rules, publisher and history; independent controller review',
                    no_admin_bypass=True, no_protected_ref_push=True, no_release_authority=True,
                    new_roots=0, source_edits=0, candidate_dispatches=0, reruns=0,
                    external_gates_preserved=['PR343 owner exact-head control command', 'approved game input', 'human experience', 'packaged Play'],
                    canonical_unit_closure_already_committed=False, prepared_at_utc=now()))
    print(json.dumps({'status': 'prepared', 'plan': str(PLAN), 'plan_sha256': sha(PLAN)}))


def latest_checks(head):
    pages = gh('api', '--paginate', '--slurp', f'repos/{REPO}/commits/{head}/check-runs?per_page=100')
    runs = [c for page in pages for c in page['check_runs']]
    assert all(c['head_sha'] == head for c in runs)
    latest = {}
    for c in sorted(runs, key=lambda x: x['id']):
        latest[(c['name'], c['app']['id'])] = c
    return list(latest.values())


def fresh_admission(record):
    controller_binding(record)
    local_source(); source_evidence(); identity(); hygiene('admission')
    prior = json.loads((Path(r'D:\Development\FacMan\repositories\factorio-launcher-5db2844e2f29\tasks\task-facman-e-b7250df31d\evidence\existing-install-closeout-integration-rx2.json')).read_text(encoding='utf-8'))
    assert prior['merge'] == BASE and prior['status'] == 'integration_and_automatic_merge_CI_pass' and prior['merge_CI_pass']
    plan = json.loads(PLAN.read_text(encoding='utf-8'))
    rules, required = required_rules()
    publisher = trusted_publisher('admission')
    repo = gh('api', f'repos/{REPO}')
    assert repo['allow_merge_commit'] and repo['default_branch'] == 'main'
    assert gh('api', f'repos/{REPO}/git/ref/heads/dev')['object']['sha'] == BASE
    view = gh('pr', 'view', '372', '--json', 'state,isDraft,headRefOid,baseRefOid,headRefName,baseRefName,mergeable,mergeStateStatus,statusCheckRollup')
    assert view['state'] == 'OPEN' and not view['isDraft']
    assert (view['headRefOid'], view['baseRefOid'], view['headRefName'], view['baseRefName']) == (HEAD, BASE, BRANCH, 'dev')
    assert view['mergeable'] == 'MERGEABLE' and view['mergeStateStatus'] == 'CLEAN', view['mergeStateStatus']
    for c in view['statusCheckRollup']:
        if c['__typename'] == 'CheckRun':
            assert c['status'] == 'COMPLETED' and c['conclusion'] in {'SUCCESS', 'NEUTRAL', 'SKIPPED'}, c['name']
        else:
            assert c['state'] == 'SUCCESS', c['context']
    runs = latest_checks(HEAD)
    for name, app in required.items():
        assert any(c['name'] == name and c['app']['id'] == app and c['status'] == 'completed'
                   and c['conclusion'] == 'success' for c in runs), name
    pages = gh('api', '--paginate', '--slurp', f'repos/{REPO}/pulls/372/files?per_page=100')
    assert not aide_lite.protected_control_paths([f for page in pages for f in page])
    for operation in ['policy', 'detect', 'plan']:
        log_command('admission-git-'+operation, sys.executable, '.aide/scripts/aide_lite.py', 'git', operation)
    land = aide_lite.make_git_helper_plan(ROOT, 'land', source=BRANCH, target='dev', validation_ok=True)
    assert land['status'] == 'ready_dry_run' and not land['blockers']
    existing = subprocess.run(['git', 'show-ref', '--verify', '--quiet', TRUSTED_REF], cwd=ROOT)
    assert existing.returncode == 1, 'Preserve any pre-existing trusted-main cache ref'
    main = gh('api', f'repos/{REPO}/git/ref/heads/main')['object']['sha']
    log_command('trusted-main-fetch', 'git', 'fetch', '--no-tags', 'origin', 'refs/heads/main:'+TRUSTED_REF)
    try:
        assert output('git', 'rev-parse', TRUSTED_REF) == main
        assert gh('api', f'repos/{REPO}/git/ref/heads/main')['object']['sha'] == main
        history = E/'world-backup-integration-history.json'
        assert not history.exists()
        log_command('full-history', sys.executable, '.aide/scripts/aide_lite.py', 'git', 'task-to-dev-status',
                    '--repository', REPO, '--pull-request', '372', '--base', BASE, '--head', HEAD,
                    '--trusted-main', main, '--output', str(history))
        status = json.loads(history.read_text(encoding='utf-8'))
        assert status['conclusion'] == 'success' and status['full_history_checked'] and not status['blockers']
    finally:
        if output('git', 'rev-parse', TRUSTED_REF) == main:
            log_command('trusted-main-cache-retire', 'git', 'update-ref', '-d', TRUSTED_REF, main)
    assert sha(E/'world-backup-merge-body.txt') == plan['merge_body_sha256']
    local_source()
    assert gh('api', f'repos/{REPO}/git/ref/heads/dev')['object']['sha'] == BASE
    record.update(admission_rules=rules, required_contexts=required, admitted_PR=view,
                  admitted_check_runs=runs, trusted_main=main, trusted_publisher=publisher, admitted_at_utc=now())


def controller_binding(record):
    assert sha(PLAN) == record['plan_sha256']
    assert sha(REVIEW) == record['controller_review_sha256']
    plan = json.loads(PLAN.read_text(encoding='utf-8'))
    assert previous_controller_binding() == plan['qualified_predecessor_pins']
    assert sha(Path(__file__)) == plan['script_sha256']


def integrate(record):
    controller_binding(record)
    plan = json.loads(PLAN.read_text(encoding='utf-8'))
    record.update(status='merge_request_issued', merge_argv=plan['merge_argv'], merge_requests=1)
    write(RECEIPT, record)
    log_command('merge-request', *plan['merge_argv'])
    view = gh('pr', 'view', '372', '--json', 'state,headRefOid,baseRefName,mergeCommit,mergedAt')
    assert view['state'] == 'MERGED' and view['headRefOid'] == HEAD and view['baseRefName'] == 'dev'
    merge = view['mergeCommit']['oid']
    log_command('merged-dev-fetch', 'git', 'fetch', '--no-tags', 'origin', 'refs/heads/dev:refs/remotes/origin/dev')
    assert output('git', 'rev-parse', 'refs/remotes/origin/dev') == merge
    assert output('git', 'show', '-s', '--format=%P', merge).split() == [BASE, HEAD]
    assert output('git', 'rev-parse', merge+'^{tree}') == TREE
    record.update(status='exact_merge_verified_sync_pending', merge=merge, merged_at=view['mergedAt'])
    write(RECEIPT, record)
    assert not output('git', 'status', '--porcelain')
    assert output('git', 'branch', '--show-current') == BRANCH
    assert output('git', 'rev-parse', 'HEAD') == HEAD and output('git', 'rev-parse', 'dev') == BASE
    log_command('sync-git-plan', sys.executable, '.aide/scripts/aide_lite.py', 'git', 'plan')
    log_command('switch-dev', 'git', 'switch', 'dev')
    log_command('sync-dev-fast-forward', 'git', 'merge', '--ff-only', merge)
    assert output('git', 'rev-parse', 'HEAD') == merge and not output('git', 'status', '--porcelain')
    assert output('git', 'rev-parse', 'refs/heads/'+BRANCH) == HEAD
    assert not output('git', 'rev-list', HEAD, '--not', merge)
    dependent = gh('pr', 'list', '--base', BRANCH, '--state', 'open', '--json', 'number')
    assert not dependent, 'Keep source branch used by an open PR'
    assert 'branch refs/heads/'+BRANCH not in output('git', 'worktree', 'list', '--porcelain').splitlines()
    log_command('retire-git-plan', sys.executable, '.aide/scripts/aide_lite.py', 'git', 'plan')
    prune = aide_lite.make_git_helper_plan(ROOT, 'prune', target='dev')
    candidate = [c for c in prune['prune_candidates'] if c['branch'] == BRANCH]
    assert len(candidate) == 1 and candidate[0]['eligible']
    log_command('retire-local-task', 'git', 'branch', '-d', BRANCH)
    remote = output('git', 'ls-remote', '--heads', 'origin', 'refs/heads/'+BRANCH)
    record.update(status='merged_dev_synchronized_local_task_retired', local_dev=merge,
                  branch_retired=True, remote_task_ref='absent' if not remote else 'present; retained for separately checked retirement',
                  evidence_root_retained=True, private_data_deleted=False, synchronized_at_utc=now())
    write(RECEIPT, record)
    return merge


def observe_merge(record, merge):
    required = {name: app for name, app in record['required_contexts'].items()
                if name != 'task-to-dev-promotion-check'}
    deadline = time.monotonic()+5400
    record.update(status='automatic_merge_CI_observation', merge_CI_dispatches=0)
    write(RECEIPT, record)
    while time.monotonic() < deadline:
        checks = latest_checks(merge)
        failures = [c for c in checks if c['status'] == 'completed' and c['conclusion'] not in {'success', 'neutral', 'skipped'}]
        missing = [name for name, app in required.items() if not any(c['name'] == name and c['app']['id'] == app
                   and c['status'] == 'completed' and c['conclusion'] == 'success' for c in checks)]
        if failures:
            record.update(status='automatic_merge_CI_actionable_failure', merge_checks=checks,
                          failures=[{'name': c['name'], 'url': c['html_url']} for c in failures]); return
        if checks and not missing and all(c['status'] == 'completed' for c in checks):
            record.update(status='integration_and_automatic_merge_CI_pass', merge_checks=checks,
                          merge_CI_pass=True, canonical_unit_closure=False); return
        assert shutil.disk_usage(E).free >= 8*1024**3
        time.sleep(30)
    record.update(status='automatic_merge_CI_deadline')


def observe_PR(record):
    """Consume the existing observer's terminal result; never duplicate CI polling."""
    expected = json.loads(PLAN.read_text())['existing_observer']
    deadline = time.monotonic()+5400
    while time.monotonic() < deadline:
        observer = json.loads((E/'world-backup-acceptance-checks.json').read_text())
        assert observer['head'] == HEAD and observer['base'] == BASE and observer['PID'] == expected['PID']
        assert observer['started_at_utc'] == expected['started_at_utc']
        assert sha(E/'world-backup-acceptance-checks.claim.json') == expected['claim_sha256']
        assert sha(E/'world-backup-acceptance-checks.py') == expected['script_sha256']
        record.update(status='existing_observer_transition_wait', source_observer_status=observer['status'])
        if observer.get('finished_at_utc'):
            if observer['status'] != 'current_head_checks_pass':
                record.update(status='source_observer_actionable_result', observer_result=observer)
                return False
            assert not observer['missing_required']
            record.update(status='required_PR_and_base_CI_pass', all_checks_pass=True)
            write(RECEIPT, record)
            return True
        process = json.loads(output('powershell', '-NoProfile', '-Command',
            "Get-CimInstance Win32_Process -Filter 'ProcessId = "+str(expected['PID'])+"' | ForEach-Object { [pscustomobject]@{ProcessId=$_.ProcessId;Created=$_.CreationDate.ToUniversalTime().ToString('o');CommandLine=$_.CommandLine} } | ConvertTo-Json -Compress"))
        assert process['ProcessId'] == expected['PID'] and process['Created'] == expected['Created']
        assert process['CommandLine'] == expected['CommandLine']
        assert shutil.disk_usage(E).free >= 8*1024**3
        write(RECEIPT, record)
        time.sleep(30)
    record.update(status='existing_observer_transition_deadline')
    return False


def arm():
    assert not RECEIPT.exists(), 'Never replay an issued merge or branch operation'
    plan = json.loads(PLAN.read_text(encoding='utf-8'))
    assert previous_controller_binding() == plan['qualified_predecessor_pins']
    review = json.loads(REVIEW.read_text(encoding='utf-8'))
    assert review['verdict'] == 'PASS' and review['plan_sha256'] == sha(PLAN)
    assert review['script_sha256'] == sha(Path(__file__)) == plan['script_sha256']
    assert review['non_authoring'] and review['independent']
    with CLAIM.open('x', encoding='utf-8', newline='\n') as handle:
        handle.write(json.dumps(dict(schema='facman.exclusive_controller_claim.v1', PID=os.getpid(),
                      plan_sha256=sha(PLAN), script_sha256=sha(Path(__file__)), review_sha256=sha(REVIEW),
                      source_head=HEAD, base=BASE, created_at_utc=now(),
                      recovery='Persistent claim; never reclaim automatically after exit, crash or ambiguous request. Inspect task/Git/GitHub operation evidence first.'), indent=2)+'\n')
        handle.flush(); os.fsync(handle.fileno())
    record = dict(schema='facman.exact_checked_integration.v1', status='existing_observer_transition_wait',
                  expected_head=HEAD, expected_base=BASE, PR=372,
                  plan_sha256=sha(PLAN), controller_review_sha256=sha(REVIEW), started_at_utc=now(),
                  merge_requests=0, model_wait_calls=0, new_roots=0, candidate_dispatches=0, CI_reruns=0)
    write(RECEIPT, record)
    try:
        local_source(); source_evidence(); identity()
        if observe_PR(record):
            fresh_admission(record)
            merge = integrate(record)
            observe_merge(record, merge)
    except BaseException as exc:
        record.update(status='integration_stopped_for_actionable_review', error=repr(exc),
                      next_action='Inspect retained exact operation state before recovery; never replay ambiguous merge or discard unique work')
    record['finished_at_utc'] = now(); write(RECEIPT, record)
    print(json.dumps({k: record.get(k) for k in ['status','merge','local_dev','merge_CI_pass','error','finished_at_utc']}))


if __name__ == '__main__':
    if not __debug__ or os.environ.get('PYTHONOPTIMIZE') != '0' or os.environ.get('PYTHONDONTWRITEBYTECODE') != '1':
        raise RuntimeError('Run with assertions enabled and bytecode disabled, exact reviewed environment required')
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--arm', action='store_true')
    parser.add_argument('--publisher-check', action='store_true')
    args = parser.parse_args()
    assert sum([args.prepare, args.arm, args.publisher_check]) == 1
    if args.publisher_check:
        previous_controller_binding(); local_source(); source_evidence(); identity()
        print(json.dumps(trusted_publisher('verification')))
    else:
        prepare() if args.prepare else arm()
