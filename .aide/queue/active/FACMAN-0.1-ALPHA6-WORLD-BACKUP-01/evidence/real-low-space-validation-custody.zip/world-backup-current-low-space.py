"""Real ENOSPC proof on exact PR-tree produced Linux CLI bytes; no release claim."""
from pathlib import Path
import datetime
import errno
import hashlib
import json
import os
import shutil
import subprocess
import sys

SOURCE = Path('/mnt/d/Projects/Factorio/factorio-launcher')
E = Path(__file__).resolve().parent
PACKAGE_SOURCE = 'bd6678ee384af052e2739a814ab6950eb8afdb73'
BUNDLE = E/'world-backup-current-linux-package/linux-package-proof'
WORK = E/'world-backup-current-low-space'
RECEIPT = E/'world-backup-current-low-space.json'
records = []


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def invoke(executable, workspace, label, arguments, expected=0):
    environment = {k: v for k, v in os.environ.items() if not k.startswith('FACMAN_TEST_')}
    argv = [str(executable), '--workspace', str(workspace), *arguments, '--json']
    result = subprocess.run(argv, cwd=WORK, env=environment, capture_output=True,
                            text=True, encoding='utf-8', timeout=30)
    (WORK/(label+'.stdout')).write_text(result.stdout, encoding='utf-8')
    (WORK/(label+'.stderr')).write_text(result.stderr, encoding='utf-8')
    records.append(dict(label=label, argv=argv, exit=result.returncode))
    assert result.returncode == expected, (label, result.returncode, result.stdout[-1000:], result.stderr[-1000:])
    envelope = json.loads(result.stdout)
    assert envelope['schema'] == 'facman.transport_response.v2'
    assert isinstance(envelope['payload'], dict)
    return envelope['payload']


def inventory(root):
    return {p.relative_to(root).as_posix(): sha(p) for p in root.rglob('*') if p.is_file()}


def main():
    assert sys.platform == 'linux' and os.geteuid() == 0
    marker = json.loads((E.parent/'.facman-development-root.v1.json').read_text())
    assert marker['task_id'] == 'task/facman-owned-backup-presentation-08'
    expected_root = 'd:/development/facman/repositories/factorio-launcher-5db2844e2f29/tasks/task-facman-o-38884d9b48'
    assert marker['canonical_path'].replace('\\', '/').lower() == expected_root
    assert marker['source_root'].replace('\\', '/').lower() == 'd:/projects/factorio/factorio-launcher'
    assert not WORK.exists() and not RECEIPT.exists(), 'Retain original attempt; never overwrite'
    parent_namespace = os.environ['FACMAN_PROOF_PARENT_MOUNT_NAMESPACE']
    namespace = os.readlink('/proc/self/ns/mnt')
    assert namespace != parent_namespace, 'Must run in a separate private mount namespace'
    subprocess.run(['mount', '--make-rprivate', '/'], check=True, timeout=10)
    WORK.mkdir()
    bundle = json.loads((BUNDLE/'evidence.v1.json').read_text())
    assert bundle['schema'] == 'facman.linux_cli_package_proof.v1' and bundle['status'] == 'pass'
    assert bundle['profile_id'] == 'linux_portable_cli_x64' and bundle['required_skips'] == 0
    assert bundle['source_revisions']['factorio_launcher'] == PACKAGE_SOURCE
    assert bundle['artifact'] == 'facman-0.1.0-alpha.6-linux-cli-x64-portable.tar.gz'
    archive = BUNDLE/'dist'/bundle['artifact']
    assert archive.stat().st_size == bundle['artifact_size'] == 26638079
    assert sha(archive) == bundle['artifact_sha256'] == '92549e2a4646fe8e655727f6ddff48de23fa6f3d4017c51202679752542ff7a8'
    binding = json.loads((E/'world-backup-current-linux-source-binding.json').read_text())
    assert binding['sha'] == PACKAGE_SOURCE and binding['tree']['sha'] == '8a70f7ebb7c1aa74c1b68c521c3ddc452c5db696'
    assert [p['sha'] for p in binding['parents']] == ['eada9df6eed0353671500e6d5a8e0bc0365300d8', '28843ba31aa6f9e83ab370a4a70ae5c8dba34f78']
    extraction = WORK/'package'
    extraction.mkdir()
    import tarfile
    total = 0
    with tarfile.open(archive, mode='r:gz') as tar:
        for count, member in enumerate(tar, 1):
            total += member.size
            assert count <= 20000 and member.size >= 0 and total <= 512*1024**2
            assert member.isfile() or member.isdir(), 'Refuse archive links and special files'
            tar.extract(member, extraction, filter='data')
    executable = extraction/'bin/facman'
    assert executable.is_file() and not executable.is_symlink()
    build_info = json.loads((extraction/'manifest/build_info.v1.json').read_text())
    assert build_info['source_revisions'] == bundle['source_revisions']
    sys.path.insert(0, str(SOURCE))
    from tools import package_hash_manifest, provenance_build
    assert not package_hash_manifest.verify_manifest(extraction)
    provenance = archive.with_name(archive.name+'.provenance.v1.json')
    assert not provenance_build.verify_artifact_provenance(provenance, archive, extraction)
    package_before = inventory(extraction)
    volume = WORK/'volume'
    volume.mkdir()
    workspace_volume = WORK/'workspace-volume'
    workspace_volume.mkdir()
    workspace = workspace_volume/'workspace'
    mounted = False
    workspace_mounted = False
    report = dict(schema='facman.scoped_produced_package_test.v1', status='fail',
        source_revision=PACKAGE_SOURCE, source_tree=binding['tree']['sha'],
        github_run_id='37167358630', github_run_attempt='1',
        portable_sha256=sha(archive), extracted_cli_sha256=sha(executable),
        package_layout='linux_portable_cli_x64', test_script_sha256=sha(Path(__file__)),
        source_binding_sha256=sha(E/'world-backup-current-linux-source-binding.json'),
        PR_head='28843ba31aa6f9e83ab370a4a70ae5c8dba34f78', integration_preview=True,
        host=dict(platform=sys.platform, uname=list(os.uname()), uid=os.geteuid(),
                  mount_namespace=namespace, parent_mount_namespace=parent_namespace),
        commands=records, new_task_roots=0, candidate_dispatches=0, fault_injection=False,
        qualification=dict(exact_current_PR_tree=True, release=False, support=False, game=False, human=False),
        scope='Exact current PR371-tree Linux CLI integration-preview package low-space proof. Synthetic PR merge-source identity is retained; this is not final product-family, release, supported-host, game or human qualification.')
    try:
        subprocess.run(['mount', '-t', 'tmpfs', '-o', 'size=4M,nodev,nosuid,noexec',
                        'facman-backup-workspace-proof', str(workspace_volume)], check=True, timeout=10)
        workspace_mounted = True
        subprocess.run(['mount', '-t', 'tmpfs', '-o', 'size=4M,nodev,nosuid,noexec',
                        'facman-backup-low-space-proof', str(volume)], check=True, timeout=10)
        mounted = True
        initial = shutil.disk_usage(volume)
        assert initial.total <= 4*1024**2
        invoke(executable, workspace, 'register', ['installs', 'import',
            str(SOURCE/'tests/fixtures/fake_factorio_install'), '--id', 'fixture'])
        invoke(executable, workspace, 'instance', ['instances', 'create', 'Source World', '--install', 'fixture'])
        source = workspace/'instances/source-world/saves/world.zip'
        shutil.copyfile(SOURCE/'tests/fixtures/factorio_saves/valid_simple_save/starter.zip', source)
        source_before = sha(source)
        kept = volume/'kept.backup.zip'
        invoke(executable, workspace, 'positive-backup', ['saves', 'backup', 'world',
            '--instance', 'source-world', '--to', str(kept)])
        retained = inventory(volume)
        assert {p.relative_to(volume).as_posix() for p in volume.rglob('*')} == {'kept.backup.zip', 'kept.backup.zip.manifest.json'}
        assert sha(kept) == source_before and (volume/'kept.backup.zip.manifest.json').is_file()
        filler = volume/'owned-capacity-filler'
        written = 0
        with filler.open('xb', buffering=0) as stream:
            while written <= 4*1024**2:
                try:
                    count = stream.write(b'\0'*4096)
                    assert count > 0
                    written += count
                except OSError as error:
                    assert error.errno == errno.ENOSPC
                    break
            else:
                raise AssertionError('Bounded tmpfs did not exhaust')
        full = shutil.disk_usage(volume)
        assert full.free < 128*1024 and written <= 4*1024**2
        target = volume/'refused.backup.zip'
        refused = invoke(executable, workspace, 'real-low-space-refusal', ['saves', 'backup', 'world',
            '--instance', 'source-world', '--to', str(target)], expected=1)
        assert refused['refusal']['code'] == 'persistent_write_refused', refused
        assert not target.exists() and not Path(str(target)+'.manifest.json').exists()
        assert sha(source) == source_before
        assert {name: sha(volume/name) for name in retained} == retained
        assert {p.relative_to(volume).as_posix() for p in volume.rglob('*')} == set(retained) | {filler.name}
        assert not list(workspace.rglob('.facman-copy-*')) and not list(workspace.rglob('.facman-save-backup-*'))
        filler.unlink()
        restored = shutil.disk_usage(volume)
        assert restored.free >= source.stat().st_size+128*1024
        recovered = volume/'recovered.backup.zip'
        invoke(executable, workspace, 'capacity-restored-backup', ['saves', 'backup', 'world',
            '--instance', 'source-world', '--to', str(recovered)])
        assert sha(recovered) == source_before and sha(source) == source_before
        assert {name: sha(volume/name) for name in retained} == retained
        assert {p.relative_to(volume).as_posix() for p in volume.rglob('*')} == set(retained) | {'recovered.backup.zip', 'recovered.backup.zip.manifest.json'}
        assert inventory(extraction) == package_before
        report.update(status='pass', capacity=dict(initial=list(initial), full=list(full),
            restored=list(restored), filler_bytes=written), refusal=refused['refusal'],
            source_sha256=source_before, retained_backup_hashes=retained,
            checks=['real_positive_backup', 'kernel_ENOSPC', 'typed_low_space_refusal',
                    'no_partial_backup_or_sidecar', 'source_preserved', 'prior_backup_and_manifest_preserved',
                    'no_owned_stage_residue', 'capacity_restored_success', 'package_bytes_preserved'])
    except BaseException as error:
        report['error'] = repr(error)
    finally:
        try:
            if mounted:
                subprocess.run(['umount', str(volume)], check=True, timeout=10)
        finally:
            if workspace_mounted:
                subprocess.run(['umount', str(workspace_volume)], check=True, timeout=10)
        report['finished_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        with RECEIPT.open('x', encoding='utf-8') as stream:
            stream.write(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'commands'}))
    return 0 if report['status'] == 'pass' else 1


if __name__ == '__main__':
    raise SystemExit(main())
